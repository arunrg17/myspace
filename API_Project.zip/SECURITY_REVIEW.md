# Security review — API Test Suite (engine, server, GUI)

Reviewed: engine v2.13.0 (bundled), server v2.0.0 (single app), GUI v1.1.0.
Scope: code vulnerabilities, third-party / external references, and any trace of
the values from the original screenshots.

## Summary

No blocking issues found. The controls that matter for a shared, browser-facing
tool on a mounted volume — path containment, no process execution at all, XML
parser hardening, secret handling, output escaping — are present and covered by
tests. Merging the engine in-process removed the subprocess surface rather than
adding one.
Nothing reaches out to a third-party network endpoint at runtime, and none of
the real data values from the screenshots appear anywhere in the code, tests,
or documentation.

## 1. Screenshot data

A scan across all three packages for the real account ids, product names,
endpoints, balances and identifiers from the original screenshots returns zero
matches in source, tests, resources and docs. Every fixture uses invented
placeholders (`ACC001`, `CUST1`, `Sample`, `example.test`). This has been kept
clean across every build and is re-checked here.

## 2. External and third-party references

The only absolute URLs in the source are:

- **XML parser feature URIs** (`http://apache.org/xml/features/...`,
  `http://xml.org/sax/...`). These are constant identifiers passed to the XML
  parser to switch features off — they are never fetched. They are, in fact,
  what disables external access.
- **Placeholder hint text** in the GUI settings form (`https://api.github.com`,
  `https://host/api/v3`) shown as greyed examples in input fields, not calls.
- **A changelog comment** describing an old bug fix that mentioned a malformed
  URL. Documentation only.

No analytics, telemetry, CDN, web font, or external API call exists in any
package. The GUI is built with all assets local; the report inlines all its CSS
and JS. Both run with no outbound network dependency — which is what lets them
work in a locked-down environment.

## 3. Code vulnerabilities

### Path traversal — controlled
Every filesystem path derived from user input goes through
`WorkspaceService.resolve`, which normalises the path and rejects anything that
does not stay within its workspace area. Upload filenames are reduced to their
final segment, so a crafted name cannot write outside the target folder. The
workbooks area accepts only `.xlsx`/`.xlsm`. The template endpoint uses a fixed
filename with no user input in the path. Covered by tests for `../` escapes,
crafted upload names, and area confinement.

### Command execution — none
The engine now runs in-process (a bundled library called on a worker thread),
so there is no subprocess at all: no `ProcessBuilder`, no `Runtime.exec`, no
shell. This removes the command-execution surface entirely — nothing the user
supplies is ever passed to a process or shell.

### XML external entities (XXE) — disabled
Every XML parser in the engine sets `FEATURE_SECURE_PROCESSING`, disables
DOCTYPE declarations, disables external general and parameter entities, and
disables external DTD loading. This closes XXE and billion-laughs vectors on
responses, expected files and templates alike.

### Server-side request forgery (SSRF) — bounded
The one place the server reads a path chosen at runtime — fetching a workbook
from the configured shared folder — confines the source to the configured
directory: the normalised path must start with the configured root, or the
request is refused. It reads local files only; it does not dereference URLs.

### Secrets — referenced, masked, never logged
The engine keeps credentials out of the workbook via `${env.NAME}` and
`${file:key}` references. The server masks secret settings (e.g. a Git token) in
every response, and a masked value sent back on save never overwrites the stored
secret. A scan for secret-like values in log/print statements found none. TLS
material and tokens are logged by length only where logged at all.

### Cross-site scripting (XSS) — escaped at the source
The report escapes all response content, test names, errors and diff values as
HTML. The GUI has no `dangerouslySetInnerHTML`, `eval`, or `innerHTML` sink. The
report opens same-origin, which is safe precisely because its content is
escaped before it is ever written.

### Denial of the shared volume — addressed by the dry-run toggle
Dry runs (save off) execute in a temporary directory that is deleted on
completion, so repeated automation runs cannot fill the volume with results
nobody keeps. Kept runs are one self-contained folder each, holding only the
small JSON plus console log — trivial to prune on a retention schedule.

## 4. Residual notes (not defects)

- **Authentication is delegated.** The server has no user login of its own; it
  is meant to sit behind the enterprise gateway/SSO, and already reads an
  `X-User` header into the audit log. Deploy it behind the gateway, not exposed
  directly.
- **The audit log is a trail, not access control.** It records who uploaded,
  deleted and ran what. It does not authorise — that is the gateway's job.
- **Dry-run reports live in server memory** until viewed, by design, so they
  never touch the volume. They are lost on restart, which is the intended
  trade-off for not persisting them.

## Checks run

- Keyword scan for screenshot values across source, tests, resources, docs — 0 hits.
- External URL inventory — only parser feature URIs, placeholder hints, one comment.
- Containment tests (`../` escapes, crafted filenames, area confinement) — pass.
- Secret-logging scan — 0 hits.
- Web XSS-sink scan (`eval`, `innerHTML`, `dangerouslySetInnerHTML`) — 0 hits.
- Engine test suite — 250 pass. Server service tests — 16 pass.
