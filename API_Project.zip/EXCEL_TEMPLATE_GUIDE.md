# Excel Template Guide

How the workbook is organised, what each sheet and column means, and how to keep
it tidy when several people are entering data.

Template shipped with engine 2.15.5, at `config/test_suite.xlsx`.


## Sheets

| Sheet | Holds |
|---|---|
| README | Reference notes, kept inside the workbook so they travel with it |
| Environments | One row per target: URL, protocol, auth, and database settings |
| TestSuite | One row per test: name, comparison mode, sources, baseline file |
| Steps | The requests inside each test, in order |
| TestData | Values that fill the `${placeholders}` in endpoints and bodies |
| Assertions | Field checks and ignore directives |

Columns are read **by header name**, not by position. That means you can reorder
columns, and a column the engine does not know about is simply ignored. It also
means a header typo makes that column invisible to the engine, so the header row
is the one thing not to edit casually.


## Formatting that is already applied

The shipped template has:

- A styled header row on every data sheet
- **Frozen header row**, so headers stay visible as you scroll
- **Filter dropdowns** on every header
- Wrapped text and top alignment on data cells, so a long path or template stays
  readable
- Borders on the used range
- **Validation dropdowns** on the columns with a fixed set of values:

| Sheet | Column | Values |
|---|---|---|
| Environments | Protocol | rest, soap |
| Environments | AuthType | none, basic, bearer, apikey |
| TestSuite | ComparisonMode | vs_expected, vs_env, vs_protocol, assert_only, chain |
| TestSuite | Enabled | Y, N |
| Steps | Method | GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS |
| Assertions | PathType | jsonpath, xpath, sql |
| Assertions | Operator | the full operator list |

The Method dropdown is deliberately non-strict so an unusual verb can still be
typed in.


## The formatting problem, and the button

When several people add rows, formatting drifts: borders stop, wrapping is lost,
a row is left unaligned. Nothing breaks - the engine reads values, not
formatting - but the sheet becomes hard to read.

### Why the button is not already in the file

A clickable button runs a macro, and a macro can only live in a macro-enabled
workbook (`.xlsm`). The shipped template is a plain `.xlsx` for two reasons:

- The tooling that generates the template cannot author VBA, so the macro has to
  be added once by hand whichever way we ship it.
- Many banks block macro-enabled workbooks by policy, or strip them at the mail
  gateway. Shipping an `.xlsm` as the default would make the template unusable
  for anyone under that policy.

So the macro is documented here, and adding it takes about two minutes. If your
environment blocks macros, the section after it gives a no-macro alternative
that solves the same problem.

### Adding the Format button

1. Open `test_suite.xlsx` and save it as **`test_suite.xlsm`**
   (File, Save As, choose *Excel Macro-Enabled Workbook*).
2. Press **Alt + F11** to open the VBA editor.
3. **Insert, Module**.
4. Paste the code below.
5. Close the editor. On any sheet: **Insert, Shapes**, draw a rectangle, type
   "Format Sheets" on it, right-click it, **Assign Macro**, choose
   `FormatWorkbook`, click OK.
6. Save. Click the shape whenever you have finished entering data.

```vba
Option Explicit

' Re-applies the standard formatting to every data sheet. Safe to run as often
' as you like: it only touches formatting, never cell values.
Public Sub FormatWorkbook()
    Dim sheetNames As Variant
    Dim i As Long
    Dim ws As Worksheet
    Dim lastRow As Long, lastCol As Long
    Dim body As Range, headerRow As Range

    sheetNames = Array("Environments", "TestSuite", "Steps", "TestData", "Assertions")

    Application.ScreenUpdating = False
    On Error GoTo CleanUp

    For i = LBound(sheetNames) To UBound(sheetNames)
        On Error Resume Next
        Set ws = ThisWorkbook.Worksheets(sheetNames(i))
        On Error GoTo CleanUp
        If Not ws Is Nothing Then

            lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
            lastCol = ws.Cells(1, ws.Columns.Count).End(xlToLeft).Column
            If lastRow < 1 Then lastRow = 1
            If lastCol < 1 Then lastCol = 1

            ' Header
            Set headerRow = ws.Range(ws.Cells(1, 1), ws.Cells(1, lastCol))
            With headerRow
                .Interior.Color = RGB(31, 56, 100)
                .Font.Color = vbWhite
                .Font.Bold = True
                .Font.Size = 11
                .HorizontalAlignment = xlLeft
                .VerticalAlignment = xlCenter
            End With
            ws.Rows(1).RowHeight = 20

            ' Body
            If lastRow > 1 Then
                Set body = ws.Range(ws.Cells(2, 1), ws.Cells(lastRow, lastCol))
                With body
                    .VerticalAlignment = xlTop
                    .HorizontalAlignment = xlLeft
                    .WrapText = True
                    .Font.Bold = False
                    .Interior.Pattern = xlNone
                End With
            End If

            ' Borders over the whole used block
            With ws.Range(ws.Cells(1, 1), ws.Cells(lastRow, lastCol))
                .Borders.LineStyle = xlContinuous
                .Borders.Weight = xlThin
                .Borders.Color = RGB(191, 191, 191)
            End With

            ' Trim stray spaces that break an exact match later
            TrimCells ws, lastRow, lastCol

            ' Freeze the header and refresh the filter
            ws.Activate
            ActiveWindow.FreezePanes = False
            ws.Range("A2").Select
            ActiveWindow.FreezePanes = True

            If ws.AutoFilterMode Then ws.AutoFilterMode = False
            ws.Range(ws.Cells(1, 1), ws.Cells(lastRow, lastCol)).AutoFilter

            ws.Rows("2:" & lastRow).EntireRow.AutoFit
        End If
        Set ws = Nothing
    Next i

    ThisWorkbook.Worksheets(sheetNames(0)).Activate
    ThisWorkbook.Worksheets(sheetNames(0)).Range("A1").Select
    MsgBox "Formatting applied to all data sheets.", vbInformation, "Done"

CleanUp:
    Application.ScreenUpdating = True
    If Err.Number <> 0 Then
        MsgBox "Could not finish formatting: " & Err.Description, vbExclamation
    End If
End Sub

' Removes leading and trailing spaces from text cells. A trailing space in an
' environment name or a test id stops it matching anything, and is invisible.
Private Sub TrimCells(ws As Worksheet, lastRow As Long, lastCol As Long)
    Dim c As Range
    For Each c In ws.Range(ws.Cells(2, 1), ws.Cells(lastRow, lastCol))
        If Not IsEmpty(c.Value) Then
            If VarType(c.Value) = vbString Then
                If c.Value <> Trim(c.Value) Then c.Value = Trim(c.Value)
            End If
        End If
    Next c
End Sub
```

The macro only changes formatting and trims stray spaces around text. It never
changes a value otherwise, never adds or deletes rows, and never touches the
header names the engine reads by.

The space trimming is worth having on its own: a trailing space in an
environment name or a TestID is invisible on screen and stops the row matching
anything.

### If macros are blocked

Two options that need no VBA:

**Format Painter.** Select a correctly formatted data row, click Format Painter,
drag over the new rows. Quick for a handful of rows.

**Convert each sheet to an Excel Table.** Select the used range including the
header, then **Insert, Table**, and tick "My table has headers". A Table extends
its formatting to any row typed underneath it, so drift stops happening rather
than needing to be corrected. The engine is unaffected: it reads cells by sheet
and header name, and a Table changes neither. This is the better long-term
answer if your environment blocks macros.


## Keeping the workbook clean

- **Never put a real password in a cell.** Use `${env.NAME}` or
  `${file./absolute/path.properties:key}`. The workbook then holds no
  credentials and can be shared or committed.
- **Watch for trailing spaces** in ids and environment names. The Format button
  trims them; without it they are invisible and cause confusing no-match
  failures.
- **Paths are case sensitive.** `returnCode` and `returncode` are different
  fields, and a wrong case shows up as "path resolved to empty" rather than as
  an error.
- **Do not rename headers.** Columns are matched by header name; a renamed
  header makes that column invisible to the engine and the value is silently
  ignored.
- **Adding a column is safe.** Anything the engine does not recognise is
  ignored, so a team can keep its own notes columns in the same sheet.
