# APEX Test Suite - Deployment Guide

This guide takes you from three source folders to a running application that your
team can reach in a browser. It is written to be followed step by step, and it
calls out every path and value you might need to change.

There are two ways to run APEX:

- **Option A - Single machine (JAR).** Simplest. One Java process on a server or
  VM. Good for a team sharing one internal host.
- **Option B - Container (Docker / Kubernetes).** For a managed platform such as
  GKE, with a mounted volume and SSO in front.

Read Section 1 first (it applies to both), then follow A or B.

---

## 0. What you have and what it becomes

You have three source folders:

| Folder | What it is |
|---|---|
| `api-test-suite-java` | The test engine. A library - it does not run on its own. |
| `api-test-suite-server` | The web application (Spring Boot). This is what runs. The engine is compiled into it. |
| `api-test-suite-web` | The browser UI (React). It is built into static files that the server serves. |

The end result is **one running process** (the server) that serves the UI and
the API together on one port. There is no separate database and no separate
front-end server.

---

## 1. Prerequisites and the one build order that matters

Install these on the machine where you will **build** (they are not needed on the
machine where it runs, except Java):

| Tool | Version | Check with |
|---|---|---|
| Java (JDK) | 21 | `java -version` |
| Maven | 3.9+ | `mvn -version` |
| Node.js | 20+ | `node -version` |
| npm | 10+ | `npm -version` |

**The build order is not optional.** The server depends on the engine as a
library, so the engine must be installed into your local Maven repository first,
then the UI is built, then the server is packaged. Doing these out of order fails
with "cannot find artifact com.apitest:api-test-suite".

The correct order is: **engine -> UI -> server**. Section 2 does exactly this.

---

## 2. Build (both options need this)

Run these from the folder that contains all three source folders.

### 2.1 Build and install the engine

```bash
cd api-test-suite-java
mvn clean install
cd ..
```

This compiles the engine and places it in your local Maven repo (`~/.m2`) as
`com.apitest:api-test-suite:2.13.2`, where the server will find it.

> If you ever bump the engine version, the number in
> `api-test-suite-java/pom.xml`, `api-test-suite-java/.../Version.java`, and the
> dependency in `api-test-suite-server/pom.xml` must all match. They are aligned
> at 2.13.2 in this release.

### 2.2 Build the UI

```bash
cd api-test-suite-web
npm install
npm run build
cd ..
```

This produces `api-test-suite-web/dist/` - the compiled UI.

### 2.3 Copy the UI into the server, then package

The server serves the UI from `src/main/resources/static/`. Replace that folder
with the freshly built UI so the two are always in sync:

```bash
cd api-test-suite-server
rm -rf src/main/resources/static
mkdir -p src/main/resources/static
cp -r ../api-test-suite-web/dist/* src/main/resources/static/
mvn clean package
cd ..
```

You now have the runnable artifact:
`api-test-suite-server/target/api-test-suite-server-2.9.0.jar`

> **Tip:** the release ZIP already has the built UI inside
> `src/main/resources/static/`, so if you deploy from the ZIP you can skip 2.2
> and 2.3 and just run `mvn clean package` in the server folder (after 2.1).

---

## 3. The workspace - the one path you must decide

APEX reads and writes everything under a single folder called the **workspace**.
This is the one location you choose. It holds uploaded workbooks, templates,
expected baselines, run history, and settings. Nothing is hardcoded - you point
the app at this folder with one environment variable.

Inside the workspace, the app creates and manages this structure for you:

```
<workspace>/
  projects/
    default/
      areas/
        workbooks/     <- your .xlsx test suites
        templates/     <- request-body templates referenced from Excel
        expected/      <- expected-response baselines referenced from Excel
        runs/          <- run history and reports (written by the app)
      config/          <- settings and project registry
```

You do **not** create the inner folders by hand - the app creates them on first
start. You only create the top-level workspace folder and make sure the app can
write to it.

**Pick a path now.** Examples:
- Linux server: `/var/lib/apex/workspace`
- Windows server: `D:\apex\workspace`
- Container: `/data` (a mounted volume)

Create it and ensure the account running APEX owns it:

```bash
sudo mkdir -p /var/lib/apex/workspace
sudo chown $USER /var/lib/apex/workspace
```

### Where test authors put their files

When someone writes a test suite, their Excel workbook can reference template
files and expected-response files by name. Those referenced files must live in
the `templates/` and `expected/` folders of the workspace. Authors can upload
workbooks straight from the UI (Files screen), or you can copy them into
`.../areas/workbooks/` directly on the server. Same for templates and expected
baselines.

---

## 4. Configuration - every setting you can change

All configuration is by environment variable. There are no paths to edit in the
code. These are the only settings:

| Variable | Default | What it does |
|---|---|---|
| `APITEST_WORKSPACE` | `./workspace` | The workspace folder from Section 3. **Set this.** |
| `SERVER_PORT` | `8080` | The port the app listens on. |
| `APITEST_JAVABINARY` | `java` | Rarely needed; left for compatibility. |

The multipart upload limit (50 MB) is set in
`api-test-suite-server/src/main/resources/application.properties`. Raise it there
only if your workbooks or baselines are larger than that.

---

## Option A - Run on a single machine (JAR)

The runtime machine needs only **Java 21** installed - not Maven or Node.

1. Copy `api-test-suite-server-2.9.0.jar` to the machine.
2. Create the workspace folder (Section 3).
3. Start it:

```bash
export APITEST_WORKSPACE=/var/lib/apex/workspace
export SERVER_PORT=8080
java -jar api-test-suite-server-2.9.0.jar
```

Open `http://<machine-ip>:8080` in a browser.

### Run it as a service (so it survives reboots) - Linux systemd

Create `/etc/systemd/system/apex.service`:

```ini
[Unit]
Description=APEX Test Suite
After=network.target

[Service]
User=apex
Environment=APITEST_WORKSPACE=/var/lib/apex/workspace
Environment=SERVER_PORT=8080
ExecStart=/usr/bin/java -jar /opt/apex/api-test-suite-server-2.9.0.jar
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now apex
sudo systemctl status apex
```

### Letting colleagues reach it

If teammates on the same network cannot open the page but can ping the machine,
the firewall is almost always the cause. On Windows:

```powershell
New-NetFirewallRule -DisplayName "APEX 8080" -Direction Inbound -LocalPort 8080 -Protocol TCP -Action Allow
```

On Linux (ufw):

```bash
sudo ufw allow 8080/tcp
```

If it still is not reachable, your corporate network may isolate hosts from each
other - that is a network-team question, not an app setting.

---

## Option B - Run in a container (Docker / Kubernetes)

### B.1 Dockerfile

Put this `Dockerfile` in the `api-test-suite-server` folder. It builds in two
stages so the final image is small and contains only a JRE.

```dockerfile
# ---- build stage ----
FROM maven:3.9-eclipse-temurin-21 AS build
WORKDIR /src
# Bring in all three source folders (build context = the parent folder).
COPY api-test-suite-java   api-test-suite-java
COPY api-test-suite-web    api-test-suite-web
COPY api-test-suite-server api-test-suite-server
# Engine first.
RUN cd api-test-suite-java && mvn -q clean install
# UI next (needs Node in this stage).
RUN apt-get update && apt-get install -y nodejs npm \
 && cd api-test-suite-web && npm install && npm run build \
 && rm -rf ../api-test-suite-server/src/main/resources/static \
 && mkdir -p ../api-test-suite-server/src/main/resources/static \
 && cp -r dist/* ../api-test-suite-server/src/main/resources/static/
# Server last.
RUN cd api-test-suite-server && mvn -q clean package -DskipTests

# ---- run stage ----
FROM eclipse-temurin:21-jre
WORKDIR /app
COPY --from=build /src/api-test-suite-server/target/api-test-suite-server-2.9.0.jar app.jar
ENV APITEST_WORKSPACE=/data
ENV SERVER_PORT=8080
EXPOSE 8080
ENTRYPOINT ["java","-jar","app.jar"]
```

Build the image **from the parent folder** (so all three folders are in the build
context):

```bash
docker build -f api-test-suite-server/Dockerfile -t apex:2.9.0 .
```

Run it, mounting a host folder as the workspace so data survives restarts:

```bash
docker run -d --name apex -p 8080:8080 \
  -v /var/lib/apex/workspace:/data \
  apex:2.9.0
```

### B.2 Kubernetes

APEX is a single stateless container plus one read-write volume for the
workspace. The essentials:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: apex
spec:
  replicas: 1                      # one replica: it writes to one shared volume
  selector:
    matchLabels: { app: apex }
  template:
    metadata:
      labels: { app: apex }
    spec:
      containers:
        - name: apex
          image: <your-registry>/apex:2.9.0
          ports: [{ containerPort: 8080 }]
          env:
            - { name: APITEST_WORKSPACE, value: /data }
          volumeMounts:
            - { name: workspace, mountPath: /data }
      volumes:
        - name: workspace
          persistentVolumeClaim: { claimName: apex-workspace }
---
apiVersion: v1
kind: Service
metadata:
  name: apex
spec:
  selector: { app: apex }
  ports: [{ port: 80, targetPort: 8080 }]
```

The workspace PVC should be `ReadWriteOnce` (one replica) or a shared
`ReadWriteMany` filesystem if you ever scale out. Keep replicas at 1 unless you
move to a shared filesystem, because run history is written to disk.

### B.3 Access control

APEX has **no built-in login** - by design, so it can sit behind your existing
identity layer. Put it behind your ingress with SSO / an identity-aware proxy
(for GKE, that is IAP). Do not expose it directly to an untrusted network.

---

## 4a. Database drivers (for DB assertions)

The suite can validate response values against a database using `db_*`
assertions (see 4b). The engine does not bundle any JDBC driver, because vendor
drivers are licensed separately - you add the one your database needs to the
runtime classpath.

If you see an error like `JDBC driver not found: oracle.jdbc.OracleDriver`, the
driver jar is not on the classpath. To fix it:

1. Obtain the driver jar from your database vendor:
   - Oracle: `ojdbc11.jar` (from Oracle's website or your DBA)
   - PostgreSQL: `postgresql-<version>.jar`
   - SQL Server: `mssql-jdbc-<version>.jar`
2. Put it beside the application jar, then start with it on the classpath:

   ```bash
   # Linux/Mac - colon separator
   java -cp "api-test-suite-server-2.10.0.jar:ojdbc11.jar" \
     org.springframework.boot.loader.launch.JarLauncher

   # Windows - semicolon separator
   java -cp "api-test-suite-server-2.10.0.jar;ojdbc11.jar" ^
     org.springframework.boot.loader.launch.JarLauncher
   ```

   For a container, `COPY ojdbc11.jar /app/` in the Dockerfile and use the same
   `-cp` form in the entrypoint.

3. In the workbook's Environments sheet, set the driver class in the `DbDriver`
   column (for Oracle that is `oracle.jdbc.OracleDriver`) and the connection
   string in `DbURL` (for Oracle, `jdbc:oracle:thin:@host:1521/service`). The
   `DbUser` and `DbPassword` columns complete the connection; both accept
   `${env.VAR}` so credentials can come from environment variables rather than
   living in the sheet.

DB assertions are read-only: the engine rejects anything that is not a single
`SELECT`/`WITH`, blocks multiple statements, sets the connection read-only, and
bounds each query with a timeout.

## 4b. Assertion features (per-step and database)

Assertions live on the optional `Assertions` sheet, one row each, with columns
`TestID`, `StepOrder`, `Path`, `PathType`, `Operator`, `ExpectedValue`,
`Description`.

- **Per-step assertions.** Leave `StepOrder` blank (or 0) and the assertion runs
  once against the final response, as before. Set it to a step's number and the
  assertion runs right after that step, against that step's response. Not every
  step needs one. This works in `chain` mode too, so a single chained
  create/update/delete test can validate at each stage.

- **Carrying a value between steps.** A step can capture a value from its
  response with the `ExtractVars` column (for example `portfolioId=$.portfolioNumber`).
  Later steps - and any step-scoped assertion - reference it as
  `${step1.portfolioId}`. The reference resolves inside the endpoint, the body,
  and inside a DB assertion's SQL, so a server-generated id created in step 1 can
  be validated in the database in step 1's assertion and reused to update and
  delete in later steps.

- **DB operators.** `db_exists` (query returns at least one row), `db_equals`
  (first column of the first row equals ExpectedValue - use `SELECT COUNT(*) ...`
  expecting `0` to confirm a delete), `db_contains` (first value contains
  ExpectedValue), and `db_rows` for multi-row checks.

- **Validating several rows (db_rows).** When a response lists several ids for a
  customer and you need the database to contain exactly those rows, put a query
  returning one column in `Path` and the expected values, comma-separated, in
  `ExpectedValue`:

  ```
  Operator:      db_rows
  Path:          SELECT portfolio_number FROM portfolios WHERE customer_id = 'C1'
  ExpectedValue: PF-100, PF-101, PF-102
  ```

  The check is order-independent and reports any missing or unexpected rows. Left
  blank, `ExpectedValue` just requires more than one row to come back.

- **POST/PUT without a body.** The `BodyTemplate` column is optional. Leave it
  empty when the request carries its data in the endpoint itself; the request is
  sent with no body.


## 5. First-run checklist

1. Open the app. You should see the **APEX** sidebar and the **New run** screen.
2. Go to **Files** and upload a workbook (`.xlsx`), or drop one into
   `.../areas/workbooks/` on disk.
3. Back on **New run**, pick the workbook and press **Execute**.
4. Watch the console stream; when it finishes, the **Summary** tab shows the
   counts and a link to the HTML report.
5. **Suite health** shows trends once you have a few runs.

If the run finishes but the summary looks empty, confirm the workspace volume is
writable by the app account - the app needs to write the report back to
`.../runs/` and read it again.

---

## 6. Backups and housekeeping

Everything that matters is under the workspace folder. Back that one folder up and
you have backed up all workbooks, baselines, settings, and history. Old runs are
compacted and gzipped automatically, but if `.../runs/` grows large over months,
it is safe to delete old run subfolders.

---

## 7. Where to change common things (quick reference)

| I want to change... | Where |
|---|---|
| The workspace location | `APITEST_WORKSPACE` env var (Section 4) |
| The port | `SERVER_PORT` env var |
| The product name shown in the UI | `api-test-suite-web/src/App.tsx` (the `APEX` text) and `index.html` (the `<title>`), then rebuild the UI (2.2-2.3) |
| The upload size limit | `application.properties` in the server |
| The engine version | keep it identical in the engine `pom.xml`, engine `Version.java`, and the server `pom.xml` dependency |

There are no absolute file paths baked into the source. Everything the app reads
or writes is resolved under the single workspace folder you choose.
