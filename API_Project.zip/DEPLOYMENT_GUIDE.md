# Deployment Guide

How to build, configure and run the API test suite, including how to keep the
workbook, templates, baselines and reports in a Google Cloud Storage bucket.

Engine version: 2.15.5. This covers the standalone jar; there is no server
component in this package.


## 1. Prerequisites

| Requirement | Notes |
|---|---|
| JDK 21 | The POM targets 21. Older JDKs will not compile it. |
| Maven | Any recent 3.x. |
| Internal Maven repository access | The dependencies, including the Oracle JDBC driver if you keep it in the POM, resolve from your internal repository rather than the public internet. On a corporate network this usually means VPN plus a `settings.xml` with the mirror and your credentials. |
| JDBC driver | Only if tests use `db_*` assertions or `${sql:...}` values. |

A fresh machine that has never built this project needs the VPN connection and
`~/.m2/settings.xml` before anything else. A missing `settings.xml` shows up as
Maven failing to resolve a parent POM or a dependency, which reads like a
project problem but is an environment one.


## 2. Build

```bash
mvn clean package
```

Produces the shaded jar in `target/`. It contains all dependencies, so nothing
else needs to be on the classpath at run time.

Tests only:

```bash
mvn test
```


## 3. Layout on disk

```
<work dir>/
  config/
    test_suite.xlsx          the workbook
    secrets.properties       optional, referenced from the workbook
  templates/                 request body templates
  expected/                  baseline responses for vs_expected
  reports/                   generated HTML reports
  runs/                      per-run request and response artifacts
```

None of these paths are fixed; every one is a command line flag.


## 4. Running

```bash
java -jar api-test-suite.jar \
  --suite         config/test_suite.xlsx \
  --templates-dir templates \
  --expected-dir  expected \
  --output-dir    runs \
  --report        reports/report.html
```

`--help` lists all flags. The exit code is non-zero when any test fails, so a CI
job can gate on it.


## 5. Secrets

Never put a real password in the workbook. A password cell accepts:

| Form | Resolves to |
|---|---|
| `${env.DB_PASSWORD}` | The environment variable of that name |
| `${file./opt/apitest/secrets.properties:db_password}` | The named key from a properties file |
| a literal | The value itself - avoid outside a throwaway local run |

Use an **absolute path** in the `${file...}` form. A relative path is resolved
against the process working directory, not the workbook, so it only works when
the tool happens to be launched from exactly the right place. A file that cannot
be read resolves to an empty password, which usually surfaces later as a
confusing SSL or login failure rather than a missing-file error, so check the
console for a warning about an unreadable properties file when diagnosing one.

Key names are case sensitive: `TRUST_PASS` in the reference must be `TRUST_PASS`
in the file.

Permissions: `chmod 600` the properties file and keep it outside the project
directory so it cannot be committed.


## 6. Using a Google Cloud Storage bucket

The engine reads and writes ordinary files through `java.nio.file`. There are
two ways to put those files in a bucket. The first needs no code change at all
and is the recommendation.

### 6a. Mount the bucket as a filesystem (recommended, no code changes)

Cloud Storage FUSE presents a bucket as a directory, and the tool then reads and
writes it exactly as it does local disk.

**Install and mount on a VM:**

```bash
export GCSFUSE_REPO=gcsfuse-$(lsb_release -c -s)
echo "deb https://packages.cloud.google.com/apt $GCSFUSE_REPO main" \
  | sudo tee /etc/apt/sources.list.d/gcsfuse.list
curl https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key add -
sudo apt-get update && sudo apt-get install -y gcsfuse

sudo mkdir -p /mnt/apitest
gcsfuse --implicit-dirs my-apitest-bucket /mnt/apitest
```

**Run against the mount:**

```bash
java -jar api-test-suite.jar \
  --suite         /mnt/apitest/config/test_suite.xlsx \
  --templates-dir /mnt/apitest/templates \
  --expected-dir  /mnt/apitest/expected \
  --output-dir    /mnt/apitest/runs \
  --report        /mnt/apitest/reports/report.html
```

**Bucket layout.** Mirror the local layout so the same flags work either way:

```
gs://my-apitest-bucket/
  config/test_suite.xlsx
  templates/
  expected/
  reports/
  runs/
```

**Authentication.** On a GCE VM, GKE pod or Cloud Run job, attach a service
account and gcsfuse picks it up automatically. Off Google infrastructure, point
at a key file:

```bash
export GOOGLE_APPLICATION_CREDENTIALS=/etc/apitest/gcs-sa.json
```

**IAM.** Grant on the bucket, not the project:

| The run does | Role |
|---|---|
| Reads workbook and templates, writes reports and runs | `roles/storage.objectAdmin` |
| Reads only, writes results to local disk | `roles/storage.objectViewer` |

**On Cloud Run jobs** use the built-in volume mount rather than installing
gcsfuse yourself:

```yaml
volumes:
  - name: apitest-data
    csi:
      driver: gcsfuse.run.googleapis.com
      volumeAttributes:
        bucketName: my-apitest-bucket
volumeMounts:
  - name: apitest-data
    mountPath: /mnt/apitest
```

**On GKE** enable the Cloud Storage FUSE CSI driver and declare a
PersistentVolume backed by the bucket, then mount it into the pod at
`/mnt/apitest`.

**What to know about a FUSE mount.** It is object storage behind a filesystem
interface, not a general purpose disk:

- Reads and writes are whole-object operations. The report is uploaded once when
  the file is closed, which suits this tool.
- There is no file locking. Two runs writing the same report path overwrite each
  other, so give each run its own output path:
  `--report /mnt/apitest/reports/run-$(date +%Y%m%d-%H%M%S).html`
- Listing a large directory is slower than local disk. Keep `runs/` pruned, or
  point `--output-dir` at local disk and only put the report in the bucket.
- The workbook is read once at the start, so a slower first read costs a second
  and nothing more.
- Keep truststores, keystores and the secrets properties file on **local disk**,
  not in the bucket.

### 6b. Use the Cloud Storage SDK directly (code changes required)

Only worth doing if a FUSE mount is not permitted, because it means changing
every file access.

Add the dependency:

```xml
<dependency>
  <groupId>com.google.cloud</groupId>
  <artifactId>google-cloud-storage</artifactId>
  <version>2.40.0</version>
</dependency>
```

Rather than sprinkling SDK calls through the code, introduce one interface with
two implementations - local disk and GCS - and route every access through it:

```java
public interface FileStore {
    InputStream read(String path) throws IOException;
    String readString(String path) throws IOException;
    void writeString(String path, String content) throws IOException;
    void createDirectories(String path) throws IOException;
}
```

The GCS implementation maps a `gs://bucket/key` path onto `Storage.get` and
`Storage.create`, and treats `createDirectories` as a no-op because object
storage has no directories.

**Every place that touches a file, and what each needs:**

| File | Around line | Operation | Purpose |
|---|---|---|---|
| `excel/ExcelLoader` | 37 | `new FileInputStream` | Reads the workbook; needs a stream from the bucket |
| `template/TemplateEngine` | 191 | `Files.readString` | Reads a request body template |
| `runner/Runner` | 237 | `Files.readString` | Reads the baseline for `vs_expected` |
| `runner/Runner` | 80, 148, 303, 511 | `Files.createDirectories` | No-op against a bucket |
| `runner/Runner` | 512, 514, 520 | `Files.writeString` | Per-step request, response, render log |
| `reporter/Reporter` | 29, 30 | `createDirectories`, `writeString` | Writes the HTML report |
| `reporter/JsonReport` | 83 | `createDirectories` | Writes the JSON report |
| `dispatcher/SslConfig` | - | file read | Truststore, keystore, secrets file. Leave these on local disk |

Budget roughly a day including tests. The mount achieves the same result in an
afternoon with no code change and no new dependency, which is why it is the
recommendation.

### 6c. Choosing

| | FUSE mount | SDK |
|---|---|---|
| Code changes | None | Every file access |
| New dependency | None | google-cloud-storage |
| Works with the jar you already built | Yes | No, needs a rebuild |
| Fine-grained control | Limited | Full |
| Effort | Hours | Days |


## 7. Running in CI

The tool is a jar with an exit code, so it drops into any runner:

```yaml
- name: API tests
  run: |
    java -jar api-test-suite.jar \
      --suite  "$WORKBOOK" \
      --report "reports/run-${BUILD_ID}.html"
```

Publish `reports/` as a build artifact. The report is one self-contained file,
so it needs no web server and no assets beside it.


## 8. Docker

```dockerfile
FROM eclipse-temurin:21-jre
WORKDIR /app
COPY target/api-test-suite.jar /app/api-test-suite.jar
# Only if tests use database assertions
COPY drivers/ /app/drivers/
ENTRYPOINT ["java", "-jar", "/app/api-test-suite.jar"]
```

```bash
docker run --rm \
  -v /data/apitest:/data \
  -e DB_PASSWORD \
  api-test-suite \
  --suite  /data/config/test_suite.xlsx \
  --report /data/reports/report.html
```

Pass secrets as environment variables and reference them from the workbook as
`${env.DB_PASSWORD}`. Do not bake them into the image.


## 9. Troubleshooting

| Symptom | Usual cause |
|---|---|
| Maven cannot resolve a parent POM or dependency | Not on VPN, or no `~/.m2/settings.xml` pointing at the internal repository |
| `ClassNotFoundException` for a JDBC driver | Driver jar not on the classpath; add it or put the dependency back in the POM |
| SSL handshake failure after adding a truststore | The `${file...}` path is relative, or the key name case does not match. Check the console for a warning about an unreadable properties file |
| A database assertion is rejected before running | Only `SELECT` and `WITH` are accepted, and only one statement per assertion |
| An assertion reports the path resolved to empty | The path does not match. Paths are case sensitive and a nested level is easy to miss. Use the `XPathTester` helper against a saved response to try a path before putting it in the workbook |
| Report is very large | A test captured a very large response. Trim what the suite requests, or prune `runs/` |
| Two runs overwrite each other's report on a bucket | Give each run its own `--report` path; a FUSE mount has no file locking |
