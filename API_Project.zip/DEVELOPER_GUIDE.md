# Developer Guide

For developers who will maintain, extend or build the API test suite. It covers
how the code is laid out, how a run flows through it, how to build and test, and
where to make changes for the usual kinds of work.

Engine version: 2.15.5


## What the tool does

A tester describes API tests in an Excel workbook. The engine runs each test
against real endpoints, compares the response against a baseline, another
environment, or field-level assertions, and writes a self-contained HTML report.

There is no server component in this package: it is a single Java library with a
command line entry point, built into one fat jar.


## Layout

```
com.apitest
  Main                     Command line entry point: parses flags, runs, reports
  Version                  Version constant and change history
  XPathTester              Standalone helper for trying a path against a payload
  ResponseSkeleton         Standalone helper for outlining a response structure

  model/                   Plain data carriers
    Environment            One environment row: URL, protocol, auth, DB settings
    Step                   One request inside a test
    Assertion              One field check, optionally scoped to a step
    TestCase               One test: steps, data, assertions
    TestSuite              Everything loaded from the workbook
    StepResult             What happened for one step
    DiffEntry              One structural difference
    CompareResult          Outcome of one comparison
    AssertionResult        Outcome of one assertion
    TestResult             Everything about one finished test

  excel/
    ExcelLoader            Reads the workbook into a TestSuite (Apache POI)

  template/
    TemplateEngine         Resolves ${placeholders} in bodies and endpoints,
                           prunes empty XML elements and JSON members

  dispatcher/
    Dispatcher             Sends the request, handles auth per protocol
    Response               What came back
    SslConfig              Truststore, client certificates, secret resolution

  comparator/
    Comparator             Structural diff of XML and JSON, ignore rules
    AssertionEngine        Field-level and database assertions
    DbQuery                Shared read-only database access with guards
    CrossFormatCanonicalizer, SimpleXmlWalker   Payload normalising helpers

  runner/
    RunConfig              Inputs one run needs
    Runner                 Orchestrates load, execute, compare, record

  reporter/
    Reporter               Builds the self-contained HTML report
    JsonReport             Serialises results to and from JSON
```


## How a run flows

```
workbook.xlsx
     |
     v
ExcelLoader  ->  TestSuite (environments + test cases)
     |
     v
Runner.runAll()
     |
     |-- per test case:
     |     |-- resolve ${sql:...} values in TestData against a database
     |     |-- per step in order:
     |     |     |-- TemplateEngine renders endpoint and body
     |     |     |-- Dispatcher sends the request
     |     |     |-- capture variables from the response for later steps
     |     |
     |     |-- Comparator compares, when the mode calls for it
     |     |-- AssertionEngine checks field and database assertions
     |
     v
List<TestResult>  ->  Reporter  ->  report.html
```

Every request and response is also written under the run's output folder, so a
failure can be inspected exactly as it happened.


## Comparison modes

Set per test on the TestSuite sheet.

| Mode | Runs | Compares |
|---|---|---|
| `vs_expected` | Source A | Last response against a saved baseline file |
| `vs_env` | A and B | The two responses against each other |
| `vs_protocol` | A and B | Two different protocols, normalised first |
| `assert_only` | Source A | Nothing; field assertions only |
| `chain` | Source A | Nothing; runs steps in order, honours assertions |


## Assertions

Field checks live on the Assertions sheet: a path (XPath or JSONPath), an
operator, an expected value. Leave `StepOrder` blank to check the final
response, or set it to check after a specific step.

Operators that a blank expected value would trivially satisfy - `contains`,
`not_contains`, `regex_match`, `one_of` - reject a blank expected value with a
clear message instead of passing. Every value contains the empty string and
matches the empty pattern, so a blank check there is always a workbook mistake.

Database assertions (`db_equals`, `db_contains`, `db_exists`, `db_rows`) run a
query against the environment's database. All database access goes through
`DbQuery`, which enforces the same guards everywhere: only `SELECT` and `WITH`
are accepted, stacked statements are rejected, the connection is opened
read-only and the query is bounded by a timeout. The SQL comes from the tester's
own workbook, so this is defence in depth against a malformed or pasted
statement rather than against an outside attacker.


## Values from a database

A TestData cell may hold `${sql:ENV:QUERY}` instead of a literal. Before the test
runs, `Runner.resolveSqlData` replaces it with the result of the query against
environment ENV's database, or the test's own Source A database when ENV is
omitted. One value substitutes as-is; several are joined with commas, which is
what a `db_rows` assertion expects.

To use more than one database, add an Environments row per database that fills
only the `Db*` columns and leaves `BaseURL` blank, then name it in the reference.


## Optional request fields

When a TestData value is blank the placeholder does not resolve. For XML the
containing element is pruned; for JSON the containing member or array element is
dropped and the surrounding commas are tidied, so an optional field is left out
of the request rather than sent empty. The pruned JSON is validated before it is
sent, and if pruning ever produced invalid JSON the engine falls back to
clearing the markers.


## Headers

`ExtraHeaders` takes one header per line. Only the first colon separates the
name from the value, so a value may contain colons and semicolons - a
`Content-Type` with a charset, a cookie with several pairs. There is no
delimiter to escape.


## The report

The HTML report inlines every byte of CSS and JavaScript. There are no external
links, no CDN references and no network calls of any kind, so it opens correctly
years later from an email attachment, a ticket or a bucket. That property is
deliberate and worth preserving in any report change.


## Building

Requirements: JDK 21 and Maven, with access to your internal Maven repository
for the dependencies (Apache POI, Jackson, JsonPath, HttpClient, SLF4J, and the
Oracle JDBC driver if you keep it in the POM).

```bash
mvn clean package
```

This produces the shaded jar under `target/`. Run it:

```bash
java -jar target/api-test-suite.jar --suite config/test_suite.xlsx
```

`--help` lists every flag.


## Testing

JUnit 5. Run with:

```bash
mvn test
```

The suite covers the comparator, the assertion engine (including database
assertions against an in-memory fake driver), the template engine, the Excel
round trip, header parsing, multi-value extraction, JSON pruning and the
blank-expected guards. Add a test alongside any behaviour change; the existing
tests are the model for style and setup.


## Extending

**A comparison mode.** Add a case where the mode is dispatched in `Runner`,
implement it using `Comparator` and `AssertionEngine`, and populate the result.
The report picks up new modes in its filters automatically. Update the workbook
template dropdown and the docs.

**An assertion operator.** Add a case in `AssertionEngine`, set the outcome and
a clear message. If a blank expected value would make the check meaningless,
guard it the way `contains` does. Update the dropdown and the docs.

**A protocol or auth type.** `Dispatcher` is the only place that knows about
protocols and auth. Add a branch for the new flow or header handling. Keep token
providers quiet on success and let failures surface as the response error, so
they appear in the report like any other failure.

**A workbook column.** Columns are read by header name through
`cellStr(row, cols, "Name")`, which returns an empty string when the column is
absent. That means a new column is automatically optional and older workbooks
keep working untouched. Read it in `ExcelLoader`, carry it on the relevant model
class, and use it where it applies.


## Security notes

- All XML parsing is hardened against XXE: doctype declarations are rejected,
  external general and parameter entities are disabled, external DTD loading is
  off and XInclude is disabled. See `hardenXxe`.
- The tool makes no network calls other than the requests a test asks for. There
  is no telemetry, no update check and no external asset in the report.
- Secrets are never written to the report or the run artifacts. Passwords in the
  workbook can be indirected through `${env.NAME}` or
  `${file./path/to/file.properties:key}` so the workbook itself holds no
  credentials.
- Database access is read-only and statement-guarded, as described above.
