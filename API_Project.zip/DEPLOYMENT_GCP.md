# API Test Suite — Deployment guide for DevOps

This document is for the team deploying the API Test Suite on GCP (GKE). It
covers what the application is, what it needs, how to build the image, how to
give the whole team access, and the operational details worth knowing.

There is nothing exotic here: it is a single stateless Spring Boot container
that reads and writes one mounted volume, sitting behind your existing ingress
and SSO.

---

## 1. What you are deploying

Three artifacts, one running process:

| Artifact | What it is | Where it goes |
|---|---|---|
| **Server** (`api-test-suite-server`) | Spring Boot app — the only running process. Serves the UI, exposes `/api`, runs tests **in-process**. | Built into the container image. |
| **GUI** (`api-test-suite-web`) | React app, built to static files. | Built and copied into the server's static resources at image-build time. |
| **Engine** (`api-test-suite`) | The test runner. Bundled into the server as a library — runs execute in-process, no subprocess. | Compiled into the server jar at build time. |

The application keeps **no state in the container**. Everything — uploaded
workbooks, templates, run history, results — lives on one mounted volume. That
is what makes the pod stateless: it can be restarted, rescheduled, or scaled
without losing anything.

```
                 ┌─────────────────────────────────────────┐
   Browser ──────▶  Ingress (HTTPS) ──▶ IAP / SSO           │
                 │        │                                  │
                 │        ▼                                  │
                 │   Service (ClusterIP :8080)               │
                 │        │                                  │
                 │        ▼                                  │
                 │   Pod: api-test-suite-server              │
                 │     • serves the GUI                      │
                 │     • /api endpoints                      │
                 │     • runs suites in-process (bundled)    │
                 │        │                                  │
                 │        ▼                                  │
                 │   PersistentVolume  (the only state)      │
                 │     workbooks/  templates/  expected/     │
                 │     runs/  config/                        │
                 └─────────────────────────────────────────┘
```

---

## 2. Runtime requirements

- **Java 21 runtime in the image.** The application runs on it. The engine is
  bundled in and runs in the same JVM — there is no subprocess. A
  `eclipse-temurin:21-jre` base is enough.
- **One ReadWriteMany volume**, mounted at a fixed path (this guide uses
  `/data/apitest`). It must be RWX if you ever run more than one replica, so
  they share the same workspace — a GCP Filestore (NFS) PVC is the natural
  choice. A single replica can use ReadWriteOnce (a regional PD), which is
  simpler and fine to start with.
- **Outbound network to the systems under test.** The whole point of the tool
  is to call your APIs, so the pod's egress must reach those hosts. It needs
  **no other outbound access** — no internet, no third-party services.
- Roughly **512Mi–1Gi memory** and **0.5–1 vCPU** to start. Runs execute as
  threads inside the one JVM (no subprocess), so heap is the thing to watch;
  size up if large suites run concurrently.

---

## 3. Building the container image

The GUI is built and folded into the server before packaging. Do this in the
image build (multi-stage Dockerfile shown; adapt to your CI):

```dockerfile
# ---- stage 1: build the GUI ----
FROM node:20 AS gui
WORKDIR /gui
COPY api-test-suite-web/ .
RUN npm ci && npm run build          # produces dist/

# ---- stage 2: build the server (with the GUI inside it) ----
FROM maven:3.9-eclipse-temurin-21 AS server
WORKDIR /build
# engine must be installed to the local Maven repo first (server depends on it)
COPY api-test-suite/ ./engine-src/
RUN cd engine-src && mvn -q install
COPY api-test-suite-server/ ./server-src/
COPY --from=gui /gui/dist/ ./server-src/src/main/resources/static/
RUN cd server-src && mvn -q package -DskipTests

# ---- stage 3: runtime ----
FROM eclipse-temurin:21-jre
WORKDIR /app
COPY --from=server /build/server-src/target/api-test-suite-server-2.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java","-jar","/app/app.jar"]
```

Notes:
- The engine (`api-test-suite`) is a Maven dependency of the server, so it must
  be `mvn install`ed into the local repo before the server builds. The stage
  above does that. It is compiled into the server jar — there is no separate
  engine artifact to deploy.
- If Maven Central is restricted in your build network, point Maven at your
  Artifactory mirror. The server's only external dependencies are
  `spring-boot-starter-web` and `spring-boot-starter-test`.

---

## 4. Seeding the volume (one time)

Before the first run, put one file on the volume — the starter template:

```
/data/apitest/
└── config/
    └── test_suite_template.xlsx    ← from the server package's workspace-seed/
```

The server creates the other folders (`workbooks/`, `templates/`, `expected/`,
`runs/`) itself on startup. The template enables the GUI's "Download blank
template" button for first-time users. It is optional — the app runs without it;
you just lose that button.

You can seed it with a short-lived job that mounts the volume and copies it in,
or an `initContainer` on the first deploy. (No engine jar is needed on the
volume — the engine is bundled into the application.)

---

## 5. Kubernetes manifests (starting point)

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: apitest-data
spec:
  accessModes: ["ReadWriteMany"]     # RWX for multi-replica; RWO if single
  resources:
    requests:
      storage: 20Gi
  storageClassName: filestore-rwx    # your RWX class; adjust
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-test-suite
spec:
  replicas: 1
  selector:
    matchLabels: { app: api-test-suite }
  template:
    metadata:
      labels: { app: api-test-suite }
    spec:
      containers:
        - name: server
          image: REGION-docker.pkg.dev/PROJECT/REPO/api-test-suite:2.0.0
          ports:
            - containerPort: 8080
          env:
            - name: APITEST_WORKSPACE
              value: /data/apitest
            - name: SERVER_PORT
              value: "8080"
          volumeMounts:
            - name: apitest-data
              mountPath: /data/apitest
          resources:
            requests: { cpu: "500m", memory: "512Mi" }
            limits:   { cpu: "1",    memory: "1Gi" }
          readinessProbe:
            httpGet: { path: /api/context, port: 8080 }
            initialDelaySeconds: 15
            periodSeconds: 10
          livenessProbe:
            httpGet: { path: /api/context, port: 8080 }
            initialDelaySeconds: 30
            periodSeconds: 20
      volumes:
        - name: apitest-data
          persistentVolumeClaim:
            claimName: apitest-data
---
apiVersion: v1
kind: Service
metadata:
  name: api-test-suite
spec:
  selector: { app: api-test-suite }
  ports:
    - port: 80
      targetPort: 8080
```

`GET /api/context` returns 200 once the workspace is ready, so it doubles as the
health probe.

---

## 6. Giving the whole team access

The application has **no built-in login** — this is deliberate. It expects to
sit behind your existing authentication, so the team uses their normal
corporate identity and you manage access in one place.

Recommended for GCP:

- Put the Service behind an **Ingress with Identity-Aware Proxy (IAP)** enabled.
- Grant the team the **IAP-secured Web App User** role — either to a Google
  Group that contains everyone, or to the whole domain if that fits your policy.
  Managing a group is the easy path: add or remove people there, no redeploy.
- IAP passes the authenticated user's identity to the pod. The application reads
  an `X-User` header into its audit log, so if you configure IAP to forward the
  user's email as `X-User`, every upload, delete and run is attributed to a real
  person. (Access still works without it; you just get `-` in the audit log.)

```
Team (Google Group)
   └── IAM role: IAP-secured Web App User
         └── on the Ingress backend service
               └── Pod  (sees the user via IAP headers)
```

If you don't use IAP, any authenticating reverse proxy in front of the Service
works the same way — the application trusts the proxy to have authenticated the
user.

---

## 7. Operational notes

- **Storage growth.** Each kept run is one folder holding a small `report.json`
  and a console log — tens of KB, not the multi-MB HTML. The GUI has a "save
  results" toggle that is **off** for dry runs, so day-to-day automation does
  not accumulate junk. Still, add a retention job (a CronJob deleting
  `runs/` folders older than N days) so history is bounded.
- **Backups.** The volume is the only state. Snapshot it on your normal PVC
  backup schedule. Losing the container loses nothing; losing the volume loses
  history and uploaded suites.
- **Scaling.** One replica is the simplest and is usually enough. To run more,
  use an RWX volume so replicas share the workspace; runs are isolated by
  folder, so they don't collide. There is no in-memory session to make sticky,
  except a dry run's report, which is held in memory until viewed — with
  multiple replicas, pin dry-run viewing to the same pod, or simply save those
  runs.
- **Egress.** The pod must reach the API hosts under test. If you use a
  NetworkPolicy, allow egress to those hosts (and DNS). No ingress from the pod
  to the internet is required.
- **TLS to systems under test.** The engine verifies TLS by default. A per-
  environment option can disable verification for a test target; when it does,
  the run log prints a clear warning. That switch is in the test workbook, not
  the deployment.
- **Upgrades.** Roll a new image for any change — server, GUI or engine. The
  engine is bundled into the image now, so an engine update is a new image like
  any other (a clean, versioned rollout rather than swapping a jar on a live
  volume).

---

## 8. Pre-flight checklist

- [ ] Image built with the GUI folded in and a Java 21 **JRE** in the runtime stage
- [ ] RWX (or RWO for single replica) PVC created and bound
- [ ] Volume seeded (optional): `config/test_suite_template.xlsx`
- [ ] `APITEST_WORKSPACE=/data/apitest` set on the container
- [ ] Readiness/liveness probes pointed at `/api/context`
- [ ] Ingress + IAP in front, team granted IAP-secured Web App User via a group
- [ ] (Optional) IAP configured to forward user email as `X-User` for the audit log
- [ ] Egress from the pod to the API hosts under test allowed
- [ ] Retention CronJob for `runs/` scheduled
- [ ] Volume added to the PVC backup schedule
