# Encoded payload handling - design record

This records the encoded-payload work that was built on top of v2.15.5 and
released as v2.16.0 through v2.20.0. The engine has since been reverted to
v2.15.5, so none of this is in the shipped code. It is written down so the work
does not have to be rediscovered if it is picked up again.

Everything below was implemented, tested (347 tests passing at v2.20.0) and in
use against a real payload before the revert.


## The problem it solved

A response contained a list of sections, each holding a request and a response
that were base64 text rather than nested objects:

```
status.serviceRequestResponses[ { id, request, response }, ... ]
```

Decoding one of those responses gave, in the real case:

```
|201:"{\"OrderResponse\":{\"OrderUUID\":\"...\",\"returnCode\":\"0000\"}}"
```

Three layers at once: a transport prefix, a JSON string, and JSON inside that
string. On top of which the payloads carried a generated PDF and fresh GUIDs on
every run.


## What was added

### 1. Decode column on the Assertions sheet

An optional `Decode` column. `base64` decoded the value the path resolved to
before the operator ran; blank left the value untouched. A value that would not
decode failed the assertion with a clear message rather than passing.

- `Assertion` record gained a seventh component, `decode`, with two
  backwards-compatible constructors so the existing 38 construction sites kept
  compiling.
- `AssertionEngine.decodeValues(values, mode, result)` decoded each extracted
  value, returning null on failure after setting the result message.
- Applied once at the single extraction point so every downstream branch
  (single match, multi match, joined report) saw the decoded form.

### 2. DecodePaths column on the TestSuite sheet

JSONPaths, one per line, of base64 fields decoded on **both** sides before a
`vs_expected` / `vs_env` comparison.

- `Comparator.compare` gained a four-argument overload taking the paths; the
  original three-argument method delegated to it with null, so all 57 existing
  call sites were untouched.
- Decoding happened as a pre-transform on the payload strings, before any
  comparison logic. The diffing, format detection and ignore handling were not
  modified at all.
- Wildcards worked: `$.sections[*].response`.

### 3. Nesting

Paths were applied in the order given, each resolved against the document **as
it stood after the previous path had been applied**. That is what let an inner
field be decoded once an outer field had been opened:

```
$.status.serviceRequestResponses[*].response
$.status.serviceRequestResponses[*].response.body.renderResult
```

The first implementation resolved every path against the original payload,
which meant nested paths never matched. Fixing that was the substance of
v2.18.0.

### 4. Binary guard

Decoded bytes that did not survive a round trip through UTF-8 were left
encoded rather than forced through a lossy conversion. A base64 PDF starts
`JVBERi0` and its bytes are not text; converting it produced mojibake and
meaningless differences. The result note reported how many fields were left
encoded.

A generated PDF also embeds a creation timestamp, so it differs on every run
regardless. The guidance was to ignore it and assert on stable siblings such as
`pageCount` and `documentCount`.

### 5. MaskPatterns column on the TestSuite sheet

Regular expressions, one per line, whose matches were blanked on both sides
after decoding. For values that differ every run by design:

```
[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}
\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}
```

Masks reached into decoded text that no ignore path could target, which
mattered because a decoded value that is plain text has no structure to point
at. Guards: a pattern that did not compile was skipped, and a replacement that
left the payload unparseable was discarded rather than applied, so a careless
expression could not break a working comparison.

### 6. Prefix and quoted-body handling

`Comparator.asStructure(text)` turned decoded text into something the
comparison could walk:

- text that was already a JSON document was parsed
- a JSON string holding a document was unwrapped, then parsed
- a prefix followed by either of those became
  `{ "prefix": "|201:", "body": <parsed document> }`
- anything else stayed as the text it was

The prefix was **kept rather than discarded**. Dropping it would have been
simpler but would have hidden a `|200:` that had become a `|500:` - a false
pass, which is the worst failure mode for a test tool.

Paths then read:

```
$.status.serviceRequestResponses[?(@.id=='ORINOCO')].response.body.OrderResponse.returnCode
```

### 7. Assertions saw the decoded document

`Comparator.decodeForAssertions(payload, decodePaths)` was called in the Runner
before both assertion evaluation points, so an ordinary path reached inside an
encoded section without needing the `Decode` column. `executeSteps` gained a
`decodePaths` parameter to carry this to per-step assertions.

### 8. Report: diff window centred on the first difference

`Reporter.diffSideValue` was changed to show a window around the first
character that differed from the other side, with a marker at that point,
instead of the first 500 characters. Two payloads that agree for a thousand
characters before diverging were otherwise both cut off before the difference
was ever reached.


## Things learned that are worth keeping

- Base64 is not canonical. The same content encodes differently depending on
  the whitespace of the source, so comparing encoded strings reports
  differences that are not real. Decoding first is what makes the comparison
  meaningful.
- Decoded JSON must go back as **parsed structure**, not as a string. The first
  implementation inserted it as an escaped string, which left two identical
  documents comparing unequal - the feature looked like it worked and did
  nothing useful.
- Auto-detecting which fields are base64 is not worth it. Plenty of ordinary
  ids and tokens look like base64 and decode to noise. Declared paths fail
  loudly and once when wrong; detection fails silently and repeatedly.
- Do not recurse blindly into decoded content. Declaring each level is bounded
  and predictable; automatic recursion is where this kind of feature goes
  wrong.
- Most of the residual failures were not engine bugs but path mistakes:
  a missing nesting level (`body.returnCode` where the field was
  `body.OrderResponse.returnCode`), and a case difference (`returncode` for
  `returnCode`). JSONPath is case sensitive.


## If this is rebuilt

The order that worked was: assertion-level decode first (self-contained, does
not touch the comparison engine), then the comparison-level decode as a
pre-transform behind an overload, then nesting, the binary guard and masking,
and the prefix handling last. Each step kept the previous test suite green
before the next was started.

Corner cases that earned their place as tests: identical content encoded
differently, a real difference inside an encoded field, wildcard decoding over
repeated sections, an inner path declared before its outer, binary alongside
text in one pass, a mask that would break the JSON, an invalid regex, a prefix
change, a quoted body with no prefix, and a quoted string that is not a
document.
