package com.apitest;

import com.apitest.comparator.Comparator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the "[xX][mM][lL] is not allowed" error reported AT NON-ZERO COLUMN
 * (i.e., not from leading whitespace). Real-world causes:
 *   1. Two XML documents concatenated by a buggy proxy or chunked transfer
 *   2. An inner <?xml ... ?> declaration inside a SOAP wrapper
 *   3. A trailing <?xml after the root element closes
 */
class XmlInnerPrologSanitizationTest {

    @Test
    void concatenatedXmlDocumentsKeepFirst() {
        // Two complete docs glued together — server bug.
        // The second <?xml is at column ~70+ — exactly the user's reported
        // "[Fatal Error] :1:199" pattern, just with shorter strings here.
        String doublePayload =
                "<?xml version=\"1.0\"?><Response><id>FIRST</id><cost>100</cost></Response>" +
                "<?xml version=\"1.0\"?><Response><id>SECOND</id><cost>200</cost></Response>";

        // The framework should keep the first doc and silently drop the second.
        assertEquals("FIRST", Comparator.extractVariable(doublePayload, "//id"));
        assertEquals("100", Comparator.extractVariable(doublePayload, "//cost"));
    }

    @Test
    void innerXmlDeclarationIsStripped() {
        // Inner <?xml inside the payload — illegal per spec but real servers send it
        String payload = "<Wrapper>"
                + "<Payload><?xml version=\"1.0\"?><Inner><x>found</x></Inner></Payload>"
                + "</Wrapper>";

        assertEquals("found", Comparator.extractVariable(payload, "//Inner/x"));
    }

    @Test
    void trailingXmlAfterRootIsTruncated() {
        // Bogus trailing <?xml after the root closes
        String payload = "<?xml version=\"1.0\"?>"
                + "<Resp><id>only</id></Resp>"
                + "  \n<?xml version=\"1.0\"?><Junk>ignored</Junk>";

        assertEquals("only", Comparator.extractVariable(payload, "//id"));
        // The junk root must NOT be in the parsed result
        assertEquals("", Comparator.extractVariable(payload, "//Junk"));
    }

    @Test
    void wellFormedXmlIsUntouched() {
        // Sanity: clean XML must still work exactly as before.
        String good = "<?xml version=\"1.0\"?><r><a>1</a><b>2</b></r>";
        assertEquals("1", Comparator.extractVariable(good, "//a"));
        assertEquals("2", Comparator.extractVariable(good, "//b"));
    }

    @Test
    void userScenarioConcatenatedSoapResponses() {
        // Mimics what the user is seeing: a SOAP-like response, but with
        // a stray <?xml partway through pushing the bad PI to column ~199.
        String filler = "<note>some lengthy descriptive text that pushes us out past column 100 easily</note>";
        String payload =
                "<?xml version=\"1.0\"?>"
                + "<Portfolio>"
                + "  <securityItem><Security><id>abc123</id><cost>249.95</cost>"
                + filler
                + "</Security></securityItem>"
                + "</Portfolio>"
                + "<?xml version=\"1.0\"?><Garbage/>";

        // Should extract abc123 cost cleanly despite the trailing trash
        String cost = Comparator.extractVariable(payload,
                "//securityItem/Security[id='abc123']/cost");
        assertEquals("249.95", cost);
    }

    @Test
    void bomThenConcatenatedDocs() {
        // Worst case: BOM at start AND concatenated docs at end.
        String payload =
                "\uFEFF<?xml version=\"1.0\"?><r><a>x</a></r>"
                + "<?xml version=\"1.0\"?><r><a>y</a></r>";
        assertEquals("x", Comparator.extractVariable(payload, "//a"));
    }
}
