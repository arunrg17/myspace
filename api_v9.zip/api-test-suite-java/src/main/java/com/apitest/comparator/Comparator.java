package com.apitest.comparator;

import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import com.apitest.model.DiffEntry;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.ReadContext;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import java.io.StringReader;
import java.util.*;

/**
 * Compare two payloads structurally with ignore-field support.
 *
 * Handles XML vs XML, JSON vs JSON, and cross-format (XML vs JSON) by
 * normalising XML into a JSON-like tree.
 */
public class Comparator {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Configuration JSONPATH_CFG = Configuration.builder()
            .options(Option.SUPPRESS_EXCEPTIONS)
            .build();

    public static String detectFormat(String payload) {
        if (payload == null) return "empty";
        // Strip BOM + leading junk so a BOM-prefixed XML response is still
        // classified as XML rather than as "text".
        String s = sanitizeXmlProlog(payload).strip();
        if (s.isEmpty()) return "empty";
        if (s.startsWith("<")) return "xml";
        if (s.startsWith("{") || s.startsWith("[")) return "json";
        return "text";
    }

    public static CompareResult compare(String expected, String actual, List<Assertion> assertions) {
        CompareResult result = new CompareResult();
        if (assertions == null) assertions = List.of();

        String fmtA = detectFormat(expected);
        String fmtB = detectFormat(actual);

        if ("empty".equals(fmtA) || "empty".equals(fmtB)) {
            result.matched = false;
            result.note = "One side is empty";
            return result;
        }

        List<String> xpathIgnores = new ArrayList<>();
        List<String> jsonpathIgnores = new ArrayList<>();
        for (Assertion a : assertions) {
            if (!"ignore".equalsIgnoreCase(a.operator())) continue;
            if ("xpath".equalsIgnoreCase(a.pathType())) xpathIgnores.add(a.path());
            else if ("jsonpath".equalsIgnoreCase(a.pathType())) jsonpathIgnores.add(a.path());
        }

        try {
            Object objA, objB;
            if ("xml".equals(fmtA) && "xml".equals(fmtB)) {
                objA = xmlToMap(applyXpathIgnores(expected, xpathIgnores));
                objB = xmlToMap(applyXpathIgnores(actual, xpathIgnores));
                applyJsonpathIgnores(objA, jsonpathIgnores);
                applyJsonpathIgnores(objB, jsonpathIgnores);
                result.note = "xml vs xml";
            } else if ("json".equals(fmtA) && "json".equals(fmtB)) {
                objA = jsonToMap(expected);
                objB = jsonToMap(actual);
                applyJsonpathIgnores(objA, jsonpathIgnores);
                applyJsonpathIgnores(objB, jsonpathIgnores);
                result.note = "json vs json";
            } else {
                objA = "xml".equals(fmtA) ? xmlToMap(applyXpathIgnores(expected, xpathIgnores)) : jsonToMap(expected);
                objB = "xml".equals(fmtB) ? xmlToMap(applyXpathIgnores(actual, xpathIgnores)) : jsonToMap(actual);
                applyJsonpathIgnores(objA, jsonpathIgnores);
                applyJsonpathIgnores(objB, jsonpathIgnores);
                result.note = fmtA + " vs " + fmtB + " (cross-format)";
            }

            diff(objA, objB, "$", result.diffs);
            result.matched = result.diffs.isEmpty();
        } catch (Exception ex) {
            result.matched = false;
            result.note = "Parse error: " + ex.getMessage();
        }
        return result;
    }

    // ------------------------------------------------------------------
    // Format conversion
    // ------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    public static Object jsonToMap(String json) throws Exception {
        JsonNode node = MAPPER.readTree(json);
        return jsonNodeToObject(node);
    }

    private static Object jsonNodeToObject(JsonNode node) {
        if (node.isObject()) {
            Map<String, Object> map = new LinkedHashMap<>();
            node.fields().forEachRemaining(e -> map.put(e.getKey(), jsonNodeToObject(e.getValue())));
            return map;
        }
        if (node.isArray()) {
            List<Object> list = new ArrayList<>();
            node.forEach(c -> list.add(jsonNodeToObject(c)));
            return list;
        }
        if (node.isNumber()) return node.numberValue();
        if (node.isBoolean()) return node.booleanValue();
        if (node.isNull()) return null;
        return node.asText();
    }

    public static Object xmlToMap(String xml) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(false);
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new InputSource(new StringReader(xml)));
        Node root = doc.getDocumentElement();
        Map<String, Object> wrapper = new LinkedHashMap<>();
        wrapper.put(localName(root.getNodeName()), elementToObject(root));
        return wrapper;
    }

    @SuppressWarnings("unchecked")
    private static Object elementToObject(Node elem) {
        List<Node> children = new ArrayList<>();
        NodeList nl = elem.getChildNodes();
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < nl.getLength(); i++) {
            Node c = nl.item(i);
            if (c.getNodeType() == Node.ELEMENT_NODE) children.add(c);
            else if (c.getNodeType() == Node.TEXT_NODE || c.getNodeType() == Node.CDATA_SECTION_NODE) {
                text.append(c.getNodeValue());
            }
        }

        NamedNodeMap attrs = elem.getAttributes();
        if (children.isEmpty()) {
            String t = text.toString().trim();
            if (attrs == null || attrs.getLength() == 0) return t;
            Map<String, Object> map = new LinkedHashMap<>();
            for (int i = 0; i < attrs.getLength(); i++) {
                Node a = attrs.item(i);
                if (isNamespaceAttr(a)) continue;
                map.put("@" + localName(a.getNodeName()), a.getNodeValue());
            }
            if (map.isEmpty()) return t;
            if (!t.isEmpty()) map.put("#text", t);
            return map;
        }

        Map<String, Object> map = new LinkedHashMap<>();
        for (Node child : children) {
            String key = localName(child.getNodeName());
            Object value = elementToObject(child);
            if (map.containsKey(key)) {
                Object existing = map.get(key);
                if (existing instanceof List) {
                    ((List<Object>) existing).add(value);
                } else {
                    List<Object> list = new ArrayList<>();
                    list.add(existing);
                    list.add(value);
                    map.put(key, list);
                }
            } else {
                map.put(key, value);
            }
        }
        if (attrs != null) {
            for (int i = 0; i < attrs.getLength(); i++) {
                Node a = attrs.item(i);
                if (isNamespaceAttr(a)) continue;
                map.put("@" + localName(a.getNodeName()), a.getNodeValue());
            }
        }
        return map;
    }

    private static boolean isNamespaceAttr(Node a) {
        String n = a.getNodeName();
        return "xmlns".equals(n) || n.startsWith("xmlns:");
    }

    private static String localName(String qname) {
        int idx = qname.indexOf(':');
        return idx >= 0 ? qname.substring(idx + 1) : qname;
    }

    // ------------------------------------------------------------------
    // Ignore application
    // ------------------------------------------------------------------

    private static String applyXpathIgnores(String xml, List<String> patterns) {
        if (patterns.isEmpty()) return xml;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            Document doc = dbf.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
            XPath xp = XPathFactory.newInstance().newXPath();
            for (String pat : patterns) {
                try {
                    NodeList nodes = (NodeList) xp.evaluate(pat, doc, XPathConstants.NODESET);
                    for (int i = 0; i < nodes.getLength(); i++) {
                        nodes.item(i).setTextContent("__IGNORED__");
                    }
                } catch (Exception ignore) {}
            }
            javax.xml.transform.Transformer t = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
            java.io.StringWriter sw = new java.io.StringWriter();
            t.transform(new javax.xml.transform.dom.DOMSource(doc), new javax.xml.transform.stream.StreamResult(sw));
            return sw.toString();
        } catch (Exception ex) {
            return xml;
        }
    }

    @SuppressWarnings("unchecked")
    private static void applyJsonpathIgnores(Object obj, List<String> patterns) {
        if (patterns.isEmpty()) return;
        try {
            String json = MAPPER.writeValueAsString(obj);
            ReadContext ctx = JsonPath.using(JSONPATH_CFG).parse(json);
            Object doc = ctx.json();
            for (String pat : patterns) {
                try {
                    JsonPath.using(JSONPATH_CFG).parse(doc).set(pat, "__IGNORED__");
                } catch (Exception ignore) {}
            }
            // Copy patched back into obj
            if (obj instanceof Map && doc instanceof Map) {
                ((Map<String, Object>) obj).clear();
                ((Map<String, Object>) obj).putAll((Map<String, Object>) doc);
            }
        } catch (Exception ignore) {}
    }

    // ------------------------------------------------------------------
    // Recursive diff
    // ------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    public static void diff(Object a, Object b, String path, List<DiffEntry> diffs) {
        if ("__IGNORED__".equals(a) || "__IGNORED__".equals(b)) return;
        if (a == null && b == null) return;
        if (a == null) {
            diffs.add(new DiffEntry(path, "<missing>", String.valueOf(b), "removed"));
            return;
        }
        if (b == null) {
            diffs.add(new DiffEntry(path, String.valueOf(a), "<missing>", "added"));
            return;
        }

        // Numeric tolerance: treat numbers as numbers regardless of int/double
        if (a instanceof Number && b instanceof Number) {
            if (((Number) a).doubleValue() != ((Number) b).doubleValue()) {
                diffs.add(new DiffEntry(path, a.toString(), b.toString(), "value"));
            }
            return;
        }

        if (a.getClass() != b.getClass() && !(a instanceof Map && b instanceof Map)
                && !(a instanceof List && b instanceof List)) {
            // Treat numeric strings vs numbers as a value mismatch
            diffs.add(new DiffEntry(path, a.toString(), b.toString(), "type"));
            return;
        }

        if (a instanceof Map && b instanceof Map) {
            Map<String, Object> ma = (Map<String, Object>) a;
            Map<String, Object> mb = (Map<String, Object>) b;
            Set<String> keys = new TreeSet<>();
            keys.addAll(ma.keySet());
            keys.addAll(mb.keySet());
            for (String k : keys) {
                String childPath = path + "." + k;
                if (!ma.containsKey(k)) diffs.add(new DiffEntry(childPath, "<missing>", String.valueOf(mb.get(k)), "added"));
                else if (!mb.containsKey(k)) diffs.add(new DiffEntry(childPath, String.valueOf(ma.get(k)), "<missing>", "removed"));
                else diff(ma.get(k), mb.get(k), childPath, diffs);
            }
            return;
        }

        if (a instanceof List && b instanceof List) {
            List<Object> la = (List<Object>) a;
            List<Object> lb = (List<Object>) b;
            if (la.size() != lb.size()) {
                diffs.add(new DiffEntry(path, "length=" + la.size(), "length=" + lb.size(), "length"));
            }
            int min = Math.min(la.size(), lb.size());
            for (int i = 0; i < min; i++) {
                diff(la.get(i), lb.get(i), path + "[" + i + "]", diffs);
            }
            return;
        }

        if (!Objects.equals(a, b)) {
            diffs.add(new DiffEntry(path, a.toString(), b.toString(), "value"));
        }
    }

    // ------------------------------------------------------------------
    // Variable extraction
    // ------------------------------------------------------------------

    /** Thrown when extractVariable fails for a reportable reason. */
    public static class ExtractionException extends RuntimeException {
        public ExtractionException(String msg) { super(msg); }
    }

    public static String extractVariable(String payload, String path) {
        String fmt = detectFormat(payload);
        if ("json".equals(fmt)) {
            try {
                Object value = JsonPath.using(JSONPATH_CFG).parse(payload).read(path);
                if (value == null) return "";
                if (value instanceof List) {
                    List<?> list = (List<?>) value;
                    return list.isEmpty() ? "" : String.valueOf(list.get(0));
                }
                return String.valueOf(value);
            } catch (Exception ex) {
                throw new ExtractionException("JSONPath failed: " + ex.getMessage());
            }
        }
        if ("xml".equals(fmt)) {
            // Servers sometimes return XML containing HTML-escaped XML as text
            // content (common SOAP pattern). Decode so XPath can address the
            // inner elements directly without the user knowing about the wrap.
            String decoded = decodeEmbeddedEscapedXml(payload);
            // Normalize CRLF/CR — servers sometimes send Windows line endings
            // which end up as &#xd; in extracted values.
            decoded = decoded.replace("\r\n", "\n").replace("\r", "");
            // Strip BOM + leading whitespace BEFORE <?xml ... ?>
            decoded = sanitizeXmlProlog(decoded);

            Document doc;
            try {
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                dbf.setNamespaceAware(false);  // ignore namespaces — match by local name
                // Silence the "[Fatal Error]" stderr noise — we re-throw as ExtractionException
                dbf.newDocumentBuilder();  // pre-check builder construction
                DocumentBuilder builder = dbf.newDocumentBuilder();
                builder.setErrorHandler(new org.xml.sax.helpers.DefaultHandler());
                doc = builder.parse(new InputSource(new StringReader(decoded)));
            } catch (Exception ex) {
                throw new ExtractionException("XML parse failed: " + ex.getMessage());
            }

            try {
                XPath xp = XPathFactory.newInstance().newXPath();
                // Evaluate to a NodeSet first so we can detect "no match" cleanly.
                org.w3c.dom.NodeList nodes = (org.w3c.dom.NodeList) xp.evaluate(path, doc, XPathConstants.NODESET);
                if (nodes != null && nodes.getLength() > 0) {
                    String v = nodes.item(0).getTextContent();
                    return v == null ? "" : v.trim();
                }
                // Fall back to a string evaluation for paths that return scalars
                // (e.g. count(...), string-length(...), or attribute selections).
                Object str = xp.evaluate(path, doc, XPathConstants.STRING);
                String s = str == null ? "" : str.toString().trim();
                return s;
            } catch (javax.xml.xpath.XPathExpressionException ex) {
                throw new ExtractionException("XPath syntax error: " + ex.getMessage());
            } catch (Exception ex) {
                throw new ExtractionException("XPath evaluation failed: " + ex.getMessage());
            }
        }
        return "";
    }

    /**
     * Sanitize XML for parsing. Handles three real-world malformations seen
     * in enterprise SOAP responses:
     *
     *   1. BOM + leading whitespace/control chars before &lt;?xml — easy.
     *   2. Inner &lt;?xml declarations anywhere except position 0 — illegal
     *      per the spec, but real servers (especially chained proxies, MTOM
     *      strippers, and over-eager logging filters) emit them. We strip
     *      every non-leading &lt;?xml ... ?&gt; instruction.
     *   3. Two XML documents concatenated. We keep the first complete
     *      document by truncating at the first standalone &lt;?xml that
     *      appears after the leading prolog. Specifically: if a &lt;?xml
     *      declaration appears AFTER any element has already opened, we
     *      treat that as the start of a second document and discard from
     *      that point on.
     *
     * The fix is conservative — well-formed XML is unchanged.
     */
    public static String sanitizeXmlProlog(String xml) {
        if (xml == null || xml.isEmpty()) return xml;

        // Step 1: strip BOM + leading whitespace/control chars
        int start = 0;
        while (start < xml.length()) {
            char c = xml.charAt(start);
            if (c == '\uFEFF'
                    || c == '\u00A0'
                    || Character.isWhitespace(c)
                    || Character.isISOControl(c)) {
                start++;
            } else {
                break;
            }
        }
        String s = (start == 0) ? xml : xml.substring(start);
        if (s.isEmpty()) return s;

        // Step 2: locate the leading <?xml ... ?> prolog (if present) so we
        // know what's "the legitimate one" and can strip any subsequent ones.
        int searchFrom = 0;
        if (s.startsWith("<?xml")) {
            int prologEnd = s.indexOf("?>", 5);
            if (prologEnd > 0) {
                searchFrom = prologEnd + 2;
            }
        }

        // Step 3: scan for additional <?xml declarations or processing
        // instructions that target xml — both are the trigger of the
        // "[xX][mM][lL] is not allowed" error.
        int badIdx = findIllegalXmlPi(s, searchFrom);
        if (badIdx < 0) {
            return s;
        }

        // We found junk starting at badIdx. Two strategies:
        //   (a) If badIdx is after the document's root element closed, keep
        //       everything up to the close — that means we had two concatenated docs.
        //   (b) Otherwise the bad <?xml is mid-document (illegal but
        //       recoverable) — strip just the offending PI and keep parsing.
        int rootCloseEnd = findRootCloseEnd(s, searchFrom);
        if (rootCloseEnd > 0 && badIdx >= rootCloseEnd) {
            // Case (a): concatenated documents. Truncate at the root close.
            return s.substring(0, rootCloseEnd);
        }

        // Case (b): strip ALL non-leading <?...?> PIs whose target is "xml".
        StringBuilder out = new StringBuilder(s.length());
        out.append(s, 0, searchFrom);
        int cursor = searchFrom;
        while (cursor < s.length()) {
            int piStart = s.indexOf("<?", cursor);
            if (piStart < 0) {
                out.append(s, cursor, s.length());
                break;
            }
            // Append everything up to this PI start
            out.append(s, cursor, piStart);
            int piEnd = s.indexOf("?>", piStart + 2);
            if (piEnd < 0) {
                // Unterminated PI — best we can do is drop the rest
                break;
            }
            String target = s.substring(piStart + 2, Math.min(piStart + 6, s.length())).toLowerCase();
            if (target.startsWith("xml")) {
                // Skip this PI entirely
                cursor = piEnd + 2;
            } else {
                // Legitimate non-xml PI — keep it
                out.append(s, piStart, piEnd + 2);
                cursor = piEnd + 2;
            }
        }
        return out.toString();
    }

    /**
     * Find the next <?xml ... ?> processing instruction starting from `from`.
     * Returns the start index, or -1 if none.
     */
    private static int findIllegalXmlPi(String s, int from) {
        int idx = from;
        while (idx < s.length()) {
            int p = s.indexOf("<?", idx);
            if (p < 0) return -1;
            // Check the PI target — case-insensitive "xml"
            if (p + 5 <= s.length()) {
                String target = s.substring(p + 2, p + 5).toLowerCase();
                if (target.equals("xml")) {
                    return p;
                }
            }
            idx = p + 2;
        }
        return -1;
    }

    /**
     * Find the end-of-document position by locating the first element opened
     * after `from` and then its matching close tag in the raw text.
     * Returns the index AFTER the closing > of the root element, or -1 if
     * the structure can't be determined.
     *
     * This is a heuristic — it doesn't fully parse. It works for typical
     * concatenated-document responses where the root element name is
     * straightforward.
     */
    private static int findRootCloseEnd(String s, int from) {
        // Find first element start
        int open = s.indexOf('<', from);
        while (open >= 0 && open + 1 < s.length()) {
            char c = s.charAt(open + 1);
            if (c == '?' || c == '!' || c == '/') {
                open = s.indexOf('<', open + 1);
                continue;
            }
            break;
        }
        if (open < 0) return -1;
        // Read root element name
        int nameStart = open + 1;
        int nameEnd = nameStart;
        while (nameEnd < s.length()) {
            char c = s.charAt(nameEnd);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '>' || c == '/') break;
            nameEnd++;
        }
        if (nameEnd == nameStart) return -1;
        String rootName = s.substring(nameStart, nameEnd);
        String closeTag = "</" + rootName + ">";
        int closeStart = s.indexOf(closeTag);
        if (closeStart < 0) return -1;
        return closeStart + closeTag.length();
    }

    /**
     * If a payload contains 3+ HTML-escaped XML tags, decode them into real XML
     * so XPath can address the inner elements. Idempotent.
     */
    private static String decodeEmbeddedEscapedXml(String s) {
        if (s == null || !s.contains("&lt;")) return s;
        int hits = 0;
        int idx = 0;
        while ((idx = s.indexOf("&lt;", idx)) != -1) { hits++; idx += 4; if (hits >= 3) break; }
        if (hits < 3) return s;
        return s.replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'")
                .replace("&amp;", "&");
    }
}
