# Changelog

All notable changes to the qTest Test Case Importer are documented here.

Versioning follows [Semantic Versioning](https://semver.org/):
- **MAJOR** version for incompatible or breaking changes
- **MINOR** version for new functionality in a backward-compatible manner
- **PATCH** version for backward-compatible bug fixes

## [1.1.0]

### Fixed
- **Excel (.xlsx) reading failure** — The shaded JAR was missing the OOXML
  `WorkbookProvider` service registration because competing `META-INF/services`
  files from POI's modules overwrote each other during packaging. Added the
  Maven Shade `ServicesResourceTransformer` to merge them. Both `.xls` and
  `.xlsx` now work from the fat JAR.
- **log4j `NoClassDefFoundError` at startup** — Replaced the previous log4j-api
  exclusion (which broke POI's class loading) with the `log4j-to-slf4j` bridge
  routed to `slf4j-nop`. The vulnerable `log4j-core` remains absent.

### Changed
- **Test step ordering** — Steps are now zero-indexed to match qTest's internal
  ordering. ALM exports starting at step 1 are automatically shifted so the first
  step becomes order 0.

## [1.0.0]

### Added
- Initial release.
- Bulk import of test cases from ALM-exported Excel/CSV into qTest.
- OAuth authentication via `POST /oauth/token` using standard user credentials.
- ALM multi-row-per-test-case grouping (metadata in first row, steps across rows).
- Configurable field mapping via properties file.
- Automatic dropdown value resolution by label.
- Multi-value field support (array wrapping).
- Dry-run validation mode with sample payload output.
- Batch import with configurable size and delay.
- Per-record error logging.
- Discovery commands: `list-projects`, `list-fields`, `list-modules`.
