package com.apitest;

import com.apitest.comparator.Comparator;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A path that matches several values must return all of them, not just the
 * first. This is what lets a step capture, say, every id in a list and hand the
 * whole set to a db_rows assertion.
 */
class MultiValueExtractionTest {

    private static final String JSON = "{"
            + "\"groups\":[{\"id\":\"G1\",\"entries\":[{"
            + "\"items\":["
            + "{\"id\":\"ITEM_1\"},{\"id\":\"ITEM_10\"},{\"id\":\"ITEM_2\"},{\"id\":\"ITEM_3\"}"
            + "]}]}]}";

    @Test
    void extractsEveryMatchingId() {
        List<String> ids = Comparator.extractAllVariables(JSON, "$..items[*].id");
        assertEquals(List.of("ITEM_1", "ITEM_10", "ITEM_2", "ITEM_3"), ids);
    }

    @Test
    void fullyQualifiedPathReturnsSameSet() {
        List<String> ids = Comparator.extractAllVariables(
                JSON, "$.groups[*].entries[*].items[*].id");
        assertEquals(4, ids.size());
    }

    @Test
    void singleMatchReturnsOneElement() {
        List<String> one = Comparator.extractAllVariables(JSON, "$.groups[0].id");
        assertEquals(List.of("G1"), one);
    }

    @Test
    void noMatchReturnsEmpty() {
        List<String> none = Comparator.extractAllVariables(JSON, "$..nonexistent");
        assertTrue(none.isEmpty());
    }

    @Test
    void joinedResultIsAcommaSeparatedSetForDbRows() {
        List<String> ids = Comparator.extractAllVariables(JSON, "$..items[*].id");
        String joined = ids.size() == 1 ? ids.get(0) : String.join(",", ids);
        assertEquals("ITEM_1,ITEM_10,ITEM_2,ITEM_3", joined);
    }
}
