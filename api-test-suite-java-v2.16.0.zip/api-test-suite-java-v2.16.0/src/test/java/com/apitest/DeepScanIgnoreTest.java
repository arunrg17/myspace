package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Ignore directives must hold when the ignored field is returned by only one
 * of the two sources. Two environments on different releases often differ by
 * exactly one optional field, and an ignore row is how a user says that field
 * plays no part in the comparison.
 */
class DeepScanIgnoreTest {

    /** Five levels deep, with the flag on every repeated child. */
    private static final String WITH_FLAG =
            "{\"masterPartner\":{\"customer\":["
          + "{\"id\":1,\"accounts\":{\"cashaccount\":["
          + "{\"no\":\"A1\",\"bal\":10,\"deletedflag\":false},"
          + "{\"no\":\"A2\",\"bal\":20,\"deletedflag\":false}]}},"
          + "{\"id\":2,\"accounts\":{\"cashaccount\":["
          + "{\"no\":\"B1\",\"bal\":30,\"deletedflag\":false},"
          + "{\"no\":\"B2\",\"bal\":40,\"deletedflag\":true}]}}]}}";

    /** Same payload from a source that does not return the flag at all. */
    private static final String WITHOUT_FLAG = WITH_FLAG
            .replace(",\"deletedflag\":false", "")
            .replace(",\"deletedflag\":true", "");

    private static final String FLAG_FLIPPED =
            WITH_FLAG.replace("\"deletedflag\":true", "\"deletedflag\":false");

    private static final String DEEP_SCAN = "$..deletedflag";
    private static final String WILDCARD =
            "$.masterPartner.customer[*].accounts.cashaccount[*].deletedflag";

    private static List<Assertion> ignoreJson(String path) {
        return List.of(new Assertion(path, "jsonpath", "ignore", "", "varies by environment"));
    }

    @Test
    @DisplayName("deep scan ignore holds when both sources return the field")
    void bothSidesHaveField() {
        CompareResult r = Comparator.compare(WITH_FLAG, FLAG_FLIPPED, ignoreJson(DEEP_SCAN));
        assertTrue(r.matched, () -> "unexpected diffs: " + r.diffs);
    }

    @Test
    @DisplayName("deep scan ignore holds when only source A returns the field")
    void onlySourceAHasField() {
        CompareResult r = Comparator.compare(WITH_FLAG, WITHOUT_FLAG, ignoreJson(DEEP_SCAN));
        assertTrue(r.matched, () -> "unexpected diffs: " + r.diffs);
    }

    @Test
    @DisplayName("deep scan ignore holds when only source B returns the field")
    void onlySourceBHasField() {
        CompareResult r = Comparator.compare(WITHOUT_FLAG, WITH_FLAG, ignoreJson(DEEP_SCAN));
        assertTrue(r.matched, () -> "unexpected diffs: " + r.diffs);
    }

    @Test
    @DisplayName("deep scan ignore is harmless when neither source returns the field")
    void neitherSideHasField() {
        CompareResult r = Comparator.compare(WITHOUT_FLAG, WITHOUT_FLAG, ignoreJson(DEEP_SCAN));
        assertTrue(r.matched, () -> "unexpected diffs: " + r.diffs);
    }

    @Test
    @DisplayName("an explicit wildcard path behaves the same as a deep scan")
    void wildcardPathOneSidedField() {
        CompareResult r = Comparator.compare(WITH_FLAG, WITHOUT_FLAG, ignoreJson(WILDCARD));
        assertTrue(r.matched, () -> "unexpected diffs: " + r.diffs);
    }

    @Test
    @DisplayName("a real difference beside an ignored field is still reported")
    void realDifferenceStillReported() {
        CompareResult r = Comparator.compare(
                WITH_FLAG, WITHOUT_FLAG.replace("\"B2\"", "\"B9\""), ignoreJson(DEEP_SCAN));
        assertFalse(r.matched);
        assertEquals(1, r.diffs.size(), () -> "diffs: " + r.diffs);
        assertTrue(r.diffs.get(0).path.endsWith(".no"), r.diffs.get(0).path);
        assertEquals("B2", r.diffs.get(0).expected);
        assertEquals("B9", r.diffs.get(0).actual);
    }

    @Test
    @DisplayName("without an ignore row a one-sided field is still a difference")
    void withoutIgnoreFieldIsReported() {
        CompareResult r = Comparator.compare(WITH_FLAG, WITHOUT_FLAG, List.of());
        assertFalse(r.matched, "a field missing on one side must be reported when not ignored");
        assertEquals(4, r.diffs.size(), () -> "diffs: " + r.diffs);
    }

    @Test
    @DisplayName("an XPath ignore holds when only one source returns the element")
    void xpathIgnoreOneSidedField() {
        String a = "<r><acc><no>A1</no><deletedflag>false</deletedflag></acc>"
                 + "<acc><no>A2</no><deletedflag>true</deletedflag></acc></r>";
        String b = "<r><acc><no>A1</no></acc><acc><no>A2</no></acc></r>";
        CompareResult r = Comparator.compare(a, b,
                List.of(new Assertion("//deletedflag", "xpath", "ignore", "", "varies by environment")));
        assertTrue(r.matched, () -> "unexpected diffs: " + r.diffs);
    }
}
