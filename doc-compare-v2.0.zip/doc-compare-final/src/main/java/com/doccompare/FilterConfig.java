package com.doccompare;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;

/**
 * Immutable configuration for one comparison run.
 * Build with {@link Builder}.
 */
public final class FilterConfig {

    private final String  pdf1Path;
    private final String  pdf2Path;
    private final String  outputPath;
    private final boolean ignoreHeader;
    private final boolean ignoreFooter;
    private final boolean ignoreLeftMargin;
    private final boolean ignoreRightMargin;
    private final double  headerPct;
    private final double  footerPct;
    private final double  marginPct;
    private final boolean ignoreTimestamps;
    private final boolean ignorePageNumbers;
    private final List<Pattern> customPatterns;

    // ── Built-in patterns ───────────────────────────────────────────────────

    static final Pattern[] TIMESTAMP_PATTERNS = {
        Pattern.compile("\\b\\d{4}-\\d{2}-\\d{2}[T ]\\d{2}:\\d{2}(:\\d{2})?\\b"),
        Pattern.compile("\\b\\d{1,2}[/\\-.]\\d{1,2}[/\\-.]\\d{2,4}\\b"),
        Pattern.compile("\\b(\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{4}|[A-Za-z]{3,9}\\s+\\d{1,2},?\\s+\\d{4})\\b"),
        Pattern.compile("\\b\\d{1,2}:\\d{2}(:\\d{2})?\\s*(AM|PM|Uhr)?\\b", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?i)(printed|generated|created|issued|erstellt|datum|date|timestamp)[:\\s]+[\\d\\w./ \\-:,]{4,40}"),
    };

    static final Pattern[] PAGE_NUMBER_PATTERNS = {
        Pattern.compile("(?i)^\\s*page\\s+\\d+(\\s+of\\s+\\d+)?\\s*$"),
        Pattern.compile("(?i)^\\s*seite\\s+\\d+(\\s+von\\s+\\d+)?\\s*$"),
        Pattern.compile("^\\s*\\d+\\s*/\\s*\\d+\\s*$"),
        Pattern.compile("^\\s*[-\u2013]\\s*\\d+\\s*[-\u2013]\\s*$"),
        Pattern.compile("^\\s*\\d+\\s*$"),
    };

    private FilterConfig(Builder b) {
        this.pdf1Path          = b.pdf1Path;
        this.pdf2Path          = b.pdf2Path;
        this.outputPath        = b.outputPath;
        this.ignoreHeader      = b.ignoreHeader;
        this.ignoreFooter      = b.ignoreFooter;
        this.ignoreLeftMargin  = b.ignoreLeftMargin;
        this.ignoreRightMargin = b.ignoreRightMargin;
        this.headerPct         = clamp(b.headerPct,  1.0, 49.0);
        this.footerPct         = clamp(b.footerPct,  1.0, 49.0);
        this.marginPct         = clamp(b.marginPct,  1.0, 30.0);
        this.ignoreTimestamps  = b.ignoreTimestamps;
        this.ignorePageNumbers = b.ignorePageNumbers;
        this.customPatterns    = Collections.unmodifiableList(new ArrayList<>(b.customPatterns));
    }

    // ── Accessors ────────────────────────────────────────────────────────────

    public String  getPdf1Path()             { return pdf1Path; }
    public String  getPdf2Path()             { return pdf2Path; }
    public String  getOutputPath()           { return outputPath; }
    public boolean isIgnoreHeader()          { return ignoreHeader; }
    public boolean isIgnoreFooter()          { return ignoreFooter; }
    public boolean isIgnoreLeftMargin()      { return ignoreLeftMargin; }
    public boolean isIgnoreRightMargin()     { return ignoreRightMargin; }
    public double  getHeaderPct()            { return headerPct; }
    public double  getFooterPct()            { return footerPct; }
    public double  getMarginPct()            { return marginPct; }
    public boolean isIgnoreTimestamps()      { return ignoreTimestamps; }
    public boolean isIgnorePageNumbers()     { return ignorePageNumbers; }
    public List<Pattern> getCustomPatterns() { return customPatterns; }

    /**
     * Process one extracted line through all content filters.
     * @return filtered text, or null if the line should be dropped entirely.
     */
    public String processLine(String line) {
        if (line == null) return null;
        String trimmed = line.trim();

        if (ignorePageNumbers) {
            for (Pattern p : PAGE_NUMBER_PATTERNS) {
                if (p.matcher(trimmed).matches()) return null;
            }
        }

        String result = line;
        if (ignoreTimestamps) {
            for (Pattern p : TIMESTAMP_PATTERNS) {
                result = p.matcher(result).replaceAll("");
            }
        }
        for (Pattern p : customPatterns) {
            result = p.matcher(result).replaceAll("");
        }

        return result.trim().isEmpty() ? null : result;
    }

    /** Human-readable list of active filter names — shown in the report header. */
    public String summary() {
        List<String> parts = new ArrayList<>();
        if (ignoreHeader)      parts.add("header " + (int) headerPct + "%");
        if (ignoreFooter)      parts.add("footer " + (int) footerPct + "%");
        if (ignoreLeftMargin)  parts.add("left-margin " + (int) marginPct + "%");
        if (ignoreRightMargin) parts.add("right-margin " + (int) marginPct + "%");
        if (ignoreTimestamps)  parts.add("timestamps");
        if (ignorePageNumbers) parts.add("page-numbers");
        for (Pattern p : customPatterns) parts.add("text:" + p.pattern());
        return parts.isEmpty() ? "none" : String.join(" | ", parts);
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BUILDER
    // ════════════════════════════════════════════════════════════════════════

    public static final class Builder {

        private String  pdf1Path;
        private String  pdf2Path;
        private String  outputPath;
        private boolean ignoreHeader      = false;
        private boolean ignoreFooter      = false;
        private boolean ignoreLeftMargin  = false;
        private boolean ignoreRightMargin = false;
        private double  headerPct         = 10.0;
        private double  footerPct         = 10.0;
        private double  marginPct         = 8.0;
        private boolean ignoreTimestamps  = false;
        private boolean ignorePageNumbers = false;
        private final List<Pattern> customPatterns = new ArrayList<>();

        public Builder pdf1(String path)   { this.pdf1Path   = path; return this; }
        public Builder pdf2(String path)   { this.pdf2Path   = path; return this; }
        public Builder output(String path) { this.outputPath = path; return this; }

        public Builder ignoreHeader(boolean v)      { this.ignoreHeader      = v; return this; }
        public Builder ignoreFooter(boolean v)      { this.ignoreFooter      = v; return this; }
        public Builder ignoreLeftMargin(boolean v)  { this.ignoreLeftMargin  = v; return this; }
        public Builder ignoreRightMargin(boolean v) { this.ignoreRightMargin = v; return this; }
        public Builder ignoreMargins(boolean v)     { this.ignoreLeftMargin  = v; this.ignoreRightMargin = v; return this; }
        public Builder headerPct(double pct)        { this.headerPct         = pct; return this; }
        public Builder footerPct(double pct)        { this.footerPct         = pct; return this; }
        public Builder marginPct(double pct)        { this.marginPct         = pct; return this; }
        public Builder ignoreTimestamps(boolean v)  { this.ignoreTimestamps  = v; return this; }
        public Builder ignorePageNumbers(boolean v) { this.ignorePageNumbers = v; return this; }

        /** Add a Java regex — matched text is stripped from the line. */
        public Builder ignorePattern(String regex) {
            this.customPatterns.add(Pattern.compile(regex));
            return this;
        }

        /** Add a plain literal string to strip (auto-escaped, no regex knowledge needed). */
        public Builder ignoreText(String literal) {
            this.customPatterns.add(Pattern.compile(Pattern.quote(literal)));
            return this;
        }

        /**
         * Load ignore settings from a .properties file.
         * Settings are additive — combined with flags already set.
         *
         * Supported keys:
         *   ignore.header=true          ignore.footer=true
         *   ignore.margins=true         ignore.left.margin=true   ignore.right.margin=true
         *   ignore.timestamps=true      ignore.page.numbers=true
         *   header.pct=15               footer.pct=12             margin.pct=10
         *   ignore.text.1=Erstellt am   ignore.text.2=COSREP
         *   ignore.pattern.1=DRAFT      ignore.pattern.2=Generated by.*
         */
        public Builder ignoreConfig(String propertiesPath) throws IOException {
            Properties props = new Properties();
            try (FileInputStream fis = new FileInputStream(propertiesPath)) {
                props.load(fis);
            }
            if ("true".equalsIgnoreCase(props.getProperty("ignore.header")))        this.ignoreHeader      = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.footer")))        this.ignoreFooter      = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.left.margin")))   this.ignoreLeftMargin  = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.right.margin")))  this.ignoreRightMargin = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.margins")))       { this.ignoreLeftMargin = true; this.ignoreRightMargin = true; }
            if ("true".equalsIgnoreCase(props.getProperty("ignore.timestamps")))    this.ignoreTimestamps  = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.page.numbers")))  this.ignorePageNumbers = true;

            String hp = props.getProperty("header.pct"); if (hp != null) this.headerPct = Double.parseDouble(hp.trim());
            String fp = props.getProperty("footer.pct"); if (fp != null) this.footerPct = Double.parseDouble(fp.trim());
            String mp = props.getProperty("margin.pct"); if (mp != null) this.marginPct = Double.parseDouble(mp.trim());

            for (int n = 1; n <= 100; n++) {
                String v = props.getProperty("ignore.text." + n);
                if (v == null) break;
                this.customPatterns.add(Pattern.compile(Pattern.quote(v.trim())));
            }
            for (int n = 1; n <= 100; n++) {
                String v = props.getProperty("ignore.pattern." + n);
                if (v == null) break;
                this.customPatterns.add(Pattern.compile(v.trim()));
            }
            return this;
        }

        public FilterConfig build() {
            if (pdf1Path   == null || pdf1Path.trim().isEmpty())   throw new IllegalArgumentException("pdf1 path must be provided");
            if (pdf2Path   == null || pdf2Path.trim().isEmpty())   throw new IllegalArgumentException("pdf2 path must be provided");
            if (outputPath == null || outputPath.trim().isEmpty()) throw new IllegalArgumentException("output path must be provided");
            return new FilterConfig(this);
        }
    }
}
