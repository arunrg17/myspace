package com.apitest.model;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Per-step execution result.
 */
public class StepResult {
    public String name;
    public int order;
    public String method;
    public String url;
    public int status;
    public List<Integer> expectedStatus;
    public long elapsedMs;
    public String requestBody = "";
    public String responseBody = "";
    public Map<String, String> extracted = new LinkedHashMap<>();

    /** Short one-line error summary. */
    public String error;

    /** Full error detail (stack trace, cause chain). */
    public String errorDetail;

    public boolean passed;
}
