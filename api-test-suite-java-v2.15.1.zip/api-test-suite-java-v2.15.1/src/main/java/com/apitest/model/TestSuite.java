package com.apitest.model;

import java.util.List;
import java.util.Map;

/**
 * The fully parsed contents of a test-suite workbook.
 *
 * @param environments named environments keyed by environment name
 *                     (from the Environments sheet)
 * @param tests        the ordered list of enabled test cases
 *                     (from the TestSuite sheet, joined with Steps,
 *                     TestData and Assertions)
 */
public record TestSuite(
        Map<String, Environment> environments,
        List<TestCase> tests
) {}
