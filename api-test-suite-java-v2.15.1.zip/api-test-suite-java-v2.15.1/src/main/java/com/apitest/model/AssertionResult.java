package com.apitest.model;

/**
 * The outcome of evaluating a single {@link Assertion} against a response
 * (or against the database, for {@code db_*} operators).
 *
 * <p>Populated by {@code AssertionEngine} and rendered in the HTML report.
 * It echoes the inputs ({@link #path}, {@link #operator}, {@link #expectedValue})
 * alongside what was actually found ({@link #actualValue}) so a reader can see
 * exactly why an assertion passed or failed.
 */
public class AssertionResult {
    /** The path (JSONPath, XPath, or SQL) that was evaluated. */
    public String path;
    /** The operator applied, e.g. {@code equals}, {@code one_of}, {@code db_exists}. */
    public String operator;
    /** The value the assertion expected (may be empty for existence checks). */
    public String expectedValue;
    /** The value actually resolved from the response or database. */
    public String actualValue;
    /** Optional human-readable description carried over from the Excel row. */
    public String description;
    /** True if the assertion held. */
    public boolean passed;
    /** Explanation shown when the assertion fails (empty when it passes). */
    public String message = "";
}
