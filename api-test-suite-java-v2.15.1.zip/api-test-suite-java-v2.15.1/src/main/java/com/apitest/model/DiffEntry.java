package com.apitest.model;


/**
 * Diff entry: one structural mismatch between expected and actual.
 */
public class DiffEntry {
    public String path;
    public String expected;
    public String actual;
    public String kind; // value, type, added, removed, length

    /** Create an empty diff entry. */
    public DiffEntry() {}

    /**
     * @param path     location of the difference (JSON-path style)
     * @param expected value on the expected side ("<missing>" if absent)
     * @param actual   value on the actual side ("<missing>" if absent)
     * @param kind     one of value, type, added, removed, length
     */
    public DiffEntry(String path, String expected, String actual, String kind) {
        this.path = path;
        this.expected = expected;
        this.actual = actual;
        this.kind = kind;
    }
}
