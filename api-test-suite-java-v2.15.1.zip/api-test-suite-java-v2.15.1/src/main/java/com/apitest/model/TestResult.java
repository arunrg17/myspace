package com.apitest.model;

import java.util.ArrayList;
import java.util.List;

public class TestResult {
    public String testId;
    public String name;
    public String description;
    public String comparisonMode;
    public String sourceA;
    public String sourceB;
    public List<StepResult> stepsA = new ArrayList<>();
    public List<StepResult> stepsB = new ArrayList<>();
    public CompareResult compareResult;
    public List<AssertionResult> assertionResults = new ArrayList<>();
    public String status = "PASS";  // PASS, FAIL, ERROR
    public String started = "";
    public long durationMs;

    /** Short one-line error summary shown in the banner. */
    public String error;

    /** Full error detail (stack trace, cause chain) shown in the Diagnostics tab. */
    public String errorDetail;
}
