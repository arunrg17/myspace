package com.apitest.reporter;

import com.apitest.Version;
import com.apitest.model.TestResult;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * The report as data: everything the HTML report is built from, stored as one
 * JSON file.
 *
 * <p>A stored run only needs this file. It is a fraction of the size of the
 * finished HTML (which inlines its CSS and JS into every copy), and the exact
 * same HTML can be regenerated from it at any time with
 * {@link Reporter#renderHtml} - so an archive keeps JSON and renders on demand
 * rather than storing thousands of self-contained HTML files.
 *
 * <p>The envelope carries a schema marker so a future format change can be
 * detected instead of mis-read.
 */
public final class JsonReport {

    /** Bump when the envelope or model shape changes incompatibly. */
    public static final String SCHEMA = "apitest-report/1";

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .setSerializationInclusion(JsonInclude.Include.NON_NULL)
            .configure(SerializationFeature.INDENT_OUTPUT, true)
            // A newer engine may add fields; an older report must still load.
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    private JsonReport() {}

    /** The envelope written to disk. Public fields, like the model classes. */
    public static final class Envelope {
        public String schema = SCHEMA;
        public String engineVersion = Version.VERSION;
        public String suiteName = "";
        public String generatedAt = "";
        public Summary summary = new Summary();
        public List<TestResult> results = new ArrayList<>();
    }

    public static final class Summary {
        public int total;
        public int passed;
        public int failed;
        public int errored;
        public long durationMs;
    }

    /** Build the envelope for a finished run. */
    public static Envelope envelope(List<TestResult> results, String suiteName) {
        Envelope e = new Envelope();
        e.suiteName = suiteName == null ? "" : suiteName;
        e.generatedAt = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        e.results = results;
        e.summary.total = results.size();
        for (TestResult r : results) {
            switch (r.status == null ? "" : r.status) {
                case "PASS" -> e.summary.passed++;
                case "FAIL" -> e.summary.failed++;
                default -> e.summary.errored++;
            }
            e.summary.durationMs += r.durationMs;
        }
        return e;
    }

    /** Write the run as JSON. */
    public static void write(List<TestResult> results, Path outPath, String suiteName)
            throws IOException {
        if (outPath.getParent() != null) Files.createDirectories(outPath.getParent());
        MAPPER.writeValue(outPath.toFile(), envelope(results, suiteName));
    }

    /** Read a stored run back. Refuses a file from an unknown schema. */
    public static Envelope read(Path jsonPath) throws IOException {
        Envelope e = MAPPER.readValue(jsonPath.toFile(), Envelope.class);
        if (!SCHEMA.equals(e.schema)) {
            throw new IOException("Unsupported report schema '" + e.schema
                    + "' in " + jsonPath + " (this engine reads " + SCHEMA + ")");
        }
        return e;
    }

    /** Serialize to a JSON string (used by tests and the web layer). */
    public static String toJson(List<TestResult> results, String suiteName) throws IOException {
        return MAPPER.writeValueAsString(envelope(results, suiteName));
    }

    /** Parse a JSON string produced by {@link #toJson} or {@link #write}. */
    public static Envelope fromJson(String json) throws IOException {
        Envelope e = MAPPER.readValue(json, Envelope.class);
        if (!SCHEMA.equals(e.schema)) {
            throw new IOException("Unsupported report schema '" + e.schema + "'");
        }
        return e;
    }
}
