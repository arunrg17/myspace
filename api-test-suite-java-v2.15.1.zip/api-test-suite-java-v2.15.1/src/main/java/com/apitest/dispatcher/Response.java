package com.apitest.dispatcher;

import java.util.Map;

/**
 * The outcome of a single HTTP request made by {@link Dispatcher}.
 *
 * <p>This is a plain data holder. On success {@link #status}, {@link #headers},
 * {@link #body} and {@link #elapsedMs} are populated and {@link #error} is null.
 * On a transport failure (timeout, DNS, TLS, connection refused) {@link #error}
 * carries a human-readable message and the body/status are left at their
 * defaults, so callers can branch on {@code error != null} rather than catching
 * exceptions.
 */
public class Response {
    /** HTTP status code returned by the server (0 if the call never completed). */
    public int status;
    /** Response headers, keyed by header name. */
    public Map<String, String> headers;
    /** Response body as text (never null; empty string when there is no body). */
    public String body = "";
    /** Wall-clock time the request took, in milliseconds. */
    public long elapsedMs;
    /** The fully composed URL that was actually called. */
    public String url = "";
    /** Non-null only when the request failed before producing a response. */
    public String error;

    /** Creates an empty response with default values. */
    public Response() {}
}
