package com.apitest.dispatcher;

import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.*;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Multi-protocol HTTP dispatcher.
 *
 * <p>Handles auth header injection, content-type defaults, and response capture
 * for REST, SOAP, Apigee, Fabric (Microsoft), and GCP endpoints.
 *
 * <p>Supported protocols (set in the Environments sheet's Protocol column):
 * <ul>
 *   <li>{@code rest}    - generic REST; Content-Type defaults to application/json
 *   <li>{@code soap}    - SOAP; forces POST, defaults Content-Type to text/xml
 *   <li>{@code apigee}  - Apigee proxy; Content-Type defaults to application/json
 *   <li>{@code fabric}  - Microsoft Fabric; same as REST
 *   <li>{@code gcp}     - Google Cloud; same as REST
 * </ul>
 *
 * <p>For form-urlencoded auth requests, set Content-Type in ExtraHeaders:
 * {@code Content-Type: application/x-www-form-urlencoded} and write the body
 * template as {@code grant_type=client_credentials&client_id=${id}&client_secret=${secret}}.
 */
public class Dispatcher {

    private static final int DEFAULT_TIMEOUT_MS = 30_000;

    /**
     * Convenience overload that sends a request with no SSL configuration.
     *
     * @param protocol  one of rest, soap, apigee, fabric, gcp (affects defaults)
     * @param baseUrl   the environment base URL (skipped if endpoint is a full URL)
     * @param endpoint  the path or full URL to call
     * @param method    HTTP method (GET, POST, PUT, DELETE, ...)
     * @param body      request body (may be empty)
     * @param headers   headers to send; may override protocol defaults
     * @param authType  none, basic, bearer, apikey, oauth2, service_account
     * @param authValue the credential, already resolved from any secret reference
     * @return the response, or a Response whose {@code error} is set on failure
     */
    public static Response send(String protocol, String baseUrl, String endpoint,
                                String method, String body, Map<String, String> headers,
                                String authType, String authValue) {
        return send(protocol, baseUrl, endpoint, method, body, headers, authType, authValue, null);
    }

    /**
     * Send one HTTP request and capture the response.
     *
     * <p>This never throws on a transport problem: timeouts, DNS failures, TLS
     * errors and refused connections are caught and returned as a
     * {@link Response} with {@code error} set, so the runner can record a failed
     * step and carry on. Connect and socket timeouts are both bounded by
     * {@link #DEFAULT_TIMEOUT_MS}. The HTTP client and the response are always
     * closed.
     *
     * @param protocol  one of rest, soap, apigee, fabric, gcp (affects defaults)
     * @param baseUrl   the environment base URL (skipped if endpoint is a full URL)
     * @param endpoint  the path or full URL to call
     * @param method    HTTP method (GET, POST, PUT, DELETE, ...)
     * @param body      request body (may be empty)
     * @param headers   headers to send; may override protocol defaults
     * @param authType  none, basic, bearer, apikey, oauth2, service_account
     * @param authValue the credential, already resolved from any secret reference
     * @param sslConfig optional SSL configuration string (truststore, keystore, verify)
     * @return the response, or a Response whose {@code error} is set on failure
     */
    public static Response send(String protocol, String baseUrl, String endpoint,
                                String method, String body, Map<String, String> headers,
                                String authType, String authValue, String sslConfig) {

        String url = composeUrl(baseUrl, endpoint);
        Map<String, String> finalHeaders = new LinkedHashMap<>(headers == null ? Map.of() : headers);
        finalHeaders.putAll(resolveAuth(authType, authValue));

        // Protocol-specific defaults
        String proto = protocol == null ? "" : protocol.toLowerCase(Locale.ROOT);
        switch (proto) {
            case "soap" -> {
                finalHeaders.putIfAbsent("Content-Type", "text/xml; charset=utf-8");
                finalHeaders.putIfAbsent("SOAPAction", "\"\"");
                // SOAP is conventionally POST, so default to it - but honor an
                // explicitly configured method. Some gateways are invoked over
                // GET while still requiring the SOAP body (which is delivered
                // regardless of method). Only default to POST when no method
                // was given.
                if (method == null || method.isBlank()) {
                    method = "POST";
                }
            }
            case "apigee" -> {
                // Apigee proxies use REST over HTTPS with an API key.
                // The user can provide the key in AuthValue; we inject it
                // as the standard Apigee header if not already set.
                finalHeaders.putIfAbsent("Content-Type", "application/json");
            }
            default -> {
                // REST / GCP / Fabric / anything else
                if (body != null && !body.isEmpty()) {
                    finalHeaders.putIfAbsent("Content-Type", "application/json");
                }
            }
        }

        long started = System.currentTimeMillis();
        Response resp = new Response();
        resp.url = url;

        RequestConfig config = RequestConfig.custom()
                .setConnectTimeout(DEFAULT_TIMEOUT_MS)
                .setSocketTimeout(DEFAULT_TIMEOUT_MS)
                .build();

        try (CloseableHttpClient client = buildClient(config, sslConfig)) {
            boolean hasBody = body != null && !body.isEmpty();

            // Build the request. When a body is present on a GET/DELETE we use
            // a body-capable variant that KEEPS the method on the wire (a plain
            // HttpGet would silently drop the entity). This is what lets a
            // SOAP-over-GET gateway receive its XML body while the request line
            // still reads GET.
            HttpRequestBase request = buildRequest(method, url, hasBody);

            for (Map.Entry<String, String> e : finalHeaders.entrySet()) {
                request.addHeader(e.getKey(), e.getValue());
            }

            if (hasBody && request instanceof HttpEntityEnclosingRequestBase entReq) {
                String ct = finalHeaders.getOrDefault("Content-Type", "application/json");
                entReq.setEntity(new ByteArrayEntity(body.getBytes(StandardCharsets.UTF_8),
                                                     ContentType.parse(ct)));
            }

            var response = client.execute(request);
            try {
                resp.status = response.getStatusLine().getStatusCode();
                resp.headers = new HashMap<>();
                for (var h : response.getAllHeaders()) {
                    resp.headers.put(h.getName(), h.getValue());
                }
                resp.body = response.getEntity() == null ? ""
                        : EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            } finally {
                response.close();
            }
        } catch (Exception ex) {
            resp.error = ex.getClass().getSimpleName() + ": " + ex.getMessage();
        }

        resp.elapsedMs = System.currentTimeMillis() - started;
        return resp;
    }

    // ------------------------------------------------------------------

    /**
     * Builds an HttpClient with SSL configured per the env's SslConfig.
     * If sslConfig is null/empty, uses the JVM default trust store.
     */
    private static CloseableHttpClient buildClient(RequestConfig config, String sslConfig) {
        var builder = HttpClients.custom().setDefaultRequestConfig(config);

        if (sslConfig != null && !sslConfig.isBlank()) {
            SSLContext ctx = SslConfig.buildContext(sslConfig);
            if (ctx != null) {
                // When verify=false, also skip hostname verification - otherwise
                // a CN/SAN mismatch will still fail even with TrustAllManager.
                var hostnameVerifier = SslConfig.isVerifyDisabled(sslConfig)
                        ? NoopHostnameVerifier.INSTANCE
                        : SSLConnectionSocketFactory.getDefaultHostnameVerifier();
                var sslFactory = new SSLConnectionSocketFactory(ctx, hostnameVerifier);
                builder.setSSLSocketFactory(sslFactory);

                Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                        .register("http", PlainConnectionSocketFactory.getSocketFactory())
                        .register("https", sslFactory)
                        .build();
                builder.setConnectionManager(new BasicHttpClientConnectionManager(registry));
            }
        }

        return builder.build();
    }

    /**
     * Join a base URL and an endpoint into the final request URL.
     *
     * <p>If the endpoint is itself a full URL (starts with http:// or https://)
     * it is used verbatim and the base URL is ignored - this is what lets a
     * token endpoint on a different host work. Otherwise the endpoint is
     * appended to the base URL with exactly one slash between them.
     *
     * @param baseUrl  the environment base URL (may be null/empty)
     * @param endpoint the path or full URL
     * @return the composed absolute URL
     */
    private static String composeUrl(String baseUrl, String endpoint) {
        if (baseUrl == null) baseUrl = "";
        if (endpoint == null || endpoint.isEmpty()) return baseUrl;

        // If the endpoint is already a full URL (e.g. a token endpoint on a
        // different host), use it as-is - don't prepend the env's BaseURL.
        if (endpoint.startsWith("http://") || endpoint.startsWith("https://")) {
            return endpoint;
        }

        String b = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        String e = endpoint.startsWith("/") ? endpoint : "/" + endpoint;
        return b + e;
    }

    /**
     * Build the Apache HttpClient request object for the given HTTP method.
     *
     * @param method the HTTP verb (case-insensitive)
     * @param url    the absolute request URL
     * @return a method-specific request object
     * @throws IllegalArgumentException if the method is not supported
     */
    private static HttpRequestBase buildRequest(String method, String url) {
        return buildRequest(method, url, false);
    }

    /**
     * Build the Apache HttpClient request object for the given HTTP method.
     *
     * <p>GET and DELETE normally carry no body. But some SOAP/legacy gateways
     * are invoked over GET yet still require an XML body. When {@code withBody}
     * is true and the method is GET or DELETE, a body-capable request variant
     * is returned so the entity is actually transmitted (and the request line
     * still reads GET/DELETE) instead of being silently dropped.
     *
     * @param method   the HTTP verb (case-insensitive)
     * @param url      the absolute request URL
     * @param withBody whether a non-empty body will be attached
     * @return a method-specific request object
     * @throws IllegalArgumentException if the method is not supported
     */
    private static HttpRequestBase buildRequest(String method, String url, boolean withBody) {
        return switch (method.toUpperCase()) {
            case "GET" -> withBody ? new HttpGetWithEntity(url) : new HttpGet(url);
            case "POST" -> new HttpPost(url);
            case "PUT" -> new HttpPut(url);
            case "DELETE" -> withBody ? new HttpDeleteWithEntity(url) : new HttpDelete(url);
            case "PATCH" -> new HttpPatch(url);
            case "HEAD" -> new HttpHead(url);
            case "OPTIONS" -> new HttpOptions(url);
            default -> throw new IllegalArgumentException("Unsupported method: " + method);
        };
    }

    /**
     * A GET request that can carry a request body. Standard {@link HttpGet}
     * cannot enclose an entity, so a body would be silently dropped; some
     * SOAP gateways require the body even on GET. This variant keeps the
     * request-line method as GET while carrying the entity.
     */
    private static final class HttpGetWithEntity extends HttpEntityEnclosingRequestBase {
        HttpGetWithEntity(String uri) { super(); setURI(java.net.URI.create(uri)); }
        @Override public String getMethod() { return "GET"; }
    }

    /** A DELETE request that can carry a request body (symmetric with GET). */
    private static final class HttpDeleteWithEntity extends HttpEntityEnclosingRequestBase {
        HttpDeleteWithEntity(String uri) { super(); setURI(java.net.URI.create(uri)); }
        @Override public String getMethod() { return "DELETE"; }
    }

    /**
     * Turn an auth type and credential into the headers that carry it.
     *
     * <p>Supports: {@code basic} (Base64 user:pass), {@code bearer}/{@code oauth2}/
     * {@code service_account} (Authorization: Bearer ...), and {@code apikey}
     * (x-api-key). The credential is first resolved through
     * {@link SslConfig#resolveSecret} so {@code ${env.VAR}} and
     * {@code ${file.path:key}} references work. Returns an empty map for
     * {@code none} or an unrecognized type.
     *
     * @param authType  the auth scheme
     * @param authValue the raw credential (possibly a secret reference)
     * @return headers to merge into the request
     */
    private static Map<String, String> resolveAuth(String authType, String authValue) {
        Map<String, String> out = new HashMap<>();
        if (authType == null || authType.isEmpty() || "none".equalsIgnoreCase(authType)) return out;

        // Resolve the value - supports ${env.VAR}, ${file.path:key}, or literal
        String value = SslConfig.resolveSecret(authValue == null ? "" : authValue);

        switch (authType.toLowerCase(Locale.ROOT)) {
            case "basic" -> {
                if (value.contains(":")) {
                    String enc = Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
                    out.put(HttpHeaders.AUTHORIZATION, "Basic " + enc);
                }
            }
            case "bearer"         -> out.put(HttpHeaders.AUTHORIZATION, "Bearer " + value);
            case "apikey"         -> out.put("x-api-key", value);
            case "oauth2"         -> out.put(HttpHeaders.AUTHORIZATION, "Bearer " + value);
            case "service_account"-> out.put(HttpHeaders.AUTHORIZATION, "Bearer " + value);
        }
        return out;
    }
}
