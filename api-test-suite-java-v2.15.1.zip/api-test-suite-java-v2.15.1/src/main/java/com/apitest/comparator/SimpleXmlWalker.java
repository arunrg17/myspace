package com.apitest.comparator;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Simple tag-walker for extracting values from XML-like text.
 *
 * Why not use a real XML parser? Real-world SOAP responses contain so many
 * standards violations (stray PIs, mixed encodings, unescaped chars, double-
 * wrapped payloads) that strict parsers reject them. We don't need full XML
 * validation - we just need to find tags by name and read their content.
 *
 * Supported XPath-like syntax:
 *   //TagName                          - first <TagName>...</TagName>
 *   //TagName[N]                       - Nth occurrence (1-indexed)
 *   //Parent[Child='value']            - first <Parent> whose <Child> has text 'value'
 *   //Parent[Child='value']/Sibling    - sibling tag inside the matched parent
 *   //Parent[ChildA/ChildB='value']    - predicate on nested child
 *   //Parent[Child='value']/A/B        - chained navigation after match
 *
 * Namespace prefixes are stripped: //Envelope matches <S:Envelope> and <Envelope>.
 * Element-name matching is case-sensitive (XML rule).
 * HTML-escaped content (&lt;Inner&gt;...) is recursively walked too.
 */
public class SimpleXmlWalker {

    private static final Pattern TAG_OPEN = Pattern.compile(
            "<(?!\\?|!)([A-Za-z_][\\w.\\-]*(?::[\\w.\\-]+)?)([^>]*)>",
            Pattern.DOTALL);
    private static final Pattern TAG_SELF_CLOSE = Pattern.compile(
            "<(?!\\?|!)([A-Za-z_][\\w.\\-]*(?::[\\w.\\-]+)?)([^>]*?)/>",
            Pattern.DOTALL);
    private static final Pattern CLOSE_TAG = Pattern.compile(
            "</([A-Za-z_][\\w.\\-]*(?::[\\w.\\-]+)?)\\s*>");
    private static final Pattern PREDICATE_EQ = Pattern.compile("(.+?)\\s*=\\s*['\"](.+?)['\"]");

    /**
     * Find the value at the given XPath-like expression.
     * Returns "" if no match, never throws on malformed input.
     */
    public static String findFirst(String xml, String xpath) {
        if (xml == null || xml.isEmpty() || xpath == null || xpath.isEmpty()) return "";

        String body = stripJunk(xml);
        body = decodeEscaped(body);
        body = unwrapCdata(body);
        body = stripInnerXmlDeclarations(body);

        List<PathStep> steps = parsePath(xpath);
        if (steps.isEmpty()) return "";

        return walk(body, 0, body.length(), steps, 0);
    }

    /**
     * Return every matching value for the given XPath-like expression.
     *
     * <p>Same preprocessing and path parsing as {@link #findFirst}, but
     * instead of stopping at the first match it collects them all. Used by
     * the assertion engine so it can check all sibling elements that share
     * the same tag name.
     *
     * @param xml   the XML payload
     * @param xpath the XPath-like expression
     * @return all matching text values (never null; empty list on no match)
     */
    public static List<String> findAll(String xml, String xpath) {
        if (xml == null || xml.isEmpty() || xpath == null || xpath.isEmpty()) return List.of();

        String body = stripJunk(xml);
        body = decodeEscaped(body);
        body = unwrapCdata(body);
        body = stripInnerXmlDeclarations(body);

        List<PathStep> steps = parsePath(xpath);
        if (steps.isEmpty()) return List.of();

        List<String> results = new ArrayList<>();
        walkAll(body, 0, body.length(), steps, 0, results);
        return results;
    }

    /**
     * Returns true if this XPath uses only idioms the walker supports.
     * If false, the caller should fall through to the strict XPath engine.
     *
     * Supported:  //Tag, //Tag[N], //Tag[last()], //Tag[Child='value'],
     *             //Tag[Child/Grand='v'], chained navigation with /
     * Unsupported (use strict XPath): count(), starts-with(), contains(),
     *             attribute paths @attr, $variables, complex predicates with
     *             logical operators (and, or, not()).
     */
    public static boolean canHandle(String xpath) {
        if (xpath == null || xpath.isEmpty()) return false;
        String x = xpath.trim();
        // JSONPath syntax is not XPath at all
        if (x.startsWith("$")) return false;
        // Functions and advanced selectors
        if (x.contains("count(") || x.contains("starts-with(")
                || x.contains("contains(") || x.contains("not(")
                || x.contains("text()") || x.contains("local-name(")
                || x.contains(" and ") || x.contains(" or ")) return false;
        // Attribute selection (@attr)
        if (x.contains("@")) return false;
        // Must start with // or /
        if (!x.startsWith("/")) return false;
        return true;
    }

    //
    // Path parsing
    //

    private record PathStep(String tagName, String predicateChild, String predicateValue, int positional) {
        boolean isLast() { return positional == -1; }
    }

    /**
     * Split an XPath-like expression into ordered path steps.
     * Handles leading "//", element names, and predicates such as
     * [child='value'] or [n]. Each step is matched in turn during the walk.
     */
    private static List<PathStep> parsePath(String xpath) {
        List<PathStep> steps = new ArrayList<>();
        // Normalise leading "//" or "/"
        String p = xpath.trim();
        if (p.startsWith("//")) p = p.substring(2);
        else if (p.startsWith("/")) p = p.substring(1);

        // Split on / but NOT inside [...]
        List<String> segments = new ArrayList<>();
        StringBuilder buf = new StringBuilder();
        int depth = 0;
        for (int i = 0; i < p.length(); i++) {
            char c = p.charAt(i);
            if (c == '[') depth++;
            else if (c == ']') depth--;
            if (c == '/' && depth == 0) {
                if (buf.length() > 0) { segments.add(buf.toString()); buf.setLength(0); }
            } else {
                buf.append(c);
            }
        }
        if (buf.length() > 0) segments.add(buf.toString());

        for (String seg : segments) {
            steps.add(parseSegment(seg));
        }
        return steps;
    }

    /**
     * Parse a single path segment (one tag plus an optional predicate) into a
     * {@link PathStep}. Recognises positional ([2]), last(), and
     * child-equals ([id='X']) predicates.
     */
    private static PathStep parseSegment(String segment) {
        // Forms: TagName, TagName[N], TagName[Child='v'], TagName[A/B='v']
        int br = segment.indexOf('[');
        if (br < 0) {
            return new PathStep(localName(segment.trim()), null, null, 0);
        }
        String tag = localName(segment.substring(0, br).trim());
        int closeBr = segment.lastIndexOf(']');
        if (closeBr < br) return new PathStep(tag, null, null, 0);
        String pred = segment.substring(br + 1, closeBr).trim();

        // Positional index: [3]
        if (pred.matches("\\d+")) {
            return new PathStep(tag, null, null, Integer.parseInt(pred));
        }
        // last()
        if (pred.equals("last()")) {
            return new PathStep(tag, null, null, -1);
        }

        // child='value' or child="value" or A/B='value'
        Matcher m = PREDICATE_EQ.matcher(pred);
        if (m.matches()) {
            return new PathStep(tag, m.group(1).trim(), m.group(2), 0);
        }
        return new PathStep(tag, null, null, 0);
    }

    /** Strip any namespace prefix, returning just the local element name. */
    private static String localName(String qname) {
        int c = qname.indexOf(':');
        return c >= 0 ? qname.substring(c + 1) : qname;
    }

    //
    // Walker
    //

    /**
     * Recursively find the next step's tag within the current bounds [start, end).
     * Returns the inner text content of the final matched element, or "" if none.
     */
    private static String walk(String xml, int start, int end, List<PathStep> steps, int stepIdx) {
        if (stepIdx >= steps.size()) return "";
        PathStep step = steps.get(stepIdx);

        // Special handling for last(): collect ALL matching elements, then take the last.
        if (step.isLast()) {
            List<ElementRange> matches = new ArrayList<>();
            int cursor = start;
            while (cursor < end) {
                ElementRange er = findNextElement(xml, cursor, end, step.tagName);
                if (er == null) break;
                matches.add(er);
                cursor = er.afterEnd;
            }
            if (matches.isEmpty()) return "";
            ElementRange chosen = matches.get(matches.size() - 1);
            if (stepIdx + 1 >= steps.size()) {
                return innerText(xml, chosen.contentStart, chosen.contentEnd);
            }
            return walk(xml, chosen.contentStart, chosen.contentEnd, steps, stepIdx + 1);
        }

        int position = 0;
        int cursor = start;
        while (cursor < end) {
            ElementRange er = findNextElement(xml, cursor, end, step.tagName);
            if (er == null) return "";

            // Predicate / positional check
            boolean accept = true;
            if (step.positional > 0) {
                position++;
                accept = (position == step.positional);
            } else if (step.predicateChild != null) {
                String childVal = resolveChildValue(xml, er.contentStart, er.contentEnd, step.predicateChild);
                accept = step.predicateValue.equals(childVal == null ? null : childVal.trim());
            }

            if (accept) {
                if (stepIdx + 1 >= steps.size()) {
                    return innerText(xml, er.contentStart, er.contentEnd);
                }
                String r = walk(xml, er.contentStart, er.contentEnd, steps, stepIdx + 1);
                if (!r.isEmpty()) return r;
                if (step.positional > 0) return "";
            }

            cursor = er.afterEnd;
        }
        return "";
    }

    /**
     * Like {@link #walk}, but collects every matching value instead of
     * returning on the first one.
     */
    private static void walkAll(String xml, int start, int end,
                                List<PathStep> steps, int stepIdx,
                                List<String> results) {
        if (stepIdx >= steps.size()) return;
        PathStep step = steps.get(stepIdx);

        if (step.isLast()) {
            // last() - only the final occurrence is collected
            List<ElementRange> matches = new ArrayList<>();
            int cursor = start;
            while (cursor < end) {
                ElementRange er = findNextElement(xml, cursor, end, step.tagName);
                if (er == null) break;
                matches.add(er);
                cursor = er.afterEnd;
            }
            if (matches.isEmpty()) return;
            ElementRange chosen = matches.get(matches.size() - 1);
            if (stepIdx + 1 >= steps.size()) {
                results.add(innerText(xml, chosen.contentStart, chosen.contentEnd));
            } else {
                walkAll(xml, chosen.contentStart, chosen.contentEnd, steps, stepIdx + 1, results);
            }
            return;
        }

        int position = 0;
        int cursor = start;
        while (cursor < end) {
            ElementRange er = findNextElement(xml, cursor, end, step.tagName);
            if (er == null) return;

            boolean accept = true;
            if (step.positional > 0) {
                position++;
                accept = (position == step.positional);
            } else if (step.predicateChild != null) {
                String childVal = resolveChildValue(xml, er.contentStart, er.contentEnd, step.predicateChild);
                accept = step.predicateValue.equals(childVal == null ? null : childVal.trim());
            }

            if (accept) {
                if (stepIdx + 1 >= steps.size()) {
                    results.add(innerText(xml, er.contentStart, er.contentEnd));
                } else {
                    walkAll(xml, er.contentStart, er.contentEnd, steps, stepIdx + 1, results);
                }
                if (step.positional > 0) return;
            }

            cursor = er.afterEnd;
        }
    }

    /**
     * Resolve a child-path (potentially nested like 'A/B/C') to a leaf text value.
     */
    private static String resolveChildValue(String xml, int start, int end, String childPath) {
        String[] parts = childPath.split("/");
        int curStart = start, curEnd = end;
        for (int i = 0; i < parts.length; i++) {
            String tag = localName(parts[i].trim());
            ElementRange er = findNextElement(xml, curStart, curEnd, tag);
            if (er == null) return null;
            if (i == parts.length - 1) {
                return innerText(xml, er.contentStart, er.contentEnd);
            }
            curStart = er.contentStart;
            curEnd = er.contentEnd;
        }
        return null;
    }

    /**
     * Element range info - where the open tag ends, where the matching close starts,
     * and where to resume scanning afterwards.
     */
    private record ElementRange(int openEnd, int contentStart, int contentEnd, int afterEnd) {}

    /**
     * Find the next element with the given local name in [start, end).
     * `//` (descendant) semantics: descends into elements, not just siblings.
     * Handles self-closing tags, nested same-name tags, namespace prefixes,
     * comments, processing instructions, and CDATA sections.
     */
    private static ElementRange findNextElement(String xml, int start, int end, String tagName) {
        int idx = start;
        while (idx < end) {
            int lt = xml.indexOf('<', idx);
            if (lt < 0 || lt >= end) return null;

            // Skip comments, processing instructions, CDATA, closing tags
            if (xml.startsWith("<!--", lt)) {
                int close = xml.indexOf("-->", lt + 4);
                idx = close < 0 ? end : close + 3;
                continue;
            }
            if (xml.startsWith("<?", lt)) {
                int close = xml.indexOf("?>", lt + 2);
                idx = close < 0 ? end : close + 2;
                continue;
            }
            if (xml.startsWith("<![CDATA[", lt)) {
                int close = xml.indexOf("]]>", lt + 9);
                idx = close < 0 ? end : close + 3;
                continue;
            }
            if (xml.startsWith("</", lt)) {
                int gt = xml.indexOf('>', lt + 2);
                idx = gt < 0 ? end : gt + 1;
                continue;
            }

            // Tag name runs from '<' to the first whitespace or '>'.
            int nameStart = lt + 1;
            int nameEnd = nameStart;
            while (nameEnd < end) {
                char c = xml.charAt(nameEnd);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '>' || c == '/') break;
                nameEnd++;
            }
            if (nameEnd <= nameStart) { idx = lt + 1; continue; }
            String fullName = xml.substring(nameStart, nameEnd);
            String thisLocal = localName(fullName);

            int gt = xml.indexOf('>', nameEnd);
            if (gt < 0 || gt >= end) return null;
            boolean selfClose = (gt > 0 && xml.charAt(gt - 1) == '/');

            if (thisLocal.equals(tagName)) {
                // Found a match
                if (selfClose) {
                    return new ElementRange(gt + 1, gt + 1, gt, gt + 1);
                }
                int contentStart = gt + 1;
                int contentEnd = findMatchingClose(xml, contentStart, end, fullName);
                if (contentEnd < 0) {
                    // Unclosed tag - return what we have (best-effort), content runs to end
                    return new ElementRange(gt, contentStart, end, end);
                }
                int afterClose = xml.indexOf('>', contentEnd);
                return new ElementRange(gt, contentStart, contentEnd, afterClose < 0 ? end : afterClose + 1);
            }

            // Not a match - DESCEND into this element (// = descendant axis).
            // Just advance past the opening tag's '>' and keep scanning;
            // we'll naturally enter the element's content on the next iteration.
            if (selfClose) {
                idx = gt + 1;
            } else {
                idx = gt + 1;  // descend into content
            }
        }
        return null;
    }

    /**
     * Find the position of the matching closing tag (the '<' of '</name>'),
     * respecting nested same-named elements.
     */
    private static int findMatchingClose(String xml, int start, int end, String fullName) {
        String localTag = localName(fullName);
        int depth = 1;
        int idx = start;
        while (idx < end) {
            int lt = xml.indexOf('<', idx);
            if (lt < 0 || lt >= end) return -1;

            // Skip comments / PIs / CDATA
            if (xml.startsWith("<!--", lt)) {
                int c = xml.indexOf("-->", lt + 4);
                idx = c < 0 ? end : c + 3;
                continue;
            }
            if (xml.startsWith("<?", lt)) {
                int c = xml.indexOf("?>", lt + 2);
                idx = c < 0 ? end : c + 2;
                continue;
            }
            if (xml.startsWith("<![CDATA[", lt)) {
                int c = xml.indexOf("]]>", lt + 9);
                idx = c < 0 ? end : c + 3;
                continue;
            }

            boolean isClose = xml.startsWith("</", lt);
            int nameStart = lt + (isClose ? 2 : 1);
            int nameEnd = nameStart;
            while (nameEnd < end) {
                char c = xml.charAt(nameEnd);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '>' || c == '/') break;
                nameEnd++;
            }
            if (nameEnd <= nameStart) { idx = lt + 1; continue; }
            String thisLocal = localName(xml.substring(nameStart, nameEnd));
            int gt = xml.indexOf('>', nameEnd);
            if (gt < 0 || gt >= end) return -1;

            if (thisLocal.equals(localTag)) {
                if (isClose) {
                    depth--;
                    if (depth == 0) return lt;
                } else {
                    boolean selfClose = (gt > 0 && xml.charAt(gt - 1) == '/');
                    if (!selfClose) depth++;
                }
            }
            idx = gt + 1;
        }
        return -1;
    }

    /**
     * Extract the trimmed text content of an element. If the content contains
     * nested tags, returns just the concatenated text nodes (recursively).
     * Honors CDATA sections by preserving their content literally.
     */
    private static String innerText(String xml, int start, int end) {
        if (start >= end) return "";
        String content = xml.substring(start, end);

        // First, extract CDATA content (preserve as-is)
        if (content.contains("<![CDATA[")) {
            StringBuilder out = new StringBuilder();
            int idx = 0;
            while (idx < content.length()) {
                int cdStart = content.indexOf("<![CDATA[", idx);
                if (cdStart < 0) {
                    out.append(content.substring(idx));
                    break;
                }
                out.append(content, idx, cdStart);
                int cdEnd = content.indexOf("]]>", cdStart + 9);
                if (cdEnd < 0) {
                    out.append(content.substring(cdStart + 9));
                    break;
                }
                out.append(content, cdStart + 9, cdEnd);
                idx = cdEnd + 3;
            }
            content = out.toString();
        }

        // If there are nested tags, strip them - keep only text
        if (content.contains("<")) {
            content = content.replaceAll("<!--.*?-->", "");
            content = content.replaceAll("<\\?[^?]*\\?>", "");
            content = content.replaceAll("<![A-Z][^>]*>", "");
            content = content.replaceAll("<[^>]+>", "");
        }
        // Unescape entities for leaf values
        content = content.replace("&lt;", "<")
                         .replace("&gt;", ">")
                         .replace("&quot;", "\"")
                         .replace("&apos;", "'")
                         .replace("&#xd;", "").replace("&#xD;", "")
                         .replace("&#13;", "")
                         .replace("&amp;", "&");
        return content.trim();
    }

    //
    // Pre-processing
    //

    /** Strip BOM, leading whitespace, CRs, and known junk character refs. */
    private static String stripJunk(String s) {
        if (s == null || s.isEmpty()) return s;
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '\uFEFF' || c == '\u00A0'
                    || Character.isWhitespace(c) || Character.isISOControl(c)) i++;
            else break;
        }
        String out = i == 0 ? s : s.substring(i);
        out = out.replace("\r\n", "\n").replace("\r", "");
        return out;
    }

    /**
     * Replace every <![CDATA[ ... ]]> section with its raw inner content,
     * so the walker can descend into elements that were wrapped in CDATA.
     * Some SOAP services wrap the inner XML payload this way.
     */
    private static String unwrapCdata(String s) {
        if (s == null || !s.contains("<![CDATA[")) return s;
        StringBuilder out = new StringBuilder(s.length());
        int idx = 0;
        while (idx < s.length()) {
            int start = s.indexOf("<![CDATA[", idx);
            if (start < 0) {
                out.append(s, idx, s.length());
                break;
            }
            out.append(s, idx, start);
            int end = s.indexOf("]]>", start + 9);
            if (end < 0) {
                // Unterminated CDATA - keep the rest as-is
                out.append(s, start + 9, s.length());
                break;
            }
            // Append the inner content WITHOUT the markers
            out.append(s, start + 9, end);
            idx = end + 3;
        }
        return out.toString();
    }

    /**
     * Strip every &lt;?xml ... ?&gt; declaration that's NOT at the very start
     * of the document. After unwrapping CDATA / decoding escaped XML, the
     * inner payloads' own prologs end up sitting mid-document, which would
     * confuse strict parsers - but more importantly, they shift positions
     * for human readers debugging the response. Just remove them all and
     * leave only the outermost one (if any).
     */
    private static String stripInnerXmlDeclarations(String s) {
        if (s == null || s.isEmpty()) return s;
        // Find the FIRST <?xml - keep it intact (legitimate prolog)
        int first = s.indexOf("<?xml");
        if (first < 0) {
            // No prologs at all, just strip any case-variant inner ones
            return s.replaceAll("(?i)<\\?xml[^?]*\\?>", "");
        }
        int firstEnd = s.indexOf("?>", first);
        if (firstEnd < 0) return s;
        String prolog = s.substring(0, firstEnd + 2);
        String rest = s.substring(firstEnd + 2);
        // Strip every additional <?xml...?> from `rest`
        rest = rest.replaceAll("(?i)<\\?xml[^?]*\\?>", "");
        return prolog + rest;
    }

    /**
     * Decode HTML-escaped XML chunks (for SOAP-in-SOAP payloads).
     * Iterates until no more escaped XML layers remain - some servers
     * double-encode (escaped XML inside an element whose value is itself
     * escaped XML), and the walker needs the fully unwrapped tree.
     *
     * Handles both named entities (&lt; &gt; &amp; &quot; &apos;) AND
     * numeric character references (&#60; &#62; &#38; etc.) - some servers
     * emit one form, some the other, some both.
     */
    private static String decodeEscaped(String s) {
        if (s == null) return s;
        // Apply repeatedly until no further decoding is possible
        for (int pass = 0; pass < 10; pass++) {  // hard cap on layers
            // Detect if there's escaped XML to unwrap. Triggers on either
            // &lt; (named) or &#60; (numeric, decimal) or &#x3c; (numeric, hex).
            int totalEscapes = countOccurrences(s, "&lt;")
                             + countOccurrences(s, "&#60;")
                             + countOccurrences(s, "&#x3c;")
                             + countOccurrences(s, "&#x3C;");
            if (totalEscapes < 3) return s;

            String next = s
                    // Numeric refs first (so &amp;#60; -> &#60; -> < doesn't double-process)
                    .replace("&#60;", "<").replace("&#062;", "<")
                    .replace("&#62;", ">").replace("&#x3c;", "<")
                    .replace("&#x3C;", "<").replace("&#x3e;", ">")
                    .replace("&#x3E;", ">")
                    .replace("&#34;", "\"").replace("&#x22;", "\"")
                    .replace("&#39;", "'").replace("&#x27;", "'")
                    // Named refs
                    .replace("&lt;", "<")
                    .replace("&gt;", ">")
                    .replace("&quot;", "\"")
                    .replace("&apos;", "'")
                    // &amp; LAST so we don't pre-empty &amp;lt; -> <
                    .replace("&amp;", "&");
            if (next.equals(s)) return s;
            s = next;
        }
        return s;
    }

    /** Count non-overlapping occurrences of a substring. */
    private static int countOccurrences(String s, String sub) {
        if (s == null || sub == null || sub.isEmpty()) return 0;
        int count = 0, idx = 0;
        while ((idx = s.indexOf(sub, idx)) != -1) {
            count++;
            idx += sub.length();
            if (count >= 3) break; // early exit; we only need to know "3 or more"
        }
        return count;
    }
}
