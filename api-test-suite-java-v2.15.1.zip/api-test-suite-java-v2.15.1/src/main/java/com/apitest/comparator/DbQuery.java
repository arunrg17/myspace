package com.apitest.comparator;

import com.apitest.model.Environment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Runs a read-only query against an environment's configured database and
 * returns the first column of every row. Shared by DB assertions and by SQL
 * references in the TestData sheet so both go through the same connection
 * handling and the same safety guards: only SELECT/WITH is allowed, stacked
 * statements are rejected, and the connection is opened read-only with a bounded
 * timeout.
 */
public final class DbQuery {

    private DbQuery() {
    }

    /** Thrown when a query is rejected by a guard or fails to run. */
    public static final class DbQueryException extends RuntimeException {
        public DbQueryException(String message) {
            super(message);
        }
    }

    /**
     * Reject anything that is not a single read-only SELECT/WITH. Returns the
     * trimmed SQL when it passes; throws with a clear reason when it does not.
     */
    public static String guard(String sql) {
        if (sql == null || sql.trim().isEmpty()) {
            throw new DbQueryException("SQL query is empty");
        }
        String trimmed = sql.trim();
        String firstWord = trimmed.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        if (!firstWord.equals("select") && !firstWord.equals("with")) {
            throw new DbQueryException(
                    "Only read-only SELECT/WITH queries are allowed; got: " + firstWord);
        }
        int sc = trimmed.indexOf(';');
        if (sc >= 0 && sc < trimmed.length() - 1 && !trimmed.substring(sc + 1).trim().isEmpty()) {
            throw new DbQueryException("Multiple statements are not allowed (found ';')");
        }
        return trimmed;
    }

    /**
     * Run the query against the environment's database and return the first
     * column of each row, trimmed. The caller decides what to do with the list
     * (a single value, or a comma-joined set). Secret references in the DB
     * credentials are resolved the same way the assertion path resolves them.
     */
    public static List<String> firstColumn(Environment env, String sql) {
        if (env == null || env.dbUrl() == null || env.dbUrl().isEmpty()) {
            throw new DbQueryException("No database configured on environment '"
                    + (env == null ? "" : env.name()) + "' (DbURL is empty)");
        }
        String guarded = guard(sql);

        String password = com.apitest.dispatcher.SslConfig.resolveSecret(env.dbPassword());
        String user = com.apitest.dispatcher.SslConfig.resolveSecret(env.dbUser());
        String dbUrl = com.apitest.dispatcher.SslConfig.resolveSecret(env.dbUrl());

        if (env.dbDriver() != null && !env.dbDriver().isEmpty()) {
            try {
                Class.forName(env.dbDriver());
            } catch (ClassNotFoundException cnf) {
                throw new DbQueryException("JDBC driver not found: " + env.dbDriver()
                        + ". Add the vendor driver jar to the classpath "
                        + "(for Oracle, ojdbc11.jar) and restart.");
            }
        }

        try (Connection conn = DriverManager.getConnection(dbUrl, user, password);
             Statement stmt = conn.createStatement()) {
            try { conn.setReadOnly(true); } catch (Exception ignore) { }
            try { stmt.setQueryTimeout(30); } catch (Exception ignore) { }
            try (ResultSet rs = stmt.executeQuery(guarded)) {
                List<String> out = new ArrayList<>();
                while (rs.next()) {
                    String v = rs.getString(1);
                    out.add(v == null ? "" : v.trim());
                }
                return out;
            }
        } catch (DbQueryException dqe) {
            throw dqe;
        } catch (Exception ex) {
            throw new DbQueryException("Query failed: " + ex.getMessage());
        }
    }
}
