package com.apitest;

import com.apitest.comparator.SimpleXmlWalker;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SimpleXmlWalkerTest {

    // Basic

    @Test
    void plainTag() {
        assertEquals("hello", SimpleXmlWalker.findFirst("<r><a>hello</a></r>", "//a"));
    }

    @Test
    void firstMatchWhenMultiple() {
        assertEquals("one", SimpleXmlWalker.findFirst(
                "<r><a>one</a><a>two</a></r>", "//a"));
    }

    @Test
    void positional() {
        assertEquals("two", SimpleXmlWalker.findFirst(
                "<r><a>one</a><a>two</a><a>three</a></r>", "//a[2]"));
    }

    @Test
    void namespacePrefixIgnored() {
        assertEquals("ok", SimpleXmlWalker.findFirst(
                "<S:Envelope xmlns:S='x'><S:Body><Item>ok</Item></S:Body></S:Envelope>",
                "//Item"));
    }

    // Predicate

    @Test
    void predicateChildEqualsValue() {
        String xml = "<list>"
                + "<item><id>1</id><name>alpha</name></item>"
                + "<item><id>2</id><name>beta</name></item>"
                + "<item><id>3</id><name>gamma</name></item>"
                + "</list>";
        assertEquals("beta", SimpleXmlWalker.findFirst(xml, "//item[id='2']/name"));
        assertEquals("gamma", SimpleXmlWalker.findFirst(xml, "//item[id='3']/name"));
    }

    @Test
    void predicateNestedChildPath() {
        String xml = "<list>"
                + "<item><sec><id>AA</id></sec><cost>100</cost></item>"
                + "<item><sec><id>BB</id></sec><cost>200</cost></item>"
                + "</list>";
        assertEquals("200", SimpleXmlWalker.findFirst(xml, "//item[sec/id='BB']/cost"));
    }

    @Test
    void chainedPathAfterPredicate() {
        String xml = "<root>"
                + "<emp><id>1</id><addr><city>Berlin</city></addr></emp>"
                + "<emp><id>2</id><addr><city>Paris</city></addr></emp>"
                + "</root>";
        assertEquals("Paris", SimpleXmlWalker.findFirst(xml, "//emp[id='2']/addr/city"));
    }

    // SOAP-in-SOAP (the user's actual scenario)

    @Test
    void escapedXmlInsideReturnElement() {
        String xml = "<S:Envelope><S:Body><ns0:executeResponse>"
                + "<return>&lt;Envelope&gt;&lt;Content&gt;"
                + "&lt;LineItem&gt;&lt;Product&gt;&lt;Id&gt;AAA123&lt;/Id&gt;&lt;/Product&gt;"
                + "&lt;Price&gt;249.95&lt;/Price&gt;&lt;/LineItem&gt;"
                + "&lt;LineItem&gt;&lt;Product&gt;&lt;Id&gt;BBB456&lt;/Id&gt;&lt;/Product&gt;"
                + "&lt;Price&gt;500.00&lt;/Price&gt;&lt;/LineItem&gt;"
                + "&lt;/Content&gt;&lt;/Envelope&gt;"
                + "</return></ns0:executeResponse></S:Body></S:Envelope>";

        assertEquals("249.95",
                SimpleXmlWalker.findFirst(xml, "//LineItem[Product/Id='AAA123']/Price"));
        assertEquals("500.00",
                SimpleXmlWalker.findFirst(xml, "//LineItem[Product/Id='BBB456']/Price"));
    }

    // Robustness against malformed input

    @Test
    void strayXmlMidDocumentDoesNotBreakExtraction() {
        // Was producing [Fatal Error] :1:N before
        String xml = "<?xml version='1.0'?><r><a>found</a>"
                + "<?xml version='1.0'?>"  // stray inner PI
                + "<b>also</b></r>";
        assertEquals("found", SimpleXmlWalker.findFirst(xml, "//a"));
        assertEquals("also", SimpleXmlWalker.findFirst(xml, "//b"));
    }

    @Test
    void bomAndLeadingWhitespace() {
        String xml = "\uFEFF\n  <?xml version='1.0'?><r><a>x</a></r>";
        assertEquals("x", SimpleXmlWalker.findFirst(xml, "//a"));
    }

    @Test
    void unclosedTagsStillExtractEarlierContent() {
        // Even when the doc is broken at the end, earlier tags should resolve
        String xml = "<r><a>good</a><b>also good</b><c>broken";
        assertEquals("good", SimpleXmlWalker.findFirst(xml, "//a"));
        assertEquals("also good", SimpleXmlWalker.findFirst(xml, "//b"));
    }

    @Test
    void cdataContent() {
        String xml = "<r><a><![CDATA[hello & world]]></a></r>";
        // Walker should strip CDATA markers and return the content
        String result = SimpleXmlWalker.findFirst(xml, "//a");
        assertTrue(result.contains("hello"), "Got: '" + result + "'");
    }

    @Test
    void selfClosingSiblingsDoNotConfuseSearch() {
        String xml = "<r><skip/><skip/><target>found</target></r>";
        assertEquals("found", SimpleXmlWalker.findFirst(xml, "//target"));
    }

    @Test
    void noMatchReturnsEmpty() {
        String xml = "<r><a>x</a></r>";
        assertEquals("", SimpleXmlWalker.findFirst(xml, "//missing"));
    }

    @Test
    void crlfArtifactsStrippedFromValues() {
        // Server emits &#xd; inside text content - strip from extracted value
        String xml = "<r><a>hello&#xd;</a></r>";
        assertEquals("hello", SimpleXmlWalker.findFirst(xml, "//a"));
    }

    @Test
    void deeplyNestedSameNamedElements() {
        // The closing-tag matcher must respect nesting depth
        String xml = "<a><a><a>inner</a></a></a>";
        // //a should match outermost; its inner text is the nested a's content
        String result = SimpleXmlWalker.findFirst(xml, "//a");
        assertTrue(result.contains("inner"), "Got: '" + result + "'");
    }

    @Test
    void attributeNoiseDoesNotBreakTagMatching() {
        String xml = "<r><tag attr1='x' attr2=\"y z\">value</tag></r>";
        assertEquals("value", SimpleXmlWalker.findFirst(xml, "//tag"));
    }
}
