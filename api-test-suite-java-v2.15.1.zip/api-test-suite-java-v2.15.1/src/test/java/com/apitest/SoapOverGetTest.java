package com.apitest;

import com.apitest.dispatcher.Dispatcher;
import com.apitest.dispatcher.Response;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Verifies request-body and method handling on the wire, in particular the
 * cross-protocol case where one source is a plain REST GET (no body) and the
 * other is a SOAP service invoked over GET that still requires its XML body.
 *
 * <p>Uses a tiny raw-socket server so the exact request line and body the
 * client puts on the wire can be inspected.
 */
class SoapOverGetTest {

    /** Capture of one raw HTTP request. */
    private record Captured(String requestLine, String body) {}

    /** Start a one-shot raw server, run the request, return what it received. */
    private Captured roundTrip(String protocol, String method, String body,
                               Map<String, String> headers) throws Exception {
        try (ServerSocket ss = new ServerSocket(0)) {
            int port = ss.getLocalPort();
            ExecutorService ex = Executors.newSingleThreadExecutor();
            Future<Captured> cap = ex.submit(() -> {
                try (Socket s = ss.accept()) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    String requestLine = in.readLine();
                    String line;
                    int contentLength = 0;
                    while ((line = in.readLine()) != null && !line.isEmpty()) {
                        if (line.toLowerCase().startsWith("content-length:")) {
                            contentLength = Integer.parseInt(line.split(":")[1].trim());
                        }
                    }
                    char[] buf = new char[contentLength];
                    if (contentLength > 0) in.read(buf, 0, contentLength);
                    String resp = "<S:Envelope><Result>OK</Result></S:Envelope>";
                    OutputStream out = s.getOutputStream();
                    out.write(("HTTP/1.1 200 OK\r\nContent-Length: " + resp.length()
                            + "\r\n\r\n" + resp).getBytes());
                    out.flush();
                    return new Captured(requestLine, new String(buf));
                }
            });
            String url = "http://localhost:" + port + "/svc";
            Response r = Dispatcher.send(protocol, "", url, method, body, headers, "none", "", null);
            Captured c = cap.get(5, TimeUnit.SECONDS);
            ex.shutdown();
            assertEquals(200, r.status, "endpoint should have responded 200");
            return c;
        }
    }

    @Test
    void soapOverGetKeepsGetMethodAndSendsBody() throws Exception {
        Map<String, String> h = new HashMap<>();
        h.put("Content-Type", "text/xml");
        String soap = "<S:Envelope><Body><GetBalances><id>1</id></GetBalances></Body></S:Envelope>";
        Captured c = roundTrip("soap", "GET", soap, h);
        assertTrue(c.requestLine().startsWith("GET "),
                "SOAP over an explicit GET must keep GET on the wire: " + c.requestLine());
        assertTrue(c.body().contains("GetBalances"),
                "The SOAP body must be delivered even on GET: " + c.body());
    }

    @Test
    void soapWithNoMethodDefaultsToPost() throws Exception {
        Map<String, String> h = new HashMap<>();
        h.put("Content-Type", "text/xml");
        Captured c = roundTrip("soap", "", "<x/>", h);
        assertTrue(c.requestLine().startsWith("POST "),
                "SOAP with no explicit method should default to POST: " + c.requestLine());
    }

    @Test
    void restGetWithNoBodySendsEmpty() throws Exception {
        Captured c = roundTrip("rest", "GET", "", new HashMap<>());
        assertTrue(c.requestLine().startsWith("GET "), c.requestLine());
        assertEquals("", c.body(), "A GET with no body must send nothing");
    }

    @Test
    void postSendsBody() throws Exception {
        Map<String, String> h = new HashMap<>();
        h.put("Content-Type", "application/json");
        Captured c = roundTrip("rest", "POST", "{\"a\":1}", h);
        assertTrue(c.requestLine().startsWith("POST "), c.requestLine());
        assertTrue(c.body().contains("\"a\":1"), c.body());
    }
}
