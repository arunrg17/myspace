package com.apitest.template;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A workbook may be shared between teams, so a BodyTemplate value must not be
 * able to reach outside the project and pull an unrelated file into a request
 * body. Relative paths are contained; absolute paths remain allowed for
 * templates kept on a shared drive.
 *
 * <p>Lives in the template package because the resolver is package-private.
 */
class TemplatePathContainmentTest {

    @Test
    void templateInsideDirectoryResolves(@TempDir Path root) throws Exception {
        Path templates = Files.createDirectories(root.resolve("templates"));
        Files.writeString(templates.resolve("request.xml"), "<req/>");

        Path resolved = TemplateEngine.resolveTemplatePath("request.xml", templates, root);
        assertTrue(resolved.endsWith("request.xml"));
    }

    @Test
    void nestedTemplateResolves(@TempDir Path root) throws Exception {
        Path templates = Files.createDirectories(root.resolve("templates/soap"));
        Files.writeString(templates.resolve("envelope.xml"), "<env/>");

        Path resolved = TemplateEngine.resolveTemplatePath(
                "soap/envelope.xml", root.resolve("templates"), root);
        assertTrue(resolved.endsWith("envelope.xml"));
    }

    @Test
    void traversalOutsideProjectIsRejected(@TempDir Path root) throws Exception {
        Path templates = Files.createDirectories(root.resolve("templates"));
        Path outside = root.getParent().resolve("outside-" + root.getFileName() + ".txt");
        Files.writeString(outside, "content that must stay unreachable");
        try {
            assertThrows(Exception.class, () -> TemplateEngine.resolveTemplatePath(
                    "../" + outside.getFileName(), templates, root));
        } finally {
            Files.deleteIfExists(outside);
        }
    }

    @Test
    void deepTraversalIsRejected(@TempDir Path root) throws Exception {
        Path templates = Files.createDirectories(root.resolve("templates"));
        assertThrows(Exception.class, () -> TemplateEngine.resolveTemplatePath(
                "../../../../etc/hostname", templates, root));
    }

    @Test
    void absolutePathIsStillAllowed(@TempDir Path root) throws Exception {
        Path shared = Files.writeString(root.resolve("shared.xml"), "<shared/>");
        Path resolved = TemplateEngine.resolveTemplatePath(
                shared.toAbsolutePath().toString(), root.resolve("templates"), root);
        assertEquals(shared.toAbsolutePath(), resolved);
    }

    @Test
    void missingTemplateGivesAClearError(@TempDir Path root) {
        Exception e = assertThrows(Exception.class, () -> TemplateEngine.resolveTemplatePath(
                "does_not_exist.xml", root.resolve("templates"), root));
        assertTrue(e.getMessage().contains("does_not_exist.xml"),
                "The error should name the missing file: " + e.getMessage());
    }
}
