package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.CompareResult;
import com.apitest.model.DiffEntry;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Verifies that XML and JSON payloads with the same logical structure
 * compare as equal, and that real value/structural differences are
 * surfaced even across formats.
 *
 * The comparator normalizes both formats to a common Map representation,
 * so XML &lt;Order&gt;&lt;Id&gt;X100&lt;/Id&gt;&lt;/Order&gt; and
 * JSON {"Order":{"Id":"X100"}} are equivalent.
 */
class XmlVsJsonCrossFormatTest {

    @Test
    void sameStructureMatches() {
        String xml  = "<Order><Id>X100</Id><Status>OK</Status></Order>";
        String json = "{\"Order\":{\"Id\":\"X100\",\"Status\":\"OK\"}}";
        CompareResult r = Comparator.compare(xml, json, List.of());
        assertTrue(r.matched, "Same logical structure should match across XML/JSON");
        assertTrue(r.note.contains("cross-format"), "Note should flag cross-format: " + r.note);
    }

    @Test
    void differentValueDetected() {
        String xml  = "<Order><Id>X100</Id><Status>OK</Status></Order>";
        String json = "{\"Order\":{\"Id\":\"X100\",\"Status\":\"ERROR\"}}";
        CompareResult r = Comparator.compare(xml, json, List.of());
        assertFalse(r.matched);
        assertEquals(1, r.diffs.size());
        DiffEntry d = r.diffs.get(0);
        assertEquals("value", d.kind);
        assertEquals("OK", d.expected);
        assertEquals("ERROR", d.actual);
    }

    @Test
    void missingFieldDetected() {
        String xml  = "<Order><Id>X100</Id><Status>OK</Status></Order>";
        String json = "{\"Order\":{\"Id\":\"X100\"}}";
        CompareResult r = Comparator.compare(xml, json, List.of());
        assertFalse(r.matched);
        boolean hasRemoved = r.diffs.stream().anyMatch(d -> "removed".equals(d.kind));
        assertTrue(hasRemoved, "Should report Status as removed");
    }

    @Test
    void extraFieldDetected() {
        String xml  = "<Order><Id>X100</Id></Order>";
        String json = "{\"Order\":{\"Id\":\"X100\",\"Status\":\"OK\"}}";
        CompareResult r = Comparator.compare(xml, json, List.of());
        assertFalse(r.matched);
        boolean hasAdded = r.diffs.stream().anyMatch(d -> "added".equals(d.kind));
        assertTrue(hasAdded, "Should report Status as added");
    }

    @Test
    void nestedStructureMatches() {
        String xml  = "<Order>"
                + "<Customer><Id>C1</Id><Name>Alice</Name></Customer>"
                + "<Items><Item><Sku>A</Sku></Item><Item><Sku>B</Sku></Item></Items>"
                + "</Order>";
        String json = "{\"Order\":{\"Customer\":{\"Id\":\"C1\",\"Name\":\"Alice\"},"
                + "\"Items\":{\"Item\":[{\"Sku\":\"A\"},{\"Sku\":\"B\"}]}}}";
        CompareResult r = Comparator.compare(xml, json, List.of());
        assertTrue(r.matched, "Nested structure should match: " + r.diffs);
    }
}
