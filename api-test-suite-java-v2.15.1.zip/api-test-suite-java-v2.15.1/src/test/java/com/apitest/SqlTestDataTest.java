package com.apitest;

import com.apitest.comparator.DbQuery;
import com.apitest.model.Environment;
import com.apitest.testdb.FakeDriver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SQL references in the TestData sheet, resolved through the shared DbQuery
 * helper against an environment's database. Covers single and multiple values
 * and the read-only guard.
 */
class SqlTestDataTest {

    private Environment dbEnv() {
        return new Environment("PORTFOLIO_DB", "", "", "", "", java.util.Map.of(),
                "", "", "", java.util.Map.of(),
                "jdbc:fake:mem", "u", "p", "com.apitest.testdb.FakeDriver");
    }

    @BeforeEach
    void seed() throws Exception {
        Class.forName("com.apitest.testdb.FakeDriver");
        FakeDriver.PORTFOLIOS.clear();
        FakeDriver.PORTFOLIOS.put("PF-100", "ACTIVE");
        FakeDriver.PORTFOLIOS.put("PF-101", "ACTIVE");
        FakeDriver.PORTFOLIOS.put("PF-102", "ACTIVE");
    }

    @Test
    void returnsAllMatchingRows() {
        List<String> rows = DbQuery.firstColumn(dbEnv(), "SELECT portfolio_number FROM portfolios");
        assertEquals(3, rows.size());
        assertTrue(rows.contains("PF-100"));
    }

    @Test
    void joinsMultipleValuesForDbRows() {
        List<String> rows = DbQuery.firstColumn(dbEnv(), "SELECT portfolio_number FROM portfolios");
        String joined = rows.size() == 1 ? rows.get(0) : String.join(",", rows);
        assertEquals(3, joined.split(",").length);
    }

    @Test
    void rejectsNonSelect() {
        DbQuery.DbQueryException ex = assertThrows(DbQuery.DbQueryException.class,
                () -> DbQuery.firstColumn(dbEnv(), "UPDATE portfolios SET status='X'"));
        assertTrue(ex.getMessage().toLowerCase().contains("select"));
    }

    @Test
    void rejectsStackedStatements() {
        assertThrows(DbQuery.DbQueryException.class,
                () -> DbQuery.firstColumn(dbEnv(),
                        "SELECT portfolio_number FROM portfolios; DROP TABLE portfolios"));
    }

    @Test
    void reportsMissingDatabase() {
        Environment noDb = new Environment("NOPE", "http://x", "http://x", "", "", java.util.Map.of(),
                "", "", "", java.util.Map.of(), "", "", "", "");
        DbQuery.DbQueryException ex = assertThrows(DbQuery.DbQueryException.class,
                () -> DbQuery.firstColumn(noDb, "SELECT 1"));
        assertTrue(ex.getMessage().toLowerCase().contains("no database"));
    }
}
