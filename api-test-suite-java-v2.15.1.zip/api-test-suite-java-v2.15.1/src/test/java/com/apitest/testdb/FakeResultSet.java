package com.apitest.testdb;
import java.sql.*;
import java.util.List;import java.util.Map;import java.util.Calendar;
import java.io.*;
import java.net.URL;
import java.math.BigDecimal;
import java.util.Calendar;

public class FakeResultSet implements ResultSet {
  private final List<String[]> rows;
  private int idx = -1;
  public FakeResultSet(List<String[]> rows){ this.rows = rows; }
  public boolean next(){ idx++; return idx < rows.size(); }
  public String getString(int col){ return rows.get(idx)[col-1]; }
  public String getString(String c){ return rows.get(idx)[0]; }
  public void close(){}
  public boolean wasNull(){ return false; }
  // minimal getObject
  public Object getObject(int col){ return rows.get(idx)[col-1]; }
  public int getInt(int col){ return Integer.parseInt(rows.get(idx)[col-1]); }
  // --- everything else stubbed ---
  public boolean getBoolean(int c){ return false; } public byte getByte(int c){ return 0; }
  public short getShort(int c){ return 0; } public long getLong(int c){ return 0; }
  public float getFloat(int c){ return 0; } public double getDouble(int c){ return 0; }
  public BigDecimal getBigDecimal(int c,int s){ return null; } public byte[] getBytes(int c){ return null; }
  public Date getDate(int c){ return null; } public Time getTime(int c){ return null; }
  public Timestamp getTimestamp(int c){ return null; } public InputStream getAsciiStream(int c){ return null; }
  public InputStream getUnicodeStream(int c){ return null; } public InputStream getBinaryStream(int c){ return null; }
  public boolean getBoolean(String c){ return false; } public byte getByte(String c){ return 0; }
  public short getShort(String c){ return 0; } public int getInt(String c){ return 0; }
  public long getLong(String c){ return 0; } public float getFloat(String c){ return 0; }
  public double getDouble(String c){ return 0; } public BigDecimal getBigDecimal(String c,int s){ return null; }
  public byte[] getBytes(String c){ return null; } public Date getDate(String c){ return null; }
  public Time getTime(String c){ return null; } public Timestamp getTimestamp(String c){ return null; }
  public InputStream getAsciiStream(String c){ return null; } public InputStream getUnicodeStream(String c){ return null; }
  public InputStream getBinaryStream(String c){ return null; }
  public SQLWarning getWarnings(){ return null; } public void clearWarnings(){}
  public String getCursorName(){ return null; } public ResultSetMetaData getMetaData(){ return null; }
  public Object getObject(String c){ return null; } public int findColumn(String c){ return 1; }
  public Reader getCharacterStream(int c){ return null; } public Reader getCharacterStream(String c){ return null; }
  public BigDecimal getBigDecimal(int c){ return null; } public BigDecimal getBigDecimal(String c){ return null; }
  public boolean isBeforeFirst(){ return idx < 0; } public boolean isAfterLast(){ return idx >= rows.size(); }
  public boolean isFirst(){ return idx == 0; } public boolean isLast(){ return idx == rows.size()-1; }
  public void beforeFirst(){} public void afterLast(){} public boolean first(){ return false; }
  public boolean last(){ return false; } public int getRow(){ return idx+1; }
  public boolean absolute(int r){ return false; } public boolean relative(int r){ return false; }
  public boolean previous(){ return false; }
  public void setFetchDirection(int d){} public int getFetchDirection(){ return 0; }
  public void setFetchSize(int r){} public int getFetchSize(){ return 0; }
  public int getType(){ return 0; } public int getConcurrency(){ return 0; }
  public boolean rowUpdated(){ return false; } public boolean rowInserted(){ return false; }
  public boolean rowDeleted(){ return false; }
  public void updateNull(int c){} public void updateBoolean(int c,boolean x){} public void updateByte(int c,byte x){}
  public void updateShort(int c,short x){} public void updateInt(int c,int x){} public void updateLong(int c,long x){}
  public void updateFloat(int c,float x){} public void updateDouble(int c,double x){} public void updateBigDecimal(int c,BigDecimal x){}
  public void updateString(int c,String x){} public void updateBytes(int c,byte[] x){} public void updateDate(int c,Date x){}
  public void updateTime(int c,Time x){} public void updateTimestamp(int c,Timestamp x){}
  public void updateAsciiStream(int c,InputStream x,int l){} public void updateBinaryStream(int c,InputStream x,int l){}
  public void updateCharacterStream(int c,Reader x,int l){} public void updateObject(int c,Object x,int s){}
  public void updateObject(int c,Object x){}
  public void updateNull(String c){} public void updateBoolean(String c,boolean x){} public void updateByte(String c,byte x){}
  public void updateShort(String c,short x){} public void updateInt(String c,int x){} public void updateLong(String c,long x){}
  public void updateFloat(String c,float x){} public void updateDouble(String c,double x){} public void updateBigDecimal(String c,BigDecimal x){}
  public void updateString(String c,String x){} public void updateBytes(String c,byte[] x){} public void updateDate(String c,Date x){}
  public void updateTime(String c,Time x){} public void updateTimestamp(String c,Timestamp x){}
  public void updateAsciiStream(String c,InputStream x,int l){} public void updateBinaryStream(String c,InputStream x,int l){}
  public void updateCharacterStream(String c,Reader x,int l){} public void updateObject(String c,Object x,int s){}
  public void updateObject(String c,Object x){}
  public void insertRow(){} public void updateRow(){} public void deleteRow(){} public void refreshRow(){}
  public void cancelRowUpdates(){} public void moveToInsertRow(){} public void moveToCurrentRow(){}
  public Statement getStatement(){ return null; }
  public Object getObject(int c,Map<String,Class<?>> m){ return null; } public Ref getRef(int c){ return null; }
  public Blob getBlob(int c){ return null; } public Clob getClob(int c){ return null; } public Array getArray(int c){ return null; }
  public Object getObject(String c,Map<String,Class<?>> m){ return null; } public Ref getRef(String c){ return null; }
  public Blob getBlob(String c){ return null; } public Clob getClob(String c){ return null; } public Array getArray(String c){ return null; }
  public Date getDate(int c,Calendar cal){ return null; } public Date getDate(String c,Calendar cal){ return null; }
  public Time getTime(int c,Calendar cal){ return null; } public Time getTime(String c,Calendar cal){ return null; }
  public Timestamp getTimestamp(int c,Calendar cal){ return null; } public Timestamp getTimestamp(String c,Calendar cal){ return null; }
  public URL getURL(int c){ return null; } public URL getURL(String c){ return null; }
  public void updateRef(int c,Ref x){} public void updateRef(String c,Ref x){}
  public void updateBlob(int c,Blob x){} public void updateBlob(String c,Blob x){}
  public void updateClob(int c,Clob x){} public void updateClob(String c,Clob x){}
  public void updateArray(int c,Array x){} public void updateArray(String c,Array x){}
  public RowId getRowId(int c){ return null; } public RowId getRowId(String c){ return null; }
  public void updateRowId(int c,RowId x){} public void updateRowId(String c,RowId x){}
  public int getHoldability(){ return 0; } public boolean isClosed(){ return false; }
  public void updateNString(int c,String x){} public void updateNString(String c,String x){}
  public void updateNClob(int c,NClob x){} public void updateNClob(String c,NClob x){}
  public NClob getNClob(int c){ return null; } public NClob getNClob(String c){ return null; }
  public SQLXML getSQLXML(int c){ return null; } public SQLXML getSQLXML(String c){ return null; }
  public void updateSQLXML(int c,SQLXML x){} public void updateSQLXML(String c,SQLXML x){}
  public String getNString(int c){ return null; } public String getNString(String c){ return null; }
  public Reader getNCharacterStream(int c){ return null; } public Reader getNCharacterStream(String c){ return null; }
  public void updateNCharacterStream(int c,Reader x,long l){} public void updateNCharacterStream(String c,Reader x,long l){}
  public void updateAsciiStream(int c,InputStream x,long l){} public void updateBinaryStream(int c,InputStream x,long l){}
  public void updateCharacterStream(int c,Reader x,long l){} public void updateAsciiStream(String c,InputStream x,long l){}
  public void updateBinaryStream(String c,InputStream x,long l){} public void updateCharacterStream(String c,Reader x,long l){}
  public void updateBlob(int c,InputStream x,long l){} public void updateBlob(String c,InputStream x,long l){}
  public void updateClob(int c,Reader x,long l){} public void updateClob(String c,Reader x,long l){}
  public void updateNClob(int c,Reader x,long l){} public void updateNClob(String c,Reader x,long l){}
  public void updateNCharacterStream(int c,Reader x){} public void updateNCharacterStream(String c,Reader x){}
  public void updateAsciiStream(int c,InputStream x){} public void updateBinaryStream(int c,InputStream x){}
  public void updateCharacterStream(int c,Reader x){} public void updateAsciiStream(String c,InputStream x){}
  public void updateBinaryStream(String c,InputStream x){} public void updateCharacterStream(String c,Reader x){}
  public void updateBlob(int c,InputStream x){} public void updateBlob(String c,InputStream x){}
  public void updateClob(int c,Reader x){} public void updateClob(String c,Reader x){}
  public void updateNClob(int c,Reader x){} public void updateNClob(String c,Reader x){}
  public <T> T getObject(int c,Class<T> t){ return null; } public <T> T getObject(String c,Class<T> t){ return null; }
  public <T> T unwrap(Class<T> i){ return null; } public boolean isWrapperFor(Class<?> i){ return false; }
}
