package com.apitest.testdb;
import java.sql.*;
import java.util.*;
import java.util.concurrent.Executor;

public class FakeConnection implements Connection {
  private boolean readOnly = false;
  public Statement createStatement() { return new FakeStatement(); }
  public void setReadOnly(boolean ro) { this.readOnly = ro; }
  public boolean isReadOnly() { return readOnly; }
  public void close() {}
  public boolean isClosed() { return false; }
  // --- everything else unsupported / no-op ---
  public PreparedStatement prepareStatement(String s){ throw new UnsupportedOperationException(); }
  public CallableStatement prepareCall(String s){ throw new UnsupportedOperationException(); }
  public String nativeSQL(String s){ return s; }
  public void setAutoCommit(boolean b){} public boolean getAutoCommit(){ return true; }
  public void commit(){} public void rollback(){}
  public DatabaseMetaData getMetaData(){ return null; }
  public void setCatalog(String c){} public String getCatalog(){ return null; }
  public void setTransactionIsolation(int l){} public int getTransactionIsolation(){ return 0; }
  public SQLWarning getWarnings(){ return null; } public void clearWarnings(){}
  public Statement createStatement(int a,int b){ return new FakeStatement(); }
  public PreparedStatement prepareStatement(String s,int a,int b){ throw new UnsupportedOperationException(); }
  public CallableStatement prepareCall(String s,int a,int b){ throw new UnsupportedOperationException(); }
  public Map<String,Class<?>> getTypeMap(){ return null; } public void setTypeMap(Map<String,Class<?>> m){}
  public void setHoldability(int h){} public int getHoldability(){ return 0; }
  public Savepoint setSavepoint(){ return null; } public Savepoint setSavepoint(String n){ return null; }
  public void rollback(Savepoint s){} public void releaseSavepoint(Savepoint s){}
  public Statement createStatement(int a,int b,int c){ return new FakeStatement(); }
  public PreparedStatement prepareStatement(String s,int a,int b,int c){ throw new UnsupportedOperationException(); }
  public CallableStatement prepareCall(String s,int a,int b,int c){ throw new UnsupportedOperationException(); }
  public PreparedStatement prepareStatement(String s,int a){ throw new UnsupportedOperationException(); }
  public PreparedStatement prepareStatement(String s,int[] a){ throw new UnsupportedOperationException(); }
  public PreparedStatement prepareStatement(String s,String[] a){ throw new UnsupportedOperationException(); }
  public Clob createClob(){ return null; } public Blob createBlob(){ return null; }
  public NClob createNClob(){ return null; } public SQLXML createSQLXML(){ return null; }
  public boolean isValid(int t){ return true; }
  public void setClientInfo(String n,String v){} public void setClientInfo(Properties p){}
  public String getClientInfo(String n){ return null; } public Properties getClientInfo(){ return null; }
  public Array createArrayOf(String t,Object[] e){ return null; }
  public Struct createStruct(String t,Object[] a){ return null; }
  public void setSchema(String s){} public String getSchema(){ return null; }
  public void abort(Executor e){} public void setNetworkTimeout(Executor e,int m){}
  public int getNetworkTimeout(){ return 0; }
  public <T> T unwrap(Class<T> i){ return null; } public boolean isWrapperFor(Class<?> i){ return false; }
}
