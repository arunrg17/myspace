package com.apitest.testdb;
import java.sql.*;
import java.util.*;

public class FakeStatement implements Statement {
  private int timeout = 0;
  public ResultSet executeQuery(String sql) {
    String s = sql.toLowerCase(Locale.ROOT);
    List<String[]> rows = new ArrayList<>();  // each row: one string column

    // COUNT(*) query -> single row with the count
    if (s.contains("count(")) {
      int count = 0;
      for (var e : FakeDriver.PORTFOLIOS.entrySet()) {
        if (matchesWhere(s, e.getKey(), e.getValue())) count++;
      }
      rows.add(new String[]{ String.valueOf(count) });
      return new FakeResultSet(rows);
    }
    // status query -> return status of the matching portfolio
    if (s.contains("select status")) {
      for (var e : FakeDriver.PORTFOLIOS.entrySet()) {
        if (matchesWhere(s, e.getKey(), e.getValue())) rows.add(new String[]{ e.getValue() });
      }
      return new FakeResultSet(rows);
    }
    // default: select portfolio_number -> return matching keys (possibly many)
    for (var e : FakeDriver.PORTFOLIOS.entrySet()) {
      if (matchesWhere(s, e.getKey(), e.getValue())) rows.add(new String[]{ e.getKey() });
    }
    return new FakeResultSet(rows);
  }

  // Very small WHERE matcher: if the SQL mentions a specific portfolio number
  // literal, only that row matches; if it mentions a customer filter, all rows
  // match (the test seeds only that customer's rows).
  private boolean matchesWhere(String sql, String pnum, String status) {
    // find a quoted literal
    int q1 = sql.indexOf('\'');
    if (q1 >= 0) {
      int q2 = sql.indexOf('\'', q1 + 1);
      if (q2 > q1) {
        String literal = sql.substring(q1 + 1, q2);
        // customer filter (cust...) -> match all seeded rows
        if (sql.contains("customer") || sql.contains("cust_id") || sql.contains("cust")) return true;
        // otherwise it's a portfolio_number filter -> exact match
        return pnum.equalsIgnoreCase(literal);
      }
    }
    return true; // no filter -> all rows
  }

  public void setQueryTimeout(int s){ this.timeout = s; }
  public int getQueryTimeout(){ return timeout; }
  public void close(){} public void cancel(){}
  // --- unsupported / no-op ---
  public int executeUpdate(String s){ return 0; }
  public int getMaxFieldSize(){ return 0; } public void setMaxFieldSize(int m){}
  public int getMaxRows(){ return 0; } public void setMaxRows(int m){}
  public void setEscapeProcessing(boolean b){}
  public SQLWarning getWarnings(){ return null; } public void clearWarnings(){}
  public void setCursorName(String n){}
  public boolean execute(String s){ return false; }
  public ResultSet getResultSet(){ return null; } public int getUpdateCount(){ return -1; }
  public boolean getMoreResults(){ return false; }
  public void setFetchDirection(int d){} public int getFetchDirection(){ return 0; }
  public void setFetchSize(int r){} public int getFetchSize(){ return 0; }
  public int getResultSetConcurrency(){ return 0; } public int getResultSetType(){ return 0; }
  public void addBatch(String s){} public void clearBatch(){} public int[] executeBatch(){ return new int[0]; }
  public Connection getConnection(){ return null; }
  public boolean getMoreResults(int c){ return false; }
  public ResultSet getGeneratedKeys(){ return null; }
  public int executeUpdate(String s,int a){ return 0; }
  public int executeUpdate(String s,int[] a){ return 0; }
  public int executeUpdate(String s,String[] a){ return 0; }
  public boolean execute(String s,int a){ return false; }
  public boolean execute(String s,int[] a){ return false; }
  public boolean execute(String s,String[] a){ return false; }
  public int getResultSetHoldability(){ return 0; }
  public boolean isClosed(){ return false; }
  public void setPoolable(boolean b){} public boolean isPoolable(){ return false; }
  public void closeOnCompletion(){} public boolean isCloseOnCompletion(){ return false; }
  public <T> T unwrap(Class<T> i){ return null; } public boolean isWrapperFor(Class<?> i){ return false; }
}
