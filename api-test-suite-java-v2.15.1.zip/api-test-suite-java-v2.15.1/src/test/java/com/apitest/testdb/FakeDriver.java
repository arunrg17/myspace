package com.apitest.testdb;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

/**
 * Minimal in-memory JDBC driver for testing DB assertions. Holds a table of
 * portfolios keyed by a static map. SQL is matched by simple substring rules -
 * enough to exercise db_equals / db_exists / db_rows without a real database.
 */
public class FakeDriver implements Driver {
  // portfolio_number -> {status}
  public static final Map<String,String> PORTFOLIOS = new LinkedHashMap<>();
  static { try { DriverManager.registerDriver(new FakeDriver()); } catch(Exception e){} }

  public boolean acceptsURL(String url){ return url != null && url.startsWith("jdbc:fake:"); }
  public Connection connect(String url, Properties info) throws SQLException {
    if (!acceptsURL(url)) return null;
    return new FakeConnection();
  }
  public int getMajorVersion(){ return 1; }
  public int getMinorVersion(){ return 0; }
  public boolean jdbcCompliant(){ return false; }
  public DriverPropertyInfo[] getPropertyInfo(String u, Properties p){ return new DriverPropertyInfo[0]; }
  public Logger getParentLogger(){ return null; }
}
