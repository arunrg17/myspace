package com.apitest;

import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test the ExtraHeaders parsing logic - both newline-delimited and
 * semicolon-delimited formats should work.
 */
class ExtraHeadersParsingTest {

    /**
     * Invoke the private parseHeaders method via reflection.
     */
    @SuppressWarnings("unchecked")
    private Map<String, String> parseHeaders(String raw) throws Exception {
        Class<?> cls = Class.forName("com.apitest.excel.ExcelLoader");
        Method m = cls.getDeclaredMethod("parseHeaders", String.class);
        m.setAccessible(true);
        return (Map<String, String>) m.invoke(null, raw);
    }

    @Test
    void newlineDelimited() throws Exception {
        String input = "Authorization: Bearer xyz\nX-Custom-Header: value123";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(2, headers.size());
        assertEquals("Bearer xyz", headers.get("Authorization"));
        assertEquals("value123", headers.get("X-Custom-Header"));
    }

    @Test
    void semicolonDelimited() throws Exception {
        String input = "Authorization: Bearer xyz; X-Custom-Header: value123";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(2, headers.size());
        assertEquals("Bearer xyz", headers.get("Authorization"));
        assertEquals("value123", headers.get("X-Custom-Header"));
    }

    @Test
    void mixedFormat() throws Exception {
        String input = "Authorization: Bearer xyz; X-Custom: val1\nContent-Type: application/json";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(3, headers.size());
        assertEquals("Bearer xyz", headers.get("Authorization"));
        assertEquals("val1", headers.get("X-Custom"));
        assertEquals("application/json", headers.get("Content-Type"));
    }

    @Test
    void trailingSpaces() throws Exception {
        String input = "Authorization:  Bearer xyz  ;  X-Custom:  value123  ";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(2, headers.size());
        assertEquals("Bearer xyz", headers.get("Authorization"));
        assertEquals("value123", headers.get("X-Custom"));
    }

    @Test
    void emptyInput() throws Exception {
        Map<String, String> headers = parseHeaders("");
        assertTrue(headers.isEmpty());
        headers = parseHeaders(null);
        assertTrue(headers.isEmpty());
    }

    @Test
    void headerValueWithColon() throws Exception {
        // Bearer token might have colons in the value
        String input = "Authorization: Bearer eyJhbGc:iOiJIUzI1:NiIsInR5cCI6Ikp";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(1, headers.size());
        // Only the FIRST colon is the delimiter
        assertEquals("Bearer eyJhbGc:iOiJIUzI1:NiIsInR5cCI6Ikp", headers.get("Authorization"));
    }
}
