package com.apitest;

import com.apitest.template.TemplateEngine;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A blank TestData cell should leave its field out of a JSON request rather
 * than send an empty value the server rejects. This is the JSON counterpart to
 * the empty-element pruning XML templates already get, and every result here
 * must still parse as JSON.
 */
class JsonEmptyFieldPruningTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private String render(String template, Map<String, String> data) {
        return TemplateEngine.render(template, data, new LinkedHashMap<>());
    }

    private void assertValidJson(String s) {
        try {
            MAPPER.readTree(s);
        } catch (Exception ex) {
            fail("Not valid JSON: " + s + " (" + ex.getMessage() + ")");
        }
    }

    @Test
    void dropsMissingMemberInTheMiddle() {
        Map<String, String> d = new HashMap<>();
        d.put("orderId", "ORD-1");
        d.put("qty", "5");
        String out = render("{ \"orderId\": \"${orderId}\", \"amount\": \"${amount}\", \"qty\": ${qty} }", d);
        assertValidJson(out);
        assertTrue(out.contains("ORD-1"));
        assertFalse(out.contains("amount"));
    }

    @Test
    void dropsMissingMemberAtTheEnd() {
        Map<String, String> d = new HashMap<>();
        d.put("orderId", "ORD-1");
        String out = render("{ \"orderId\": \"${orderId}\", \"amount\": \"${amount}\" }", d);
        assertValidJson(out);
        assertFalse(out.contains("amount"));
    }

    @Test
    void dropsMissingNumericMember() {
        Map<String, String> d = new HashMap<>();
        d.put("orderId", "ORD-1");
        String out = render("{ \"orderId\": \"${orderId}\", \"score\": ${score} }", d);
        assertValidJson(out);
        assertFalse(out.contains("score"));
    }

    @Test
    void dropsMissingArrayElement() {
        Map<String, String> d = new HashMap<>();
        d.put("a", "one");
        String out = render("{ \"tags\": [ \"${a}\", \"${b}\", \"z\" ] }", d);
        assertValidJson(out);
        assertTrue(out.contains("one"));
        assertTrue(out.contains("z"));
    }

    @Test
    void dropsMissingMemberInNestedObject() {
        Map<String, String> d = new HashMap<>();
        d.put("a", "one");
        d.put("c", "3");
        String out = render("{ \"o\": { \"a\": \"${a}\", \"b\": \"${b}\" }, \"c\": ${c} }", d);
        assertValidJson(out);
        assertFalse(out.contains("\"b\""));
    }

    @Test
    void leavesFullyResolvedJsonUnchanged() {
        Map<String, String> d = new HashMap<>();
        d.put("orderId", "ORD-1");
        d.put("qty", "5");
        String out = render("{ \"orderId\": \"${orderId}\", \"qty\": ${qty} }", d);
        assertValidJson(out);
        assertTrue(out.contains("ORD-1"));
        assertTrue(out.contains("5"));
    }
}
