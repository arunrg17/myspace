package com.apitest;

import com.apitest.comparator.Comparator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Reproduces a tricky real-world SOAP response shape:
 *   - <?xml ... ?> prolog with single quotes
 *   - <S:Envelope> wrapping a business <Envelope> with the same local name
 *   - Literal &#xd; entity refs after every closing tag
 *   - Repeated line items that need predicate-based lookup
 *
 * Also verifies that stderr noise from the parser doesn't pollute the console.
 */
class SoapResponseWithCrlfArtifactsTest {

    private static final String RESPONSE =
            "<?xml version='1.0' encoding='UTF-8'?>"
            + "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">"
            + "<S:Body>"
            + "<Envelope>&#xd;\n"
            + "  <Version>354</Version>&#xd;\n"
            + "  <Sender>&#xd;\n"
            + "    <AppId>ClientApp</AppId>&#xd;\n"
            + "  </Sender>&#xd;\n"
            + "  <Receiver>&#xd;\n"
            + "    <AppId>ServerApp</AppId>&#xd;\n"
            + "  </Receiver>&#xd;\n"
            + "  <Content>&#xd;\n"
            + "    <LineItem>&#xd;\n"
            + "      <Product>&#xd;\n"
            + "        <Id>AAA123</Id>&#xd;\n"
            + "        <Name>Product One</Name>&#xd;\n"
            + "      </Product>&#xd;\n"
            + "      <Price>249.95</Price>&#xd;\n"
            + "      <Currency>EUR</Currency>&#xd;\n"
            + "    </LineItem>&#xd;\n"
            + "    <LineItem>&#xd;\n"
            + "      <Product>&#xd;\n"
            + "        <Id>BBB456</Id>&#xd;\n"
            + "        <Name>Product Two</Name>&#xd;\n"
            + "      </Product>&#xd;\n"
            + "      <Price>500.00</Price>&#xd;\n"
            + "      <Currency>USD</Currency>&#xd;\n"
            + "    </LineItem>&#xd;\n"
            + "    <LineItem>&#xd;\n"
            + "      <Product>&#xd;\n"
            + "        <Id>CCC789</Id>&#xd;\n"
            + "        <Name>Product Three</Name>&#xd;\n"
            + "      </Product>&#xd;\n"
            + "      <Price>123.45</Price>&#xd;\n"
            + "      <Currency>GBP</Currency>&#xd;\n"
            + "    </LineItem>&#xd;\n"
            + "  </Content>&#xd;\n"
            + "</Envelope>&#xd;\n"
            + "</S:Body></S:Envelope>";

    @Test
    void findLineItemByNestedId() {
        String price = Comparator.extractVariable(RESPONSE,
                "//LineItem[Product/Id='AAA123']/Price");
        assertEquals("249.95", price);
    }

    @Test
    void findSiblingCurrency() {
        String currency = Comparator.extractVariable(RESPONSE,
                "//LineItem[Product/Id='BBB456']/Currency");
        assertEquals("USD", currency);
    }

    @Test
    void findNestedProductName() {
        String name = Comparator.extractVariable(RESPONSE,
                "//LineItem[Product/Id='CCC789']/Product/Name");
        assertEquals("Product Three", name);
    }

    @Test
    void noMatchReturnsEmpty() {
        String missing = Comparator.extractVariable(RESPONSE,
                "//LineItem[Product/Id='ZZZ999']/Price");
        assertEquals("", missing);
    }

    @Test
    void parseDoesNotWriteToStderr() throws Exception {
        java.io.ByteArrayOutputStream errBuf = new java.io.ByteArrayOutputStream();
        java.io.PrintStream original = System.err;
        try {
            System.setErr(new java.io.PrintStream(errBuf));
            String malformed = "<?xml version=\"1.0\"?><r><a>1</a></r>"
                    + "<?xml version=\"1.0\"?><b>2</b>";
            Comparator.extractVariable(malformed, "//a");
        } finally {
            System.setErr(original);
        }
        String stderr = errBuf.toString();
        assertFalse(stderr.contains("[Fatal Error]"),
                "Parser should not write to stderr during parse recovery. Got: " + stderr);
    }

    @Test
    void noVisibleCrlfArtifactsInExtractedValues() {
        String version = Comparator.extractVariable(RESPONSE, "//Version");
        assertEquals("354", version);
        assertFalse(version.contains("&#xd"));
        assertFalse(version.contains("\r"));
    }
}
