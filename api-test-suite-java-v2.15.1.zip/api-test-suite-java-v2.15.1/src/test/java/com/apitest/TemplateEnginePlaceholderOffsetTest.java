package com.apitest;

import com.apitest.template.TemplateEngine;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A placeholder may carry a trailing whole-number offset, e.g.
 * {@code ${step1.orderId + 1}}, for the case of taking a number out of one
 * response and sending the next value on the following request.
 *
 * <p>Whitespace around the operator is required, which is what keeps an
 * ordinary hyphenated name from being mistaken for subtraction.
 */
class TemplateEnginePlaceholderOffsetTest {

    private static Map<String, String> data(String... kv) {
        Map<String, String> m = new HashMap<>();
        for (int i = 0; i < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return m;
    }

    private static Map<Integer, Map<String, String>> stepVars(int step, String key, String value) {
        Map<Integer, Map<String, String>> outer = new LinkedHashMap<>();
        Map<String, String> inner = new HashMap<>();
        inner.put(key, value);
        outer.put(step, inner);
        return outer;
    }

    // the value the user actually asked about

    @Test
    @DisplayName("Large extracted number is incremented, not string-concatenated")
    void incrementsLargeExtractedNumber() {
        Map<Integer, Map<String, String>> vars = stepVars(1, "seq", "234234233");
        String out = TemplateEngine.render("${step1.seq + 1}", new HashMap<>(), vars);
        assertEquals("234234234", out);
    }

    // basic arithmetic

    @Test
    void addsToStepVariable() {
        Map<Integer, Map<String, String>> vars = stepVars(1, "orderId", "100");
        assertEquals("/orders/101",
                TemplateEngine.render("/orders/${step1.orderId + 1}", new HashMap<>(), vars));
    }

    @Test
    void subtractsFromStepVariable() {
        Map<Integer, Map<String, String>> vars = stepVars(2, "id", "500");
        assertEquals("499",
                TemplateEngine.render("${step2.id - 1}", new HashMap<>(), vars));
    }

    @Test
    void addsLargerOffset() {
        Map<Integer, Map<String, String>> vars = stepVars(1, "n", "10");
        assertEquals("110",
                TemplateEngine.render("${step1.n + 100}", new HashMap<>(), vars));
    }

    @Test
    void worksOnTestDataColumn() {
        assertEquals("43",
                TemplateEngine.render("${counter + 1}", data("counter", "42"), Map.of()));
    }

    @Test
    void appliesToMandatoryPlaceholder() {
        Map<Integer, Map<String, String>> vars = stepVars(1, "seq", "7");
        assertEquals("8",
                TemplateEngine.render("${!step1.seq + 1}", new HashMap<>(), vars));
    }

    @Test
    void offsetCanBeNegativeResult() {
        assertEquals("-1",
                TemplateEngine.render("${n - 5}", data("n", "4"), Map.of()));
    }

    // error handling

    @Test
    @DisplayName("Non-numeric value with an offset fails with a clear message")
    void nonNumericValueFails() {
        Map<Integer, Map<String, String>> vars = stepVars(1, "orderId", "ORD-42");
        IllegalStateException ex = assertThrows(IllegalStateException.class, () ->
                TemplateEngine.render("${step1.orderId + 1}", new HashMap<>(), vars));
        assertTrue(ex.getMessage().contains("not a whole number"), ex.getMessage());
        assertTrue(ex.getMessage().contains("ORD-42"), ex.getMessage());
    }

    // the tokens that must be left completely alone

    @Test
    @DisplayName("A hyphenated name with a trailing number is not treated as subtraction")
    void hyphenatedNameIsNotArithmetic() {
        String out = TemplateEngine.render("${order-2024}",
                data("order-2024", "present"), Map.of());
        assertEquals("present", out);
    }

    @Test
    @DisplayName("No spaces around the operator means it is a plain token, not arithmetic")
    void noSpacesIsNotArithmetic() {
        // Treated as an ordinary (here missing) variable, so it drops to empty
        // rather than doing arithmetic.
        String out = TemplateEngine.render("x${seq+1}y", new HashMap<>(), Map.of());
        assertEquals("xy", out);
    }

    @Test
    void plainPlaceholderStillWorks() {
        Map<Integer, Map<String, String>> vars = stepVars(1, "orderId", "100");
        assertEquals("/orders/100",
                TemplateEngine.render("/orders/${step1.orderId}", new HashMap<>(), vars));
    }

    @Test
    void offsetIsIgnorableWhitespaceInsensitiveOnBrace() {
        // The engine trims inside the braces already; confirm the offset still
        // parses when the whole token has outer padding.
        Map<Integer, Map<String, String>> vars = stepVars(1, "seq", "9");
        assertEquals("10",
                TemplateEngine.render("${ step1.seq + 1 }", new HashMap<>(), vars));
    }
}
