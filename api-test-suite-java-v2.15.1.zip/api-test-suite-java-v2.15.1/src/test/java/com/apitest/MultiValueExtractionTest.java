package com.apitest;

import com.apitest.comparator.Comparator;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A path that matches several values must return all of them, not just the
 * first. This is what lets a step capture, say, every id in a list and hand the
 * whole set to a db_rows assertion.
 */
class MultiValueExtractionTest {

    private static final String JSON = "{"
            + "\"kacClass\":[{\"id\":\"OBB\",\"investmentObjective\":[{"
            + "\"performanceFigures\":["
            + "{\"id\":\"PF_1\"},{\"id\":\"PF_10\"},{\"id\":\"PF_2\"},{\"id\":\"PF_3\"}"
            + "]}]}]}";

    @Test
    void extractsEveryMatchingId() {
        List<String> ids = Comparator.extractAllVariables(JSON, "$..performanceFigures[*].id");
        assertEquals(List.of("PF_1", "PF_10", "PF_2", "PF_3"), ids);
    }

    @Test
    void fullyQualifiedPathReturnsSameSet() {
        List<String> ids = Comparator.extractAllVariables(
                JSON, "$.kacClass[*].investmentObjective[*].performanceFigures[*].id");
        assertEquals(4, ids.size());
    }

    @Test
    void singleMatchReturnsOneElement() {
        List<String> one = Comparator.extractAllVariables(JSON, "$.kacClass[0].id");
        assertEquals(List.of("OBB"), one);
    }

    @Test
    void noMatchReturnsEmpty() {
        List<String> none = Comparator.extractAllVariables(JSON, "$..nonexistent");
        assertTrue(none.isEmpty());
    }

    @Test
    void joinedResultIsAcommaSeparatedSetForDbRows() {
        List<String> ids = Comparator.extractAllVariables(JSON, "$..performanceFigures[*].id");
        String joined = ids.size() == 1 ? ids.get(0) : String.join(",", ids);
        assertEquals("PF_1,PF_10,PF_2,PF_3", joined);
    }
}
