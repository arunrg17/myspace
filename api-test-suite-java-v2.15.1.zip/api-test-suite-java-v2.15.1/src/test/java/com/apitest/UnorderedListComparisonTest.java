package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests that repeated child elements / array items compare correctly even
 * when the two systems return them in a different order. The comparison must
 * still flag genuine value differences and true surplus/shortfall.
 */
class UnorderedListComparisonTest {

    @Test
    void reorderedJsonObjectsMatch() {
        CompareResult r = Comparator.compare(
                "{\"items\":[{\"id\":\"A\"},{\"id\":\"B\"},{\"id\":\"C\"}]}",
                "{\"items\":[{\"id\":\"C\"},{\"id\":\"A\"},{\"id\":\"B\"}]}",
                List.of());
        assertTrue(r.matched, "Same objects in a different order should match: " + r.diffs);
    }

    @Test
    void reorderedXmlElementsMatch() {
        CompareResult r = Comparator.compare(
                "<o><item><id>A</id></item><item><id>B</id></item></o>",
                "<o><item><id>B</id></item><item><id>A</id></item></o>",
                List.of());
        assertTrue(r.matched, "Same XML elements in a different order should match: " + r.diffs);
    }

    @Test
    void reorderedScalarsMatch() {
        CompareResult r = Comparator.compare(
                "{\"tags\":[\"x\",\"y\",\"z\"]}",
                "{\"tags\":[\"z\",\"y\",\"x\"]}",
                List.of());
        assertTrue(r.matched, "Same scalars in a different order should match: " + r.diffs);
    }

    @Test
    void orderedListsStillMatch() {
        CompareResult r = Comparator.compare(
                "{\"items\":[{\"id\":\"A\"},{\"id\":\"B\"}]}",
                "{\"items\":[{\"id\":\"A\"},{\"id\":\"B\"}]}",
                List.of());
        assertTrue(r.matched, "Identical ordered lists must still match");
    }

    @Test
    void genuineValueDifferenceStillReported() {
        CompareResult r = Comparator.compare(
                "{\"items\":[{\"id\":\"A\"},{\"id\":\"B\"}]}",
                "{\"items\":[{\"id\":\"A\"},{\"id\":\"X\"}]}",
                List.of());
        assertFalse(r.matched, "A changed value must still be reported");
        assertTrue(r.diffs.stream().anyMatch(d -> "value".equals(d.kind)),
                "Should report a value diff");
    }

    @Test
    void extraElementReported() {
        CompareResult r = Comparator.compare(
                "{\"items\":[{\"id\":\"A\"}]}",
                "{\"items\":[{\"id\":\"A\"},{\"id\":\"B\"}]}",
                List.of());
        assertFalse(r.matched);
        assertTrue(r.diffs.stream().anyMatch(d -> "added".equals(d.kind)),
                "Extra element on the actual side should be reported as added");
    }

    @Test
    void missingElementReported() {
        CompareResult r = Comparator.compare(
                "{\"items\":[{\"id\":\"A\"},{\"id\":\"B\"}]}",
                "{\"items\":[{\"id\":\"A\"}]}",
                List.of());
        assertFalse(r.matched);
        assertTrue(r.diffs.stream().anyMatch(d -> "removed".equals(d.kind)),
                "Missing element on the actual side should be reported as removed");
    }

    @Test
    void reorderedWithOneGenuineDifference() {
        // B and C swapped (fine) but one id changed (must be caught)
        CompareResult r = Comparator.compare(
                "{\"items\":[{\"id\":\"A\"},{\"id\":\"B\"},{\"id\":\"C\"}]}",
                "{\"items\":[{\"id\":\"C\"},{\"id\":\"A\"},{\"id\":\"Z\"}]}",
                List.of());
        assertFalse(r.matched, "The changed element must be detected despite reordering");
    }
}
