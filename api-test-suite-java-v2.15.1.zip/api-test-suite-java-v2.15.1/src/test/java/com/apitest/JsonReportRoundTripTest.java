package com.apitest;

import com.apitest.model.AssertionResult;
import com.apitest.model.CompareResult;
import com.apitest.model.DiffEntry;
import com.apitest.model.StepResult;
import com.apitest.model.TestResult;
import com.apitest.reporter.JsonReport;
import com.apitest.reporter.Reporter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A run stored as JSON must regenerate the identical HTML report on demand.
 * That equality is the whole point of the format: an archive can keep the small
 * JSON file and rebuild the report whenever someone opens it.
 */
class JsonReportRoundTripTest {

    /** A run with every part populated: steps, comparison, assertions, errors. */
    private static List<TestResult> sampleRun() {
        TestResult pass = new TestResult();
        pass.testId = "T001";
        pass.name = "Cross-format accounts";
        pass.comparisonMode = "vs_protocol";
        pass.sourceA = "REST_UAT";
        pass.sourceB = "SOAP_UAT";
        pass.durationMs = 120;

        StepResult sa = new StepResult();
        sa.order = 1;
        sa.name = "Fetch accounts";
        sa.method = "GET";
        sa.url = "https://a.example.test/v1/accounts";
        sa.status = 200;
        sa.responseBody = "{\"items\":[{\"id\":\"A1\",\"amount\":100}]}";
        sa.extracted.put("accId", "A1");
        sa.expectedStatus = List.of(200);
        sa.passed = true;
        sa.elapsedMs = 60;
        pass.stepsA.add(sa);

        StepResult sb = new StepResult();
        sb.order = 1;
        sb.name = "Fetch accounts";
        sb.method = "POST";
        sb.url = "https://b.example.test/router";
        sb.status = 200;
        sb.requestBody = "<Envelope/>";
        sb.responseBody = "<R><Item><Id>A1</Id><Amount>100.00</Amount></Item></R>";
        sb.expectedStatus = List.of(200);
        sb.passed = true;
        sb.elapsedMs = 45;
        pass.stepsB.add(sb);

        CompareResult cr = new CompareResult();
        cr.matched = true;
        cr.note = "json vs xml (cross-format, records)";
        pass.compareResult = cr;

        AssertionResult ar = new AssertionResult();
        ar.path = "$.items[0].id";
        ar.operator = "equals";
        ar.expectedValue = "A1";
        ar.actualValue = "A1";
        ar.passed = true;
        pass.assertionResults.add(ar);

        TestResult fail = new TestResult();
        fail.testId = "T002";
        fail.name = "Balance mismatch <script>";  // must survive escaping unchanged
        fail.comparisonMode = "vs_env";
        fail.status = "FAIL";
        fail.durationMs = 80;
        CompareResult bad = new CompareResult();
        bad.matched = false;
        bad.diffs.add(new DiffEntry("$[A1].amount", "100", "999", "value"));
        bad.diffs.add(new DiffEntry("$[A1].extra", "x", "<missing>", "removed"));
        fail.compareResult = bad;

        TestResult error = new TestResult();
        error.testId = "T003";
        error.name = "Broken environment";
        error.status = "ERROR";
        error.error = "Environment 'NOPE' is not defined";
        error.errorDetail = "java.lang.IllegalStateException: ...\n  at com.apitest...";

        return List.of(pass, fail, error);
    }

    @Test
    void jsonRegeneratesIdenticalHtml(@TempDir Path dir) throws Exception {
        List<TestResult> original = sampleRun();
        String htmlBefore = Reporter.renderHtml(original, "Round trip suite");

        Path json = dir.resolve("report.json");
        JsonReport.write(original, json, "Round trip suite");
        JsonReport.Envelope loaded = JsonReport.read(json);
        String htmlAfter = Reporter.renderHtml(loaded.results, loaded.suiteName);

        assertEquals(scrubTimestamp(htmlBefore), scrubTimestamp(htmlAfter),
                "HTML regenerated from JSON must be identical to the original");
    }

    /** The generation timestamp is the one legitimate difference between renders. */
    private static String scrubTimestamp(String html) {
        return html.replaceAll("Generated [0-9:\\- ]+", "Generated X");
    }

    @Test
    void summaryCountsMatchStatuses(@TempDir Path dir) throws Exception {
        Path json = dir.resolve("r.json");
        JsonReport.write(sampleRun(), json, "s");
        JsonReport.Summary s = JsonReport.read(json).summary;
        assertEquals(3, s.total);
        assertEquals(1, s.passed);
        assertEquals(1, s.failed);
        assertEquals(1, s.errored);
        assertEquals(200, s.durationMs);
    }

    @Test
    void jsonIsMuchSmallerThanHtml(@TempDir Path dir) throws Exception {
        List<TestResult> run = sampleRun();
        Path json = dir.resolve("r.json");
        Path html = dir.resolve("r.html");
        JsonReport.write(run, json, "s");
        Reporter.renderReport(run, html, "s");
        long jsonSize = Files.size(json);
        long htmlSize = Files.size(html);
        assertTrue(jsonSize < htmlSize / 2,
                "JSON (" + jsonSize + ") should be far smaller than HTML (" + htmlSize + ")");
    }

    @Test
    void unknownSchemaIsRefused(@TempDir Path dir) throws Exception {
        Path json = dir.resolve("bad.json");
        Files.writeString(json, "{\"schema\":\"someone-elses/9\",\"results\":[]}");
        Exception e = assertThrows(Exception.class, () -> JsonReport.read(json));
        assertTrue(e.getMessage().contains("schema"), e.getMessage());
    }

    @Test
    void unknownFieldsFromNewerEngineAreTolerated(@TempDir Path dir) throws Exception {
        // A report written by a future engine may carry extra fields.
        String json = JsonReport.toJson(sampleRun(), "s")
                .replaceFirst("\\{", "{\"futureField\":123,");
        JsonReport.Envelope e = JsonReport.fromJson(json);
        assertEquals(3, e.results.size());
    }

    @Test
    void everyDetailSurvivesTheRoundTrip() throws Exception {
        JsonReport.Envelope e = JsonReport.fromJson(JsonReport.toJson(sampleRun(), "s"));

        TestResult pass = e.results.get(0);
        assertEquals("T001", pass.testId);
        assertEquals("GET", pass.stepsA.get(0).method);
        assertEquals("A1", pass.stepsA.get(0).extracted.get("accId"));
        assertEquals("POST", pass.stepsB.get(0).method);
        assertTrue(pass.compareResult.matched);
        assertEquals("A1", pass.assertionResults.get(0).actualValue);

        TestResult fail = e.results.get(1);
        assertEquals(2, fail.compareResult.diffs.size());
        assertEquals("value", fail.compareResult.diffs.get(0).kind);
        assertEquals("$[A1].amount", fail.compareResult.diffs.get(0).path);

        TestResult error = e.results.get(2);
        assertEquals("ERROR", error.status);
        assertTrue(error.errorDetail.contains("IllegalStateException"));
    }
}
