package com.migration.qtest;

import com.google.gson.*;
import org.apache.poi.ss.usermodel.*;

import javax.net.ssl.*;
import java.io.*;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Command-line utility for bulk-importing test cases from ALM-exported Excel/CSV
 * files into qTest Manager via its REST API.
 *
 * <p>Key behaviour:
 * <ul>
 *   <li>Reads ALM's multi-row-per-test-case export format, where the first row of
 *       each test case carries all metadata (name, description, status, etc.) and
 *       the following rows carry only step-level data.</li>
 *   <li>Maps Excel columns to qTest fields using a configuration file.</li>
 *   <li>Resolves dropdown values by label and creates folder hierarchies on demand.</li>
 *   <li>Authenticates with standard qTest user credentials (no admin access needed)
 *       via the OAuth token endpoint.</li>
 * </ul>
 *
 * <p>The whole tool is intentionally a single class so it is easy to review, build,
 * and hand off. Sections are separated by banner comments below.
 */
public class QTestImporter {

    private static final String VERSION = "3.0.0";
    private static final int HTTP_TIMEOUT_SECONDS = 30;
    private static final String DEFAULT_CONFIG = "qtest-config.properties";

    // ---- Runtime configuration (populated from the config file) ----
    private String baseUrl;
    private String token;
    private String tokenType;
    private long projectId;
    private Long parentModuleId;
    private boolean skipSsl;
    private int batchSize = 10;
    private int batchDelayMs = 500;
    private int stepStartOrder = 1;
    private boolean richText = false;
    private boolean verbose = false;
    private String attachmentsDir = "";
    private String requirementMappingFile = "requirement-mapping.csv";
    private HttpClient httpClient;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    /** qTest field definitions for the target project, loaded once per run. */
    private List<FieldDef> fieldDefs;

    /** Requirement lookup cache (PID and name, lower-cased) to ID, built on demand. */
    private Map<String, Long> requirementCache;

    /** User lookup cache (email, username, full name — all lower-cased) to ID. */
    private Map<String, Long> userCache;

    /**
     * Fallback column-to-field mapping, used only if the config file contains no
     * {@code mapping.*} entries at all. Normally the config file is authoritative.
     */
    private static final Map<String, String> DEFAULT_MAPPING = new LinkedHashMap<>();
    static {
        DEFAULT_MAPPING.put("Test Case Name", "name");
        DEFAULT_MAPPING.put("Description", "description");
        DEFAULT_MAPPING.put("Prerequisites", "precondition");
        DEFAULT_MAPPING.put("Status", "Status");
        DEFAULT_MAPPING.put("Priority", "Priority");
        DEFAULT_MAPPING.put("Test Type", "Type");
        DEFAULT_MAPPING.put("Automation", "Automation");
        DEFAULT_MAPPING.put("Step Description", "step.description");
        DEFAULT_MAPPING.put("Expected Result", "step.expected");
        DEFAULT_MAPPING.put("Step Name", "step.name");
    }

    // ========================================================================
    // Entry Point
    // ========================================================================

    /**
     * Program entry point. Dispatches the first argument to the matching command.
     * Any exception is reported as an error and exits with a non-zero status.
     *
     * @param args command name followed by command-specific arguments and options
     */
    public static void main(String[] args) {
        printBanner();
        if (args.length < 1) { printUsage(); System.exit(1); }

        QTestImporter app = new QTestImporter();
        String command = args[0].toLowerCase();

        try {
            switch (command) {
                case "login":
                    app.runLogin(args);
                    break;
                case "test-connection":
                    app.initFromConfig(args);
                    app.testConnection();
                    break;
                case "list-projects":
                    app.initFromConfig(args);
                    app.listProjects();
                    break;
                case "list-fields":
                    app.initFromConfig(args);
                    app.listFields(resolveArtifactType(args));
                    break;
                case "list-modules":
                    app.initFromConfig(args);
                    app.listModules();
                    break;
                case "create-folder":
                    requireArg(args, "create-folder <folderPath>");
                    app.runCreateFolder(args);
                    break;
                case "dry-run":
                    requireArg(args, "dry-run <file.xlsx|csv>");
                    app.runDryRun(args);
                    break;
                case "dry-run-requirements":
                    requireArg(args, "dry-run-requirements <file.xlsx|csv>");
                    app.runDryRunRequirements(args);
                    break;
                case "dry-run-defects":
                    requireArg(args, "dry-run-defects <file.xlsx|csv>");
                    app.runDryRunDefects(args);
                    break;
                case "import":
                    requireArg(args, "import <file.xlsx|csv>");
                    app.runImport(args);
                    break;
                case "import-batch":
                    requireArg(args, "import-batch <manifest>");
                    app.runImportBatch(args);
                    break;
                case "import-requirements":
                    requireArg(args, "import-requirements <file.xlsx|csv>");
                    app.runImportRequirements(args);
                    break;
                case "import-defects":
                    requireArg(args, "import-defects <file.xlsx|csv>");
                    app.runImportDefects(args);
                    break;
                default:
                    log("ERROR", "Unknown command: " + command);
                    printUsage();
                    System.exit(1);
            }
        } catch (Exception e) {
            log("ERROR", e.getMessage());
            System.exit(1);
        }
    }

    /**
     * Ensures a command was given a positional argument; otherwise prints usage and exits.
     *
     * @param args  the full argument array
     * @param usage short usage hint shown on error
     */
    private static void requireArg(String[] args, String usage) {
        if (args.length < 2) {
            log("ERROR", "Usage: " + usage);
            System.exit(1);
        }
    }

    /**
     * Resolves the artifact type for the {@code list-fields} command from the first
     * positional argument. Accepts {@code requirements}/{@code req},
     * {@code defects}/{@code defect}, or defaults to {@code test-cases}.
     *
     * @param args the full argument array
     * @return the artifact type path segment
     */
    private static String resolveArtifactType(String[] args) {
        if (args.length >= 2) {
            String a = args[1].toLowerCase();
            if (a.startsWith("req")) return "requirements";
            if (a.startsWith("def")) return "defects";
            if (a.equals("test-cases") || a.equals("testcases") || a.startsWith("test")) return "test-cases";
        }
        return "test-cases";
    }

    // ========================================================================
    // Configuration
    // ========================================================================

    /**
     * Loads the configuration file and populates all runtime settings, then builds
     * the HTTP client. When the auth type is {@code password}, this also performs
     * the login and stores the resulting bearer token for the rest of the run.
     *
     * @param args the argument array (scanned for an optional {@code --config} path)
     * @throws Exception if the config file is missing or a required value is absent
     */
    private void initFromConfig(String[] args) throws Exception {
        String configFile = findConfigArg(args);
        Properties props = loadProps(configFile);

        baseUrl = requireProp(props, "qtest.url").replaceAll("/+$", "");
        tokenType = props.getProperty("qtest.token.type", "bearer").trim();
        skipSsl = "true".equalsIgnoreCase(props.getProperty("qtest.skip.ssl", "false").trim());

        String pid = props.getProperty("qtest.project.id", "").trim();
        if (!pid.isEmpty()) projectId = Long.parseLong(pid);

        String mid = props.getProperty("qtest.module.id", "").trim();
        if (!mid.isEmpty()) parentModuleId = Long.parseLong(mid);

        batchSize = Math.max(1, Integer.parseInt(props.getProperty("import.batch.size", "10").trim()));
        batchDelayMs = Math.max(0, Integer.parseInt(props.getProperty("import.batch.delay.ms", "500").trim()));
        stepStartOrder = Integer.parseInt(props.getProperty("import.step.start.order", "1").trim());
        richText = "true".equalsIgnoreCase(props.getProperty("import.rich.text", "false").trim());
        attachmentsDir = props.getProperty("import.attachments.dir", "").trim();
        requirementMappingFile = props.getProperty("import.requirement.mapping.file", "requirement-mapping.csv").trim();
        verbose = hasFlag(args, "--verbose") || hasFlag(args, "--debug")
            || "true".equalsIgnoreCase(props.getProperty("import.verbose", "false").trim());

        buildHttpClient();

        if ("password".equalsIgnoreCase(tokenType)) {
            String user = requireProp(props, "qtest.username");
            String pass = requireProp(props, "qtest.password");
            log("INFO", "Authenticating as " + user + "...");
            token = loginAndGetToken(user, pass);
            tokenType = "bearer";
            log("OK", "Authentication successful.");
        } else {
            token = requireProp(props, "qtest.token");
        }
    }

    /**
     * Returns the config file path from a {@code --config} option, or the default
     * file name if the option is not present.
     *
     * @param args the argument array
     * @return the config file path to use
     */
    private String findConfigArg(String[] args) {
        String v = findOptionValue(args, "--config");
        return v != null ? v : DEFAULT_CONFIG;
    }

    /**
     * Returns the value that follows a named option (for example, the path after
     * {@code --folder}), or {@code null} if the option is absent or has no value.
     *
     * @param args       the argument array
     * @param optionName the option flag to look for
     * @return the following value, or {@code null}
     */
    private String findOptionValue(String[] args, String optionName) {
        for (int i = 0; i < args.length - 1; i++) {
            if (optionName.equals(args[i])) return args[i + 1];
        }
        return null;
    }

    /**
     * Returns {@code true} if a standalone flag (for example {@code --create-folder})
     * appears anywhere in the argument array.
     *
     * @param args     the argument array
     * @param flagName the flag to look for
     * @return whether the flag is present
     */
    private boolean hasFlag(String[] args, String flagName) {
        for (String a : args) if (flagName.equals(a)) return true;
        return false;
    }

    /**
     * Loads a properties file from disk.
     *
     * @param path the file path
     * @return the parsed {@link Properties}
     * @throws Exception if the file does not exist or cannot be read
     */
    private Properties loadProps(String path) throws Exception {
        File f = new File(path);
        if (!f.exists()) {
            throw new Exception("Config file not found: " + path
                + "\nEdit the bundled " + DEFAULT_CONFIG + " or pass one with --config <file>.");
        }
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(f)) { props.load(fis); }
        return props;
    }

    /**
     * Reads a required property, trimming whitespace.
     *
     * @param p   the properties
     * @param key the property key
     * @return the non-empty value
     * @throws Exception if the value is missing or blank
     */
    private String requireProp(Properties p, String key) throws Exception {
        String v = p.getProperty(key, "").trim();
        if (v.isEmpty()) throw new Exception("Missing required property: " + key);
        return v;
    }

    // ========================================================================
    // HTTP Client & Authentication
    // ========================================================================

    /**
     * Builds the shared {@link HttpClient}. When {@code qtest.skip.ssl} is enabled,
     * installs a trust-all SSL context so self-signed certificates are accepted.
     *
     * @throws Exception if the SSL context cannot be initialised
     */
    private void buildHttpClient() throws Exception {
        HttpClient.Builder builder = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .followRedirects(HttpClient.Redirect.NORMAL);

        if (skipSsl) {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
            }}, new SecureRandom());
            builder.sslContext(sc);
        }
        httpClient = builder.build();
    }

    /**
     * Authenticates against the qTest OAuth token endpoint using a username and
     * password and returns the resulting access token.
     *
     * <p>The {@code Authorization} header is {@code Basic base64(siteName + ":")},
     * where the site name is derived from the configured URL. The request body uses
     * the OAuth password grant.
     *
     * @param username the qTest login (usually an email address)
     * @param password the qTest password
     * @return the access token to use as a bearer token
     * @throws Exception if the request fails or the response has no access token
     */
    private String loginAndGetToken(String username, String password) throws Exception {
        String siteName = extractSiteName(baseUrl);
        String basicAuth = "Basic " + Base64.getEncoder()
            .encodeToString((siteName + ":").getBytes(StandardCharsets.UTF_8));

        String formBody = "grant_type=password"
            + "&username=" + URLEncoder.encode(username, StandardCharsets.UTF_8)
            + "&password=" + URLEncoder.encode(password, StandardCharsets.UTF_8);

        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + "/oauth/token"))
            .header("Content-Type", "application/x-www-form-urlencoded")
            .header("Authorization", basicAuth)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .POST(HttpRequest.BodyPublishers.ofString(formBody))
            .build();

        HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() < 200 || resp.statusCode() >= 300) {
            throw new Exception("Authentication failed (HTTP " + resp.statusCode() + "): "
                + truncate(resp.body(), 300));
        }

        JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
        if (!json.has("access_token")) {
            throw new Exception("Response missing access_token: " + truncate(resp.body(), 300));
        }
        return json.get("access_token").getAsString();
    }

    /**
     * Derives the qTest site name from a base URL. For example,
     * {@code https://myorg.qtestnet.com} yields {@code myorg}.
     *
     * @param url the configured base URL
     * @return the leading host label, or the host itself if it has no dot
     */
    private String extractSiteName(String url) {
        try {
            String host = URI.create(url).getHost();
            if (host != null && host.contains(".")) return host.substring(0, host.indexOf("."));
            return host != null ? host : "";
        } catch (Exception e) {
            return url.replaceAll("https?://", "").split("[./:]")[0];
        }
    }

    /**
     * Performs an authenticated GET request against the qTest API.
     *
     * @param path the API path (appended to the base URL)
     * @return the response body
     * @throws Exception on a non-2xx response or transport error
     */
    private String httpGet(String path) throws Exception {
        if (verbose) logRequest("GET", baseUrl + path,
            "Accept: application/json | Authorization: bearer ****", null);
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + path))
            .header("Accept", "application/json")
            .header("Authorization", "bearer " + token)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .GET().build();
        HttpResponse<String> resp = sendWithRetry(req);
        if (verbose) logResponse(resp);
        checkResponse(resp);
        return resp.body();
    }

    /**
     * Performs an authenticated POST request with a JSON body against the qTest API.
     *
     * @param path the API path (appended to the base URL)
     * @param body the JSON request body
     * @return the response body
     * @throws Exception on a non-2xx response or transport error
     */
    private String httpPost(String path, String body) throws Exception {
        if (verbose) logRequest("POST", baseUrl + path,
            "Content-Type: application/json | Accept: application/json | Authorization: bearer ****", body);
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + path))
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .header("Authorization", "bearer " + token)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
            .build();
        HttpResponse<String> resp = sendWithRetry(req);
        if (verbose) logResponse(resp);
        checkResponse(resp);
        return resp.body();
    }

    /**
     * Sends an HTTP request, retrying on transient failures (transport errors and
     * HTTP 429/5xx responses) with a short increasing backoff. Non-retryable
     * responses (including 4xx client errors) are returned immediately for the
     * caller to handle, since retrying them would not help.
     *
     * @param req the request to send
     * @return the HTTP response
     * @throws Exception if all attempts fail with a transport error
     */
    private HttpResponse<String> sendWithRetry(HttpRequest req) throws Exception {
        int maxAttempts = 3;
        Exception lastError = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
                int code = resp.statusCode();
                boolean transient_ = code == 429 || (code >= 500 && code < 600);
                if (!transient_ || attempt == maxAttempts) return resp;
                if (verbose) log("WARN", "  Transient HTTP " + code + ", retrying (" + attempt + "/"
                    + (maxAttempts - 1) + ")...");
            } catch (IOException | InterruptedException e) {
                lastError = e;
                if (attempt == maxAttempts) break;
                if (verbose) log("WARN", "  Network error, retrying (" + attempt + "/"
                    + (maxAttempts - 1) + "): " + truncate(e.getMessage(), 60));
            }
            Thread.sleep(500L * attempt); // simple linear backoff
        }
        throw new Exception("Request failed after " + maxAttempts + " attempts: "
            + (lastError != null ? lastError.getMessage() : "unknown error"));
    }

    /**
     * Uploads a single file to a qTest object as an attachment using a
     * {@code multipart/form-data} POST. The endpoint is
     * {@code /api/v3/projects/{projectId}/{objectType}/{objectId}/attachments},
     * where {@code objectType} is {@code test-cases}, {@code test-steps},
     * {@code requirements}, or {@code defects}.
     *
     * @param objectType the qTest object type path segment
     * @param objectId   the target object's ID
     * @param file       the file to upload
     * @throws Exception on a non-2xx response or transport error
     */
    private void uploadAttachment(String objectType, long objectId, File file) throws Exception {
        String boundary = "----qtestimporter" + System.currentTimeMillis();
        String path = "/api/v3/projects/" + projectId + "/" + objectType + "/" + objectId + "/attachments";
        String mime = guessContentType(file.getName());

        // Build the multipart body: a preamble (text), the raw file bytes, then a closing boundary.
        byte[] fileBytes = Files.readAllBytes(file.toPath());
        String preamble = "--" + boundary + "\r\n"
            + "Content-Disposition: form-data; name=\"file\"; filename=\"" + file.getName() + "\"\r\n"
            + "Content-Type: " + mime + "\r\n\r\n";
        String epilogue = "\r\n--" + boundary + "--\r\n";

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bos.write(preamble.getBytes(StandardCharsets.UTF_8));
        bos.write(fileBytes);
        bos.write(epilogue.getBytes(StandardCharsets.UTF_8));

        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + path))
            .header("Content-Type", "multipart/form-data; boundary=" + boundary)
            .header("Accept", "application/json")
            .header("Authorization", "bearer " + token)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .POST(HttpRequest.BodyPublishers.ofByteArray(bos.toByteArray()))
            .build();

        if (verbose) logRequest("POST", baseUrl + path,
            "Content-Type: multipart/form-data; boundary=" + boundary
                + " | Accept: application/json | Authorization: bearer ****",
            "[multipart body] file=" + file.getName() + " (" + fileBytes.length + " bytes, "
                + mime + ")");

        HttpResponse<String> resp = sendWithRetry(req);
        if (verbose) logResponse(resp);
        checkResponse(resp);
    }

    /**
     * Guesses an HTTP content type from a file name's extension, falling back to
     * {@code application/octet-stream} for unknown types.
     *
     * @param fileName the file name
     * @return a best-effort MIME type
     */
    private String guessContentType(String fileName) {
        String n = fileName.toLowerCase();
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".txt") || n.endsWith(".log")) return "text/plain";
        if (n.endsWith(".csv")) return "text/csv";
        if (n.endsWith(".xml")) return "text/xml";
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        if (n.endsWith(".doc")) return "application/msword";
        if (n.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (n.endsWith(".xls")) return "application/vnd.ms-excel";
        if (n.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        if (n.endsWith(".zip")) return "application/zip";
        return "application/octet-stream";
    }

    /**
     * Resolves a semicolon-separated list of attachment file names against the
     * configured attachments directory and uploads each existing file to the given
     * qTest object. Missing files are reported as warnings and skipped.
     *
     * @param objectType the qTest object type path segment
     * @param objectId   the target object's ID
     * @param fileList   semicolon-separated file names (may be empty)
     * @param label      a short label for log messages (e.g. the test case name)
     * @return the number of files successfully uploaded
     */
    private int uploadAttachmentList(String objectType, long objectId, String fileList, String label) {
        if (fileList == null || fileList.trim().isEmpty()) return 0;
        int uploaded = 0;
        for (String raw : fileList.split(";")) {
            String fileName = raw.trim();
            if (fileName.isEmpty()) continue;
            File f = new File(fileName);
            if (!f.isAbsolute()) f = new File(attachmentsDir, fileName);
            if (verbose) log("INFO", "  Looking for attachment at: " + f.getAbsolutePath());
            if (!f.exists()) {
                log("WARN", "Attachment not found for " + label + ": " + fileName
                    + " (looked in: " + (attachmentsDir.isEmpty() ? "<current dir>" : attachmentsDir) + ")");
                continue;
            }
            try {
                uploadAttachment(objectType, objectId, f);
                uploaded++;
            } catch (Exception e) {
                log("WARN", "Attachment upload failed (" + fileName + "): " + truncate(e.getMessage(), 80));
            }
        }
        return uploaded;
    }

    /**
     * Throws an exception if the HTTP response status is outside the 2xx range.
     *
     * @param resp the HTTP response to check
     * @throws Exception describing the status code and truncated body
     */
    private void checkResponse(HttpResponse<String> resp) throws Exception {
        int code = resp.statusCode();
        if (code >= 200 && code < 300) return;
        throw new Exception("HTTP " + code + ": " + truncate(resp.body(), 500));
    }

    // ========================================================================
    // Commands: Login & Discovery
    // ========================================================================

    /**
     * Interactive login command. Reads credentials from the config file or prompts
     * for any that are missing, obtains a bearer token, prints it, and optionally
     * writes it back into the config file.
     *
     * @param args the argument array (scanned for an optional {@code --config} path)
     * @throws Exception if login fails
     */
    private void runLogin(String[] args) throws Exception {
        String configFile = findConfigArg(args);
        Properties props = loadProps(configFile);
        baseUrl = requireProp(props, "qtest.url").replaceAll("/+$", "");
        skipSsl = "true".equalsIgnoreCase(props.getProperty("qtest.skip.ssl", "false").trim());
        buildHttpClient();

        String user = props.getProperty("qtest.username", "").trim();
        String pass = props.getProperty("qtest.password", "").trim();

        if (user.isEmpty()) { System.out.print("  Username (email): "); user = readLine(); }
        if (pass.isEmpty()) {
            if (System.console() != null) {
                pass = new String(System.console().readPassword("  Password: "));
            } else {
                System.out.print("  Password: "); pass = readLine();
            }
        }

        String accessToken = loginAndGetToken(user, pass);
        log("OK", "Login successful. Bearer token:");
        System.out.println("\n  " + accessToken + "\n");

        System.out.print("  Save token to " + configFile + "? (y/n): ");
        if ("y".equalsIgnoreCase(readLine())) {
            String content = Files.readString(Path.of(configFile));
            content = content.replaceAll("(?m)^qtest\\.token\\.type=.*$", "qtest.token.type=bearer");
            content = content.replaceAll("(?m)^qtest\\.token=.*$", "qtest.token=" + accessToken);
            Files.writeString(Path.of(configFile), content);
            log("OK", "Saved to " + configFile);
        }
    }

    /**
     * Verifies connectivity and credentials by listing the accessible projects.
     *
     * @throws Exception if the request fails
     */
    private void testConnection() throws Exception {
        log("INFO", "Connecting to " + baseUrl + (skipSsl ? " (SSL skip)" : ""));
        JsonArray projects = JsonParser.parseString(httpGet("/api/v3/projects")).getAsJsonArray();
        log("OK", "Connected. " + projects.size() + " project(s) accessible.");
    }

    /**
     * Prints all projects the authenticated user can access, with their IDs.
     *
     * @throws Exception if the request fails
     */
    private void listProjects() throws Exception {
        JsonArray projects = JsonParser.parseString(httpGet("/api/v3/projects")).getAsJsonArray();
        log("INFO", projects.size() + " project(s):");
        System.out.println();
        System.out.printf("  %-12s %-50s%n", "ID", "NAME");
        System.out.printf("  %-12s %-50s%n", "----------", "----");
        for (JsonElement el : projects) {
            JsonObject p = el.getAsJsonObject();
            System.out.printf("  %-12s %-50s%n", getJsonVal(p, "id"), truncate(getJsonVal(p, "name"), 48));
        }
        System.out.println();
    }

    /**
     * Prints the fields for a given artifact type ({@code test-cases},
     * {@code requirements}, or {@code defects}): the built-in fields that can be
     * mapped directly, followed by the project-specific fields with their IDs,
     * required/multi flags, and allowed dropdown values.
     *
     * @param artifactType the artifact type to list fields for
     * @throws Exception if the project is not set or the request fails
     */
    private void listFields(String artifactType) throws Exception {
        requireProject();
        List<FieldDef> defs = fetchFieldDefs(artifactType);
        log("INFO", artifactType + " fields for project " + projectId + ":\n");

        System.out.println("  BUILT-IN FIELDS (use these as mapping targets directly):");
        System.out.println("  -------------------------------------------------------");
        switch (artifactType) {
            case "requirements":
                System.out.printf("  %-25s  %s%n", "name", "Requirement name (REQUIRED)");
                System.out.printf("  %-25s  %s%n", "description", "Description text");
                System.out.printf("  %-25s  %s%n", "attachments", "Semicolon-separated file names");
                System.out.printf("  %-25s  %s%n", "requirement", "ALM requirement ID (for mapping file)");
                break;
            case "defects":
                System.out.printf("  %-25s  %s%n", "summary", "Defect summary (REQUIRED)");
                System.out.printf("  %-25s  %s%n", "description", "Description text");
                System.out.printf("  %-25s  %s%n", "attachments", "Semicolon-separated file names");
                break;
            default:
                System.out.printf("  %-25s  %s%n", "name", "Test case title (REQUIRED)");
                System.out.printf("  %-25s  %s%n", "description", "Description text");
                System.out.printf("  %-25s  %s%n", "precondition", "Precondition text");
                System.out.printf("  %-25s  %s%n", "step.description", "Step action text");
                System.out.printf("  %-25s  %s%n", "step.expected", "Step expected result");
                System.out.printf("  %-25s  %s%n", "attachments", "Test-case-level file names");
                System.out.printf("  %-25s  %s%n", "step.attachments", "Step-level file names");
                System.out.printf("  %-25s  %s%n", "requirement", "Requirement ID(s) to link (';'-separated)");
                break;
        }

        System.out.println("\n  PROJECT FIELDS (use the LABEL as mapping target):");
        System.out.println("  -------------------------------------------------");
        System.out.printf("  %-10s %-28s %-5s %-5s %-6s %s%n", "FIELD_ID", "LABEL", "REQ?", "MULTI", "DTYPE", "ALLOWED VALUES");
        System.out.printf("  %-10s %-28s %-5s %-5s %-6s %s%n", "--------", "-----", "----", "-----", "-----", "--------------");
        for (FieldDef fd : defs) {
            String vals = fd.allowedValues.stream()
                .map(v -> v.label + "(" + v.value + ")")
                .collect(Collectors.joining(", "));
            String dtype = fd.dataType + (isUserField(fd) ? "=USER" : "");
            System.out.printf("  %-10s %-28s %-5s %-5s %-6s %s%n",
                fd.id, truncate(fd.label, 26),
                fd.required ? "YES" : "", fd.multiple ? "YES" : "", dtype,
                vals.isEmpty() ? "(free text)" : vals);
        }
        System.out.println("\n  Config example: mapping.Status=Status");
        System.out.println("  Values auto-resolve by label (e.g. 'High' -> 724).\n");
    }

    /**
     * Prints the module (folder) hierarchy for the configured project.
     *
     * @throws Exception if the project is not set or the request fails
     */
    private void listModules() throws Exception {
        requireProject();
        JsonArray modules = JsonParser.parseString(
            httpGet("/api/v3/projects/" + projectId + "/modules")).getAsJsonArray();
        log("INFO", "Module tree for project " + projectId + ":\n");
        printModuleTree(modules, 1);
        System.out.println();
    }

    /**
     * Recursively prints a module tree with indentation.
     *
     * @param modules the modules at the current level
     * @param depth   the current indentation depth (1-based)
     */
    private void printModuleTree(JsonArray modules, int depth) {
        for (JsonElement el : modules) {
            JsonObject m = el.getAsJsonObject();
            System.out.printf("%s%-8s %s%n", "  ".repeat(depth), getJsonVal(m, "id"), getJsonVal(m, "name"));
            if (m.has("children") && m.get("children").isJsonArray()) {
                printModuleTree(m.getAsJsonArray("children"), depth + 1);
            }
        }
    }

    /**
     * Ensures a project ID has been configured before running a project-scoped command.
     *
     * @throws Exception if {@code qtest.project.id} is not set
     */
    private void requireProject() throws Exception {
        if (projectId == 0) throw new Exception("Set qtest.project.id in config. Run 'list-projects' to find it.");
    }

    // ========================================================================
    // Commands: Dry Run & Import
    // ========================================================================

    /**
     * Validates an input file without writing anything to qTest. Reads the file,
     * applies the mapping, builds test cases, validates each one, and prints a
     * summary plus a sample JSON payload for the first test case.
     *
     * @param args the argument array; {@code args[1]} is the input file path
     * @throws Exception if setup or file reading fails
     */
    private void runDryRun(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        log("INFO", "Loading field definitions...");
        fieldDefs = fetchFieldDefs();

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());

        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<TestCase> testCases = buildTestCases(headers, dataRows, mapping);

        System.out.println();
        log("DRY-RUN", "Validating " + testCases.size() + " test case(s)...\n");

        int valid = 0, invalid = 0;
        for (int i = 0; i < testCases.size(); i++) {
            TestCase tc = testCases.get(i);
            List<String> errors = validate(tc);
            if (errors.isEmpty()) {
                valid++;
                System.out.printf("  [%3d] OK   %-50s  %d step(s)%n",
                    i + 1, truncate(tc.name, 48), tc.steps.size());
            } else {
                invalid++;
                System.out.printf("  [%3d] FAIL %s%n", i + 1, truncate(tc.name, 55));
                errors.forEach(err -> System.out.println("           - " + err));
            }
        }

        System.out.println();
        log("DRY-RUN", "Valid: " + valid + "  Invalid: " + invalid + "  Total: " + testCases.size());

        if (!testCases.isEmpty()) {
            System.out.println();
            log("INFO", "Sample JSON payload (first test case):");
            System.out.println(gson.toJson(buildPayload(testCases.get(0))));
        }
    }

    /**
     * Validates a requirements file without writing anything to qTest. Builds the
     * requirements, validates each against the requirement field definitions, and
     * prints a summary plus a sample JSON payload for the first requirement.
     *
     * @param args the argument array; {@code args[1]} is the input file path
     * @throws Exception if setup or file reading fails
     */
    private void runDryRunRequirements(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        log("INFO", "Loading requirement field definitions...");
        List<FieldDef> reqFields = fetchFieldDefs("requirements");

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());
        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<Requirement> reqs = buildRequirements(headers, dataRows, mapping);
        System.out.println();
        log("DRY-RUN", "Validating " + reqs.size() + " requirement(s)...\n");

        int valid = 0, invalid = 0;
        for (int i = 0; i < reqs.size(); i++) {
            Requirement r = reqs.get(i);
            List<String> errors = validateProperties(r.name, r.properties, reqFields);
            if (r.name.isEmpty()) errors.add(0, "Name is empty");
            if (errors.isEmpty()) {
                valid++;
                System.out.printf("  [%3d] OK   %-55s%n", i + 1, truncate(r.name, 53));
            } else {
                invalid++;
                System.out.printf("  [%3d] FAIL %s%n", i + 1, truncate(r.name, 55));
                errors.forEach(err -> System.out.println("           - " + err));
            }
        }
        System.out.println();
        log("DRY-RUN", "Valid: " + valid + "  Invalid: " + invalid + "  Total: " + reqs.size());

        if (!reqs.isEmpty()) {
            Requirement r = reqs.get(0);
            JsonObject body = new JsonObject();
            body.addProperty("name", r.name);
            if (!r.description.isEmpty()) body.addProperty("description", fieldText(r.description));
            JsonArray props = buildProperties(r.properties, reqFields);
            if (props.size() > 0) body.add("properties", props);
            System.out.println();
            log("INFO", "Sample JSON payload (first requirement):");
            System.out.println(gson.toJson(body));
        }
    }

    /**
     * Validates a defects file without writing anything to qTest. Builds the defects,
     * validates each against the defect field definitions, and prints a summary plus
     * a sample JSON payload for the first defect.
     *
     * @param args the argument array; {@code args[1]} is the input file path
     * @throws Exception if setup or file reading fails
     */
    private void runDryRunDefects(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        log("INFO", "Loading defect field definitions...");
        List<FieldDef> defectFields = fetchFieldDefs("defects");

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());
        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<Defect> defects = buildDefects(headers, dataRows, mapping);
        System.out.println();
        log("DRY-RUN", "Validating " + defects.size() + " defect(s)...\n");

        int valid = 0, invalid = 0;
        for (int i = 0; i < defects.size(); i++) {
            Defect d = defects.get(i);
            List<String> errors = validateProperties(d.summary, d.properties, defectFields);
            if (errors.isEmpty()) {
                valid++;
                System.out.printf("  [%3d] OK   %-55s%n", i + 1, truncate(d.summary, 53));
            } else {
                invalid++;
                System.out.printf("  [%3d] FAIL %s%n", i + 1, truncate(d.summary, 55));
                errors.forEach(err -> System.out.println("           - " + err));
            }
        }
        System.out.println();
        log("DRY-RUN", "Valid: " + valid + "  Invalid: " + invalid + "  Total: " + defects.size());

        if (!defects.isEmpty()) {
            JsonObject body = new JsonObject();
            body.add("properties", buildProperties(defects.get(0).properties, defectFields));
            System.out.println();
            log("INFO", "Sample JSON payload (first defect):");
            System.out.println(gson.toJson(body));
        }
    }

    /**
     * Validates a label-keyed property map against field definitions, returning any
     * problems: unknown field labels, unresolvable user references, and unresolvable
     * dropdown values. Shared by the requirement and defect dry runs.
     *
     * @param label  a label for context (name or summary), checked for emptiness
     * @param values the field label to raw value map
     * @param defs   the field definitions for the artifact type
     * @return a list of human-readable problems (empty if valid)
     */
    private List<String> validateProperties(String label, Map<String, String> values, List<FieldDef> defs) {
        List<String> errors = new ArrayList<>();
        for (Map.Entry<String, String> e : values.entrySet()) {
            FieldDef fd = findFieldDef(e.getKey(), defs);
            if (fd == null) {
                errors.add("Unknown field: '" + e.getKey() + "'");
            } else if (isUserField(fd)) {
                try {
                    if (resolveUserId(e.getValue()) == null) {
                        errors.add("Cannot resolve user '" + e.getValue() + "' for field '" + fd.label
                            + "'. Use an email, username, or full name on the project.");
                    }
                } catch (Exception ex) {
                    errors.add("User lookup failed for field '" + fd.label + "': " + ex.getMessage());
                }
            } else if (!fd.allowedValues.isEmpty() && resolveAllowedValue(fd, e.getValue()) == null) {
                String available = fd.allowedValues.stream()
                    .map(v -> v.label).limit(8).collect(Collectors.joining(", "));
                errors.add("Cannot resolve '" + e.getValue() + "' for field '" + fd.label
                    + "'. Available: " + available);
            }
        }
        for (FieldDef fd : defs) {
            if (fd.required && !fd.label.equalsIgnoreCase("Name") && !values.containsKey(fd.label)) {
                errors.add("Required field missing: " + fd.label);
            }
        }
        return errors;
    }

    /**
     * Imports test cases from a single file. Resolves an optional target folder
     * (creating it when {@code --create-folder} is supplied), builds the test cases,
     * asks for confirmation, then performs the import.
     *
     * @param args the argument array; {@code args[1]} is the input file path.
     *             Recognised options: {@code --folder <path>}, {@code --create-folder}.
     * @throws Exception if setup, folder resolution, or file reading fails
     */
    private void runImport(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        // A command-line --attachments-dir overrides the config value for this run.
        String attDirOpt = findOptionValue(args, "--attachments-dir");
        if (attDirOpt != null) attachmentsDir = attDirOpt;

        log("INFO", "Loading field definitions...");
        fieldDefs = fetchFieldDefs();

        // Determine the target folder: --folder overrides the config's qtest.module.id.
        Long targetModule = parentModuleId;
        String folderPath = findOptionValue(args, "--folder");
        boolean createFolder = hasFlag(args, "--create-folder");
        if (folderPath != null) {
            targetModule = createFolder
                ? resolveOrCreateModulePath(folderPath)
                : resolveModulePath(folderPath);
        }

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());

        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<TestCase> testCases = buildTestCases(headers, dataRows, mapping);

        System.out.println();
        log("CONFIRM", "Import " + testCases.size() + " test case(s) into project " + projectId + "?");
        if (targetModule != null) log("INFO", "Target module ID: " + targetModule);
        System.out.print("  Type 'yes' to proceed: ");
        if (!"yes".equalsIgnoreCase(readLine())) { log("INFO", "Aborted."); return; }

        ImportResult result = executeImport(testCases, targetModule);
        reportResult(result);
    }

    /**
     * Imports several files in one run, driven by a manifest file. Each manifest
     * line maps one input file to a folder action:
     *
     * <pre>
     *   &lt;file path&gt; | &lt;action&gt; | &lt;folder path&gt;
     * </pre>
     *
     * Actions are {@code create} (create the folder path and any missing parents),
     * {@code existing} (folder must already exist), or {@code root} (no folder).
     * Lines beginning with {@code #} are comments and blank lines are ignored.
     *
     * <p>All files and folder targets are validated up front, so a bad entry stops
     * the run before any data is written. A file-level failure during import is
     * logged and does not abort the remaining files.
     *
     * @param args the argument array; {@code args[1]} is the manifest path
     * @throws Exception if setup fails or the manifest is invalid
     */
    private void runImportBatch(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        String manifestPath = args[1];
        File manifest = new File(manifestPath);
        if (!manifest.exists()) throw new Exception("Manifest not found: " + manifestPath);

        Map<String, String> mapping = loadMappingFromFile(findConfigArg(args));

        List<ManifestEntry> entries = parseManifest(manifest);
        if (entries.isEmpty()) throw new Exception("Manifest has no valid entries");

        log("INFO", entries.size() + " file(s) in manifest");
        System.out.println();

        // Resolve every file path and show the plan before importing anything.
        File baseDir = manifest.getAbsoluteFile().getParentFile();
        for (ManifestEntry e : entries) {
            File f = resolveManifestFile(baseDir, e.filePath);
            if (!f.exists()) throw new Exception("File not found (from manifest): " + e.filePath);
            e.resolvedFile = f;
            System.out.printf("  %-36s -> %-12s %-10s %s%n",
                truncate(e.filePath, 34), e.type, e.action,
                e.folderPath.isEmpty() ? "(root)" : e.folderPath);
        }

        // Load only the field definitions the manifest actually needs.
        boolean needTc = entries.stream().anyMatch(e -> e.type.equals("testcases"));
        boolean needReq = entries.stream().anyMatch(e -> e.type.equals("requirements"));
        boolean needDef = entries.stream().anyMatch(e -> e.type.equals("defects"));
        log("INFO", "Loading field definitions...");
        if (needTc) fieldDefs = fetchFieldDefs("test-cases");
        List<FieldDef> reqFields = needReq ? fetchFieldDefs("requirements") : null;
        List<FieldDef> defectFields = needDef ? fetchFieldDefs("defects") : null;

        System.out.println();
        log("CONFIRM", "Import " + entries.size() + " file(s) into project " + projectId + "?");
        System.out.print("  Type 'yes' to proceed: ");
        if (!"yes".equalsIgnoreCase(readLine())) { log("INFO", "Aborted."); return; }

        ImportResult grand = new ImportResult();
        for (int idx = 0; idx < entries.size(); idx++) {
            ManifestEntry e = entries.get(idx);
            System.out.println();
            log("INFO", "[" + (idx + 1) + "/" + entries.size() + "] " + e.filePath + " (" + e.type + ")");

            try {
                Long targetModule;
                switch (e.action) {
                    case "create":
                        targetModule = resolveOrCreateModulePath(e.folderPath);
                        break;
                    case "existing":
                        targetModule = resolveModulePath(e.folderPath);
                        break;
                    case "root":
                    default:
                        targetModule = null;
                        break;
                }

                List<String[]> allRows = readFile(e.resolvedFile.getPath());
                if (allRows.size() < 2) { log("WARN", "No data rows, skipping."); continue; }
                String[] headers = allRows.get(0);
                List<String[]> dataRows = allRows.subList(1, allRows.size());
                Map<String, String> resolved = resolveMapping(headers, mapping);

                ImportResult r;
                switch (e.type) {
                    case "requirements":
                        r = importRequirementList(buildRequirements(headers, dataRows, resolved),
                            reqFields, targetModule, null);
                        break;
                    case "defects":
                        r = importDefectList(buildDefects(headers, dataRows, resolved), defectFields);
                        break;
                    default:
                        r = executeImport(buildTestCases(headers, dataRows, resolved), targetModule);
                        break;
                }
                grand.ok += r.ok;
                grand.fail += r.fail;
                grand.errors.addAll(r.errors);
            } catch (Exception ex) {
                log("ERROR", "File failed: " + ex.getMessage());
                grand.errors.add(e.filePath + " (file-level): " + ex.getMessage());
            }
        }

        System.out.println();
        log("DONE", "Batch complete. Imported: " + grand.ok + "  Failed: " + grand.fail);
        writeErrorLog(grand.errors);
    }

    /**
     * Sends each test case to qTest, one at a time, pausing between batches.
     * Successes and failures are tallied; failures are recorded with their message.
     *
     * @param testCases           the test cases to create
     * @param targetModuleOverride the folder ID to place them in, or {@code null} for root
     * @return an {@link ImportResult} with counts, elapsed time, and error messages
     * @throws Exception if a batch pause is interrupted
     */
    private ImportResult executeImport(List<TestCase> testCases, Long targetModuleOverride) throws Exception {
        ImportResult result = new ImportResult();
        int total = testCases.size();
        long startTime = System.currentTimeMillis();

        for (int i = 0; i < total; i++) {
            TestCase tc = testCases.get(i);
            try {
                String json = gson.toJson(buildPayload(tc, targetModuleOverride));
                String resp = httpPost("/api/v3/projects/" + projectId + "/test-cases", json);
                JsonObject created = JsonParser.parseString(resp).getAsJsonObject();
                result.ok++;
                System.out.printf("  [%3d/%d] OK   %-45s -> %s%n",
                    i + 1, total, truncate(tc.name, 43), getJsonVal(created, "pid"));

                // Post-creation extras: test-case attachments, step attachments, requirement link.
                long testCaseId = getJsonLong(created, "id");
                handlePostCreate(tc, created, testCaseId);
            } catch (Exception e) {
                result.fail++;
                String msg = truncate(e.getMessage(), 120);
                result.errors.add(tc.name + ": " + msg);
                System.out.printf("  [%3d/%d] FAIL %-40s %s%n",
                    i + 1, total, truncate(tc.name, 38), msg);
            }

            // Pause after every full batch to be gentle on the API.
            if (i < total - 1 && (i + 1) % batchSize == 0) {
                log("INFO", "Batch pause (" + batchDelayMs + "ms)...");
                Thread.sleep(batchDelayMs);
            }
        }

        result.elapsedSeconds = (System.currentTimeMillis() - startTime) / 1000;
        return result;
    }

    /**
     * Performs the optional steps that follow a successful test case creation:
     * uploads test-case-level attachments, uploads step-level attachments (matching
     * each input step to the created step by order), and links the test case to a
     * requirement when a reference is given. Failures here are logged as warnings
     * and never fail the test case itself, which already exists in qTest.
     *
     * @param tc         the source test case
     * @param created    the JSON returned by the create call
     * @param testCaseId the new test case's ID
     */
    private void handlePostCreate(TestCase tc, JsonObject created, long testCaseId) {
        // Test-case-level attachments.
        if (!tc.attachments.isEmpty()) {
            int n = uploadAttachmentList("test-cases", testCaseId, tc.attachments, tc.name);
            if (n > 0) log("INFO", "  Uploaded " + n + " attachment(s) to test case");
        }

        // Step-level attachments: match created steps to input steps by position.
        boolean anyStepAtt = tc.steps.stream().anyMatch(s -> !s.attachments.isEmpty());
        if (anyStepAtt && created.has("test_steps") && created.get("test_steps").isJsonArray()) {
            JsonArray createdSteps = created.getAsJsonArray("test_steps");
            for (int s = 0; s < tc.steps.size() && s < createdSteps.size(); s++) {
                TestStep src = tc.steps.get(s);
                if (src.attachments.isEmpty()) continue;
                Long stepId = getJsonLong(createdSteps.get(s).getAsJsonObject(), "id");
                if (stepId == null) continue;
                int n = uploadAttachmentList("test-steps", stepId, src.attachments,
                    tc.name + " step " + (s + 1));
                if (n > 0) log("INFO", "  Uploaded " + n + " attachment(s) to step " + (s + 1));
            }
        }

        // Requirement link(s). The reference column may list several requirement IDs
        // separated by semicolons; each is resolved and linked independently.
        if (!tc.requirementRef.isEmpty()) {
            for (String raw : tc.requirementRef.split(";")) {
                String ref = raw.trim();
                if (ref.isEmpty()) continue;
                try {
                    linkTestCaseToRequirement(testCaseId, ref);
                    log("INFO", "  Linked to requirement: " + ref);
                } catch (Exception e) {
                    log("WARN", "  Requirement link failed (" + ref + "): "
                        + truncate(e.getMessage(), 80));
                }
            }
        }
    }

    /**
     * Prints the final summary line for a single-file import and writes an error
     * log if there were any failures.
     *
     * @param r the result to report
     * @throws Exception if writing the error log fails
     */
    private void reportResult(ImportResult r) throws Exception {
        System.out.println();
        log("DONE", String.format("Imported: %d  Failed: %d  Total: %d  Time: %ds",
            r.ok, r.fail, r.ok + r.fail, r.elapsedSeconds));
        writeErrorLog(r.errors);
    }

    /**
     * Writes failed-import messages to a timestamped log file. Does nothing when
     * there are no errors.
     *
     * @param errors the collected error messages
     * @throws Exception if the file cannot be written
     */
    private void writeErrorLog(List<String> errors) throws Exception {
        if (errors.isEmpty()) return;
        String errFile = "import-errors-" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date()) + ".log";
        Files.writeString(Path.of(errFile), String.join("\n", errors));
        log("INFO", "Error details: " + errFile);
    }

    // ========================================================================
    // Manifest Parsing (batch import)
    // ========================================================================

    /**
     * Parses a batch manifest file into entries. Each non-comment line is split on
     * {@code |} into a file path, an action, and an optional folder path. Unknown
     * actions fall back to {@code root}; {@code create}/{@code existing} actions
     * require a folder path.
     *
     * @param manifest the manifest file
     * @return the parsed entries
     * @throws Exception if the file cannot be read or an entry is invalid
     */
    private List<ManifestEntry> parseManifest(File manifest) throws Exception {
        List<ManifestEntry> entries = new ArrayList<>();
        List<String> lines = Files.readAllLines(manifest.toPath(), StandardCharsets.UTF_8);

        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) continue;

            String[] parts = trimmed.split("\\|");
            if (parts.length < 2) {
                log("WARN", "Skipping invalid manifest line: " + trimmed);
                continue;
            }

            ManifestEntry e = new ManifestEntry();
            e.filePath = parts[0].trim();
            e.action = parts[1].trim().toLowerCase();
            e.folderPath = parts.length >= 3 ? parts[2].trim() : "";
            if (parts.length >= 4) {
                String t = parts[3].trim().toLowerCase();
                if (t.startsWith("req")) e.type = "requirements";
                else if (t.startsWith("def")) e.type = "defects";
                else e.type = "testcases";
            }

            if (!e.action.equals("create") && !e.action.equals("existing") && !e.action.equals("root")) {
                log("WARN", "Unknown action '" + e.action + "' for " + e.filePath + ", defaulting to 'root'");
                e.action = "root";
            }
            if ((e.action.equals("create") || e.action.equals("existing")) && e.folderPath.isEmpty()) {
                throw new Exception("Manifest action '" + e.action + "' requires a folder path: " + e.filePath);
            }
            entries.add(e);
        }
        return entries;
    }

    /**
     * Resolves a manifest file path. Absolute or already-existing paths are used
     * as-is; otherwise the path is resolved relative to the manifest's directory.
     *
     * @param baseDir  the manifest's directory
     * @param filePath the path from the manifest line
     * @return the resolved file
     */
    private File resolveManifestFile(File baseDir, String filePath) {
        File f = new File(filePath);
        if (f.isAbsolute() || f.exists()) return f;
        return new File(baseDir, filePath);
    }

    // ========================================================================
    // Module (Folder) Management
    // ========================================================================

    /**
     * Creates a folder path in qTest (and any missing parent folders) and reports
     * the resulting module ID.
     *
     * @param args the argument array; {@code args[1]} is the folder path
     * @throws Exception if setup or creation fails
     */
    private void runCreateFolder(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();
        String folderPath = args[1];
        Long id = resolveOrCreateModulePath(folderPath);
        log("OK", "Folder ready: '" + folderPath + "' -> module ID " + id);
    }

    /**
     * Resolves a separator-delimited module path (for example {@code Regression\Sprint5})
     * to the ID of its deepest folder. Does not create anything.
     *
     * @param path the folder path
     * @return the deepest module ID, or {@code null} for an empty path
     * @throws Exception if any segment does not exist
     */
    private Long resolveModulePath(String path) throws Exception {
        List<String> segments = splitPath(path);
        if (segments.isEmpty()) return null;

        List<JsonObject> currentLevel = fetchModules(null);
        Long resolvedId = null;

        for (String segment : segments) {
            JsonObject match = findModuleByName(currentLevel, segment);
            if (match == null) {
                throw new Exception("Module not found: '" + segment + "' in path '" + path
                    + "'. Use --create-folder or action 'create' to create it.");
            }
            resolvedId = getJsonLong(match, "id");
            currentLevel = fetchModules(resolvedId);
        }
        log("INFO", "Resolved folder '" + path + "' to module ID " + resolvedId);
        return resolvedId;
    }

    /**
     * Resolves a module path, creating any missing segments along the way.
     *
     * @param path the folder path
     * @return the deepest module ID, or {@code null} for an empty path
     * @throws Exception if a folder cannot be created
     */
    private Long resolveOrCreateModulePath(String path) throws Exception {
        List<String> segments = splitPath(path);
        if (segments.isEmpty()) return null;

        List<JsonObject> currentLevel = fetchModules(null);
        Long parentId = null;

        for (String segment : segments) {
            JsonObject match = findModuleByName(currentLevel, segment);
            if (match != null) {
                parentId = getJsonLong(match, "id");
            } else {
                parentId = createModule(segment, parentId);
                log("OK", "Created folder '" + segment + "' (ID " + parentId + ")");
            }
            currentLevel = fetchModules(parentId);
        }
        return parentId;
    }

    /**
     * Fetches the child modules under a given parent (or the root modules when
     * {@code parentId} is {@code null}).
     *
     * @param parentId the parent module ID, or {@code null} for the root
     * @return the modules at that level
     * @throws Exception if the request fails
     */
    private List<JsonObject> fetchModules(Long parentId) throws Exception {
        String path = "/api/v3/projects/" + projectId + "/modules";
        if (parentId != null) path += "?parentId=" + parentId;
        JsonArray arr = JsonParser.parseString(httpGet(path)).getAsJsonArray();
        List<JsonObject> modules = new ArrayList<>();
        for (JsonElement el : arr) modules.add(el.getAsJsonObject());
        return modules;
    }

    /**
     * Finds a module by name within a level, case-insensitively.
     *
     * @param modules the modules to search
     * @param name    the folder name to match
     * @return the matching module, or {@code null}
     */
    private JsonObject findModuleByName(List<JsonObject> modules, String name) {
        for (JsonObject m : modules) {
            if (name.equalsIgnoreCase(getJsonVal(m, "name"))) return m;
        }
        return null;
    }

    /**
     * Creates a single module under a parent (or at the root when {@code parentId}
     * is {@code null}) and returns its new ID.
     *
     * @param name     the new folder name
     * @param parentId the parent module ID, or {@code null} for the root
     * @return the created module's ID
     * @throws Exception if the request fails
     */
    private Long createModule(String name, Long parentId) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("name", name);
        String path = "/api/v3/projects/" + projectId + "/modules";
        if (parentId != null) path += "?parentId=" + parentId;
        String resp = httpPost(path, gson.toJson(body));
        JsonObject created = JsonParser.parseString(resp).getAsJsonObject();
        return getJsonLong(created, "id");
    }

    /**
     * Splits a folder path into segments, accepting both backslash and forward-slash
     * separators and ignoring empty segments.
     *
     * @param path the folder path
     * @return the trimmed, non-empty segments in order
     */
    private List<String> splitPath(String path) {
        List<String> segments = new ArrayList<>();
        if (path == null) return segments;
        for (String part : path.split("[\\\\/]")) {
            String t = part.trim();
            if (!t.isEmpty()) segments.add(t);
        }
        return segments;
    }

    // ========================================================================
    // Requirements: Create, Resolve & Link
    // ========================================================================

    /**
     * Imports requirements from an input file and uploads any attachments. Each
     * requirement is created under the configured target module (or an optional
     * {@code --folder}).
     *
     * @param args the argument array; {@code args[1]} is the input file path
     * @throws Exception if setup or file reading fails
     */
    private void runImportRequirements(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        Long targetModule = parentModuleId;
        String folderPath = findOptionValue(args, "--folder");
        boolean createFolder = hasFlag(args, "--create-folder");
        if (folderPath != null) {
            targetModule = createFolder ? resolveOrCreateModulePath(folderPath) : resolveModulePath(folderPath);
        }

        String attDirOpt = findOptionValue(args, "--attachments-dir");
        if (attDirOpt != null) attachmentsDir = attDirOpt;

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());
        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<Requirement> reqs = buildRequirements(headers, dataRows, mapping);
        log("INFO", reqs.size() + " requirement(s) built from " + dataRows.size() + " row(s)");

        // Requirement-specific field definitions, so mapped property columns are sent.
        log("INFO", "Loading requirement field definitions...");
        List<FieldDef> reqFields = fetchFieldDefs("requirements");

        boolean hasAlmIds = reqs.stream().anyMatch(r -> !r.almId.isEmpty());
        if (!hasAlmIds) {
            log("WARN", "No column mapped to 'requirement'. Mapping file will not be generated.");
            log("INFO", "Add mapping.Requirement ID=requirement to create the ALM-to-qTest mapping file.");
        }

        System.out.println();
        log("CONFIRM", "Import " + reqs.size() + " requirement(s) into project " + projectId + "?");
        if (targetModule != null) log("INFO", "Target module ID: " + targetModule);
        System.out.print("  Type 'yes' to proceed: ");
        if (!"yes".equalsIgnoreCase(readLine())) { log("INFO", "Aborted."); return; }

        // Collect ALM-ID mappings as requirements are created, then write the file.
        List<String> mappingLines = new ArrayList<>();
        mappingLines.add("ALM_ID,QTEST_ID,QTEST_PID,NAME");
        ImportResult result = importRequirementList(reqs, reqFields, targetModule, mappingLines);

        if (hasAlmIds && mappingLines.size() > 1) {
            Files.writeString(Path.of(requirementMappingFile), String.join("\n", mappingLines));
            log("OK", "Wrote " + (mappingLines.size() - 1) + " mapping(s) to " + requirementMappingFile);
        }

        reportResult(result);
    }

    /**
     * Creates a list of requirements in qTest, sends their mapped property fields,
     * uploads attachments, and (when {@code mappingSink} is provided) appends an
     * {@code ALM_ID,QTEST_ID,QTEST_PID,NAME} line for each created requirement that
     * carries an ALM ID.
     *
     * @param reqs        the requirements to create
     * @param reqFields   the requirement field definitions
     * @param targetModule the folder to create them in, or {@code null} for root
     * @param mappingSink  a list to append ALM-ID mapping lines to, or {@code null}
     * @return the aggregated import result
     * @throws Exception if a batch pause is interrupted
     */
    private ImportResult importRequirementList(List<Requirement> reqs, List<FieldDef> reqFields,
                                               Long targetModule, List<String> mappingSink) throws Exception {
        ImportResult result = new ImportResult();
        long start = System.currentTimeMillis();

        for (int i = 0; i < reqs.size(); i++) {
            Requirement r = reqs.get(i);
            try {
                JsonObject body = new JsonObject();
                body.addProperty("name", r.name);
                if (!r.description.isEmpty()) body.addProperty("description", fieldText(r.description));
                if (targetModule != null) body.addProperty("parent_id", targetModule);
                JsonArray props = buildProperties(r.properties, reqFields);
                if (props.size() > 0) body.add("properties", props);
                String resp = httpPost("/api/v3/projects/" + projectId + "/requirements", gson.toJson(body));
                JsonObject created = JsonParser.parseString(resp).getAsJsonObject();
                long reqId = getJsonLong(created, "id");
                String pid = getJsonVal(created, "pid");
                result.ok++;
                System.out.printf("  [%3d/%d] OK   %-45s -> %s%n",
                    i + 1, reqs.size(), truncate(r.name, 43), pid);

                if (mappingSink != null && !r.almId.isEmpty()) {
                    mappingSink.add(escapeCsv(r.almId) + "," + reqId + "," + escapeCsv(pid) + "," + escapeCsv(r.name));
                }

                if (!r.attachments.isEmpty()) {
                    int n = uploadAttachmentList("requirements", reqId, r.attachments, r.name);
                    if (n > 0) log("INFO", "  Uploaded " + n + " attachment(s) to requirement");
                }
            } catch (Exception e) {
                result.fail++;
                String msg = truncate(e.getMessage(), 120);
                result.errors.add(r.name + ": " + msg);
                System.out.printf("  [%3d/%d] FAIL %-40s %s%n", i + 1, reqs.size(), truncate(r.name, 38), msg);
            }
            if (i < reqs.size() - 1 && (i + 1) % batchSize == 0) Thread.sleep(batchDelayMs);
        }
        result.elapsedSeconds = (System.currentTimeMillis() - start) / 1000;
        return result;
    }

    /**
     * Escapes a value for CSV output: wraps in quotes if it contains a comma, quote,
     * or newline, and doubles any internal quotes.
     *
     * @param value the raw value
     * @return the CSV-safe value
     */
    private String escapeCsv(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    /**
     * Builds requirements from input rows. One row is one requirement. Columns map
     * to {@code name}, {@code description}, {@code attachments}, or a property field.
     *
     * @param headers the file's header row
     * @param rows    the data rows
     * @param mapping the resolved header-to-target map
     * @return the requirements in input order
     */
    private List<Requirement> buildRequirements(String[] headers, List<String[]> rows, Map<String, String> mapping) {
        List<Requirement> result = new ArrayList<>();
        for (String[] row : rows) {
            Requirement r = new Requirement();
            for (int i = 0; i < headers.length; i++) {
                String target = mapping.getOrDefault(headers[i].trim(), "__skip__");
                String value = safeGet(row, i);
                if (value.isEmpty() || "__skip__".equals(target)) continue;
                switch (target) {
                    case "name": r.name = value; break;
                    case "description": r.description = value; break;
                    case "attachments": r.attachments = value; break;
                    case "requirement": r.almId = value; break;
                    default: r.properties.put(target, value); break;
                }
            }
            if (!r.name.isEmpty()) result.add(r);
        }
        return result;
    }

    /**
     * Links a created test case to a requirement. The requirement reference (from the
     * {@code Requirement ID} column in the test case file) is resolved against:
     * <ol>
     *   <li>The ALM-to-qTest mapping file generated by {@code import-requirements}
     *       (matching by ALM ID).</li>
     *   <li>The qTest project's requirements (matching by PID or name).</li>
     * </ol>
     *
     * @param testCaseId the test case ID
     * @param reqRef     the ALM requirement ID, qTest PID, or requirement name
     * @throws Exception if the requirement cannot be found or the link fails
     */
    private void linkTestCaseToRequirement(long testCaseId, String reqRef) throws Exception {
        Long reqId = resolveRequirementId(reqRef);
        if (reqId == null) throw new Exception("requirement not found: " + reqRef);
        JsonArray ids = new JsonArray();
        ids.add(testCaseId);
        httpPost("/api/v3/projects/" + projectId + "/requirements/" + reqId + "/link?type=test-cases",
            gson.toJson(ids));
    }

    /**
     * Resolves a requirement reference to its qTest ID. Tries the mapping file first
     * (for ALM IDs), then falls back to the qTest API (for PIDs and names). Results
     * are cached for the duration of the run.
     *
     * @param reqRef the reference to resolve
     * @return the qTest requirement ID, or {@code null} if not found
     * @throws Exception if the API lookup fails
     */
    private Long resolveRequirementId(String reqRef) throws Exception {
        if (requirementCache == null) loadRequirementCache();
        String key = reqRef.trim().toLowerCase();
        return requirementCache.get(key);
    }

    /**
     * Builds the requirement lookup cache. First loads the mapping CSV (ALM ID to
     * qTest ID) if it exists, so ALM requirement IDs are resolvable. Then loads all
     * requirements from the qTest API (keyed by PID and name) as a fallback. The
     * mapping file takes precedence when the same key appears in both.
     *
     * @throws Exception if the API request fails
     */
    private void loadRequirementCache() throws Exception {
        requirementCache = new HashMap<>();

        // Phase 1: load the ALM ID mapping file if present.
        File mappingFile = new File(requirementMappingFile);
        if (mappingFile.exists()) {
            List<String> lines = Files.readAllLines(mappingFile.toPath(), StandardCharsets.UTF_8);
            int loaded = 0;
            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i).trim();
                if (line.isEmpty()) continue;
                String[] parts = parseCsvLine(line);
                if (parts.length >= 2) {
                    String almId = parts[0].trim().toLowerCase();
                    try {
                        long qTestId = Long.parseLong(parts[1].trim());
                        requirementCache.putIfAbsent(almId, qTestId);
                        loaded++;
                    } catch (NumberFormatException ignored) {}
                }
            }
            log("INFO", "Loaded " + loaded + " ALM ID mapping(s) from " + requirementMappingFile);
        }

        // Phase 2: load from qTest API (PID and name as keys).
        int page = 1;
        while (true) {
            String resp = httpGet("/api/v3/projects/" + projectId + "/requirements?page=" + page + "&size=100");
            JsonElement parsed = JsonParser.parseString(resp);
            JsonArray items = parsed.isJsonArray()
                ? parsed.getAsJsonArray()
                : (parsed.getAsJsonObject().has("items")
                    ? parsed.getAsJsonObject().getAsJsonArray("items") : new JsonArray());
            if (items.size() == 0) break;
            for (JsonElement el : items) {
                JsonObject o = el.getAsJsonObject();
                Long id = getJsonLong(o, "id");
                if (id == null) continue;
                String pid = getJsonVal(o, "pid").trim().toLowerCase();
                String name = getJsonVal(o, "name").trim().toLowerCase();
                if (!pid.isEmpty()) requirementCache.putIfAbsent(pid, id);
                if (!name.isEmpty()) requirementCache.putIfAbsent(name, id);
            }
            if (items.size() < 100) break;
            page++;
        }
    }

    // ========================================================================
    // User Resolution (for Assigned To and other user-list fields)
    // ========================================================================

    /**
     * Resolves a user reference (email, username, or full name) to a qTest user ID.
     * The lookup is case-insensitive and the user list is cached for the run.
     *
     * @param userRef the email, username, or full name from the input file
     * @return the qTest user ID, or {@code null} if no match is found
     * @throws Exception if the user lookup request fails
     */
    private Long resolveUserId(String userRef) throws Exception {
        if (userCache == null) loadUserCache();
        return userCache.get(userRef.trim().toLowerCase());
    }

    /**
     * Loads all users on the project into a lookup cache keyed by email, username,
     * and full name (all lower-cased), so user-list fields can be resolved by any of
     * those references.
     *
     * @throws Exception if the user lookup request fails
     */
    private void loadUserCache() throws Exception {
        userCache = new HashMap<>();
        int page = 1;
        while (true) {
            String resp = httpGet("/api/v3/projects/" + projectId + "/users?page=" + page + "&size=100");
            JsonElement parsed = JsonParser.parseString(resp);
            JsonArray items = parsed.isJsonArray()
                ? parsed.getAsJsonArray()
                : (parsed.getAsJsonObject().has("items")
                    ? parsed.getAsJsonObject().getAsJsonArray("items") : new JsonArray());
            if (items.size() == 0) break;
            for (JsonElement el : items) {
                JsonObject o = el.getAsJsonObject();
                Long id = getJsonLong(o, "id");
                if (id == null) continue;
                addUserKey(o, "email", id);
                addUserKey(o, "username", id);
                String first = getJsonVal(o, "first_name").trim();
                String last = getJsonVal(o, "last_name").trim();
                String full = (first + " " + last).trim().toLowerCase();
                if (!full.isEmpty()) userCache.putIfAbsent(full, id);
            }
            if (items.size() < 100) break;
            page++;
        }
        log("INFO", "Loaded " + userCache.size() + " user key(s) for assignment resolution");
    }

    /**
     * Adds a lower-cased user field value (if present) as a cache key for the user ID.
     *
     * @param user the user JSON object
     * @param key  the field to read (e.g. {@code email})
     * @param id   the user ID to map to
     */
    private void addUserKey(JsonObject user, String key, long id) {
        String v = getJsonVal(user, key).trim().toLowerCase();
        if (!v.isEmpty()) userCache.putIfAbsent(v, id);
    }

    /**
     * Returns true if a field is a qTest user-list field, which expects a user ID
     * (in an array) rather than a free-text value. Detected by a user-list data type
     * code (5 or 14, which vary by qTest instance) or, as a fallback, by an original
     * name that indicates a user field (e.g. "Assigned To", "Shepherd Users").
     *
     * @param fd the field definition
     * @return whether the field is a user-list field
     */
    private boolean isUserField(FieldDef fd) {
        if (fd.dataType == 5 || fd.dataType == 14) return true;
        String on = fd.originalName == null ? "" : fd.originalName.toLowerCase();
        return on.contains("assigned") || on.contains("shepherd") || on.contains("user");
    }
    private String[] parseCsvLine(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (inQuotes) {
                if (c == '"' && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    cur.append('"');
                    i++;
                } else if (c == '"') {
                    inQuotes = false;
                } else {
                    cur.append(c);
                }
            } else {
                if (c == '"') inQuotes = true;
                else if (c == ',') { fields.add(cur.toString()); cur = new StringBuilder(); }
                else cur.append(c);
            }
        }
        fields.add(cur.toString());
        return fields.toArray(new String[0]);
    }

    // ========================================================================
    // Defects: Import
    // ========================================================================

    /**
     * Imports defects from an input file and uploads any attachments. One row is one
     * defect. Columns map to {@code summary}, {@code description}, {@code attachments},
     * or a property field.
     *
     * @param args the argument array; {@code args[1]} is the input file path
     * @throws Exception if setup or file reading fails
     */
    private void runImportDefects(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        String attDirOpt = findOptionValue(args, "--attachments-dir");
        if (attDirOpt != null) attachmentsDir = attDirOpt;

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());
        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<Defect> defects = buildDefects(headers, dataRows, mapping);
        log("INFO", defects.size() + " defect(s) built from " + dataRows.size() + " row(s)");

        // Defect-specific field definitions, so dropdown values resolve correctly.
        log("INFO", "Loading defect field definitions...");
        List<FieldDef> defectFields = fetchFieldDefs("defects");

        System.out.println();
        log("CONFIRM", "Import " + defects.size() + " defect(s) into project " + projectId + "?");
        System.out.print("  Type 'yes' to proceed: ");
        if (!"yes".equalsIgnoreCase(readLine())) { log("INFO", "Aborted."); return; }

        ImportResult result = importDefectList(defects, defectFields);
        reportResult(result);
    }

    /**
     * Creates a list of defects in qTest, sending their mapped property fields and
     * uploading any attachments.
     *
     * @param defects      the defects to create
     * @param defectFields the defect field definitions
     * @return the aggregated import result
     * @throws Exception if a batch pause is interrupted
     */
    private ImportResult importDefectList(List<Defect> defects, List<FieldDef> defectFields) throws Exception {
        ImportResult result = new ImportResult();
        long start = System.currentTimeMillis();
        for (int i = 0; i < defects.size(); i++) {
            Defect d = defects.get(i);
            try {
                JsonObject body = new JsonObject();
                // qTest defects carry their fields (including Summary) in properties.
                JsonArray props = buildProperties(d.properties, defectFields);
                body.add("properties", props);
                String resp = httpPost("/api/v3/projects/" + projectId + "/defects", gson.toJson(body));
                JsonObject created = JsonParser.parseString(resp).getAsJsonObject();
                long defectId = getJsonLong(created, "id");
                result.ok++;
                System.out.printf("  [%3d/%d] OK   %-45s -> %s%n",
                    i + 1, defects.size(), truncate(d.summary, 43), getJsonVal(created, "pid"));
                if (!d.attachments.isEmpty()) {
                    int n = uploadAttachmentList("defects", defectId, d.attachments, d.summary);
                    if (n > 0) log("INFO", "  Uploaded " + n + " attachment(s) to defect");
                }
            } catch (Exception e) {
                result.fail++;
                String msg = truncate(e.getMessage(), 120);
                result.errors.add(d.summary + ": " + msg);
                System.out.printf("  [%3d/%d] FAIL %-40s %s%n", i + 1, defects.size(), truncate(d.summary, 38), msg);
            }
            if (i < defects.size() - 1 && (i + 1) % batchSize == 0) Thread.sleep(batchDelayMs);
        }
        result.elapsedSeconds = (System.currentTimeMillis() - start) / 1000;
        return result;
    }

    /**
     * Builds defects from input rows. The {@code summary} target is stored both as a
     * label (for logs) and as a property, since qTest defects keep Summary among
     * their fields.
     *
     * @param headers the file's header row
     * @param rows    the data rows
     * @param mapping the resolved header-to-target map
     * @return the defects in input order
     */
    private List<Defect> buildDefects(String[] headers, List<String[]> rows, Map<String, String> mapping) {
        List<Defect> result = new ArrayList<>();
        for (String[] row : rows) {
            Defect d = new Defect();
            for (int i = 0; i < headers.length; i++) {
                String target = mapping.getOrDefault(headers[i].trim(), "__skip__");
                String value = safeGet(row, i);
                if (value.isEmpty() || "__skip__".equals(target)) continue;
                switch (target) {
                    case "summary":
                        d.summary = value;
                        d.properties.put("Summary", value);
                        break;
                    case "description":
                        d.description = value;
                        d.properties.put("Description", value);
                        break;
                    case "attachments": d.attachments = value; break;
                    default: d.properties.put(target, value); break;
                }
            }
            if (!d.summary.isEmpty() || !d.properties.isEmpty()) result.add(d);
        }
        return result;
    }

    // ========================================================================
    // qTest Field Definitions
    // ========================================================================

    /**
     * Fetches the test case field definitions for the configured project.
     *
     * @return the field definitions
     * @throws Exception if the request fails
     */
    private List<FieldDef> fetchFieldDefs() throws Exception {
        return fetchFieldDefs("test-cases");
    }

    /**
     * Fetches the field definitions for a given artifact type ({@code test-cases},
     * {@code requirements}, or {@code defects}), including each field's ID, label,
     * required and multi-value flags, and allowed values.
     *
     * @param artifactType the qTest artifact type path segment
     * @return the field definitions
     * @throws Exception if the request fails
     */
    private List<FieldDef> fetchFieldDefs(String artifactType) throws Exception {
        JsonArray raw = JsonParser.parseString(
            httpGet("/api/v3/projects/" + projectId + "/settings/" + artifactType + "/fields")).getAsJsonArray();

        List<FieldDef> result = new ArrayList<>();
        for (JsonElement el : raw) {
            JsonObject f = el.getAsJsonObject();
            FieldDef fd = new FieldDef();
            fd.id = getJsonVal(f, "id");
            fd.label = getJsonVal(f, "label");
            fd.required = f.has("required") && f.get("required").getAsBoolean();
            fd.multiple = f.has("multiple") && f.get("multiple").getAsBoolean();
            fd.dataType = f.has("data_type") && f.get("data_type").isJsonPrimitive()
                ? safeInt(getJsonVal(f, "data_type")) : 0;
            fd.originalName = getJsonVal(f, "original_name");
            fd.allowedValues = new ArrayList<>();

            if (f.has("allowed_values") && f.get("allowed_values").isJsonArray()) {
                for (JsonElement av : f.getAsJsonArray("allowed_values")) {
                    JsonObject v = av.getAsJsonObject();
                    AllowedValue val = new AllowedValue();
                    val.label = getJsonVal(v, "label");
                    val.value = getJsonVal(v, "value");
                    fd.allowedValues.add(val);
                }
            }
            result.add(fd);
        }
        return result;
    }

    /**
     * Builds a qTest {@code properties} JSON array from a label-keyed value map,
     * resolving dropdown values against the supplied field definitions and applying
     * the rich-text setting to free-text values. Unknown labels are skipped.
     *
     * @param values the field label to raw value map
     * @param defs   the field definitions for the target artifact type
     * @return a properties array (possibly empty)
     */
    private JsonArray buildProperties(Map<String, String> values, List<FieldDef> defs) {
        JsonArray props = new JsonArray();
        for (Map.Entry<String, String> entry : values.entrySet()) {
            FieldDef fd = findFieldDef(entry.getKey(), defs);
            if (fd == null) continue;

            JsonObject prop = new JsonObject();
            prop.addProperty("field_id", Long.parseLong(fd.id));

            // User-list fields (e.g. Assigned To) need a user ID. qTest expects the
            // value as a STRING containing an array, e.g. "[14]".
            if (isUserField(fd)) {
                Long userId = null;
                try { userId = resolveUserId(entry.getValue()); }
                catch (Exception e) { /* fall through to skip below */ }
                if (userId == null) {
                    log("WARN", "Could not resolve user '" + entry.getValue()
                        + "' for field '" + fd.label + "'; skipping this field.");
                    continue;
                }
                prop.addProperty("field_value", "[" + userId + "]");
                props.add(prop);
                continue;
            }

            String resolved = resolveAllowedValue(fd, entry.getValue());
            String finalValue = resolved != null ? resolved : entry.getValue();

            // qTest expects all field_value as strings. Multi-value dropdowns take a
            // string-wrapped array (e.g. "[701]"); everything else is a plain string.
            if (fd.multiple && finalValue.matches("-?\\d+")) {
                prop.addProperty("field_value", "[" + finalValue + "]");
            } else if (resolved != null) {
                // Resolved dropdown value id, sent as a string.
                prop.addProperty("field_value", resolved);
            } else {
                prop.addProperty("field_value", fieldText(finalValue));
            }
            props.add(prop);
        }
        return props;
    }

    /**
     * Finds a field definition by label within a specific list, case-insensitively.
     *
     * @param label the qTest field label
     * @param defs  the field definitions to search
     * @return the matching field definition, or {@code null}
     */
    private FieldDef findFieldDef(String label, List<FieldDef> defs) {
        if (defs == null) return null;
        for (FieldDef fd : defs) {
            if (label.equalsIgnoreCase(fd.label)) return fd;
        }
        return null;
    }

    /**
     * Resolves a raw dropdown label (such as {@code "High"}) to its qTest internal
     * value ID by matching against the field's allowed values, case-insensitively.
     *
     * @param fd       the field definition
     * @param rawValue the value from the input file
     * @return the matching internal value, or {@code null} if there is no match or
     *         the field has no allowed values
     */
    private String resolveAllowedValue(FieldDef fd, String rawValue) {
        if (fd.allowedValues == null || fd.allowedValues.isEmpty()) return null;
        String target = rawValue.trim().toLowerCase();
        for (AllowedValue av : fd.allowedValues) {
            if (av.label.trim().toLowerCase().equals(target)) return av.value;
        }
        return null;
    }

    // ========================================================================
    // Mapping: Config File -> Column-to-Field Mapping
    // ========================================================================

    /**
     * Reads {@code mapping.*} lines directly from the config file rather than via
     * {@link Properties}, because {@code Properties.load} treats spaces as key/value
     * separators, which would break column names like {@code "Test Case Name"}.
     *
     * <p>Each line is split on the LAST {@code =}, so
     * {@code mapping.Test Case Name=name} yields column {@code "Test Case Name"} and
     * target {@code "name"}. If no mapping lines are found, the built-in defaults
     * are used as a fallback.
     *
     * @param configPath the config file path
     * @return the column-to-target mapping
     * @throws Exception if the file cannot be read
     */
    private Map<String, String> loadMappingFromFile(String configPath) throws Exception {
        Map<String, String> mapping = new LinkedHashMap<>();
        List<String> lines = Files.readAllLines(Path.of(configPath), StandardCharsets.UTF_8);

        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.startsWith("#") || trimmed.isEmpty()) continue;
            if (!trimmed.startsWith("mapping.")) continue;

            String afterPrefix = trimmed.substring("mapping.".length());
            int eqIdx = afterPrefix.lastIndexOf('=');
            if (eqIdx <= 0) continue;

            String col = afterPrefix.substring(0, eqIdx).trim();
            String target = afterPrefix.substring(eqIdx + 1).trim();
            if (!col.isEmpty() && !target.isEmpty()) {
                mapping.put(col, target);
            }
        }

        if (mapping.isEmpty()) {
            log("WARN", "No mapping.* entries in config. Using defaults.");
            mapping.putAll(DEFAULT_MAPPING);
        }
        return mapping;
    }

    /**
     * Produces a per-header mapping for the actual file headers. Each header is
     * matched against the configured mapping (exact first, then case-insensitive);
     * unmatched headers are marked {@code __skip__}.
     *
     * @param headers the file's header row
     * @param mapping the configured column-to-target mapping
     * @return a header-to-target map covering every header
     */
    private Map<String, String> resolveMapping(String[] headers, Map<String, String> mapping) {
        Map<String, String> resolved = new LinkedHashMap<>();
        for (String h : headers) {
            String ht = h.trim();
            String found = mapping.get(ht);
            if (found == null) {
                for (Map.Entry<String, String> e : mapping.entrySet()) {
                    if (e.getKey().equalsIgnoreCase(ht)) { found = e.getValue(); break; }
                }
            }
            resolved.put(ht, found != null ? found : "__skip__");
        }
        return resolved;
    }

    /**
     * Prints how each file header maps to a qTest field, marking skipped columns.
     *
     * @param headers the file's header row
     * @param mapping the resolved header-to-target map
     */
    private void printMappingSummary(String[] headers, Map<String, String> mapping) {
        System.out.println();
        log("INFO", "Field mapping:");
        System.out.printf("  %-30s  ->  %s%n", "EXCEL COLUMN", "QTEST FIELD");
        System.out.printf("  %-30s      %s%n", "----------------------------", "-------------------");
        for (String h : headers) {
            String target = mapping.getOrDefault(h.trim(), "__skip__");
            boolean skip = "__skip__".equals(target);
            System.out.printf("  %-30s  ->  %s%s%n", truncate(h, 28), target, skip ? " (skipped)" : "");
        }
    }

    // ========================================================================
    // Test Case Builder - ALM Multi-Row Grouping
    // ========================================================================

    /**
     * Builds test cases from ALM-exported rows.
     *
     * <p>ALM export format: a test case with N steps spans N rows. The first row
     * holds all metadata (name, description, status, etc.) plus the first step's
     * data; rows 2..N have blank metadata columns and only step data.
     *
     * <p>Grouping rule: iterate rows in order. A row with a non-empty name column
     * starts a new test case and its metadata is read from that row. A row with an
     * empty name column is a continuation step that belongs to the test case most
     * recently started. Step data is collected from every row, including the first.
     *
     * <p>If no column maps to {@code name}, each row becomes its own test case.
     *
     * @param headers the file's header row
     * @param rows    the data rows (header excluded)
     * @param mapping the resolved header-to-target map
     * @return the assembled test cases in input order
     */
    private List<TestCase> buildTestCases(String[] headers, List<String[]> rows, Map<String, String> mapping) {
        int nameIdx = findMappedIndex(headers, mapping, "name");
        int stepDescIdx = findMappedIndex(headers, mapping, "step.description");
        int stepExpIdx = findMappedIndex(headers, mapping, "step.expected");
        int stepAttIdx = findMappedIndex(headers, mapping, "step.attachments");

        if (nameIdx < 0) {
            log("WARN", "No column mapped to 'name'. Each row becomes a separate test case.");
        }

        List<TestCase> result = new ArrayList<>();
        TestCase currentTc = null;

        for (String[] row : rows) {
            String nameValue = (nameIdx >= 0 && nameIdx < row.length) ? row[nameIdx].trim() : "";
            boolean isNewTestCase = !nameValue.isEmpty();

            if (nameIdx < 0) {
                // No name column mapped: treat every row as its own test case.
                isNewTestCase = true;
                nameValue = "Row_" + (result.size() + 1);
            }

            if (isNewTestCase) {
                // Start a new test case and read its metadata from this row.
                currentTc = new TestCase();
                currentTc.name = nameValue;
                result.add(currentTc);

                for (int i = 0; i < headers.length; i++) {
                    String target = mapping.getOrDefault(headers[i].trim(), "__skip__");
                    String value = safeGet(row, i);
                    if (value.isEmpty() || "__skip__".equals(target)) continue;

                    switch (target) {
                        case "name":
                        case "step.description":
                        case "step.expected":
                        case "step.name":
                        case "step.attachments":
                            break; // handled separately
                        case "description":
                            currentTc.description = value;
                            break;
                        case "precondition":
                            currentTc.precondition = value;
                            break;
                        case "attachments":
                            currentTc.attachments = value;
                            break;
                        case "requirement":
                            currentTc.requirementRef = value;
                            break;
                        default:
                            currentTc.properties.put(target, value);
                            break;
                    }
                }
            }

            // Collect step data from this row (applies to first and continuation rows).
            if (currentTc != null) {
                String stepDesc = safeGet(row, stepDescIdx);
                String stepExp = safeGet(row, stepExpIdx);
                String stepAtt = safeGet(row, stepAttIdx);
                if (!stepDesc.isEmpty() || !stepExp.isEmpty() || !stepAtt.isEmpty()) {
                    TestStep step = new TestStep();
                    step.description = stepDesc;
                    step.expected = stepExp;
                    step.attachments = stepAtt;
                    currentTc.steps.add(step);
                }
            }
        }

        log("INFO", result.size() + " test case(s) built from " + rows.size() + " row(s)");
        return result;
    }

    // ========================================================================
    // Payload Builder & Validation
    // ========================================================================

    /**
     * Builds the qTest API payload for a test case, using the configured default
     * target module.
     *
     * @param tc the test case
     * @return the JSON payload
     */
    private JsonObject buildPayload(TestCase tc) {
        return buildPayload(tc, parentModuleId);
    }

    /**
     * Builds the qTest API payload for a test case.
     *
     * <p>Property values are resolved against the field's allowed values where
     * applicable. Numeric values are sent as numbers; multi-value fields are sent
     * as a single-element array, as the qTest API requires. Steps are numbered from
     * {@code import.step.start.order} (default 1).
     *
     * @param tc       the test case
     * @param moduleId the target folder ID, or {@code null} for none
     * @return the JSON payload
     */
    private JsonObject buildPayload(TestCase tc, Long moduleId) {
        JsonObject obj = new JsonObject();
        obj.addProperty("name", tc.name);
        if (!tc.description.isEmpty()) obj.addProperty("description", fieldText(tc.description));
        if (!tc.precondition.isEmpty()) obj.addProperty("precondition", fieldText(tc.precondition));
        if (moduleId != null) obj.addProperty("parent_id", moduleId);

        if (!tc.properties.isEmpty()) {
            JsonArray props = buildProperties(tc.properties, fieldDefs);
            if (props.size() > 0) obj.add("properties", props);
        }

        if (!tc.steps.isEmpty()) {
            JsonArray steps = new JsonArray();
            for (int i = 0; i < tc.steps.size(); i++) {
                TestStep s = tc.steps.get(i);
                JsonObject step = new JsonObject();
                step.addProperty("description", fieldText(s.description));
                step.addProperty("expected", fieldText(s.expected));
                step.addProperty("order", stepStartOrder + i);
                steps.add(step);
            }
            obj.add("test_steps", steps);
        }
        return obj;
    }

    /**
     * Prepares a text field value for the API according to the rich-text setting.
     * When {@code import.rich.text=true}, the value is sent unchanged so HTML markup
     * is preserved. When false, HTML tags are stripped and common entities decoded so
     * the value is sent as plain text.
     *
     * @param value the raw field value
     * @return the value to send to qTest
     */
    private String fieldText(String value) {
        if (richText || value == null || value.isEmpty()) return value;
        if (value.indexOf('<') < 0 && value.indexOf('&') < 0) return value; // no markup to strip
        String stripped = value.replaceAll("<[^>]+>", "");
        return stripped.replace("&nbsp;", " ")
                       .replace("&amp;", "&")
                       .replace("&lt;", "<")
                       .replace("&gt;", ">")
                       .replace("&quot;", "\"")
                       .replace("&#39;", "'")
                       .trim();
    }

    /**
     * Validates a test case before import and returns any problems found: an empty
     * or over-long name, property values that do not resolve against a field's
     * allowed values, unknown field labels, and required fields that are missing.
     *
     * @param tc the test case to validate
     * @return a list of human-readable problems (empty if the test case is valid)
     */
    private List<String> validate(TestCase tc) {
        List<String> errors = new ArrayList<>();
        if (tc.name.isEmpty()) errors.add("Name is empty");
        if (tc.name.length() > 500) errors.add("Name exceeds 500 characters");
        // Property, user-field, dropdown, and required-field checks are shared.
        errors.addAll(validateProperties(tc.name, tc.properties, fieldDefs));
        return errors;
    }

    // ========================================================================
    // File Readers: Excel (.xlsx, .xls) and CSV/TSV
    // ========================================================================

    /**
     * Reads an input file into rows of string cells, choosing the reader by file
     * extension.
     *
     * @param path the file path
     * @return the rows, including the header row as the first element
     * @throws Exception if the file is missing or the format is unsupported
     */
    private List<String[]> readFile(String path) throws Exception {
        File file = new File(path);
        if (!file.exists()) throw new Exception("File not found: " + path);

        String name = file.getName().toLowerCase();
        if (name.endsWith(".xlsx")) return readExcel(file);
        if (name.endsWith(".xls")) return readExcel(file);
        if (name.endsWith(".csv")) return readCsv(file, ',');
        if (name.endsWith(".tsv")) return readCsv(file, '\t');
        throw new Exception("Unsupported format. Use .xlsx, .xls, or .csv");
    }

    /**
     * Reads the first sheet of an Excel workbook (.xlsx or .xls) into rows. Cells
     * are formatted to their displayed text; fully blank rows are skipped.
     *
     * @param file the workbook file
     * @return the non-empty rows
     * @throws Exception if the workbook cannot be opened or read
     */
    private List<String[]> readExcel(File file) throws Exception {
        log("INFO", "Reading: " + file.getName());
        List<String[]> rows = new ArrayList<>();

        try (Workbook wb = WorkbookFactory.create(file)) {
            Sheet sheet = wb.getSheetAt(0);
            DataFormatter fmt = new DataFormatter();

            for (Row row : sheet) {
                int lastCol = row.getLastCellNum();
                if (lastCol < 0) continue;

                String[] values = new String[lastCol];
                boolean hasData = false;
                for (int c = 0; c < lastCol; c++) {
                    Cell cell = row.getCell(c, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                    values[c] = (cell != null) ? fmt.formatCellValue(cell).trim() : "";
                    if (!values[c].isEmpty()) hasData = true;
                }
                if (hasData) rows.add(values);
            }
        }

        log("INFO", "Read " + rows.size() + " row(s)");
        return rows;
    }

    /**
     * Reads a delimited text file (CSV or TSV) into rows using a streaming RFC 4180
     * parser that handles quoted fields, escaped quotes ({@code ""}), and newlines
     * embedded inside quoted fields.
     *
     * @param file  the delimited file
     * @param delim the field delimiter ({@code ,} for CSV, tab for TSV)
     * @return the parsed rows
     * @throws Exception if the file cannot be read
     */
    private List<String[]> readCsv(File file, char delim) throws Exception {
        log("INFO", "Reading: " + file.getName());
        List<String[]> rows = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            List<String> fields = new ArrayList<>();
            StringBuilder current = new StringBuilder();
            boolean inQuotes = false;
            int ch;

            while ((ch = br.read()) != -1) {
                char c = (char) ch;
                if (inQuotes) {
                    if (c == '"') {
                        int next = br.read();
                        if (next == '"') {
                            current.append('"'); // escaped quote
                        } else {
                            inQuotes = false;
                            if (next == -1 || (char) next == '\n') {
                                fields.add(current.toString());
                                rows.add(fields.toArray(new String[0]));
                                fields = new ArrayList<>();
                                current = new StringBuilder();
                            } else if ((char) next == '\r') {
                                br.read(); // consume LF after CR
                                fields.add(current.toString());
                                rows.add(fields.toArray(new String[0]));
                                fields = new ArrayList<>();
                                current = new StringBuilder();
                            } else if ((char) next == delim) {
                                fields.add(current.toString());
                                current = new StringBuilder();
                            } else {
                                current.append((char) next);
                            }
                        }
                    } else {
                        current.append(c);
                    }
                } else {
                    if (c == '"') {
                        inQuotes = true;
                    } else if (c == delim) {
                        fields.add(current.toString());
                        current = new StringBuilder();
                    } else if (c == '\n') {
                        fields.add(current.toString());
                        rows.add(fields.toArray(new String[0]));
                        fields = new ArrayList<>();
                        current = new StringBuilder();
                    } else if (c == '\r') {
                        br.read(); // consume LF
                        fields.add(current.toString());
                        rows.add(fields.toArray(new String[0]));
                        fields = new ArrayList<>();
                        current = new StringBuilder();
                    } else {
                        current.append(c);
                    }
                }
            }
            if (!current.toString().isEmpty() || !fields.isEmpty()) {
                fields.add(current.toString());
                rows.add(fields.toArray(new String[0]));
            }
        }

        log("INFO", "Read " + rows.size() + " row(s)");
        return rows;
    }

    // ========================================================================
    // Utilities
    // ========================================================================

    /**
     * Returns the index of the first header that maps to the given target, or -1.
     *
     * @param headers the file's header row
     * @param mapping the resolved header-to-target map
     * @param target  the target to find (for example {@code "name"})
     * @return the column index, or -1 if no header maps to the target
     */
    private int findMappedIndex(String[] headers, Map<String, String> mapping, String target) {
        for (int i = 0; i < headers.length; i++) {
            if (target.equals(mapping.getOrDefault(headers[i].trim(), ""))) return i;
        }
        return -1;
    }

    /**
     * Safely reads and trims a cell from a row, returning an empty string when the
     * index is out of range.
     *
     * @param row the row
     * @param idx the column index
     * @return the trimmed cell value, or an empty string
     */
    private String safeGet(String[] row, int idx) {
        return (idx >= 0 && idx < row.length) ? row[idx].trim() : "";
    }

    /**
     * Safely extracts a JSON value as a string, handling numbers, booleans, and nulls.
     *
     * @param obj the JSON object
     * @param key the key to read
     * @return the value as a string, or an empty string if missing or null
     */
    private static String getJsonVal(JsonObject obj, String key) {
        if (!obj.has(key) || obj.get(key).isJsonNull()) return "";
        JsonElement el = obj.get(key);
        if (el.isJsonPrimitive()) return el.getAsString();
        return el.toString();
    }

    /**
     * Safely extracts a JSON value as a {@link Long}.
     *
     * @param obj the JSON object
     * @param key the key to read
     * @return the value as a Long, or {@code null} if missing, null, or non-numeric
     */
    private static Long getJsonLong(JsonObject obj, String key) {
        if (!obj.has(key) || obj.get(key).isJsonNull()) return null;
        try { return obj.get(key).getAsLong(); }
        catch (Exception e) { return null; }
    }

    /**
     * Truncates a string to a maximum length, appending an ellipsis when shortened.
     *
     * @param s the input string (may be {@code null})
     * @param n the maximum length
     * @return the original string, or a truncated version ending in {@code ...}
     */
    private static String truncate(String s, int n) {
        return (s == null || s.length() <= n) ? s : s.substring(0, n - 3) + "...";
    }

    /**
     * Parses an integer from a string, returning 0 if it is not a valid number.
     *
     * @param s the string to parse
     * @return the parsed integer, or 0
     */
    private static int safeInt(String s) {
        try { return Integer.parseInt(s.trim()); }
        catch (Exception e) { return 0; }
    }

    /**
     * Prints the details of an outgoing HTTP request (verbose mode). The bearer token
     * is shown redacted in the header string passed in.
     *
     * @param method  the HTTP method
     * @param url     the full request URL
     * @param headers a display string of the request headers (token redacted)
     * @param body    the request body, or {@code null} for none
     */
    private void logRequest(String method, String url, String headers, String body) {
        System.out.println("\n  --- HTTP REQUEST ---------------------------------------");
        System.out.println("  " + method + " " + url);
        System.out.println("  Headers: " + headers);
        if (body != null) {
            System.out.println("  Body:");
            for (String line : body.split("\n")) System.out.println("    " + line);
        }
        System.out.println("  --------------------------------------------------------");
    }

    /**
     * Prints the status and body of an HTTP response (verbose mode).
     *
     * @param resp the HTTP response
     */
    private void logResponse(HttpResponse<String> resp) {
        System.out.println("  --- HTTP RESPONSE (" + resp.statusCode() + ") -------------------------");
        String body = resp.body();
        System.out.println("  " + (body == null ? "" : body.replace("\n", "\n  ")));
        System.out.println("  --------------------------------------------------------\n");
    }

    /**
     * Reads a line of input from the console or standard input, trimmed.
     *
     * @return the trimmed input line
     * @throws IOException if reading fails
     */
    private static String readLine() throws IOException {
        if (System.console() != null) return System.console().readLine().trim();
        return new BufferedReader(new InputStreamReader(System.in)).readLine().trim();
    }

    /**
     * Prints a timestamped, colour-coded log line.
     *
     * @param level the level tag (OK, ERROR, WARN, INFO, DRY-RUN, CONFIRM, DONE)
     * @param msg   the message text
     */
    private static void log(String level, String msg) {
        String ts = new SimpleDateFormat("HH:mm:ss").format(new Date());
        String color;
        switch (level) {
            case "OK": case "DONE": color = "\033[32m"; break;
            case "ERROR": color = "\033[31m"; break;
            case "WARN": color = "\033[33m"; break;
            case "DRY-RUN": color = "\033[36m"; break;
            case "CONFIRM": color = "\033[35m"; break;
            default: color = "\033[0m"; break;
        }
        System.out.printf("%s [%s%-7s\033[0m] %s%n", ts, color, level, msg);
    }

    /** Prints the tool banner with its version. */
    private static void printBanner() {
        System.out.println();
        System.out.println("  qTest Test Case Importer v" + VERSION);
        System.out.println("  --------------------------------");
        System.out.println();
    }

    /** Prints the command and option reference. */
    private static void printUsage() {
        System.out.println("  Commands:");
        System.out.println("    login                        Authenticate and get bearer token");
        System.out.println("    test-connection              Verify connectivity");
        System.out.println("    list-projects                List available projects");
        System.out.println("    list-fields [type]           Field definitions (type: testcases|requirements|defects)");
        System.out.println("    list-modules                 List module/folder tree");
        System.out.println("    create-folder <path>         Create a folder path (e.g. \"Regression\\Sprint5\")");
        System.out.println("    dry-run <file.xlsx|csv>      Validate test cases without importing");
        System.out.println("    dry-run-requirements <file>  Validate requirements without importing");
        System.out.println("    dry-run-defects <file>       Validate defects without importing");
        System.out.println("    import  <file.xlsx|csv>      Import test cases");
        System.out.println("    import-batch <manifest>      Import multiple files per a manifest");
        System.out.println("    import-requirements <file>   Import requirements (with attachments)");
        System.out.println("    import-defects <file>        Import defects (with attachments)");
        System.out.println();
        System.out.println("  Options:");
        System.out.println("    --config <file>              Config file (default: " + DEFAULT_CONFIG + ")");
        System.out.println("    --folder <path>              Target folder for import");
        System.out.println("    --create-folder              Create the --folder path if it doesn't exist");
        System.out.println("    --attachments-dir <dir>      Base folder for attachment files");
        System.out.println("    --verbose (or --debug)       Print full request URL, headers, and JSON");
        System.out.println();
        System.out.println("  Examples:");
        System.out.println("    import tests.xlsx --folder \"Regression\\Sprint5\" --create-folder");
        System.out.println("    import tests.xlsx --attachments-dir ./attachments --verbose");
        System.out.println("    import-requirements reqs.xlsx --folder \"Requirements\" --create-folder");
        System.out.println("    import-defects defects.xlsx --verbose");
        System.out.println();
    }

    // ========================================================================
    // Data Classes
    // ========================================================================

    /** A qTest test case field definition and its allowed values. */
    static class FieldDef {
        String id;
        String label;
        boolean required;
        boolean multiple;
        int dataType;       // qTest data_type code (e.g. 14 = USER_LIST)
        String originalName = "";  // qTest original_name (e.g. "Assigned To", "Qup_...")
        List<AllowedValue> allowedValues = new ArrayList<>();
    }

    /** A single allowed value for a dropdown field: display label and internal value. */
    static class AllowedValue {
        String label;
        String value;
    }

    /** A test case assembled from the input file, ready to be sent to qTest. */
    static class TestCase {
        String name = "";
        String description = "";
        String precondition = "";
        Map<String, String> properties = new LinkedHashMap<>();
        List<TestStep> steps = new ArrayList<>();
        String attachments = "";       // semicolon-separated file names (test-case level)
        String requirementRef = "";    // requirement PID or name to link this test case to
    }

    /** A single test step: action description, expected result, and attachments. */
    static class TestStep {
        String description = "";
        String expected = "";
        String attachments = "";       // semicolon-separated file names (step level)
    }

    /** A requirement assembled from the input file, ready to be sent to qTest. */
    static class Requirement {
        String almId = "";             // original ALM requirement ID, written to mapping file
        String name = "";
        String description = "";
        Map<String, String> properties = new LinkedHashMap<>();
        String attachments = "";       // semicolon-separated file names
    }

    /** A defect assembled from the input file, ready to be sent to qTest. */
    static class Defect {
        String summary = "";
        String description = "";
        Map<String, String> properties = new LinkedHashMap<>();
        String attachments = "";       // semicolon-separated file names
    }

    /** Aggregated outcome of an import: success/failure counts, time, and errors. */
    static class ImportResult {
        int ok = 0;
        int fail = 0;
        long elapsedSeconds = 0;
        List<String> errors = new ArrayList<>();
    }

    /** One line of a batch manifest: a file plus its folder action and path. */
    static class ManifestEntry {
        String filePath = "";
        String action = "";       // create | existing | root
        String folderPath = "";
        String type = "testcases"; // testcases | requirements | defects
        File resolvedFile;
    }
}
