# qTest Test Case Importer

Java CLI utility to bulk-import test cases from ALM-exported Excel/CSV into qTest.

## Build

**Prerequisites:** Java 11+, Maven 3.6+

```bash
mvn clean package
```

This produces a fat JAR at `target/qtest-importer-1.0.0.jar` with all dependencies bundled.

## Usage

```bash
# Generate config file
java -jar target/qtest-importer-1.0.0.jar generate-config

# Edit qtest-config.properties with your URL, token, project ID

# Test connection
java -jar target/qtest-importer-1.0.0.jar test-connection

# Explore your qTest instance
java -jar target/qtest-importer-1.0.0.jar list-projects
java -jar target/qtest-importer-1.0.0.jar list-fields
java -jar target/qtest-importer-1.0.0.jar list-modules

# Validate (dry run)
java -jar target/qtest-importer-1.0.0.jar dry-run exported-from-alm.xlsx

# Import
java -jar target/qtest-importer-1.0.0.jar import exported-from-alm.xlsx
```

## Authentication

Set `qtest.token.type` in config:

| Type | How to get it |
|---|---|
| `UserContextToken` | Browser DevTools > Network tab > copy Authorization header value |
| `bearer` | qTest > Resources > API & SDK > Bearer Token |

## Configuration

`qtest-config.properties` (created by `generate-config`):

```properties
qtest.url=https://your-org.qtestnet.com
qtest.token=your-token
qtest.token.type=UserContextToken
qtest.skip.ssl=false          # true for self-signed certs
qtest.project.id=12345
qtest.module.id=               # optional target folder

import.batch.size=10
import.batch.delay.ms=500

# Field mappings (ALM column = qTest target)
mapping.Test Case Name=name
mapping.Description=description
mapping.Prerequisites=precondition
mapping.Status=Status
mapping.Priority=Priority
mapping.Test Type=Type
mapping.Automation=Automation
mapping.Step Description=step.description
mapping.Expected Result=step.expected
mapping.Step Name=step.name
```

## Field Mapping

| Target | What it does |
|---|---|
| `name` | Test case name (required, groups rows) |
| `description` | Description field |
| `precondition` | Precondition field |
| `step.description` | Test step description (1 row = 1 step) |
| `step.expected` | Test step expected result |
| `Status`, `Priority`, etc. | qTest property (auto-resolves dropdown values) |
| `__skip__` | Ignore this column |

ALM exports put one row per step. Rows with the same test case name are grouped
automatically. Run `list-fields` to see your qTest fields and allowed values.

## Supported File Formats

| Format | Support |
|---|---|
| `.xlsx` | Apache POI (full support) |
| `.xls` | Apache POI (legacy format) |
| `.csv` | Built-in reader (RFC 4180, multiline fields) |
| `.tsv` | Tab-separated |

## Commands

```
generate-config           Create config template
test-connection           Verify connectivity
list-projects             Show projects with IDs
list-fields               Show test case fields + allowed values
list-modules              Show module/folder tree
dry-run <file>            Validate and show sample JSON
import  <file>            Import with confirmation prompt

Options:
  --config <file>         Alternate config file path
```
