# qTest Test Case Importer

A command-line utility for bulk-importing test cases from HP ALM-exported Excel/CSV files into Tricentis qTest Manager via its REST API.

## Overview

This tool automates the migration of test case data from HP Application Lifecycle Management (ALM) to qTest Manager. It handles ALM's multi-row export format, field mapping, value resolution, and batch API calls with built-in validation and error handling.

### Key Capabilities

- **ALM Export Parsing**: Reads ALM's multi-row-per-test-case format where metadata appears only in the first row and subsequent rows contain step data
- **Configurable Field Mapping**: Maps ALM Excel columns to qTest test case fields via a properties file
- **Automatic Value Resolution**: Resolves dropdown values (e.g., `"High"` → `724`) using qTest's field definitions
- **OAuth Authentication**: Authenticates via `POST /oauth/token` using standard user credentials (no admin access required)
- **Dry Run Validation**: Validates all data and shows the exact JSON payload before committing
- **Batch Import**: Imports with configurable batch size and delay, per-record error logging

## Prerequisites

- Java 11 or higher
- Maven 3.6 or higher
- Network access to qTest Manager instance

## Build

```bash
mvn clean package
```

Produces an executable fat JAR at `target/qtest-importer-2.0.0.jar` with all dependencies bundled.

### Dependency Notes

- **Apache POI** (5.2.5): Excel file parsing (.xlsx, .xls)
- **Gson** (2.11.0): JSON serialization/deserialization
- **log4j-to-slf4j** (2.23.1): Routes POI's internal log4j-api calls to SLF4J
- **SLF4J NOP** (2.0.13): Discards all internal library logging output
- Only `log4j-api` (interfaces) is present as a transitive dependency. `log4j-core` (the component with the known JNDI/RCE vulnerability) is **not** included anywhere in the dependency tree.

## Usage

### 1. Generate Configuration

```bash
java -jar target/qtest-importer-2.0.0.jar generate-config
```

Creates `qtest-config.properties` with documented defaults.

### 2. Configure

Edit `qtest-config.properties`:

```properties
# Connection
qtest.url=https://your-org.qtestnet.com

# Authentication — username/password (recommended)
qtest.token.type=password
qtest.username=your.email@company.com
qtest.password=your-password

# Target
qtest.project.id=12345        # from list-projects
qtest.module.id=               # optional, from list-modules

# Field mapping
mapping.Test Case Name=name
mapping.Description=description
mapping.Step Description=step.description
mapping.Expected Result=step.expected
mapping.Status=Status
mapping.Priority=Priority
```

### 3. Verify Connection

```bash
java -jar target/qtest-importer-2.0.0.jar test-connection
```

### 4. Discover Project Structure

```bash
java -jar target/qtest-importer-2.0.0.jar list-projects
java -jar target/qtest-importer-2.0.0.jar list-fields
java -jar target/qtest-importer-2.0.0.jar list-modules
```

### 5. Validate (Dry Run)

```bash
java -jar target/qtest-importer-2.0.0.jar dry-run exported-tests.xlsx
```

### 6. Import

```bash
java -jar target/qtest-importer-2.0.0.jar import exported-tests.xlsx
```

## Architecture

### Component Architecture

```
+----------------------------------------------------------------------+
|                      qTest Test Case Importer                        |
+----------------------------------------------------------------------+
|                                                                      |
|  +------------------+     +------------------+     +------------+    |
|  |  CLI Controller  |---->| Config Manager   |---->| Properties |    |
|  |  (main, switch)  |     | (loadProps,      |     | File       |    |
|  +--------+---------+     |  loadMapping)    |     +------------+    |
|           |               +------------------+                       |
|           |                                                          |
|           +-----------------------+--------------------+             |
|           v                       v                    v             |
|  +------------------+   +------------------+   +------------------+  |
|  | Manifest Parser  |   |  File Reader     |   | Module Manager   |  |
|  | (batch mode)     |   |  (Excel, CSV)    |   | (create/resolve  |  |
|  |                  |   |  Apache POI      |   |  folder paths)   |  |
|  +------------------+   +--------+---------+   +--------+---------+  |
|                                  |                      |            |
|                                  v                      |            |
|                         +------------------+            |            |
|                         | Test Case        |            |            |
|                         | Builder          |            |            |
|                         | (ALM row         |            |            |
|                         |  grouping)       |            |            |
|                         +--------+---------+            |            |
|                                  |                      |            |
|                                  v                      |            |
|  +------------------+   +------------------+            |            |
|  | Field Resolver   |<--| Payload Builder  |<-----------+            |
|  | (allowed values, |   | (JSON assembly,  |   (target folder ID)    |
|  |  multi-value)    |   |  parent_id)      |                         |
|  +------------------+   +--------+---------+                         |
|                                  |                                   |
|                                  v                                   |
|  +------------------+   +------------------+                         |
|  | Auth Manager     |-->| HTTP Client      |----> qTest REST API     |
|  | (OAuth token)    |   | (java.net.http)  |                         |
|  +------------------+   +------------------+                         |
|                                                                      |
+----------------------------------------------------------------------+
```

### Data Flow

```
                ALM Export (.xlsx / .csv)
                         |
                         v
              +---------------------+
              |    File Reader      |    Apache POI (Excel)
              |    readExcel()      |    or built-in CSV parser
              |    readCsv()        |
              +----------+----------+
                         |
                    List<String[]> rows
                         |
                         v
              +---------------------+
              |  Mapping Resolver   |    Reads mapping.* lines
              |  loadMappingFromFile|    from config file
              |  resolveMapping()   |    (handles spaces in keys)
              +----------+----------+
                         |
                  Map<column, target>
                         |
                         v
              +---------------------+
              |  Test Case Builder  |    Sequential row iteration:
              |  buildTestCases()   |    - Non-empty name = new TC
              |                     |    - Empty name = continuation
              |                     |      step for previous TC
              +----------+----------+
                         |
                  List<TestCase>
                         |
                    +----+----+
                    |         |
                    v         v
              +---------+  +----------+
              |Validator|  | Payload  |   Resolves dropdown values
              |validate |  | Builder  |   Wraps multi-value fields
              +---------+  +----+-----+   in arrays
                                |
                           JsonObject
                                |
                                v
              +---------------------+
              |     HTTP Client     |    java.net.http.HttpClient
              |   POST /api/v3/    |    OAuth bearer token auth
              |   projects/{id}/   |
              |   test-cases       |
              +---------------------+
                         |
                         v
                  qTest Manager API
```

### ALM Export Row Grouping Logic

ALM exports test cases in a multi-row format:

```
Row 1: [TC Name] [Status] [Priority] [Description] [Step 1 Desc] [Step 1 Expected]
Row 2: [      ] [      ] [        ] [           ] [Step 2 Desc] [Step 2 Expected]
Row 3: [      ] [      ] [        ] [           ] [Step 3 Desc] [Step 3 Expected]
Row 4: [New TC] [Status] [Priority] [Description] [Step 1 Desc] [Step 1 Expected]
Row 5: [      ] [      ] [        ] [           ] [Step 2 Desc] [Step 2 Expected]
```

The builder iterates sequentially:
1. **Non-empty name column** → starts a new TestCase, reads all metadata from this row
2. **Empty name column** → appends step data to the most recently created TestCase
3. **Step data** is extracted from every row (including the first row of each test case)

### Authentication Flow

```
Client                          qTest Server
  |                                  |
  |  POST /oauth/token               |
  |  Authorization: Basic <site:>    |
  |  grant_type=password             |
  |  username=xxx&password=xxx       |
  |  -------------------------------->
  |                                  |
  |  200 OK                          |
  |  { "access_token": "abc123" }    |
  |  <--------------------------------
  |                                  |
  |  GET /api/v3/projects            |
  |  Authorization: bearer abc123    |
  |  -------------------------------->
  |                                  |
```

The `Basic` auth header contains `base64(sitename:)` where sitename is extracted from the URL hostname (e.g., `myorg` from `https://myorg.qtestnet.com`).

## Field Mapping Reference

### Built-in Targets

| Target | Description |
|---|---|
| `name` | Test case name (required, used for row grouping) |
| `description` | Description field |
| `precondition` | Precondition field |
| `step.description` | Test step action text |
| `step.expected` | Test step expected result |

### Property Targets

Use the qTest field label exactly as shown by `list-fields`. The tool automatically resolves dropdown values by matching labels case-insensitively.

For multi-value fields (e.g., "Assigned To"), the resolved value ID is wrapped in a JSON array as required by the qTest API.

### Special Values

| Value | Effect |
|---|---|
| `__skip__` | Column is ignored during import |
| _(unmapped)_ | Columns not in the config are auto-skipped |

## Command Reference

| Command | Description |
|---|---|
| `generate-config` | Create configuration file template |
| `login` | Authenticate interactively and obtain bearer token |
| `test-connection` | Verify qTest connectivity and credentials |
| `list-projects` | Display accessible projects with IDs |
| `list-fields` | Display test case field definitions with allowed values |
| `list-modules` | Display module/folder hierarchy with IDs |
| `create-folder <path>` | Create a folder path, including any missing parent folders |
| `dry-run <file>` | Validate file, mapping, and payloads without importing |
| `import <file>` | Import test cases with confirmation prompt |
| `import-batch <manifest>` | Import multiple files, each to its own folder target |

### Options

| Option | Applies To | Description |
|---|---|---|
| `--config <path>` | all | Use alternate configuration file |
| `--folder <path>` | `import` | Target folder for the import (e.g. `"Regression\Sprint5"`) |
| `--create-folder` | `import` | Create the `--folder` path if it does not exist |

## Working With Folders

qTest organizes test cases into folders (called *modules*). This tool can place
imported test cases into existing folders or create new ones.

### Single-file import into a folder

```bash
# Import into an existing folder
java -jar target/qtest-importer-2.0.0.jar import tests.xlsx --folder "Sprint 12\Payments"

# Create the folder (and any missing parents), then import
java -jar target/qtest-importer-2.0.0.jar import tests.xlsx --folder "Regression\New Suite" --create-folder
```

If no `--folder` is given, the `qtest.module.id` from the config is used (if set),
otherwise test cases go to the project's default location.

### Creating a folder ahead of time

```bash
java -jar target/qtest-importer-2.0.0.jar create-folder "Regression\API\v2"
```

### Batch import — multiple files, multiple folders

Create a manifest file describing each file and where it should go:

```
# file path           | action   | folder path
login_tests.xlsx      | create   | Regression\Authentication
payment_tests.xlsx    | existing | Sprint 12\Payments
smoke_tests.csv       | root     |
```

Actions:
- **create** — create the folder path (and missing parents), then import
- **existing** — import into a folder that must already exist
- **root** — import at the project root (no folder)

Then run:

```bash
java -jar target/qtest-importer-2.0.0.jar import-batch manifest.txt
```

All files and folder targets are validated up front. Each file is then imported
to its designated folder, with a consolidated summary at the end. See
`sample-manifest.txt` for a template.

## Configuration Reference

| Property | Required | Description |
|---|---|---|
| `qtest.url` | Yes | qTest server URL |
| `qtest.token.type` | Yes | `password` or `bearer` |
| `qtest.username` | If password | Login username |
| `qtest.password` | If password | Login password |
| `qtest.token` | If bearer | Bearer token value |
| `qtest.skip.ssl` | No | `true` to skip certificate verification |
| `qtest.project.id` | Yes | Target project ID |
| `qtest.module.id` | No | Target module/folder ID |
| `import.batch.size` | No | Records per batch (default: 10) |
| `import.batch.delay.ms` | No | Delay between batches in ms (default: 500) |
| `import.step.start.order` | No | Order number of the first step (default: 1) |

## Supported File Formats

| Format | Engine |
|---|---|
| `.xlsx` | Apache POI (XSSF) |
| `.xls` | Apache POI (HSSF) |
| `.csv` | Built-in RFC 4180 parser (multiline fields, escaped quotes) |
| `.tsv` | Built-in tab-separated parser |

## Error Handling

- **Dry run validation** catches: missing required fields, unresolvable dropdown values, unknown field labels, empty or oversized names
- **Import errors** are logged per-record with timestamps to `import-errors-YYYYMMDD-HHmmss.log`
- **HTTP errors** include status code and truncated response body for diagnostics
