package com.migration.qtest;

import com.google.gson.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.net.ssl.*;
import java.io.*;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

/**
 * CLI utility for bulk-importing test cases from ALM-exported Excel/CSV into qTest.
 *
 * Handles ALM's multi-row-per-test-case export format where the first row of each
 * test case contains all metadata (name, description, status, priority, etc.) and
 * subsequent rows contain only step-level data (step description, expected result).
 *
 * Supports OAuth token-based authentication via POST /oauth/token using standard
 * qTest user credentials (no admin access required).
 */
public class QTestImporter {

    private static final String VERSION = "1.0.0";
    private static final int HTTP_TIMEOUT_SECONDS = 30;

    private String baseUrl;
    private String token;
    private String tokenType;
    private long projectId;
    private Long parentModuleId;
    private boolean skipSsl;
    private int batchSize = 10;
    private int batchDelayMs = 500;
    private HttpClient httpClient;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private List<FieldDef> fieldDefs;

    private static final Map<String, String> DEFAULT_MAPPING = new LinkedHashMap<>();
    static {
        DEFAULT_MAPPING.put("Test Case Name", "name");
        DEFAULT_MAPPING.put("Description", "description");
        DEFAULT_MAPPING.put("Prerequisites", "precondition");
        DEFAULT_MAPPING.put("Status", "Status");
        DEFAULT_MAPPING.put("Priority", "Priority");
        DEFAULT_MAPPING.put("Test Type", "Type");
        DEFAULT_MAPPING.put("Automation", "Automation");
        DEFAULT_MAPPING.put("Step Description", "step.description");
        DEFAULT_MAPPING.put("Expected Result", "step.expected");
        DEFAULT_MAPPING.put("Step Name", "step.name");
    }

    private static final String[] KNOWN_ALM_HEADERS = {
        "Test Case Name", "Application", "Designer", "Test Type", "Automation",
        "Priority", "Module", "Test Category", "Status", "Regression Candidate",
        "Creation Date", "Classification", "Project", "Program", "Test Mode",
        "Description", "Test Data Req.", "Prerequisites", "Comments",
        "Number of Steps", "Step Name", "Step Description", "Expected Result",
        "Requirement Coverage", "Test Lab Path"
    };

    // ========================================================================
    // Entry Point
    // ========================================================================

    public static void main(String[] args) {
        printBanner();
        if (args.length < 1) { printUsage(); System.exit(1); }

        QTestImporter app = new QTestImporter();
        String command = args[0].toLowerCase();

        try {
            switch (command) {
                case "generate-config":
                    app.generateConfig();
                    break;
                case "login":
                    app.runLogin(args);
                    break;
                case "test-connection":
                    app.initFromConfig(args);
                    app.testConnection();
                    break;
                case "list-projects":
                    app.initFromConfig(args);
                    app.listProjects();
                    break;
                case "list-fields":
                    app.initFromConfig(args);
                    app.listFields();
                    break;
                case "list-modules":
                    app.initFromConfig(args);
                    app.listModules();
                    break;
                case "dry-run":
                    requireFileArg(args);
                    app.runDryRun(args);
                    break;
                case "import":
                    requireFileArg(args);
                    app.runImport(args);
                    break;
                default:
                    log("ERROR", "Unknown command: " + command);
                    printUsage();
                    System.exit(1);
            }
        } catch (Exception e) {
            log("ERROR", e.getMessage());
            System.exit(1);
        }
    }

    private static void requireFileArg(String[] args) {
        if (args.length < 2) {
            log("ERROR", "Usage: " + args[0] + " <file.xlsx|csv>");
            System.exit(1);
        }
    }

    // ========================================================================
    // Configuration
    // ========================================================================

    private void initFromConfig(String[] args) throws Exception {
        String configFile = findConfigArg(args);
        Properties props = loadProps(configFile);

        baseUrl = requireProp(props, "qtest.url").replaceAll("/+$", "");
        tokenType = props.getProperty("qtest.token.type", "bearer").trim();
        skipSsl = "true".equalsIgnoreCase(props.getProperty("qtest.skip.ssl", "false").trim());

        String pid = props.getProperty("qtest.project.id", "").trim();
        if (!pid.isEmpty()) projectId = Long.parseLong(pid);

        String mid = props.getProperty("qtest.module.id", "").trim();
        if (!mid.isEmpty()) parentModuleId = Long.parseLong(mid);

        batchSize = Math.max(1, Integer.parseInt(props.getProperty("import.batch.size", "10").trim()));
        batchDelayMs = Math.max(0, Integer.parseInt(props.getProperty("import.batch.delay.ms", "500").trim()));

        buildHttpClient();

        if ("password".equalsIgnoreCase(tokenType)) {
            String user = requireProp(props, "qtest.username");
            String pass = requireProp(props, "qtest.password");
            log("INFO", "Authenticating as " + user + "...");
            token = loginAndGetToken(user, pass);
            tokenType = "bearer";
            log("OK", "Authentication successful.");
        } else {
            token = requireProp(props, "qtest.token");
        }
    }

    private String findConfigArg(String[] args) {
        for (int i = 0; i < args.length - 1; i++) {
            if ("--config".equals(args[i])) return args[i + 1];
        }
        return "qtest-config.properties";
    }

    private Properties loadProps(String path) throws Exception {
        File f = new File(path);
        if (!f.exists()) {
            throw new Exception("Config not found: " + path + "\nRun: java -jar qtest-importer.jar generate-config");
        }
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(f)) { props.load(fis); }
        return props;
    }

    private String requireProp(Properties p, String key) throws Exception {
        String v = p.getProperty(key, "").trim();
        if (v.isEmpty()) throw new Exception("Missing required property: " + key);
        return v;
    }

    private void generateConfig() throws Exception {
        String filename = "qtest-config.properties";
        if (new File(filename).exists()) {
            System.out.print("  " + filename + " exists. Overwrite? (y/n): ");
            if (!"y".equalsIgnoreCase(readLine())) { log("INFO", "Aborted."); return; }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("# qTest Importer - Configuration\n");
        sb.append("# Generated ").append(nowStr()).append("\n\n");

        sb.append("# ============================================================\n");
        sb.append("# Connection\n");
        sb.append("# ============================================================\n");
        sb.append("qtest.url=https://your-org.qtestnet.com\n\n");

        sb.append("# ============================================================\n");
        sb.append("# Authentication (choose ONE option)\n");
        sb.append("# ============================================================\n\n");
        sb.append("# OPTION A: Login with username/password (recommended)\n");
        sb.append("# Calls POST /oauth/token automatically. Works for all users.\n");
        sb.append("qtest.token.type=password\n");
        sb.append("qtest.username=your.email@company.com\n");
        sb.append("qtest.password=your-password\n\n");
        sb.append("# OPTION B: Use a bearer token directly\n");
        sb.append("# qtest.token.type=bearer\n");
        sb.append("# qtest.token=your-bearer-token\n\n");

        sb.append("# Skip SSL verification (set true for self-signed certificates)\n");
        sb.append("qtest.skip.ssl=false\n\n");

        sb.append("# ============================================================\n");
        sb.append("# Target\n");
        sb.append("# ============================================================\n");
        sb.append("# Project ID — run 'list-projects' to find yours\n");
        sb.append("qtest.project.id=\n\n");
        sb.append("# Target module ID (optional) — run 'list-modules' to browse\n");
        sb.append("qtest.module.id=\n\n");

        sb.append("# ============================================================\n");
        sb.append("# Import Settings\n");
        sb.append("# ============================================================\n");
        sb.append("import.batch.size=10\n");
        sb.append("import.batch.delay.ms=500\n\n");

        sb.append("# ============================================================\n");
        sb.append("# Field Mapping: mapping.<Excel Column>=<qTest Target>\n");
        sb.append("# ============================================================\n");
        sb.append("# Built-in targets: name, description, precondition\n");
        sb.append("# Step targets:     step.description, step.expected\n");
        sb.append("# Property targets: use qTest field label (Status, Priority, etc.)\n");
        sb.append("# Use __skip__ to ignore. Unmapped columns are auto-skipped.\n");
        sb.append("# Run 'list-fields' to see all available qTest fields.\n\n");

        for (Map.Entry<String, String> e : DEFAULT_MAPPING.entrySet()) {
            sb.append("mapping.").append(e.getKey()).append("=").append(e.getValue()).append("\n");
        }
        sb.append("\n# Other columns (uncomment and set target to map):\n");
        for (String h : KNOWN_ALM_HEADERS) {
            if (!DEFAULT_MAPPING.containsKey(h)) {
                sb.append("# mapping.").append(h).append("=__skip__\n");
            }
        }

        Files.writeString(Path.of(filename), sb.toString());
        log("OK", "Created: " + filename);
        log("INFO", "Edit the file, then run: java -jar qtest-importer.jar test-connection");
    }

    // ========================================================================
    // HTTP Client & Authentication
    // ========================================================================

    private void buildHttpClient() throws Exception {
        HttpClient.Builder builder = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .followRedirects(HttpClient.Redirect.NORMAL);

        if (skipSsl) {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
            }}, new SecureRandom());
            builder.sslContext(sc);
        }
        httpClient = builder.build();
    }

    private String loginAndGetToken(String username, String password) throws Exception {
        String siteName = extractSiteName(baseUrl);
        String basicAuth = "Basic " + Base64.getEncoder()
            .encodeToString((siteName + ":").getBytes(StandardCharsets.UTF_8));

        String formBody = "grant_type=password"
            + "&username=" + URLEncoder.encode(username, StandardCharsets.UTF_8)
            + "&password=" + URLEncoder.encode(password, StandardCharsets.UTF_8);

        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + "/oauth/token"))
            .header("Content-Type", "application/x-www-form-urlencoded")
            .header("Authorization", basicAuth)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .POST(HttpRequest.BodyPublishers.ofString(formBody))
            .build();

        HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() < 200 || resp.statusCode() >= 300) {
            throw new Exception("Authentication failed (HTTP " + resp.statusCode() + "): "
                + truncate(resp.body(), 300));
        }

        JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
        if (!json.has("access_token")) {
            throw new Exception("Response missing access_token: " + truncate(resp.body(), 300));
        }
        return json.get("access_token").getAsString();
    }

    private String extractSiteName(String url) {
        try {
            String host = URI.create(url).getHost();
            if (host != null && host.contains(".")) return host.substring(0, host.indexOf("."));
            return host != null ? host : "";
        } catch (Exception e) {
            return url.replaceAll("https?://", "").split("[./:]")[0];
        }
    }

    private String httpGet(String path) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + path))
            .header("Accept", "application/json")
            .header("Authorization", "bearer " + token)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .GET().build();
        HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
        checkResponse(resp);
        return resp.body();
    }

    private String httpPost(String path, String body) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + path))
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .header("Authorization", "bearer " + token)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
            .build();
        HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
        checkResponse(resp);
        return resp.body();
    }

    private void checkResponse(HttpResponse<String> resp) throws Exception {
        int code = resp.statusCode();
        if (code >= 200 && code < 300) return;
        throw new Exception("HTTP " + code + ": " + truncate(resp.body(), 500));
    }

    // ========================================================================
    // Commands: Login, Connection, Discovery
    // ========================================================================

    private void runLogin(String[] args) throws Exception {
        String configFile = findConfigArg(args);
        Properties props = loadProps(configFile);
        baseUrl = requireProp(props, "qtest.url").replaceAll("/+$", "");
        skipSsl = "true".equalsIgnoreCase(props.getProperty("qtest.skip.ssl", "false").trim());
        buildHttpClient();

        String user = props.getProperty("qtest.username", "").trim();
        String pass = props.getProperty("qtest.password", "").trim();

        if (user.isEmpty()) { System.out.print("  Username (email): "); user = readLine(); }
        if (pass.isEmpty()) {
            if (System.console() != null) {
                pass = new String(System.console().readPassword("  Password: "));
            } else {
                System.out.print("  Password: "); pass = readLine();
            }
        }

        String accessToken = loginAndGetToken(user, pass);
        log("OK", "Login successful. Bearer token:");
        System.out.println("\n  " + accessToken + "\n");

        System.out.print("  Save token to " + configFile + "? (y/n): ");
        if ("y".equalsIgnoreCase(readLine())) {
            String content = Files.readString(Path.of(configFile));
            content = content.replaceAll("(?m)^qtest\\.token\\.type=.*$", "qtest.token.type=bearer");
            content = content.replaceAll("(?m)^qtest\\.token=.*$", "qtest.token=" + accessToken);
            Files.writeString(Path.of(configFile), content);
            log("OK", "Saved to " + configFile);
        }
    }

    private void testConnection() throws Exception {
        log("INFO", "Connecting to " + baseUrl + (skipSsl ? " (SSL skip)" : ""));
        JsonArray projects = JsonParser.parseString(httpGet("/api/v3/projects")).getAsJsonArray();
        log("OK", "Connected. " + projects.size() + " project(s) accessible.");
    }

    private void listProjects() throws Exception {
        JsonArray projects = JsonParser.parseString(httpGet("/api/v3/projects")).getAsJsonArray();
        log("INFO", projects.size() + " project(s):");
        System.out.println();
        System.out.printf("  %-12s %-50s%n", "ID", "NAME");
        System.out.printf("  %-12s %-50s%n", "----------", "----");
        for (JsonElement el : projects) {
            JsonObject p = el.getAsJsonObject();
            System.out.printf("  %-12s %-50s%n", getJsonVal(p, "id"), truncate(getJsonVal(p, "name"), 48));
        }
        System.out.println();
    }

    private void listFields() throws Exception {
        requireProject();
        fieldDefs = fetchFieldDefs();
        log("INFO", "Test case fields for project " + projectId + ":\n");

        System.out.println("  BUILT-IN FIELDS (use these as mapping targets directly):");
        System.out.println("  -------------------------------------------------------");
        System.out.printf("  %-25s  %s%n", "name", "Test case title (REQUIRED)");
        System.out.printf("  %-25s  %s%n", "description", "Description text");
        System.out.printf("  %-25s  %s%n", "precondition", "Precondition text");
        System.out.printf("  %-25s  %s%n", "step.description", "Step action text");
        System.out.printf("  %-25s  %s%n", "step.expected", "Step expected result");

        System.out.println("\n  PROJECT FIELDS (use the LABEL as mapping target):");
        System.out.println("  -------------------------------------------------");
        System.out.printf("  %-10s %-30s %-6s %-6s %s%n", "FIELD_ID", "LABEL", "REQ?", "MULTI", "ALLOWED VALUES");
        System.out.printf("  %-10s %-30s %-6s %-6s %s%n", "--------", "-----", "----", "-----", "--------------");
        for (FieldDef fd : fieldDefs) {
            String vals = fd.allowedValues.stream()
                .map(v -> v.label + "(" + v.value + ")")
                .collect(Collectors.joining(", "));
            System.out.printf("  %-10s %-30s %-6s %-6s %s%n",
                fd.id, truncate(fd.label, 28),
                fd.required ? "YES" : "", fd.multiple ? "YES" : "",
                vals.isEmpty() ? "(free text)" : vals);
        }
        System.out.println("\n  Config example: mapping.Status=Status");
        System.out.println("  Values auto-resolve by label (e.g. 'High' -> 724).\n");
    }

    private void listModules() throws Exception {
        requireProject();
        JsonArray modules = JsonParser.parseString(
            httpGet("/api/v3/projects/" + projectId + "/modules")).getAsJsonArray();
        log("INFO", "Module tree for project " + projectId + ":\n");
        printModuleTree(modules, 1);
        System.out.println();
    }

    private void printModuleTree(JsonArray modules, int depth) {
        for (JsonElement el : modules) {
            JsonObject m = el.getAsJsonObject();
            System.out.printf("%s%-8s %s%n", "  ".repeat(depth), getJsonVal(m, "id"), getJsonVal(m, "name"));
            if (m.has("children") && m.get("children").isJsonArray()) {
                printModuleTree(m.getAsJsonArray("children"), depth + 1);
            }
        }
    }

    private void requireProject() throws Exception {
        if (projectId == 0) throw new Exception("Set qtest.project.id in config. Run 'list-projects' to find it.");
    }

    // ========================================================================
    // Commands: Dry Run & Import
    // ========================================================================

    private void runDryRun(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        log("INFO", "Loading field definitions...");
        fieldDefs = fetchFieldDefs();

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());

        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<TestCase> testCases = buildTestCases(headers, dataRows, mapping);

        System.out.println();
        log("DRY-RUN", "Validating " + testCases.size() + " test case(s)...\n");

        int valid = 0, invalid = 0;
        for (int i = 0; i < testCases.size(); i++) {
            TestCase tc = testCases.get(i);
            List<String> errors = validate(tc);
            if (errors.isEmpty()) {
                valid++;
                System.out.printf("  [%3d] OK   %-50s  %d step(s)%n",
                    i + 1, truncate(tc.name, 48), tc.steps.size());
            } else {
                invalid++;
                System.out.printf("  [%3d] FAIL %s%n", i + 1, truncate(tc.name, 55));
                errors.forEach(err -> System.out.println("           - " + err));
            }
        }

        System.out.println();
        log("DRY-RUN", "Valid: " + valid + "  Invalid: " + invalid + "  Total: " + testCases.size());

        if (!testCases.isEmpty()) {
            System.out.println();
            log("INFO", "Sample JSON payload (first test case):");
            System.out.println(gson.toJson(buildPayload(testCases.get(0))));
        }
    }

    private void runImport(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        log("INFO", "Loading field definitions...");
        fieldDefs = fetchFieldDefs();

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());

        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<TestCase> testCases = buildTestCases(headers, dataRows, mapping);
        log("INFO", testCases.size() + " test case(s) built from " + dataRows.size() + " row(s)");

        System.out.println();
        log("CONFIRM", "Import " + testCases.size() + " test case(s) into project " + projectId + "?");
        if (parentModuleId != null) log("INFO", "Target module: " + parentModuleId);
        System.out.print("  Type 'yes' to proceed: ");
        if (!"yes".equalsIgnoreCase(readLine())) { log("INFO", "Aborted."); return; }

        executeImport(testCases);
    }

    private void executeImport(List<TestCase> testCases) throws Exception {
        int total = testCases.size(), ok = 0, fail = 0;
        List<String> errors = new ArrayList<>();
        long startTime = System.currentTimeMillis();

        for (int i = 0; i < total; i++) {
            TestCase tc = testCases.get(i);
            try {
                String json = gson.toJson(buildPayload(tc));
                String resp = httpPost("/api/v3/projects/" + projectId + "/test-cases", json);
                JsonObject created = JsonParser.parseString(resp).getAsJsonObject();
                ok++;
                System.out.printf("  [%3d/%d] OK   %-45s -> %s%n",
                    i + 1, total, truncate(tc.name, 43), getJsonVal(created, "pid"));
            } catch (Exception e) {
                fail++;
                String msg = truncate(e.getMessage(), 120);
                errors.add(tc.name + ": " + msg);
                System.out.printf("  [%3d/%d] FAIL %-40s %s%n",
                    i + 1, total, truncate(tc.name, 38), msg);
            }

            if (i < total - 1 && (i + 1) % batchSize == 0) {
                log("INFO", "Batch pause (" + batchDelayMs + "ms)...");
                Thread.sleep(batchDelayMs);
            }
        }

        long elapsed = (System.currentTimeMillis() - startTime) / 1000;
        System.out.println();
        log("DONE", String.format("Imported: %d  Failed: %d  Total: %d  Time: %ds", ok, fail, total, elapsed));

        if (!errors.isEmpty()) {
            String errFile = "import-errors-" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date()) + ".log";
            Files.writeString(Path.of(errFile), String.join("\n", errors));
            log("INFO", "Error details: " + errFile);
        }
    }

    // ========================================================================
    // qTest Field Definitions
    // ========================================================================

    private List<FieldDef> fetchFieldDefs() throws Exception {
        JsonArray raw = JsonParser.parseString(
            httpGet("/api/v3/projects/" + projectId + "/settings/test-cases/fields")).getAsJsonArray();

        List<FieldDef> result = new ArrayList<>();
        for (JsonElement el : raw) {
            JsonObject f = el.getAsJsonObject();
            FieldDef fd = new FieldDef();
            fd.id = getJsonVal(f, "id");
            fd.label = getJsonVal(f, "label");
            fd.required = f.has("required") && f.get("required").getAsBoolean();
            fd.multiple = f.has("multiple") && f.get("multiple").getAsBoolean();
            fd.allowedValues = new ArrayList<>();

            if (f.has("allowed_values") && f.get("allowed_values").isJsonArray()) {
                for (JsonElement av : f.getAsJsonArray("allowed_values")) {
                    JsonObject v = av.getAsJsonObject();
                    AllowedValue val = new AllowedValue();
                    val.label = getJsonVal(v, "label");
                    val.value = getJsonVal(v, "value");
                    fd.allowedValues.add(val);
                }
            }
            result.add(fd);
        }
        return result;
    }

    private FieldDef findFieldDef(String label) {
        if (fieldDefs == null) return null;
        for (FieldDef fd : fieldDefs) {
            if (label.equalsIgnoreCase(fd.label)) return fd;
        }
        return null;
    }

    private String resolveAllowedValue(FieldDef fd, String rawValue) {
        if (fd.allowedValues == null || fd.allowedValues.isEmpty()) return null;
        String target = rawValue.trim().toLowerCase();
        for (AllowedValue av : fd.allowedValues) {
            if (av.label.trim().toLowerCase().equals(target)) return av.value;
        }
        return null;
    }

    // ========================================================================
    // Mapping: Config File -> Column-to-Field Mapping
    // ========================================================================

    /**
     * Reads mapping lines directly from the config file (not via Properties.load)
     * because Java Properties treats spaces as key-value separators, which breaks
     * column names like "Test Case Name" or "Step Description".
     *
     * Parses each line starting with "mapping." and splits on the LAST '=' sign,
     * so "mapping.Test Case Name=name" correctly yields column="Test Case Name", target="name".
     */
    private Map<String, String> loadMappingFromFile(String configPath) throws Exception {
        Map<String, String> mapping = new LinkedHashMap<>();
        List<String> lines = Files.readAllLines(Path.of(configPath), StandardCharsets.UTF_8);

        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.startsWith("#") || trimmed.isEmpty()) continue;
            if (!trimmed.startsWith("mapping.")) continue;

            String afterPrefix = trimmed.substring("mapping.".length());
            int eqIdx = afterPrefix.lastIndexOf('=');
            if (eqIdx <= 0) continue;

            String col = afterPrefix.substring(0, eqIdx).trim();
            String target = afterPrefix.substring(eqIdx + 1).trim();
            if (!col.isEmpty() && !target.isEmpty()) {
                mapping.put(col, target);
            }
        }

        if (mapping.isEmpty()) {
            log("WARN", "No mapping.* entries in config. Using defaults.");
            mapping.putAll(DEFAULT_MAPPING);
        }
        return mapping;
    }

    private Map<String, String> resolveMapping(String[] headers, Map<String, String> mapping) {
        Map<String, String> resolved = new LinkedHashMap<>();
        for (String h : headers) {
            String ht = h.trim();
            String found = mapping.get(ht);
            if (found == null) {
                for (Map.Entry<String, String> e : mapping.entrySet()) {
                    if (e.getKey().equalsIgnoreCase(ht)) { found = e.getValue(); break; }
                }
            }
            resolved.put(ht, found != null ? found : "__skip__");
        }
        return resolved;
    }

    private void printMappingSummary(String[] headers, Map<String, String> mapping) {
        System.out.println();
        log("INFO", "Field mapping:");
        System.out.printf("  %-30s  ->  %s%n", "EXCEL COLUMN", "QTEST FIELD");
        System.out.printf("  %-30s      %s%n", "----------------------------", "-------------------");
        for (String h : headers) {
            String target = mapping.getOrDefault(h.trim(), "__skip__");
            boolean skip = "__skip__".equals(target);
            System.out.printf("  %-30s  ->  %s%s%n", truncate(h, 28), target, skip ? " (skipped)" : "");
        }
    }

    // ========================================================================
    // Test Case Builder — ALM Multi-Row Grouping
    // ========================================================================

    /**
     * Builds test cases from ALM-exported Excel rows.
     *
     * ALM export format: for a test case with N steps, there are N rows in the sheet.
     * - Row 1 (first step): contains ALL metadata (name, description, status, priority,
     *   etc.) PLUS the first step's data (step description, expected result).
     * - Rows 2..N (subsequent steps): metadata columns are BLANK, only step columns
     *   (step number, step name, step description, expected result) are filled.
     *
     * Grouping logic: iterate rows sequentially. When a row has a non-empty name column,
     * it starts a new test case. When the name column is empty, the row is a continuation
     * step belonging to the most recently started test case.
     */
    private List<TestCase> buildTestCases(String[] headers, List<String[]> rows, Map<String, String> mapping) {
        int nameIdx = findMappedIndex(headers, mapping, "name");
        int stepDescIdx = findMappedIndex(headers, mapping, "step.description");
        int stepExpIdx = findMappedIndex(headers, mapping, "step.expected");

        if (nameIdx < 0) {
            log("WARN", "No column mapped to 'name'. Each row becomes a separate test case.");
        }

        List<TestCase> result = new ArrayList<>();
        TestCase currentTc = null;

        for (String[] row : rows) {
            String nameValue = (nameIdx >= 0 && nameIdx < row.length) ? row[nameIdx].trim() : "";
            boolean isNewTestCase = !nameValue.isEmpty();

            if (nameIdx < 0) {
                // No name column mapped: every row is its own test case
                isNewTestCase = true;
                nameValue = "Row_" + (result.size() + 1);
            }

            if (isNewTestCase) {
                // Start a new test case — read all metadata from this row
                currentTc = new TestCase();
                currentTc.name = nameValue;
                result.add(currentTc);

                for (int i = 0; i < headers.length; i++) {
                    String target = mapping.getOrDefault(headers[i].trim(), "__skip__");
                    String value = safeGet(row, i);
                    if (value.isEmpty() || "__skip__".equals(target)) continue;

                    switch (target) {
                        case "name":
                        case "step.description":
                        case "step.expected":
                        case "step.name":
                            break; // handled separately
                        case "description":
                            currentTc.description = value;
                            break;
                        case "precondition":
                            currentTc.precondition = value;
                            break;
                        default:
                            currentTc.properties.put(target, value);
                            break;
                    }
                }
            }

            // Add step data from every row (including the first row of each test case)
            if (currentTc != null) {
                String stepDesc = safeGet(row, stepDescIdx);
                String stepExp = safeGet(row, stepExpIdx);
                if (!stepDesc.isEmpty() || !stepExp.isEmpty()) {
                    TestStep step = new TestStep();
                    step.description = stepDesc;
                    step.expected = stepExp;
                    currentTc.steps.add(step);
                }
            }
        }

        log("INFO", result.size() + " test case(s) built from " + rows.size() + " row(s)");
        return result;
    }

    // ========================================================================
    // Payload Builder & Validation
    // ========================================================================

    private JsonObject buildPayload(TestCase tc) {
        JsonObject obj = new JsonObject();
        obj.addProperty("name", tc.name);
        if (!tc.description.isEmpty()) obj.addProperty("description", tc.description);
        if (!tc.precondition.isEmpty()) obj.addProperty("precondition", tc.precondition);
        if (parentModuleId != null) obj.addProperty("parent_id", parentModuleId);

        if (!tc.properties.isEmpty()) {
            JsonArray props = new JsonArray();
            for (Map.Entry<String, String> entry : tc.properties.entrySet()) {
                FieldDef fd = findFieldDef(entry.getKey());
                if (fd == null) continue;

                JsonObject prop = new JsonObject();
                prop.addProperty("field_id", Long.parseLong(fd.id));
                String resolved = resolveAllowedValue(fd, entry.getValue());
                String finalValue = resolved != null ? resolved : entry.getValue();

                if (fd.multiple && finalValue.matches("-?\\d+")) {
                    JsonArray arr = new JsonArray();
                    arr.add(Long.parseLong(finalValue));
                    prop.add("field_value", arr);
                } else if (finalValue.matches("-?\\d+")) {
                    prop.addProperty("field_value", Long.parseLong(finalValue));
                } else {
                    prop.addProperty("field_value", finalValue);
                }
                props.add(prop);
            }
            if (props.size() > 0) obj.add("properties", props);
        }

        if (!tc.steps.isEmpty()) {
            JsonArray steps = new JsonArray();
            for (int i = 0; i < tc.steps.size(); i++) {
                TestStep s = tc.steps.get(i);
                JsonObject step = new JsonObject();
                step.addProperty("description", s.description);
                step.addProperty("expected", s.expected);
                step.addProperty("order", i + 1);
                steps.add(step);
            }
            obj.add("test_steps", steps);
        }
        return obj;
    }

    private List<String> validate(TestCase tc) {
        List<String> errors = new ArrayList<>();
        if (tc.name.isEmpty()) errors.add("Name is empty");
        if (tc.name.length() > 500) errors.add("Name exceeds 500 characters");

        for (Map.Entry<String, String> e : tc.properties.entrySet()) {
            FieldDef fd = findFieldDef(e.getKey());
            if (fd == null) {
                errors.add("Unknown field: '" + e.getKey() + "'");
            } else if (!fd.allowedValues.isEmpty() && resolveAllowedValue(fd, e.getValue()) == null) {
                String available = fd.allowedValues.stream()
                    .map(v -> v.label).limit(8).collect(Collectors.joining(", "));
                errors.add("Cannot resolve '" + e.getValue() + "' for field '" + fd.label
                    + "'. Available: " + available);
            }
        }

        if (fieldDefs != null) {
            for (FieldDef fd : fieldDefs) {
                if (fd.required && !fd.label.equalsIgnoreCase("Name")
                    && !tc.properties.containsKey(fd.label)) {
                    errors.add("Required field missing: " + fd.label);
                }
            }
        }
        return errors;
    }

    // ========================================================================
    // File Readers: Excel (.xlsx, .xls) and CSV
    // ========================================================================

    private List<String[]> readFile(String path) throws Exception {
        File file = new File(path);
        if (!file.exists()) throw new Exception("File not found: " + path);

        String name = file.getName().toLowerCase();
        if (name.endsWith(".xlsx")) return readExcel(file);
        if (name.endsWith(".xls")) return readExcel(file);
        if (name.endsWith(".csv")) return readCsv(file, ',');
        if (name.endsWith(".tsv")) return readCsv(file, '\t');
        throw new Exception("Unsupported format. Use .xlsx, .xls, or .csv");
    }

    private List<String[]> readExcel(File file) throws Exception {
        log("INFO", "Reading: " + file.getName());
        List<String[]> rows = new ArrayList<>();

        try (Workbook wb = WorkbookFactory.create(file)) {
            Sheet sheet = wb.getSheetAt(0);
            DataFormatter fmt = new DataFormatter();

            for (Row row : sheet) {
                int lastCol = row.getLastCellNum();
                if (lastCol < 0) continue;

                String[] values = new String[lastCol];
                boolean hasData = false;
                for (int c = 0; c < lastCol; c++) {
                    Cell cell = row.getCell(c, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                    values[c] = (cell != null) ? fmt.formatCellValue(cell).trim() : "";
                    if (!values[c].isEmpty()) hasData = true;
                }
                if (hasData) rows.add(values);
            }
        }

        log("INFO", "Read " + rows.size() + " row(s)");
        return rows;
    }

    private List<String[]> readCsv(File file, char delim) throws Exception {
        log("INFO", "Reading: " + file.getName());
        List<String[]> rows = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            List<String> fields = new ArrayList<>();
            StringBuilder current = new StringBuilder();
            boolean inQuotes = false;
            int ch;

            while ((ch = br.read()) != -1) {
                char c = (char) ch;
                if (inQuotes) {
                    if (c == '"') {
                        int next = br.read();
                        if (next == '"') {
                            current.append('"');
                        } else {
                            inQuotes = false;
                            if (next == -1 || (char) next == '\n') {
                                fields.add(current.toString());
                                rows.add(fields.toArray(new String[0]));
                                fields = new ArrayList<>();
                                current = new StringBuilder();
                            } else if ((char) next == '\r') {
                                br.read(); // consume LF after CR
                                fields.add(current.toString());
                                rows.add(fields.toArray(new String[0]));
                                fields = new ArrayList<>();
                                current = new StringBuilder();
                            } else if ((char) next == delim) {
                                fields.add(current.toString());
                                current = new StringBuilder();
                            } else {
                                current.append((char) next);
                            }
                        }
                    } else {
                        current.append(c);
                    }
                } else {
                    if (c == '"') {
                        inQuotes = true;
                    } else if (c == delim) {
                        fields.add(current.toString());
                        current = new StringBuilder();
                    } else if (c == '\n') {
                        fields.add(current.toString());
                        rows.add(fields.toArray(new String[0]));
                        fields = new ArrayList<>();
                        current = new StringBuilder();
                    } else if (c == '\r') {
                        br.read(); // consume LF
                        fields.add(current.toString());
                        rows.add(fields.toArray(new String[0]));
                        fields = new ArrayList<>();
                        current = new StringBuilder();
                    } else {
                        current.append(c);
                    }
                }
            }
            if (!current.toString().isEmpty() || !fields.isEmpty()) {
                fields.add(current.toString());
                rows.add(fields.toArray(new String[0]));
            }
        }

        log("INFO", "Read " + rows.size() + " row(s)");
        return rows;
    }

    // ========================================================================
    // Utilities
    // ========================================================================

    private int findMappedIndex(String[] headers, Map<String, String> mapping, String target) {
        for (int i = 0; i < headers.length; i++) {
            if (target.equals(mapping.getOrDefault(headers[i].trim(), ""))) return i;
        }
        return -1;
    }

    private String safeGet(String[] row, int idx) {
        return (idx >= 0 && idx < row.length) ? row[idx].trim() : "";
    }

    /**
     * Safely extracts a JSON value as string, handling numbers, booleans, and nulls.
     */
    private static String getJsonVal(JsonObject obj, String key) {
        if (!obj.has(key) || obj.get(key).isJsonNull()) return "";
        JsonElement el = obj.get(key);
        if (el.isJsonPrimitive()) return el.getAsString();
        return el.toString();
    }

    private static String truncate(String s, int n) {
        return (s == null || s.length() <= n) ? s : s.substring(0, n - 3) + "...";
    }

    private static String nowStr() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }

    private static String readLine() throws IOException {
        if (System.console() != null) return System.console().readLine().trim();
        return new BufferedReader(new InputStreamReader(System.in)).readLine().trim();
    }

    private static void log(String level, String msg) {
        String ts = new SimpleDateFormat("HH:mm:ss").format(new Date());
        String color;
        switch (level) {
            case "OK": case "DONE": color = "\033[32m"; break;
            case "ERROR": color = "\033[31m"; break;
            case "WARN": color = "\033[33m"; break;
            case "DRY-RUN": color = "\033[36m"; break;
            case "CONFIRM": color = "\033[35m"; break;
            default: color = "\033[0m"; break;
        }
        System.out.printf("%s [%s%-7s\033[0m] %s%n", ts, color, level, msg);
    }

    private static void printBanner() {
        System.out.println();
        System.out.println("  qTest Test Case Importer v" + VERSION);
        System.out.println("  --------------------------------");
        System.out.println();
    }

    private static void printUsage() {
        System.out.println("  Commands:");
        System.out.println("    generate-config           Create configuration file");
        System.out.println("    login                     Authenticate and get bearer token");
        System.out.println("    test-connection            Verify connectivity");
        System.out.println("    list-projects              List available projects");
        System.out.println("    list-fields                List test case field definitions");
        System.out.println("    list-modules               List module/folder tree");
        System.out.println("    dry-run <file.xlsx|csv>    Validate without importing");
        System.out.println("    import  <file.xlsx|csv>    Import test cases");
        System.out.println();
        System.out.println("  Options:");
        System.out.println("    --config <file>            Config file (default: qtest-config.properties)");
        System.out.println();
    }

    // ========================================================================
    // Data Classes
    // ========================================================================

    static class FieldDef {
        String id;
        String label;
        boolean required;
        boolean multiple;
        List<AllowedValue> allowedValues = new ArrayList<>();
    }

    static class AllowedValue {
        String label;
        String value;
    }

    static class TestCase {
        String name = "";
        String description = "";
        String precondition = "";
        Map<String, String> properties = new LinkedHashMap<>();
        List<TestStep> steps = new ArrayList<>();
    }

    static class TestStep {
        String description = "";
        String expected = "";
    }
}
