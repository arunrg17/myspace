package com.doccompare;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

/**
 * Unit tests for core comparison logic.
 * No file I/O — tests the algorithm in isolation.
 */
public class PDFComparatorTest {

    // ── Diff algorithm ────────────────────────────────────────────────────

    @Test
    public void testIdenticalArraysProduceNoDiff() {
        String[] a = { "line one", "line two", "line three" };
        String[] b = { "line one", "line two", "line three" };
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long diffs = diff.stream().filter(r -> r.type != PDFComparator.DiffType.SAME).count();
        assertEquals("Identical inputs should produce zero diffs", 0, diffs);
    }

    @Test
    public void testAddedLineDetected() {
        String[] a = { "alpha", "gamma" };
        String[] b = { "alpha", "beta", "gamma" };
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long added = diff.stream().filter(r -> r.type == PDFComparator.DiffType.ADDED).count();
        assertEquals("One line added", 1, added);
    }

    @Test
    public void testRemovedLineDetected() {
        String[] a = { "alpha", "beta", "gamma" };
        String[] b = { "alpha", "gamma" };
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long removed = diff.stream().filter(r -> r.type == PDFComparator.DiffType.REMOVED).count();
        assertEquals("One line removed", 1, removed);
    }

    @Test
    public void testChangedLineDetected() {
        String[] a = { "Rate: $100 per hour" };
        String[] b = { "Rate: $150 per hour" };
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long changed = diff.stream().filter(r -> r.type == PDFComparator.DiffType.CHANGED).count();
        assertEquals("One line changed", 1, changed);
    }

    @Test
    public void testEmptyArraysProduceEmptyDiff() {
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(new String[0], new String[0]);
        assertTrue("Empty diff for empty inputs", diff.isEmpty());
    }

    @Test
    public void testLineNumbersAreCorrect() {
        String[] a = { "a", "b", "c" };
        String[] b = { "a", "X", "c" };
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        // Find the changed row
        PDFComparator.DiffRow changed = diff.stream()
            .filter(r -> r.type == PDFComparator.DiffType.CHANGED)
            .findFirst().orElse(null);
        assertNotNull("Changed row should exist", changed);
        assertEquals("Left line number should be 2", 2, changed.leftLineNo);
        assertEquals("Right line number should be 2", 2, changed.rightLineNo);
    }

    // ── Word diff ─────────────────────────────────────────────────────────

    @Test
    public void testWordDiffMarksOnlyChangedWords() {
        String[] result = PDFComparator.wordDiff("Rate: $100 per hour", "Rate: $150 per hour");
        assertTrue("Left should contain mark around 100",  result[0].contains("<mark>100</mark>"));
        assertTrue("Right should contain mark around 150", result[1].contains("<mark>150</mark>"));
        assertTrue("'Rate:' should not be marked in left",  !result[0].contains("<mark>Rate</mark>"));
        assertTrue("'Rate:' should not be marked in right", !result[1].contains("<mark>Rate</mark>"));
    }

    @Test
    public void testWordDiffIdenticalStringsProduceNoMarks() {
        String[] result = PDFComparator.wordDiff("hello world", "hello world");
        assertFalse("No marks expected for identical input", result[0].contains("<mark>"));
        assertFalse("No marks expected for identical input", result[1].contains("<mark>"));
    }

    // ── HTML escaping ─────────────────────────────────────────────────────

    @Test
    public void testEscapeAmpersand() {
        assertEquals("&amp;", PDFComparator.escHtml("&"));
    }

    @Test
    public void testEscapeLtGt() {
        assertEquals("&lt;tag&gt;", PDFComparator.escHtml("<tag>"));
    }

    @Test
    public void testEscapeQuote() {
        assertEquals("&quot;", PDFComparator.escHtml("\""));
    }

    @Test
    public void testEscapeNull() {
        assertEquals("", PDFComparator.escHtml(null));
    }

    @Test
    public void testEscapeXssAttempt() {
        String xss = "<script>alert('xss')</script>";
        String escaped = PDFComparator.escHtml(xss);
        assertFalse("Escaped output must not contain <script>", escaped.contains("<script>"));
    }

    // ── FilterConfig ──────────────────────────────────────────────────────

    @Test
    public void testFilterConfigBuildsSuccessfully() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("out.html")
            .ignoreHeader(true).ignoreFooter(true)
            .ignoreMargins(true).ignoreTimestamps(true)
            .headerPct(15).footerPct(12).marginPct(10)
            .build();
        assertTrue(cfg.isIgnoreHeader());
        assertTrue(cfg.isIgnoreFooter());
        assertTrue(cfg.isIgnoreLeftMargin());
        assertTrue(cfg.isIgnoreRightMargin());
        assertTrue(cfg.isIgnoreTimestamps());
        assertEquals(15.0, cfg.getHeaderPct(), 0.001);
        assertEquals(12.0, cfg.getFooterPct(), 0.001);
        assertEquals(10.0, cfg.getMarginPct(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFilterConfigRequiresPdf1() {
        new FilterConfig.Builder().pdf2("b.pdf").output("out.html").build();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFilterConfigRequiresPdf2() {
        new FilterConfig.Builder().pdf1("a.pdf").output("out.html").build();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testFilterConfigRequiresOutput() {
        new FilterConfig.Builder().pdf1("a.pdf").pdf2("b.pdf").build();
    }

    @Test
    public void testHeaderPctIsClamped() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .headerPct(99) // over max
            .build();
        assertTrue("Header pct should be clamped to max 49", cfg.getHeaderPct() <= 49.0);
    }

    // ── ProcessLine (content filters) ─────────────────────────────────────

    @Test
    public void testProcessLineDropsPageNumbers() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .ignorePageNumbers(true).build();
        assertNull("Bare page number should be dropped", cfg.processLine("5"));
        assertNull("'Page 3 of 10' should be dropped",  cfg.processLine("Page 3 of 10"));
        assertNotNull("Normal content should be kept",   cfg.processLine("Some content here"));
    }

    @Test
    public void testProcessLineStripsTimestamps() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .ignoreTimestamps(true).build();
        String result = cfg.processLine("Report generated on 2024-01-15T14:30:00");
        assertNotNull(result);
        assertFalse("Timestamp should be stripped", result.contains("2024-01-15"));
    }

    @Test
    public void testProcessLineCustomPattern() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .ignorePattern("DRAFT").build();
        String result = cfg.processLine("Content DRAFT version");
        assertNotNull(result);
        assertFalse("DRAFT should be stripped", result.contains("DRAFT"));
    }

    // ── CLI arg parsing ───────────────────────────────────────────────────

    @Test
    public void testCliMissingArgsFails() {
        int code = PDFComparator.runCli(new String[]{ "only-one.pdf" });
        assertEquals("Missing args should return EXIT_ERROR", PDFComparator.EXIT_ERROR, code);
    }

    @Test
    public void testCliNonExistentFileFails() {
        int code = PDFComparator.runCli(new String[]{
            "nonexistent1.pdf", "nonexistent2.pdf", "out.html"
        });
        assertEquals("Non-existent file should return EXIT_ERROR", PDFComparator.EXIT_ERROR, code);
    }
}
