package com.doccompare;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Builds a self-contained HTML comparison report.
 *
 * <h2>Security guarantees</h2>
 * <ul>
 *   <li>All file-derived content is HTML-escaped before insertion.</li>
 *   <li>No external URLs — all CSS and JavaScript are inline.</li>
 *   <li>No {@code <script src>}, no {@code <link href>}, no {@code <img src>},
 *       no fetch/XHR calls in the embedded JavaScript.</li>
 *   <li>Content Security Policy meta tag is set to block any external loads.</li>
 * </ul>
 */
final class HtmlReportBuilder {

    private HtmlReportBuilder() {}

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    static String build(
            List<PDFComparator.DiffRow> diff,
            String file1Name, String file2Name,
            FilterConfig config,
            int totalLinesLeft, int totalLinesRight,
            int added, int removed, int changed,
            boolean passed) {

        String ts      = LocalDateTime.now()
                           .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        int    same    = totalLinesLeft - removed - changed;
        int    total   = added + removed + changed;
        int    diffPct = totalLinesLeft > 0 ? (int) Math.round(total * 100.0 / totalLinesLeft) : 0;
        String verdict = passed ? "PASS" : "FAIL";

        StringBuilder sb = new StringBuilder(65536);

        sb.append("<!DOCTYPE html>\n")
          .append("<html lang=\"en\">\n")
          .append("<head>\n")
          .append("<meta charset=\"UTF-8\">\n")
          .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n")
          // CSP — blocks any external resource load
          .append("<meta http-equiv=\"Content-Security-Policy\" ")
          .append("content=\"default-src 'none'; style-src 'unsafe-inline'; ")
          .append("script-src 'unsafe-inline';\">\n")
          .append("<title>[").append(verdict).append("] ")
          .append(PDFComparator.escHtml(file1Name)).append(" vs ")
          .append(PDFComparator.escHtml(file2Name)).append("</title>\n")
          .append("<style>\n").append(CSS).append("</style>\n")
          .append("</head>\n<body>\n");

        // ── Sticky header ──────────────────────────────────────────────────
        sb.append("<div class=\"topbar\">\n");

        // Row 1: verdict + filenames + timestamp
        sb.append("  <div class=\"tb-row1\">\n")
          .append("    <span class=\"verdict ").append(passed ? "v-pass" : "v-fail").append("\">")
          .append(passed ? "&#10003;&nbsp;PASS" : "&#10007;&nbsp;FAIL").append("</span>\n")
          .append("    <span class=\"tb-sep\"></span>\n")
          .append("    <span class=\"tb-file tb-file-l\">")
          .append(PDFComparator.escHtml(file1Name)).append("</span>\n")
          .append("    <span class=\"tb-vs\">vs</span>\n")
          .append("    <span class=\"tb-file tb-file-r\">")
          .append(PDFComparator.escHtml(file2Name)).append("</span>\n")
          .append("    <span class=\"tb-ts\">").append(ts).append("</span>\n")
          .append("  </div>\n");

        // Row 2: stats chips
        sb.append("  <div class=\"stats-row\">\n");
        statChip(sb, "PDF\u00a01",  totalLinesLeft  + " lines", "");
        statChip(sb, "PDF\u00a02",  totalLinesRight + " lines", "");
        statChip(sb, "Added",       String.valueOf(added),   added   > 0 ? "s-fail" : "s-ok");
        statChip(sb, "Removed",     String.valueOf(removed), removed > 0 ? "s-fail" : "s-ok");
        statChip(sb, "Changed",     String.valueOf(changed), changed > 0 ? "s-warn" : "s-ok");
        statChip(sb, "Same",        String.valueOf(Math.max(same, 0)), "s-muted");
        statChip(sb, "Diff\u00a0%", diffPct + "%",           total   > 0 ? "s-fail" : "s-ok");
        sb.append("  </div>\n");

        // Row 3: active filter chips
        sb.append("  <div class=\"filter-row\">\n")
          .append("    <span class=\"fc-lbl\">Filters:</span>\n");
        buildFilterChips(sb, config);
        sb.append("  </div>\n");

        // Row 4: navigation controls
        sb.append("  <div class=\"nav-row\">\n")
          .append("    <button class=\"btn\" onclick=\"navDiff(-1)\">&#9650; Prev</button>\n")
          .append("    <span class=\"nav-pos\" id=\"navPos\"></span>\n")
          .append("    <button class=\"btn\" onclick=\"navDiff(1)\">Next &#9660;</button>\n")
          .append("    <button class=\"btn\" id=\"btnHide\" onclick=\"toggleSame()\">")
          .append("Hide unchanged</button>\n")
          .append("    <span class=\"kb\">Alt+&#8593;&#8595; to navigate</span>\n")
          .append("  </div>\n")
          .append("</div>\n");

        // ── Diff table ─────────────────────────────────────────────────────
        sb.append("<div class=\"wrap\">\n")
          .append("<table class=\"tbl\">\n")
          .append("<colgroup>")
          .append("<col class=\"c-lno\"><col class=\"c-icon\"><col class=\"c-txt\">")
          .append("<col class=\"c-lno\"><col class=\"c-icon\"><col class=\"c-txt\">")
          .append("</colgroup>\n")
          .append("<thead><tr>")
          .append("<th colspan=\"3\" class=\"th th-l\">&#9664;&nbsp;")
          .append(PDFComparator.escHtml(file1Name)).append("</th>")
          .append("<th colspan=\"3\" class=\"th th-r\">&#9654;&nbsp;")
          .append(PDFComparator.escHtml(file2Name)).append("</th>")
          .append("</tr></thead>\n")
          .append("<tbody id=\"body\">\n");

        buildDiffRows(sb, diff);

        sb.append("</tbody>\n</table>\n</div>\n");

        // ── Command footer ─────────────────────────────────────────────────
        sb.append("<div class=\"cmd-bar\">\n")
          .append("  <span class=\"cmd-lbl\">Command:</span>\n")
          .append("  <code class=\"cmd\">")
          .append(PDFComparator.escHtml(buildCommandHint(config)))
          .append("</code>\n")
          .append("</div>\n");

        // ── Inline JavaScript (navigation only — no diff logic, no network) ──
        sb.append("<script>\n").append(JS).append("\n</script>\n");

        sb.append("</body>\n</html>\n");
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DIFF ROW RENDERING
    // ════════════════════════════════════════════════════════════════════════

    private static void buildDiffRows(StringBuilder sb, List<PDFComparator.DiffRow> diff) {
        int di = 0;
        for (PDFComparator.DiffRow row : diff) {
            String cls, icon, iconCls;
            switch (row.type) {
                case ADDED:   cls = "r-add"; icon = "+";      iconCls = "i-add"; break;
                case REMOVED: cls = "r-rem"; icon = "\u2212"; iconCls = "i-rem"; break;
                case CHANGED: cls = "r-chg"; icon = "~";      iconCls = "i-chg"; break;
                default:      cls = "r-sme"; icon = "";       iconCls = "";       break;
            }

            boolean isDiff = row.type != PDFComparator.DiffType.SAME;
            sb.append("<tr class=\"").append(cls).append("\"");
            if (isDiff) sb.append(" id=\"d").append(di++).append("\"");
            sb.append(">");

            // Word-level diff for changed rows, plain escape for everything else
            String leftHtml, rightHtml;
            if (row.type == PDFComparator.DiffType.CHANGED) {
                String[] wd = PDFComparator.wordDiff(row.left, row.right);
                leftHtml  = wd[0];
                rightHtml = wd[1];
            } else {
                leftHtml  = PDFComparator.escHtml(row.left);
                rightHtml = PDFComparator.escHtml(row.right);
            }

            appendCell(sb, row.leftLineNo,  icon, iconCls, leftHtml,  row.type == PDFComparator.DiffType.ADDED);
            appendCell(sb, row.rightLineNo, icon, iconCls, rightHtml, row.type == PDFComparator.DiffType.REMOVED);
            sb.append("</tr>\n");
        }
    }

    private static void appendCell(StringBuilder sb, int lineNo, String icon,
                                    String iconCls, String html, boolean empty) {
        sb.append("<td class=\"lno\">").append(lineNo > 0 ? lineNo : "").append("</td>")
          .append("<td class=\"icon ").append(iconCls).append("\">").append(icon).append("</td>")
          .append("<td class=\"code\">");
        if (empty) {
            sb.append("<span class=\"empty\">(empty)</span>");
        } else {
            sb.append(html);
        }
        sb.append("</td>");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STAT / FILTER CHIP HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private static void statChip(StringBuilder sb, String label, String value, String cls) {
        sb.append("    <div class=\"sc ").append(cls).append("\">")
          .append("<span class=\"sc-l\">").append(label).append("</span>")
          .append("<span class=\"sc-v\">").append(value).append("</span>")
          .append("</div>\n");
    }

    private static void buildFilterChips(StringBuilder sb, FilterConfig config) {
        List<String[]> chips = new ArrayList<>(); // [label, cssClass]
        if (config.isIgnoreHeader())
            chips.add(new String[]{ "&#8679; header " + (int) config.getHeaderPct() + "%", "fc-zone" });
        if (config.isIgnoreFooter())
            chips.add(new String[]{ "&#8681; footer " + (int) config.getFooterPct() + "%", "fc-zone" });
        if (config.isIgnoreLeftMargin())
            chips.add(new String[]{ "&#8678; left " + (int) config.getMarginPct() + "%", "fc-zone" });
        if (config.isIgnoreRightMargin())
            chips.add(new String[]{ "&#8680; right " + (int) config.getMarginPct() + "%", "fc-zone" });
        if (config.isIgnoreTimestamps())
            chips.add(new String[]{ "timestamps", "fc-content" });
        if (config.isIgnorePageNumbers())
            chips.add(new String[]{ "page-numbers", "fc-content" });
        for (java.util.regex.Pattern p : config.getCustomPatterns())
            chips.add(new String[]{ "/ " + PDFComparator.escHtml(p.pattern()), "fc-custom" });

        if (chips.isEmpty()) {
            sb.append("    <span class=\"fc fc-none\">none &mdash; full content compared</span>\n");
        } else {
            for (String[] chip : chips) {
                sb.append("    <span class=\"fc ").append(chip[1]).append("\">")
                  .append(chip[0]).append("</span>\n");
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  COMMAND HINT (shown in report footer for traceability)
    // ════════════════════════════════════════════════════════════════════════

    private static String buildCommandHint(FilterConfig config) {
        StringBuilder sb = new StringBuilder("java -jar doc-compare.jar ")
            .append(config.getPdf1Path()).append(" ")
            .append(config.getPdf2Path()).append(" ")
            .append(config.getOutputPath());
        if (config.isIgnoreHeader())       sb.append(" --ignore-header");
        if (config.getHeaderPct() != 10.0) sb.append(" --header-pct=").append((int) config.getHeaderPct());
        if (config.isIgnoreFooter())       sb.append(" --ignore-footer");
        if (config.getFooterPct() != 10.0) sb.append(" --footer-pct=").append((int) config.getFooterPct());
        if (config.isIgnoreLeftMargin() && config.isIgnoreRightMargin()) sb.append(" --ignore-margins");
        else {
            if (config.isIgnoreLeftMargin())  sb.append(" --ignore-left-margin");
            if (config.isIgnoreRightMargin()) sb.append(" --ignore-right-margin");
        }
        if (config.getMarginPct() != 8.0)  sb.append(" --margin-pct=").append((int) config.getMarginPct());
        if (config.isIgnoreTimestamps())    sb.append(" --ignore-timestamps");
        if (config.isIgnorePageNumbers())   sb.append(" --ignore-page-numbers");
        for (java.util.regex.Pattern p : config.getCustomPatterns())
            sb.append(" --ignore-pattern=").append(p.pattern());
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  INLINE CSS  — zero external references
    // ════════════════════════════════════════════════════════════════════════

    private static final String CSS =
        ":root{--c-add:#c8e6c9;--c-rem:#ffcdd2;--c-chl:#fff3e0;--c-chr:#f1f8e9;" +
        "--c-sme:#fafafa;--c-bdr:#e0e0e0;--c-bar-a:#43a047;--c-bar-r:#e53935;" +
        "--c-bar-c:#fb8c00;--c-lno:#b0bec5;}\n" +
        "*{box-sizing:border-box;margin:0;padding:0;}\n" +
        "body{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;background:#f4f4f4;" +
        "color:#212121;}\n" +
        /* ── Top bar ── */
        ".topbar{position:sticky;top:0;z-index:100;background:#263238;color:#fff;" +
        "padding:8px 16px 5px;box-shadow:0 2px 8px rgba(0,0,0,.45);}\n" +
        ".tb-row1{display:flex;align-items:center;gap:10px;margin-bottom:5px;flex-wrap:wrap;}\n" +
        ".verdict{font-size:14px;font-weight:700;padding:2px 12px;border-radius:4px;" +
        "white-space:nowrap;flex-shrink:0;}\n" +
        ".v-pass{background:#1b5e20;color:#c8e6c9;}\n" +
        ".v-fail{background:#b71c1c;color:#ffcdd2;}\n" +
        ".tb-sep{flex:1;}\n" +
        ".tb-file{font-size:12px;font-weight:500;max-width:260px;" +
        "overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}\n" +
        ".tb-file-l{color:#80cbc4;}.tb-file-r{color:#a5d6a7;}\n" +
        ".tb-vs{font-size:11px;color:#546e7a;}\n" +
        ".tb-ts{font-size:11px;color:#546e7a;margin-left:auto;white-space:nowrap;}\n" +
        /* ── Stats row ── */
        ".stats-row{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:5px;}\n" +
        ".sc{background:rgba(255,255,255,.1);border-radius:4px;padding:2px 9px;" +
        "display:flex;flex-direction:column;align-items:center;min-width:55px;}\n" +
        ".sc-l{font-size:9px;color:#90a4ae;text-transform:uppercase;letter-spacing:.4px;}\n" +
        ".sc-v{font-size:15px;font-weight:600;color:#fff;line-height:1.2;}\n" +
        ".s-fail .sc-v{color:#ef9a9a;}.s-warn .sc-v{color:#ffcc80;}" +
        ".s-ok   .sc-v{color:#a5d6a7;}.s-muted .sc-v{color:#78909c;}\n" +
        /* ── Filter chips ── */
        ".filter-row{display:flex;align-items:center;gap:4px;flex-wrap:wrap;margin-bottom:5px;}\n" +
        ".fc-lbl{font-size:10px;color:#78909c;}\n" +
        ".fc{display:inline-block;border-radius:9px;padding:1px 8px;font-size:10px;font-weight:500;}\n" +
        ".fc-zone{background:#1a237e;color:#c5cae9;}\n" +
        ".fc-content{background:#e65100;color:#ffe0b2;}\n" +
        ".fc-custom{background:#4a148c;color:#e1bee7;}\n" +
        ".fc-none{background:#37474f;color:#90a4ae;}\n" +
        /* ── Nav row ── */
        ".nav-row{display:flex;align-items:center;gap:6px;flex-wrap:wrap;}\n" +
        ".btn{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);" +
        "color:#fff;padding:3px 11px;border-radius:4px;cursor:pointer;font-size:12px;}\n" +
        ".btn:hover{background:rgba(255,255,255,.22);}\n" +
        ".btn.on{background:#e65100;border-color:#bf360c;}\n" +
        ".nav-pos{font-size:12px;color:#90a4ae;min-width:52px;text-align:center;}\n" +
        ".kb{font-size:10px;color:#546e7a;margin-left:4px;}\n" +
        /* ── Diff table ── */
        ".wrap{overflow-x:auto;}\n" +
        ".tbl{width:100%;border-collapse:collapse;table-layout:fixed;min-width:680px;}\n" +
        ".c-lno{width:40px;}.c-icon{width:18px;}.c-txt{width:calc(50% - 58px - 9px);}\n" +
        ".th{padding:6px 12px;font-size:12px;font-weight:600;color:#fff;" +
        "position:sticky;top:0;z-index:5;border-bottom:2px solid rgba(255,255,255,.15);}\n" +
        ".th-l{background:#37474f;}.th-r{background:#263238;border-left:3px solid #455a64;}\n" +
        "tbody tr td{border-bottom:1px solid var(--c-bdr);vertical-align:top;padding:1px 0;}\n" +
        ".lno{font-family:monospace;font-size:10px;color:var(--c-lno);text-align:right;" +
        "padding:2px 4px 2px 2px;user-select:none;white-space:nowrap;}\n" +
        ".icon{font-family:monospace;font-size:11px;font-weight:700;text-align:center;" +
        "padding:0 1px;user-select:none;width:18px;}\n" +
        ".i-add{color:#2e7d32;}.i-rem{color:#c62828;}.i-chg{color:#e65c00;}\n" +
        ".code{font-family:Consolas,'Courier New',monospace;font-size:11.5px;" +
        "padding:2px 7px;word-break:break-all;white-space:pre-wrap;}\n" +
        ".empty{color:#bdbdbd;font-style:italic;font-size:10px;}\n" +
        /* ── Row colours ── */
        ".r-sme td{background:var(--c-sme);}\n" +
        ".r-sme.h{display:none;}\n" +
        ".r-add td:nth-child(-n+3){background:#fafafa;}\n" +
        ".r-add td:nth-child(n+4){background:var(--c-add);}\n" +
        ".r-add td:nth-child(4){border-left:3px solid var(--c-bar-a);}\n" +
        ".r-rem td:nth-child(-n+3){background:var(--c-rem);}\n" +
        ".r-rem td:nth-child(1){border-left:3px solid var(--c-bar-r);}\n" +
        ".r-rem td:nth-child(n+4){background:#fafafa;}\n" +
        ".r-chg td:nth-child(-n+3){background:var(--c-chl);}\n" +
        ".r-chg td:nth-child(1){border-left:3px solid var(--c-bar-c);}\n" +
        ".r-chg td:nth-child(n+4){background:var(--c-chr);}\n" +
        ".r-chg td:nth-child(4){border-left:3px solid var(--c-bar-c);}\n" +
        "mark{background:#ffe082;color:#5d4037;border-radius:2px;padding:0 1px;}\n" +
        ".r-add mark{background:#a5d6a7;color:#1b5e20;}\n" +
        ".r-rem mark{background:#ef9a9a;color:#7f0000;}\n" +
        ".hl{outline:2px solid #ff6f00;outline-offset:-1px;}\n" +
        /* ── Command footer ── */
        ".cmd-bar{background:#fff;border-top:1px solid var(--c-bdr);padding:8px 14px;" +
        "display:flex;align-items:flex-start;gap:8px;}\n" +
        ".cmd-lbl{font-size:11px;color:#9e9e9e;white-space:nowrap;padding-top:2px;}\n" +
        ".cmd{font-family:monospace;font-size:11px;color:#424242;background:#f5f5f5;" +
        "padding:3px 7px;border-radius:3px;border:1px solid #e0e0e0;word-break:break-all;flex:1;}\n";

    // ════════════════════════════════════════════════════════════════════════
    //  INLINE JAVASCRIPT — navigation only, no network calls, no eval()
    // ════════════════════════════════════════════════════════════════════════

    private static final String JS =
        "(function(){\n" +
        "  'use strict';\n" +
        "  var diffs = Array.from(document.querySelectorAll('#body tr[id]'));\n" +
        "  var cur = -1;\n" +
        "  var sameVisible = true;\n" +
        "  var navPos = document.getElementById('navPos');\n" +
        "  function updateNav() {\n" +
        "    navPos.textContent = diffs.length === 0\n" +
        "      ? 'no diffs' : (cur + 1) + ' / ' + diffs.length;\n" +
        "  }\n" +
        "  updateNav();\n" +
        "  window.navDiff = function(dir) {\n" +
        "    if (!diffs.length) return;\n" +
        "    if (cur >= 0) diffs[cur].classList.remove('hl');\n" +
        "    cur = (cur + dir + diffs.length) % diffs.length;\n" +
        "    diffs[cur].classList.add('hl');\n" +
        "    diffs[cur].scrollIntoView({ behavior: 'smooth', block: 'center' });\n" +
        "    updateNav();\n" +
        "  };\n" +
        "  window.toggleSame = function() {\n" +
        "    sameVisible = !sameVisible;\n" +
        "    document.querySelectorAll('.r-sme').forEach(function(r) {\n" +
        "      r.classList.toggle('h', !sameVisible);\n" +
        "    });\n" +
        "    var btn = document.getElementById('btnHide');\n" +
        "    btn.textContent = sameVisible ? 'Hide unchanged' : 'Show unchanged';\n" +
        "    btn.classList.toggle('on', !sameVisible);\n" +
        "  };\n" +
        "  document.addEventListener('keydown', function(e) {\n" +
        "    if (e.altKey && e.key === 'ArrowDown') { e.preventDefault(); navDiff(1);  }\n" +
        "    if (e.altKey && e.key === 'ArrowUp')   { e.preventDefault(); navDiff(-1); }\n" +
        "  });\n" +
        "}());\n";
}
