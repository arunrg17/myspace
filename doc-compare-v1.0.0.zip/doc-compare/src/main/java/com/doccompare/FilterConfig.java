package com.doccompare;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Immutable configuration for a PDF comparison run.
 *
 * <p>Create instances via {@link Builder}:
 * <pre>
 *   FilterConfig config = new FilterConfig.Builder()
 *       .pdf1("C:/reports/env1.pdf")
 *       .pdf2("C:/reports/env2.pdf")
 *       .output("C:/reports/comparison.html")
 *       .ignoreHeader(true)
 *       .ignoreFooter(true)
 *       .ignoreMargins(true)
 *       .ignoreTimestamps(true)
 *       .build();
 * </pre>
 *
 * <p>All zone percentages are clamped to safe ranges at build time.
 * No external connections are made at any point.
 */
public final class FilterConfig {

    // ── File paths ──────────────────────────────────────────────────────────
    private final String pdf1Path;
    private final String pdf2Path;
    private final String outputPath;

    // ── Spatial zone flags ──────────────────────────────────────────────────
    private final boolean ignoreHeader;
    private final boolean ignoreFooter;
    private final boolean ignoreLeftMargin;
    private final boolean ignoreRightMargin;
    private final double  headerPct;   // % from top of page to exclude
    private final double  footerPct;   // % from bottom of page to exclude
    private final double  marginPct;   // % from each side to exclude

    // ── Content filter flags ────────────────────────────────────────────────
    private final boolean        ignoreTimestamps;
    private final boolean        ignorePageNumbers;
    private final List<Pattern>  customPatterns;  // unmodifiable

    // ── Built-in patterns (compiled once, never recompiled) ─────────────────

    /** Timestamp / date patterns — covers ISO, slash, word-month, time, labelled */
    static final Pattern[] TIMESTAMP_PATTERNS = {
        Pattern.compile("\\b\\d{4}-\\d{2}-\\d{2}[T ]\\d{2}:\\d{2}(:\\d{2})?\\b"),
        Pattern.compile("\\b\\d{1,2}[/\\-]\\d{1,2}[/\\-]\\d{2,4}\\b"),
        Pattern.compile("\\b(\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{4}|[A-Za-z]{3,9}\\s+\\d{1,2},?\\s+\\d{4})\\b"),
        Pattern.compile("\\b\\d{1,2}:\\d{2}(:\\d{2})?\\s*(AM|PM)?\\b", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?i)(printed|generated|created|issued|date|timestamp)[:\\s]+[\\d\\w/\\-:,\\s]{4,40}"),
    };

    /** Page-number-only line patterns */
    static final Pattern[] PAGE_NUMBER_PATTERNS = {
        Pattern.compile("(?i)^\\s*page\\s+\\d+(\\s+of\\s+\\d+)?\\s*$"),
        Pattern.compile("^\\s*\\d+\\s*/\\s*\\d+\\s*$"),
        Pattern.compile("^\\s*[-\u2013]\\s*\\d+\\s*[-\u2013]\\s*$"),
        Pattern.compile("^\\s*\\d+\\s*$"),
    };

    // ── Private constructor — use Builder ───────────────────────────────────

    private FilterConfig(Builder b) {
        this.pdf1Path         = b.pdf1Path;
        this.pdf2Path         = b.pdf2Path;
        this.outputPath       = b.outputPath;
        this.ignoreHeader     = b.ignoreHeader;
        this.ignoreFooter     = b.ignoreFooter;
        this.ignoreLeftMargin = b.ignoreLeftMargin;
        this.ignoreRightMargin= b.ignoreRightMargin;
        this.headerPct        = clamp(b.headerPct,  1.0, 49.0);
        this.footerPct        = clamp(b.footerPct,  1.0, 49.0);
        this.marginPct        = clamp(b.marginPct,  1.0, 30.0);
        this.ignoreTimestamps = b.ignoreTimestamps;
        this.ignorePageNumbers= b.ignorePageNumbers;
        this.customPatterns   = Collections.unmodifiableList(new ArrayList<>(b.customPatterns));
    }

    // ── Accessors ────────────────────────────────────────────────────────────

    public String  getPdf1Path()          { return pdf1Path; }
    public String  getPdf2Path()          { return pdf2Path; }
    public String  getOutputPath()        { return outputPath; }
    public boolean isIgnoreHeader()       { return ignoreHeader; }
    public boolean isIgnoreFooter()       { return ignoreFooter; }
    public boolean isIgnoreLeftMargin()   { return ignoreLeftMargin; }
    public boolean isIgnoreRightMargin()  { return ignoreRightMargin; }
    public double  getHeaderPct()         { return headerPct; }
    public double  getFooterPct()         { return footerPct; }
    public double  getMarginPct()         { return marginPct; }
    public boolean isIgnoreTimestamps()   { return ignoreTimestamps; }
    public boolean isIgnorePageNumbers()  { return ignorePageNumbers; }
    public List<Pattern> getCustomPatterns() { return customPatterns; }

    /**
     * Apply content-level filters to a single extracted text line.
     *
     * @param line raw text line
     * @return filtered line, or {@code null} if the line should be dropped entirely
     */
    public String processLine(String line) {
        if (line == null) return null;
        String trimmed = line.trim();

        // Drop the whole line if it is only a page number
        if (ignorePageNumbers) {
            for (Pattern p : PAGE_NUMBER_PATTERNS) {
                if (p.matcher(trimmed).matches()) return null;
            }
        }

        // Strip timestamp sub-strings in place
        String result = line;
        if (ignoreTimestamps) {
            for (Pattern p : TIMESTAMP_PATTERNS) {
                result = p.matcher(result).replaceAll("");
            }
        }

        // Strip custom pattern matches in place
        for (Pattern p : customPatterns) {
            result = p.matcher(result).replaceAll("");
        }

        return result.trim().isEmpty() ? null : result;
    }

    /** Human-readable summary of active filters — used in the HTML report header. */
    public String summary() {
        List<String> parts = new ArrayList<>();
        if (ignoreHeader)       parts.add("header " + (int) headerPct + "%");
        if (ignoreFooter)       parts.add("footer " + (int) footerPct + "%");
        if (ignoreLeftMargin)   parts.add("left-margin " + (int) marginPct + "%");
        if (ignoreRightMargin)  parts.add("right-margin " + (int) marginPct + "%");
        if (ignoreTimestamps)   parts.add("timestamps");
        if (ignorePageNumbers)  parts.add("page-numbers");
        for (Pattern p : customPatterns) parts.add("pattern:" + p.pattern());
        return parts.isEmpty() ? "none" : String.join("  |  ", parts);
    }

    // ── Utility ──────────────────────────────────────────────────────────────

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BUILDER
    // ════════════════════════════════════════════════════════════════════════

    public static final class Builder {

        // Required
        private String pdf1Path;
        private String pdf2Path;
        private String outputPath;

        // Spatial zones — off by default
        private boolean ignoreHeader      = false;
        private boolean ignoreFooter      = false;
        private boolean ignoreLeftMargin  = false;
        private boolean ignoreRightMargin = false;
        private double  headerPct         = 10.0;
        private double  footerPct         = 10.0;
        private double  marginPct         = 8.0;

        // Content filters — off by default
        private boolean       ignoreTimestamps  = false;
        private boolean       ignorePageNumbers = false;
        private List<Pattern> customPatterns    = new ArrayList<>();

        /** Path to the first (baseline) PDF. */
        public Builder pdf1(String path) { this.pdf1Path = path; return this; }

        /** Path to the second (comparison) PDF. */
        public Builder pdf2(String path) { this.pdf2Path = path; return this; }

        /** Path where the HTML report will be written. Parent directory is created if absent. */
        public Builder output(String path) { this.outputPath = path; return this; }

        /** Ignore the top N% of each page (headers, logos, letterhead). Default N=10. */
        public Builder ignoreHeader(boolean v) { this.ignoreHeader = v; return this; }

        /** Ignore the bottom N% of each page (footers, page numbers). Default N=10. */
        public Builder ignoreFooter(boolean v) { this.ignoreFooter = v; return this; }

        /** Ignore the left N% of each page (vertical timestamps, binding marks). Default N=8. */
        public Builder ignoreLeftMargin(boolean v) { this.ignoreLeftMargin = v; return this; }

        /** Ignore the right N% of each page (vertical watermarks, border text). Default N=8. */
        public Builder ignoreRightMargin(boolean v) { this.ignoreRightMargin = v; return this; }

        /** Convenience: ignore both left and right margins. */
        public Builder ignoreMargins(boolean v) {
            this.ignoreLeftMargin = v; this.ignoreRightMargin = v; return this;
        }

        /** Override the header zone height (1–49 %). */
        public Builder headerPct(double pct) { this.headerPct = pct; return this; }

        /** Override the footer zone height (1–49 %). */
        public Builder footerPct(double pct) { this.footerPct = pct; return this; }

        /** Override the margin zone width (1–30 %). */
        public Builder marginPct(double pct) { this.marginPct = pct; return this; }

        /** Strip date/time patterns from line content before comparing. */
        public Builder ignoreTimestamps(boolean v) { this.ignoreTimestamps = v; return this; }

        /** Drop lines whose entire content is a page number. */
        public Builder ignorePageNumbers(boolean v) { this.ignorePageNumbers = v; return this; }

        /**
         * Add a custom Java regex. Lines matching the pattern have the match replaced with
         * an empty string; if the whole line becomes empty it is dropped.
         *
         * @throws PatternSyntaxException if the regex is invalid
         */
        public Builder ignorePattern(String regex) {
            this.customPatterns.add(Pattern.compile(regex));
            return this;
        }

        /**
         * Build a {@link FilterConfig}.
         *
         * @throws IllegalArgumentException if any required path is missing or blank
         */
        public FilterConfig build() {
            requireNonBlank(pdf1Path,   "pdf1 path must be provided");
            requireNonBlank(pdf2Path,   "pdf2 path must be provided");
            requireNonBlank(outputPath, "output path must be provided");
            return new FilterConfig(this);
        }

        private static void requireNonBlank(String value, String message) {
            if (value == null || value.trim().isEmpty()) {
                throw new IllegalArgumentException(message);
            }
        }
    }
}
