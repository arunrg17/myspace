package com.apitest.excel;

import com.apitest.model.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.nio.file.Path;
import java.util.*;

/**
 * Load test suite configuration from the Excel workbook.
 *
 * Required sheets:
 *   Environments  - named endpoints (DEV/UAT/PROD) for any protocol
 *   TestSuite     - one row per test case
 *   Steps         - one row per request (multiple steps per TestID allowed)
 *
 * Optional sheets:
 *   TestData      - variable values per test
 *   Assertions    - field-level assertions + ignore directives
 */
public class ExcelLoader {

    /**
     * Read a workbook from disk and assemble the full {@link TestSuite}.
     *
     * <p>Loads the Environments and TestSuite sheets, then layers on Steps,
     * TestData and Assertions, and finally sorts each test's steps by their
     * StepOrder. The workbook stream is always closed.
     *
     * @param path path to the .xlsx file
     * @return the parsed test suite
     * @throws Exception if the file can't be read or a required sheet is missing
     */
    public static TestSuite load(Path path) throws Exception {
        try (FileInputStream fis = new FileInputStream(path.toFile());
             Workbook wb = new XSSFWorkbook(fis)) {

            // Check every required sheet up front and report all that are
            // missing at once, rather than failing on the first one and making
            // the user fix them one re-run at a time.
            List<String> missing = missingSheets(wb);
            if (!missing.isEmpty()) {
                throw new IllegalStateException(
                        "Required sheet(s) missing: " + String.join(", ", missing));
            }

            Map<String, Environment> envs = loadEnvironments(wb);
            Map<String, TestCase> tests = loadTestSuite(wb);
            loadSteps(wb, tests);
            loadTestData(wb, tests);
            loadAssertions(wb, tests);

            // Sort steps per test
            for (TestCase tc : tests.values()) {
                tc.steps.sort(Comparator.comparingInt(Step::order));
            }

            return new TestSuite(envs, new ArrayList<>(tests.values()));
        }
    }

    /** The sheets a workbook must contain to be runnable. */
    public static final List<String> REQUIRED_SHEETS = List.of("Environments", "TestSuite", "Steps");

    /**
     * Return the required sheets this workbook does not contain, in the order
     * they are expected. An empty list means the structure is sound. TestData
     * and Assertions are optional and so are not checked here.
     */
    public static List<String> missingSheets(Workbook wb) {
        List<String> missing = new ArrayList<>();
        for (String name : REQUIRED_SHEETS) {
            if (wb.getSheet(name) == null) missing.add(name);
        }
        return missing;
    }

    // ------------------------------------------------------------------

    /**
     * Parse the Environments sheet into a map keyed by environment name.
     * Each row becomes one {@link Environment} carrying its protocol, base URL,
     * auth, optional SSL config, optional auto-token columns and optional
     * database-connection columns. Blank rows are skipped.
     */
    private static Map<String, Environment> loadEnvironments(Workbook wb) {
        Map<String, Environment> envs = new LinkedHashMap<>();
        Sheet sheet = requireSheet(wb, "Environments");
        Map<String, Integer> cols = headerColumns(sheet);

        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String name = cellStr(row, cols, "EnvName");
            if (name.isEmpty()) continue;

            envs.put(name, new Environment(
                    name,
                    cellStr(row, cols, "Protocol"),
                    cellStr(row, cols, "BaseURL"),
                    cellStr(row, cols, "AuthType"),
                    cellStr(row, cols, "AuthValue"),
                    parseHeaders(cellStr(row, cols, "ExtraHeaders")),
                    cellStr(row, cols, "SslConfig"),
                    cellStr(row, cols, "TokenURL"),
                    cellStr(row, cols, "TokenBody"),
                    parseHeaders(cellStr(row, cols, "TokenHeaders")),
                    cellStr(row, cols, "DbURL"),
                    cellStr(row, cols, "DbUser"),
                    cellStr(row, cols, "DbPassword"),
                    cellStr(row, cols, "DbDriver")
            ));
        }
        return envs;
    }

    /**
     * Parse the TestSuite sheet into test cases keyed by TestID.
     * Only rows whose Enabled column is "Y" (or blank) are included; disabled
     * rows are skipped. Sets the comparison mode, the two source environment
     * names and the expected-file path on each {@link TestCase}.
     */
    private static Map<String, TestCase> loadTestSuite(Workbook wb) {
        Map<String, TestCase> tests = new LinkedHashMap<>();
        Sheet sheet = requireSheet(wb, "TestSuite");
        Map<String, Integer> cols = headerColumns(sheet);

        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String enabled = cellStr(row, cols, "Enabled").trim().toUpperCase(Locale.ROOT);
            if (!"Y".equals(enabled) && !"YES".equals(enabled) && !"TRUE".equals(enabled)) continue;

            String testId = cellStr(row, cols, "TestID");
            if (testId.isEmpty()) continue;

            TestCase tc = new TestCase();
            tc.testId = testId;
            tc.name = cellStr(row, cols, "TestName");
            tc.description = cellStr(row, cols, "Description");
            tc.comparisonMode = cellStr(row, cols, "ComparisonMode");
            tc.sourceA = cellStr(row, cols, "SourceA");
            tc.sourceB = cellStr(row, cols, "SourceB");
            tc.expectedFile = cellStr(row, cols, "ExpectedFile");
            // Optional: JSONPaths of base64 fields to decode on both sides
            // before comparing. One per line, so a path containing a semicolon
            // is safe. Absent in older workbooks, which read it as blank.
            for (String p : cellStr(row, cols, "DecodePaths").split("\\r?\\n")) {
                String t = p.trim();
                if (!t.isEmpty()) tc.decodePaths.add(t);
            }
            // Optional: regexes blanking values that change every run. One per
            // line, since a pattern can contain almost any punctuation.
            for (String m : cellStr(row, cols, "MaskPatterns").split("\\r?\\n")) {
                String t = m.trim();
                if (!t.isEmpty()) tc.maskPatterns.add(t);
            }
            tc.enabled = true;
            tests.put(tc.testId, tc);
        }
        return tests;
    }

    /**
     * Attach the request steps to their test cases from the Steps sheet.
     * Each row is one HTTP call; multiple rows with the same TestID form an
     * ordered sequence. The Endpoint cell may hold two pipe-separated values
     * ("/a|/b") for vs_protocol tests, in which case the first is used for
     * source A and the second for source B.
     */
    private static void loadSteps(Workbook wb, Map<String, TestCase> tests) {
        Sheet sheet = requireSheet(wb, "Steps");
        Map<String, Integer> cols = headerColumns(sheet);

        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String tid = cellStr(row, cols, "TestID");
            TestCase tc = tests.get(tid);
            if (tc == null) continue;

            // Endpoint, Method and BodyTemplate each support a pipe-separated
            // "SourceA|SourceB" form for vs_protocol tests. First part = Source
            // A, second = Source B. If no pipe, the value is used for both.
            String[] ep = splitSourcePair(cellStr(row, cols, "Endpoint"));
            String[] me = splitSourcePair(cellStr(row, cols, "Method").toUpperCase(Locale.ROOT));
            String[] bt = splitSourcePair(cellStr(row, cols, "BodyTemplate"));

            Step step = new Step(
                    tid,
                    (int) cellNum(row, cols, "StepOrder", 1),
                    cellStr(row, cols, "StepName"),
                    me[0],          // method (Source A)
                    me[1],          // methodB (Source B, "" = same as A)
                    ep[0],          // endpoint (Source A)
                    ep[1],          // endpointB
                    bt[0],          // bodyTemplate (Source A)
                    bt[1],          // bodyTemplateB
                    parseExtractVars(cellStr(row, cols, "ExtractVars")),
                    parseStatus(cellStr(row, cols, "ExpectedStatus")),
                    parseHeaders(cellStr(row, cols, "ExtraHeaders"))
            );
            tc.steps.add(step);
        }
    }

    /**
     * Split a cell into a [SourceA, SourceB] pair on the first pipe.
     * If there is no pipe, SourceB is returned as "" (meaning "same as A").
     * Both parts are trimmed.
     */
    public static String[] splitSourcePair(String raw) {
        if (raw == null) return new String[]{"", ""};
        int pipe = raw.indexOf('|');
        if (pipe < 0) return new String[]{raw.trim(), ""};
        return new String[]{
                raw.substring(0, pipe).trim(),
                raw.substring(pipe + 1).trim()
        };
    }

    /**
     * Attach per-test variable values from the optional TestData sheet.
     * Every column other than TestID becomes a named value that templates and
     * endpoints can reference as ${column_name}. Missing sheet is not an error.
     */
    private static void loadTestData(Workbook wb, Map<String, TestCase> tests) {
        Sheet sheet = wb.getSheet("TestData");
        if (sheet == null) return;

        Map<String, Integer> cols = headerColumns(sheet);
        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String tid = cellStr(row, cols, "TestID");
            TestCase tc = tests.get(tid);
            if (tc == null) continue;

            for (Map.Entry<String, Integer> e : cols.entrySet()) {
                if ("TestID".equals(e.getKey())) continue;
                String value = cellStr(row, cols, e.getKey());
                tc.data.put(e.getKey(), value);
            }
        }
    }

    /**
     * Attach field-level assertions and ignore directives from the optional
     * Assertions sheet. A row whose TestID is "*" applies to every test (used
     * for global ignores like timestamps). Missing sheet is not an error.
     */
    private static void loadAssertions(Workbook wb, Map<String, TestCase> tests) {
        Sheet sheet = wb.getSheet("Assertions");
        if (sheet == null) return;

        Map<String, Integer> cols = headerColumns(sheet);
        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String target = cellStr(row, cols, "TestID");
            String path = cellStr(row, cols, "Path");
            if (path.isEmpty()) continue;

            Assertion a = new Assertion(
                    path,
                    cellStr(row, cols, "PathType"),
                    cellStr(row, cols, "Operator").toLowerCase(Locale.ROOT),
                    cellStr(row, cols, "ExpectedValue"),
                    cellStr(row, cols, "Description"),
                    // Optional: bind this assertion to one step. Blank/0 means it
                    // runs against the final response, as assertions always have.
                    (int) cellNum(row, cols, "StepOrder", 0),
                    // Optional: decode the resolved value before the operator
                    // runs (base64). Blank means no decode - the column is
                    // absent in older workbooks and reads as blank, so they are
                    // unaffected.
                    cellStr(row, cols, "Decode")
            );

            if ("*".equals(target)) {
                for (TestCase tc : tests.values()) tc.assertions.add(a);
            } else {
                TestCase tc = tests.get(target);
                if (tc != null) tc.assertions.add(a);
            }
        }
    }

    // ------------------------------------------------------------------

    /**
     * Fetch a sheet by name, throwing a clear error if it is absent.
     * @throws IllegalArgumentException if the sheet does not exist
     */
    private static Sheet requireSheet(Workbook wb, String name) {
        Sheet s = wb.getSheet(name);
        if (s == null) throw new IllegalStateException("Required sheet missing: " + name);
        return s;
    }

    /**
     * Build a map from header name to column index using the first row.
     * Header lookups are then by name, so column order in the workbook does
     * not matter and extra columns are ignored.
     */
    private static Map<String, Integer> headerColumns(Sheet sheet) {
        Row header = sheet.getRow(0);
        Map<String, Integer> out = new LinkedHashMap<>();
        if (header == null) return out;
        for (Cell c : header) {
            String v = cellStringValue(c);
            if (!v.isEmpty()) out.put(v, c.getColumnIndex());
        }
        return out;
    }

    /** @return true if the row is null or every cell is empty/blank. */
    private static boolean isBlankRow(Row row) {
        if (row == null) return true;
        for (Cell c : row) {
            String v = cellStringValue(c);
            if (!v.isEmpty()) return false;
        }
        return true;
    }

    /**
     * Read a cell as a trimmed string by header name.
     * @return the cell text, or "" if the column or cell is absent
     */
    private static String cellStr(Row row, Map<String, Integer> cols, String key) {
        Integer idx = cols.get(key);
        if (idx == null) return "";
        return cellStringValue(row.getCell(idx));
    }

    /**
     * Read a cell as a number by header name, tolerating numeric text.
     * @param def value returned when the cell is missing or not a number
     */
    private static double cellNum(Row row, Map<String, Integer> cols, String key, double def) {
        Integer idx = cols.get(key);
        if (idx == null) return def;
        Cell c = row.getCell(idx);
        if (c == null) return def;
        try {
            if (c.getCellType() == CellType.NUMERIC) return c.getNumericCellValue();
            String s = cellStringValue(c);
            if (s.isEmpty()) return def;
            return Double.parseDouble(s);
        } catch (Exception e) {
            return def;
        }
    }

    /**
     * Convert any cell type (string, numeric, boolean, formula) to a string.
     * Numbers that are whole are rendered without a trailing ".0" so IDs and
     * status codes read naturally.
     */
    private static String cellStringValue(Cell c) {
        if (c == null) return "";
        try {
            return switch (c.getCellType()) {
                case STRING -> c.getStringCellValue().trim();
                case NUMERIC -> {
                    double d = c.getNumericCellValue();
                    if (d == Math.floor(d) && !Double.isInfinite(d)) {
                        yield Long.toString((long) d);
                    } else {
                        yield Double.toString(d);
                    }
                }
                case BOOLEAN -> Boolean.toString(c.getBooleanCellValue());
                case FORMULA -> {
                    try { yield c.getStringCellValue().trim(); }
                    catch (Exception ex) { yield Double.toString(c.getNumericCellValue()); }
                }
                default -> "";
            };
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Parse extra headers from the ExtraHeaders column.
     *
     * One header per line:
     *   Authorization: Bearer xyz
     *   Content-Type: text/html; charset=utf-8
     *
     * Only the first colon on a line separates the name from the value, so a
     * value may itself contain colons or semicolons (a Content-Type charset, a
     * Cookie with several pairs) without being cut short. There is no delimiter
     * to escape - put each header on its own line.
     */
    private static Map<String, String> parseHeaders(String raw) {
        Map<String, String> out = new LinkedHashMap<>();
        if (raw == null || raw.isEmpty()) return out;

        for (String line : raw.split("\\r?\\n")) {
            if (line.trim().isEmpty()) continue;
            int idx = line.indexOf(':');
            if (idx > 0) {
                out.put(line.substring(0, idx).trim(), line.substring(idx + 1).trim());
            }
        }
        return out;
    }

    /**
     * Parse the ExtractVars cell into a map of variable name to path.
     * Format is "name=path" pairs separated by newlines or semicolons, e.g.
     * "order_id=$.order.id". These let a later step reference ${stepN.order_id}.
     */
    private static Map<String, String> parseExtractVars(String raw) {
        Map<String, String> out = new LinkedHashMap<>();
        if (raw == null || raw.isEmpty()) return out;
        for (String part : raw.split(",")) {
            int eq = part.indexOf('=');
            if (eq > 0) {
                out.put(part.substring(0, eq).trim(), part.substring(eq + 1).trim());
            }
        }
        return out;
    }

    /**
     * Parse the ExpectedStatus cell into a list of acceptable HTTP codes.
     * Accepts comma-separated values (e.g. "200,201"); defaults to a single
     * 200 when blank.
     */
    private static List<Integer> parseStatus(String raw) {
        if (raw == null || raw.isEmpty()) return List.of(200, 201, 204);
        List<Integer> out = new ArrayList<>();
        for (String s : raw.split(",")) {
            try { out.add(Integer.parseInt(s.trim())); }
            catch (NumberFormatException ignore) {}
        }
        return out.isEmpty() ? List.of(200, 201, 204) : out;
    }
}
