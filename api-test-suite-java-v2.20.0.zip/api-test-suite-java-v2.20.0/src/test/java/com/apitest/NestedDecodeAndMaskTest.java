package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.Test;

import java.util.Base64;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * The three things a response full of encoded sections needs beyond a single
 * decode: opening a field that only appears once an outer field is decoded,
 * leaving binary content alone instead of mangling it, and blanking the values
 * that are different on every run by design.
 */
class NestedDecodeAndMaskTest {

    private static String b64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes());
    }

    /** Leading bytes of a real PDF: decodes to bytes that are not valid UTF-8. */
    private static final String PDF_B64 = "JVBERi0xLjQNCiWhs8XXDQoxIDAgb2JqDQo8PC9NYW5nKGR1KQ==";

    private static final String GUID =
            "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";

    // ---- nesting ----

    @Test
    void decodesAFieldRevealedByAnEarlierDecode() {
        String innerA = "{\"ok\":true,\"renderResult\":\"" + b64("{\"page\":1}") + "\"}";
        String innerB = "{\"ok\":true,\"renderResult\":\"" + b64("{\"page\": 1}") + "\"}";
        String a = "{\"srr\":[{\"id\":\"OMS\",\"response\":\"" + b64(innerA) + "\"}]}";
        String b = "{\"srr\":[{\"id\":\"OMS\",\"response\":\"" + b64(innerB) + "\"}]}";

        CompareResult outerOnly = Comparator.compare(a, b, List.of(), List.of("$.srr[*].response"));
        assertFalse(outerOnly.matched, "inner encoding still differs when only the outer is opened");

        CompareResult both = Comparator.compare(a, b, List.of(),
                List.of("$.srr[*].response", "$.srr[*].response.renderResult"));
        assertTrue(both.matched, both.note);
    }

    @Test
    void nestedDifferenceIsStillCaught() {
        String innerA = "{\"renderResult\":\"" + b64("{\"page\":1}") + "\"}";
        String innerB = "{\"renderResult\":\"" + b64("{\"page\":99}") + "\"}";
        String a = "{\"s\":\"" + b64(innerA) + "\"}";
        String b = "{\"s\":\"" + b64(innerB) + "\"}";
        CompareResult r = Comparator.compare(a, b, List.of(),
                List.of("$.s", "$.s.renderResult"));
        assertFalse(r.matched, "a real difference two levels down must be reported");
    }

    @Test
    void innerPathDeclaredBeforeOuterSimplyDoesNotResolve() {
        // Order matters: the inner path cannot resolve until the outer is open.
        // Declaring it first must not throw or corrupt anything.
        String inner = "{\"renderResult\":\"" + b64("{\"p\":1}") + "\"}";
        String a = "{\"s\":\"" + b64(inner) + "\"}";
        assertDoesNotThrow(() ->
                Comparator.compare(a, a, List.of(), List.of("$.s.renderResult", "$.s")));
        assertTrue(Comparator.compare(a, a, List.of(),
                List.of("$.s.renderResult", "$.s")).matched);
    }

    // ---- binary guard ----

    @Test
    void binaryContentIsLeftEncodedNotMangled() {
        String a = "{\"doc\":\"" + PDF_B64 + "\"}";
        CompareResult r = Comparator.compare(a, a, List.of(), List.of("$.doc"));
        assertTrue(r.matched);
        assertTrue(r.note.contains("binary"), "note should say it was left encoded: " + r.note);
    }

    @Test
    void binaryFieldDoesNotBreakOtherDecodesInSamePass() {
        String a = "{\"doc\":\"" + PDF_B64 + "\",\"txt\":\"" + b64("{\"v\":1}") + "\"}";
        String b = "{\"doc\":\"" + PDF_B64 + "\",\"txt\":\"" + b64("{\"v\": 1}") + "\"}";
        CompareResult r = Comparator.compare(a, b, List.of(), List.of("$.doc", "$.txt"));
        assertTrue(r.matched, "the text field should still decode and match: " + r.note);
    }

    @Test
    void twoDifferentPdfsStillCompareAsTheirEncodedForm() {
        String other = Base64.getEncoder().encodeToString(new byte[]{(byte) 0xFF, (byte) 0xD8, (byte) 0xFF});
        String a = "{\"doc\":\"" + PDF_B64 + "\"}";
        String b = "{\"doc\":\"" + other + "\"}";
        CompareResult r = Comparator.compare(a, b, List.of(), List.of("$.doc"));
        assertFalse(r.matched, "different binary content is still a difference");
    }

    // ---- masking ----

    @Test
    void maskBlanksGeneratedIdsOnBothSides() {
        String a = "{\"h\":\"X-REQUEST-ID=3c86adad-b9a4-4849-9772-11759e5bcd6a\"}";
        String b = "{\"h\":\"X-REQUEST-ID=8e4432b1-bdcd-43d8-939f-7a1c7fca9690\"}";
        assertFalse(Comparator.compare(a, b, List.of(), null, null).matched);
        assertTrue(Comparator.compare(a, b, List.of(), null, List.of(GUID)).matched);
    }

    @Test
    void maskDoesNotHideARealDifference() {
        String a = "{\"id\":\"3c86adad-b9a4-4849-9772-11759e5bcd6a\",\"status\":\"OK\"}";
        String b = "{\"id\":\"8e4432b1-bdcd-43d8-939f-7a1c7fca9690\",\"status\":\"FAILED\"}";
        CompareResult r = Comparator.compare(a, b, List.of(), null, List.of(GUID));
        assertFalse(r.matched, "status still differs and must be reported");
    }

    @Test
    void maskAppliesToContentRevealedByDecoding() {
        String innerA = "{\"trace\":\"3c86adad-b9a4-4849-9772-11759e5bcd6a\",\"v\":1}";
        String innerB = "{\"trace\":\"8e4432b1-bdcd-43d8-939f-7a1c7fca9690\",\"v\":1}";
        String a = "{\"s\":\"" + b64(innerA) + "\"}";
        String b = "{\"s\":\"" + b64(innerB) + "\"}";
        CompareResult r = Comparator.compare(a, b, List.of(), List.of("$.s"), List.of(GUID));
        assertTrue(r.matched, "mask must reach content that only exists after decoding: " + r.note);
    }

    @Test
    void invalidRegexIsSkippedNotFatal() {
        String a = "{\"x\":1}";
        assertDoesNotThrow(() -> Comparator.compare(a, a, List.of(), null, List.of("[unclosed")));
        assertTrue(Comparator.compare(a, a, List.of(), null, List.of("[unclosed")).matched);
    }

    @Test
    void maskThatWouldBreakTheJsonIsDiscarded() {
        // A pattern matching the quotes and braces would leave the payload
        // unparseable; it must be dropped rather than applied.
        String a = "{\"x\":\"value\"}";
        String b = "{\"x\":\"value\"}";
        CompareResult r = Comparator.compare(a, b, List.of(), null, List.of("[\"{}]"));
        assertTrue(r.matched, "a destructive mask must not break a working comparison: " + r.note);
    }

    @Test
    void nullAndEmptyMasksBehaveLikeNoMasking() {
        String a = "{\"x\":1}";
        String b = "{\"x\":2}";
        assertEquals(Comparator.compare(a, b, List.of()).matched,
                Comparator.compare(a, b, List.of(), null, null).matched);
        assertEquals(Comparator.compare(a, b, List.of()).matched,
                Comparator.compare(a, b, List.of(), null, List.of()).matched);
    }

    @Test
    void blankPatternEntriesAreIgnored() {
        String a = "{\"h\":\"id=3c86adad-b9a4-4849-9772-11759e5bcd6a\"}";
        String b = "{\"h\":\"id=8e4432b1-bdcd-43d8-939f-7a1c7fca9690\"}";
        List<String> pats = java.util.Arrays.asList("", "   ", GUID);
        assertTrue(Comparator.compare(a, b, List.of(), null, pats).matched);
    }

    // ---- everything together, shaped like the real payload ----

    @Test
    void encodedSectionsWithNestedDocumentAndGeneratedIds() {
        String innerA = "{\"trace\":\"3c86adad-b9a4-4849-9772-11759e5bcd6a\","
                + "\"renderResult\":\"" + PDF_B64 + "\",\"status\":\"OK\"}";
        String innerB = "{\"trace\":\"8e4432b1-bdcd-43d8-939f-7a1c7fca9690\","
                + "\"renderResult\":\"" + PDF_B64 + "\",\"status\":\"OK\"}";
        String a = "{\"srr\":[{\"id\":\"OMS\",\"response\":\"" + b64(innerA) + "\"}]}";
        String b = "{\"srr\":[{\"id\":\"OMS\",\"response\":\"" + b64(innerB) + "\"}]}";

        CompareResult r = Comparator.compare(a, b, List.of(),
                List.of("$.srr[*].response", "$.srr[*].response.renderResult"),
                List.of(GUID));
        assertTrue(r.matched, "sections decode, the pdf stays encoded, the ids are masked: " + r.note);
        assertTrue(r.note.contains("binary"), r.note);
    }

    @Test
    void sameShapeButAGenuineStatusDifferenceStillFails() {
        String innerA = "{\"trace\":\"3c86adad-b9a4-4849-9772-11759e5bcd6a\",\"status\":\"OK\"}";
        String innerB = "{\"trace\":\"8e4432b1-bdcd-43d8-939f-7a1c7fca9690\",\"status\":\"NOT-OK\"}";
        String a = "{\"srr\":[{\"response\":\"" + b64(innerA) + "\"}]}";
        String b = "{\"srr\":[{\"response\":\"" + b64(innerB) + "\"}]}";
        CompareResult r = Comparator.compare(a, b, List.of(),
                List.of("$.srr[*].response"), List.of(GUID));
        assertFalse(r.matched, "masking ids must not hide a status difference");
    }
}
