package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import org.junit.jupiter.api.Test;

import java.util.Base64;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A body that was serialised into a field rather than nested arrives as a JSON
 * string holding JSON, sometimes behind a transport prefix: |200:"{\"a\":1}".
 * Without unwrapping the quoted layer the whole value is one string that no
 * path can reach into, which is what made an ignore silently match nothing.
 */
class DoubleEncodedBodyTest {

    private static final List<String> DECODE =
            List.of("$.status.serviceRequestResponses[*].response");
    private static final String ORINOCO =
            "$.status.serviceRequestResponses[?(@.id=='ORINOCO')].response.body.";

    private static String b64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes());
    }

    /** Build the shape these services return: prefix, then JSON-encoded JSON. */
    private static String doc(String prefix, String pdf, int pageCount, String returnCode) {
        String body = "{\"mimeType\":\"application/pdf\",\"documentCount\":1,\"pageCount\":"
                + pageCount + ",\"returnCode\":\"" + returnCode
                + "\",\"renderResult\":\"" + pdf + "\"}";
        String escaped = body.replace("\\", "\\\\").replace("\"", "\\\"");
        String inner = prefix + "\"" + escaped + "\"";
        return "{\"status\":{\"serviceRequestResponses\":[{\"id\":\"ORINOCO\",\"response\":\""
                + b64(inner) + "\"}]}}";
    }

    private static Assertion ignoreRender() {
        return new Assertion(
                "$.status.serviceRequestResponses[*].response.body.renderResult",
                "jsonpath", "ignore", "", "");
    }

    private AssertionResult check(String path, String expected, String payload) {
        String body = Comparator.decodeForAssertions(payload, DECODE);
        Assertion a = new Assertion(path, "jsonpath", "equals", expected, "", 0, "");
        return AssertionEngine.evaluate(body, List.of(a)).get(0);
    }

    @Test
    void generatedDocumentCanBeIgnoredInsideAQuotedBody() {
        String a = doc("|200:", "JVBERi0xAAA", 32, "0000");
        String b = doc("|200:", "JVBERi0xBBB", 32, "0000");
        assertFalse(Comparator.compare(a, b, List.of(), DECODE).matched);
        assertTrue(Comparator.compare(a, b, List.of(ignoreRender()), DECODE).matched,
                "the ignore path must reach through the quoted layer");
    }

    @Test
    void realDifferenceInsideAQuotedBodyIsReported() {
        String a = doc("|200:", "JVBERi0xAAA", 32, "0000");
        String b = doc("|200:", "JVBERi0xAAA", 99, "0000");
        assertFalse(Comparator.compare(a, b, List.of(ignoreRender()), DECODE).matched);
    }

    @Test
    void prefixChangeIsStillReported() {
        String a = doc("|200:", "JVBERi0xAAA", 32, "0000");
        String b = doc("|500:", "JVBERi0xAAA", 32, "0000");
        assertFalse(Comparator.compare(a, b, List.of(ignoreRender()), DECODE).matched);
    }

    @Test
    void fieldsInsideTheQuotedBodyAreReachable() {
        String p = doc("|200:", "JVBERi0xAAA", 32, "0000");
        assertTrue(check(ORINOCO + "returnCode", "0000", p).passed);
        assertTrue(check(ORINOCO + "pageCount", "32", p).passed);
        assertTrue(check(ORINOCO + "mimeType", "application/pdf", p).passed);
    }

    @Test
    void pathIsCaseSensitive() {
        // returncode is not returnCode; the miss must show up as a failure
        // rather than quietly matching something else.
        String p = doc("|200:", "JVBERi0xAAA", 32, "0000");
        assertFalse(check(ORINOCO + "returncode", "0000", p).passed);
    }

    @Test
    void quotedBodyWithNoPrefixIsUnwrappedToo() {
        String body = "{\"returnCode\":\"0000\"}";
        String escaped = body.replace("\\", "\\\\").replace("\"", "\\\"");
        String p = "{\"status\":{\"serviceRequestResponses\":[{\"id\":\"ORINOCO\",\"response\":\""
                + b64("\"" + escaped + "\"") + "\"}]}}";
        String decoded = Comparator.decodeForAssertions(p, DECODE);
        Assertion a = new Assertion(
                "$.status.serviceRequestResponses[?(@.id=='ORINOCO')].response.returnCode",
                "jsonpath", "equals", "0000", "", 0, "");
        assertTrue(AssertionEngine.evaluate(decoded, List.of(a)).get(0).passed,
                "with no prefix there is no body wrapper");
    }

    @Test
    void quotedStringThatIsNotADocumentStaysText() {
        String p = "{\"status\":{\"serviceRequestResponses\":[{\"id\":\"ORINOCO\",\"response\":\""
                + b64("|200:\"just a message\"") + "\"}]}}";
        String decoded = Comparator.decodeForAssertions(p, DECODE);
        Assertion a = new Assertion(
                "$.status.serviceRequestResponses[?(@.id=='ORINOCO')].response",
                "jsonpath", "contains", "just a message", "", 0, "");
        assertTrue(AssertionEngine.evaluate(decoded, List.of(a)).get(0).passed);
    }

    @Test
    void plainNestedDocumentStillWorksUnchanged() {
        // No quoting: the earlier shape must behave exactly as before.
        String inner = "|200:{\"returnCode\":\"0000\"}";
        String p = "{\"status\":{\"serviceRequestResponses\":[{\"id\":\"ORINOCO\",\"response\":\""
                + b64(inner) + "\"}]}}";
        assertTrue(check(ORINOCO + "returnCode", "0000", p).passed);
    }
}
