package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.Test;

import java.util.Base64;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Some services put a short transport prefix in front of the JSON body, which
 * leaves a decoded value unparseable and so compared as one long string - no
 * path can reach inside it. A prefix followed by a valid document is now split
 * into prefix and body, so ordinary paths work, and the prefix is kept rather
 * than dropped so a change in it is still a difference.
 */
class PrefixedPayloadTest {

    private static final List<String> DECODE =
            List.of("$.status.serviceRequestResponses[*].response");
    private static final String ORINOCO =
            "$.status.serviceRequestResponses[?(@.id=='ORINOCO')].response";

    private static String b64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes());
    }

    private static String doc(String prefix, String pdf, int pageCount, String returnCode) {
        String inner = prefix + "{\"mimeType\":\"application/pdf\",\"pageCount\":" + pageCount
                + ",\"returnCode\":\"" + returnCode + "\",\"renderResult\":\"" + pdf + "\"}";
        return "{\"status\":{\"serviceRequestResponses\":[{\"id\":\"ORINOCO\",\"response\":\""
                + b64(inner) + "\"}]}}";
    }

    private static Assertion ignoreRender() {
        return new Assertion(
                "$.status.serviceRequestResponses[*].response.body.renderResult",
                "jsonpath", "ignore", "", "");
    }

    private AssertionResult check(String path, String op, String expected, String payload) {
        String body = Comparator.decodeForAssertions(payload, DECODE);
        Assertion a = new Assertion(path, "jsonpath", op, expected, "", 0, "");
        return AssertionEngine.evaluate(body, List.of(a)).get(0);
    }

    // ---- comparison ----

    @Test
    void nestedDocumentCanBeIgnoredByPath() {
        String a = doc("|200:", "JVBERi0xAAA", 32, "0000");
        String b = doc("|200:", "JVBERi0xBBB", 32, "0000");
        assertFalse(Comparator.compare(a, b, List.of(), DECODE).matched,
                "the two documents differ until the render result is ignored");
        assertTrue(Comparator.compare(a, b, List.of(ignoreRender()), DECODE).matched,
                "the ignore path can now reach inside the prefixed body");
    }

    @Test
    void changeInThePrefixIsStillADifference() {
        String a = doc("|200:", "JVBERi0xAAA", 32, "0000");
        String b = doc("|500:", "JVBERi0xAAA", 32, "0000");
        assertFalse(Comparator.compare(a, b, List.of(ignoreRender()), DECODE).matched,
                "dropping the prefix would hide a 200 that became a 500");
    }

    @Test
    void realFieldDifferenceIsStillReported() {
        String a = doc("|200:", "JVBERi0xAAA", 32, "0000");
        String b = doc("|200:", "JVBERi0xAAA", 99, "0000");
        assertFalse(Comparator.compare(a, b, List.of(ignoreRender()), DECODE).matched);
    }

    // ---- assertions ----

    @Test
    void assertionReachesAFieldInsideThePrefixedBody() {
        String p = doc("|200:", "JVBERi0xAAA", 32, "0000");
        assertTrue(check(ORINOCO + ".body.returnCode", "equals", "0000", p).passed);
        assertTrue(check(ORINOCO + ".body.pageCount", "equals", "32", p).passed);
    }

    @Test
    void assertionCanCheckThePrefixItself() {
        String p = doc("|200:", "JVBERi0xAAA", 32, "0000");
        assertTrue(check(ORINOCO + ".prefix", "equals", "|200:", p).passed);
    }

    @Test
    void wrongExpectedValueStillFails() {
        String p = doc("|200:", "JVBERi0xAAA", 32, "0000");
        assertFalse(check(ORINOCO + ".body.returnCode", "equals", "9999", p).passed);
    }

    @Test
    void containsOnTheWholeResponseStillWorks() {
        // The older style, for anyone who already wrote assertions this way.
        String p = doc("|200:", "JVBERi0xAAA", 32, "0000");
        assertTrue(check(ORINOCO + ".body.returnCode", "contains", "0000", p).passed);
    }

    // ---- shapes that must not change ----

    @Test
    void bodyWithNoPrefixIsStillParsedFlat() {
        // No prefix: the decoded value is the document itself, no body wrapper.
        String inner = "{\"returnCode\":\"0000\"}";
        String p = "{\"status\":{\"serviceRequestResponses\":[{\"id\":\"ORINOCO\",\"response\":\""
                + b64(inner) + "\"}]}}";
        assertTrue(check(ORINOCO + ".returnCode", "equals", "0000", p).passed,
                "an unprefixed body keeps its original shape");
    }

    @Test
    void plainTextWithNoJsonStaysText() {
        String p = "{\"status\":{\"serviceRequestResponses\":[{\"id\":\"ORINOCO\",\"response\":\""
                + b64("just a message, no json here") + "\"}]}}";
        assertTrue(check(ORINOCO, "contains", "just a message", p).passed);
    }

    @Test
    void prefixFollowedByInvalidJsonStaysText() {
        String p = "{\"status\":{\"serviceRequestResponses\":[{\"id\":\"ORINOCO\",\"response\":\""
                + b64("|200:{not valid json") + "\"}]}}";
        assertTrue(check(ORINOCO, "contains", "|200:", p).passed,
                "nothing to parse, so the value stays as the text it is");
    }

    @Test
    void emptyDecodePathsLeavesAssertionsOnTheRawBody() {
        String inner = "{\"returnCode\":\"0000\"}";
        String p = "{\"status\":{\"serviceRequestResponses\":[{\"id\":\"ORINOCO\",\"response\":\""
                + b64(inner) + "\"}]}}";
        String unchanged = Comparator.decodeForAssertions(p, List.of());
        assertEquals(p, unchanged);
        assertNull(Comparator.decodeForAssertions(null, DECODE));
    }
}
