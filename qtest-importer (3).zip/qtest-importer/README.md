# qTest Test Case Importer

Java CLI utility to bulk-import test cases from ALM-exported Excel/CSV into qTest.

## Build

**Prerequisites:** Java 11+, Maven 3.6+

```bash
cd qtest-importer
mvn clean package
```

Produces a fat JAR: `target/qtest-importer-1.0.0.jar`

## Quick Start

```bash
# 1. Generate config
java -jar target/qtest-importer-1.0.0.jar generate-config

# 2. Edit qtest-config.properties — set URL, username, password

# 3. Test connection
java -jar target/qtest-importer-1.0.0.jar test-connection

# 4. Find your project ID
java -jar target/qtest-importer-1.0.0.jar list-projects

# 5. Set project ID in config, then validate
java -jar target/qtest-importer-1.0.0.jar dry-run your-export.xlsx

# 6. Import
java -jar target/qtest-importer-1.0.0.jar import your-export.xlsx
```

## Authentication

**You do NOT need admin access.** Any qTest user can authenticate.

### Option A: Username/Password (recommended)

Set in `qtest-config.properties`:
```properties
qtest.token.type=password
qtest.username=your.email@company.com
qtest.password=your-qtest-password
```

The tool calls `POST /oauth/token` automatically to get a bearer token
using your regular qTest login credentials. This is the default config.

### Option B: Login command (interactive)

```bash
java -jar target/qtest-importer-1.0.0.jar login
```

Prompts for username/password, gets a bearer token, and optionally
saves it to the config file.

### Option C: Bearer token directly

If you have a bearer token (from admin panel or the login command):
```properties
qtest.token.type=bearer
qtest.token=your-bearer-token-here
```

### How it works under the hood

The login calls:
```
POST https://your-org.qtestnet.com/oauth/token
Authorization: Basic <base64 of "sitename:">
Content-Type: application/x-www-form-urlencoded

grant_type=password&username=you@company.com&password=yourpass
```

The site name is extracted from your URL (e.g. `your-org` from `https://your-org.qtestnet.com`).
The response contains an `access_token` used as `bearer <token>` for all API calls.

## Configuration

```properties
qtest.url=https://your-org.qtestnet.com

# Auth (Option A)
qtest.token.type=password
qtest.username=your.email@company.com
qtest.password=your-qtest-password

# Auth (Option C)
# qtest.token.type=bearer
# qtest.token=your-bearer-token

qtest.skip.ssl=false          # true for self-signed certs
qtest.project.id=12345
qtest.module.id=               # optional target folder

import.batch.size=10
import.batch.delay.ms=500

# Field mappings
mapping.Test Case Name=name
mapping.Description=description
mapping.Prerequisites=precondition
mapping.Status=Status
mapping.Priority=Priority
mapping.Test Type=Type
mapping.Automation=Automation
mapping.Step Description=step.description
mapping.Expected Result=step.expected
mapping.Step Name=step.name
```

## Field Mapping

| Target | What it does |
|---|---|
| `name` | Test case name (required, groups rows) |
| `description` | Description field |
| `precondition` | Precondition field |
| `step.description` | Test step description (1 row = 1 step) |
| `step.expected` | Test step expected result |
| `Status`, `Priority`, etc. | qTest property (auto-resolves dropdown values) |
| `__skip__` | Ignore this column |

ALM exports one row per step. Rows with the same Test Case Name are grouped
automatically. Run `list-fields` to see your qTest fields and allowed values.

## Supported File Formats

| Format | Support |
|---|---|
| `.xlsx` | Apache POI |
| `.xls` | Apache POI (legacy) |
| `.csv` | Built-in (RFC 4180, multiline fields) |
| `.tsv` | Tab-separated |

## All Commands

```
generate-config           Create config template
login                     Get bearer token via username/password
test-connection           Verify connectivity
list-projects             Show projects with IDs
list-fields               Show test case fields + allowed values
list-modules              Show module/folder tree
dry-run <file>            Validate and show sample JSON
import  <file>            Import with confirmation prompt

Options:
  --config <file>         Alternate config file path
```
