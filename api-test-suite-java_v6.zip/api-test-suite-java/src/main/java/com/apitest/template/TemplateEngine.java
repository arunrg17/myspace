package com.apitest.template;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Renders request bodies and endpoints with ${placeholder} substitution.
 *
 * Placeholder syntax:
 *   ${col}        Substitute the TestData column value. If the column is
 *                 blank or missing, the placeholder is replaced with the
 *                 EMPTY STRING. The surrounding tag is preserved. This is
 *                 the default for SOAP envelopes and any structural XML
 *                 where empty elements are still meaningful.
 *
 *   ${col?}       Optional placeholder. If blank or missing, the surrounding
 *                 leaf tag is DROPPED entirely from the output. Use this for
 *                 fields that should not appear in the request when absent.
 *                 Example: <Phone>${phone?}</Phone> — if phone is blank,
 *                 <Phone/> is removed.
 *
 *   ${!col}       Required placeholder. If blank or missing, the test FAILS
 *                 immediately with a clear error. Use for fields where blank
 *                 is definitely wrong (e.g. an Order ID).
 *
 *   ${stepN.field}   Pull a variable extracted from step N's response.
 *   ${env.NAME}      OS environment variable (for secrets).
 *   ${now}           Current UTC ISO-8601 timestamp.
 *   ${uuid}          Random UUID v4.
 *
 * Element-level opt-in:
 *   <Parent optional="true">...</Parent>
 *      If after processing all children Parent has no remaining children
 *      (and no text), drop Parent. The `optional="true"` marker is stripped
 *      from the output regardless of whether Parent survives.
 *
 * The root element is never auto-removed. If after pruning the body is
 * effectively empty, the framework still sends what's there and lets the
 * server respond — that's strictly more informative than guessing.
 */
public class TemplateEngine {

    // ${col}, ${col?}, ${!col}, ${stepN.field}, ${env.NAME}, ${now}, ${uuid}
    private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{([^}]+)}");

    /** Sentinel marker for unresolved optional placeholders. */
    private static final String DROP_MARKER = "\u0001__DROP__\u0001";

    public static String render(String template, Map<String, String> data,
                                Map<Integer, Map<String, String>> stepVars) {
        if (template == null || template.isEmpty()) return template == null ? "" : "";

        Matcher m = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String token = m.group(1).trim();
            String replacement = resolve(token, data, stepVars);
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        String rendered = out.toString();

        if (looksLikeXml(rendered)) {
            // Drop leaf tags whose content was an opt-out (${col?}) placeholder
            // that didn't resolve.
            if (rendered.contains(DROP_MARKER)) {
                rendered = dropOptionalLeaves(rendered);
            }
            // Drop attributes whose value was an opt-out placeholder that
            // didn't resolve.
            rendered = dropOptionalAttributes(rendered);
            // Handle <Parent optional="true">...</Parent> opt-in
            rendered = dropOptionalEmptyParents(rendered);
            // Strip the optional="true" markers from any surviving parents
            rendered = rendered.replaceAll("\\s+optional\\s*=\\s*[\"']true[\"']", "");
            // Clean any stragglers
            rendered = rendered.replace(DROP_MARKER, "");
        } else if (rendered.contains(DROP_MARKER)) {
            // Non-XML body: drop marker, leave text behind
            rendered = rendered.replace(DROP_MARKER, "");
        }

        return rendered;
    }

    public static String renderFile(String templatePath, Map<String, String> data,
                                    Map<Integer, Map<String, String>> stepVars,
                                    Path baseDir) throws IOException {
        if (templatePath == null || templatePath.isEmpty()) return "";
        Path p = baseDir.resolve(templatePath);
        return render(Files.readString(p), data, stepVars);
    }

    // ──────────────────────────────────────────────────────────────────────
    // Resolution
    // ──────────────────────────────────────────────────────────────────────

    private static String resolve(String token, Map<String, String> data,
                                  Map<Integer, Map<String, String>> stepVars) {
        // Required: ${!col}
        if (token.startsWith("!")) {
            String key = token.substring(1).trim();
            String value = resolveValue(key, data, stepVars);
            if (value == null || value.isEmpty()) {
                throw new IllegalStateException("Required placeholder ${!" + key
                        + "} resolved to empty. Check TestData column or step output.");
            }
            return value;
        }

        // Opt-out: ${col?}
        if (token.endsWith("?")) {
            String key = token.substring(0, token.length() - 1).trim();
            String value = resolveValue(key, data, stepVars);
            return (value == null || value.isEmpty()) ? DROP_MARKER : value;
        }

        // Default: ${col} — blank/missing becomes empty string, tag preserved
        String value = resolveValue(token, data, stepVars);
        return value == null ? "" : value;
    }

    private static String resolveValue(String token, Map<String, String> data,
                                       Map<Integer, Map<String, String>> stepVars) {
        if ("now".equals(token)) return Instant.now().toString();
        if ("uuid".equals(token)) return UUID.randomUUID().toString();
        if (token.startsWith("env.")) {
            String v = System.getenv(token.substring(4));
            return v == null ? "" : v;
        }
        if (token.startsWith("step") && token.contains(".")) {
            int dot = token.indexOf('.');
            String head = token.substring(0, dot);
            String key = token.substring(dot + 1);
            try {
                int n = Integer.parseInt(head.substring(4));
                Map<String, String> vars = stepVars == null ? null : stepVars.get(n);
                if (vars != null) {
                    String v = vars.get(key);
                    return v == null ? "" : v;
                }
            } catch (NumberFormatException ignore) {}
            return "";
        }
        if (data == null) return "";
        String v = data.get(token);
        return v == null ? "" : v;
    }

    // ──────────────────────────────────────────────────────────────────────
    // Pruning helpers
    // ──────────────────────────────────────────────────────────────────────

    private static boolean looksLikeXml(String s) {
        if (s == null) return false;
        String t = s.trim();
        return t.startsWith("<");
    }

    /**
     * Drop leaf elements whose entire textual content is the drop marker
     * (possibly surrounded by whitespace). Multi-pass to handle adjacent
     * pruned siblings.
     */
    private static String dropOptionalLeaves(String xml) {
        // Pattern: <Tag ...> (whitespace) MARKER (whitespace) </Tag>
        // Also: <Tag ...>MARKER</Tag>
        // We use a manual scan to handle nested same-named tags correctly.
        String prev;
        String current = xml;
        int passes = 0;
        do {
            prev = current;
            current = dropLeavesOnePass(current);
            passes++;
            if (passes > 20) break;
        } while (!current.equals(prev));
        return current;
    }

    private static String dropLeavesOnePass(String xml) {
        StringBuilder out = new StringBuilder(xml.length());
        int cursor = 0;
        while (cursor < xml.length()) {
            int lt = xml.indexOf('<', cursor);
            if (lt < 0) { out.append(xml, cursor, xml.length()); break; }

            // Skip meta constructs
            if (xml.startsWith("<!--", lt)) {
                int end = xml.indexOf("-->", lt + 4);
                int copyTo = end < 0 ? xml.length() : end + 3;
                out.append(xml, cursor, copyTo);
                cursor = copyTo;
                continue;
            }
            if (xml.startsWith("<?", lt)) {
                int end = xml.indexOf("?>", lt + 2);
                int copyTo = end < 0 ? xml.length() : end + 2;
                out.append(xml, cursor, copyTo);
                cursor = copyTo;
                continue;
            }
            if (xml.startsWith("<![CDATA[", lt)) {
                int end = xml.indexOf("]]>", lt + 9);
                int copyTo = end < 0 ? xml.length() : end + 3;
                out.append(xml, cursor, copyTo);
                cursor = copyTo;
                continue;
            }
            if (xml.startsWith("</", lt)) {
                int gt = xml.indexOf('>', lt);
                int copyTo = gt < 0 ? xml.length() : gt + 1;
                out.append(xml, cursor, copyTo);
                cursor = copyTo;
                continue;
            }

            // Element open tag
            int nameStart = lt + 1;
            int nameEnd = nameStart;
            while (nameEnd < xml.length()) {
                char c = xml.charAt(nameEnd);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '/' || c == '>') break;
                nameEnd++;
            }
            int gt = xml.indexOf('>', nameEnd);
            if (gt < 0) { out.append(xml, cursor, xml.length()); break; }
            String fullName = xml.substring(nameStart, nameEnd);
            boolean selfClose = gt > 0 && xml.charAt(gt - 1) == '/';
            if (selfClose) {
                out.append(xml, cursor, gt + 1);
                cursor = gt + 1;
                continue;
            }

            int contentStart = gt + 1;
            int contentEnd = findMatchingClose(xml, contentStart, fullName);
            if (contentEnd < 0) {
                out.append(xml, cursor, xml.length());
                break;
            }
            int closeEnd = xml.indexOf('>', contentEnd);
            if (closeEnd < 0) closeEnd = xml.length() - 1;
            String content = xml.substring(contentStart, contentEnd);

            // Drop the element iff its content is:
            //   - only the DROP_MARKER (with optional surrounding whitespace), OR
            //   - mixed content containing the marker plus other non-whitespace
            //     text (only when there are NO child elements — mixed content
            //     case)
            String stripped = content.trim();
            boolean contentIsOnlyMarker = stripped.equals(DROP_MARKER);
            boolean hasChildElement = containsChildElement(content);
            boolean mixedTextWithMarker = !hasChildElement
                    && content.contains(DROP_MARKER);

            if (contentIsOnlyMarker || mixedTextWithMarker) {
                // Drop this element + its preceding indentation + a trailing newline
                int dropFrom = lt;
                while (dropFrom > cursor && (xml.charAt(dropFrom - 1) == ' ' || xml.charAt(dropFrom - 1) == '\t')) {
                    dropFrom--;
                }
                int dropTo = closeEnd + 1;
                if (dropTo < xml.length() && xml.charAt(dropTo) == '\n') dropTo++;
                out.append(xml, cursor, dropFrom);
                cursor = dropTo;
                continue;
            }

            // Keep open tag and recurse via main loop
            out.append(xml, cursor, contentStart);
            cursor = contentStart;
        }
        return out.toString();
    }

    /** Drop attributes whose value contains the drop marker. */
    private static String dropOptionalAttributes(String xml) {
        String esc = Pattern.quote(DROP_MARKER);
        return xml
                .replaceAll("\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*\"[^\"]*" + esc + "[^\"]*\"", "")
                .replaceAll("\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*'[^']*" + esc + "[^']*'", "");
    }

    /**
     * Drop empty parent elements that the user marked with `optional="true"`.
     * Multi-pass to allow nested optionals to cascade.
     */
    private static String dropOptionalEmptyParents(String xml) {
        Pattern emptyOptional = Pattern.compile(
                "<([A-Za-z_][\\w:.\\-]*)\\b[^>]*\\boptional\\s*=\\s*[\"']true[\"'][^>]*>\\s*</\\1>\\s*\\n?",
                Pattern.DOTALL);
        String prev;
        String current = xml;
        int passes = 0;
        do {
            prev = current;
            current = emptyOptional.matcher(current).replaceAll("");
            passes++;
            if (passes > 10) break;
        } while (!current.equals(prev));
        return current;
    }

    /** Does the content contain a real child element? */
    private static boolean containsChildElement(String content) {
        int i = 0;
        while (i < content.length()) {
            int lt = content.indexOf('<', i);
            if (lt < 0) return false;
            if (content.startsWith("<!--", lt)) {
                int end = content.indexOf("-->", lt + 4);
                if (end < 0) return false;
                i = end + 3;
                continue;
            }
            if (content.startsWith("<?", lt)) {
                int end = content.indexOf("?>", lt + 2);
                if (end < 0) return false;
                i = end + 2;
                continue;
            }
            if (content.startsWith("<![CDATA[", lt)) {
                int end = content.indexOf("]]>", lt + 9);
                if (end < 0) return false;
                i = end + 3;
                continue;
            }
            return true;
        }
        return false;
    }

    /** Find the matching close tag respecting nesting. */
    private static int findMatchingClose(String xml, int start, String fullName) {
        int depth = 1;
        int idx = start;
        while (idx < xml.length()) {
            int lt = xml.indexOf('<', idx);
            if (lt < 0) return -1;
            if (xml.startsWith("<!--", lt)) {
                int e = xml.indexOf("-->", lt + 4);
                idx = e < 0 ? xml.length() : e + 3;
                continue;
            }
            if (xml.startsWith("<?", lt)) {
                int e = xml.indexOf("?>", lt + 2);
                idx = e < 0 ? xml.length() : e + 2;
                continue;
            }
            if (xml.startsWith("<![CDATA[", lt)) {
                int e = xml.indexOf("]]>", lt + 9);
                idx = e < 0 ? xml.length() : e + 3;
                continue;
            }
            boolean isClose = xml.startsWith("</", lt);
            int nameStart = lt + (isClose ? 2 : 1);
            int nameEnd = nameStart;
            while (nameEnd < xml.length()) {
                char c = xml.charAt(nameEnd);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '/' || c == '>') break;
                nameEnd++;
            }
            String name = xml.substring(nameStart, nameEnd);
            int gt = xml.indexOf('>', nameEnd);
            if (gt < 0) return -1;
            if (name.equals(fullName)) {
                if (isClose) {
                    depth--;
                    if (depth == 0) return lt;
                } else {
                    boolean selfClose = gt > 0 && xml.charAt(gt - 1) == '/';
                    if (!selfClose) depth++;
                }
            }
            idx = gt + 1;
        }
        return -1;
    }
}
