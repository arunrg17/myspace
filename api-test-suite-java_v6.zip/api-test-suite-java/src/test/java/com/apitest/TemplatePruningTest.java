package com.apitest;

import com.apitest.template.TemplateEngine;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Template substitution and pruning behavior.
 *
 * The framework supports three placeholder forms:
 *   ${col}      - default: blank/missing → empty string, surrounding tag KEPT
 *   ${col?}     - opt-out: blank/missing → DROP the surrounding leaf tag
 *   ${!col}     - required: blank/missing → throw IllegalStateException
 *
 * Plus element-level opt-in:
 *   <Parent optional="true">...</Parent>
 *      - parent dropped if it ends up empty after pruning children
 */
class TemplatePruningTest {

    private static Map<String, String> data(String... kv) {
        Map<String, String> m = new HashMap<>();
        for (int i = 0; i < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return m;
    }

    private static String render(String template, Map<String, String> data) {
        return TemplateEngine.render(template, data, Map.of());
    }

    // ── Default ${col}: blank → empty string, tag KEPT ─────────────────────

    @Test
    void defaultPlaceholderKeepsTagWhenBlank() {
        String t = "<r><a>${x}</a></r>";
        // Default behavior: tag kept, content empty
        assertEquals("<r><a></a></r>", render(t, data()));
    }

    @Test
    void defaultPlaceholderResolvesNormallyWhenFilled() {
        assertEquals("<r><a>hello</a></r>",
                render("<r><a>${x}</a></r>", data("x", "hello")));
    }

    @Test
    void defaultPlaceholderInStructuralWrapper() {
        // The critical scenario: <execute>${payload}</execute> with empty
        // payload must NOT drop <execute>. It's a structural wrapper.
        String t = "<Envelope><Body><execute>${payload}</execute></Body></Envelope>";
        String out = render(t, data());
        assertTrue(out.contains("<execute>"), "execute wrapper kept: " + out);
        assertTrue(out.contains("</execute>"), out);
        assertTrue(out.contains("<Body>"), out);
    }

    // ── ${col?} opt-out: blank → drop leaf tag ─────────────────────────────

    @Test
    void optOutPlaceholderDropsLeafWhenBlank() {
        // Phone column blank → <Phone> dropped
        String t = "<Customer><Name>${name}</Name><Phone>${phone?}</Phone></Customer>";
        String out = render(t, data("name", "Alice"));
        assertTrue(out.contains("<Name>Alice</Name>"), out);
        assertFalse(out.contains("Phone"), "Phone tag dropped: " + out);
    }

    @Test
    void optOutPlaceholderResolvesNormallyWhenFilled() {
        String t = "<r><Phone>${phone?}</Phone></r>";
        assertEquals("<r><Phone>555-1234</Phone></r>",
                render(t, data("phone", "555-1234")));
    }

    @Test
    void multipleOptOutLeavesDropTogether() {
        String t = "<Order>"
                + "<Id>${id}</Id>"
                + "<Phone>${phone?}</Phone>"
                + "<Email>${email?}</Email>"
                + "<Notes>${notes?}</Notes>"
                + "</Order>";
        String out = render(t, data("id", "123"));
        assertEquals("<Order><Id>123</Id></Order>", out);
    }

    // ── ${!col} required: blank → throw ────────────────────────────────────

    @Test
    void requiredPlaceholderThrowsWhenBlank() {
        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> render("<r><id>${!order_id}</id></r>", data("order_id", "")));
        assertTrue(ex.getMessage().contains("Required"));
        assertTrue(ex.getMessage().contains("order_id"));
    }

    @Test
    void requiredPlaceholderResolvesNormallyWhenFilled() {
        assertEquals("<r><id>X100</id></r>",
                render("<r><id>${!order_id}</id></r>", data("order_id", "X100")));
    }

    // ── Attributes ─────────────────────────────────────────────────────────

    @Test
    void optOutAttributeIsDropped() {
        String t = "<Order ref=\"${ref?}\" type=\"${type?}\"><x>1</x></Order>";
        String out = render(t, data("ref", "R-100"));
        assertTrue(out.contains("ref=\"R-100\""), out);
        assertFalse(out.contains("type="), out);
    }

    @Test
    void defaultAttributeStaysAsEmpty() {
        // Default ${ref}: even when blank, attribute stays with empty value
        String t = "<Order ref=\"${ref}\"><x>1</x></Order>";
        String out = render(t, data());
        assertTrue(out.contains("ref=\"\""), "Attribute kept as empty: " + out);
    }

    // ── Element-level optional="true" ──────────────────────────────────────

    @Test
    void optionalParentDroppedWhenEmpty() {
        // Parent marked optional="true", all leaves dropped via opt-out
        String t = "<Order>"
                + "<Customer optional=\"true\">"
                + "<Name>${name?}</Name>"
                + "<Phone>${phone?}</Phone>"
                + "</Customer>"
                + "</Order>";
        String out = render(t, data());
        assertEquals("<Order></Order>", out);
    }

    @Test
    void optionalParentKeptWhenAnyChildSurvives() {
        String t = "<Order>"
                + "<Customer optional=\"true\">"
                + "<Name>${name?}</Name>"
                + "<Phone>${phone?}</Phone>"
                + "</Customer>"
                + "</Order>";
        String out = render(t, data("name", "Alice"));
        assertTrue(out.contains("<Customer>"), out);
        assertTrue(out.contains("<Name>Alice</Name>"), out);
        assertFalse(out.contains("optional"), "optional marker stripped: " + out);
        assertFalse(out.contains("Phone"), out);
    }

    // ── Real-world SOAP scenarios ──────────────────────────────────────────

    @Test
    void soapEnvelopeWithBlankPayloadKeepsStructure() {
        // User's exact failing case: <execute>${payload}</execute> empty
        String t = "<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                + "<Body>"
                + "<execute xmlns=\"http://example.com/svc\">${payload}</execute>"
                + "</Body>"
                + "</Envelope>";
        String out = render(t, data());
        assertTrue(out.contains("<Envelope"), out);
        assertTrue(out.contains("<Body>"), out);
        assertTrue(out.contains("<execute"), out);
        assertTrue(out.contains("</execute>") || out.contains("<execute"),
                "execute kept (server gets a recognisable empty payload): " + out);
        assertTrue(out.contains("</Body>"), out);
        assertTrue(out.contains("</Envelope>"), out);
    }

    @Test
    void mixedOptOutAndDefaultPlaceholders() {
        // Realistic mix: required fields use default, optional use ${col?}
        String t = "<Order>"
                + "  <Id>${order_id}</Id>"            // default, blank stays as <Id></Id>
                + "  <Customer optional=\"true\">"
                + "    <Name>${customer_name?}</Name>"  // opt-out
                + "    <Phone>${customer_phone?}</Phone>"
                + "    <Email>${customer_email?}</Email>"
                + "  </Customer>"
                + "  <Notes>${notes?}</Notes>"           // opt-out
                + "</Order>";

        Map<String,String> td = data(
                "order_id", "123",
                "customer_name", "Alice",
                "customer_email", "alice@x.com"
        );
        String out = render(t, td);
        assertTrue(out.contains("<Id>123</Id>"), out);
        assertTrue(out.contains("<Name>Alice</Name>"), out);
        assertTrue(out.contains("<Email>alice@x.com</Email>"), out);
        assertFalse(out.contains("Phone"), out);
        assertFalse(out.contains("Notes"), out);
        assertTrue(out.contains("<Customer>"), out);
        assertFalse(out.contains("optional"), out);
    }

    // ── Static placeholders still work ─────────────────────────────────────

    @Test
    void staticPlaceholdersStillWork() {
        String t = "<r><time>${now}</time><id>${uuid}</id></r>";
        String out = render(t, data());
        assertTrue(out.contains("<time>") && out.contains("</time>"), out);
        assertTrue(out.contains("<id>") && out.contains("</id>"), out);
        assertFalse(out.contains("${"), out);
    }

    // ── Literal empty tags preserved ───────────────────────────────────────

    @Test
    void literalEmptyTagInTemplateIsKept() {
        String t = "<r><a>${x}</a><Empty></Empty></r>";
        String out = render(t, data("x", "1"));
        assertTrue(out.contains("<Empty></Empty>"), out);
    }

    // ── Non-XML body unchanged ─────────────────────────────────────────────

    @Test
    void jsonBodyIsNotPruned() {
        String t = "{ \"name\": \"${name}\", \"phone\": \"${phone?}\" }";
        String out = render(t, data("name", "Alice"));
        // Default ${name} works; opt-out marker stripped to empty in JSON
        assertTrue(out.contains("\"name\": \"Alice\""), out);
    }
}
