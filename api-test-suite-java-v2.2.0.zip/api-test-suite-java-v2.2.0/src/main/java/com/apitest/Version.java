package com.apitest;

/**
 * Build version constant. Kept in sync with pom.xml {@code <version>} and
 * the {@code VERSION} file at the project root.
 *
 * Version history:
 *   2.2.0  - Path configuration via CLI flags: --templates-dir,
 *            --expected-dir, --output-dir, --project-root. Lets users ship
 *            just the jar and point it at any directory layout. Comparison
 *            tab no longer truncates large payloads — pre-rendered area is
 *            fully accessible via scroll, with a header showing char counts.
 *   2.1.1  - Bug fix: in vs_env / vs_protocol mode, when source B's
 *            step failed (e.g. socket exception), the final status-resolve
 *            block was overwriting the FAIL set earlier with PASS. Final
 *            block now preserves any explicit FAIL/ERROR set by the
 *            comparison-mode switch. Overview tab now also shows a small
 *            ok/failed pill on each Source cell.
 *   2.1.0  - Comparison view enhancements. CompareResult now carries the
 *            CDATA-unwrapped, pretty-printed payloads; the HTML report
 *            shows them side-by-side in the Comparison tab so users can
 *            see exactly what was compared. Diff cell rendering fixed
 *            to suppress the internal {@code <missing>} sentinel string.
 *            Cleanup of code/docs, version metadata, and security review.
 *   2.0.2  - Serialization clean-up: no more {@code xmlns=""} artifacts,
 *            no line-wraps inside opening tags, no leftover blank lines
 *            from original-template indentation.
 *   2.0.1  - CDATA-aware cleanup of the rendered output: inner XML inside
 *            a CDATA wrapper now has unfilled placeholder tags removed
 *            cleanly via string-level passes (DOM walker cannot enter
 *            CDATA). CDATA sections preserved through serialization.
 *   2.0.0  - Template engine rewritten using a DOM walk with cascade
 *            pruning. Per-test error isolation: template / dispatch /
 *            extract errors become reported step failures, never killing
 *            the suite. RenderLog persisted to disk for diagnostics.
 *            Placeholder syntax is {@code ${name}} only.
 *   1.0.0  - Initial Java port from UFT/VBScript suite.
 */
public final class Version {
    public static final String VERSION = "2.2.0";
    private Version() {}
}
