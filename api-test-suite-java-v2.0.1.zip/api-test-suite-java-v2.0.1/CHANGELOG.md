# Changelog

## 2.0.1 — 2026-05-15

### Bug fixes

- **CDATA-wrapped inner XML now cleaned correctly.** When a template uses
  `<arg0><![CDATA[<inner>...${field}...</inner>]]></arg0>` to wrap a
  business payload, unresolved placeholders inside the CDATA now have their
  surrounding tags removed via string-level cleanup (the parser can't walk
  into CDATA as elements). Surviving filled tags are preserved; empty
  wrappers cascade away within the CDATA.
- **CDATA sections preserved through the output.** Previously the
  Transformer was converting CDATA back to escaped entities. Now the
  serializer explicitly lists CDATA-containing element names so they
  round-trip as `<![CDATA[...]]>`.
- **DROP marker no longer leaks to output** even when an element has
  attributes and the placeholder was its only content. The element is
  dropped per the spec, regardless of attributes.

## 2.0.0 — 2026-05-15

### Behavior changes (breaking)

- **Template engine rewritten using DOM-walk + cascade pruning.** Old
  regex-based heuristics replaced with a real XML parser. Handles namespaces,
  nested structures, attributes, repeating siblings correctly.
- **Placeholder syntax is `${name}` only.** The `&{name}` form is no longer
  recognized (was briefly experimental in pre-release builds).
- **Blank/missing placeholder values now drop the surrounding tag.** This
  matches the requirements spec. A leaf with `<Phone>${phone}</Phone>` and
  blank `phone` cell renders with no `<Phone>` element at all.
- **Parent cascade cleanup.** When all children of a parent are pruned and
  the parent has no other content (no real attrs, no text), the parent
  itself is removed. Cascades up.
- **Namespace declarations don't block cascade.** `xmlns` and `xmlns:*` are
  not counted as "real" attributes — so `<execute xmlns="..."/>` cascades
  away properly when its content was just a placeholder.
- **Root element is never auto-removed.** If pruning empties everything,
  the body is `<Root></Root>` rather than nothing — better diagnostics.

### Reliability improvements

- **Per-test error isolation.** Template-not-found, dispatch errors, SSL
  failures, variable-extraction errors — all now produce a failed step in
  the report instead of an uncaught exception that killed the suite. The
  next test always runs.
- **RenderLog persisted to disk.** Each step's render log is saved next
  to its `request.txt`/`response.txt` under `output/.../step.../render-log.txt`.
  Shows which placeholders were missing, which tags were dropped, which
  parents cascaded.
- **Step errors shown in HTML report.** When a step fails for any reason
  (template error, dispatch error, etc.), the report shows the full
  rendered log inline with the failed step.

### Other

- Version badge added to HTML report header.
- `Required` placeholder syntax `${!name}` documented — raises a clear
  error if the column is blank/missing.

## 1.0.0 — earlier

- Initial Java port from the original UFT/VBScript suite.
- Excel-driven test definition (5 sheets: Environments, TestSuite, Steps,
  TestData, Assertions).
- Four protocols: REST, SOAP, Fabric, GCP.
- Five comparison modes; nine assertion operators.
- Self-contained HTML report.
- Parser-free `SimpleXmlWalker` for assertion extraction (handles
  SOAP-in-SOAP, CDATA-wrapped inner XML).
