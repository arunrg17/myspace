package com.apitest.comparator;

import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import com.apitest.model.DiffEntry;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.ReadContext;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import java.io.StringReader;
import java.util.*;

/**
 * Compare two payloads structurally with ignore-field support.
 *
 * Handles XML vs XML, JSON vs JSON, and cross-format (XML vs JSON) by
 * normalising XML into a JSON-like tree.
 */
public class Comparator {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Configuration JSONPATH_CFG = Configuration.builder()
            .options(Option.SUPPRESS_EXCEPTIONS)
            .build();

    public static String detectFormat(String payload) {
        if (payload == null) return "empty";
        // Strip BOM + leading junk so a BOM-prefixed XML response is still
        // classified as XML rather than as "text".
        String s = sanitizeXmlProlog(payload).strip();
        if (s.isEmpty()) return "empty";
        if (s.startsWith("<")) return "xml";
        if (s.startsWith("{") || s.startsWith("[")) return "json";
        // Last-ditch: if the body contains an XML-looking start somewhere in
        // the first 500 chars (e.g. "garbage prefix <?xml ...?>"), treat as XML.
        int scan = Math.min(s.length(), 500);
        int xmlStart = s.indexOf("<?xml");
        if (xmlStart < 0) xmlStart = s.indexOf("<");
        if (xmlStart >= 0 && xmlStart < scan) return "xml";
        return "text";
    }

    public static CompareResult compare(String expected, String actual, List<Assertion> assertions) {
        CompareResult result = new CompareResult();
        if (assertions == null) assertions = List.of();

        String fmtA = detectFormat(expected);
        String fmtB = detectFormat(actual);

        if ("empty".equals(fmtA) || "empty".equals(fmtB)) {
            result.matched = false;
            result.note = "One side is empty";
            return result;
        }

        List<String> xpathIgnores = new ArrayList<>();
        List<String> jsonpathIgnores = new ArrayList<>();
        for (Assertion a : assertions) {
            if (!"ignore".equalsIgnoreCase(a.operator())) continue;
            if ("xpath".equalsIgnoreCase(a.pathType())) xpathIgnores.add(a.path());
            else if ("jsonpath".equalsIgnoreCase(a.pathType())) jsonpathIgnores.add(a.path());
        }

        try {
            Object objA, objB;
            if ("xml".equals(fmtA) && "xml".equals(fmtB)) {
                objA = xmlToMap(applyXpathIgnores(expected, xpathIgnores));
                objB = xmlToMap(applyXpathIgnores(actual, xpathIgnores));
                applyJsonpathIgnores(objA, jsonpathIgnores);
                applyJsonpathIgnores(objB, jsonpathIgnores);
                result.note = "xml vs xml";
            } else if ("json".equals(fmtA) && "json".equals(fmtB)) {
                objA = jsonToMap(expected);
                objB = jsonToMap(actual);
                applyJsonpathIgnores(objA, jsonpathIgnores);
                applyJsonpathIgnores(objB, jsonpathIgnores);
                result.note = "json vs json";
            } else {
                objA = "xml".equals(fmtA) ? xmlToMap(applyXpathIgnores(expected, xpathIgnores)) : jsonToMap(expected);
                objB = "xml".equals(fmtB) ? xmlToMap(applyXpathIgnores(actual, xpathIgnores)) : jsonToMap(actual);
                applyJsonpathIgnores(objA, jsonpathIgnores);
                applyJsonpathIgnores(objB, jsonpathIgnores);
                result.note = fmtA + " vs " + fmtB + " (cross-format)";
            }

            diff(objA, objB, "$", result.diffs);
            result.matched = result.diffs.isEmpty();
        } catch (Exception ex) {
            result.matched = false;
            result.note = "Parse error: " + ex.getMessage();
        }
        return result;
    }

    // ------------------------------------------------------------------
    // Format conversion
    // ------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    public static Object jsonToMap(String json) throws Exception {
        JsonNode node = MAPPER.readTree(json);
        return jsonNodeToObject(node);
    }

    private static Object jsonNodeToObject(JsonNode node) {
        if (node.isObject()) {
            Map<String, Object> map = new LinkedHashMap<>();
            node.fields().forEachRemaining(e -> map.put(e.getKey(), jsonNodeToObject(e.getValue())));
            return map;
        }
        if (node.isArray()) {
            List<Object> list = new ArrayList<>();
            node.forEach(c -> list.add(jsonNodeToObject(c)));
            return list;
        }
        if (node.isNumber()) return node.numberValue();
        if (node.isBoolean()) return node.booleanValue();
        if (node.isNull()) return null;
        return node.asText();
    }

    public static Object xmlToMap(String xml) throws Exception {
        // Apply the same defensive sanitization + recovery as extractVariable
        // so malformed responses can still be compared.
        String sanitized = sanitizeXmlProlog(xml).replace("\r\n", "\n").replace("\r", "");
        Document doc = parseWithRecovery(sanitized);
        if (doc == null) {
            throw new IllegalStateException(
                    "XML is malformed and unrecoverable. First 200 chars: "
                            + safePreview(sanitized, 200));
        }
        Node root = doc.getDocumentElement();
        Map<String, Object> wrapper = new LinkedHashMap<>();
        wrapper.put(localName(root.getNodeName()), elementToObject(root));
        return wrapper;
    }

    @SuppressWarnings("unchecked")
    private static Object elementToObject(Node elem) {
        List<Node> children = new ArrayList<>();
        NodeList nl = elem.getChildNodes();
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < nl.getLength(); i++) {
            Node c = nl.item(i);
            if (c.getNodeType() == Node.ELEMENT_NODE) children.add(c);
            else if (c.getNodeType() == Node.TEXT_NODE || c.getNodeType() == Node.CDATA_SECTION_NODE) {
                text.append(c.getNodeValue());
            }
        }

        NamedNodeMap attrs = elem.getAttributes();
        if (children.isEmpty()) {
            String t = text.toString().trim();
            if (attrs == null || attrs.getLength() == 0) return t;
            Map<String, Object> map = new LinkedHashMap<>();
            for (int i = 0; i < attrs.getLength(); i++) {
                Node a = attrs.item(i);
                if (isNamespaceAttr(a)) continue;
                map.put("@" + localName(a.getNodeName()), a.getNodeValue());
            }
            if (map.isEmpty()) return t;
            if (!t.isEmpty()) map.put("#text", t);
            return map;
        }

        Map<String, Object> map = new LinkedHashMap<>();
        for (Node child : children) {
            String key = localName(child.getNodeName());
            Object value = elementToObject(child);
            if (map.containsKey(key)) {
                Object existing = map.get(key);
                if (existing instanceof List) {
                    ((List<Object>) existing).add(value);
                } else {
                    List<Object> list = new ArrayList<>();
                    list.add(existing);
                    list.add(value);
                    map.put(key, list);
                }
            } else {
                map.put(key, value);
            }
        }
        if (attrs != null) {
            for (int i = 0; i < attrs.getLength(); i++) {
                Node a = attrs.item(i);
                if (isNamespaceAttr(a)) continue;
                map.put("@" + localName(a.getNodeName()), a.getNodeValue());
            }
        }
        return map;
    }

    private static boolean isNamespaceAttr(Node a) {
        String n = a.getNodeName();
        return "xmlns".equals(n) || n.startsWith("xmlns:");
    }

    private static String localName(String qname) {
        int idx = qname.indexOf(':');
        return idx >= 0 ? qname.substring(idx + 1) : qname;
    }

    // ------------------------------------------------------------------
    // Ignore application
    // ------------------------------------------------------------------

    private static String applyXpathIgnores(String xml, List<String> patterns) {
        if (patterns.isEmpty()) return xml;
        try {
            String sanitized = sanitizeXmlProlog(xml).replace("\r\n", "\n").replace("\r", "");
            Document doc = parseWithRecovery(sanitized);
            if (doc == null) return xml;  // fall through; downstream will report it
            XPath xp = XPathFactory.newInstance().newXPath();
            for (String pat : patterns) {
                try {
                    NodeList nodes = (NodeList) xp.evaluate(pat, doc, XPathConstants.NODESET);
                    for (int i = 0; i < nodes.getLength(); i++) {
                        nodes.item(i).setTextContent("__IGNORED__");
                    }
                } catch (Exception ignore) {}
            }
            javax.xml.transform.Transformer t = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
            java.io.StringWriter sw = new java.io.StringWriter();
            t.transform(new javax.xml.transform.dom.DOMSource(doc), new javax.xml.transform.stream.StreamResult(sw));
            return sw.toString();
        } catch (Exception ex) {
            return xml;
        }
    }

    @SuppressWarnings("unchecked")
    private static void applyJsonpathIgnores(Object obj, List<String> patterns) {
        if (patterns.isEmpty()) return;
        try {
            String json = MAPPER.writeValueAsString(obj);
            ReadContext ctx = JsonPath.using(JSONPATH_CFG).parse(json);
            Object doc = ctx.json();
            for (String pat : patterns) {
                try {
                    JsonPath.using(JSONPATH_CFG).parse(doc).set(pat, "__IGNORED__");
                } catch (Exception ignore) {}
            }
            // Copy patched back into obj
            if (obj instanceof Map && doc instanceof Map) {
                ((Map<String, Object>) obj).clear();
                ((Map<String, Object>) obj).putAll((Map<String, Object>) doc);
            }
        } catch (Exception ignore) {}
    }

    // ------------------------------------------------------------------
    // Recursive diff
    // ------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    public static void diff(Object a, Object b, String path, List<DiffEntry> diffs) {
        if ("__IGNORED__".equals(a) || "__IGNORED__".equals(b)) return;
        if (a == null && b == null) return;
        if (a == null) {
            diffs.add(new DiffEntry(path, "<missing>", String.valueOf(b), "removed"));
            return;
        }
        if (b == null) {
            diffs.add(new DiffEntry(path, String.valueOf(a), "<missing>", "added"));
            return;
        }

        // Numeric tolerance: treat numbers as numbers regardless of int/double
        if (a instanceof Number && b instanceof Number) {
            if (((Number) a).doubleValue() != ((Number) b).doubleValue()) {
                diffs.add(new DiffEntry(path, a.toString(), b.toString(), "value"));
            }
            return;
        }

        if (a.getClass() != b.getClass() && !(a instanceof Map && b instanceof Map)
                && !(a instanceof List && b instanceof List)) {
            // Treat numeric strings vs numbers as a value mismatch
            diffs.add(new DiffEntry(path, a.toString(), b.toString(), "type"));
            return;
        }

        if (a instanceof Map && b instanceof Map) {
            Map<String, Object> ma = (Map<String, Object>) a;
            Map<String, Object> mb = (Map<String, Object>) b;
            Set<String> keys = new TreeSet<>();
            keys.addAll(ma.keySet());
            keys.addAll(mb.keySet());
            for (String k : keys) {
                String childPath = path + "." + k;
                if (!ma.containsKey(k)) diffs.add(new DiffEntry(childPath, "<missing>", String.valueOf(mb.get(k)), "added"));
                else if (!mb.containsKey(k)) diffs.add(new DiffEntry(childPath, String.valueOf(ma.get(k)), "<missing>", "removed"));
                else diff(ma.get(k), mb.get(k), childPath, diffs);
            }
            return;
        }

        if (a instanceof List && b instanceof List) {
            List<Object> la = (List<Object>) a;
            List<Object> lb = (List<Object>) b;
            if (la.size() != lb.size()) {
                diffs.add(new DiffEntry(path, "length=" + la.size(), "length=" + lb.size(), "length"));
            }
            int min = Math.min(la.size(), lb.size());
            for (int i = 0; i < min; i++) {
                diff(la.get(i), lb.get(i), path + "[" + i + "]", diffs);
            }
            return;
        }

        if (!Objects.equals(a, b)) {
            diffs.add(new DiffEntry(path, a.toString(), b.toString(), "value"));
        }
    }

    // ------------------------------------------------------------------
    // Variable extraction
    // ------------------------------------------------------------------

    /** Thrown when extractVariable fails for a reportable reason. */
    public static class ExtractionException extends RuntimeException {
        public ExtractionException(String msg) { super(msg); }
    }

    public static String extractVariable(String payload, String path) {
        String fmt = detectFormat(payload);
        if ("json".equals(fmt)) {
            try {
                Object value = JsonPath.using(JSONPATH_CFG).parse(payload).read(path);
                if (value == null) return "";
                if (value instanceof List) {
                    List<?> list = (List<?>) value;
                    return list.isEmpty() ? "" : String.valueOf(list.get(0));
                }
                return String.valueOf(value);
            } catch (Exception ex) {
                throw new ExtractionException("JSONPath failed: " + ex.getMessage());
            }
        }
        if ("xml".equals(fmt)) {
            // STRATEGY 1: Parser-free tag walker.
            // Handles the most common XPath idioms (//Tag, //Tag[N],
            // //Parent[Child='V'], chained navigation) WITHOUT requiring
            // strict-XML compliance from the response. This works against
            // real-world SOAP responses that confound proper XML parsers.
            try {
                String walked = SimpleXmlWalker.findFirst(payload, path);
                if (!walked.isEmpty()) return walked;
            } catch (Exception ignore) {
                // Fall through to strict parser
            }

            // STRATEGY 2: Strict XML parser with the recovery chain.
            // Kept as fallback for queries the simple walker can't handle
            // (count(), starts-with(), complex predicates, attribute paths).
            // Servers sometimes return XML containing HTML-escaped XML as text
            // content (common SOAP pattern). Decode so XPath can address the
            // inner elements directly without the user knowing about the wrap.
            String decoded = decodeEmbeddedEscapedXml(payload);
            // Normalize CRLF/CR — servers sometimes send Windows line endings
            // which end up as &#xd; in extracted values.
            decoded = decoded.replace("\r\n", "\n").replace("\r", "");
            // Strip literal &#xd; / &#xD; / &#13; entity references that appear
            // in element content when servers double-encode carriage returns.
            // These are legal XML character refs but appear as visible junk in
            // extracted values; remove them everywhere.
            decoded = decoded.replaceAll("&#x[dD];", "").replaceAll("&#13;", "");
            // Strip BOM + leading whitespace BEFORE <?xml ... ?>
            String sanitized = sanitizeXmlProlog(decoded);

            // Try progressively more aggressive recovery strategies before
            // giving up. This keeps the framework usable against real-world
            // SOAP servers that emit malformed XML.
            Document doc = parseWithRecovery(sanitized);
            if (doc == null) {
                // Final fallback: simple regex-based extraction.
                // Only works for plain //TagName or //Parent[Child='X']/TagName,
                // but covers the vast majority of real-world assertions.
                String fallback = regexExtract(sanitized, path);
                if (fallback != null) return fallback;

                // Diagnostic: show position of the offending <?xml so the user
                // can find the malformation in the raw response file.
                int innerXml = findInnerXmlPosition(sanitized);
                String hint = innerXml > 0
                        ? " (stray <?xml found at column " + (innerXml + 1) + ")"
                        : "";
                throw new ExtractionException(
                        "XML response is severely malformed and could not be recovered" + hint +
                        ". Inspect output/<timestamp>/<TestID>/sourceA/step*/response.txt. " +
                        "First 200 chars: " + safePreview(sanitized, 200));
            }

            try {
                XPath xp = XPathFactory.newInstance().newXPath();
                // Evaluate to a NodeSet first so we can detect "no match" cleanly.
                org.w3c.dom.NodeList nodes = (org.w3c.dom.NodeList) xp.evaluate(path, doc, XPathConstants.NODESET);
                if (nodes != null && nodes.getLength() > 0) {
                    String v = nodes.item(0).getTextContent();
                    return v == null ? "" : v.trim();
                }
                // Fall back to a string evaluation for paths that return scalars
                // (e.g. count(...), string-length(...), or attribute selections).
                Object str = xp.evaluate(path, doc, XPathConstants.STRING);
                String s = str == null ? "" : str.toString().trim();
                return s;
            } catch (javax.xml.xpath.XPathExpressionException ex) {
                throw new ExtractionException("XPath syntax error: " + ex.getMessage());
            } catch (Exception ex) {
                throw new ExtractionException("XPath evaluation failed: " + ex.getMessage());
            }
        }
        return "";
    }

    /**
     * Try parsing with three escalating strategies. Returns null if all fail.
     */
    private static Document parseWithRecovery(String xml) {
        // Attempt 1: parse as-is (already sanitized for BOM and inner <?xml).
        try {
            return buildAndParse(xml);
        } catch (Exception ignore) {}

        // Attempt 2: aggressively strip EVERY <?xml ... ?> processing
        // instruction except the very first one (if any). Some servers
        // emit them in extremely creative places that the targeted sanitizer
        // doesn't catch.
        String stripped = stripAllInnerXmlPis(xml);
        if (!stripped.equals(xml)) {
            try {
                return buildAndParse(stripped);
            } catch (Exception ignore) {}
        }

        // Attempt 3: strip invalid XML 1.0 characters (NUL bytes, raw control
        // chars, lone surrogates) which some legacy mainframe backends emit.
        String cleaned = stripInvalidXmlChars(stripped);
        if (!cleaned.equals(stripped)) {
            try {
                return buildAndParse(cleaned);
            } catch (Exception ignore) {}
        }

        // Attempt 4: wrap content in a fake root so multiple top-level
        // siblings (the second-document case) parse as one tree. We then
        // re-extract against the inner content.
        String wrapped = "<__root__>" + cleaned.replaceFirst("(?i)^\\s*<\\?xml[^?]*\\?>", "") + "</__root__>";
        try {
            return buildAndParse(wrapped);
        } catch (Exception ignore) {}

        return null;
    }

    private static Document buildAndParse(String xml) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(false);
        DocumentBuilder b = dbf.newDocumentBuilder();
        // Custom error handler: swallow EVERYTHING quietly. Fatal errors throw
        // SAXParseException up to us, which the recovery chain catches.
        b.setErrorHandler(new org.xml.sax.ErrorHandler() {
            public void warning(org.xml.sax.SAXParseException e) {}
            public void error(org.xml.sax.SAXParseException e) {}
            public void fatalError(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException {
                throw e;
            }
        });

        // Xerces writes "[Fatal Error] :1:N: ..." DIRECTLY to System.err
        // before invoking our error handler. Suppress that channel during
        // the parse attempt so the user doesn't see a misleading error in
        // their console when the recovery chain is doing its job.
        java.io.PrintStream originalErr = System.err;
        try {
            System.setErr(new java.io.PrintStream(java.io.OutputStream.nullOutputStream()));
            return b.parse(new InputSource(new StringReader(xml)));
        } finally {
            System.setErr(originalErr);
        }
    }

    /**
     * Strip every &lt;?xml ... ?&gt; processing instruction. Aggressive — used
     * as a last-ditch recovery before declaring the response unparseable.
     */
    private static String stripAllInnerXmlPis(String xml) {
        if (xml == null || xml.isEmpty()) return xml;
        // Match <?xml...?> case-insensitively. Non-greedy body.
        return xml.replaceAll("(?i)<\\?xml[^?]*\\?>", "");
    }

    /**
     * Remove characters that are illegal in XML 1.0 — NUL bytes, raw control
     * chars (0x01–0x08, 0x0B, 0x0C, 0x0E–0x1F), and lone surrogates. Some
     * legacy backends (mainframes, COBOL services) emit these and crash any
     * conformant XML parser.
     */
    private static String stripInvalidXmlChars(String xml) {
        if (xml == null || xml.isEmpty()) return xml;
        StringBuilder out = new StringBuilder(xml.length());
        for (int i = 0; i < xml.length(); i++) {
            char c = xml.charAt(i);
            // Allowed XML 1.0 chars: 0x9, 0xA, 0xD, 0x20-0xD7FF, 0xE000-0xFFFD
            if (c == 0x9 || c == 0xA || c == 0xD
                    || (c >= 0x20 && c <= 0xD7FF)
                    || (c >= 0xE000 && c <= 0xFFFD)) {
                out.append(c);
            }
            // else: skip silently
        }
        return out.toString();
    }

    /**
     * Best-effort regex extraction when the XML can't be parsed at all.
     * Supports two path shapes:
     *   //TagName                            — first occurrence's inner text
     *   //Parent[Child='value']/Sibling      — find first Parent with a
     *                                          Child equal to 'value', then
     *                                          return the inner text of its
     *                                          Sibling child.
     * Returns null if the path shape isn't supported.
     */
    private static String regexExtract(String xml, String path) {
        if (xml == null || path == null) return null;
        // Shape A: //Tag (no predicates, no slashes after the tag name)
        java.util.regex.Matcher mA = java.util.regex.Pattern
                .compile("^//([A-Za-z_][\\w-]*)$")
                .matcher(path.trim());
        if (mA.matches()) {
            return regexFindFirstTag(xml, mA.group(1));
        }
        // Shape B: //Parent[Child='value']/Sibling   (or .../Sibling/SubSibling)
        java.util.regex.Matcher mB = java.util.regex.Pattern
                .compile("^//([A-Za-z_][\\w-]*)\\[([A-Za-z_][\\w-]*)\\s*=\\s*['\"]([^'\"]+)['\"]\\]/(.+)$")
                .matcher(path.trim());
        if (mB.matches()) {
            String parent = mB.group(1);
            String pred   = mB.group(2);
            String value  = mB.group(3);
            String tail   = mB.group(4);
            return regexFindParentWithChild(xml, parent, pred, value, tail);
        }
        return null;
    }

    private static String regexFindFirstTag(String xml, String tag) {
        // Match <tag ...>content</tag> (allow attributes; non-greedy content)
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "<(?:\\w+:)?" + java.util.regex.Pattern.quote(tag) + "(?:\\s[^>]*)?>(.*?)</(?:\\w+:)?"
                        + java.util.regex.Pattern.quote(tag) + ">",
                java.util.regex.Pattern.DOTALL);
        java.util.regex.Matcher m = p.matcher(xml);
        if (m.find()) {
            return stripTags(m.group(1)).trim();
        }
        return "";
    }

    private static String regexFindParentWithChild(String xml, String parent,
                                                   String childTag, String childValue,
                                                   String tail) {
        // Find every <parent>...</parent> block, then check if it contains
        // <childTag>childValue</childTag>. On match, look up the tail tag.
        java.util.regex.Pattern parentP = java.util.regex.Pattern.compile(
                "<(?:\\w+:)?" + java.util.regex.Pattern.quote(parent) + "(?:\\s[^>]*)?>"
                        + "(.*?)</(?:\\w+:)?" + java.util.regex.Pattern.quote(parent) + ">",
                java.util.regex.Pattern.DOTALL);
        java.util.regex.Matcher pm = parentP.matcher(xml);
        java.util.regex.Pattern childP = java.util.regex.Pattern.compile(
                "<(?:\\w+:)?" + java.util.regex.Pattern.quote(childTag) + "(?:\\s[^>]*)?>"
                        + "\\s*" + java.util.regex.Pattern.quote(childValue) + "\\s*"
                        + "</(?:\\w+:)?" + java.util.regex.Pattern.quote(childTag) + ">",
                java.util.regex.Pattern.DOTALL);

        while (pm.find()) {
            String body = pm.group(1);
            if (childP.matcher(body).find()) {
                // Found the right parent. Walk the tail path (split on /)
                // and return the first match in the parent body.
                String[] parts = tail.split("/");
                String lastTag = parts[parts.length - 1];
                return regexFindFirstTag(body, lastTag);
            }
        }
        return "";
    }

    private static String stripTags(String s) {
        return s.replaceAll("<[^>]+>", "");
    }

    private static String safePreview(String s, int max) {
        if (s == null) return "(null)";
        String t = s.replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
        return t.length() > max ? t.substring(0, max) + "..." : t;
    }

    /** Return the position of the first non-leading &lt;?xml, or -1. */
    private static int findInnerXmlPosition(String s) {
        if (s == null || s.isEmpty()) return -1;
        // Skip a legitimate leading <?xml ...?>
        int start = 0;
        if (s.startsWith("<?xml")) {
            int end = s.indexOf("?>", 5);
            if (end > 0) start = end + 2;
        }
        int p = s.indexOf("<?", start);
        while (p >= 0) {
            if (p + 5 <= s.length() && s.substring(p + 2, p + 5).equalsIgnoreCase("xml")) {
                return p;
            }
            p = s.indexOf("<?", p + 2);
        }
        return -1;
    }

    /**
     * Sanitize XML for parsing. Handles three real-world malformations seen
     * in enterprise SOAP responses:
     *
     *   1. BOM + leading whitespace/control chars before &lt;?xml — easy.
     *   2. Inner &lt;?xml declarations anywhere except position 0 — illegal
     *      per the spec, but real servers (especially chained proxies, MTOM
     *      strippers, and over-eager logging filters) emit them. We strip
     *      every non-leading &lt;?xml ... ?&gt; instruction.
     *   3. Two XML documents concatenated. We keep the first complete
     *      document by truncating at the first standalone &lt;?xml that
     *      appears after the leading prolog. Specifically: if a &lt;?xml
     *      declaration appears AFTER any element has already opened, we
     *      treat that as the start of a second document and discard from
     *      that point on.
     *
     * The fix is conservative — well-formed XML is unchanged.
     */
    public static String sanitizeXmlProlog(String xml) {
        if (xml == null || xml.isEmpty()) return xml;

        // Step 1: strip BOM + leading whitespace/control chars
        int start = 0;
        while (start < xml.length()) {
            char c = xml.charAt(start);
            if (c == '\uFEFF'
                    || c == '\u00A0'
                    || Character.isWhitespace(c)
                    || Character.isISOControl(c)) {
                start++;
            } else {
                break;
            }
        }
        String s = (start == 0) ? xml : xml.substring(start);
        if (s.isEmpty()) return s;

        // Step 2: locate the leading <?xml ... ?> prolog (if present) so we
        // know what's "the legitimate one" and can strip any subsequent ones.
        int searchFrom = 0;
        if (s.startsWith("<?xml")) {
            int prologEnd = s.indexOf("?>", 5);
            if (prologEnd > 0) {
                searchFrom = prologEnd + 2;
            }
        }

        // Step 3: scan for additional <?xml declarations or processing
        // instructions that target xml — both are the trigger of the
        // "[xX][mM][lL] is not allowed" error.
        int badIdx = findIllegalXmlPi(s, searchFrom);
        if (badIdx < 0) {
            return s;
        }

        // STRIP every non-leading <?xml ... ?> instruction.  This is the
        // safe, conservative recovery — it keeps all element content and
        // only removes the offending processing instructions.  Truncation
        // (used in earlier versions) would drop legitimate sibling elements
        // when the response had multiple top-level siblings with a stray
        // <?xml between them.
        StringBuilder out = new StringBuilder(s.length());
        out.append(s, 0, searchFrom);
        int cursor = searchFrom;
        while (cursor < s.length()) {
            int piStart = s.indexOf("<?", cursor);
            if (piStart < 0) {
                out.append(s, cursor, s.length());
                break;
            }
            // Append everything up to this PI start
            out.append(s, cursor, piStart);
            int piEnd = s.indexOf("?>", piStart + 2);
            if (piEnd < 0) {
                // Unterminated PI — best we can do is drop the rest
                break;
            }
            String target = s.substring(piStart + 2, Math.min(piStart + 6, s.length())).toLowerCase();
            if (target.startsWith("xml")) {
                // Skip this PI entirely
                cursor = piEnd + 2;
            } else {
                // Legitimate non-xml PI — keep it
                out.append(s, piStart, piEnd + 2);
                cursor = piEnd + 2;
            }
        }
        return out.toString();
    }

    /**
     * Find the next <?xml ... ?> processing instruction starting from `from`.
     * Returns the start index, or -1 if none.
     */
    private static int findIllegalXmlPi(String s, int from) {
        int idx = from;
        while (idx < s.length()) {
            int p = s.indexOf("<?", idx);
            if (p < 0) return -1;
            // Check the PI target — case-insensitive "xml"
            if (p + 5 <= s.length()) {
                String target = s.substring(p + 2, p + 5).toLowerCase();
                if (target.equals("xml")) {
                    return p;
                }
            }
            idx = p + 2;
        }
        return -1;
    }

    /**
     * If a payload contains 3+ HTML-escaped XML tags, decode them into real XML
     * so XPath can address the inner elements. Idempotent.
     */
    private static String decodeEmbeddedEscapedXml(String s) {
        if (s == null || !s.contains("&lt;")) return s;
        int hits = 0;
        int idx = 0;
        while ((idx = s.indexOf("&lt;", idx)) != -1) { hits++; idx += 4; if (hits >= 3) break; }
        if (hits < 3) return s;
        return s.replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'")
                .replace("&amp;", "&");
    }
}
