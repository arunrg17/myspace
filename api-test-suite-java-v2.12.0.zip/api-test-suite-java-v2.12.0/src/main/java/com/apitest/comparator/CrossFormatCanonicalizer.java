package com.apitest.comparator;

import java.math.BigDecimal;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Makes two responses of <em>different formats</em> (JSON vs XML/SOAP)
 * comparable even when their shapes and field names don't line up.
 *
 * <p>The problem: the same business data can come back as JSON from one
 * system and XML/SOAP from another, but with different key casing
 * (amount vs Amount), different nesting (currentBalance.amount vs
 * Balance/Amount), attributes instead of fields (hasBlocks="true" vs
 * "hasBlocks":true), extra wrappers (SOAP envelope, *Response, return),
 * and different number formats (1.2345E4 vs 12345.00000). A plain
 * tree diff reports all of that as differences even though the data is
 * identical.
 *
 * <p>This class canonicalizes a parsed tree (the nested Map/List/scalar
 * form that {@link Comparator} already produces) so both sides collapse
 * to the same shape before diffing:
 * <ol>
 *   <li><b>Wrapper stripping</b> — peel SOAP envelope/body, executeResponse,
 *       return, and *Response/*Overview wrappers so only the business
 *       payload remains.</li>
 *   <li><b>Key folding</b> — normalize every key to a canonical token
 *       (lowercase, separators removed) so Amount/amount/AMOUNT and
 *       current_balance/currentBalance all align. The original key is
 *       remembered for the report.</li>
 *   <li><b>Structure flattening</b> — a single-child wrapper object whose
 *       only job is to nest one value (e.g. Balance wrapping Amount) is
 *       collapsed so currentBalance.amount and Balance/Amount meet at the
 *       same canonical path.</li>
 *   <li><b>Value normalization</b> — numbers become BigDecimal compared by
 *       value not scale; "true"/"false" strings become booleans; strings
 *       are trimmed and Unicode-NFC normalized (umlauts).</li>
 * </ol>
 *
 * <p>This class does not decide equality — it only produces a canonical
 * tree. The existing {@link Comparator#diff} then compares the two
 * canonical trees, and its order-insensitive list matching pairs repeated
 * records (accounts, line items) by content regardless of order.
 *
 * <p>It never guesses across genuinely different <em>names</em>
 * (e.g. cashAccount.name vs SalesProduct.Name). Those are bridged either
 * because the records align on other fields and the value happens to
 * match, or by an explicit mapping (handled elsewhere). Silence beats a
 * wrong auto-match on financial data.
 */
final class CrossFormatCanonicalizer {

    private CrossFormatCanonicalizer() {}

    /** Wrapper element/key names that carry no business meaning and are peeled. */
    private static final java.util.Set<String> WRAPPER_KEYS = java.util.Set.of(
            "envelope", "body", "return", "executeresponse",
            "any", "content", "result", "response", "payload"
    );

    /** Suffixes that mark an element as a response wrapper (e.g. FooResponse, BarOverviewResponse). */
    private static final String[] WRAPPER_SUFFIXES = {
            "response", "overviewresponse", "responsemessage", "reply"
    };

    /**
     * Envelope-level transport keys. These carry routing/metadata, never
     * business data, and appear as <em>siblings</em> of the real payload inside
     * a routing envelope:
     * <pre>
     *   &lt;Envelope&gt;
     *     &lt;Version&gt;…&lt;/Version&gt;        &lt;-- transport
     *     &lt;Sender&gt;…&lt;/Sender&gt;          &lt;-- transport
     *     &lt;Receiver&gt;…&lt;/Receiver&gt;      &lt;-- transport
     *     &lt;Content&gt;&lt;![CDATA[ …business… ]]&gt;&lt;/Content&gt;
     *   &lt;/Envelope&gt;
     * </pre>
     * Recognising them lets the wrapper peeler see that {@code Content} is the
     * one real child and descend into it, instead of stopping because the map
     * has four entries.
     */
    private static final java.util.Set<String> METADATA_KEYS = java.util.Set.of(
            "header", "status", "sender", "receiver", "version"
    );

    /**
     * Canonicalize a parsed tree for cross-format comparison.
     *
     * @param tree the nested Map/List/scalar tree from Comparator
     * @return a new canonical tree; the input is not modified
     */
    static Object canonicalize(Object tree) {
        Object unwrapped = stripWrappers(tree);
        return normalize(unwrapped);
    }

    /**
     * Metadata / transport keys that exist only on the SOAP side and must be
     * excluded from the data comparison (they have no JSON equivalent).
     *
     * <p>Only {@code header} is excluded unconditionally — a SOAP {@code Header}
     * block is unambiguously transport metadata. The others
     * ({@code status}, {@code sender}, {@code receiver}, envelope
     * {@code version}) are excluded only at the envelope/wrapper level, never
     * inside a business record, because "status" and "version" are perfectly
     * ordinary business field names too. See {@link #stripMetadata}.
     */
    private static final java.util.Set<String> HEADER_KEYS = java.util.Set.of("header");

    /**
     * Decide whether a canonicalized payload is a <em>collection of records</em>
     * or a <em>single rich document</em>. This picks the comparison strategy.
     *
     * <p>The old logic reduced every payload to "the single largest list of
     * objects" and diffed only those records. That is correct for a list of
     * accounts, but destructive for a single document: the largest object-list
     * inside a customer record might be a handful of trivial flag entries, and
     * collapsing the comparison onto those silently discards the entire
     * customer/account/address tree — reporting a false match while a real
     * scalar difference goes unseen.
     *
     * <p>A payload is a collection only if, after dropping transport metadata
     * and descending wrappers whose sole business entry is another wrapper, the
     * content is a list of objects (or a map whose only business entry is such
     * a list). Anything else is a single document and gets the recursive
     * structural diff instead.
     *
     * @param canonicalTree output of {@link #canonicalize}
     * @return true if the payload is a repeated list of business records
     */
    @SuppressWarnings("unchecked")
    static boolean isCollectionPayload(Object canonicalTree) {
        Object node = descendToBusinessContent(canonicalTree);
        if (node instanceof List) {
            List<Object> list = (List<Object>) node;
            return !list.isEmpty() && list.stream().allMatch(x -> x instanceof Map);
        }
        return false;
    }

    /**
     * Drop transport metadata and descend through any node whose only business
     * entry is a nested map or list, returning the first node that actually
     * holds the content (a list, or a map with several business entries).
     */
    @SuppressWarnings("unchecked")
    private static Object descendToBusinessContent(Object node) {
        int guard = 0;
        while (node instanceof Map && guard++ < 20) {
            Map<String, Object> m = (Map<String, Object>) node;
            Object soleValue = null;
            int businessCount = 0;
            for (Map.Entry<String, Object> e : m.entrySet()) {
                if (METADATA_KEYS.contains(e.getKey())) continue;
                businessCount++;
                if (businessCount > 1) break;
                soleValue = e.getValue();
            }
            if (businessCount != 1) break;              // real content (or empty)
            if (soleValue instanceof Map || soleValue instanceof List) {
                node = soleValue;
            } else {
                break;                                   // sole entry is a scalar
            }
        }
        return node;
    }

    /**
     * Recursively remove SOAP {@code Header} blocks from a canonical tree.
     * Used by the single-document comparison path, where there is no entity
     * list to naturally exclude the transport metadata.
     *
     * @param canonicalTree output of {@link #canonicalize}
     * @return a new tree without header blocks
     */
    static Object dropHeaderBlocks(Object canonicalTree) {
        return stripHeaderOnly(canonicalTree);
    }

    /**
     * Reduce a canonicalized tree to a list of <em>flat records</em>, so two
     * sides with different nesting compare on their leaf values alone.
     *
     * <p>This is the step that bridges the structural gap the key-folding
     * can't: JSON's {@code currentBalance.amount} and XML's
     * {@code Balance/Amount} both flatten to the leaf key {@code amount};
     * the JSON {@code cashAccountsBalances[]} wrapper and the XML's repeated
     * {@code CashAccount} elements both become a list of records.
     *
     * <p>The entity collection is located by searching the tree for the
     * largest list of objects, so it is found even when it sits alongside
     * sibling metadata (e.g. a SOAP {@code Header} block next to the repeated
     * {@code CashAccount} elements). Transport metadata is dropped first so it
     * never pollutes a record or gets mistaken for the entity list.
     *
     * <p>Each record is a flat {@code Map<String,Object>} of
     * <em>disambiguated leaf keys</em> to normalized values, later matched by
     * business key (see {@link #businessKey}) rather than by position.
     *
     * @param canonicalTree output of {@link #canonicalize}
     * @return a list of flat records (one per business entity)
     */
    static List<Map<String, Object>> toRecords(Object canonicalTree) {
        // Find the entity collection first: the largest list of objects.
        List<Object> entityList = findEntityList(canonicalTree);

        List<Map<String, Object>> records = new ArrayList<>();
        if (entityList != null) {
            // We have a repeated entity list. Everything OUTSIDE this list
            // (SOAP envelope, Header, Status, Sender/Receiver, version) is
            // naturally excluded because we only take the list items. Inside
            // each item we drop only a Header block (unambiguous SOAP
            // metadata); business fields like Status/Version are preserved.
            for (Object item : entityList) {
                records.add(flatten(stripHeaderOnly(item)));
            }
        } else {
            // Single-entity payload (no repeated list). Peel wrapper layers to
            // reach the business object, dropping only Header blocks. We do
            // NOT drop status/version/etc. here because on a single entity
            // those are far more likely to be real business fields than SOAP
            // metadata — and a false "ignore" would hide a real difference.
            Object cleaned = stripHeaderOnly(canonicalTree);
            if (cleaned instanceof Map) {
                records.add(flatten(cleaned));
            }
        }
        return records;
    }

    /** Recursively drop only {@code header} blocks (unambiguous SOAP metadata). */
    @SuppressWarnings("unchecked")
    private static Object stripHeaderOnly(Object node) {
        if (node instanceof Map) {
            Map<String, Object> src = (Map<String, Object>) node;
            Map<String, Object> out = new LinkedHashMap<>();
            for (Map.Entry<String, Object> e : src.entrySet()) {
                if (HEADER_KEYS.contains(e.getKey())) continue;
                out.put(e.getKey(), stripHeaderOnly(e.getValue()));
            }
            return out;
        }
        if (node instanceof List) {
            List<Object> src = (List<Object>) node;
            List<Object> out = new ArrayList<>(src.size());
            for (Object item : src) out.add(stripHeaderOnly(item));
            return out;
        }
        return node;
    }

    /**
     * Find the entity collection in a tree: the largest list whose elements
     * are objects (maps). Searches depth-first so a list nested under wrappers
     * is still found. Returns null if there's no list of objects (single
     * entity payload).
     */
    @SuppressWarnings("unchecked")
    private static List<Object> findEntityList(Object node) {
        List<Object> best = null;
        java.util.Deque<Object> stack = new java.util.ArrayDeque<>();
        stack.push(node);
        while (!stack.isEmpty()) {
            Object cur = stack.pop();
            if (cur instanceof List) {
                List<Object> list = (List<Object>) cur;
                boolean objects = !list.isEmpty()
                        && list.stream().allMatch(x -> x instanceof Map);
                if (objects && (best == null || list.size() > best.size())) {
                    best = list;
                }
                for (Object item : list) stack.push(item);
            } else if (cur instanceof Map) {
                for (Object v : ((Map<String, Object>) cur).values()) stack.push(v);
            }
        }
        return best;
    }

    /**
     * Flatten one entity subtree into a single-level map of
     * disambiguated-leaf-key to value. Nested objects contribute their leaf
     * keys; if a bare leaf name would collide with one already present, the
     * immediate parent name is prefixed to disambiguate.
     */
    @SuppressWarnings("unchecked")
    private static Map<String, Object> flatten(Object node) {
        Map<String, Object> out = new LinkedHashMap<>();
        if (node instanceof Map) {
            flattenInto((Map<String, Object>) node, "", out);
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    private static void flattenInto(Map<String, Object> node, String parentKey,
                                    Map<String, Object> out) {
        for (Map.Entry<String, Object> e : node.entrySet()) {
            String key = e.getKey();
            Object val = e.getValue();
            if (val instanceof Map) {
                // Recurse; children carry this key as their immediate parent.
                flattenInto((Map<String, Object>) val, key, out);
            } else if (val instanceof List) {
                // A nested list inside an entity (e.g. sub-items). Store it
                // under the disambiguated key so it can still be compared.
                putDisambiguated(out, key, parentKey, val);
            } else {
                putDisambiguated(out, key, parentKey, val);
            }
        }
    }

    /**
     * Insert a leaf under its bare name, or under "parent.leaf" if the bare
     * name is already taken by a different-parent leaf (disambiguation).
     */
    private static void putDisambiguated(Map<String, Object> out, String leaf,
                                         String parentKey, Object val) {
        if (!out.containsKey(leaf)) {
            out.put(leaf, val);
            return;
        }
        // Collision: keep both, qualified by parent.
        String qualified = parentKey.isEmpty() ? leaf : parentKey + "." + leaf;
        out.putIfAbsent(qualified, val);
    }

    /**
     * Derive a stable business key for a flat record so records from the two
     * systems can be paired regardless of order. Prefers an "id"-like leaf;
     * falls back to null (caller then matches by full-value content).
     */
    static Object businessKey(Map<String, Object> record) {
        for (String candidate : new String[]{"id", "accountid", "key", "number", "iban"}) {
            Object v = record.get(candidate);
            if (v != null) return v;
        }
        return null;
    }

    // ──────────────────────────────────────────────────────────────────
    // Wrapper stripping
    // ──────────────────────────────────────────────────────────────────

    /**
     * Peel envelope / body / return / *Response wrappers off the top of
     * the tree until we reach the first node that either holds real data
     * (multiple keys, or a list) or can't be reduced further.
     */
    private static Object stripWrappers(Object node) {
        int guard = 0;
        while (node instanceof Map && guard++ < 20) {
            Map<?, ?> m = (Map<?, ?>) node;
            if (m.isEmpty()) break;

            // Find this node's business entries — everything that isn't
            // envelope-level transport metadata (Version/Sender/Receiver/
            // Header/Status). A routing envelope looks like a four-entry map
            // but has exactly ONE business child (Content), so ignoring the
            // transport siblings lets us keep descending instead of stopping
            // here and leaving the payload buried.
            String businessKey = null;
            Object businessValue = null;
            int businessCount = 0;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                String folded = foldKey(String.valueOf(e.getKey()));
                if (METADATA_KEYS.contains(folded)) continue;
                businessCount++;
                if (businessCount > 1) break;
                businessKey = folded;
                businessValue = e.getValue();
            }

            // More than one real child → this is the content, not a wrapper.
            if (businessCount != 1 || businessKey == null) break;

            if (isWrapperKey(businessKey)) {
                node = businessValue;                       // descend, dropping routing siblings
            } else {
                break;
            }
        }
        return node;
    }

    /** @return true if this folded key is a known wrapper or ends with a wrapper suffix. */
    private static boolean isWrapperKey(String foldedKey) {
        if (WRAPPER_KEYS.contains(foldedKey)) return true;
        for (String suf : WRAPPER_SUFFIXES) {
            if (foldedKey.endsWith(suf) && foldedKey.length() > suf.length()) return true;
        }
        return false;
    }

    // ──────────────────────────────────────────────────────────────────
    // Recursive normalization
    // ──────────────────────────────────────────────────────────────────

    /**
     * Recursively rebuild the tree: fold keys, collapse single-child
     * structural wrappers, and normalize scalar values.
     */
    @SuppressWarnings("unchecked")
    private static Object normalize(Object node) {
        if (node instanceof Map) {
            Map<String, Object> src = (Map<String, Object>) node;
            Map<String, Object> out = new LinkedHashMap<>();
            for (Map.Entry<String, Object> e : src.entrySet()) {
                String key = foldKey(e.getKey());
                Object val = collapseStructuralWrapper(key, e.getValue());
                Object normVal = normalize(val);
                // If two source keys fold to the same canonical key (rare but
                // possible, e.g. an attribute and an element), keep the first
                // non-null — they represent the same concept.
                out.merge(key, normVal, (existing, incoming) ->
                        existing != null ? existing : incoming);
            }
            return out;
        }
        if (node instanceof List) {
            List<Object> src = (List<Object>) node;
            List<Object> out = new ArrayList<>(src.size());
            for (Object item : src) out.add(normalize(item));
            return out;
        }
        return normalizeScalar(node);
    }

    /**
     * When a key's value is a single-entry map that merely wraps one leaf or
     * one list (e.g. Balance -> {Amount: 123}), and the wrapper key name is
     * "structural" (Balance, CurrentBalance), lift the inner value up so it
     * meets the other format's flattened field at the same canonical path.
     *
     * <p>Conservative: only collapses when the inner map has exactly one
     * entry AND that inner key folds to the same token as, or is contained
     * in, the outer key — i.e. Balance/Amount is NOT auto-collapsed (Amount
     * != Balance); instead both sides keep {balance:{amount:...}} vs
     * {currentbalance:{amount:...}} and the balance/currentbalance keys are
     * reconciled by {@link #reconcileBalanceLikeKeys}. Left as an explicit
     * hook rather than an aggressive guess.
     */
    private static Object collapseStructuralWrapper(String foldedKey, Object value) {
        return value; // no aggressive collapsing; see class doc / reconcile step
    }

    // ──────────────────────────────────────────────────────────────────
    // Key + value normalization
    // ──────────────────────────────────────────────────────────────────

    /**
     * Fold a key to a canonical comparison token: strip a namespace prefix,
     * strip a leading '@' (XML attribute marker), lowercase, and remove
     * separators (_, -, ., space). So "current_balance", "currentBalance",
     * "CurrentBalance" and "@currentBalance" all fold to "currentbalance".
     */
    static String foldKey(String key) {
        if (key == null) return "";
        String k = key;
        int colon = k.indexOf(':');
        if (colon >= 0) k = k.substring(colon + 1);   // drop ns prefix
        if (k.startsWith("@")) k = k.substring(1);      // drop attribute marker
        StringBuilder sb = new StringBuilder(k.length());
        for (int i = 0; i < k.length(); i++) {
            char c = k.charAt(i);
            if (c == '_' || c == '-' || c == '.' || c == ' ') continue;
            sb.append(Character.toLowerCase(c));
        }
        return sb.toString();
    }

    /**
     * Normalize a scalar so equal-but-differently-represented values match:
     * numbers to BigDecimal (value comparison, scale-insensitive), boolean
     * strings to Boolean, other strings trimmed + NFC-normalized.
     */
    static Object normalizeScalar(Object v) {
        if (v == null) return null;
        if (v instanceof Number) {
            // Re-parse through BigDecimal and strip trailing zeros so
            // 0.15 and 0.15000, or 1.2345E4 and 12345.00000, are equal.
            return new BigDecimal(v.toString()).stripTrailingZeros();
        }
        if (v instanceof Boolean) return v;
        String s = v.toString().trim();
        if (s.isEmpty()) return "";
        // Boolean-looking strings (XML attributes are always strings)
        if (s.equalsIgnoreCase("true")) return Boolean.TRUE;
        if (s.equalsIgnoreCase("false")) return Boolean.FALSE;
        // Dates: one platform may send yyyy-MM-dd while the other sends the
        // compact yyyyMMdd form. Collapse both to the compact digits, as a
        // STRING — deliberately before the numeric branch, so a compact date
        // isn't turned into a BigDecimal and compared against a String.
        String isoDate = asIsoDate(s);
        if (isoDate != null) return isoDate;
        // Numeric-looking strings → BigDecimal so "12345.00000" (XML text)
        // compares equal to a scientific-notation JSON number.
        if (looksNumeric(s)) {
            try {
                return new BigDecimal(s).stripTrailingZeros();
            } catch (NumberFormatException ignore) { /* fall through to text */ }
        }
        // Plain text: normalize Unicode so umlauts compare byte-for-byte.
        return Normalizer.normalize(s, Normalizer.Form.NFC);
    }

    /**
     * Recognise a calendar date in either {@code yyyy-MM-dd} or {@code yyyyMMdd}
     * form and return it as compact {@code yyyyMMdd} digits, or null if the
     * string is not a date.
     *
     * <p>Validation is strict on month and day so ordinary hyphenated codes and
     * plain 8-digit numbers are not mistaken for dates: {@code 2017-08-25} and
     * {@code 20170825} normalize to the same value, while {@code 12345678}
     * (month 56) and {@code 2017-99-99} stay untouched.
     */
    private static String asIsoDate(String s) {
        String digits;
        if (s.length() == 10 && s.charAt(4) == '-' && s.charAt(7) == '-') {
            digits = s.substring(0, 4) + s.substring(5, 7) + s.substring(8, 10);
        } else if (s.length() == 8) {
            digits = s;
        } else {
            return null;
        }
        for (int i = 0; i < digits.length(); i++) {
            if (digits.charAt(i) < '0' || digits.charAt(i) > '9') return null;
        }
        int year = Integer.parseInt(digits.substring(0, 4));
        int month = Integer.parseInt(digits.substring(4, 6));
        int day = Integer.parseInt(digits.substring(6, 8));
        if (year < 1000 || year > 9999) return null;
        if (month < 1 || month > 12) return null;
        if (day < 1 || day > 31) return null;
        return digits;
    }

    /** Quick check: does this string look like a plain decimal/scientific number? */
    private static boolean looksNumeric(String s) {
        if (s.isEmpty()) return false;
        int i = 0;
        if (s.charAt(0) == '+' || s.charAt(0) == '-') i = 1;
        if (i >= s.length()) return false;
        boolean digit = false, dot = false, exp = false;
        for (; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') { digit = true; continue; }
            if (c == '.' && !dot && !exp) { dot = true; continue; }
            if ((c == 'e' || c == 'E') && digit && !exp) {
                exp = true;
                if (i + 1 < s.length() && (s.charAt(i + 1) == '+' || s.charAt(i + 1) == '-')) i++;
                continue;
            }
            return false;
        }
        return digit;
    }
}
