package com.apitest.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Outcome of comparing two payloads (expected vs actual, or source A vs B).
 *
 * <ul>
 *   <li>{@code matched} — whether the structures and values agree
 *   <li>{@code diffs}   — list of mismatches, each tagged with its kind
 *   <li>{@code note}    — short human-readable description of the formats compared
 *   <li>{@code preparedExpected} / {@code preparedActual} — the unwrapped,
 *       pretty-printed payloads that were ACTUALLY fed into the comparator.
 *       Useful for the HTML report to show users what was compared.
 * </ul>
 */
public class CompareResult {
    public boolean matched;
    public List<DiffEntry> diffs = new ArrayList<>();
    public String note = "";

    /** Expected side after CDATA unwrap, entity decode, and pretty-print. */
    public String preparedExpected;

    /** Actual side after CDATA unwrap, entity decode, and pretty-print. */
    public String preparedActual;

    /** @return a short one-line summary of the comparison outcome. */
    public String getSummary() {
        if (matched) return "MATCH";
        return diffs.size() + " difference(s)";
    }
}
