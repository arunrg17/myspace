package com.apitest.model;

import java.util.List;
import java.util.Map;

/**
 * A single HTTP request in a test sequence.
 *
 * <p>For {@code vs_protocol} mode where Source A and Source B differ, the
 * Endpoint, Method and BodyTemplate cells can each hold two pipe-separated
 * values — the first for Source A, the second for Source B. For example:
 * <pre>
 *   Endpoint:     /rest/v1/accounts?id=1 | /ServiceRouter
 *   Method:       GET | POST
 *   BodyTemplate: | soap_get_accounts.xml
 * </pre>
 * Here Source A is a REST GET with no body, and Source B is a SOAP POST that
 * renders {@code soap_get_accounts.xml}. If a cell has no pipe, the single
 * value is used for both sources.
 *
 * <p>{@code method}/{@code endpoint}/{@code bodyTemplate} hold the Source A
 * values; {@code methodB}/{@code endpointB}/{@code bodyTemplateB} hold the
 * Source B values (empty string means "same as Source A").
 *
 * <p>Each step can override the environment's default headers via
 * {@code extraHeaders}.
 */
public record Step(
        String testId,
        int order,
        String name,
        String method,
        String methodB,
        String endpoint,
        String endpointB,
        String bodyTemplate,
        String bodyTemplateB,
        Map<String, String> extractVars,
        List<Integer> expectedStatus,
        Map<String, String> extraHeaders
) {
    /** The HTTP method to use for the given source ("A" or "B"). */
    public String methodFor(String source) {
        if ("B".equals(source) && methodB != null && !methodB.isEmpty()) return methodB;
        return method;
    }

    /** The endpoint to use for the given source ("A" or "B"). */
    public String endpointFor(String source) {
        if ("B".equals(source) && endpointB != null && !endpointB.isEmpty()) return endpointB;
        return endpoint;
    }

    /** The body template to use for the given source ("A" or "B"). */
    public String bodyTemplateFor(String source) {
        if ("B".equals(source)) {
            // An explicit Source B template wins. If the B side was written as
            // just "|template" the A side is empty and B has the template.
            if (bodyTemplateB != null && !bodyTemplateB.isEmpty()) return bodyTemplateB;
            // If the Method/Endpoint were split but BodyTemplate was a single
            // shared value, fall through to the shared template.
            if (bodyTemplateB != null && bodyTemplateB.isEmpty()
                    && (bodyTemplate == null || bodyTemplate.isEmpty())) return "";
        }
        return bodyTemplate;
    }
}
