package com.apitest.dispatcher;

import javax.net.ssl.*;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SSL/TLS configuration parser and SSLContext factory.
 *
 * <p>Configured via the Environments sheet's SslConfig column. Format is a
 * semicolon-separated list of key=value pairs:
 *
 * <pre>
 *   trust_store=/path/to/cacerts.jks; trust_password=${env.TRUST_PASS}
 *   key_store=/path/to/client.p12; key_password=${env.KEY_PASS}; key_type=PKCS12
 *   trust_store=...; key_store=...                  (mTLS — both sides)
 *   verify=false                                    (skip cert validation — DEV ONLY)
 * </pre>
 *
 * <p>Supported keys:
 * <ul>
 *   <li>trust_store     — path to truststore (server CA / self-signed)
 *   <li>trust_password  — truststore password
 *   <li>trust_type      — JKS (default) | PKCS12
 *   <li>key_store       — path to keystore (client cert + private key for mTLS)
 *   <li>key_password    — keystore password
 *   <li>key_type        — JKS (default) | PKCS12
 *   <li>verify          — true (default) | false — DO NOT use false in production
 * </ul>
 *
 * <p>Password values support three forms:
 * <ul>
 *   <li>{@code ${env.MY_VAR}}                               — from OS environment
 *   <li>{@code ${file./path/to/ssl.properties:key_password}} — from a .properties file
 *   <li>Plain text                                           — literal (not recommended)
 * </ul>
 *
 * <p>Example ssl.properties file:
 * <pre>
 *   trust_password=changeit
 *   key_password=secret123
 * </pre>
 *
 * <p>Example SslConfig column using a config file:
 * <pre>
 *   trust_store=/certs/ca.jks; trust_password=${file./config/ssl.properties:trust_password}; key_store=/certs/client.p12; key_password=${file./config/ssl.properties:key_password}
 * </pre>
 *
 * <p>Built SSLContexts are cached per-config so we don't reload keystores
 * on every request.
 */
public class SslConfig {

    private static final Map<String, SSLContext> CACHE = new ConcurrentHashMap<>();

    /**
     * Build (and cache) an {@link SSLContext} from a config string.
     * The same config string returns the same cached context, so repeated
     * requests to one environment don't rebuild the trust material.
     *
     * @param configStr semicolon-separated SSL settings, or null/blank
     * @return a configured context, or null when no SSL config is given
     */
    public static SSLContext buildContext(String configStr) {
        String key = configStr == null ? "" : configStr.trim();
        if (key.isEmpty()) return null;  // null = use JVM default

        return CACHE.computeIfAbsent(key, SslConfig::build);
    }

    /** True if config explicitly disables certificate verification. */
    /**
     * @return true if the config contains {@code verify=false}, meaning
     *         certificate and hostname checks should be skipped (DEV only).
     */
    public static boolean isVerifyDisabled(String configStr) {
        Map<String, String> opts = parse(configStr);
        String v = opts.get("verify");
        return v != null && ("false".equalsIgnoreCase(v) || "no".equalsIgnoreCase(v));
    }

    // ------------------------------------------------------------------

    /**
     * Actually construct the SSL context from parsed settings: optional
     * truststore, optional client keystore (for mutual TLS), or an
     * all-trusting manager when {@code verify=false}.
     */
    private static SSLContext build(String configStr) {
        try {
            Map<String, String> opts = parse(configStr);

            TrustManager[] trustManagers;
            if ("false".equalsIgnoreCase(opts.get("verify"))) {
                // Certificate and hostname checking are both off from here on.
                // That is occasionally needed against a dev box with a
                // self-signed cert, but it must never go unnoticed in a shared
                // config, so say so on stderr every time a context is built.
                System.err.println("WARNING: TLS verification is disabled (verify=false). "
                        + "Certificates and hostnames are not checked for this environment. "
                        + "Do not use this against production.");
                trustManagers = new TrustManager[]{ new TrustAllManager() };
            } else if (opts.containsKey("trust_store")) {
                KeyStore ts = loadKeyStore(
                        opts.get("trust_store"),
                        resolveSecret(opts.getOrDefault("trust_password", "")),
                        opts.getOrDefault("trust_type", inferType(opts.get("trust_store")))
                );
                TrustManagerFactory tmf = TrustManagerFactory.getInstance(
                        TrustManagerFactory.getDefaultAlgorithm());
                tmf.init(ts);
                trustManagers = tmf.getTrustManagers();
            } else {
                trustManagers = null;  // JVM default cacerts
            }

            KeyManager[] keyManagers = null;
            if (opts.containsKey("key_store")) {
                String pw = resolveSecret(opts.getOrDefault("key_password", ""));
                KeyStore ks = loadKeyStore(
                        opts.get("key_store"),
                        pw,
                        opts.getOrDefault("key_type", inferType(opts.get("key_store")))
                );
                KeyManagerFactory kmf = KeyManagerFactory.getInstance(
                        KeyManagerFactory.getDefaultAlgorithm());
                kmf.init(ks, pw.toCharArray());
                keyManagers = kmf.getKeyManagers();
            }

            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(keyManagers, trustManagers, new SecureRandom());
            return ctx;
        } catch (Exception ex) {
            throw new RuntimeException("SSL config failed: " + ex.getMessage()
                    + " (config: " + configStr + ")", ex);
        }
    }

    /**
     * Load a JKS or PKCS12 keystore/truststore from disk.
     * @param type store type; inferred from the file extension when blank
     */
    private static KeyStore loadKeyStore(String path, String password, String type) throws Exception {
        KeyStore ks = KeyStore.getInstance(type);
        try (InputStream in = Files.newInputStream(Path.of(path))) {
            ks.load(in, password == null ? new char[0] : password.toCharArray());
        }
        return ks;
    }

    /** Infer the keystore type (PKCS12 or JKS) from the file extension. */
    private static String inferType(String path) {
        if (path == null) return "JKS";
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".p12") || lower.endsWith(".pfx")) return "PKCS12";
        return "JKS";
    }

    /**
     * Parse a semicolon-separated {@code key=value} config string into a map.
     * Recognised keys include trust_store, trust_password, key_store,
     * key_password, key_type and verify.
     */
    private static Map<String, String> parse(String configStr) {
        Map<String, String> out = new HashMap<>();
        if (configStr == null || configStr.isBlank()) return out;
        for (String part : configStr.split(";")) {
            int eq = part.indexOf('=');
            if (eq > 0) {
                String k = part.substring(0, eq).trim().toLowerCase(Locale.ROOT);
                String v = part.substring(eq + 1).trim();
                out.put(k, v);
            }
        }
        return out;
    }

    /**
     * Resolve a secret value. Three forms are supported:
     * <ul>
     *   <li>{@code ${env.VAR}}     — read from OS environment variable
     *   <li>{@code ${file./path/to/config.properties:key}} — read from a
     *       Java properties file (the path and key separated by a colon)
     *   <li>Any other string — used as a literal value
     * </ul>
     *
     * The file form lets users store certificate passwords in a config file
     * instead of environment variables, which is often easier on developer
     * machines and shared CI setups.
     */
    /**
     * Resolve a possibly-secret value to its plain text.
     *
     * <p>Supports three forms: {@code ${env.NAME}} reads an environment
     * variable, {@code ${file./path/to/file:key}} reads a key from a Java
     * .properties file, and anything else is returned literally. This keeps
     * real passwords and keys out of the workbook.
     *
     * @param value the raw value (may contain a secret reference)
     * @return the resolved plain-text value
     */
    public static String resolveSecret(String value) {
        if (value == null) return "";
        String trimmed = value.trim();

        // ${env.VAR_NAME}
        if (trimmed.startsWith("${env.") && trimmed.endsWith("}")) {
            String envVar = trimmed.substring(6, trimmed.length() - 1);
            String v = System.getenv(envVar);
            return v == null ? "" : v;
        }

        // ${file./path/to/config.properties:key_name}
        if (trimmed.startsWith("${file.") && trimmed.endsWith("}")) {
            String inner = trimmed.substring(7, trimmed.length() - 1);
            int colon = inner.lastIndexOf(':');
            if (colon > 0 && colon < inner.length() - 1) {
                String filePath = inner.substring(0, colon).trim();
                String key = inner.substring(colon + 1).trim();
                try {
                    java.util.Properties props = new java.util.Properties();
                    try (InputStream in = Files.newInputStream(Path.of(filePath))) {
                        props.load(in);
                    }
                    String v = props.getProperty(key);
                    return v == null ? "" : v;
                } catch (Exception ex) {
                    System.err.println("Warning: cannot read " + filePath + " for key " + key
                            + ": " + ex.getMessage());
                    return "";
                }
            }
        }

        return value;
    }

    // ------------------------------------------------------------------
    // Trust-all manager — used ONLY when verify=false (dev/test)
    // ------------------------------------------------------------------

    private static class TrustAllManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] c, String t) {}
        public void checkServerTrusted(X509Certificate[] c, String t) {}
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }
}
