package com.apitest.runner;

import java.nio.file.Path;

/**
 * Run-time configuration bundle.
 *
 * <p>All directories the runner needs to read from or write to are captured
 * here so they can be overridden from the command line. Lets users ship
 * just the jar to a colleague — the colleague provides the paths, no
 * matching directory layout required at the runner's working directory.
 *
 * <p>Resolution rules:
 * <ul>
 *   <li>{@code suitePath} — the Excel workbook (absolute or relative to CWD)
 *   <li>{@code reportPath} — output HTML report (absolute or relative to CWD)
 *   <li>{@code projectRoot} — base directory used to resolve any path in
 *       {@code templatesDir}, {@code expectedDir} or {@code outputDir} that
 *       was given as a relative path. Also the implicit base for any
 *       BodyTemplate or ExpectedFile entry in the Excel that is relative.
 *   <li>{@code templatesDir} — where {@code BodyTemplate} paths in Excel
 *       resolve against
 *   <li>{@code expectedDir} — where {@code ExpectedFile} paths in Excel
 *       resolve against
 *   <li>{@code outputDir} — where per-run artifact subdirectories are
 *       created (one per test run, timestamp-keyed)
 * </ul>
 *
 * Paths inside the Excel that are already absolute are honoured as-is.
 */
public final class RunConfig {

    public final Path suitePath;
    public final Path reportPath;
    public final Path projectRoot;
    public final Path templatesDir;
    public final Path expectedDir;
    public final Path outputDir;
    public final String name;

    /** Bundle the resolved input/output paths and run name for one execution. */
    public RunConfig(Path suitePath, Path reportPath, Path projectRoot,
                     Path templatesDir, Path expectedDir, Path outputDir,
                     String name) {
        this.suitePath = suitePath;
        this.reportPath = reportPath;
        this.projectRoot = projectRoot;
        this.templatesDir = templatesDir;
        this.expectedDir = expectedDir;
        this.outputDir = outputDir;
        this.name = name;
    }

    /**
     * Resolve a path written by the user (in Excel or on the CLI) against
     * the appropriate base directory. Absolute paths are returned as-is.
     */
    public static Path resolve(Path base, String userPath) {
        if (userPath == null || userPath.isEmpty()) return null;
        Path p = Path.of(userPath);
        if (p.isAbsolute()) return p;
        return base.resolve(userPath);
    }
}
