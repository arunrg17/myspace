package com.apitest;

import com.apitest.model.Step;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Cross-protocol steps let Source A and Source B differ in method, endpoint
 * and body template within one logical step, expressed with pipe-separated
 * cells: {@code Method="GET|POST"}, {@code Endpoint="/rest|/soap"},
 * {@code BodyTemplate="|soap_req.xml"}. These tests pin the resolution rules.
 */
class PerSourceStepTest {

    private static Step step(String method, String methodB, String ep, String epB,
                             String tmpl, String tmplB) {
        return new Step("T1", 1, "s", method, methodB, ep, epB, tmpl, tmplB,
                Map.of(), List.of(200), Map.of());
    }

    @Test
    void differentMethodPerSource() {
        Step s = step("GET", "POST", "/rest", "/soap", "", "soap.xml");
        assertEquals("GET", s.methodFor("A"));
        assertEquals("POST", s.methodFor("B"));
    }

    @Test
    void differentEndpointPerSource() {
        Step s = step("GET", "POST", "/rest/accounts", "/ServiceRouter", "", "soap.xml");
        assertEquals("/rest/accounts", s.endpointFor("A"));
        assertEquals("/ServiceRouter", s.endpointFor("B"));
    }

    @Test
    void restGetNoBodyVsSoapPostWithTemplate() {
        // The canonical case: A = REST GET no body, B = SOAP POST with template.
        Step s = step("GET", "POST", "/rest/accounts", "/ServiceRouter", "", "soap_req.xml");
        assertEquals("", s.bodyTemplateFor("A"), "Source A must have no body template");
        assertEquals("soap_req.xml", s.bodyTemplateFor("B"), "Source B must use the SOAP template");
    }

    @Test
    void sharedMethodWhenNoPipe() {
        Step s = step("GET", "", "/accounts", "", "", "");
        assertEquals("GET", s.methodFor("A"));
        assertEquals("GET", s.methodFor("B"), "No pipe means both sources share the method");
    }

    @Test
    void sharedEndpointWhenNoPipe() {
        Step s = step("GET", "", "/accounts", "", "", "");
        assertEquals("/accounts", s.endpointFor("A"));
        assertEquals("/accounts", s.endpointFor("B"));
    }

    @Test
    void sharedTemplateWhenNoPipe() {
        Step s = step("POST", "", "/a", "/b", "body.json", "");
        assertEquals("body.json", s.bodyTemplateFor("A"));
        assertEquals("body.json", s.bodyTemplateFor("B"), "A single template applies to both sources");
    }

    @Test
    void putVsPostWithDifferentTemplates() {
        Step s = step("PUT", "POST", "/rest/x", "/soap/y", "put_body.json", "post_body.xml");
        assertEquals("PUT", s.methodFor("A"));
        assertEquals("POST", s.methodFor("B"));
        assertEquals("put_body.json", s.bodyTemplateFor("A"));
        assertEquals("post_body.xml", s.bodyTemplateFor("B"));
    }

    // ── Loader pipe-splitting ────────────────────────────────────────────

    @Test
    void loaderSplitsPipeIntoTwoParts() {
        String[] p = com.apitest.excel.ExcelLoader.splitSourcePair("GET|POST");
        assertArrayEquals(new String[]{"GET", "POST"}, p);
    }

    @Test
    void loaderTrimsWhitespaceAroundPipe() {
        String[] p = com.apitest.excel.ExcelLoader.splitSourcePair("/rest/accounts | /ServiceRouter");
        assertArrayEquals(new String[]{"/rest/accounts", "/ServiceRouter"}, p);
    }

    @Test
    void loaderLeadingPipeMeansEmptySourceA() {
        String[] p = com.apitest.excel.ExcelLoader.splitSourcePair("|soap_req.xml");
        assertArrayEquals(new String[]{"", "soap_req.xml"}, p);
    }

    @Test
    void loaderNoPipeLeavesSourceBEmpty() {
        String[] p = com.apitest.excel.ExcelLoader.splitSourcePair("/accounts");
        assertArrayEquals(new String[]{"/accounts", ""}, p);
    }

    @Test
    void loaderHandlesNull() {
        String[] p = com.apitest.excel.ExcelLoader.splitSourcePair(null);
        assertArrayEquals(new String[]{"", ""}, p);
    }
}
