package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import com.apitest.model.Environment;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Regression tests for defensive hardening:
 *   - extractVariable tolerates null/empty inputs
 *   - countMatches / hasChildren tolerate null inputs
 *   - DB assertions reject non-SELECT statements and stacked statements
 *   - compare() never throws on adversarial inputs
 */
class RobustnessTest {

    @Test
    void extractVariableHandlesNulls() {
        assertEquals("", Comparator.extractVariable(null, "//a"));
        assertEquals("", Comparator.extractVariable("<a>1</a>", null));
        assertEquals("", Comparator.extractVariable("", "//a"));
        assertEquals("", Comparator.extractVariable("<a>1</a>", ""));
    }

    @Test
    void countMatchesHandlesNulls() {
        assertEquals(0, Comparator.countMatches(null, "//a"));
        assertEquals(0, Comparator.countMatches("<a/>", null));
        assertEquals(0, Comparator.countMatches("", "//a"));
    }

    @Test
    void hasChildrenHandlesNulls() {
        assertFalse(Comparator.hasChildren(null, "//a"));
        assertFalse(Comparator.hasChildren("<a/>", null));
        assertFalse(Comparator.hasChildren("", "//a"));
    }

    @Test
    void compareNeverThrowsOnGarbage() {
        assertDoesNotThrow(() -> Comparator.compare(null, null, List.of()));
        assertDoesNotThrow(() -> Comparator.compare("!@#$", "{]}[", List.of()));
        assertDoesNotThrow(() -> Comparator.compare("<a><b>", "<a></a>", null));
    }

    @Test
    void dbAssertionRejectsNonSelect() {
        Environment env = new Environment("E", "rest", "http://x", "none", "",
                Map.of(), "", "", "", Map.of(),
                "jdbc:h2:mem:test", "u", "p", "");
        for (String sql : new String[]{
                "DELETE FROM orders", "UPDATE orders SET x=1",
                "INSERT INTO orders VALUES (1)", "DROP TABLE orders",
                "TRUNCATE orders", "ALTER TABLE orders ADD c INT"}) {
            Assertion a = new Assertion(sql, "sql", "db_equals", "1", "");
            List<AssertionResult> rs = AssertionEngine.evaluate("{}", List.of(a), env);
            assertFalse(rs.get(0).passed, "Should reject: " + sql);
            assertTrue(rs.get(0).message.contains("read-only"),
                    "Should mention read-only for: " + sql + " (got: " + rs.get(0).message + ")");
        }
    }

    @Test
    void dbAssertionRejectsStackedStatements() {
        Environment env = new Environment("E", "rest", "http://x", "none", "",
                Map.of(), "", "", "", Map.of(),
                "jdbc:h2:mem:test", "u", "p", "");
        Assertion a = new Assertion("SELECT 1; DROP TABLE orders", "sql", "db_equals", "1", "");
        List<AssertionResult> rs = AssertionEngine.evaluate("{}", List.of(a), env);
        assertFalse(rs.get(0).passed);
        assertTrue(rs.get(0).message.contains("multiple statements"),
                "Should block stacked statements, got: " + rs.get(0).message);
    }

    @Test
    void dbAssertionAllowsSelectAndWith() {
        Environment env = new Environment("E", "rest", "http://x", "none", "",
                Map.of(), "", "", "", Map.of(),
                "jdbc:h2:mem:test", "u", "p", "");
        // These will fail at connection time (no real DB), but should pass the
        // SELECT/WITH guard — the error should be a DB error, not a guard rejection.
        for (String sql : new String[]{"SELECT status FROM orders", "WITH t AS (SELECT 1) SELECT * FROM t"}) {
            Assertion a = new Assertion(sql, "sql", "db_equals", "1", "");
            List<AssertionResult> rs = AssertionEngine.evaluate("{}", List.of(a), env);
            assertFalse(rs.get(0).message.contains("read-only"),
                    "SELECT/WITH should pass the guard: " + sql);
        }
    }

    @Test
    void dbAssertionWithNoEnvFailsGracefully() {
        Assertion a = new Assertion("SELECT 1", "sql", "db_equals", "1", "");
        List<AssertionResult> rs = AssertionEngine.evaluate("{}", List.of(a), null);
        assertFalse(rs.get(0).passed);
        assertTrue(rs.get(0).message.contains("No database configured"));
    }
}
