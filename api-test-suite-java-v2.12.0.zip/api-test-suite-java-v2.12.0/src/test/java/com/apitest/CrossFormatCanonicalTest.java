package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.CompareResult;
import com.apitest.model.DiffEntry;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Cross-format (JSON vs XML/SOAP) comparison where the two systems return
 * the same business data in different shapes: different key casing, wrapper
 * envelopes, attributes vs fields, nesting depth, and number formats.
 *
 * <p>These mirror the real GCP-JSON vs SOAP-XML case: camelCase vs PascalCase,
 * scientific-notation vs fixed-decimal numbers, hasBlocks as a field vs an
 * attribute, currency carried twice in JSON but once in XML, and account
 * records that may arrive in a different order.
 */
class CrossFormatCanonicalTest {

    private static String json(String id, String amount, String name) {
        return "{\"cashAccountsBalances\":[{"
             + "\"cashAccount\":{\"id\":\"" + id + "\",\"name\":\"" + name + "\",\"ccy\":\"EUR\","
             + "\"salesProduct\":{\"id\":\"P1\"}},"
             + "\"hasBlocks\":true,"
             + "\"currentBalance\":{\"amount\":" + amount + ",\"ccy\":\"EUR\"}}]}";
    }

    private static String xml(String id, String amount, String name) {
        return "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body>"
             + "<ns0:executeResponse xmlns:ns0=\"http://x/ws\"><return>"
             + "<CashAccountOverviewResponse>"
             + "<CashAccount hasBlocks=\"true\">"
             + "<Id>" + id + "</Id><Ccy>EUR</Ccy>"
             + "<Balance><Amount>" + amount + "</Amount></Balance>"
             + "<SalesProduct><Id>P1</Id><Name>" + name + "</Name></SalesProduct>"
             + "</CashAccount>"
             + "</CashAccountOverviewResponse></return></ns0:executeResponse></S:Body></S:Envelope>";
    }

    @Test
    void identicalDataDifferentFormatsMatch() {
        // camelCase JSON with scientific notation vs PascalCase XML with fixed decimals
        CompareResult r = Comparator.compare(
                json("ACC001", "1.23456789E7", "Sample Account"),
                xml("ACC001", "12345678.90000", "Sample Account"),
                List.of());
        assertTrue(r.matched, "Same data in JSON and SOAP must match. Diffs: " + r.diffs);
    }

    @Test
    void scientificVsFixedDecimalMatches() {
        CompareResult r = Comparator.compare(
                json("A1", "0.15", "X"),
                xml("A1", "0.15000", "X"),
                List.of());
        assertTrue(r.matched, "0.15 must equal 0.15000: " + r.diffs);
    }

    @Test
    void negativeScientificMatches() {
        CompareResult r = Comparator.compare(
                json("A1", "-1.2345E4", "X"),
                xml("A1", "-12345.00000", "X"),
                List.of());
        assertTrue(r.matched, "-1.2345E4 must equal -12345.00000: " + r.diffs);
    }

    @Test
    void differentAmountIsCaught() {
        CompareResult r = Comparator.compare(
                json("A1", "100.00", "X"),
                xml("A1", "999.00", "X"),
                List.of());
        assertFalse(r.matched, "A genuine amount difference must be reported");
    }

    @Test
    void differentNameIsCaught() {
        CompareResult r = Comparator.compare(
                json("A1", "100.00", "Account One"),
                xml("A1", "100.00", "Account Two"),
                List.of());
        assertFalse(r.matched, "A genuine name difference must be reported");
    }

    @Test
    void reorderedAccountsMatch() {
        String j = "{\"cashAccountsBalances\":["
                 + "{\"cashAccount\":{\"id\":\"A1\",\"ccy\":\"EUR\"},\"currentBalance\":{\"amount\":100}},"
                 + "{\"cashAccount\":{\"id\":\"A2\",\"ccy\":\"EUR\"},\"currentBalance\":{\"amount\":200}},"
                 + "{\"cashAccount\":{\"id\":\"A3\",\"ccy\":\"EUR\"},\"currentBalance\":{\"amount\":300}}]}";
        String x = "<Env><Body><CashAccountOverviewResponse>"
                 + "<CashAccount><Id>A3</Id><Ccy>EUR</Ccy><Balance><Amount>300.00</Amount></Balance></CashAccount>"
                 + "<CashAccount><Id>A1</Id><Ccy>EUR</Ccy><Balance><Amount>100.00</Amount></Balance></CashAccount>"
                 + "<CashAccount><Id>A2</Id><Ccy>EUR</Ccy><Balance><Amount>200.00</Amount></Balance></CashAccount>"
                 + "</CashAccountOverviewResponse></Body></Env>";
        CompareResult r = Comparator.compare(j, x, List.of());
        assertTrue(r.matched, "Accounts in a different order must still match: " + r.diffs);
    }

    @Test
    void oneWrongAccountAmongManyIsCaughtAndIdentified() {
        String j = "{\"cashAccountsBalances\":["
                 + "{\"cashAccount\":{\"id\":\"A1\",\"ccy\":\"EUR\"},\"currentBalance\":{\"amount\":100}},"
                 + "{\"cashAccount\":{\"id\":\"A2\",\"ccy\":\"EUR\"},\"currentBalance\":{\"amount\":200}}]}";
        String x = "<Env><Body><CashAccountOverviewResponse>"
                 + "<CashAccount><Id>A1</Id><Ccy>EUR</Ccy><Balance><Amount>100.00</Amount></Balance></CashAccount>"
                 + "<CashAccount><Id>A2</Id><Ccy>EUR</Ccy><Balance><Amount>999.00</Amount></Balance></CashAccount>"
                 + "</CashAccountOverviewResponse></Body></Env>";
        CompareResult r = Comparator.compare(j, x, List.of());
        assertFalse(r.matched);
        assertTrue(r.diffs.stream().anyMatch(d -> d.path.contains("A2")),
                "The diff should point at account A2: " + r.diffs);
    }

    @Test
    void missingAccountIsCaught() {
        String j = "{\"cashAccountsBalances\":["
                 + "{\"cashAccount\":{\"id\":\"A1\",\"ccy\":\"EUR\"},\"currentBalance\":{\"amount\":100}},"
                 + "{\"cashAccount\":{\"id\":\"A2\",\"ccy\":\"EUR\"},\"currentBalance\":{\"amount\":200}}]}";
        String x = "<Env><Body><CashAccountOverviewResponse>"
                 + "<CashAccount><Id>A1</Id><Ccy>EUR</Ccy><Balance><Amount>100.00</Amount></Balance></CashAccount>"
                 + "</CashAccountOverviewResponse></Body></Env>";
        CompareResult r = Comparator.compare(j, x, List.of());
        assertFalse(r.matched, "A missing account must be reported");
    }

    @Test
    void extraAccountIsCaught() {
        String j = "{\"cashAccountsBalances\":["
                 + "{\"cashAccount\":{\"id\":\"A1\",\"ccy\":\"EUR\"},\"currentBalance\":{\"amount\":100}}]}";
        String x = "<Env><Body><CashAccountOverviewResponse>"
                 + "<CashAccount><Id>A1</Id><Ccy>EUR</Ccy><Balance><Amount>100.00</Amount></Balance></CashAccount>"
                 + "<CashAccount><Id>A9</Id><Ccy>EUR</Ccy><Balance><Amount>900.00</Amount></Balance></CashAccount>"
                 + "</CashAccountOverviewResponse></Body></Env>";
        CompareResult r = Comparator.compare(j, x, List.of());
        assertFalse(r.matched, "An extra account must be reported");
    }

    @Test
    void hasBlocksAttributeMatchesJsonBooleanField() {
        // XML: attribute hasBlocks="true" ; JSON: field "hasBlocks":true
        CompareResult r = Comparator.compare(
                "{\"items\":[{\"id\":\"A1\",\"hasBlocks\":true,\"amount\":100}]}",
                "<r><Item hasBlocks=\"true\"><Id>A1</Id><Amount>100.00</Amount></Item></r>",
                List.of());
        assertTrue(r.matched, "XML attribute must match JSON boolean field: " + r.diffs);
    }

    @Test
    void unicodeUmlautNamesMatch() {
        // Same umlaut name; different Unicode normalization forms must still match
        CompareResult r = Comparator.compare(
                "{\"items\":[{\"id\":\"A1\",\"name\":\"M\u00fcller\",\"amount\":100}]}",
                "<r><Item><Id>A1</Id><Name>M\u00fcller</Name><Amount>100.00</Amount></Item></r>",
                List.of());
        assertTrue(r.matched, "Umlaut names must match: " + r.diffs);
    }

    @Test
    void currencyRedundancyIsNotReportedAsDifference() {
        // JSON carries ccy twice (account + balance); XML once. Not a real diff.
        CompareResult r = Comparator.compare(
                "{\"items\":[{\"cashAccount\":{\"id\":\"A1\",\"ccy\":\"EUR\"},\"currentBalance\":{\"amount\":100,\"ccy\":\"EUR\"}}]}",
                "<r><CashAccount><Id>A1</Id><Ccy>EUR</Ccy><Balance><Amount>100.00</Amount></Balance></CashAccount></r>",
                List.of());
        assertTrue(r.matched, "Duplicated currency in JSON must not be a difference: " + r.diffs);
    }

    // ── SOAP Header block exclusion (real-world shape) ───────────────────

    private static String soapWithHeader(String accounts) {
        return "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body>"
             + "<ns0:executeResponse xmlns:ns0=\"http://x/ws\"><return>"
             + "<CashAccountOverviewResponse>"
             + "<Header><EntityId>ENT</EntityId><Application>1</Application>"
             + "<Version>1</Version><User><Id>USR001</Id></User></Header>"
             + accounts
             + "</CashAccountOverviewResponse></return></ns0:executeResponse></S:Body></S:Envelope>";
    }

    private static String soapAcct(String id, String amount, boolean blocks, String rate) {
        String r = rate == null ? "" : "<InterestRate>" + rate + "</InterestRate>";
        return "<CashAccount hasBlocks=\"" + blocks + "\"><Id>" + id + "</Id><Ccy>EUR</Ccy>"
             + "<Balance><Amount>" + amount + "</Amount></Balance>"
             + "<SalesProduct><Id>P1</Id><Name>Sample</Name></SalesProduct>" + r + "</CashAccount>";
    }

    private static String jsonAcct(String id, double amount, boolean blocks, Double rate) {
        String r = rate == null ? "" : ",\"interestRate\":" + rate;
        return "{\"cashAccount\":{\"id\":\"" + id + "\",\"ccy\":\"EUR\","
             + "\"salesProduct\":{\"id\":\"P1\",\"name\":\"Sample\"},\"hasBlocks\":" + blocks + r + "},"
             + "\"currentBalance\":{\"amount\":" + amount + ",\"ccy\":\"EUR\"}}";
    }

    private static String jsonAccts(String... a) {
        return "{\"cashAccountsBalances\":[" + String.join(",", a) + "]}";
    }

    @Test
    void soapHeaderBlockIsExcludedFromComparison() {
        // The SOAP Header (EntityId, Application, Version, User) sits as a
        // sibling of the CashAccount elements and must not count as data.
        CompareResult r = Comparator.compare(
                jsonAccts(jsonAcct("A1", 100.0, true, null), jsonAcct("A2", 200.0, false, null)),
                soapWithHeader(soapAcct("A1", "100.00000", true, null)
                             + soapAcct("A2", "200.00000", false, null)),
                List.of());
        assertTrue(r.matched, "Header block must be excluded: " + r.diffs);
    }

    @Test
    void differentHeaderValuesDoNotCauseDifference() {
        String soapA = soapWithHeader(soapAcct("A1", "100.00", true, null));
        String soapDifferentHeader =
                "<S:Envelope xmlns:S=\"http://x\"><S:Body><ns0:executeResponse xmlns:ns0=\"http://x/ws\"><return>"
              + "<CashAccountOverviewResponse><Header><EntityId>XYZ</EntityId><Application>99</Application>"
              + "<Version>1</Version><User><Id>OTHER</Id></User></Header>"
              + soapAcct("A1", "100.00", true, null)
              + "</CashAccountOverviewResponse></return></ns0:executeResponse></S:Body></S:Envelope>";
        String json = jsonAccts(jsonAcct("A1", 100.0, true, null));
        CompareResult ra = Comparator.compare(json, soapA, List.of());
        CompareResult rb = Comparator.compare(json, soapDifferentHeader, List.of());
        assertTrue(ra.matched && rb.matched,
                "Header content must never affect the result. a=" + ra.diffs + " b=" + rb.diffs);
    }

    @Test
    void interestRatePresentOnlyOnSomeAccountsMatches() {
        // interestRate is present on the last two accounts only, consistently
        // on both sides — this must match, not report the absent ones as diffs.
        CompareResult r = Comparator.compare(
                jsonAccts(jsonAcct("A1", 100.0, true, null),
                          jsonAcct("A2", 200.0, false, 0.15),
                          jsonAcct("A3", 300.0, false, 0.25)),
                soapWithHeader(soapAcct("A1", "100.00", true, null)
                             + soapAcct("A2", "200.00", false, "0.15000")
                             + soapAcct("A3", "300.00", false, "0.25000")),
                List.of());
        assertTrue(r.matched, "Optional interestRate must match when consistent: " + r.diffs);
    }

    @Test
    void interestRateDifferenceIsCaught() {
        CompareResult r = Comparator.compare(
                jsonAccts(jsonAcct("A1", 100.0, false, 0.15)),
                soapWithHeader(soapAcct("A1", "100.00", false, "0.99000")),
                List.of());
        assertFalse(r.matched, "A real interestRate difference must be caught");
    }

    @Test
    void manyAccountsReorderedWithHeaderMatch() {
        CompareResult r = Comparator.compare(
                jsonAccts(jsonAcct("A1", 100.0, false, null), jsonAcct("A2", 200.0, false, null),
                          jsonAcct("A3", 300.0, false, null), jsonAcct("A4", 400.0, false, null),
                          jsonAcct("A5", 500.0, false, null)),
                soapWithHeader(soapAcct("A5", "500.00", false, null) + soapAcct("A3", "300.00", false, null)
                             + soapAcct("A1", "100.00", false, null) + soapAcct("A4", "400.00", false, null)
                             + soapAcct("A2", "200.00", false, null)),
                List.of());
        assertTrue(r.matched, "Reordered accounts (with header) must match: " + r.diffs);
    }
}
