package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Cross-format comparison of a <em>single rich document</em> (as opposed to a
 * repeated list of records).
 *
 * <p>These pin the two failures that made deeply nested documents compare
 * wrongly:
 * <ul>
 *   <li>reducing the payload to its largest inner list, which silently
 *       discarded the rest of the tree and reported a false match;</li>
 *   <li>failing to peel a routing envelope whose transport siblings
 *       ({@code Version}/{@code Sender}/{@code Receiver}) sit beside the
 *       {@code Content} holding the business payload.</li>
 * </ul>
 */
class CrossFormatDocumentTest {

    /**
     * A single document whose largest object-list ({@code informationDistribution})
     * is a set of trivial flags — the real data is the surrounding entity tree.
     */
    private static String json(String status, String date) {
        return "{\"masterPartner\":{"
             + "\"entityId\":\"E1\","
             + "\"usResident\":false,"
             + "\"phoneNumber\":[{\"type\":\"mobile\",\"value\":\"111\"}],"
             + "\"frameworkAgreement\":{\"status\":\"" + status + "\",\"date\":\"" + date + "\"},"
             + "\"informationDistribution\":["
             + "{\"type\":\"a\",\"agreed\":true},{\"type\":\"b\",\"agreed\":true},"
             + "{\"type\":\"c\",\"agreed\":true},{\"type\":\"d\",\"agreed\":false},"
             + "{\"type\":\"e\",\"agreed\":true},{\"type\":\"f\",\"agreed\":false}]"
             + "}}";
    }

    /** The same document as SOAP, inside a double envelope with routing siblings. */
    private static String xml(String status, String date) {
        return "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\"><S:Body>"
             + "<ns0:executeResponse xmlns:ns0=\"http://x/ws\"><return>"
             + "<Envelope>"
             + "<Version>1</Version>"
             + "<Sender><ApplicationId>APP1</ApplicationId></Sender>"
             + "<Receiver><ApplicationId>APP2</ApplicationId></Receiver>"
             + "<Content>"
             + "<PartnerReadResponse>"
             + "<MasterPartner usResident=\"false\">"
             + "<EntityId>E1</EntityId>"
             + "<PhoneNumber><Type>mobile</Type><Value>111</Value></PhoneNumber>"
             + "<FrameworkAgreement><Status>" + status + "</Status>"
             + "<Date>" + date + "</Date></FrameworkAgreement>"
             + "<InformationDistribution><Type>c</Type><Agreed>true</Agreed></InformationDistribution>"
             + "<InformationDistribution><Type>a</Type><Agreed>true</Agreed></InformationDistribution>"
             + "<InformationDistribution><Type>b</Type><Agreed>true</Agreed></InformationDistribution>"
             + "<InformationDistribution><Type>e</Type><Agreed>true</Agreed></InformationDistribution>"
             + "<InformationDistribution><Type>d</Type><Agreed>false</Agreed></InformationDistribution>"
             + "<InformationDistribution><Type>f</Type><Agreed>false</Agreed></InformationDistribution>"
             + "</MasterPartner>"
             + "</PartnerReadResponse>"
             + "</Content></Envelope>"
             + "</return></ns0:executeResponse></S:Body></S:Envelope>";
    }

    @Test
    void identicalRichDocumentMatchesAcrossFormats() {
        CompareResult r = Comparator.compare(json("1", "2017-08-25"),
                                             xml("1", "20170825"), List.of());
        assertTrue(r.matched, "Same document in two shapes must match: " + r.diffs);
    }

    @Test
    void scalarDifferenceDeepInTreeIsCaught() {
        // The regression: this used to report a false match because the whole
        // comparison collapsed onto the trivial flag list.
        CompareResult r = Comparator.compare(json("1", "2017-08-25"),
                                             xml("0", "20170825"), List.of());
        assertFalse(r.matched, "A genuine scalar difference must never be hidden");
        assertTrue(r.diffs.stream().anyMatch(d -> d.path.toLowerCase().contains("status")),
                "The diff should point at the differing field: " + r.diffs);
    }

    @Test
    void routingEnvelopeSiblingsAreNotDifferences() {
        // Version/Sender/Receiver exist only on the SOAP side.
        CompareResult r = Comparator.compare(json("1", "20170825"),
                                             xml("1", "20170825"), List.of());
        assertTrue(r.matched, "Routing metadata must be peeled, not reported: " + r.diffs);
    }

    @Test
    void reorderedNestedListStillMatches() {
        // The XML lists the flag entries in a different order than the JSON.
        CompareResult r = Comparator.compare(json("1", "20170825"),
                                             xml("1", "20170825"), List.of());
        assertTrue(r.matched, "Reordered nested list must not create diffs: " + r.diffs);
    }

    @Test
    void singleElementMatchesOneElementArray() {
        // XML has one <PhoneNumber> element; JSON has a one-element array.
        CompareResult r = Comparator.compare(
                "{\"partner\":{\"id\":\"P1\",\"phoneNumber\":[{\"value\":\"111\"}]}}",
                "<Partner><Id>P1</Id><PhoneNumber><Value>111</Value></PhoneNumber></Partner>",
                List.of());
        assertTrue(r.matched, "A lone element must line up with a one-element array: " + r.diffs);
    }

    @Test
    void fieldPresentOnOnlyOneSideIsReported() {
        String extra = json("1", "2017-08-25")
                .replace("\"entityId\":\"E1\",", "\"entityId\":\"E1\",\"extraField\":\"X\",");
        CompareResult r = Comparator.compare(extra, xml("1", "20170825"), List.of());
        assertFalse(r.matched, "A field on only one side must surface, not be hidden");
    }

    @Test
    void isoDateMatchesCompactDate() {
        CompareResult r = Comparator.compare(
                "{\"rec\":{\"id\":\"1\",\"when\":\"2017-08-25\"}}",
                "<Rec><Id>1</Id><When>20170825</When></Rec>",
                List.of());
        assertTrue(r.matched, "yyyy-MM-dd must equal yyyyMMdd: " + r.diffs);
    }

    @Test
    void nonDateDigitsAreNotTreatedAsDates() {
        // 12345678 has month 56 — it must stay a number, not become a date.
        CompareResult r = Comparator.compare(
                "{\"rec\":{\"id\":\"1\",\"code\":12345678}}",
                "<Rec><Id>1</Id><Code>87654321</Code></Rec>",
                List.of());
        assertFalse(r.matched, "Different numbers must still differ");
    }

    @Test
    void attributeMatchesJsonFieldInDocument() {
        // usResident is an XML attribute and a JSON boolean field.
        CompareResult r = Comparator.compare(json("1", "20170825"),
                                             xml("1", "20170825"), List.of());
        assertTrue(r.matched, "Attribute/field bridging must hold in documents: " + r.diffs);
    }
}
