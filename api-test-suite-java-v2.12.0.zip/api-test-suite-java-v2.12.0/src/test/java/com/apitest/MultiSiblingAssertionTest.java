package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Verifies that assertions check ALL matching sibling elements, not just
 * the first one. When multiple elements share the same tag name under one
 * parent, an assertion like {@code equals "300"} must pass if any of them
 * holds that value, even if the first one holds something different.
 */
class MultiSiblingAssertionTest {

    private static final String XML =
            "<root><group>"
          + "<item><type>A</type><val>100</val></item>"
          + "<item><type>B</type><val>200</val></item>"
          + "<item><type>C</type><val>300</val></item>"
          + "</group></root>";

    private static final String JSON =
            "{\"items\":[{\"type\":\"A\",\"val\":100},"
          + "{\"type\":\"B\",\"val\":200},"
          + "{\"type\":\"C\",\"val\":300}]}";

    // ── extractAllVariables ──────────────────────────────────────────────

    @Test
    void extractAllReturnsEveryXmlMatch() {
        List<String> vals = Comparator.extractAllVariables(XML, "//item/val");
        assertEquals(3, vals.size());
        assertTrue(vals.containsAll(List.of("100", "200", "300")));
    }

    @Test
    void extractAllReturnsEveryJsonMatch() {
        List<String> vals = Comparator.extractAllVariables(JSON, "$.items[*].val");
        assertEquals(3, vals.size());
    }

    @Test
    void extractAllSingleMatch() {
        List<String> vals = Comparator.extractAllVariables(XML, "//item[type='C']/val");
        assertEquals(1, vals.size());
        assertEquals("300", vals.get(0));
    }

    @Test
    void extractAllNoMatch() {
        List<String> vals = Comparator.extractAllVariables(XML, "//missing");
        assertTrue(vals.isEmpty());
    }

    // ── Assertion: equals across siblings ────────────────────────────────

    @Test
    void equalsPassesOnLaterSiblingXml() {
        Assertion a = new Assertion("//item/val", "xpath", "equals", "300", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(XML, List.of(a));
        assertTrue(rs.get(0).passed, "Should find 300 in third sibling: " + rs.get(0).message);
        assertEquals("300", rs.get(0).actualValue);
    }

    @Test
    void equalsPassesOnMiddleSiblingXml() {
        Assertion a = new Assertion("//item/val", "xpath", "equals", "200", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(XML, List.of(a));
        assertTrue(rs.get(0).passed);
    }

    @Test
    void equalsPassesOnLaterSiblingJson() {
        Assertion a = new Assertion("$.items[*].val", "jsonpath", "equals", "300", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(JSON, List.of(a));
        assertTrue(rs.get(0).passed, "Should find 300 in JSON array: " + rs.get(0).message);
    }

    @Test
    void equalsFailsWhenNoSiblingMatches() {
        Assertion a = new Assertion("//item/val", "xpath", "equals", "999", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(XML, List.of(a));
        assertFalse(rs.get(0).passed);
        // The error should show all values that were checked
        assertTrue(rs.get(0).actualValue.contains("100"),
                "Error should show checked values: " + rs.get(0).actualValue);
        assertTrue(rs.get(0).message.contains("3 matches"),
                "Error should mention match count: " + rs.get(0).message);
    }

    // ── Other operators across siblings ──────────────────────────────────

    @Test
    void containsPassesOnAnySibling() {
        Assertion a = new Assertion("//item/val", "xpath", "contains", "30", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(XML, List.of(a));
        assertTrue(rs.get(0).passed, "Should find '30' in 300: " + rs.get(0).message);
    }

    @Test
    void greaterThanPassesOnAnySibling() {
        Assertion a = new Assertion("//item/val", "xpath", "greater_than", "250", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(XML, List.of(a));
        assertTrue(rs.get(0).passed, "300 > 250 should pass: " + rs.get(0).message);
    }

    @Test
    void regexMatchPassesOnAnySibling() {
        Assertion a = new Assertion("//item/val", "xpath", "regex_match", "3\\d+", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(XML, List.of(a));
        assertTrue(rs.get(0).passed, "300 matches 3\\d+: " + rs.get(0).message);
    }

    @Test
    void oneOfPassesOnAnySibling() {
        Assertion a = new Assertion("//item/val", "xpath", "one_of", "300,400,500", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(XML, List.of(a));
        assertTrue(rs.get(0).passed, "300 is in the list: " + rs.get(0).message);
    }

    // ── Single match still works ─────────────────────────────────────────

    @Test
    void singleMatchPredicateStillWorks() {
        Assertion a = new Assertion("//item[type='A']/val", "xpath", "equals", "100", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(XML, List.of(a));
        assertTrue(rs.get(0).passed);
        assertEquals("100", rs.get(0).actualValue);
    }

    @Test
    void existsStillWorksWithMultipleMatches() {
        Assertion a = new Assertion("//item/val", "xpath", "exists", "", "");
        List<AssertionResult> rs = AssertionEngine.evaluate(XML, List.of(a));
        assertTrue(rs.get(0).passed);
    }
}
