# API Test Suite

**Version 2.12.0** — Excel-driven API testing for REST, SOAP, Fabric, and GCP — with multi-step chains,
structural response comparison, field-level assertions, and self-contained HTML
reports. Single Java JAR. No code required to add a test.

---

## Quick start

```bash
# Prerequisites: Java 21+ and Maven 3.8+
mvn package

# A ready-to-use starter workbook ships in config/test_suite.xlsx.
# Edit it to your needs, then run
java -jar target/api-test-suite.jar

# Open the report
open reports/report.html        # macOS
xdg-open reports/report.html    # Linux
start reports/report.html       # Windows
```

Exit code is `0` if every test passes, `1` otherwise — drop straight into any CI
pipeline.

### Running with just the jar (any directory layout)

Ship `target/api-test-suite.jar` to anyone. They can point each path at their
own files — nothing about the directory layout needs to match:

```bash
java -jar api-test-suite.jar \
  --suite          C:/work/tests/my_suite.xlsx \
  --report         C:/work/tests/report.html \
  --templates-dir  C:/work/tests/templates \
  --expected-dir   C:/work/tests/expected \
  --output-dir     C:/work/tests/run-artifacts
```

Or set just `--project-root` and the four conventional subdirectories
(`templates/`, `expected/`, `output/`, `config/`) are picked up automatically:

```bash
java -jar api-test-suite.jar --project-root C:/work/tests
```

Run `java -jar api-test-suite.jar --help` for the full flag list.

---

## Project layout

```
api-test-suite/
├── pom.xml                       Maven build
├── config/
│   └── test_suite.xlsx           Your test definitions (generated)
├── templates/                    Request body templates with ${placeholders}
│   ├── create_order.xml
│   ├── update_order.xml
│   └── get_account.xml
├── expected/                     Baseline responses for vs_expected mode
│   └── T002_create_order.xml
├── reports/
│   └── report.html               Generated after each run
├── output/                       Raw request/response captures per run
│   └── 20260513_123456/
│       └── T001/sourceA/step1_get_customer/{request,response}.txt
└── src/main/java/com/apitest/    Source
```

---

## How a test runs

1. **Load** the Excel suite — Environments, TestSuite, Steps, TestData, Assertions.
2. **For each enabled test:**
   - Resolve placeholders from the TestData row.
   - Send each step's HTTP request to source A (and source B for two-sided modes).
   - Extract response variables for later steps in the chain.
   - Compare and/or assert per the comparison mode.
3. **Write** the HTML report and raw request/response captures.

---

## The Excel workbook

Five sheets. Headers are case-sensitive. Add columns wherever it helps you;
unrecognised columns are simply ignored.

### Sheet 1: Environments

Define one row per named endpoint. Same protocol can have multiple envs (DEV, UAT, PROD).

| Column | Purpose |
|---|---|
| `EnvName` | Short identifier used by SourceA / SourceB. |
| `Protocol` | `rest`, `soap`, `apigee`, `fabric`, `gcp`. |
| `BaseURL` | Full origin (no trailing slash). |
| `AuthType` | `none`, `basic`, `bearer`, `apikey`, `oauth2`, `service_account`. |
| `AuthValue` | Token / key / credentials. Supports `${env.VAR}` or `${file./path/config.properties:key}`. |
| `ExtraHeaders` | Newline or semicolon-separated `Header: value` pairs. Overridden by step-level ExtraHeaders. |
| `SslConfig` | SSL/TLS settings (see [SSL Guide](docs/SSL_GUIDE.md)). Passwords support `${env.}` and `${file.}`. |

> **Secrets never go in Excel.** Use `${env.MY_TOKEN}`, `${file./config/secrets.properties:token}`,
> or a combination. Source A and B are separate Environment rows — they can have completely
> different headers, auth, and certificates.

### Sheet 2: TestSuite

One row per test case.

| Column | Purpose |
|---|---|
| `TestID` | Unique identifier (e.g. `T001`). |
| `TestName` | Short readable title. |
| `Description` | Free-form notes shown in the report. |
| `ComparisonMode` | One of `vs_expected`, `vs_env`, `vs_protocol`, `assert_only`, `chain`. |
| `SourceA` | Primary environment to run against. |
| `SourceB` | Secondary environment (for `vs_env` / `vs_protocol` only). |
| `ExpectedFile` | Path to baseline file (for `vs_expected` only). |
| `Enabled` | `Y` to include, anything else to skip. |

### Sheet 3: Steps

One row per HTTP request. Multiple rows per `TestID` build a chain (StepOrder = 1, 2, 3…).

| Column | Purpose |
|---|---|
| `TestID` | Links the step back to a TestSuite row. |
| `StepOrder` | Numeric order of execution. |
| `StepName` | Shown in the report. |
| `Method` | `GET`, `POST`, `PUT`, `DELETE`, `PATCH`. For `vs_protocol`, a pipe gives Source A and Source B different methods: `GET\|POST`. |
| `Endpoint` | Path appended to `BaseURL`, with placeholders. For `vs_protocol`, a pipe gives each source its own path: `/rest/accounts\|/ServiceRouter`. |
| `BodyTemplate` | Relative path to a template in `/templates`, blank for none. For `vs_protocol`, a pipe gives each source its own template: `\|soap_request.xml` (A sends no body, B sends the SOAP template). |
| `ExtractVars` | Comma-separated `name=jsonpath_or_xpath` to save values for the next step. |
| `ExpectedStatus` | Comma-separated HTTP codes that count as success (default: `200,201,204`). |
| `ExtraHeaders` | Per-step headers (override environment headers). Supports semicolon or newline-delimited format. |

#### Cross-protocol steps (Source A vs Source B differ)

In `vs_protocol` mode, Source A and Source B are often different kinds of
service — for example a REST GET on one side and a SOAP POST on the other.
The `Method`, `Endpoint` and `BodyTemplate` cells each accept a pipe-separated
`SourceA | SourceB` value so one logical step can drive both:

| Column | Value | Meaning |
|---|---|---|
| `Method` | `GET\|POST` | A uses GET, B uses POST |
| `Endpoint` | `/rest/v1/accounts?id=${id}\|/ServiceRouter` | A hits the REST path, B hits the SOAP router |
| `BodyTemplate` | `\|soap_get_accounts.xml` | A sends no body, B renders the SOAP template |

Rules:
- No pipe → the single value is used for **both** sources.
- A leading pipe (`\|soap_req.xml`) means Source A is empty and Source B has
  the value — the typical shape for "REST GET vs SOAP POST".
- The report shows each source's own method, endpoint and request body, so
  a REST GET with no body correctly shows `(empty)` while the SOAP side shows
  its rendered XML.

For a SOAP service that returns an HTML/WSDL landing page instead of a SOAP
response, the request wasn't recognised as a SOAP call — check that Source B's
method is `POST`, its `BodyTemplate` is the SOAP envelope, and (if the service
requires it) a `SOAPAction` header is set in `ExtraHeaders`.

#### Where template and baseline files may live

`BodyTemplate` and `ExpectedFile` are resolved against the templates and
expected directories, falling back to the project root. A relative path must
stay inside the directory it resolves against — workbooks get passed between
teams, and one that quietly reads a file from elsewhere on the machine and
prints it into the report is not something the tool allows. A path such as
`../../somewhere/else.xml` is refused with a "not found" error listing the
directories that were searched.

Absolute paths are still honoured, so templates and baselines kept on a shared
drive work as before.

#### Dynamic token authentication

For services requiring fresh tokens (OAuth, custom auth endpoints), use a
two-step flow:

**Step 1: Fetch token**
- `Method`: `POST`
- `Endpoint`: `/oauth/token` or `/auth/login`
- `BodyTemplate`: `auth_request.xml` (with username/password from TestData)
- `ExtractVars`: `token=//access_token` (extract token from response)

**Step 2: Use token**
- `Method`: `POST`
- `Endpoint`: `/api/yourService`
- `BodyTemplate`: `service_request.xml`
- `ExtraHeaders`: `Authorization: Bearer ${step1.token}`

The placeholder `${step1.token}` references the token extracted in step 1.
Both environment-level and step-level headers support placeholders and are
rendered just before dispatch, so tokens stay fresh.

### Sheet 4: TestData

Variables per test. Each column header is a placeholder name.

| TestID | customer_id | product_id | quantity | unit_price | … |
|---|---|---|---|---|---|
| T002 | CUST-1001 | PROD-501 | 5 | 49.99 | … |

In templates and endpoints, reference these as `${customer_id}`, `${product_id}`, etc.

### Sheet 5: Assertions

Field-level checks **and** ignore directives for noisy fields.

| Column | Purpose |
|---|---|
| `TestID` | Specific test, or `*` to apply to every test. |
| `Path` | JSONPath (`$.order.id`) or XPath (`//Status`). |
| `PathType` | `jsonpath` or `xpath`. |
| `Operator` | See operators below. |
| `ExpectedValue` | The value to compare against (where applicable). |
| `Description` | Shown in the report. |

---

## The five comparison modes

| Mode | What runs | What gets compared |
|---|---|---|
| `vs_expected` | Source A only | Last response vs `ExpectedFile` |
| `vs_env` | Source A + Source B | Response A vs Response B |
| `vs_protocol` | Source A + Source B | Normalized A vs normalized B (XML↔JSON OK) |
| `assert_only` | Source A only | Field assertions only — no file comparison |
| `chain` | Source A only | No comparison — chain succeeds if every step's HTTP status matches expected |

**Field assertions** can be added to **any** mode except `chain`. They run on the
final Source A response and are evaluated alongside the structural comparison.
The test only passes when both pass.

---

## Comparing across formats

`vs_protocol` handles the case where two platforms return the same business data
in genuinely different shapes — JSON from one, SOAP/XML from the other. A plain
tree diff would report all of that as differences, so both sides are normalised
first and only real differences survive.

### Bridged automatically

These never show up as differences:

| Difference | Example |
|---|---|
| Key casing and separators | `MasterPartner` ↔ `masterPartner` ↔ `master_partner` |
| XML attributes vs JSON fields | `usResident="false"` ↔ `"usResident": false` |
| Single element vs one-element array | one `<PhoneNumber>` ↔ `"phoneNumber": [ { … } ]` |
| List ordering | accounts returned in a different order on each side |
| Number formats | `12345.00000` ↔ `1.2345E4`, `0.15` ↔ `0.15000` |
| Booleans | `"true"` ↔ `true` |
| Dates | `20170825` ↔ `2017-08-25` |
| Unicode form | umlauts normalised before comparing |
| Transport wrappers | SOAP envelope, `Header`, and the routing `Version`/`Sender`/`Receiver` block |

Numbers are compared by value rather than by text, so scale differences don't
matter. Dates are validated on month and day, so an ordinary 8-digit number is
not mistaken for one.

### Still reported

| Difference | Shown as |
|---|---|
| Different scalar values | `value` |
| Field present on only one side | `added` / `removed` |
| Missing or surplus records | `added` / `removed` |

Fields that legitimately exist on only one platform surface as `added` or
`removed` by design, so nothing is hidden. When you expect them, silence them
per test with an `ignore` assertion rather than having the tool guess.

### Two payload shapes

The comparison picks its strategy from the payload:

- **A list of records** — a collection of accounts, line items, and so on — is
  flattened and matched by business key (`id` and friends) rather than by
  position, so reordering never creates false differences.
- **A single document** — one deeply nested entity — gets a recursive
  structural walk instead. Reducing such a payload to its largest inner list
  would silently discard the rest of the tree, so it isn't done.

### When names genuinely differ

Automatic normalisation bridges casing, nesting and representation. It does not
invent a mapping between two genuinely different field *names* (`cashAccount.name`
against `SalesProduct/Name`, say). Those align when the records already match on
their business key and the values agree; where they don't, add an `ignore`
assertion or compare that field with a targeted assertion instead.

---

## Assertion operators

| Operator | Behaviour | Example ExpectedValue |
|---|---|---|
| `equals` | Strict string equality after path extraction. | `created` |
| `not_equals` | Negation of the above. | `cancelled` |
| `contains` | Substring match. | `ERROR` |
| `not_contains` | Substring must not appear. | `FAILED` |
| `exists` | Path resolves to a non-empty value. | *(blank)* |
| `not_exists` | Path is missing or resolves empty. | *(blank)* |
| `not_null` | Path resolves and the value is not null. | *(blank)* |
| `greater_than` | Numeric: actual > expected. | `0` |
| `less_than` | Numeric: actual < expected. | `100` |
| `regex_match` | Java regex search on the extracted value. | `^(EMEA\|AMER\|APAC)$` |
| `one_of` | Value matches any entry in a comma-separated list. | `UPDATED,ACCEPTED` |
| `has_children` | The element at the path has child elements. | *(blank)* |
| `count_equals` | Number of matches equals the expected count. | `3` |
| `ignore` | **Skip this field during structural comparison.** Doesn't fail; quiets diff noise. | *(blank)* |
| `db_equals` | Run a read-only SELECT and compare the first column. | `CREATED` |
| `db_contains` | Same, but substring match. | `PEND` |
| `db_exists` | The query returns at least one row. | *(blank)* |

### When a path matches several elements

If a path resolves to more than one element — several `<Item>` siblings under
one parent, say — the assertion passes when **any** of them satisfies it. This
matters for responses where the value you care about sits in the third repeated
block rather than the first. When nothing matches, the failure message lists
every value that was checked, so you can see what the response actually held.

### Database assertions

`db_*` operators put the SQL query in the `Path` column and set `PathType` to
`sql`. They are deliberately restricted: only `SELECT` and `WITH` statements
run, stacked statements are rejected, the connection is opened read-only, and
queries time out after 30 seconds. Placeholders are **not** substituted into
SQL, so `${step1.orderId}` in a query stays literal.

---

## Placeholder cheat sheet

Available in BodyTemplate files and the Endpoint column.

| Placeholder | Resolves to | When blank/missing |
|---|---|---|
| `${col}` or `${col}` | TestData cell value | **Tag (or attribute) is removed entirely.** Parents cascade-clean. |
| `${!col}` or `${!col}` | TestData cell value | **Test fails immediately** with a clear error. |
| `${stepN.field}` | Variable extracted from step N's response | Same as above |
| `${env.VAR}` | OS environment variable | Same as above |
| `${now}` | Current UTC ISO-8601 timestamp | — |
| `${uuid}` | Random UUID v4 | — |
| `${name + N}` / `${name - N}` | The value of `name`, plus or minus a whole number | Same rules as `name` on its own |

Both `${name}` and `${name}` are accepted as placeholder syntax — they're
exact aliases. Use whichever you prefer; mixing in the same template is
fine.

### Incrementing an extracted value

When you pull a number out of one response and need to send the next value on
the following request, add a whole-number offset to the placeholder:

```
Step 1  ExtractVars:  seq=$.data.sequenceNumber
Step 2  Endpoint:     /api/orders/${step1.seq + 1}/submit
```

If step 1 returns `234234233`, step 2 is called with `234234234`. It works on
any numeric placeholder — a step variable, a TestData column or an environment
variable — and combines with the `!` mandatory prefix, e.g. `${!step1.seq + 1}`.

The rules are deliberately narrow:

- **Whole numbers only**, `+` or `-`. This is for sequence numbers and ids, not
  general expressions.
- **Spaces around the operator are required** (`${seq + 1}`, not `${seq+1}`).
  That is what lets an ordinary column named `order-2024` stay a plain name
  rather than being read as subtraction.
- **The value must be a whole number.** Applying an offset to something like
  `ORD-42` fails the test with a clear message rather than guessing.
- Large values are handled exactly (arbitrary precision), so a 9- or 18-digit
  id increments without rounding.

### How blank values are handled

For XML templates (auto-detected — output starts with `<`), the framework
parses the rendered output and walks it recursively:

1. **Empty element value** → the element is removed
2. **Empty attribute value** → the attribute is removed (element stays)
3. **Parent left with no children, no attributes, no text** → parent is
   removed too (cascading; repeats up the tree)
4. **Root element** → always preserved (even when empty)
5. **Repeating siblings** → each evaluated independently; blank ones drop,
   filled ones stay

For JSON, plain-text, or form bodies, blank placeholders are replaced
with empty strings — no structural pruning is performed.

### Worked example

**Template:**
```xml
<Order>
  <Customer>
    <FirstName>${first}</FirstName>
    <MiddleName>${middle}</MiddleName>
    <LastName>${last}</LastName>
    <Address>
      <Street>${street}</Street>
      <City>${city}</City>
    </Address>
  </Customer>
  <Notes>${notes}</Notes>
</Order>
```

**TestData row:** `first=Alice`, `city=Berlin` (everything else blank)

**Rendered:**
```xml
<Order>
  <Customer>
    <FirstName>Alice</FirstName>
    <Address>
      <City>Berlin</City>
    </Address>
  </Customer>
</Order>
```

`MiddleName`, `LastName`, `Street`, `Notes` removed. `Address` kept (has
City). `Customer` kept (has FirstName + Address). Root preserved.

### Mandatory fields

Prefix the placeholder name with `!` to make it required — the test fails
fast with a clear error if the column is blank or missing:

```xml
<Order>
  <Id>${!order_id}</Id>    <!-- test fails if order_id is blank -->
</Order>
```

### Repeating children

Each repeated element is evaluated independently. Only ones whose data is
missing are pruned; the rest stay:

```xml
<Products>
  <Product><Id>${productId_1}</Id></Product>
  <Product><Id>${productId_2}</Id></Product>
  <Product><Id>${productId_3}</Id></Product>
</Products>
```

If `productId_2` is blank but `productId_1` and `productId_3` are filled,
the output has 2 `<Product>` elements. If all three are blank, the
`<Products>` container is removed too (cascading).

### Render log

The framework tracks every removed tag, attribute, and missing placeholder.
You can access this programmatically via the overload that accepts a
`RenderLog` argument — useful for diagnostics and CI logs.

---

## Walkthrough: adding a new test

A common workflow — no code changes, only Excel edits.

**Goal:** add a test that creates a customer via REST, then verifies the
returned `customer.id` is a UUID and `customer.status` is `pending`.

1. **TestSuite sheet** — add a row:
   ```
   T010 | Create customer | Verify response shape | assert_only | DEV_REST | | | Y
   ```

2. **Steps sheet** — add a row:
   ```
   T010 | 1 | Create customer | POST | /customers | templates/create_customer.json | | 201
   ```

3. **TestData sheet** — add a row with the input data:
   ```
   T010 | (customer_id blank) | | | | | | | | first_name=Alice last_name=Diaz
   ```

4. **Assertions sheet** — add the field checks:
   ```
   T010 | $.customer.id     | jsonpath | regex_match | ^[0-9a-f-]{36}$ | UUID format
   T010 | $.customer.status | jsonpath | equals      | pending         | New customer state
   T010 | $.customer.email  | jsonpath | exists      |                 | Email must echo
   ```

5. **templates/create_customer.json** — create the template:
   ```json
   { "first_name": "${first_name}", "last_name": "${last_name}", "requestId": "${uuid}" }
   ```

6. Run `java -jar target/api-test-suite.jar` and open `reports/report.html`.

That's it. Adding tests is data entry.

---

## Secrets and CI

```bash
export DEV_TOKEN="eyJhbGc..."          # referenced as ${env.DEV_TOKEN} in Excel
export FABRIC_CLIENT_SECRET="..."
export TRUST_PASS="changeit"           # for keystore passwords if using SslConfig

mvn -q package
java -jar target/api-test-suite.jar    # exit 0 → all pass, exit 1 → at least one fail
```

## SSL / TLS

For services with private CAs, self-signed certs, or mTLS, configure the
`SslConfig` column on the `Environments` sheet. Examples:

```
trust_store=certs/ca.jks; trust_password=${env.TRUST_PASS}
key_store=certs/client.p12; key_password=${env.CLIENT_PASS}; key_type=PKCS12
verify=false                              (DEV ONLY)
```

See [docs/SSL_GUIDE.md](docs/SSL_GUIDE.md) for full instructions including
`.pem` → `.jks` conversion, mTLS setup, and troubleshooting.

## Writing assertions for repeated XML elements

When your response has many elements with the same name (multiple employees,
line items, projects), a plain `//City` returns just the *first* match. To
target a specific one, use XPath predicates: `//Employee[EmployeeId='1002']/Address/City`.

See [docs/XPATH_GUIDE.md](docs/XPATH_GUIDE.md) for the four common patterns
and a complete cheat sheet.

## Testing an XPath against a saved response

After a run, every response is saved to `output/<timestamp>/<TestID>/sourceA/step*/response.txt`.
To verify an XPath against a real captured response without running the full
suite:

```bash
java -cp target/api-test-suite.jar com.apitest.XPathTester \
    output/20260513_120000/T001/sourceA/step1_get/response.txt \
    "//LineItem[Product/Id='AAA123']/Price" \
    "//Version"
```

This uses the exact same parser as the test runner, so what works here
works in your assertions. Pass multiple XPaths to test several at once.

## Sharing structure for help without leaking response content

If your response contains proprietary data and you need help with an XPath,
the `ResponseSkeleton` tool extracts just the element names and nesting,
redacting every value:

```bash
java -cp target/api-test-suite.jar com.apitest.ResponseSkeleton \
    output/20260513_120000/T001/sourceA/step1_get/response.txt
```

Output shows the element tree with all text/attribute values replaced by
placeholders, plus a list of unique element names and which ones repeat
(those are the candidates for `//Parent[Child='X']`-style predicates).
Safe to paste anywhere for debugging.

**Do not use online XPath testers to verify paths against this framework's
responses.** Many of them default to HTML5 mode and will flag valid XML as
invalid (because HTML doesn't allow capitalized tags or colons in names).
Use the built-in `XPathTester` tool, `xmlstarlet`, or Python `lxml` instead.

GitHub Actions example:
```yaml
- uses: actions/setup-java@v4
  with: { distribution: 'temurin', java-version: '21' }
- run: mvn -q package
- run: java -jar target/api-test-suite.jar
  env:
    DEV_TOKEN: ${{ secrets.DEV_TOKEN }}
- uses: actions/upload-artifact@v4
  if: always()
  with: { name: api-test-report, path: reports/report.html }
```

---

## Wiring real auth providers

The `Dispatcher.getOauth2Token()` and `Dispatcher.getGcpToken()` methods are
stubs that read `OAUTH2_TOKEN` / `GCP_TOKEN` from the environment. In
production, replace them with real flows:

- **OAuth2 / Microsoft Fabric** — use MSAL4J (`com.microsoft.azure.msal4j`)
  client-credentials flow. Drop the dependency into `pom.xml`, swap the stub.
- **GCP** — use `com.google.auth:google-auth-library-oauth2-http`, load the
  service account JSON from the path in `AuthValue`, request a token.

---

## Command-line options

```
java -jar target/api-test-suite.jar [options]

Path options (all support absolute or relative paths):
  --suite <path>           Excel suite file
                           default: <project-root>/config/test_suite.xlsx
  --report <path>          HTML report output file
                           default: <project-root>/reports/report.html
  --project-root <path>    Base directory used for resolving the four
                           defaults below; default: current working dir
  --templates-dir <path>   Where BodyTemplate paths in Excel resolve
                           default: <project-root>/templates
  --expected-dir <path>    Where ExpectedFile paths in Excel resolve
                           default: <project-root>/expected
  --output-dir <path>      Per-run artifact storage (request/response/log)
                           default: <project-root>/output

Other options:
  --name <name>            Suite name shown in the report header
  --version, -v            Print version and exit
  --help, -h               Show this help message
```

Excel `BodyTemplate` and `ExpectedFile` entries that are absolute paths
are honoured as-is. Relative entries resolve against `--templates-dir` and
`--expected-dir` respectively.

---

## The HTML report

After each run you get a single self-contained HTML file with:

- A donut chart summary, KPIs, and mode breakdown.
- A searchable, filterable sidebar of every test.
- Per-test tabs:
  - **Overview** — at-a-glance metadata.
  - **Steps** — each request/response with syntax-highlighted code blocks and copy buttons.
  - **Comparison** — shows the prepared payloads (after CDATA unwrap and
    pretty-print) side-by-side, followed by the diff in either side-by-side
    or table form. The prepared view lets you see exactly what the
    comparator saw, which is essential for SOAP responses where the
    meaningful XML is buried under several wrapping layers.
  - **Assertions** — per-field pass/fail table.
- Keyboard shortcuts: `/` to focus search, `Esc` to clear.
- A print stylesheet for PDF export.

No external dependencies — open it from anywhere.

---

## Troubleshooting

**"Required sheet missing: TestSuite"**
The workbook was edited and a required sheet was renamed or removed. Required
sheets are Environments, TestSuite, and Steps.

**`PathType` left blank**
Treated as missing. Set it to `jsonpath` or `xpath` explicitly.

**Numbers showing as `49.99000000001`**
Format the TestData column as Text in Excel before typing, or wrap critical
strings in single quotes (Excel strips them on save).

**Diff shows differences I expected to ignore**
Check the Assertions sheet — `PathType` must match the response format
(`jsonpath` for JSON responses, `xpath` for XML/SOAP).

**Bearer/OAuth token is empty**
The `${env.VAR}` referenced wasn't exported in the shell that ran the JAR.
Print it with `echo $VAR` before invoking Java.

---

## Building from source

```bash
mvn clean package        # builds the fat-jar at target/api-test-suite.jar
mvn test                 # runs all JUnit tests
```

### Quick demo (no network calls)

To see the report format without configuring any real environments:

```bash
mvn package
java -cp target/api-test-suite.jar com.apitest.Demo
open reports/demo_report.html
```

This runs 6 simulated test cases covering every comparison mode, generates a
real HTML report, and exits — useful for a first look or for showing
stakeholders what the output looks like.

Java 21 features used: records, switch expressions, pattern matching, text blocks.
Earlier JDKs will fail to compile.
