# Changelog

## 2.12.0

### Added

- **Whole-number offsets on placeholders.** A placeholder may end with `+ N`
  or `- N`, e.g. `${step1.orderId + 1}`, so a number extracted from one
  response can be sent incremented on the next request without a separate step
  to compute it. Works on step variables, TestData columns and environment
  variables, and combines with the `!` mandatory prefix. Values are handled at
  arbitrary precision, so large ids increment exactly.

  The syntax is deliberately narrow: whole numbers only, `+`/`-` only, and
  whitespace around the operator is required — which is what keeps a column
  named `order-2024` from being read as subtraction. Applying an offset to a
  non-numeric value fails the test with a clear message.

### Scope

- The change is confined to the template engine; no other module is affected.
  Placeholders without an offset behave exactly as before.

### Tests

- `TemplateEnginePlaceholderOffsetTest`: the large-number case, add/subtract,
  each value source, the mandatory-prefix combination, non-numeric failure, and
  confirmation that hyphenated names and space-free tokens are left alone.

## 2.11.1

### Security

- **Path containment for workbook-supplied file paths.** `BodyTemplate` and
  `ExpectedFile` resolve relative paths strictly inside their configured
  directory. Previously a value such as `../../etc/passwd` would be read and,
  for an expected file, rendered into the HTML report. Workbooks get shared
  between teams, so a path escaping the project is not something to allow.
  Absolute paths still work for templates and baselines kept on a shared drive.
- **Disabling TLS verification is no longer silent.** `verify=false` turns off
  both certificate and hostname checking; it now prints a warning naming that
  when the SSL context is built. Contexts are cached, so the warning appears
  once per environment rather than on every request.

### Documentation

- Added a cross-format comparison section to the README covering what is
  bridged automatically (key casing, attributes vs fields, single element vs
  one-element array, list ordering, number formats, booleans, dates, Unicode,
  transport wrappers), what is still reported, the two payload shapes, and the
  limit on genuinely different field names. Every claim in that table is
  covered by a test.
- Documented the full operator set. Both the README and the Excel guide listed
  9 of the 17 that exist; `not_contains`, `not_null`, `one_of`, `has_children`,
  `count_equals` and the three `db_*` operators were missing.
- Documented that an assertion passes when any matching sibling satisfies it,
  and the read-only restrictions on database assertions.
- Documented where template and baseline files may live, and why a relative
  path cannot leave its directory.
- Documented the `verify=false` warning in the SSL guide.
- Brought the architecture tree back in line with the source: added
  `CrossFormatCanonicalizer`, `SimpleXmlWalker` and `SslConfig`.

### Housekeeping

- Removed three unused imports.
- Reworded a few comments that restated the code rather than explaining it.

### Tests

- `TemplatePathContainmentTest`: templates inside the directory resolve,
  nested paths resolve, traversal outside the project is rejected, absolute
  paths still work, and a missing template still names the file it looked for.

## 2.11.0

### Cross-format comparison: shape-aware strategy

Cross-format comparison now detects the payload shape and picks a strategy,
fixing two failures that broke deeply nested single-entity documents.

**Fix 1 — a single document is no longer reduced to its largest inner list.**
The comparison used to collapse every payload onto "the single largest list of
objects". That is correct for a list of records (e.g. a list of accounts), but
destructive for one rich document: if the largest object-list happened to be a
handful of trivial flag entries, those matched and the entire surrounding
entity tree was silently discarded — reporting a false match while a genuine
scalar difference went unseen. Payload shape is now detected:

- **Collection payload** (a repeated list of business records) → unchanged
  flatten-and-match-by-business-key path.
- **Single document** → a new recursive structural diff that walks both trees
  and reports only real differences.

**Fix 2 — routing envelopes are peeled.** A response may wrap the business
document a second time, with transport siblings beside the content:
`Version`, `Sender`, `Receiver` next to `Content`. The wrapper peeler only
descended through single-key maps, so it stopped at that four-entry node and
left the payload buried. It is now metadata-aware: transport siblings are
ignored when deciding whether a node is a wrapper, so the peeler descends into
the content and drops the routing block.

### Bridged automatically (not reported as differences)

Key casing and separators; XML attributes vs JSON fields; a single element vs a
one-element array; reordered lists (matched by business key, then by content);
number formats (fixed-decimal vs scientific, scale-insensitive); `"true"`/
`"false"` vs booleans; ISO dates (`yyyy-MM-dd`) vs compact (`yyyyMMdd`);
Unicode normalization; SOAP `Header` blocks and the routing envelope.

Date detection validates month and day, so ordinary 8-digit numbers and
hyphenated codes are not mistaken for dates.

### Still reported (genuine differences)

Different scalar values; fields present on only one side (`added`/`removed`);
missing or surplus list elements. Fields that legitimately exist on only one
platform surface by design so nothing is hidden — suppress them per test with
`ignore` assertions when they are expected.

### Tests

- New `CrossFormatDocumentTest`: 9 tests covering identical rich documents
  across formats, a scalar difference buried deep in the tree (the false-match
  regression), routing-envelope peeling, reordered nested lists, single element
  vs one-element array, one-sided fields, and date normalization including the
  non-date case.
- No regressions: the existing collection-path suites are untouched.

## 2.10.3

### Per-source method, endpoint and template for cross-protocol tests

`vs_protocol` steps can now differ between Source A and Source B in all three
of Method, Endpoint and BodyTemplate — not just Endpoint. Each cell accepts a
pipe-separated `SourceA | SourceB` value:

| Column | Example | Result |
|---|---|---|
| `Method` | `GET\|POST` | A = GET, B = POST |
| `Endpoint` | `/rest/accounts\|/ServiceRouter` | A hits REST, B hits the SOAP router |
| `BodyTemplate` | `\|soap_req.xml` | A sends no body, B sends the SOAP template |

This fixes the case where a REST GET is compared against a SOAP POST: before,
method and template were shared, so the SOAP side was sent with the wrong
method/body (often producing an HTML/WSDL landing page instead of a SOAP
response). Now each side is configured independently.

- No pipe → the value is shared by both sources (unchanged behaviour).
- The HTML report shows each source's own method, endpoint and request body,
  so a REST GET correctly shows `(empty)` while the SOAP side shows its XML.

### Tests

- New `PerSourceStepTest`: 12 tests covering per-source method/endpoint/
  template resolution and the loader's pipe-splitting (including leading-pipe,
  no-pipe, whitespace and null cases).

## 2.10.2

### Request body / method fixes

- **Body is decided by the template, not the method.** Previously a body was
  only sent for POST/PUT/PATCH. That broke the cross-protocol case where
  source A is a REST GET with no template and source B is a SOAP service
  invoked over GET that still needs its XML body — source B was sent an empty
  body and the gateway faulted ("Unexpected EOF in prolog [1,0]"). Now a body
  is rendered and sent whenever a BodyTemplate is configured for the step,
  regardless of method; a GET with no template sends nothing.
- **SOAP over GET keeps GET on the wire.** A body-capable request variant is
  used so the XML body is transmitted while the request line still reads GET
  (a plain GET would silently drop the body). SOAP with no explicit method
  still defaults to POST, as before.
- **Report display.** Source A (GET, no template) shows "Request body:
  (empty)"; source B (SOAP with template) shows its XML body — matching what
  is actually sent.

### Tests

- New `SoapOverGetTest`: raw-socket verification that SOAP-over-GET keeps GET
  and delivers the body, SOAP with no method defaults to POST, GET with no
  body sends nothing, and POST sends its body.
- Removed the obsolete method-based body test (logic is now template-based).

## 2.10.1

### Cross-format comparison fixes

- **SOAP Header block beside the data.** When a SOAP response carries a
  `Header` block (EntityId, Application, Version, User) as a sibling of the
  repeated business elements, the comparison now locates the entity list
  correctly among the sibling metadata and excludes the Header. Previously
  the Header polluted the first record and produced a cascade of false
  differences.
- **Envelope/transport metadata** (SOAP envelope, Header, Status, Sender,
  Receiver) that sits outside the repeated entity list is naturally excluded
  from the data comparison. Business fields named "status" or "version" that
  live inside a record are preserved and still compared.
- **Optional fields on some records.** A field present on only some records
  (e.g. `interestRate` on a subset of accounts) no longer reports the records
  that lack it as differences, while a genuine value difference is still
  caught.

### Report fix

- **No request body for GET/HEAD/DELETE.** The HTML report no longer shows a
  request body under a GET step. A body is only rendered and sent for methods
  that carry one (POST/PUT/PATCH); a BodyTemplate value on a GET row is
  ignored, as it should be.

### Tests

- 5 new cross-format regression tests (Header exclusion, differing header
  values ignored, optional interestRate present/absent/different, many
  reordered accounts with a header).
- 4 new tests for the method/body rule.

## 2.10.0

### Cross-format comparison (JSON vs XML/SOAP)

The biggest limitation of cross-format comparison is fixed: previously two
systems returning the same data in different shapes (JSON from one, SOAP/XML
from another) reported almost everything as a difference, because the trees
didn't line up. The comparison now **canonicalizes both sides before diffing**:

- **Wrapper stripping** — SOAP `Envelope`/`Body`, `executeResponse`, `return`,
  and `*Response`/`*OverviewResponse` wrappers are peeled so only the business
  payload is compared.
- **Key folding** — key casing and separators are normalized, so `Amount`/
  `amount`, `currentBalance`/`current_balance` align. camelCase vs PascalCase
  no longer matters.
- **Attribute folding** — an XML attribute (`hasBlocks="true"`) matches the
  equivalent JSON field (`"hasBlocks":true`).
- **Number normalization** — numbers are compared by value via `BigDecimal`
  (scale-insensitive), so scientific notation (`1.2345E4`) equals fixed-decimal
  (`12345.00000`), and `0.15` equals `0.15000`.
- **Boolean & Unicode normalization** — `"true"` string equals `true` boolean;
  strings are trimmed and Unicode-NFC normalized (umlauts).
- **Business-key record matching** — repeated records (accounts, line items)
  are flattened and matched by their identifier, not by position, so a
  different ordering between the two systems is not a difference.
- **Representation-only redundancy** — a value carried twice in one format but
  once in the other (e.g. currency at both account and balance level in JSON,
  once in XML) is not reported as a difference.

Genuine differences are still caught precisely: a changed amount or name, a
missing record, an extra record, or one wrong record among many are all
reported and identified by business key.

Same-format comparisons (XML vs XML, JSON vs JSON) are completely unchanged.

### Internal

- New `CrossFormatCanonicalizer` — canonicalizes a parsed tree and reduces it
  to flat, business-keyed records.
- New `diffRecords` / `diffRecordPair` in `Comparator` — record-set diff with
  business-key matching, best-overlap fallback, and redundancy suppression.
- 12 new regression tests covering identical-data matching, number formats,
  attributes, Unicode, reordering, and every genuine-difference case.

## 2.9.0

### Assertions

- **Multi-sibling assertion evaluation.** When a path like `//Item/Amount`
  matches multiple sibling elements, the assertion engine now checks every
  match — not just the first. If any of them satisfies the operator (equals,
  contains, one_of, greater_than, regex_match, etc.) the assertion passes.
  Previously this was a false failure when the expected value happened to be
  in a later sibling.

- When no match satisfies the assertion, the error message now shows all
  values that were checked (e.g. `100 | 200 | 300 (checked 3 matches)`) so
  the user can immediately see what the response actually contained.

### Internal

- Added `Comparator.extractAllVariables(payload, path)` — returns every
  matching value instead of just the first.
- Added `SimpleXmlWalker.findAll(xml, xpath)` — collects all matches from
  the parser-free XML walker.
- 14 new regression tests covering the multi-sibling scenario across XML,
  JSON, and every applicable operator.

## 2.8.0

### Comparison

- **Order-insensitive list comparison.** When a response contains repeated
  child elements (line items, accounts, etc.) or a JSON array, the two sides
  are now matched by content rather than strictly by position. A list that one
  system returns in a different order from another no longer floods the report
  with false differences. Genuine value changes, and any extra or missing
  element, are still reported exactly as before.

### Packaging

- **Removed the in-code workbook generator.** The starter workbook is now
  shipped directly as `config/test_suite.xlsx` instead of being generated at
  runtime, removing unnecessary code from the build.

### Documentation

- Added a Javadoc comment to every method describing what it does.

### Verification

- Re-ran the full security pass: no external references, XXE protection on all
  XML parsers, read-only SELECT-only database assertions, zero compiler
  warnings. 170 tests pass.

## 2.7.1 — 2026-05-31

### Robustness

- `Comparator.extractVariable`, `countMatches`, and `hasChildren` now
  return a safe empty/zero/false result for null or empty payload/path
  inputs rather than propagating a parser exception.
- Verified the comparison engine never throws on adversarial inputs
  (null, malformed XML, garbage, 100k-char payloads, 300-level nesting,
  unicode, CDATA) via an expanded stress suite.

### Security

- Database assertions are now strictly read-only:
  - Only `SELECT` / `WITH` statements are permitted; write/DDL verbs
    (DELETE, UPDATE, INSERT, DROP, TRUNCATE, ALTER) are rejected before
    execution.
  - Stacked statements (a `;` followed by more SQL) are blocked.
  - Connections are set read-only and queries are bounded by a 30s
    timeout so a runaway query can't hang the suite.
- Added `RobustnessTest` covering all of the above (8 cases).

### Cleanup

- Genericized every test fixture and documentation example to a neutral
  orders/products domain. No domain-specific identifiers remain anywhere
  in source, tests, README, or docs.
- Zero `javac -Xlint:all` warnings.
- Confirmed: no external network references (only sample/schema/XXE-flag
  URLs), no hardcoded credentials, XXE hardening on all XML parsers.

## 2.7.0 — 2026-05-19

### Features

- **Robust error handling.** TestResult and StepResult now carry an
  {@code errorDetail} field with the full exception chain and stack
  trace. The HTML report shows a collapsible "Show full diagnostics"
  panel for any failed test or step. Click to expand the exact root
  cause and stack — no more digging through console output.

- **Excel template upgraded** with full Calibri-10 styling:
  - Color-coded header row per sheet (deep blue, forest green, burnt
    orange, purple, dark red)
  - Alternating row stripes for readability
  - Data validation dropdowns on every fixed-set column:
    Protocol, AuthType, ComparisonMode, Enabled, Method, PathType, Operator
  - Excel Tables wrapping each sheet — gives auto-filter, banded rows,
    and auto-expand when you tab into a new row
  - Frozen header row on every data sheet

- **XML vs JSON cross-format comparison** verified with regression tests.
  The comparator normalizes both formats to a common structure so
  &lt;Order&gt;&lt;Id&gt;X100&lt;/Id&gt;&lt;/Order&gt; and
  {"Order":{"Id":"X100"}} are treated as equivalent. Real value or
  structural differences are still reported regardless of source format.

### Cleanup

- Zero references to external/user-provided content
- XXE hardening verified on all 7 XML parser entry points
- No hardcoded credentials
- No backup files, no dead code, zero javac warnings

## 2.6.0 — 2026-05-18

### Features

- **Dual endpoints for vs_protocol.** Pipe-separated values in the Endpoint
  column: `/fabric/datasets|/apigee/v1/datasets`. First part goes to
  Source A, second to Source B. No pipe = same endpoint for both.

- **Database validation assertions.** New operators:
  - `db_equals`   — run SQL query, compare first column/row to ExpectedValue
  - `db_contains` — run SQL query, check result contains ExpectedValue
  - `db_exists`   — run SQL query, check at least one row returned
  
  SQL query goes in the Path column. DB connection configured per
  environment via `DbURL`, `DbUser`, `DbPassword`, `DbDriver` columns.
  Passwords support `${env.}` and `${file.}`.

- **New assertion operators:**
  - `one_of`        — value is one of comma-separated options (e.g. `OK,SUCCESS,PASS`)
  - `not_null`      — alias for exists
  - `not_contains`  — actual does not contain expected
  - `has_children`  — XML node or JSON object/array at path has children
  - `count_equals`  — number of nodes matching path == expected number

### Cleanup

- Removed all traces of user-shared content references
- XXE hardening verified on all XML parser entry points
- No hardcoded credentials
- No dead code or commented-out blocks

## 2.5.0 — 2026-05-18

### Features

- **Automatic token fetch from the Environments sheet.** Two new columns:
  - `TokenURL` — the full URL of your OAuth / Glue token endpoint
  - `TokenBody` — the form-urlencoded body (supports `${env.}` and
    `${file.}` placeholders)

  When configured, the runner automatically POSTs to the token URL with
  `Content-Type: application/x-www-form-urlencoded` before any test step
  runs, extracts `access_token` from the JSON response, and injects
  `Authorization: Bearer <token>` into every request header. No template
  file, no extra step in the Steps sheet, no manual wiring.

  Example Environments row:
  ```
  EnvName:   DEV_REST
  TokenURL:  https://auth.example.com/oauth/token
  TokenBody: grant_type=client_credentials&client_id=${env.CLIENT_ID}&client_secret=${env.CLIENT_SECRET}
  ```

  The token fetch appears as "Step 0" in the HTML report so you can see
  the request/response and timing. If the token fetch fails, the test
  immediately fails with a clear error.

## 2.4.1 — 2026-05-17

### Bug fixes

- **Full URLs in the Endpoint column are now used as-is.** When a step's
  endpoint starts with `http://` or `https://` (e.g. a token service on a
  different host), the runner no longer prepends the environment's BaseURL.
  Previously, `https://auth.example.com/oauth/token` in the Endpoint column
  with BaseURL `https://dev-api.example.com` produced the broken URL
  `https://dev-api.example.com/https://auth.example.com/oauth/token`.

## 2.4.0 — 2026-05-17

### Features

- **Apigee protocol support.** Set `Protocol = apigee` in the Environments
  sheet. Defaults Content-Type to `application/json`. Works with the new
  `apikey` auth type for `x-api-key` header injection.

- **New `apikey` auth type.** Set `AuthType = apikey` and `AuthValue` to
  your API key (literal, `${env.VAR}`, or `${file.path:key}`). Injects
  the key as the `x-api-key` header.

- **Form-urlencoded body for OAuth token requests.** For token endpoints
  that require `Content-Type: application/x-www-form-urlencoded`, set
  the Content-Type in ExtraHeaders and write the body template as plain
  key=value pairs:
  ```
  grant_type=client_credentials&client_id=${client_id}&client_secret=${client_secret}
  ```
  No XML template needed — the framework sends the body exactly as
  written with the specified Content-Type.

- **Certificate passwords from config files.** SSL passwords now support
  `${file./path/to/ssl.properties:key_name}` in addition to `${env.VAR}`.
  The same syntax works for AuthValue. Create a `.properties` file:
  ```properties
  trust_password=changeit
  key_password=secret123
  apigee_key=my-api-key-here
  ```
  Then reference it in the Environments sheet:
  ```
  trust_password=${file./config/ssl.properties:trust_password}
  ```

### Notes on source A vs B headers

Source A and source B are separate Environment rows in the Excel, each
with their own `ExtraHeaders`, `AuthType`, `AuthValue`, and `SslConfig`.
They can be completely different — different headers, different auth,
different certificates. The runner processes each source independently.

## 2.3.1 — 2026-05-17


### Bug fixes

- **Template and expected-file path resolution fixed.** Paths in the Excel
  `BodyTemplate` and `ExpectedFile` columns now resolve via a fallback
  chain: first against the configured directory (`--templates-dir` /
  `--expected-dir`), then against `--project-root`. This fixes the
  double-directory bug where writing `templates/req.xml` in the Excel
  while `--templates-dir` was already set to `<project>/templates` caused
  the runner to look for `templates/templates/req.xml`.
  
  All three forms now work:
  - `req.xml` → resolved against `--templates-dir`
  - `templates/req.xml` → tries `--templates-dir` first, falls back to
    `--project-root`
  - Absolute paths → used as-is
  
  The error message now lists both attempted paths so you can see where
  it looked.

## 2.3.0 — 2026-05-17


### Features

- **Per-step ExtraHeaders** for dynamic authentication flows. Steps sheet
  now has an `ExtraHeaders` column. Headers specified here override the
  environment's default headers for that step. Both environment-level and
  step-level headers support placeholders like `${step1.token}`.
  
  **Use case:** OAuth / token-based auth where you need to fetch a fresh
  token before each test run:
  
  ```
  Step 1: POST /auth/token → extracts token to ${step1.access_token}
  Step 2: POST /api/service → ExtraHeaders: Authorization: Bearer ${step1.access_token}
  ```
  
  The token is fetched dynamically as the first step and reused in
  subsequent steps. Supports the same semicolon/newline formats as
  environment headers.

- **TemplateGenerator** updated to include the new `ExtraHeaders` column
  in the generated Steps sheet template.

## 2.2.1 — 2026-05-16


### Bug fixes

- **ExtraHeaders column now supports semicolon-delimited format.** REST
  services often need many headers; entering them on separate lines in an
  Excel cell was awkward. The parser now accepts both:
  - Newline-delimited (original): `Authorization: Bearer xyz\nX-Custom: val`
  - Semicolon-delimited (new): `Authorization: Bearer xyz; X-Custom: val`
  - Both formats can mix in the same cell. Header values can contain
    colons (only the first colon per header is the delimiter).

## 2.2.0 — 2026-05-16


### Features

- **Full path configuration via CLI.** Every directory the runner reads or
  writes is now overridable from the command line — `--templates-dir`,
  `--expected-dir`, `--output-dir`, `--project-root`, plus the existing
  `--suite` and `--report`. Means you can ship just the jar to a teammate
  and have them point the flags at their own files; no matching directory
  layout required at the runner's working directory.
- **`RunConfig` bundle** in `com.apitest.runner` carries all paths
  programmatically. New `Runner.runAll(RunConfig)` and
  `Runner.runTest(TestCase, TestSuite, RunConfig, Path)` overloads. The
  previous single-path entry points (`runAll(Path, Path)`, `runTest(TestCase,
  TestSuite, Path, Path)`) are kept for backward compatibility.
- **Helpful startup banner** prints the resolved paths so users can see
  exactly where the runner is reading from and writing to.

### Bug fixes

- **Comparison tab no longer truncates payloads at 5000 chars.** Large
  responses (typical SOAP business payloads) showed only the first
  5000 characters in the prepared-payloads side-by-side view. Truncation
  removed; the pane is scrollable via CSS so the page itself doesn't
  blow up, and a header shows the total character count for each side.

## 2.1.1 — 2026-05-16


### Bug fixes

- **Test status now correctly reports FAIL when source B fails in vs_env /
  vs_protocol mode.** Previously, when source A succeeded but source B
  hit a socket exception (or other dispatch error), the test was
  incorrectly reported as PASS in the HTML report. Root cause: the final
  status-resolve block at the end of `runTest` was overwriting the FAIL
  set earlier by the vs_env branch with a default PASS. Fixed by making
  the final block preserve any explicit FAIL or ERROR set previously.
- **Overview tab now indicates Source A and Source B status individually.**
  Each Source cell shows a small pill (`ok` or `failed`) so users can
  immediately see which side had a problem without drilling into the
  Steps tab.

### Tests

- Added `StatusOverrideRegressionTest` covering the four key paths:
  vs_env B-failure, vs_env all-ok, vs_env assertion-fail, ERROR-preserved.

## 2.1.0 — 2026-05-15


### Features

- **CDATA-aware comparison.** When the actual response wraps the business
  payload inside CDATA (a common SOAP pattern such as
  `<arg0><![CDATA[<RealPayload>...</RealPayload>]]></arg0>`), the
  comparator now unwraps it before structural diff so you can compare
  against a clean expected XML file. Also handles escaped XML
  (`&lt;...&gt;`) and SOAP-in-SOAP nested wrappers.
- **Smart comparison anchor.** When the expected file's top-level element
  exists somewhere inside the unwrapped actual response, comparison
  automatically anchors on that element. Lets users write expected files
  that contain only the business payload without having to mirror the
  full SOAP envelope structure.

### Improvements

- **Differences tab readability:**
  - `added` / `removed` rows now show `(missing)` on the absent side
    instead of repeating the value in both columns
  - Empty values render as `(empty)` instead of an indistinguishable blank
  - Long values truncate at 300 chars with a footer indicating how many
    more chars were elided
  - Table layout uses fixed widths for Kind/Path so the value columns get
    consistent space; word-break prevents overflow

### Security

- **XXE hardening across all XML parsers.** Every `DocumentBuilderFactory`
  now disables doctype declarations, external general/parameter entities,
  external DTD loading, XInclude, and entity expansion. Defense-in-depth
  against the small but real risk of a malicious response triggering an
  XXE-style attack on the test harness.

### Cleanup

- Removed unused `Demo.java` scaffolding.
- All snippets/identifiers from real-world test runs replaced with
  neutral example domain names. No proprietary references remain in the
  codebase.
- `serialVersionUID` added to `ExtractionException`.

## 2.0.2 — 2026-05-15

### Bug fixes

- **No more `xmlns=""` artifacts.** The namespace-aware DOM parser sometimes
  inserted redundant `xmlns=""` declarations on child elements during
  round-trip. A new cleanup pass walks the tree and removes empty default
  namespace declarations when the parent already had no default namespace.
- **No more line-wrapping inside element open tags.** The Transformer's
  pretty-print was wrapping long opening tags across multiple lines (e.g.
  `<arg0\n   xmlns="">`), which some strict server parsers reject. Indent
  is now disabled in the serializer; output is single-line clean XML.
- **No more visible blank lines inside the request.** After pruning, the
  original template's indentation whitespace was left as text nodes between
  elements, producing visible gaps in the output. A cleanup pass removes
  whitespace-only text nodes between structural elements.

## 2.0.1 — 2026-05-15

### Bug fixes

- **CDATA-wrapped inner XML now cleaned correctly.** When a template uses
  `<arg0><![CDATA[<inner>...${field}...</inner>]]></arg0>` to wrap a
  business payload, unresolved placeholders inside the CDATA now have their
  surrounding tags removed via string-level cleanup (the parser can't walk
  into CDATA as elements). Surviving filled tags are preserved; empty
  wrappers cascade away within the CDATA.
- **CDATA sections preserved through the output.** Previously the
  Transformer was converting CDATA back to escaped entities. Now the
  serializer explicitly lists CDATA-containing element names so they
  round-trip as `<![CDATA[...]]>`.
- **DROP marker no longer leaks to output** even when an element has
  attributes and the placeholder was its only content. The element is
  dropped per the spec, regardless of attributes.

## 2.0.0 — 2026-05-15

### Behavior changes (breaking)

- **Template engine rewritten using DOM-walk + cascade pruning.** Old
  regex-based heuristics replaced with a real XML parser. Handles namespaces,
  nested structures, attributes, repeating siblings correctly.
- **Placeholder syntax is `${name}` only.** The `&{name}` form is no longer
  recognized (was briefly experimental in pre-release builds).
- **Blank/missing placeholder values now drop the surrounding tag.** This
  matches the requirements spec. A leaf with `<Phone>${phone}</Phone>` and
  blank `phone` cell renders with no `<Phone>` element at all.
- **Parent cascade cleanup.** When all children of a parent are pruned and
  the parent has no other content (no real attrs, no text), the parent
  itself is removed. Cascades up.
- **Namespace declarations don't block cascade.** `xmlns` and `xmlns:*` are
  not counted as "real" attributes — so `<execute xmlns="..."/>` cascades
  away properly when its content was just a placeholder.
- **Root element is never auto-removed.** If pruning empties everything,
  the body is `<Root></Root>` rather than nothing — better diagnostics.

### Reliability improvements

- **Per-test error isolation.** Template-not-found, dispatch errors, SSL
  failures, variable-extraction errors — all now produce a failed step in
  the report instead of an uncaught exception that killed the suite. The
  next test always runs.
- **RenderLog persisted to disk.** Each step's render log is saved next
  to its `request.txt`/`response.txt` under `output/.../step.../render-log.txt`.
  Shows which placeholders were missing, which tags were dropped, which
  parents cascaded.
- **Step errors shown in HTML report.** When a step fails for any reason
  (template error, dispatch error, etc.), the report shows the full
  rendered log inline with the failed step.

### Other

- Version badge added to HTML report header.
- `Required` placeholder syntax `${!name}` documented — raises a clear
  error if the column is blank/missing.

## 1.0.0 — earlier

- Initial Java port from the original UFT/VBScript suite.
- Excel-driven test definition (5 sheets: Environments, TestSuite, Steps,
  TestData, Assertions).
- Four protocols: REST, SOAP, Fabric, GCP.
- Five comparison modes; nine assertion operators.
- Self-contained HTML report.
- Parser-free `SimpleXmlWalker` for assertion extraction (handles
  SOAP-in-SOAP, CDATA-wrapped inner XML).
