# API Test Suite — Python

**Version 1.1.0** — Excel-driven API testing for REST, SOAP, Apigee, Fabric and
GCP, with multi-step chains, structural response comparison, field-level
assertions and a self-contained HTML report.

This is the Python flavour of the tool. It reads the same workbook format and
produces the same comparison results as the Java version, so a suite written for
one runs unchanged on the other.

---

## What you need

- Python 3.11 or newer
- The four runtime packages in `requirements.txt`

```bash
pip install -r requirements.txt
```

If your environment blocks installs, `pip download -r requirements.txt -d wheels`
on a machine that allows them, copy the `wheels` folder across, then
`pip install --no-index --find-links wheels -r requirements.txt`.

---

## Quick start

```bash
python -m apitest --suite config/test_suite.xlsx --report reports
```

Exit code is 0 when everything passed and 1 when anything failed, so it drops
straight into a CI job.

### Command-line options

| Flag | Purpose |
|---|---|
| `--suite <file>` | Workbook to run. Default `config/test_suite.xlsx`. |
| `--report <dir>` | Where the HTML report is written. Default `reports`. |
| `--templates <dir>` | Where BodyTemplate files are looked up. Default `templates`. |
| `--expected <dir>` | Where ExpectedFile baselines are looked up. Default `expected`. |
| `--filter T001,T002` | Run only these tests. |
| `--fail-fast` | Stop at the first failing test. |
| `--dry-run` | Load and validate the workbook without sending any request. |

`--dry-run` is worth knowing about: it prints the method, endpoint and template
each source would use and flags undefined environments, missing SourceB and
tests with no steps — all without touching a real system.

---

## Project layout

```
api-test-suite-py/
├── apitest/                Package
│   ├── cli.py              Entry point and argument parsing
│   ├── excel.py            Workbook → model
│   ├── models.py           Dataclasses passed between the stages
│   ├── templating.py       ${placeholder} substitution, path containment
│   ├── dispatcher.py       HTTP, auth, TLS
│   ├── canonical.py        Cross-format normalisation
│   ├── comparator.py       Structural diff
│   ├── assertions.py       Field and database assertions
│   └── reporter.py         HTML report
├── config/
│   ├── test_suite.xlsx     Your tests
│   └── secrets.properties  Referenced values, never committed
├── templates/              Request body templates
├── expected/               Baseline files for vs_expected
├── reports/                Generated reports
└── tests/                  pytest suite
```

---

## The workbook

Five sheets, matched by name: **Environments**, **TestSuite**, **Steps**,
**TestData**, **Assertions**. Columns are found by header name, so column order
does not matter and extra columns are ignored.

### Comparison modes

| Mode | What runs | What is compared |
|---|---|---|
| `vs_expected` | Source A | Last response against `ExpectedFile` |
| `vs_env` | A and B | Response A against response B |
| `vs_protocol` | A and B | Same, but the two may be different formats |
| `assert_only` | Source A | Nothing — assertions only |
| `chain` | Source A | Nothing — passes when every step returns an expected status |

### Two sources in one step

For `vs_env` and `vs_protocol`, the `Method`, `Endpoint` and `BodyTemplate`
cells each accept `SourceA | SourceB`:

| Cell | Value | Result |
|---|---|---|
| `Method` | `GET\|POST` | A uses GET, B uses POST |
| `Endpoint` | `/rest/accounts\|/ServiceRouter` | Each source gets its own path |
| `BodyTemplate` | `\|soap_req.xml` | A sends no body, B sends the SOAP envelope |

No pipe means the single value applies to both. `ExtraHeaders` does not split —
put a per-platform header such as `SOAPAction` on that platform's row in the
Environments sheet.

### Placeholders

| Token | Resolves to |
|---|---|
| `${column_name}` | A value from this test's TestData row |
| `${stepN.field}` | A value extracted by step N of the same test |
| `${env.NAME}` | An environment variable |
| `${file.path:key}` | A key from a properties file |
| `${now}` / `${uuid}` | Timestamp / random id |
| `${name + N}` / `${name - N}` | The value of `name`, plus or minus a whole number |

Step variables are shared between steps of the same test only; they do not carry
across TestIDs.

### Incrementing an extracted value

When you pull a number out of one response and need the next value on the
following request, add a whole-number offset to the placeholder:

```
Step 1  ExtractVars:  seq=$.data.sequenceNumber
Step 2  Endpoint:     /api/orders/${step1.seq + 1}/submit
```

If step 1 returns `234234233`, step 2 is called with `234234234`. It works on
any numeric placeholder — a step variable, a TestData column or an environment
variable.

The rules are deliberately narrow: whole numbers only, `+` or `-` only, and
**spaces around the operator are required** (`${seq + 1}`, not `${seq+1}`) — which
keeps a column named `order-2024` from being read as subtraction. Applying an
offset to a non-numeric value fails the test with a clear message. Values are
handled at arbitrary precision, so large ids increment exactly.

---

## Comparing across formats

`vs_protocol` handles two platforms returning the same data in different shapes.
Both sides are normalised first, so only real differences survive.

**Bridged automatically:** key casing and separators; XML attributes against
JSON fields; a single element against a one-element array; list ordering;
number formats (`12345.00000` against `1.2345E4`, `0.15` against `0.15000`);
`"true"` against `true`; dates (`20170825` against `2017-08-25`); Unicode form;
SOAP envelopes, `Header` blocks and the routing `Version`/`Sender`/`Receiver`
block.

**Still reported:** different scalar values, fields present on only one side,
and missing or surplus records.

The comparison picks its strategy from the payload. A list of records is matched
by business key rather than position, so reordering is not a difference. A single
deeply nested document gets a recursive walk instead — reducing it to its largest
inner list would silently discard the rest of the tree.

Fields that legitimately exist on only one platform surface as added or removed
by design. Silence them with an `ignore` assertion when you expect them.

---

## Assertions

| Group | Operators |
|---|---|
| Value | `equals`, `not_equals`, `contains`, `not_contains` |
| Presence | `exists`, `not_exists`, `not_null` |
| Numeric / pattern | `greater_than`, `less_than`, `regex_match` |
| List membership | `one_of` |
| Structure | `has_children`, `count_equals` |
| Database | `db_equals`, `db_contains`, `db_exists` |
| Comparison control | `ignore` |

When a path matches several sibling elements the assertion passes if **any** of
them satisfies it, and a failure lists every value that was checked.

`TestID` of `*` applies a rule to every test — useful for ignoring timestamps
and trace ids.

Database assertions put the SQL in the `Path` column with `PathType` of `sql`.
Only `SELECT` and `WITH` run, stacked statements are rejected. SQLite works out
of the box; other engines need their driver installed.

---

## The HTML report

One self-contained file — no CDN, no web fonts, nothing fetched when it opens,
so it works on a locked-down machine and survives being emailed.

- Filter by status and search by name (press `/` to jump to the box)
- Differences grouped by kind, so value mismatches sit above one-sided fields
- Copy button on every payload
- **Reproduce with curl** on every step, with credentials redacted
- Collapsible diagnostics with the full traceback when something breaks

---

## Security

- Secrets are referenced, never stored: `${env.NAME}` or `${file.path:key}`.
  The workbook stays safe to share.
- `BodyTemplate` and `ExpectedFile` resolve strictly inside their configured
  directory. A relative path cannot climb out with `../`. Absolute paths still
  work for files on a shared drive.
- XML parsing has external entities, DTDs and network access disabled.
- Turning off TLS verification prints a warning naming the risk, once per
  environment.
- Report content is HTML-escaped, and `Authorization`, `x-api-key` and `Cookie`
  headers are redacted from the curl commands.

---

## Running the tests

```bash
pip install -r requirements.txt pytest
python -m pytest
```
