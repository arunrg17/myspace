"""Excel-driven API testing for REST, SOAP, Apigee, Fabric and GCP."""

__version__ = "1.1.0"
