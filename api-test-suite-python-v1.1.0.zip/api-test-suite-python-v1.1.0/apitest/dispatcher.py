"""Sends one HTTP request and captures the response.

Never raises for transport problems — a timeout or TLS failure comes back as a
Response with ``error`` set, so one unreachable environment does not abort the
whole suite.
"""

from __future__ import annotations

import base64
import os
import re
import time
from pathlib import Path

import requests
import urllib3

from .models import Response

TIMEOUT_SECONDS = 30

_SECRET_ENV = re.compile(r"\$\{env\.([^}]+)\}")
_SECRET_FILE = re.compile(r"\$\{file\.([^:}]+):([^}]+)\}")

# Contexts get reused, so the TLS warning is printed once per config rather than
# on every request.
_warned_configs: set[str] = set()


def resolve_secret(value: str) -> str:
    """Turn ${env.NAME} or ${file.path:key} into the real value.

    Never logs what it resolved — that is the whole point of keeping secrets out
    of the workbook.
    """
    if not value:
        return ""

    def from_env(m: re.Match) -> str:
        return os.environ.get(m.group(1), "")

    def from_file(m: re.Match) -> str:
        path, key = m.group(1), m.group(2)
        try:
            for line in Path(path).read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                if k.strip() == key:
                    return v.strip()
        except OSError:
            return ""
        return ""

    value = _SECRET_ENV.sub(from_env, value)
    value = _SECRET_FILE.sub(from_file, value)
    return value


def _parse_ssl_config(config: str) -> dict[str, str]:
    opts: dict[str, str] = {}
    for part in (config or "").split(";"):
        part = part.strip()
        if "=" in part:
            k, v = part.split("=", 1)
            opts[k.strip().lower()] = v.strip()
    return opts


def _tls_settings(ssl_config: str) -> tuple[object, object]:
    """Return (verify, cert) for requests, warning if verification is off."""
    opts = _parse_ssl_config(ssl_config)
    if not opts:
        return True, None

    verify: object = True
    if opts.get("verify", "").lower() == "false":
        if ssl_config not in _warned_configs:
            _warned_configs.add(ssl_config)
            print("WARNING: TLS verification is disabled (verify=false). "
                  "Certificates and hostnames are not checked for this environment. "
                  "Do not use this against production.")
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        verify = False
    elif "trust_store" in opts:
        verify = opts["trust_store"]

    cert: object = None
    if "key_store" in opts:
        key_pass = resolve_secret(opts.get("key_password", ""))
        cert = (opts["key_store"], key_pass) if key_pass else opts["key_store"]

    return verify, cert


def resolve_auth(auth_type: str, auth_value: str) -> dict[str, str]:
    """Turn an auth type and credential into the headers that carry it."""
    kind = (auth_type or "none").lower()
    value = resolve_secret(auth_value or "")
    if kind in ("none", "") or not value:
        return {}
    if kind == "basic":
        token = base64.b64encode(value.encode("utf-8")).decode("ascii")
        return {"Authorization": f"Basic {token}"}
    if kind in ("bearer", "oauth2", "service_account"):
        return {"Authorization": value if value.lower().startswith("bearer ") else f"Bearer {value}"}
    if kind == "apikey":
        return {"x-api-key": value}
    return {}


def compose_url(base_url: str, endpoint: str) -> str:
    if endpoint.startswith(("http://", "https://")):
        return endpoint
    if not base_url:
        return endpoint
    return base_url.rstrip("/") + "/" + endpoint.lstrip("/")


def send(protocol: str, base_url: str, endpoint: str, method: str, body: str,
         headers: dict[str, str] | None, auth_type: str, auth_value: str,
         ssl_config: str = "") -> Response:
    """Send one request. Transport failures come back in ``Response.error``."""
    final_headers = dict(headers or {})
    final_headers.update(resolve_auth(auth_type, auth_value))

    proto = (protocol or "").lower()
    if proto == "soap":
        final_headers.setdefault("Content-Type", "text/xml; charset=utf-8")
        final_headers.setdefault("SOAPAction", '""')
        # SOAP is conventionally POST, but honour an explicit method: some
        # gateways are invoked over GET and still expect the envelope.
        if not method or not method.strip():
            method = "POST"
    elif proto in ("rest", "apigee", "fabric", "gcp"):
        if body:
            final_headers.setdefault("Content-Type", "application/json")

    method = (method or "GET").upper()
    url = compose_url(base_url, endpoint)
    verify, cert = _tls_settings(ssl_config)

    resp = Response(url=url)
    started = time.monotonic()
    try:
        # requests sends a body on any verb, so a SOAP call over GET still
        # delivers its envelope.
        r = requests.request(
            method=method, url=url,
            data=body.encode("utf-8") if body else None,
            headers=final_headers, timeout=TIMEOUT_SECONDS,
            verify=verify, cert=cert, allow_redirects=True,
        )
        resp.status = r.status_code
        resp.headers = dict(r.headers)
        resp.body = r.text
    except requests.exceptions.RequestException as exc:
        resp.error = f"{type(exc).__name__}: {exc}"
    finally:
        resp.elapsed_ms = int((time.monotonic() - started) * 1000)

    return resp
