"""Builds the HTML report.

Everything is inlined — no CDN, no web fonts, no external scripts — so the file
opens on a locked-down machine and can be emailed as a single attachment.
"""

from __future__ import annotations

import html
import json
import shlex
from datetime import datetime
from pathlib import Path

from .models import CompareResult, DiffEntry, StepResult, TestResult


def esc(s: object) -> str:
    return html.escape("" if s is None else str(s), quote=True)


def _pretty(payload: str) -> str:
    """Pretty-print JSON so a one-line response is readable."""
    text = (payload or "").strip()
    if not text:
        return ""
    if text[0] in "{[":
        try:
            return json.dumps(json.loads(text), indent=2, ensure_ascii=False)
        except json.JSONDecodeError:
            return text
    return text


def _as_curl(step: StepResult) -> str:
    """Rebuild the request as a curl command so a failure can be reproduced."""
    parts = ["curl", "-i", "-X", step.method or "GET"]
    for k, v in (step.request_headers or {}).items():
        # Never leak credentials into something people paste into chat.
        shown = "<redacted>" if k.lower() in ("authorization", "x-api-key", "cookie") else v
        parts += ["-H", f"{k}: {shown}"]
    if step.request_body:
        parts += ["--data-binary", step.request_body]
    parts.append(step.url or "")
    return " ".join(shlex.quote(p) for p in parts)


def _code_block(payload: str, label: str, block_id: str) -> str:
    if not (payload or "").strip():
        return f'<div class="code-empty">{esc(label)}: (empty)</div>'
    text = _pretty(payload)
    lines = text.count("\n") + 1
    size = len(text)
    return (
        f'<div class="code-wrap">'
        f'<div class="code-head">'
        f'<span class="code-label">{esc(label)}</span>'
        f'<span class="code-meta">{lines} lines · {size:,} bytes</span>'
        f'<button class="copy-btn" onclick="copyBlock(\'{block_id}\')">Copy</button>'
        f'</div>'
        f'<pre class="code" id="{block_id}">{esc(text)}</pre>'
        f'</div>')


def _severity(kind: str) -> str:
    return {"value": "Value mismatch", "added": "Only in B", "removed": "Only in A"}.get(kind, kind)


def _diff_table(diffs: list[DiffEntry]) -> str:
    """Group differences by kind, so real conflicts surface above absences."""
    if not diffs:
        return '<div class="ok-note">No differences.</div>'

    grouped: dict[str, list[DiffEntry]] = {}
    for d in diffs:
        grouped.setdefault(d.kind, []).append(d)

    out = []
    for kind in ("value", "removed", "added"):
        items = grouped.get(kind)
        if not items:
            continue
        out.append(
            f'<div class="diff-group">'
            f'<div class="diff-group-head diff-{esc(kind)}">'
            f'{esc(_severity(kind))} <span class="pill">{len(items)}</span></div>'
            f'<table class="diff-table"><thead><tr>'
            f'<th>Path</th><th>Source A</th><th>Source B</th></tr></thead><tbody>')
        for d in items[:200]:
            out.append(
                f'<tr><td class="path">{esc(d.path)}</td>'
                f'<td class="val">{esc(d.expected)}</td>'
                f'<td class="val">{esc(d.actual)}</td></tr>')
        if len(items) > 200:
            out.append(f'<tr><td colspan="3" class="more">'
                       f'… {len(items) - 200} more not shown</td></tr>')
        out.append('</tbody></table></div>')
    return "".join(out)


def _assertion_table(results) -> str:
    if not results:
        return ""
    rows = []
    for a in results:
        cls = "pass" if a.passed else "fail"
        rows.append(
            f'<tr class="{cls}">'
            f'<td>{"PASS" if a.passed else "FAIL"}</td>'
            f'<td class="path">{esc(a.path)}</td>'
            f'<td>{esc(a.operator)}</td>'
            f'<td class="val">{esc(a.expected_value)}</td>'
            f'<td class="val">{esc(a.actual_value)}</td>'
            f'<td class="msg">{esc(a.message or a.description)}</td></tr>')
    return (
        '<table class="assert-table"><thead><tr>'
        '<th>Result</th><th>Path</th><th>Operator</th>'
        '<th>Expected</th><th>Actual</th><th>Notes</th>'
        '</tr></thead><tbody>' + "".join(rows) + '</tbody></table>')


def _step_card(s: StepResult, idx: str, side: str) -> str:
    status_cls = "pass" if s.passed else "fail"
    curl_id = f"curl-{idx}"
    return (
        f'<div class="step">'
        f'<div class="step-head">'
        f'<span class="badge {status_cls}">{esc(s.method)}</span>'
        f'<span class="step-name">{esc(s.name)}</span>'
        f'<span class="step-meta">{s.status or "—"} · {s.elapsed_ms} ms</span>'
        f'</div>'
        f'<div class="url">{esc(s.url)}</div>'
        + (f'<div class="err">{esc(s.error)}</div>' if s.error else "")
        + _code_block(s.request_body, "Request body", f"req-{idx}")
        + _code_block(s.response_body, "Response body", f"res-{idx}")
        + f'<details class="curl"><summary>Reproduce with curl</summary>'
          f'<div class="code-wrap"><div class="code-head">'
          f'<span class="code-label">curl</span>'
          f'<button class="copy-btn" onclick="copyBlock(\'{curl_id}\')">Copy</button></div>'
          f'<pre class="code" id="{curl_id}">{esc(_as_curl(s))}</pre></div></details>'
        + (f'<details class="diag"><summary>Diagnostics</summary>'
           f'<pre class="code">{esc(s.error_detail)}</pre></details>' if s.error_detail else "")
        + '</div>')


def _test_section(r: TestResult, idx: int) -> str:
    cls = r.status.lower()
    parts = [
        f'<section class="test {cls}" id="test-{idx}" '
        f'data-status="{esc(r.status)}" data-name="{esc((r.test_id + " " + r.name).lower())}">',
        f'<h2><span class="status-chip {cls}">{esc(r.status)}</span>'
        f'{esc(r.test_id)} — {esc(r.name)}</h2>',
        f'<div class="test-meta">{esc(r.mode)}'
        + (f' · A: {esc(r.source_a)}' if r.source_a else "")
        + (f' · B: {esc(r.source_b)}' if r.source_b else "")
        + f' · {r.elapsed_ms} ms</div>',
    ]
    if r.description:
        parts.append(f'<div class="desc">{esc(r.description)}</div>')
    if r.error:
        parts.append(f'<div class="err">{esc(r.error)}</div>')
    if r.error_detail:
        parts.append(f'<details class="diag"><summary>Diagnostics</summary>'
                     f'<pre class="code">{esc(r.error_detail)}</pre></details>')

    if r.steps_a:
        parts.append(f'<h3>Source A{" — " + esc(r.source_a) if r.source_a else ""}</h3>')
        parts += [_step_card(s, f"{idx}a{i}", "A") for i, s in enumerate(r.steps_a)]
    if r.steps_b:
        parts.append(f'<h3>Source B{" — " + esc(r.source_b) if r.source_b else ""}</h3>')
        parts += [_step_card(s, f"{idx}b{i}", "B") for i, s in enumerate(r.steps_b)]

    if r.comparison:
        c: CompareResult = r.comparison
        verdict = "match" if c.matched else "differ"
        parts.append(f'<h3>Comparison <span class="note">{esc(c.note)}</span></h3>')
        parts.append(f'<div class="verdict {verdict}">'
                     f'{"Payloads match" if c.matched else f"{len(c.diffs)} difference(s)"}</div>')
        if c.parse_error:
            parts.append(f'<div class="err">{esc(c.parse_error)}</div>')
        parts.append(_diff_table(c.diffs))

    if r.assertions:
        passed = sum(1 for a in r.assertions if a.passed)
        parts.append(f'<h3>Assertions <span class="note">{passed}/{len(r.assertions)} passed</span></h3>')
        parts.append(_assertion_table(r.assertions))

    parts.append('</section>')
    return "".join(parts)


def _donut(passed: int, failed: int, errored: int) -> str:
    total = max(passed + failed + errored, 1)
    circumference = 2 * 3.14159 * 52
    segments, offset = [], 0.0
    for count, colour in ((passed, "#2e754b"), (failed, "#c23b3b"), (errored, "#b7791f")):
        if not count:
            continue
        length = circumference * count / total
        segments.append(
            f'<circle cx="60" cy="60" r="52" fill="none" stroke="{colour}" stroke-width="14" '
            f'stroke-dasharray="{length:.2f} {circumference - length:.2f}" '
            f'stroke-dashoffset="{-offset:.2f}" transform="rotate(-90 60 60)"/>')
        offset += length
    pct = round(100 * passed / total)
    return (f'<svg width="120" height="120" viewBox="0 0 120 120">'
            f'<circle cx="60" cy="60" r="52" fill="none" stroke="#e6ebf1" stroke-width="14"/>'
            + "".join(segments)
            + f'<text x="60" y="66" text-anchor="middle" font-size="24" font-weight="600" '
              f'fill="#1f4e79">{pct}%</text></svg>')


def render_report(results: list[TestResult], report_path: str | Path,
                  suite_name: str = "") -> Path:
    """Write the report and return where it landed."""
    report_path = Path(report_path)
    report_path.parent.mkdir(parents=True, exist_ok=True)

    passed = sum(1 for r in results if r.status == "PASS")
    failed = sum(1 for r in results if r.status == "FAIL")
    errored = sum(1 for r in results if r.status == "ERROR")
    total_ms = sum(r.elapsed_ms for r in results)

    nav = "".join(
        f'<a class="nav-item {r.status.lower()}" href="#test-{i}" '
        f'data-status="{esc(r.status)}" data-name="{esc((r.test_id + " " + r.name).lower())}">'
        f'<span class="dot {r.status.lower()}"></span>'
        f'<span class="nav-id">{esc(r.test_id)}</span>'
        f'<span class="nav-name">{esc(r.name)}</span></a>'
        for i, r in enumerate(results))

    sections = "".join(_test_section(r, i) for i, r in enumerate(results))
    generated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    doc = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>API Test Report</title>
<style>{_CSS}</style></head>
<body>
<header class="top">
  <div class="title">
    <h1>API Test Report</h1>
    <div class="sub">{esc(suite_name)} · generated {esc(generated)}</div>
  </div>
  <div class="summary">
    {_donut(passed, failed, errored)}
    <div class="counts">
      <div class="count pass"><b>{passed}</b> passed</div>
      <div class="count fail"><b>{failed}</b> failed</div>
      <div class="count error"><b>{errored}</b> errored</div>
      <div class="count total"><b>{len(results)}</b> total · {total_ms:,} ms</div>
    </div>
  </div>
</header>

<div class="layout">
  <aside class="sidebar">
    <input id="search" class="search" type="search" placeholder="Filter tests…"
           oninput="applyFilters()" autocomplete="off">
    <div class="filters">
      <button class="chip active" data-filter="ALL" onclick="setFilter(this)">All</button>
      <button class="chip" data-filter="PASS" onclick="setFilter(this)">Passed</button>
      <button class="chip" data-filter="FAIL" onclick="setFilter(this)">Failed</button>
      <button class="chip" data-filter="ERROR" onclick="setFilter(this)">Errored</button>
    </div>
    <nav id="nav">{nav}</nav>
  </aside>
  <main id="main">{sections}
    <div id="empty" class="empty" hidden>Nothing matches the current filter.</div>
  </main>
</div>

<script>
var currentFilter = 'ALL';

function setFilter(btn) {{
  currentFilter = btn.getAttribute('data-filter');
  var chips = document.querySelectorAll('.chip');
  for (var i = 0; i < chips.length; i++) chips[i].classList.remove('active');
  btn.classList.add('active');
  applyFilters();
}}

function applyFilters() {{
  var q = document.getElementById('search').value.toLowerCase().trim();
  var shown = 0;
  var tests = document.querySelectorAll('.test');
  for (var i = 0; i < tests.length; i++) {{
    var el = tests[i];
    var okStatus = currentFilter === 'ALL' || el.getAttribute('data-status') === currentFilter;
    var okText = !q || el.getAttribute('data-name').indexOf(q) !== -1;
    var visible = okStatus && okText;
    el.hidden = !visible;
    if (visible) shown++;
  }}
  var items = document.querySelectorAll('.nav-item');
  for (var j = 0; j < items.length; j++) {{
    var n = items[j];
    var okS = currentFilter === 'ALL' || n.getAttribute('data-status') === currentFilter;
    var okT = !q || n.getAttribute('data-name').indexOf(q) !== -1;
    n.hidden = !(okS && okT);
  }}
  document.getElementById('empty').hidden = shown !== 0;
}}

function copyBlock(id) {{
  var el = document.getElementById(id);
  if (!el) return;
  var text = el.innerText;
  if (navigator.clipboard && navigator.clipboard.writeText) {{
    navigator.clipboard.writeText(text);
  }} else {{
    var ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    try {{ document.execCommand('copy'); }} catch (e) {{}}
    document.body.removeChild(ta);
  }}
}}

document.addEventListener('keydown', function (e) {{
  if (e.key === '/' && document.activeElement.id !== 'search') {{
    e.preventDefault();
    document.getElementById('search').focus();
  }}
}});
</script>
</body></html>"""

    report_path.write_text(doc, encoding="utf-8")
    return report_path


_CSS = """
* { box-sizing: border-box; }
body { margin:0; font:14px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
       color:#22303c; background:#f4f6f8; }
h1 { margin:0; font-size:20px; color:#1f4e79; }
h2 { margin:0 0 4px; font-size:16px; }
h3 { margin:20px 0 8px; font-size:13px; text-transform:uppercase;
     letter-spacing:.5px; color:#5b6b7d; }
.note { text-transform:none; letter-spacing:0; color:#8895a3; font-weight:400; }

.top { display:flex; justify-content:space-between; align-items:center; gap:24px;
       padding:16px 24px; background:#fff; border-bottom:1px solid #dde4ea; }
.sub { color:#7d8b99; font-size:12px; margin-top:2px; }
.summary { display:flex; align-items:center; gap:20px; }
.counts { display:grid; grid-template-columns:auto auto; gap:2px 18px; font-size:13px; }
.count b { font-size:15px; }
.count.pass b { color:#2e754b; } .count.fail b { color:#c23b3b; }
.count.error b { color:#b7791f; } .count.total { color:#7d8b99; }

.layout { display:flex; align-items:flex-start; }
.sidebar { width:270px; flex:0 0 270px; padding:16px; position:sticky; top:0;
           max-height:100vh; overflow-y:auto; }
.search { width:100%; padding:7px 10px; border:1px solid #cfd8e1; border-radius:6px;
          font-size:13px; background:#fff; }
.filters { display:flex; gap:4px; margin:10px 0; flex-wrap:wrap; }
.chip { border:1px solid #cfd8e1; background:#fff; border-radius:20px; padding:3px 11px;
        font-size:12px; cursor:pointer; color:#5b6b7d; }
.chip.active { background:#1f4e79; color:#fff; border-color:#1f4e79; }
.nav-item { display:flex; align-items:center; gap:7px; padding:6px 8px; border-radius:5px;
            text-decoration:none; color:#33485e; font-size:13px; }
.nav-item:hover { background:#e9eff5; }
.nav-id { font-weight:600; font-size:12px; }
.nav-name { color:#7d8b99; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.dot { width:8px; height:8px; border-radius:50%; flex:0 0 8px; }
.dot.pass { background:#2e754b; } .dot.fail { background:#c23b3b; }
.dot.error { background:#b7791f; }

main { flex:1; padding:16px 24px 60px 0; min-width:0; }
.test { background:#fff; border:1px solid #dde4ea; border-left-width:4px;
        border-radius:8px; padding:16px 18px; margin-bottom:16px; }
.test.pass { border-left-color:#2e754b; }
.test.fail { border-left-color:#c23b3b; }
.test.error { border-left-color:#b7791f; }
.status-chip { display:inline-block; padding:1px 8px; border-radius:4px; font-size:11px;
               font-weight:700; margin-right:8px; vertical-align:middle; color:#fff; }
.status-chip.pass { background:#2e754b; } .status-chip.fail { background:#c23b3b; }
.status-chip.error { background:#b7791f; }
.test-meta { color:#8895a3; font-size:12px; }
.desc { color:#5b6b7d; font-size:13px; margin-top:6px; }

.step { border:1px solid #e6ebf1; border-radius:6px; padding:10px 12px; margin-bottom:10px;
        background:#fbfcfd; }
.step-head { display:flex; align-items:center; gap:9px; }
.badge { font-size:11px; font-weight:700; padding:2px 7px; border-radius:4px; color:#fff; }
.badge.pass { background:#2e754b; } .badge.fail { background:#c23b3b; }
.step-name { font-weight:600; font-size:13px; }
.step-meta { margin-left:auto; color:#8895a3; font-size:12px; }
.url { font-family:Consolas,Menlo,monospace; font-size:12px; color:#33485e;
       margin:6px 0 8px; word-break:break-all; }

.code-wrap { border:1px solid #e6ebf1; border-radius:5px; margin:6px 0; background:#fff; }
.code-head { display:flex; align-items:center; gap:10px; padding:5px 9px;
             background:#f4f7fa; border-bottom:1px solid #e6ebf1; font-size:11px; }
.code-label { font-weight:600; color:#5b6b7d; }
.code-meta { color:#9aa7b4; }
.copy-btn { margin-left:auto; border:1px solid #cfd8e1; background:#fff; border-radius:4px;
            font-size:11px; padding:2px 8px; cursor:pointer; color:#5b6b7d; }
.copy-btn:hover { background:#eef3f8; }
pre.code { margin:0; padding:9px 11px; font-family:Consolas,Menlo,monospace; font-size:12px;
           white-space:pre-wrap; word-break:break-word; max-height:340px; overflow:auto; }
.code-empty { border:1px dashed #d5dde5; border-radius:5px; padding:7px 10px; margin:6px 0;
              color:#9aa7b4; font-size:12px; font-style:italic; }

.verdict { padding:7px 11px; border-radius:5px; font-size:13px; font-weight:600; margin:6px 0; }
.verdict.match { background:#e9f5ee; color:#2e754b; }
.verdict.differ { background:#fdeeee; color:#c23b3b; }
.ok-note { color:#2e754b; font-size:13px; }

.diff-group { margin-bottom:12px; }
.diff-group-head { font-size:12px; font-weight:700; padding:5px 9px; border-radius:4px 4px 0 0; }
.diff-group-head.diff-value { background:#fdeeee; color:#a02c2c; }
.diff-group-head.diff-removed { background:#fff6e9; color:#8a5a12; }
.diff-group-head.diff-added { background:#eef3f8; color:#1f4e79; }
.pill { background:rgba(0,0,0,.12); border-radius:10px; padding:0 7px; margin-left:6px; }
table { border-collapse:collapse; width:100%; font-size:12px; }
.diff-table th, .assert-table th { text-align:left; background:#f4f7fa; color:#5b6b7d;
       padding:5px 8px; border-bottom:1px solid #e6ebf1; font-weight:600; }
.diff-table td, .assert-table td { padding:5px 8px; border-bottom:1px solid #f0f3f6;
       vertical-align:top; }
.path { font-family:Consolas,Menlo,monospace; color:#33485e; word-break:break-all; }
.val { font-family:Consolas,Menlo,monospace; word-break:break-all; }
.msg { color:#7d8b99; }
.more { color:#9aa7b4; font-style:italic; }
.assert-table tr.pass td:first-child { color:#2e754b; font-weight:700; }
.assert-table tr.fail td:first-child { color:#c23b3b; font-weight:700; }

.err { background:#fdeeee; border-left:3px solid #c23b3b; color:#a02c2c; padding:7px 10px;
       border-radius:4px; font-size:12px; margin:6px 0; white-space:pre-wrap; }
details.diag, details.curl { margin-top:6px; }
details summary { cursor:pointer; font-size:12px; color:#5b6b7d; padding:3px 0; }
.empty { text-align:center; color:#9aa7b4; padding:50px; font-style:italic; }
"""
