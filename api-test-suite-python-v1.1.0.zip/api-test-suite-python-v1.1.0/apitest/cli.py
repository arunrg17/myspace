"""Command-line entry point.

Exits 0 when everything passed and 1 when anything failed, so it drops straight
into a CI job.
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

from . import excel, reporter, runner
from .models import RunConfig

VERSION = "1.1.0"


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="apitest",
        description="Excel-driven API testing for REST, SOAP, Apigee, Fabric and GCP.")
    p.add_argument("--suite", default="config/test_suite.xlsx",
                   help="workbook to run (default: config/test_suite.xlsx)")
    p.add_argument("--report", default="reports",
                   help="directory for the HTML report (default: reports)")
    p.add_argument("--templates", default="templates",
                   help="directory holding request body templates")
    p.add_argument("--expected", default="expected",
                   help="directory holding baseline files")
    p.add_argument("--certs", default="certs", help="directory holding keystores")
    p.add_argument("--filter", default="",
                   help="run only these test ids, comma separated")
    p.add_argument("--fail-fast", action="store_true",
                   help="stop at the first failing test")
    p.add_argument("--dry-run", action="store_true",
                   help="load and validate the workbook without sending any request")
    p.add_argument("--version", action="version", version=f"apitest {VERSION}")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    suite_path = Path(args.suite).resolve()
    project_root = suite_path.parent.parent if suite_path.parent.name == "config" else Path.cwd()

    cfg = RunConfig(
        suite_file=suite_path,
        report_dir=Path(args.report).resolve(),
        templates_dir=Path(args.templates).resolve(),
        expected_dir=Path(args.expected).resolve(),
        certs_dir=Path(args.certs).resolve(),
        project_root=project_root,
    )

    print(f"apitest {VERSION}")
    print(f"  suite:     {suite_path}")

    try:
        suite = excel.load(suite_path)
    except excel.WorkbookError as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"\nERROR: could not read the workbook: {exc}", file=sys.stderr)
        return 1

    if args.filter:
        wanted = {t.strip() for t in args.filter.split(",") if t.strip()}
        suite.tests = [t for t in suite.tests if t.test_id in wanted]

    print(f"  tests:     {len(suite.tests)}")
    print(f"  environments: {len(suite.environments)}\n")

    if not suite.tests:
        print("Nothing to run.")
        return 0

    if args.dry_run:
        return _dry_run(suite)

    results = []
    for tc in suite.tests:
        print(f"  {tc.test_id}  {tc.name}")
        r = runner.run_test(tc, suite, cfg)
        print(f"    -> {r.status} ({r.elapsed_ms} ms)")
        results.append(r)
        if args.fail_fast and r.status != "PASS":
            print("\n  stopping early (--fail-fast)")
            break

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = cfg.report_dir / f"report_{stamp}.html"
    reporter.render_report(results, report_file, suite_name=suite_path.name)

    passed = sum(1 for r in results if r.status == "PASS")
    failed = len(results) - passed
    print(f"\n  {passed} passed, {failed} failed")
    print(f"  report: {report_file}")
    return 0 if failed == 0 else 1


def _dry_run(suite) -> int:
    """Report what would run, and any problems visible without sending traffic."""
    problems: list[str] = []
    print("Dry run — no requests will be sent.\n")

    for tc in suite.tests:
        print(f"  {tc.test_id}  {tc.name}  [{tc.mode}]")
        if tc.source_a and tc.source_a not in suite.environments:
            problems.append(f"{tc.test_id}: SourceA '{tc.source_a}' is not defined")
        if tc.mode in ("vs_env", "vs_protocol"):
            if not tc.source_b:
                problems.append(f"{tc.test_id}: {tc.mode} needs a SourceB")
            elif tc.source_b not in suite.environments:
                problems.append(f"{tc.test_id}: SourceB '{tc.source_b}' is not defined")
        if tc.mode == "vs_expected" and not tc.expected_file:
            problems.append(f"{tc.test_id}: vs_expected needs an ExpectedFile")
        if not tc.steps:
            problems.append(f"{tc.test_id}: has no steps")

        for s in tc.steps:
            a = f"A: {s.method_for('A')} {s.endpoint_for('A')}"
            print(f"      {a}" + (f"  body={s.body_template_for('A')}"
                                  if s.body_template_for('A') else ""))
            if tc.mode in ("vs_env", "vs_protocol"):
                b = f"B: {s.method_for('B')} {s.endpoint_for('B')}"
                print(f"      {b}" + (f"  body={s.body_template_for('B')}"
                                      if s.body_template_for('B') else ""))

    if problems:
        print("\n  Problems found:")
        for p in problems:
            print(f"    - {p}")
        return 1

    print("\n  No problems found.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
