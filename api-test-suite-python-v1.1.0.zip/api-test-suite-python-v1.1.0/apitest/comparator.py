"""Structural comparison of two payloads.

Both sides are parsed into a common dict/list/scalar tree so XML and JSON can be
compared directly. Same-format payloads get a plain recursive diff; payloads in
different formats are canonicalised first and then compared either as a list of
records or as a single document, depending on their shape.
"""

from __future__ import annotations

import html
import json
import re
from decimal import Decimal
from typing import Any

from lxml import etree

from . import canonical
from .models import Assertion, CompareResult, DiffEntry

# Parser that refuses external entities and DTDs. Responses come from systems we
# do not control, so an XXE payload must not be able to read local files.
_SAFE_PARSER = etree.XMLParser(
    resolve_entities=False, no_network=True, load_dtd=False, dtd_validation=False,
    huge_tree=False, recover=False,
)
_RECOVERING_PARSER = etree.XMLParser(
    resolve_entities=False, no_network=True, load_dtd=False, dtd_validation=False,
    huge_tree=False, recover=True,
)


class ExtractionError(Exception):
    """A path could not be evaluated against a payload."""


# ─── format detection and parsing ────────────────────────────────────────

def detect_format(payload: str) -> str:
    if payload is None:
        return "empty"
    s = payload.strip()
    if not s:
        return "empty"
    if s.startswith("<"):
        return "xml"
    if s[0] in "{[":
        return "json"
    return "text"


def _decode_escaped_xml(payload: str) -> str:
    """Decode a payload whose XML has been HTML-escaped into a text node."""
    if "&lt;" in payload and "<" in payload:
        unescaped = html.unescape(payload)
        if unescaped.count("<") > payload.count("<"):
            return unescaped
    return payload


def _unwrap_cdata(payload: str) -> str:
    matches = re.findall(r"<!\[CDATA\[(.*?)\]\]>", payload, re.S)
    for m in matches:
        if m.strip().startswith("<"):
            return m.strip()
    return payload


def _strip_inner_declarations(payload: str) -> str:
    """Remove any <?xml ?> that is no longer at the start after unwrapping."""
    first = payload.find("<?xml")
    if first <= 0:
        return payload
    return payload[:first] + re.sub(r"<\?xml[^>]*\?>", "", payload[first:])


def extract_inner_payload(payload: str) -> str:
    """Unwrap CDATA, escaped XML and SOAP envelopes until the real body shows."""
    current = payload
    for _ in range(10):
        nxt = _strip_inner_declarations(_unwrap_cdata(_decode_escaped_xml(current)))
        if nxt == current:
            break
        current = nxt
    return current.strip()


def _local_name(tag: Any) -> str:
    if not isinstance(tag, str):
        return ""
    return tag.split("}", 1)[1] if "}" in tag else tag


def _element_to_obj(el: etree._Element) -> Any:
    """Turn an element into a scalar, dict or list mirroring its structure."""
    children = [c for c in el if isinstance(c.tag, str)]
    result: dict[str, Any] = {}

    for name, value in el.attrib.items():
        result[f"@{_local_name(name)}"] = value

    if not children:
        text = (el.text or "").strip()
        if not result:
            return text
        if text:
            result["#text"] = text
        return result

    grouped: dict[str, list[Any]] = {}
    for child in children:
        grouped.setdefault(_local_name(child.tag), []).append(_element_to_obj(child))

    for name, values in grouped.items():
        result[name] = values[0] if len(values) == 1 else values
    return result


def xml_to_obj(payload: str) -> Any:
    """Parse XML into the common tree, recovering from minor malformation."""
    text = extract_inner_payload(payload)
    text = text.replace("\r\n", "\n").replace("\r", "")
    text = re.sub(r"&#x[dD];|&#13;", "", text)
    data = text.encode("utf-8")
    try:
        root = etree.fromstring(data, _SAFE_PARSER)
    except etree.XMLSyntaxError:
        root = etree.fromstring(data, _RECOVERING_PARSER)
        if root is None:
            raise
    return {_local_name(root.tag): _element_to_obj(root)}


def json_to_obj(payload: str) -> Any:
    return json.loads(payload)


def parse_payload(payload: str) -> Any:
    fmt = detect_format(payload)
    if fmt == "xml":
        return xml_to_obj(payload)
    if fmt == "json":
        return json_to_obj(payload)
    return payload


# ─── value equality ──────────────────────────────────────────────────────

def values_equal(a: Any, b: Any) -> bool:
    """Compare leaves by value, so 0.15 and 0.15000 are the same number."""
    if isinstance(a, bool) or isinstance(b, bool):
        return a == b
    if isinstance(a, (int, float, Decimal)) and isinstance(b, (int, float, Decimal)):
        return Decimal(str(a)) == Decimal(str(b))
    return a == b


def _fmt(v: Any) -> str:
    if v is None:
        return "<null>"
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


# ─── same-format structural diff ─────────────────────────────────────────

def _diff(a: Any, b: Any, path: str, diffs: list[DiffEntry]) -> None:
    if a is None and b is None:
        return
    if a is None:
        diffs.append(DiffEntry(path, "<missing>", _fmt(b), "added"))
        return
    if b is None:
        diffs.append(DiffEntry(path, _fmt(a), "<missing>", "removed"))
        return

    if isinstance(a, dict) and isinstance(b, dict):
        for key in sorted(set(a) | set(b)):
            child = f"{path}.{key}"
            if key in a and key in b:
                _diff(a[key], b[key], child, diffs)
            elif key in a:
                diffs.append(DiffEntry(child, _fmt(a[key]), "<missing>", "removed"))
            else:
                diffs.append(DiffEntry(child, "<missing>", _fmt(b[key]), "added"))
        return

    if isinstance(a, list) and isinstance(b, list):
        _diff_lists(a, b, path, diffs)
        return

    if not values_equal(a, b):
        diffs.append(DiffEntry(path, _fmt(a), _fmt(b), "value"))


def _diff_lists(la: list, lb: list, path: str, diffs: list[DiffEntry]) -> None:
    """Match list elements by content rather than position.

    Two systems may return the same items in a different order; that is not a
    difference worth reporting.
    """
    used = [False] * len(lb)
    unmatched: list[int] = []

    for i, item in enumerate(la):
        match = -1
        for j, candidate in enumerate(lb):
            if used[j]:
                continue
            probe: list[DiffEntry] = []
            _diff(item, candidate, "", probe)
            if not probe:
                match = j
                break
        if match >= 0:
            used[match] = True
        else:
            unmatched.append(i)

    for i in unmatched:
        best, best_score = -1, -1
        for j, candidate in enumerate(lb):
            if used[j]:
                continue
            probe: list[DiffEntry] = []
            _diff(la[i], candidate, "", probe)
            score = -len(probe)
            if score > best_score:
                best_score, best = score, j
        if best >= 0:
            used[best] = True
            _diff(la[i], lb[best], f"{path}[{i}]", diffs)
        else:
            diffs.append(DiffEntry(f"{path}[{i}]", _fmt(la[i]), "<missing>", "removed"))

    for j, candidate in enumerate(lb):
        if not used[j]:
            diffs.append(DiffEntry(f"{path}[{j}]", "<missing>", _fmt(candidate), "added"))


# ─── cross-format: records ───────────────────────────────────────────────

def _overlap_score(a: dict, b: dict) -> int:
    return sum(1 for k, v in a.items() if k in b and values_equal(v, b[k]))


def _value_appears_in(value: Any, record: dict) -> bool:
    return value is not None and any(values_equal(value, v) for v in record.values())


def _diff_record_pair(a: dict, b: dict, path: str, diffs: list[DiffEntry]) -> None:
    for key in sorted(set(a) | set(b)):
        child = f"{path}.{key}"
        in_a, in_b = key in a, key in b
        if in_a and in_b:
            _diff(a[key], b[key], child, diffs)
        elif in_a:
            # A leaf only on one side is representation-only when the same value
            # already appears elsewhere in the other record — currency carried
            # twice in JSON but once in XML, for instance.
            if not _value_appears_in(a[key], b):
                diffs.append(DiffEntry(child, _fmt(a[key]), "<missing>", "removed"))
        else:
            if not _value_appears_in(b[key], a):
                diffs.append(DiffEntry(child, "<missing>", _fmt(b[key]), "added"))


def _diff_records(rec_a: list[dict], rec_b: list[dict], diffs: list[DiffEntry]) -> None:
    """Pair records by business key, falling back to best field overlap."""
    used = [False] * len(rec_b)

    for i, a in enumerate(rec_a):
        key_a = canonical.business_key(a)
        match = -1
        if key_a is not None:
            for j, b in enumerate(rec_b):
                if not used[j] and canonical.business_key(b) == key_a:
                    match = j
                    break
        if match < 0:
            best_score = -1
            for j, b in enumerate(rec_b):
                if used[j]:
                    continue
                score = _overlap_score(a, b)
                if score > best_score:
                    best_score, match = score, j

        label = key_a if key_a is not None else i
        if match >= 0:
            used[match] = True
            _diff_record_pair(a, rec_b[match], f"$[{label}]", diffs)
        else:
            diffs.append(DiffEntry(f"$[{label}]", _fmt(a), "<missing>", "removed"))

    for j, b in enumerate(rec_b):
        if not used[j]:
            key_b = canonical.business_key(b)
            label = key_b if key_b is not None else j
            diffs.append(DiffEntry(f"$[{label}]", "<missing>", _fmt(b), "added"))


# ─── cross-format: single document ───────────────────────────────────────

def _unwrap_singleton(value: Any, other: Any) -> Any:
    """Treat a one-element list as the bare element when the other side is not
    a list, so a lone XML element lines up with a one-element JSON array."""
    if isinstance(value, list) and not isinstance(other, list) and len(value) == 1:
        return value[0]
    return value


def _pick_partner(item: Any, candidates: list, used: list[bool]) -> int:
    key = canonical.business_key(item) if isinstance(item, dict) else None
    best, best_score = -1, -1
    for j, cand in enumerate(candidates):
        if used[j]:
            continue
        if key is not None and isinstance(cand, dict) and canonical.business_key(cand) == key:
            return j
        score = _overlap_score(item, cand) if isinstance(item, dict) and isinstance(cand, dict) else 0
        if score > best_score:
            best_score, best = score, j
    return best


def _structural_diff_lists(la: list, lb: list, path: str, diffs: list[DiffEntry]) -> None:
    used = [False] * len(lb)
    unmatched: list[int] = []

    for i, item in enumerate(la):
        match = -1
        for j, cand in enumerate(lb):
            if used[j]:
                continue
            probe: list[DiffEntry] = []
            _structural_diff(item, cand, "", probe)
            if not probe:
                match = j
                break
        if match >= 0:
            used[match] = True
        else:
            unmatched.append(i)

    for i in unmatched:
        best = _pick_partner(la[i], lb, used)
        if best >= 0:
            used[best] = True
            _structural_diff(la[i], lb[best], f"{path}[{i}]", diffs)
        else:
            diffs.append(DiffEntry(f"{path}[{i}]", _fmt(la[i]), "<missing>", "removed"))

    for j, cand in enumerate(lb):
        if not used[j]:
            diffs.append(DiffEntry(f"{path}[{j}]", "<missing>", _fmt(cand), "added"))


def _structural_diff(a: Any, b: Any, path: str, diffs: list[DiffEntry]) -> None:
    """Recursive comparison for a single rich document."""
    left = _unwrap_singleton(a, b)
    right = _unwrap_singleton(b, a)

    if left is None and right is None:
        return
    if left is None:
        diffs.append(DiffEntry(path, "<missing>", _fmt(right), "added"))
        return
    if right is None:
        diffs.append(DiffEntry(path, _fmt(left), "<missing>", "removed"))
        return

    if isinstance(left, dict) and isinstance(right, dict):
        for key in sorted(set(left) | set(right)):
            child = f"{path}.{key}"
            if key in left and key in right:
                _structural_diff(left[key], right[key], child, diffs)
            elif key in left:
                diffs.append(DiffEntry(child, _fmt(left[key]), "<missing>", "removed"))
            else:
                diffs.append(DiffEntry(child, "<missing>", _fmt(right[key]), "added"))
        return

    if isinstance(left, list) and isinstance(right, list):
        _structural_diff_lists(left, right, path, diffs)
        return

    if not values_equal(left, right):
        diffs.append(DiffEntry(path, _fmt(left), _fmt(right), "value"))


# ─── ignore directives ───────────────────────────────────────────────────

def _apply_ignores(obj: Any, paths: list[str]) -> None:
    """Blank out ignored leaves before comparing.

    Only the trailing name of each path is used, which covers the recursive
    forms (``$..timestamp``, ``//*[local-name()='TraceId']``) that people
    actually write for noisy fields.
    """
    names = set()
    for p in paths:
        m = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", p)
        if m:
            names.add(canonical.fold_key(m[-1]))
    if not names:
        return

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            for k in list(node):
                if canonical.fold_key(k) in names:
                    node[k] = "<ignored>"
                else:
                    walk(node[k])
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(obj)


# ─── entry point ─────────────────────────────────────────────────────────

def compare(expected: str, actual: str, assertions: list[Assertion] | None = None) -> CompareResult:
    """Compare two payloads structurally."""
    result = CompareResult()
    assertions = assertions or []

    ignore_paths = [a.path for a in assertions if a.operator == "ignore"]

    exp_inner = extract_inner_payload(expected or "")
    act_inner = extract_inner_payload(actual or "")
    result.expected_prepared = exp_inner
    result.actual_prepared = act_inner

    fmt_a = detect_format(exp_inner)
    fmt_b = detect_format(act_inner)

    if fmt_a == "empty" and fmt_b == "empty":
        result.matched = True
        result.note = "both payloads empty"
        return result
    if fmt_a == "empty" or fmt_b == "empty":
        result.matched = False
        result.note = "one side empty"
        result.diffs.append(DiffEntry(
            "$", "<empty>" if fmt_a == "empty" else "<present>",
            "<empty>" if fmt_b == "empty" else "<present>", "value"))
        return result

    if fmt_a == "text" or fmt_b == "text":
        result.matched = exp_inner.strip() == act_inner.strip()
        result.note = "plain text comparison"
        if not result.matched:
            result.diffs.append(DiffEntry("$", exp_inner[:200], act_inner[:200], "value"))
        return result

    try:
        obj_a = parse_payload(exp_inner)
        obj_b = parse_payload(act_inner)
    except Exception as exc:
        result.matched = False
        result.parse_error = f"{type(exc).__name__}: {exc}"
        result.note = "payload could not be parsed"
        return result

    _apply_ignores(obj_a, ignore_paths)
    _apply_ignores(obj_b, ignore_paths)

    if fmt_a == fmt_b:
        _diff(obj_a, obj_b, "$", result.diffs)
        result.note = f"{fmt_a} vs {fmt_b}"
    else:
        canon_a = canonical.canonicalize(obj_a)
        canon_b = canonical.canonicalize(obj_b)
        if canonical.is_collection_payload(canon_a) or canonical.is_collection_payload(canon_b):
            _diff_records(canonical.to_records(canon_a), canonical.to_records(canon_b), result.diffs)
            result.note = f"{fmt_a} vs {fmt_b} (cross-format, records)"
        else:
            _structural_diff(canonical.drop_header_blocks(canon_a),
                             canonical.drop_header_blocks(canon_b), "$", result.diffs)
            result.note = f"{fmt_a} vs {fmt_b} (cross-format, document)"

    result.matched = not result.diffs
    return result
