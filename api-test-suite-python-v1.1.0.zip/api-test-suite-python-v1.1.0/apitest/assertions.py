"""Field-level assertions against a response.

Paths are JSONPath or XPath depending on the row's PathType. When a path matches
several sibling elements the assertion passes if any of them satisfies the
operator — the value you are checking often sits in the third repeated block
rather than the first.
"""

from __future__ import annotations

import json
import re
from decimal import Decimal, InvalidOperation
from typing import Any

from jsonpath_ng.ext import parse as jsonpath_parse
from lxml import etree

from .comparator import _RECOVERING_PARSER, _SAFE_PARSER, detect_format, extract_inner_payload
from .models import Assertion, AssertionResult, Environment

# Operators needing no ExpectedValue.
_NO_VALUE_OPERATORS = {"exists", "not_exists", "not_null", "has_children", "ignore", "db_exists"}

_ALL_OPERATORS = {
    "equals", "not_equals", "contains", "not_contains", "exists", "not_exists",
    "not_null", "greater_than", "less_than", "regex_match", "one_of",
    "has_children", "count_equals", "ignore", "db_equals", "db_contains", "db_exists",
}


def extract_all(payload: str, path: str, path_type: str = "") -> list[str]:
    """Every value matching a path, as strings. Empty list when nothing matches."""
    if not payload or not path:
        return []

    kind = (path_type or "").lower()
    if kind not in ("jsonpath", "xpath"):
        fmt = detect_format(payload)
        kind = "xpath" if fmt == "xml" else "jsonpath"

    if kind == "jsonpath":
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            return []
        try:
            matches = jsonpath_parse(path).find(data)
        except Exception:
            return []
        out: list[str] = []
        for m in matches:
            v = m.value
            if v is None:
                continue
            if isinstance(v, bool):
                out.append("true" if v else "false")
            elif isinstance(v, (dict, list)):
                out.append(json.dumps(v))
            else:
                out.append(str(v))
        return out

    text = extract_inner_payload(payload)
    text = re.sub(r"&#x[dD];|&#13;", "", text)
    data = text.encode("utf-8")
    try:
        root = etree.fromstring(data, _SAFE_PARSER)
    except etree.XMLSyntaxError:
        try:
            root = etree.fromstring(data, _RECOVERING_PARSER)
        except etree.XMLSyntaxError:
            return []
    if root is None:
        return []
    try:
        nodes = root.xpath(path)
    except etree.XPathEvalError:
        return []

    if not isinstance(nodes, list):
        return [str(nodes)]
    out = []
    for n in nodes:
        if isinstance(n, etree._Element):
            out.append("".join(n.itertext()).strip())
        else:
            out.append(str(n).strip())
    return out


def extract_first(payload: str, path: str, path_type: str = "") -> str:
    values = extract_all(payload, path, path_type)
    return values[0] if values else ""


def count_matches(payload: str, path: str, path_type: str = "") -> int:
    """How many elements a path selects.

    A JSONPath resolving to a single list counts that list's length, which is
    what people mean by count_equals on an array.
    """
    values = extract_all(payload, path, path_type)
    if len(values) == 1:
        try:
            parsed = json.loads(values[0])
            if isinstance(parsed, list):
                return len(parsed)
        except (json.JSONDecodeError, TypeError):
            pass
    return len(values)


def has_children(payload: str, path: str, path_type: str = "") -> bool:
    values = extract_all(payload, path, path_type)
    if not values:
        return False
    try:
        parsed = json.loads(values[0])
        return isinstance(parsed, (dict, list)) and len(parsed) > 0
    except (json.JSONDecodeError, TypeError):
        return bool(values[0].strip())


def _as_decimal(s: str) -> Decimal | None:
    try:
        return Decimal(str(s).strip())
    except (InvalidOperation, ValueError):
        return None


def _evaluate_one(op: str, actual: str, expected: str) -> tuple[bool, str]:
    """Apply one non-database operator. Returns (passed, failure message)."""
    if op == "equals":
        a, e = _as_decimal(actual), _as_decimal(expected)
        if a is not None and e is not None:
            return (a == e, "" if a == e else f"expected {expected}, got {actual}")
        ok = actual == expected
        return ok, "" if ok else f"expected '{expected}', got '{actual}'"

    if op == "not_equals":
        ok = actual != expected
        return ok, "" if ok else f"expected anything but '{expected}'"

    if op == "contains":
        ok = expected in actual
        return ok, "" if ok else f"'{expected}' not found in '{actual}'"

    if op == "not_contains":
        ok = expected not in actual
        return ok, "" if ok else f"'{expected}' unexpectedly present"

    if op == "exists":
        ok = bool(actual.strip())
        return ok, "" if ok else "path did not resolve to a value"

    if op == "not_exists":
        ok = not actual.strip()
        return ok, "" if ok else f"expected nothing, got '{actual}'"

    if op == "not_null":
        ok = bool(actual.strip()) and actual.strip().lower() != "null"
        return ok, "" if ok else "value was null or empty"

    if op in ("greater_than", "less_than"):
        a, e = _as_decimal(actual), _as_decimal(expected)
        if a is None or e is None:
            return False, f"not numeric: actual='{actual}' expected='{expected}'"
        ok = a > e if op == "greater_than" else a < e
        symbol = ">" if op == "greater_than" else "<"
        return ok, "" if ok else f"expected {actual} {symbol} {expected}"

    if op == "regex_match":
        try:
            ok = re.search(expected, actual) is not None
        except re.error as exc:
            return False, f"invalid regex: {exc}"
        return ok, "" if ok else f"'{actual}' does not match /{expected}/"

    if op == "one_of":
        options = [o.strip() for o in expected.split(",") if o.strip()]
        ok = actual.strip() in options
        return ok, "" if ok else f"'{actual}' is not one of {options}"

    return False, f"unknown operator '{op}'"


def _evaluate_db(a: Assertion, env: Environment | None) -> tuple[bool, str, str]:
    """Run a read-only query and check the first column.

    Only SELECT and WITH statements are allowed and stacked statements are
    rejected — a test suite has no business writing to a database.
    """
    if env is None or not env.db_url:
        return False, "", "no database configured for this environment"

    sql = a.path.strip()
    first_word = sql.split()[0].lower() if sql.split() else ""
    if first_word not in ("select", "with"):
        return False, "", f"only SELECT/WITH queries are allowed, got: {first_word}"
    if ";" in sql.rstrip(";"):
        return False, "", "stacked statements are not allowed"

    try:
        import sqlite3
    except ImportError:  # pragma: no cover
        return False, "", "no database driver available"

    # Only SQLite ships with Python. Other engines need their own driver, which
    # a restricted environment may not have, so fail with a clear message rather
    # than an import traceback.
    if not env.db_url.startswith("sqlite:"):
        return False, "", (f"driver for '{env.db_url.split(':')[0]}' is not installed; "
                           "database assertions currently support sqlite out of the box")

    path = env.db_url.split(":", 1)[1]
    try:
        conn = sqlite3.connect(path)
        try:
            cur = conn.execute(sql)
            row = cur.fetchone()
        finally:
            conn.close()
    except Exception as exc:
        return False, "", f"query failed: {exc}"

    if a.operator == "db_exists":
        ok = row is not None
        return ok, "" if row is None else str(row[0]), "" if ok else "query returned no rows"

    actual = "" if row is None else str(row[0])
    if a.operator == "db_equals":
        ok = actual == a.expected_value
        return ok, actual, "" if ok else f"expected '{a.expected_value}', got '{actual}'"
    ok = a.expected_value in actual
    return ok, actual, "" if ok else f"'{a.expected_value}' not found in '{actual}'"


def evaluate(response_body: str, assertions: list[Assertion],
             env: Environment | None = None) -> list[AssertionResult]:
    """Run every assertion, skipping ``ignore`` rows (they steer the diff)."""
    results: list[AssertionResult] = []

    for a in assertions:
        if a.operator == "ignore":
            continue

        r = AssertionResult(path=a.path, operator=a.operator,
                            expected_value=a.expected_value, description=a.description)

        if a.operator not in _ALL_OPERATORS:
            r.passed = False
            r.message = f"unknown operator '{a.operator}'"
            results.append(r)
            continue

        if a.operator.startswith("db_"):
            r.passed, r.actual_value, r.message = _evaluate_db(a, env)
            results.append(r)
            continue

        if a.operator == "count_equals":
            n = count_matches(response_body, a.path, a.path_type)
            r.actual_value = str(n)
            expected = _as_decimal(a.expected_value)
            r.passed = expected is not None and Decimal(n) == expected
            if not r.passed:
                r.message = f"expected {a.expected_value} matches, found {n}"
            results.append(r)
            continue

        if a.operator == "has_children":
            r.passed = has_children(response_body, a.path, a.path_type)
            r.actual_value = "yes" if r.passed else "no"
            if not r.passed:
                r.message = "element has no children"
            results.append(r)
            continue

        values = extract_all(response_body, a.path, a.path_type)

        if not values:
            r.actual_value = ""
            r.passed, r.message = _evaluate_one(a.operator, "", a.expected_value)
        elif len(values) == 1:
            r.actual_value = values[0]
            r.passed, r.message = _evaluate_one(a.operator, values[0], a.expected_value)
        else:
            # Several siblings matched. Pass on the first that satisfies the
            # operator; if none do, show every value that was checked so the
            # report says what the response actually held.
            first_message = ""
            for v in values:
                ok, msg = _evaluate_one(a.operator, v, a.expected_value)
                if not first_message:
                    first_message = msg
                if ok:
                    r.passed, r.actual_value, r.message = True, v, ""
                    break
            else:
                r.passed = False
                r.actual_value = " | ".join(values)
                r.message = f"{first_message} (checked {len(values)} matches)"

        results.append(r)

    return results
