"""Data carried between the loader, runner, comparator and reporter.

These are plain containers with no behaviour beyond a couple of lookups that
would otherwise be repeated at every call site.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Environment:
    """One row of the Environments sheet: a system under test."""

    name: str = ""
    protocol: str = "rest"
    base_url: str = ""
    auth_type: str = "none"
    auth_value: str = ""
    extra_headers: dict[str, str] = field(default_factory=dict)
    ssl_config: str = ""
    token_url: str = ""
    token_body: str = ""
    token_headers: dict[str, str] = field(default_factory=dict)
    db_url: str = ""
    db_user: str = ""
    db_password: str = ""
    db_driver: str = ""
    description: str = ""


@dataclass
class Step:
    """One HTTP call.

    For two-source modes the Method, Endpoint and BodyTemplate cells may each
    hold a pipe-separated ``SourceA|SourceB`` pair. The ``*_b`` fields hold the
    Source B half; empty means "same as Source A".
    """

    test_id: str = ""
    order: int = 1
    name: str = ""
    method: str = "GET"
    method_b: str = ""
    endpoint: str = ""
    endpoint_b: str = ""
    body_template: str = ""
    body_template_b: str = ""
    extract_vars: dict[str, str] = field(default_factory=dict)
    expected_status: list[int] = field(default_factory=lambda: [200, 201, 204])
    extra_headers: dict[str, str] = field(default_factory=dict)

    def method_for(self, source: str) -> str:
        if source == "B" and self.method_b:
            return self.method_b
        return self.method

    def endpoint_for(self, source: str) -> str:
        if source == "B" and self.endpoint_b:
            return self.endpoint_b
        return self.endpoint

    def body_template_for(self, source: str) -> str:
        if source == "B":
            if self.body_template_b:
                return self.body_template_b
            # A leading pipe means "nothing on A, something on B". If both
            # halves are empty neither source sends a body.
            if not self.body_template:
                return ""
        return self.body_template


@dataclass
class Assertion:
    """One row of the Assertions sheet."""

    test_id: str = ""
    path: str = ""
    path_type: str = "jsonpath"
    operator: str = "equals"
    expected_value: str = ""
    description: str = ""


@dataclass
class TestCase:
    """One row of the TestSuite sheet plus everything attached to it."""

    test_id: str = ""
    name: str = ""
    mode: str = "assert_only"
    source_a: str = ""
    source_b: str = ""
    expected_file: str = ""
    enabled: bool = True
    description: str = ""
    steps: list[Step] = field(default_factory=list)
    data: dict[str, str] = field(default_factory=dict)
    assertions: list[Assertion] = field(default_factory=list)


@dataclass
class TestSuite:
    environments: dict[str, Environment] = field(default_factory=dict)
    tests: list[TestCase] = field(default_factory=list)


@dataclass
class Response:
    """What came back from one HTTP call."""

    status: int = 0
    headers: dict[str, str] = field(default_factory=dict)
    body: str = ""
    url: str = ""
    elapsed_ms: int = 0
    error: str = ""


@dataclass
class DiffEntry:
    """One structural difference.

    ``kind`` is ``value`` (both sides present but different), ``added`` (only on
    B) or ``removed`` (only on A).
    """

    path: str
    expected: str
    actual: str
    kind: str = "value"


@dataclass
class CompareResult:
    matched: bool = False
    diffs: list[DiffEntry] = field(default_factory=list)
    note: str = ""
    expected_prepared: str = ""
    actual_prepared: str = ""
    parse_error: str = ""


@dataclass
class AssertionResult:
    path: str = ""
    operator: str = ""
    expected_value: str = ""
    actual_value: str = ""
    passed: bool = False
    message: str = ""
    description: str = ""


@dataclass
class StepResult:
    order: int = 0
    name: str = ""
    method: str = ""
    url: str = ""
    request_body: str = ""
    request_headers: dict[str, str] = field(default_factory=dict)
    response_body: str = ""
    status: int = 0
    expected_status: list[int] = field(default_factory=list)
    elapsed_ms: int = 0
    passed: bool = False
    error: str = ""
    error_detail: str = ""


@dataclass
class TestResult:
    test_id: str = ""
    name: str = ""
    mode: str = ""
    source_a: str = ""
    source_b: str = ""
    status: str = "PASS"
    steps_a: list[StepResult] = field(default_factory=list)
    steps_b: list[StepResult] = field(default_factory=list)
    comparison: CompareResult | None = None
    assertions: list[AssertionResult] = field(default_factory=list)
    error: str = ""
    error_detail: str = ""
    elapsed_ms: int = 0
    description: str = ""


@dataclass
class RunConfig:
    """Resolved paths for one execution."""

    suite_file: Any = None
    report_dir: Any = None
    templates_dir: Any = None
    expected_dir: Any = None
    certs_dir: Any = None
    project_root: Any = None
