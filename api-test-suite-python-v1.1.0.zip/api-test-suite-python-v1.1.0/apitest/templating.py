"""Placeholder substitution for endpoints, request bodies and headers.

Supported tokens:

  ${column_name}   a value from the test's TestData row
  ${stepN.field}   a value extracted by an earlier step of the same test
  ${env.NAME}      an environment variable
  ${now}           current timestamp
  ${uuid}          a fresh random id

A placeholder may end with a whole-number offset, e.g. ${stepN.field + 1} or
${seq - 2}, for passing an incremented value from one step to the next. Spaces
around the operator are required, which keeps a hyphenated name from being read
as subtraction.

XML templates get a second pass that prunes elements left empty after
substitution, so optional fields do not appear in the request when no value was
supplied.
"""

from __future__ import annotations

import os
import re
import uuid as _uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from lxml import etree

_TOKEN = re.compile(r"\$\{([^}]+)\}")


class RenderLog:
    """Records what each placeholder resolved to, for the report's diagnostics."""

    def __init__(self) -> None:
        self.entries: list[str] = []

    def note(self, token: str, value: str | None) -> None:
        shown = "<unresolved>" if value is None else (value if len(value) <= 60 else value[:60] + "…")
        self.entries.append(f"  ${{{token}}} -> {shown}")

    def summary(self) -> str:
        return "Render log:\n" + "\n".join(self.entries) if self.entries else ""


# A placeholder may carry a trailing whole-number offset, e.g.
# ${step1.orderId + 1}. Whitespace around the operator is required, so an
# ordinary column named "order-2024" is not mistaken for "order" minus 2024.
_OFFSET = re.compile(r"^(.*\S)\s+([+-])\s+(\d+)$")


def _apply_offset(value: str, delta: int, name: str) -> str:
    """Add a whole-number offset to a resolved value.

    Kept deliberately narrow — whole numbers only — for the common case of
    taking a number out of one response and sending the next value on. Python's
    ints are arbitrary precision, so large ids increment exactly.
    """
    try:
        return str(int(str(value).strip()) + delta)
    except ValueError:
        raise ValueError(f"Cannot apply offset to placeholder '{name}': "
                         f"value '{value}' is not a whole number.")


def _resolve(token: str, data: dict[str, str], step_vars: dict[str, str]) -> str | None:
    token = token.strip()

    # Peel off a trailing offset first, then resolve the base token exactly as
    # it always has; the offset is applied to whatever comes back.
    delta = 0
    offset = _OFFSET.match(token)
    if offset:
        token = offset.group(1).strip()
        delta = int(offset.group(3))
        if offset.group(2) == "-":
            delta = -delta

    if token == "now":
        value = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    elif token == "uuid":
        value = str(_uuid.uuid4())
    elif token.startswith("env."):
        value = os.environ.get(token[4:])
    elif re.fullmatch(r"step\d+\..+", token):
        value = step_vars.get(token)
    else:
        value = data.get(token)

    if offset and value is not None and value != "":
        return _apply_offset(value, delta, token)
    return value


def render(text: str, data: dict[str, str] | None = None,
           step_vars: dict[str, str] | None = None,
           log: RenderLog | None = None) -> str:
    """Substitute every ${...} token. Unresolved tokens are left in place."""
    if not text:
        return ""
    data = data or {}
    step_vars = step_vars or {}

    def sub(m: re.Match) -> str:
        token = m.group(1)
        value = _resolve(token, data, step_vars)
        if log is not None:
            log.note(token, value)
        return m.group(0) if value is None else str(value)

    result = _TOKEN.sub(sub, text)

    if result.lstrip().startswith("<") and _TOKEN.search(result):
        result = prune_empty_elements(result)
    return result


def prune_empty_elements(xml_text: str) -> str:
    """Drop elements whose content is an unresolved placeholder or empty.

    Falls back to the original text when the document cannot be parsed — a
    half-pruned request is worse than an unpruned one.
    """
    try:
        parser = etree.XMLParser(resolve_entities=False, no_network=True,
                                 load_dtd=False, remove_blank_text=False)
        root = etree.fromstring(xml_text.encode("utf-8"), parser)
    except etree.XMLSyntaxError:
        return xml_text

    def prune(el: etree._Element) -> bool:
        """Return True when the element should be removed."""
        for child in list(el):
            if prune(child):
                el.remove(child)
        if len(el):
            return False
        text = (el.text or "").strip()
        if not text:
            return True
        return bool(_TOKEN.fullmatch(text))

    for child in list(root):
        if prune(child):
            root.remove(child)

    return etree.tostring(root, encoding="unicode")


def resolve_contained(base: Path | None, relative: str) -> Path | None:
    """Resolve a path under ``base``, refusing anything that escapes it.

    Workbooks get passed between teams. One that quietly reads a file from
    elsewhere on the machine — and prints it into the report — is not something
    to allow.
    """
    if base is None:
        return None
    candidate = (base / relative).resolve()
    try:
        candidate.relative_to(base.resolve())
    except ValueError:
        return None
    return candidate if candidate.exists() else None


def resolve_template_path(template_path: str, templates_dir: Path | None,
                          project_root: Path | None) -> Path:
    """Find a template file. Absolute paths are honoured for shared drives."""
    p = Path(template_path)
    if p.is_absolute():
        if p.exists():
            return p
        raise FileNotFoundError(f"Template file not found: {p}")

    for base in (templates_dir, project_root):
        found = resolve_contained(base, template_path)
        if found is not None:
            return found

    tried = "\n    ".join(str((b / template_path)) for b in (templates_dir, project_root) if b)
    raise FileNotFoundError(f"Template file not found: {template_path}\n  Tried:\n    {tried}")


def render_file(template_path: str, data: dict[str, str] | None,
                step_vars: dict[str, str] | None, templates_dir: Path | None,
                project_root: Path | None, log: RenderLog | None = None) -> str:
    path = resolve_template_path(template_path, templates_dir, project_root)
    return render(path.read_text(encoding="utf-8"), data, step_vars, log)
