"""Makes two responses of different formats comparable.

The same business data can come back as JSON from one system and XML/SOAP from
another, with different key casing, different nesting, attributes instead of
fields, extra transport wrappers and different number formats. A plain tree diff
reports all of that as differences even though the data is identical.

This module canonicalises a parsed tree so both sides collapse to the same
shape, and decides which comparison strategy the payload needs. It does not
decide equality — that is the comparator's job.
"""

from __future__ import annotations

import unicodedata
from decimal import Decimal, InvalidOperation
from typing import Any

# Element names that carry no business meaning and get peeled off the top.
WRAPPER_KEYS = {
    "envelope", "body", "return", "executeresponse",
    "any", "content", "result", "response", "payload",
}

# Suffixes marking an element as a response wrapper, e.g. FooResponse.
WRAPPER_SUFFIXES = ("response", "overviewresponse", "responsemessage", "reply")

# Envelope-level transport keys. These sit as siblings of the real payload
# inside a routing envelope:
#
#   <Envelope>
#     <Version>..</Version>      <- transport
#     <Sender>..</Sender>        <- transport
#     <Receiver>..</Receiver>    <- transport
#     <Content>..business..</Content>
#   </Envelope>
#
# Recognising them lets the peeler see that Content is the one real child and
# descend into it, instead of stopping because the map has four entries.
METADATA_KEYS = {"header", "status", "sender", "receiver", "version"}

# Only a Header block is unambiguously SOAP metadata. "status" and "version"
# are ordinary business field names too, so they are never stripped from inside
# a record.
HEADER_KEYS = {"header"}

# Leaf names that identify a business record, tried in order.
BUSINESS_KEY_CANDIDATES = ("id", "accountid", "key", "number", "iban")

_MAX_DESCENT = 20


def fold_key(key: str) -> str:
    """Reduce a key to a canonical token for matching.

    Drops any namespace prefix and the ``@`` attribute marker, lowercases, and
    removes separators. ``current_balance``, ``currentBalance``,
    ``CurrentBalance`` and ``@currentBalance`` all fold to ``currentbalance``.
    """
    if key is None:
        return ""
    k = str(key)
    if ":" in k:
        k = k.split(":", 1)[1]
    if k.startswith("@"):
        k = k[1:]
    return "".join(c.lower() for c in k if c not in "_-. ")


def _is_wrapper_key(folded: str) -> bool:
    if folded in WRAPPER_KEYS:
        return True
    return any(folded.endswith(s) and len(folded) > len(s) for s in WRAPPER_SUFFIXES)


def as_iso_date(s: str) -> str | None:
    """Recognise ``yyyy-MM-dd`` or ``yyyyMMdd`` and return the compact digits.

    Month and day are validated, so an ordinary 8-digit number such as 12345678
    (month 56) and a hyphenated code that isn't a date are left alone.
    """
    if len(s) == 10 and s[4] == "-" and s[7] == "-":
        digits = s[:4] + s[5:7] + s[8:10]
    elif len(s) == 8:
        digits = s
    else:
        return None
    if not digits.isdigit():
        return None
    year, month, day = int(digits[:4]), int(digits[4:6]), int(digits[6:8])
    if not (1000 <= year <= 9999):
        return None
    if not (1 <= month <= 12):
        return None
    if not (1 <= day <= 31):
        return None
    return digits


def _looks_numeric(s: str) -> bool:
    try:
        Decimal(s)
        return True
    except (InvalidOperation, ValueError):
        return False


def _strip_trailing_zeros(d: Decimal) -> Decimal:
    """Normalise scale so 0.15 and 0.15000 compare equal."""
    normalised = d.normalize()
    # normalize() turns 100 into 1E+2; expand it back for readable output.
    sign, digits, exponent = normalised.as_tuple()
    if isinstance(exponent, int) and exponent > 0:
        return normalised.quantize(Decimal(1))
    return normalised


def normalize_scalar(v: Any) -> Any:
    """Normalise a leaf so equal-but-differently-written values match."""
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float, Decimal)):
        return _strip_trailing_zeros(Decimal(str(v)))

    s = str(v).strip()
    if not s:
        return ""
    low = s.lower()
    if low == "true":
        return True
    if low == "false":
        return False

    # Dates before numbers: a compact date is all digits, and turning it into a
    # Decimal here would stop it matching the hyphenated form on the other side.
    iso = as_iso_date(s)
    if iso is not None:
        return iso

    if _looks_numeric(s):
        try:
            return _strip_trailing_zeros(Decimal(s))
        except (InvalidOperation, ValueError):
            pass

    return unicodedata.normalize("NFC", s)


def _strip_wrappers(node: Any) -> Any:
    """Peel envelope/body/return/*Response layers off the top of the tree."""
    guard = 0
    while isinstance(node, dict) and guard < _MAX_DESCENT:
        guard += 1
        if not node:
            break

        business_key = None
        business_value = None
        business_count = 0
        for k, v in node.items():
            if fold_key(k) in METADATA_KEYS:
                continue
            business_count += 1
            if business_count > 1:
                break
            business_key = fold_key(k)
            business_value = v

        # More than one real child means this is the content, not a wrapper.
        if business_count != 1 or business_key is None:
            break

        if _is_wrapper_key(business_key):
            node = business_value
        else:
            break
    return node


def _normalize(node: Any) -> Any:
    """Rebuild the tree with folded keys and normalised leaves."""
    if isinstance(node, dict):
        out: dict[str, Any] = {}
        for k, v in node.items():
            key = fold_key(k)
            value = _normalize(v)
            # Two source keys can fold to the same token (an attribute and an
            # element of the same name). Keep the first non-null.
            if key in out and out[key] is not None:
                continue
            out[key] = value
        return out
    if isinstance(node, list):
        return [_normalize(x) for x in node]
    return normalize_scalar(node)


def canonicalize(tree: Any) -> Any:
    """Canonicalise a parsed tree. The input is not modified."""
    return _normalize(_strip_wrappers(tree))


def _descend_to_business_content(node: Any) -> Any:
    """Skip metadata and single-child wrappers to reach the actual content."""
    guard = 0
    while isinstance(node, dict) and guard < _MAX_DESCENT:
        guard += 1
        sole_value = None
        business_count = 0
        for k, v in node.items():
            if k in METADATA_KEYS:
                continue
            business_count += 1
            if business_count > 1:
                break
            sole_value = v
        if business_count != 1:
            break
        if isinstance(sole_value, (dict, list)):
            node = sole_value
        else:
            break
    return node


def is_collection_payload(canonical_tree: Any) -> bool:
    """True when the payload is a repeated list of business records.

    This picks the comparison strategy. Reducing every payload to its largest
    inner list is right for a list of accounts but destructive for a single rich
    document: the largest object-list there might be a handful of trivial flags,
    and collapsing onto those silently discards the rest of the tree.
    """
    node = _descend_to_business_content(canonical_tree)
    if isinstance(node, list):
        return bool(node) and all(isinstance(x, dict) for x in node)
    return False


def _strip_header_only(node: Any) -> Any:
    """Drop Header blocks, which are unambiguously transport metadata."""
    if isinstance(node, dict):
        return {k: _strip_header_only(v) for k, v in node.items() if k not in HEADER_KEYS}
    if isinstance(node, list):
        return [_strip_header_only(x) for x in node]
    return node


def drop_header_blocks(canonical_tree: Any) -> Any:
    """Remove Header blocks for the single-document comparison path."""
    return _strip_header_only(canonical_tree)


def _find_entity_list(node: Any) -> list | None:
    """Return the largest list of objects anywhere in the tree.

    Searching rather than following a fixed path means the entity collection is
    still found when transport metadata sits beside it.
    """
    best: list | None = None
    stack = [node]
    while stack:
        cur = stack.pop()
        if isinstance(cur, list):
            if cur and all(isinstance(x, dict) for x in cur):
                if best is None or len(cur) > len(best):
                    best = cur
            stack.extend(cur)
        elif isinstance(cur, dict):
            stack.extend(cur.values())
    return best


def _put_disambiguated(out: dict, leaf: str, parent_key: str, value: Any) -> None:
    """Store a leaf, qualifying it with its parent when the name is taken."""
    if leaf not in out:
        out[leaf] = value
        return
    qualified = f"{parent_key}.{leaf}" if parent_key else leaf
    out.setdefault(qualified, value)


def _flatten_into(node: dict, parent_key: str, out: dict) -> None:
    for k, v in node.items():
        if isinstance(v, dict):
            _flatten_into(v, k, out)
        else:
            _put_disambiguated(out, k, parent_key, v)


def flatten(node: Any) -> dict[str, Any]:
    """Flatten one entity to ``{leaf_name: value}``.

    This bridges the nesting gap that key folding cannot: JSON's
    ``currentBalance.amount`` and XML's ``Balance/Amount`` both land on the leaf
    ``amount``. A leaf keeps enough of its parent path to stay unique, so an
    account ``id`` and a ``salesProduct.id`` do not collide.
    """
    out: dict[str, Any] = {}
    if isinstance(node, dict):
        _flatten_into(node, "", out)
    return out


def to_records(canonical_tree: Any) -> list[dict[str, Any]]:
    """Reduce a canonical tree to a list of flat business records."""
    entity_list = _find_entity_list(canonical_tree)
    if entity_list is not None:
        # Everything outside the list — envelope, Header, Status, Sender — is
        # excluded simply by taking only the list items.
        return [flatten(_strip_header_only(item)) for item in entity_list]

    cleaned = _strip_header_only(canonical_tree)
    return [flatten(cleaned)] if isinstance(cleaned, dict) else []


def business_key(record: dict[str, Any]) -> Any:
    """An identifier for pairing records across the two sides, or None."""
    for candidate in BUSINESS_KEY_CANDIDATES:
        v = record.get(candidate)
        if v is not None:
            return v
    return None
