"""Runs each test end to end and records what happened.

Any failure inside a test — a missing template, an unreachable host, a bad path
— is captured as a failed test rather than allowed to abort the run.
"""

from __future__ import annotations

import time
import traceback
from pathlib import Path

from . import assertions as assertion_engine
from . import comparator, dispatcher, templating
from .models import (Environment, RunConfig, Step, StepResult, TestCase,
                     TestResult, TestSuite)


def _format_exception(exc: BaseException) -> str:
    return "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))


def _resolve_expected_file(name: str, cfg: RunConfig) -> Path | None:
    """Find a baseline file, refusing paths that escape their directory."""
    if not name:
        return None
    p = Path(name)
    if p.is_absolute():
        return p if p.exists() else None
    for base in (cfg.expected_dir, cfg.project_root):
        found = templating.resolve_contained(base, name) if base else None
        if found is not None:
            return found
    return None


def _fetch_token(env: Environment, data: dict, step_vars: dict) -> tuple[str, str]:
    """Fetch a bearer token before the first step. Returns (token, error)."""
    if not env.token_url:
        return "", ""
    body = templating.render(env.token_body, data, step_vars)
    url = templating.render(env.token_url, data, step_vars)
    print(f"    Fetching token from {url}")
    resp = dispatcher.send("rest", "", url, "POST", body, dict(env.token_headers),
                           "none", "", env.ssl_config)
    if resp.error:
        return "", resp.error
    if resp.status >= 400:
        return "", f"token endpoint returned {resp.status}"

    token = ""
    for field in ("access_token", "token", "id_token"):
        found = assertion_engine.extract_first(resp.body, f"$.{field}", "jsonpath")
        if found:
            token = found
            break
    if not token:
        token = assertion_engine.extract_first(resp.body, "//access_token", "xpath")
    if token:
        print(f"    Token acquired ({len(token)} chars)")
        return token, ""
    return "", "no token field found in the response"


def execute_steps(steps: list[Step], env: Environment, source: str,
                  data: dict[str, str], cfg: RunConfig) -> list[StepResult]:
    """Run every step for one source against one environment."""
    results: list[StepResult] = []
    step_vars: dict[str, str] = {}

    env_headers = dict(env.extra_headers)
    if env.token_url:
        token, error = _fetch_token(env, data, step_vars)
        if error:
            sr = StepResult(order=0, name="Fetch auth token", method="POST",
                            url=env.token_url, passed=False,
                            error=f"Token fetch failed: {error}")
            results.append(sr)
            return results
        env_headers["Authorization"] = f"Bearer {token}"

    for step in steps:
        method = step.method_for(source)
        raw_endpoint = step.endpoint_for(source)
        template = step.body_template_for(source)

        log = templating.RenderLog()
        body = ""
        try:
            endpoint = templating.render(raw_endpoint, data, step_vars, log)
            # A body is sent when a template is configured for this source, not
            # because of the HTTP verb: some gateways want an envelope on GET.
            if template:
                body = templating.render_file(template, data, step_vars,
                                              cfg.templates_dir, cfg.project_root, log)
        except Exception as exc:
            results.append(StepResult(
                order=step.order, name=step.name, method=method, url=raw_endpoint,
                request_body=body, expected_status=step.expected_status, passed=False,
                error=f"Template error: {type(exc).__name__}: {exc}",
                error_detail=_format_exception(exc) + "\n\n" + log.summary()))
            continue

        headers = {k: templating.render(v, data, step_vars) for k, v in env_headers.items()}
        headers.update({k: templating.render(v, data, step_vars)
                        for k, v in step.extra_headers.items()})

        try:
            resp = dispatcher.send(env.protocol, env.base_url, endpoint, method, body,
                                   headers, env.auth_type, env.auth_value, env.ssl_config)
        except Exception as exc:
            results.append(StepResult(
                order=step.order, name=step.name, method=method, url=endpoint,
                request_body=body, expected_status=step.expected_status, passed=False,
                error=f"Dispatch error: {type(exc).__name__}: {exc}",
                error_detail=_format_exception(exc)))
            continue

        sr = StepResult(
            order=step.order, name=step.name, method=method, url=resp.url or endpoint,
            request_body=body, request_headers=headers, response_body=resp.body,
            status=resp.status, expected_status=step.expected_status,
            elapsed_ms=resp.elapsed_ms)

        if resp.error:
            sr.passed = False
            sr.error = resp.error
        else:
            sr.passed = resp.status in step.expected_status
            if not sr.passed:
                sr.error = (f"Expected status {step.expected_status}, got {resp.status}")

        for name, path in step.extract_vars.items():
            value = assertion_engine.extract_first(resp.body, path)
            step_vars[f"step{step.order}.{name}"] = value

        results.append(sr)

        if not sr.passed:
            break  # a failed step makes the rest of the chain meaningless

    return results


def run_test(tc: TestCase, suite: TestSuite, cfg: RunConfig) -> TestResult:
    """Run one test case and decide its outcome."""
    started = time.monotonic()
    result = TestResult(test_id=tc.test_id, name=tc.name, mode=tc.mode,
                        source_a=tc.source_a, source_b=tc.source_b,
                        description=tc.description)

    env_a = suite.environments.get(tc.source_a)
    if env_a is None:
        result.status = "ERROR"
        result.error = f"Environment '{tc.source_a}' is not defined in the Environments sheet"
        return result

    try:
        result.steps_a = execute_steps(tc.steps, env_a, "A", tc.data, cfg)

        needs_b = tc.mode in ("vs_env", "vs_protocol")
        if needs_b:
            env_b = suite.environments.get(tc.source_b)
            if env_b is None:
                result.status = "ERROR"
                result.error = f"Environment '{tc.source_b}' is not defined in the Environments sheet"
                return result
            result.steps_b = execute_steps(tc.steps, env_b, "B", tc.data, cfg)

        last_a = result.steps_a[-1].response_body if result.steps_a else ""

        if tc.mode == "vs_expected":
            path = _resolve_expected_file(tc.expected_file, cfg)
            if path is None:
                result.status = "ERROR"
                result.error = f"Expected file not found: {tc.expected_file}"
            else:
                result.comparison = comparator.compare(
                    path.read_text(encoding="utf-8"), last_a, tc.assertions)
        elif needs_b:
            last_b = result.steps_b[-1].response_body if result.steps_b else ""
            result.comparison = comparator.compare(last_a, last_b, tc.assertions)

        if tc.mode != "chain" and tc.assertions:
            result.assertions = assertion_engine.evaluate(last_a, tc.assertions, env_a)

    except Exception as exc:
        result.status = "ERROR"
        result.error = f"{type(exc).__name__}: {exc}"
        result.error_detail = _format_exception(exc)
        return result
    finally:
        result.elapsed_ms = int((time.monotonic() - started) * 1000)

    if result.status not in ("ERROR", "FAIL"):
        steps_ok = all(s.passed for s in result.steps_a) and all(s.passed for s in result.steps_b)
        compare_ok = result.comparison.matched if result.comparison else True
        asserts_ok = all(a.passed for a in result.assertions)
        result.status = "PASS" if (steps_ok and compare_ok and asserts_ok) else "FAIL"

    return result


def run_suite(suite: TestSuite, cfg: RunConfig) -> list[TestResult]:
    results: list[TestResult] = []
    for tc in suite.tests:
        print(f"  {tc.test_id}  {tc.name}")
        r = run_test(tc, suite, cfg)
        icon = {"PASS": "ok", "FAIL": "FAILED", "ERROR": "ERROR"}.get(r.status, r.status)
        print(f"    -> {icon} ({r.elapsed_ms} ms)")
        results.append(r)
    return results
