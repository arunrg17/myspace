"""Reads the workbook into the in-memory model.

Columns are looked up by header name, so column order does not matter and extra
columns are ignored.
"""

from __future__ import annotations

from pathlib import Path

from openpyxl import load_workbook

from .models import Assertion, Environment, Step, TestCase, TestSuite

REQUIRED_SHEETS = ("Environments", "TestSuite", "Steps")


class WorkbookError(Exception):
    """The workbook is missing something the run needs."""


def split_source_pair(raw: str) -> tuple[str, str]:
    """Split a cell into (Source A, Source B) on the first pipe.

    No pipe means Source B is empty, i.e. "same as Source A".
    """
    if raw is None:
        return "", ""
    text = str(raw)
    if "|" not in text:
        return text.strip(), ""
    a, b = text.split("|", 1)
    return a.strip(), b.strip()


def _cell_text(value) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _headers(sheet) -> dict[str, int]:
    out: dict[str, int] = {}
    for idx, cell in enumerate(next(sheet.iter_rows(min_row=1, max_row=1))):
        name = _cell_text(cell.value)
        if name:
            out[name] = idx
    return out


def _get(row, cols: dict[str, int], name: str, default: str = "") -> str:
    idx = cols.get(name)
    if idx is None or idx >= len(row):
        return default
    return _cell_text(row[idx].value) or default


def _parse_headers(raw: str) -> dict[str, str]:
    """Parse headers written one per line or separated by semicolons."""
    out: dict[str, str] = {}
    if not raw:
        return out
    parts = raw.replace(";", "\n").splitlines()
    for part in parts:
        part = part.strip()
        if ":" in part:
            k, v = part.split(":", 1)
            out[k.strip()] = v.strip()
    return out


def _parse_extract_vars(raw: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for part in (raw or "").split(","):
        part = part.strip()
        if "=" in part:
            k, v = part.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def _parse_status(raw: str) -> list[int]:
    codes: list[int] = []
    for part in (raw or "").split(","):
        part = part.strip()
        if part.isdigit():
            codes.append(int(part))
    return codes or [200, 201, 204]


def load(path: str | Path) -> TestSuite:
    """Read the workbook and return the populated suite."""
    path = Path(path)
    if not path.exists():
        raise WorkbookError(f"Workbook not found: {path}")

    wb = load_workbook(path, data_only=True, read_only=True)
    try:
        missing = [s for s in REQUIRED_SHEETS if s not in wb.sheetnames]
        if missing:
            raise WorkbookError(
                f"Workbook is missing required sheet(s): {', '.join(missing)}. "
                f"Found: {', '.join(wb.sheetnames)}")

        suite = TestSuite()
        _load_environments(wb, suite)
        by_id = _load_tests(wb, suite)
        _load_steps(wb, by_id)
        _load_test_data(wb, by_id)
        _load_assertions(wb, by_id, suite)

        for tc in suite.tests:
            tc.steps.sort(key=lambda s: s.order)
        return suite
    finally:
        wb.close()


def _load_environments(wb, suite: TestSuite) -> None:
    sheet = wb["Environments"]
    cols = _headers(sheet)
    for row in sheet.iter_rows(min_row=2):
        name = _get(row, cols, "EnvName")
        if not name:
            continue
        suite.environments[name] = Environment(
            name=name,
            protocol=_get(row, cols, "Protocol", "rest").lower(),
            base_url=_get(row, cols, "BaseURL"),
            auth_type=_get(row, cols, "AuthType", "none").lower(),
            auth_value=_get(row, cols, "AuthValue"),
            extra_headers=_parse_headers(_get(row, cols, "ExtraHeaders")),
            ssl_config=_get(row, cols, "SslConfig"),
            token_url=_get(row, cols, "TokenURL"),
            token_body=_get(row, cols, "TokenBody"),
            token_headers=_parse_headers(_get(row, cols, "TokenHeaders")),
            db_url=_get(row, cols, "DbURL"),
            db_user=_get(row, cols, "DbUser"),
            db_password=_get(row, cols, "DbPassword"),
            db_driver=_get(row, cols, "DbDriver"),
            description=_get(row, cols, "Description"),
        )


def _load_tests(wb, suite: TestSuite) -> dict[str, TestCase]:
    sheet = wb["TestSuite"]
    cols = _headers(sheet)
    by_id: dict[str, TestCase] = {}
    for row in sheet.iter_rows(min_row=2):
        tid = _get(row, cols, "TestID")
        if not tid:
            continue
        enabled = _get(row, cols, "Enabled", "Y").upper() != "N"
        if not enabled:
            continue
        tc = TestCase(
            test_id=tid,
            name=_get(row, cols, "TestName", tid),
            mode=_get(row, cols, "ComparisonMode", "assert_only").lower(),
            source_a=_get(row, cols, "SourceA"),
            source_b=_get(row, cols, "SourceB"),
            expected_file=_get(row, cols, "ExpectedFile"),
            enabled=True,
            description=_get(row, cols, "Description"),
        )
        suite.tests.append(tc)
        by_id[tid] = tc
    return by_id


def _load_steps(wb, by_id: dict[str, TestCase]) -> None:
    sheet = wb["Steps"]
    cols = _headers(sheet)
    for row in sheet.iter_rows(min_row=2):
        tid = _get(row, cols, "TestID")
        tc = by_id.get(tid)
        if tc is None:
            continue

        # Method, Endpoint and BodyTemplate each accept "SourceA|SourceB".
        method_a, method_b = split_source_pair(_get(row, cols, "Method", "GET").upper())
        endpoint_a, endpoint_b = split_source_pair(_get(row, cols, "Endpoint"))
        template_a, template_b = split_source_pair(_get(row, cols, "BodyTemplate"))

        order_text = _get(row, cols, "StepOrder", "1")
        order = int(float(order_text)) if order_text.replace(".", "").isdigit() else 1

        tc.steps.append(Step(
            test_id=tid,
            order=order,
            name=_get(row, cols, "StepName", f"Step {order}"),
            method=method_a or "GET",
            method_b=method_b,
            endpoint=endpoint_a,
            endpoint_b=endpoint_b,
            body_template=template_a,
            body_template_b=template_b,
            extract_vars=_parse_extract_vars(_get(row, cols, "ExtractVars")),
            expected_status=_parse_status(_get(row, cols, "ExpectedStatus")),
            extra_headers=_parse_headers(_get(row, cols, "ExtraHeaders")),
        ))


def _load_test_data(wb, by_id: dict[str, TestCase]) -> None:
    if "TestData" not in wb.sheetnames:
        return
    sheet = wb["TestData"]
    cols = _headers(sheet)
    for row in sheet.iter_rows(min_row=2):
        tid = _get(row, cols, "TestID")
        tc = by_id.get(tid)
        if tc is None:
            continue
        for name, idx in cols.items():
            if name == "TestID":
                continue
            value = _cell_text(row[idx].value) if idx < len(row) else ""
            if value:
                tc.data[name] = value


def _load_assertions(wb, by_id: dict[str, TestCase], suite: TestSuite) -> None:
    if "Assertions" not in wb.sheetnames:
        return
    sheet = wb["Assertions"]
    cols = _headers(sheet)
    for row in sheet.iter_rows(min_row=2):
        tid = _get(row, cols, "TestID")
        path = _get(row, cols, "Path")
        if not tid or not path:
            continue
        assertion = Assertion(
            test_id=tid,
            path=path,
            path_type=_get(row, cols, "PathType", "jsonpath").lower(),
            operator=_get(row, cols, "Operator", "equals").lower(),
            expected_value=_get(row, cols, "ExpectedValue"),
            description=_get(row, cols, "Description"),
        )
        # A TestID of * applies the rule to every test.
        targets = suite.tests if tid == "*" else ([by_id[tid]] if tid in by_id else [])
        for tc in targets:
            tc.assertions.append(assertion)
