"""Request dispatch over a real socket, and report generation."""

import json
import re
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from apitest import reporter
from apitest.dispatcher import compose_url, resolve_auth, resolve_secret, send
from apitest.models import (AssertionResult, CompareResult, DiffEntry, StepResult,
                            TestResult)


class _Capture(BaseHTTPRequestHandler):
    """Records the method and body it received, then replies."""

    received: dict = {}

    def log_message(self, *args):
        pass

    def _handle(self):
        length = int(self.headers.get("Content-Length", 0))
        _Capture.received = {
            "method": self.command,
            "path": self.path,
            "body": self.rfile.read(length).decode() if length else "",
            "headers": dict(self.headers),
        }
        payload = b'{"ok":true}'
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    do_GET = do_POST = do_PUT = do_DELETE = _handle


@pytest.fixture
def server():
    srv = HTTPServer(("127.0.0.1", 0), _Capture)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_port}"
    srv.shutdown()


class TestDispatch:
    def test_get_without_body_sends_nothing(self, server):
        send("rest", server, "/x", "GET", "", {}, "none", "")
        assert _Capture.received["method"] == "GET"
        assert _Capture.received["body"] == ""

    def test_post_sends_body(self, server):
        send("rest", server, "/x", "POST", '{"a":1}', {}, "none", "")
        assert _Capture.received["method"] == "POST"
        assert '"a":1' in _Capture.received["body"]

    def test_soap_over_get_keeps_get_and_sends_body(self, server):
        # Some gateways are invoked over GET and still expect the envelope.
        send("soap", server, "/x", "GET", "<Envelope/>", {}, "none", "")
        assert _Capture.received["method"] == "GET"
        assert "<Envelope/>" in _Capture.received["body"]

    def test_soap_without_method_defaults_to_post(self, server):
        send("soap", server, "/x", "", "<Envelope/>", {}, "none", "")
        assert _Capture.received["method"] == "POST"

    def test_soap_sets_content_type_and_action(self, server):
        send("soap", server, "/x", "POST", "<E/>", {}, "none", "")
        headers = _Capture.received["headers"]
        assert "text/xml" in headers.get("Content-Type", "")
        assert "SOAPAction" in headers

    def test_user_header_wins_over_protocol_default(self, server):
        send("soap", server, "/x", "POST", "<E/>",
             {"Content-Type": "application/soap+xml"}, "none", "")
        assert _Capture.received["headers"]["Content-Type"] == "application/soap+xml"

    def test_unreachable_host_returns_error_not_exception(self):
        resp = send("rest", "http://127.0.0.1:1", "/x", "GET", "", {}, "none", "")
        assert resp.error and resp.status == 0


class TestAuthAndSecrets:
    def test_basic_is_base64(self):
        assert resolve_auth("basic", "user:pass")["Authorization"].startswith("Basic ")

    def test_bearer_prefix_added_once(self):
        assert resolve_auth("bearer", "abc")["Authorization"] == "Bearer abc"
        assert resolve_auth("bearer", "Bearer abc")["Authorization"] == "Bearer abc"

    def test_apikey_header(self):
        assert resolve_auth("apikey", "k")["x-api-key"] == "k"

    def test_none_yields_no_header(self):
        assert resolve_auth("none", "") == {}

    def test_env_secret_resolved(self, monkeypatch):
        monkeypatch.setenv("SECRET_TOKEN", "s3cret")
        assert resolve_secret("${env.SECRET_TOKEN}") == "s3cret"

    def test_file_secret_resolved(self, tmp_path):
        f = tmp_path / "secrets.properties"
        f.write_text("# comment\nkey_one=value_one\n")
        assert resolve_secret("${file.%s:key_one}" % f) == "value_one"

    def test_missing_secret_is_empty_not_literal(self):
        assert resolve_secret("${env.DEFINITELY_NOT_SET_12345}") == ""


class TestUrlComposition:
    @pytest.mark.parametrize("base,endpoint,expected", [
        ("http://h", "/a", "http://h/a"),
        ("http://h/", "/a", "http://h/a"),
        ("http://h", "a", "http://h/a"),
        ("http://h", "http://other/a", "http://other/a"),
    ])
    def test_compose(self, base, endpoint, expected):
        assert compose_url(base, endpoint) == expected


class TestReport:
    @staticmethod
    def _results():
        passing = TestResult(test_id="T1", name="Passing", mode="assert_only", status="PASS")
        passing.steps_a = [StepResult(order=1, name="Call", method="GET",
                                      url="http://h/a", status=200, passed=True,
                                      response_body='{"ok":true}',
                                      request_headers={"Authorization": "Bearer secret-token"})]
        passing.assertions = [AssertionResult(path="$.ok", operator="equals",
                                              expected_value="true", actual_value="true",
                                              passed=True)]
        failing = TestResult(test_id="T2", name="Failing", mode="vs_protocol", status="FAIL")
        failing.comparison = CompareResult(
            matched=False, note="json vs xml (cross-format, records)",
            diffs=[DiffEntry("$[A1].amount", "100", "200", "value"),
                   DiffEntry("$[A1].extra", "x", "<missing>", "removed")])
        return [passing, failing]

    def test_report_is_written(self, tmp_path):
        out = reporter.render_report(self._results(), tmp_path / "r.html", "suite.xlsx")
        assert out.exists() and out.stat().st_size > 1000

    def test_report_is_self_contained(self, tmp_path):
        html = reporter.render_report(self._results(), tmp_path / "r.html").read_text()
        # Nothing may be fetched from the network when the report is opened.
        assert not re.search(r'src="http|href="http|@import', html)

    def test_credentials_are_redacted_in_curl(self, tmp_path):
        html = reporter.render_report(self._results(), tmp_path / "r.html").read_text()
        assert "secret-token" not in html
        assert "redacted" in html

    def test_response_content_is_escaped(self, tmp_path):
        r = TestResult(test_id="T1", name="XSS", status="PASS")
        r.steps_a = [StepResult(order=1, name="Call", method="GET", url="http://h",
                                status=200, passed=True,
                                response_body="<script>alert(1)</script>")]
        html = reporter.render_report([r], tmp_path / "r.html").read_text()
        assert "<script>alert(1)</script>" not in html
        assert "&lt;script&gt;" in html

    def test_diffs_are_grouped_by_kind(self, tmp_path):
        html = reporter.render_report(self._results(), tmp_path / "r.html").read_text()
        assert "Value mismatch" in html and "Only in A" in html

    def test_filter_controls_present(self, tmp_path):
        html = reporter.render_report(self._results(), tmp_path / "r.html").read_text()
        for hook in ('id="search"', "setFilter", "copyBlock", 'data-status="PASS"'):
            assert hook in html
