"""Field-level assertions, including the multi-sibling rule."""

import pytest

from apitest.assertions import count_matches, evaluate, extract_all, extract_first
from apitest.models import Assertion

XML = ("<root><group>"
       "<item><type>A</type><val>100</val></item>"
       "<item><type>B</type><val>200</val></item>"
       "<item><type>C</type><val>300</val></item>"
       "</group></root>")

JSON = ('{"items":[{"type":"A","val":100},'
        '{"type":"B","val":200},{"type":"C","val":300}]}')


def check(payload, path, path_type, operator, expected=""):
    return evaluate(payload, [Assertion(path=path, path_type=path_type,
                                        operator=operator, expected_value=expected)])[0]


class TestExtraction:
    def test_extract_all_xml(self):
        assert extract_all(XML, "//item/val", "xpath") == ["100", "200", "300"]

    def test_extract_all_json(self):
        assert extract_all(JSON, "$.items[*].val", "jsonpath") == ["100", "200", "300"]

    def test_extract_first(self):
        assert extract_first(XML, "//item/val", "xpath") == "100"

    def test_no_match_is_empty(self):
        assert extract_all(XML, "//missing", "xpath") == []

    def test_count_matches_array(self):
        assert count_matches(JSON, "$.items", "jsonpath") == 3


class TestMultiSibling:
    """A path matching several siblings passes if any of them satisfies it."""

    def test_matches_third_sibling(self):
        r = check(XML, "//item/val", "xpath", "equals", "300")
        assert r.passed and r.actual_value == "300"

    def test_matches_middle_sibling(self):
        assert check(XML, "//item/val", "xpath", "equals", "200").passed

    def test_json_matches_third(self):
        assert check(JSON, "$.items[*].val", "jsonpath", "equals", "300").passed

    def test_no_sibling_matches_fails(self):
        r = check(XML, "//item/val", "xpath", "equals", "999")
        assert not r.passed

    def test_failure_lists_every_value_checked(self):
        r = check(XML, "//item/val", "xpath", "equals", "999")
        assert "100" in r.actual_value and "300" in r.actual_value
        assert "3 matches" in r.message


class TestOperators:
    @pytest.mark.parametrize("operator,expected,should_pass", [
        ("equals", "100", True),
        ("not_equals", "999", True),
        ("contains", "00", True),
        ("not_contains", "zzz", True),
        ("exists", "", True),
        ("not_null", "", True),
        ("greater_than", "250", True),
        ("less_than", "150", True),
        ("regex_match", r"^\d+$", True),
        ("one_of", "300,400", True),
        ("one_of", "777,888", False),
        ("greater_than", "9999", False),
    ])
    def test_operator(self, operator, expected, should_pass):
        assert check(XML, "//item/val", "xpath", operator, expected).passed is should_pass

    def test_count_equals(self):
        assert check(JSON, "$.items", "jsonpath", "count_equals", "3").passed

    def test_has_children(self):
        assert check(JSON, "$.items", "jsonpath", "has_children").passed

    def test_not_exists(self):
        assert check(JSON, "$.nothing", "jsonpath", "not_exists").passed

    def test_unknown_operator_fails_clearly(self):
        r = check(JSON, "$.items", "jsonpath", "no_such_operator")
        assert not r.passed and "unknown operator" in r.message

    def test_ignore_rows_are_skipped(self):
        results = evaluate(JSON, [Assertion(path="$.x", operator="ignore")])
        assert results == []

    def test_numeric_equality_ignores_formatting(self):
        payload = '{"a":100.00}'
        assert check(payload, "$.a", "jsonpath", "equals", "100").passed


class TestDatabaseGuards:
    def test_write_statement_rejected(self):
        from apitest.models import Environment
        env = Environment(name="x", db_url="sqlite:/tmp/none.db")
        r = evaluate("", [Assertion(path="DELETE FROM orders", path_type="sql",
                                    operator="db_equals", expected_value="1")], env)[0]
        assert not r.passed and "SELECT" in r.message

    def test_stacked_statement_rejected(self):
        from apitest.models import Environment
        env = Environment(name="x", db_url="sqlite:/tmp/none.db")
        r = evaluate("", [Assertion(path="SELECT 1; DROP TABLE orders",
                                    path_type="sql", operator="db_equals",
                                    expected_value="1")], env)[0]
        assert not r.passed and "stacked" in r.message

    def test_missing_environment_reported(self):
        r = evaluate("", [Assertion(path="SELECT 1", path_type="sql",
                                    operator="db_exists")], None)[0]
        assert not r.passed
