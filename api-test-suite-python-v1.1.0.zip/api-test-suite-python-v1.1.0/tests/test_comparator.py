"""Structural comparison, same-format and cross-format."""

from apitest.comparator import compare, detect_format, extract_inner_payload


def _soap(inner: str, *, routing: bool = False) -> str:
    body = (
        '<Envelope><Version>1</Version>'
        '<Sender><ApplicationId>A</ApplicationId></Sender>'
        '<Receiver><ApplicationId>B</ApplicationId></Receiver>'
        f'<Content>{inner}</Content></Envelope>'
    ) if routing else inner
    return ('<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/"><S:Body>'
            f'<ns0:executeResponse xmlns:ns0="http://x/ws"><return>{body}'
            '</return></ns0:executeResponse></S:Body></S:Envelope>')


class TestFormatDetection:
    def test_detects_json(self):
        assert detect_format('{"a":1}') == "json"
        assert detect_format('[1,2]') == "json"

    def test_detects_xml(self):
        assert detect_format("<a/>") == "xml"

    def test_detects_empty(self):
        assert detect_format("") == "empty"
        assert detect_format("   ") == "empty"

    def test_detects_text(self):
        assert detect_format("hello") == "text"

    def test_unwraps_cdata(self):
        payload = "<w><![CDATA[<Inner><Id>1</Id></Inner>]]></w>"
        assert extract_inner_payload(payload).startswith("<Inner>")


class TestSameFormat:
    def test_identical_json_matches(self):
        assert compare('{"a":1,"b":"x"}', '{"a":1,"b":"x"}').matched

    def test_different_value_reported(self):
        r = compare('{"a":1}', '{"a":2}')
        assert not r.matched
        assert any("a" in d.path for d in r.diffs)

    def test_list_order_ignored(self):
        assert compare('{"a":[1,2,3]}', '{"a":[3,1,2]}').matched

    def test_missing_field_reported(self):
        r = compare('{"a":1,"b":2}', '{"a":1}')
        assert not r.matched
        assert any(d.kind == "removed" for d in r.diffs)

    def test_extra_field_reported(self):
        r = compare('{"a":1}', '{"a":1,"b":2}')
        assert not r.matched
        assert any(d.kind == "added" for d in r.diffs)

    def test_identical_xml_matches(self):
        assert compare("<r><A>1</A></r>", "<r><A>1</A></r>").matched


class TestCrossFormatBridging:
    """Everything documented as bridged automatically."""

    def test_key_casing(self):
        assert compare('{"masterPartner":{"id":"1","entityId":"E"}}',
                       "<MasterPartner><Id>1</Id><EntityId>E</EntityId></MasterPartner>").matched

    def test_attribute_matches_json_field(self):
        assert compare('{"p":{"id":"1","usResident":false}}',
                       '<P usResident="false"><Id>1</Id></P>').matched

    def test_singleton_matches_one_element_array(self):
        assert compare('{"p":{"id":"1","phoneNumber":[{"value":"9"}]}}',
                       "<P><Id>1</Id><PhoneNumber><Value>9</Value></PhoneNumber></P>").matched

    def test_scientific_matches_fixed_decimal(self):
        assert compare('{"p":{"id":"1","amt":1.2345E4}}',
                       "<P><Id>1</Id><Amt>12345.00000</Amt></P>").matched

    def test_scale_insensitive_numbers(self):
        assert compare('{"p":{"id":"1","rate":0.15}}',
                       "<P><Id>1</Id><Rate>0.15000</Rate></P>").matched

    def test_boolean_string_matches_boolean(self):
        assert compare('{"p":{"id":"1","ok":true}}',
                       "<P><Id>1</Id><Ok>true</Ok></P>").matched

    def test_iso_date_matches_compact(self):
        assert compare('{"p":{"id":"1","d":"2017-08-25"}}',
                       "<P><Id>1</Id><D>20170825</D></P>").matched

    def test_unicode_normalised(self):
        assert compare('{"p":{"id":"1","name":"M\u00fcller"}}',
                       "<P><Id>1</Id><Name>M\u00fcller</Name></P>").matched

    def test_routing_envelope_peeled(self):
        assert compare('{"p":{"id":"1","v":"x"}}',
                       _soap("<P><Id>1</Id><V>x</V></P>", routing=True)).matched

    def test_currency_redundancy_not_reported(self):
        # JSON carries the currency twice, XML once. Not a data difference.
        assert compare(
            '{"items":[{"cashAccount":{"id":"A1","ccy":"EUR"},'
            '"currentBalance":{"amount":100,"ccy":"EUR"}}]}',
            "<r><CashAccount><Id>A1</Id><Ccy>EUR</Ccy>"
            "<Balance><Amount>100.00</Amount></Balance></CashAccount></r>").matched


class TestCrossFormatStillReports:
    """Real differences must never be hidden by the normalisation."""

    def test_different_scalar(self):
        r = compare('{"p":{"id":"1","v":"a"}}', "<P><Id>1</Id><V>b</V></P>")
        assert not r.matched

    def test_one_sided_field(self):
        r = compare('{"p":{"id":"1","v":"a","extra":"z"}}', "<P><Id>1</Id><V>a</V></P>")
        assert not r.matched

    def test_non_date_digits_not_treated_as_dates(self):
        r = compare('{"p":{"id":"1","code":12345678}}', "<P><Id>1</Id><Code>87654321</Code></P>")
        assert not r.matched


class TestCollectionPayloads:
    @staticmethod
    def _json(*ids):
        items = ",".join(
            '{"cashAccount":{"id":"%s","ccy":"EUR"},"currentBalance":{"amount":%d}}'
            % (i, 100 * (n + 1)) for n, i in enumerate(ids))
        return '{"cashAccountsBalances":[%s]}' % items

    @staticmethod
    def _xml(*ids, header=True):
        head = ("<Header><EntityId>ENT</EntityId><Application>1</Application>"
                "<Version>1</Version><User><Id>USR</Id></User></Header>") if header else ""
        accs = "".join(
            "<CashAccount><Id>%s</Id><Ccy>EUR</Ccy>"
            "<Balance><Amount>%d.00000</Amount></Balance></CashAccount>"
            % (i, 100 * (n + 1)) for n, i in enumerate(ids))
        return _soap(f"<CashAccountOverviewResponse>{head}{accs}</CashAccountOverviewResponse>")

    def test_header_sibling_excluded(self):
        assert compare(self._json("A1", "A2"), self._xml("A1", "A2")).matched

    def test_reordered_records_match(self):
        reordered = _soap(
            "<CashAccountOverviewResponse><Header><EntityId>ENT</EntityId></Header>"
            "<CashAccount><Id>A2</Id><Ccy>EUR</Ccy>"
            "<Balance><Amount>200.00000</Amount></Balance></CashAccount>"
            "<CashAccount><Id>A1</Id><Ccy>EUR</Ccy>"
            "<Balance><Amount>100.00000</Amount></Balance></CashAccount>"
            "</CashAccountOverviewResponse>")
        assert compare(self._json("A1", "A2"), reordered).matched

    def test_wrong_amount_identified_by_key(self):
        bad = self._xml("A1", "A2").replace("<Amount>200.00000</Amount>",
                                            "<Amount>999.00000</Amount>")
        r = compare(self._json("A1", "A2"), bad)
        assert not r.matched
        assert any("A2" in d.path for d in r.diffs)

    def test_missing_record_reported(self):
        r = compare(self._json("A1", "A2"), self._xml("A1"))
        assert not r.matched

    def test_extra_record_reported(self):
        r = compare(self._json("A1"), self._xml("A1", "A2"))
        assert not r.matched


class TestSingleDocumentPayloads:
    """A rich document must not be reduced to its largest inner list."""

    @staticmethod
    def _json(status):
        return ('{"masterPartner":{"entityId":"E1","usResident":false,'
                '"phoneNumber":[{"type":"mobile","value":"111"}],'
                f'"frameworkAgreement":{{"status":"{status}","date":"2017-08-25"}},'
                '"informationDistribution":['
                '{"type":"a","agreed":true},{"type":"b","agreed":true},'
                '{"type":"c","agreed":true},{"type":"d","agreed":false},'
                '{"type":"e","agreed":true},{"type":"f","agreed":false}]}}')

    @staticmethod
    def _xml(status):
        return _soap(
            "<PartnerReadResponse><MasterPartner usResident=\"false\">"
            "<EntityId>E1</EntityId>"
            "<PhoneNumber><Type>mobile</Type><Value>111</Value></PhoneNumber>"
            f"<FrameworkAgreement><Status>{status}</Status><Date>20170825</Date></FrameworkAgreement>"
            "<InformationDistribution><Type>c</Type><Agreed>true</Agreed></InformationDistribution>"
            "<InformationDistribution><Type>a</Type><Agreed>true</Agreed></InformationDistribution>"
            "<InformationDistribution><Type>b</Type><Agreed>true</Agreed></InformationDistribution>"
            "<InformationDistribution><Type>e</Type><Agreed>true</Agreed></InformationDistribution>"
            "<InformationDistribution><Type>d</Type><Agreed>false</Agreed></InformationDistribution>"
            "<InformationDistribution><Type>f</Type><Agreed>false</Agreed></InformationDistribution>"
            "</MasterPartner></PartnerReadResponse>", routing=True)

    def test_identical_document_matches(self):
        assert compare(self._json("1"), self._xml("1")).matched

    def test_buried_scalar_difference_is_caught(self):
        # The regression: this used to report a false match because the whole
        # comparison collapsed onto the six trivial flag entries.
        r = compare(self._json("1"), self._xml("0"))
        assert not r.matched
        assert any("status" in d.path.lower() for d in r.diffs)
