"""Workbook loading, per-source pipe splitting, and template safety."""

import pytest
from openpyxl import Workbook

from apitest.excel import WorkbookError, load, split_source_pair
from apitest.models import Step
from apitest.templating import (RenderLog, prune_empty_elements, render,
                                resolve_template_path)


class TestPipeSplitting:
    @pytest.mark.parametrize("raw,expected", [
        ("GET|POST", ("GET", "POST")),
        ("GET", ("GET", "")),
        ("|soap.xml", ("", "soap.xml")),
        ("a.json|b.xml", ("a.json", "b.xml")),
        ("", ("", "")),
        ("/rest/x | /soap/y", ("/rest/x", "/soap/y")),
        ("body.json|", ("body.json", "")),
    ])
    def test_split(self, raw, expected):
        assert split_source_pair(raw) == expected

    def test_none_is_safe(self):
        assert split_source_pair(None) == ("", "")


class TestPerSourceResolution:
    def test_different_method_and_template(self):
        s = Step(method="GET", method_b="POST", endpoint="/rest", endpoint_b="/soap",
                 body_template="", body_template_b="soap.xml")
        assert s.method_for("A") == "GET"
        assert s.method_for("B") == "POST"
        assert s.endpoint_for("A") == "/rest"
        assert s.endpoint_for("B") == "/soap"
        assert s.body_template_for("A") == ""
        assert s.body_template_for("B") == "soap.xml"

    def test_no_pipe_shares_value(self):
        s = Step(method="GET", endpoint="/same", body_template="body.json")
        for source in ("A", "B"):
            assert s.method_for(source) == "GET"
            assert s.endpoint_for(source) == "/same"
            assert s.body_template_for(source) == "body.json"


class TestWorkbookLoading:
    @staticmethod
    def _workbook(tmp_path, steps_rows=None):
        wb = Workbook()
        wb.remove(wb.active)
        env = wb.create_sheet("Environments")
        env.append(["EnvName", "Protocol", "BaseURL", "AuthType"])
        env.append(["E1", "rest", "http://localhost", "none"])
        ts = wb.create_sheet("TestSuite")
        ts.append(["TestID", "TestName", "ComparisonMode", "SourceA", "Enabled"])
        ts.append(["T1", "First", "assert_only", "E1", "Y"])
        ts.append(["T2", "Disabled", "assert_only", "E1", "N"])
        st = wb.create_sheet("Steps")
        st.append(["TestID", "StepOrder", "StepName", "Method", "Endpoint", "BodyTemplate"])
        for row in (steps_rows or [["T1", 1, "Call", "GET|POST", "/a|/b", "|s.xml"]]):
            st.append(row)
        path = tmp_path / "suite.xlsx"
        wb.save(path)
        return path

    def test_loads_environments_and_tests(self, tmp_path):
        suite = load(self._workbook(tmp_path))
        assert "E1" in suite.environments
        assert [t.test_id for t in suite.tests] == ["T1"]  # T2 is disabled

    def test_pipe_columns_reach_the_step(self, tmp_path):
        suite = load(self._workbook(tmp_path))
        step = suite.tests[0].steps[0]
        assert step.method_for("A") == "GET"
        assert step.method_for("B") == "POST"
        assert step.body_template_for("B") == "s.xml"

    def test_missing_sheet_is_explained(self, tmp_path):
        wb = Workbook()
        wb.remove(wb.active)
        wb.create_sheet("Environments").append(["EnvName"])
        path = tmp_path / "broken.xlsx"
        wb.save(path)
        with pytest.raises(WorkbookError) as exc:
            load(path)
        assert "TestSuite" in str(exc.value)

    def test_missing_file_is_explained(self, tmp_path):
        with pytest.raises(WorkbookError):
            load(tmp_path / "nope.xlsx")


class TestTemplating:
    def test_substitutes_data_and_step_vars(self):
        out = render("/a/${id}/b/${step1.token}", {"id": "7"}, {"step1.token": "abc"})
        assert out == "/a/7/b/abc"

    def test_unresolved_token_left_alone(self):
        assert render("${missing}", {}, {}) == "${missing}"

    def test_env_lookup(self, monkeypatch):
        monkeypatch.setenv("MY_VALUE", "from-env")
        assert render("${env.MY_VALUE}") == "from-env"

    def test_now_and_uuid_resolve(self):
        assert render("${now}") != "${now}"
        assert len(render("${uuid}")) == 36

    def test_render_log_records_tokens(self):
        log = RenderLog()
        render("${id}", {"id": "7"}, {}, log)
        assert "${id}" in log.summary()

    def test_prunes_unresolved_xml_elements(self):
        xml = "<r><Keep>1</Keep><Drop>${missing}</Drop><Empty></Empty></r>"
        out = prune_empty_elements(xml)
        assert "Keep" in out and "Drop" not in out and "Empty" not in out


class TestPlaceholderOffset:
    """A placeholder may carry a trailing whole-number offset, e.g.
    ${step1.orderId + 1}, for passing an incremented value to the next step."""

    def test_increments_large_extracted_number(self):
        # The case this feature exists for.
        assert render("${step1.seq + 1}", {}, {"step1.seq": "234234233"}) == "234234234"

    def test_adds_in_endpoint(self):
        assert render("/orders/${step1.orderId + 1}", {}, {"step1.orderId": "100"}) == "/orders/101"

    def test_subtracts(self):
        assert render("${step2.id - 1}", {}, {"step2.id": "500"}) == "499"

    def test_larger_offset(self):
        assert render("${step1.n + 100}", {}, {"step1.n": "10"}) == "110"

    def test_works_on_testdata_column(self):
        assert render("${counter + 1}", {"counter": "42"}, {}) == "43"

    def test_negative_result_allowed(self):
        assert render("${n - 5}", {"n": "4"}, {}) == "-1"

    def test_large_id_is_exact(self):
        # Arbitrary precision — no rounding on an 18-digit id.
        assert render("${v + 1}", {"v": "123456789012345678"}, {}) == "123456789012345679"

    def test_outer_padding_inside_braces(self):
        assert render("${ step1.seq + 1 }", {}, {"step1.seq": "9"}) == "10"

    def test_non_numeric_value_raises(self):
        with pytest.raises(ValueError) as exc:
            render("${step1.orderId + 1}", {}, {"step1.orderId": "ORD-42"})
        assert "not a whole number" in str(exc.value)
        assert "ORD-42" in str(exc.value)

    def test_hyphenated_name_is_not_arithmetic(self):
        assert render("${order-2024}", {"order-2024": "present"}, {}) == "present"

    def test_no_spaces_is_not_arithmetic(self):
        # Without spaces it is an ordinary (here missing) token, left in place.
        assert render("${seq+1}", {}, {}) == "${seq+1}"

    def test_plain_placeholder_unaffected(self):
        assert render("${step1.orderId}", {}, {"step1.orderId": "100"}) == "100"

    def test_offset_composes_with_xml_pruning(self):
        out = render("<req><id>${step1.seq + 1}</id><note>${missing}</note></req>",
                     {}, {"step1.seq": "7"})
        assert out == "<req><id>8</id></req>"


class TestTemplatePathContainment:
    """A shared workbook must not reach outside the project for a file."""

    def test_template_inside_directory_resolves(self, tmp_path):
        templates = tmp_path / "templates"
        templates.mkdir()
        (templates / "req.xml").write_text("<r/>")
        assert resolve_template_path("req.xml", templates, tmp_path).name == "req.xml"

    def test_nested_path_resolves(self, tmp_path):
        nested = tmp_path / "templates" / "soap"
        nested.mkdir(parents=True)
        (nested / "env.xml").write_text("<e/>")
        found = resolve_template_path("soap/env.xml", tmp_path / "templates", tmp_path)
        assert found.name == "env.xml"

    def test_traversal_is_rejected(self, tmp_path):
        templates = tmp_path / "templates"
        templates.mkdir()
        outside = tmp_path.parent / f"outside-{tmp_path.name}.txt"
        outside.write_text("must stay unreachable")
        try:
            with pytest.raises(FileNotFoundError):
                resolve_template_path(f"../{outside.name}", templates, templates)
        finally:
            outside.unlink(missing_ok=True)

    def test_deep_traversal_is_rejected(self, tmp_path):
        templates = tmp_path / "templates"
        templates.mkdir()
        with pytest.raises(FileNotFoundError):
            resolve_template_path("../../../../etc/hostname", templates, templates)

    def test_absolute_path_still_allowed(self, tmp_path):
        shared = tmp_path / "shared.xml"
        shared.write_text("<s/>")
        assert resolve_template_path(str(shared), tmp_path / "templates", tmp_path) == shared

    def test_missing_template_names_the_file(self, tmp_path):
        with pytest.raises(FileNotFoundError) as exc:
            resolve_template_path("nope.xml", tmp_path / "templates", tmp_path)
        assert "nope.xml" in str(exc.value)
