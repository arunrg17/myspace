# API Test Suite

Excel-driven API testing for REST, SOAP, Fabric, and GCP — with multi-step chains,
structural response comparison, field-level assertions, and self-contained HTML
reports. Single Java JAR. No code required to add a test.

---

## Quick start

```bash
# Prerequisites: Java 21+ and Maven 3.8+
mvn package

# Generate the starter Excel workbook
java -cp target/api-test-suite.jar com.apitest.excel.TemplateGenerator

# Edit config/test_suite.xlsx to your needs, then run
java -jar target/api-test-suite.jar

# Open the report
open reports/report.html        # macOS
xdg-open reports/report.html    # Linux
start reports/report.html       # Windows
```

Exit code is `0` if every test passes, `1` otherwise — drop straight into any CI
pipeline.

---

## Project layout

```
api-test-suite/
├── pom.xml                       Maven build
├── config/
│   └── test_suite.xlsx           Your test definitions (generated)
├── templates/                    Request body templates with ${placeholders}
│   ├── create_order.xml
│   ├── update_order.xml
│   └── get_account.xml
├── expected/                     Baseline responses for vs_expected mode
│   └── T002_create_order.xml
├── reports/
│   └── report.html               Generated after each run
├── output/                       Raw request/response captures per run
│   └── 20260513_123456/
│       └── T001/sourceA/step1_get_customer/{request,response}.txt
└── src/main/java/com/apitest/    Source
```

---

## How a test runs

1. **Load** the Excel suite — Environments, TestSuite, Steps, TestData, Assertions.
2. **For each enabled test:**
   - Resolve placeholders from the TestData row.
   - Send each step's HTTP request to source A (and source B for two-sided modes).
   - Extract response variables for later steps in the chain.
   - Compare and/or assert per the comparison mode.
3. **Write** the HTML report and raw request/response captures.

---

## The Excel workbook

Five sheets. Headers are case-sensitive. Add columns wherever it helps you;
unrecognised columns are simply ignored.

### Sheet 1: Environments

Define one row per named endpoint. Same protocol can have multiple envs (DEV, UAT, PROD).

| Column | Purpose |
|---|---|
| `EnvName` | Short identifier used by SourceA / SourceB. |
| `Protocol` | `rest`, `soap`, `fabric`, `gcp`. |
| `BaseURL` | Full origin (no trailing slash). |
| `AuthType` | `none`, `basic`, `bearer`, `oauth2`, `service_account`. |
| `AuthValue` | Token literal or `${env.VAR}` to pull from OS environment. |
| `ExtraHeaders` | Newline-separated `Header: value` pairs. |

> **Secrets never go in Excel.** Use `${env.MY_TOKEN}` and export `MY_TOKEN` in your shell or CI.

### Sheet 2: TestSuite

One row per test case.

| Column | Purpose |
|---|---|
| `TestID` | Unique identifier (e.g. `T001`). |
| `TestName` | Short readable title. |
| `Description` | Free-form notes shown in the report. |
| `ComparisonMode` | One of `vs_expected`, `vs_env`, `vs_protocol`, `assert_only`, `chain`. |
| `SourceA` | Primary environment to run against. |
| `SourceB` | Secondary environment (for `vs_env` / `vs_protocol` only). |
| `ExpectedFile` | Path to baseline file (for `vs_expected` only). |
| `Enabled` | `Y` to include, anything else to skip. |

### Sheet 3: Steps

One row per HTTP request. Multiple rows per `TestID` build a chain (StepOrder = 1, 2, 3…).

| Column | Purpose |
|---|---|
| `TestID` | Links the step back to a TestSuite row. |
| `StepOrder` | Numeric order of execution. |
| `StepName` | Shown in the report. |
| `Method` | `GET`, `POST`, `PUT`, `DELETE`, `PATCH`. |
| `Endpoint` | Path appended to `BaseURL`, with placeholders. |
| `BodyTemplate` | Relative path to a template in `/templates`, blank for none. |
| `ExtractVars` | Comma-separated `name=jsonpath_or_xpath` to save values for the next step. |
| `ExpectedStatus` | Comma-separated HTTP codes that count as success (default: `200,201,204`). |

### Sheet 4: TestData

Variables per test. Each column header is a placeholder name.

| TestID | customer_id | product_id | quantity | unit_price | … |
|---|---|---|---|---|---|
| T002 | CUST-1001 | PROD-501 | 5 | 49.99 | … |

In templates and endpoints, reference these as `${customer_id}`, `${product_id}`, etc.

### Sheet 5: Assertions

Field-level checks **and** ignore directives for noisy fields.

| Column | Purpose |
|---|---|
| `TestID` | Specific test, or `*` to apply to every test. |
| `Path` | JSONPath (`$.order.id`) or XPath (`//Status`). |
| `PathType` | `jsonpath` or `xpath`. |
| `Operator` | See operators below. |
| `ExpectedValue` | The value to compare against (where applicable). |
| `Description` | Shown in the report. |

---

## The five comparison modes

| Mode | What runs | What gets compared |
|---|---|---|
| `vs_expected` | Source A only | Last response vs `ExpectedFile` |
| `vs_env` | Source A + Source B | Response A vs Response B |
| `vs_protocol` | Source A + Source B | Normalized A vs normalized B (XML↔JSON OK) |
| `assert_only` | Source A only | Field assertions only — no file comparison |
| `chain` | Source A only | No comparison — chain succeeds if every step's HTTP status matches expected |

**Field assertions** can be added to **any** mode except `chain`. They run on the
final Source A response and are evaluated alongside the structural comparison.
The test only passes when both pass.

---

## The 9 assertion operators

| Operator | Behaviour | Example ExpectedValue |
|---|---|---|
| `equals` | Strict string equality after path extraction. | `created` |
| `not_equals` | Negation of the above. | `cancelled` |
| `contains` | Substring match. | `ERROR` |
| `exists` | Path resolves to a non-empty value. | *(blank)* |
| `not_exists` | Path is missing or resolves empty. | *(blank)* |
| `greater_than` | Numeric: actual > expected. | `0` |
| `less_than` | Numeric: actual < expected. | `100` |
| `regex_match` | Java regex search on the extracted value. | `^(EMEA\|AMER\|APAC)$` |
| `ignore` | **Skip this field during structural comparison.** Doesn't fail; quiets diff noise. | *(blank)* |

---

## Placeholder cheat sheet

Available in BodyTemplate files and the Endpoint column.

| Placeholder | Resolves to |
|---|---|
| `${col_name}` | Cell value from the TestData row matching this test. |
| `${!col_name}` | Same as above, but **required** — fails the test if the cell is blank or missing. |
| `${stepN.field}` | A variable extracted from step N's response (e.g. `${step1.order_id}`). |
| `${env.VAR}` | OS environment variable. Used for secrets/tokens. |
| `${now}` | Current UTC timestamp in ISO-8601 (`2026-05-13T12:34:56Z`). |
| `${uuid}` | Random UUID v4. |

### XML template pruning (sparse TestData)

When you have one template covering many test cases, you may not want every tag
filled for every test. The framework automatically **drops tags whose
placeholders are blank or missing**, so a single template works for 50 different
data combinations without producing `<EmptyTag></EmptyTag>` that fails XSD
validation.

**Template:**
```xml
<Order>
  <Id>${order_id}</Id>
  <Customer>
    <Name>${customer_name}</Name>
    <Phone>${customer_phone}</Phone>
    <Email>${customer_email}</Email>
  </Customer>
  <DeliveryDate>${delivery_date}</DeliveryDate>
  <Notes>${notes}</Notes>
</Order>
```

**TestData row** (only some columns filled):

| order_id | customer_name | customer_phone | customer_email | delivery_date | notes |
|---|---|---|---|---|---|
| 123 | Alice | *(blank)* | alice@x.com | *(blank)* | *(blank)* |

**Rendered request:**
```xml
<Order>
  <Id>123</Id>
  <Customer>
    <Name>Alice</Name>
    <Email>alice@x.com</Email>
  </Customer>
</Order>
```

Rules:
- Blank or missing column → drop the tag entirely
- Parent left with no remaining children → drop the parent too (cascades)
- Attribute with blank value → drop the attribute, keep the element
- Mixed content with any unresolved placeholder → drop the whole tag
- Literal empty tags you wrote in the template (`<Empty></Empty>`) → preserved
- For JSON/text bodies, no pruning — unresolved placeholders become empty strings
- Use `${!col}` to mark a column as **required** — the test fails fast if it's blank instead of silently dropping the tag

---

## Walkthrough: adding a new test

A common workflow — no code changes, only Excel edits.

**Goal:** add a test that creates a customer via REST, then verifies the
returned `customer.id` is a UUID and `customer.status` is `pending`.

1. **TestSuite sheet** — add a row:
   ```
   T010 | Create customer | Verify response shape | assert_only | DEV_REST | | | Y
   ```

2. **Steps sheet** — add a row:
   ```
   T010 | 1 | Create customer | POST | /customers | templates/create_customer.json | | 201
   ```

3. **TestData sheet** — add a row with the input data:
   ```
   T010 | (customer_id blank) | | | | | | | | first_name=Alice last_name=Diaz
   ```

4. **Assertions sheet** — add the field checks:
   ```
   T010 | $.customer.id     | jsonpath | regex_match | ^[0-9a-f-]{36}$ | UUID format
   T010 | $.customer.status | jsonpath | equals      | pending         | New customer state
   T010 | $.customer.email  | jsonpath | exists      |                 | Email must echo
   ```

5. **templates/create_customer.json** — create the template:
   ```json
   { "first_name": "${first_name}", "last_name": "${last_name}", "requestId": "${uuid}" }
   ```

6. Run `java -jar target/api-test-suite.jar` and open `reports/report.html`.

That's it. Adding tests is data entry.

---

## Secrets and CI

```bash
export DEV_TOKEN="eyJhbGc..."          # referenced as ${env.DEV_TOKEN} in Excel
export FABRIC_CLIENT_SECRET="..."
export TRUST_PASS="changeit"           # for keystore passwords if using SslConfig

mvn -q package
java -jar target/api-test-suite.jar    # exit 0 → all pass, exit 1 → at least one fail
```

## SSL / TLS

For services with private CAs, self-signed certs, or mTLS, configure the
`SslConfig` column on the `Environments` sheet. Examples:

```
trust_store=certs/ca.jks; trust_password=${env.TRUST_PASS}
key_store=certs/client.p12; key_password=${env.CLIENT_PASS}; key_type=PKCS12
verify=false                              (DEV ONLY)
```

See [docs/SSL_GUIDE.md](docs/SSL_GUIDE.md) for full instructions including
`.pem` → `.jks` conversion, mTLS setup, and troubleshooting.

## Writing assertions for repeated XML elements

When your response has many elements with the same name (multiple employees,
line items, projects), a plain `//City` returns just the *first* match. To
target a specific one, use XPath predicates: `//Employee[EmployeeId='1002']/Address/City`.

See [docs/XPATH_GUIDE.md](docs/XPATH_GUIDE.md) for the four common patterns
and a complete cheat sheet.

## Testing an XPath against a saved response

After a run, every response is saved to `output/<timestamp>/<TestID>/sourceA/step*/response.txt`.
To verify an XPath against a real captured response without running the full
suite:

```bash
java -cp target/api-test-suite.jar com.apitest.XPathTester \
    output/20260513_120000/T001/sourceA/step1_get/response.txt \
    "//SecurityCostItem[Security/Id='AA0RED']/Cost" \
    "//Version"
```

This uses the exact same parser as the test runner, so what works here
works in your assertions. Pass multiple XPaths to test several at once.

## Sharing structure for help without leaking response content

If your response contains proprietary data and you need help with an XPath,
the `ResponseSkeleton` tool extracts just the element names and nesting,
redacting every value:

```bash
java -cp target/api-test-suite.jar com.apitest.ResponseSkeleton \
    output/20260513_120000/T001/sourceA/step1_get/response.txt
```

Output shows the element tree with all text/attribute values replaced by
placeholders, plus a list of unique element names and which ones repeat
(those are the candidates for `//Parent[Child='X']`-style predicates).
Safe to paste anywhere for debugging.

**Do not use online XPath testers to verify paths against this framework's
responses.** Many of them default to HTML5 mode and will flag valid XML as
invalid (because HTML doesn't allow capitalized tags or colons in names).
Use the built-in `XPathTester` tool, `xmlstarlet`, or Python `lxml` instead.

GitHub Actions example:
```yaml
- uses: actions/setup-java@v4
  with: { distribution: 'temurin', java-version: '21' }
- run: mvn -q package
- run: java -jar target/api-test-suite.jar
  env:
    DEV_TOKEN: ${{ secrets.DEV_TOKEN }}
- uses: actions/upload-artifact@v4
  if: always()
  with: { name: api-test-report, path: reports/report.html }
```

---

## Wiring real auth providers

The `Dispatcher.getOauth2Token()` and `Dispatcher.getGcpToken()` methods are
stubs that read `OAUTH2_TOKEN` / `GCP_TOKEN` from the environment. In
production, replace them with real flows:

- **OAuth2 / Microsoft Fabric** — use MSAL4J (`com.microsoft.azure.msal4j`)
  client-credentials flow. Drop the dependency into `pom.xml`, swap the stub.
- **GCP** — use `com.google.auth:google-auth-library-oauth2-http`, load the
  service account JSON from the path in `AuthValue`, request a token.

---

## Command-line options

```
java -jar target/api-test-suite.jar [options]

  --suite <path>    Excel suite file (default: config/test_suite.xlsx)
  --report <path>   HTML report output (default: reports/report.html)
  --name <name>     Suite name shown in the report header
  --help, -h        Show this help
```

---

## The HTML report

After each run you get a single self-contained HTML file with:

- A donut chart summary, KPIs, and mode breakdown.
- A searchable, filterable sidebar of every test.
- Per-test tabs:
  - **Overview** — at-a-glance metadata.
  - **Steps** — each request/response with syntax-highlighted code blocks and copy buttons.
  - **Comparison** — side-by-side diff or table view of every difference.
  - **Assertions** — per-field pass/fail table.
- Keyboard shortcuts: `/` to focus search, `Esc` to clear.
- A print stylesheet for PDF export.

No external dependencies — open it from anywhere.

---

## Troubleshooting

**"Required sheet missing: TestSuite"**
The workbook was edited and a required sheet was renamed or removed. Required
sheets are Environments, TestSuite, and Steps.

**`PathType` left blank**
Treated as missing. Set it to `jsonpath` or `xpath` explicitly.

**Numbers showing as `49.99000000001`**
Format the TestData column as Text in Excel before typing, or wrap critical
strings in single quotes (Excel strips them on save).

**Diff shows differences I expected to ignore**
Check the Assertions sheet — `PathType` must match the response format
(`jsonpath` for JSON responses, `xpath` for XML/SOAP).

**Bearer/OAuth token is empty**
The `${env.VAR}` referenced wasn't exported in the shell that ran the JAR.
Print it with `echo $VAR` before invoking Java.

---

## Building from source

```bash
mvn clean package        # builds the fat-jar at target/api-test-suite.jar
mvn test                 # runs all JUnit tests
```

### Quick demo (no network calls)

To see the report format without configuring any real environments:

```bash
mvn package
java -cp target/api-test-suite.jar com.apitest.Demo
open reports/demo_report.html
```

This runs 6 simulated test cases covering every comparison mode, generates a
real HTML report, and exits — useful for a first look or for showing
stakeholders what the output looks like.

Java 21 features used: records, switch expressions, pattern matching, text blocks.
Earlier JDKs will fail to compile.
