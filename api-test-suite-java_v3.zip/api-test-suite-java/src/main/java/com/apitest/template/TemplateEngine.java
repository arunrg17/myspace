package com.apitest.template;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Renders request bodies and endpoints with ${placeholder} substitution.
 *
 * Supported placeholders:
 *   ${col_name}        from TestCase.data
 *   ${stepN.varname}   from a previous step's extracted variables
 *   ${env.NAME}        from OS environment variable
 *   ${now}             current UTC ISO timestamp
 *   ${uuid}            random UUID
 *   ${!required_col}   REQUIRED column — throws if missing or blank
 *
 * Template pruning (XML only):
 *   When a TestData column is blank or missing, the corresponding placeholder
 *   resolves to an "unresolved" marker, and during a post-substitution pass:
 *     - Elements whose entire content was a single unresolved placeholder
 *       are removed (so <Phone>${phone}</Phone> with phone=blank → gone)
 *     - Attributes whose value was an unresolved placeholder are removed
 *       (so <Order ref="${r}">, with r blank → <Order>)
 *     - Mixed content with ANY unresolved placeholder removes the whole tag
 *     - Parent elements left with no remaining children and no text are
 *       themselves removed (cascade)
 *
 * Pass `${!col}` to force a column to be required — if missing/blank, the
 * render fails with a clear error rather than silently dropping the tag.
 */
public class TemplateEngine {

    private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{([^}]+)}");

    /** Sentinel left in the rendered output where a placeholder didn't resolve. */
    private static final String UNRESOLVED_MARKER = "\u0001__UNRESOLVED__\u0001";

    public static String render(String template, Map<String, String> data,
                                Map<Integer, Map<String, String>> stepVars) {
        if (template == null || template.isEmpty()) return template == null ? "" : template;

        // Phase 1: substitution. Unresolved placeholders become UNRESOLVED_MARKER.
        Matcher m = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String token = m.group(1).trim();
            String replacement = resolve(token, data, stepVars);
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        String rendered = out.toString();

        // Phase 2: if the output looks like XML and contains unresolved markers,
        // strip the tags/attributes those markers belong to. JSON / form bodies
        // are passed through unchanged (callers handle those formats themselves).
        if (rendered.contains(UNRESOLVED_MARKER) && looksLikeXml(rendered)) {
            rendered = pruneUnresolved(rendered);
        } else if (rendered.contains(UNRESOLVED_MARKER)) {
            // Non-XML body with unresolved placeholders — strip the markers
            // (treat as empty string, preserving prior behaviour for JSON).
            rendered = rendered.replace(UNRESOLVED_MARKER, "");
        }

        return rendered;
    }

    public static String renderFile(String templatePath, Map<String, String> data,
                                    Map<Integer, Map<String, String>> stepVars,
                                    Path baseDir) throws IOException {
        if (templatePath == null || templatePath.isEmpty()) return "";
        Path p = baseDir.resolve(templatePath);
        String text = Files.readString(p);
        return render(text, data, stepVars);
    }

    // ------------------------------------------------------------------
    // Resolution
    // ------------------------------------------------------------------

    private static String resolve(String token, Map<String, String> data,
                                  Map<Integer, Map<String, String>> stepVars) {
        // Required-column syntax: ${!column_name}
        boolean required = false;
        if (token.startsWith("!")) {
            required = true;
            token = token.substring(1).trim();
        }

        String value = resolveLiteral(token, data, stepVars);

        if (required && (value == null || value.isEmpty())) {
            throw new IllegalStateException("Required placeholder ${!" + token
                    + "} resolved to empty. Check TestData column or step output.");
        }

        return (value == null || value.isEmpty()) ? UNRESOLVED_MARKER : value;
    }

    private static String resolveLiteral(String token, Map<String, String> data,
                                         Map<Integer, Map<String, String>> stepVars) {
        if ("now".equals(token)) return Instant.now().toString();
        if ("uuid".equals(token)) return UUID.randomUUID().toString();
        if (token.startsWith("env.")) {
            String v = System.getenv(token.substring(4));
            return v == null ? "" : v;
        }
        if (token.startsWith("step") && token.contains(".")) {
            int dot = token.indexOf('.');
            String head = token.substring(0, dot);
            String key = token.substring(dot + 1);
            try {
                int n = Integer.parseInt(head.substring(4));
                Map<String, String> vars = stepVars.get(n);
                if (vars != null) {
                    String v = vars.get(key);
                    return v == null ? "" : v;
                }
            } catch (NumberFormatException ignore) {}
            return "";
        }
        if (data == null) return "";
        String v = data.get(token);
        return v == null ? "" : v;
    }

    // ------------------------------------------------------------------
    // Pruning
    // ------------------------------------------------------------------

    private static boolean looksLikeXml(String s) {
        String t = s.trim();
        return t.startsWith("<");
    }

    /**
     * Multi-pass pruning. Each pass:
     *   1. Removes attributes whose value is just the unresolved marker
     *   2. Removes elements whose entire content is the unresolved marker
     *      (handles <Tag>${blank}</Tag> → element gone)
     *   3. Removes elements whose mixed content contains the marker anywhere
     *      (handles <Tag>prefix ${blank} suffix</Tag> → element gone)
     *   4. Removes empty PARENT (non-root) elements that resulted from steps 2/3
     * Loops until no further changes — cascading deletes propagate.
     *
     * The ROOT element is never pruned, even if all its children are removed.
     * Producing an empty root is far better than producing an empty body
     * (which fails server-side with confusing "EOF in prolog" errors).
     */
    static String pruneUnresolved(String xml) {
        // Identify the root element name so we can exclude it from the
        // "remove empty parents" pass.
        String rootName = findRootElementName(xml);

        String prev;
        String current = xml;
        int passes = 0;
        do {
            prev = current;
            current = removeAttributesWithMarker(current);
            current = removeElementsWithMarkerContent(current);
            current = removeEmptyParentElements(current, rootName);
            passes++;
            if (passes > 20) break;  // safety
        } while (!current.equals(prev));

        // Clean up any stragglers (e.g. attribute markers in CDATA, comments, etc.)
        current = current.replace(UNRESOLVED_MARKER, "");

        // Check for the failure case: every placeholder was unresolved, leaving
        // the root element empty. Producing an empty/skeleton request gets
        // confusing "EOF in prolog" errors from the server. Fail with a clear
        // message instead so the user knows their TestData doesn't match the
        // template placeholders.
        if (rootName != null && rootIsEffectivelyEmpty(current, rootName)) {
            throw new IllegalStateException(
                    "Template rendered to an empty request body — every placeholder "
                    + "in <" + rootName + "> was unresolved. Check that your TestData "
                    + "columns match the ${placeholder} names in your template.");
        }
        return current;
    }

    /** True if the root element has no element children and no non-whitespace text. */
    private static boolean rootIsEffectivelyEmpty(String xml, String rootName) {
        // Find the root opening tag
        Pattern rootOpen = Pattern.compile("<" + Pattern.quote(rootName) + "\\b[^>]*>", Pattern.DOTALL);
        Matcher m = rootOpen.matcher(xml);
        if (!m.find()) return false;
        int contentStart = m.end();
        // Find the matching close
        String closeTag = "</" + rootName + ">";
        int closeStart = xml.lastIndexOf(closeTag);
        if (closeStart < 0 || closeStart < contentStart) return false;
        String content = xml.substring(contentStart, closeStart);
        // Strip comments / PIs / CDATA so we only assess "real" content
        String stripped = content
                .replaceAll("(?s)<!--.*?-->", "")
                .replaceAll("(?s)<\\?[^?]*\\?>", "")
                .replaceAll("(?s)<!\\[CDATA\\[.*?\\]\\]>", "")
                .trim();
        // Empty if no remaining content of any kind
        return stripped.isEmpty();
    }

    /** Find the local name of the root element (the first non-prolog, non-comment tag). */
    private static String findRootElementName(String xml) {
        int idx = 0;
        while (idx < xml.length()) {
            int lt = xml.indexOf('<', idx);
            if (lt < 0) return null;
            if (xml.startsWith("<?", lt)) {
                int e = xml.indexOf("?>", lt + 2);
                idx = e < 0 ? xml.length() : e + 2;
                continue;
            }
            if (xml.startsWith("<!--", lt)) {
                int e = xml.indexOf("-->", lt + 4);
                idx = e < 0 ? xml.length() : e + 3;
                continue;
            }
            if (xml.startsWith("<!", lt)) {
                int e = xml.indexOf('>', lt);
                idx = e < 0 ? xml.length() : e + 1;
                continue;
            }
            // First real element
            int nameStart = lt + 1;
            int nameEnd = nameStart;
            while (nameEnd < xml.length()) {
                char c = xml.charAt(nameEnd);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '/' || c == '>') break;
                nameEnd++;
            }
            return xml.substring(nameStart, nameEnd);
        }
        return null;
    }

    /**
     * Remove attributes whose value is the unresolved marker.
     * Handles both attr="${blank}" and attr='${blank}'.
     */
    private static String removeAttributesWithMarker(String xml) {
        // Strip attr="<marker>" and attr='<marker>' (with optional surrounding whitespace).
        // Also strip leading space so we don't leave double spaces in the tag.
        String esc = Pattern.quote(UNRESOLVED_MARKER);
        return xml
                .replaceAll("\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*\"" + esc + "\"", "")
                .replaceAll("\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*'" + esc + "'", "");
    }

    /**
     * Remove elements whose entire content is the unresolved marker
     * (allowing surrounding whitespace).
     * Handles both <Tag>${blank}</Tag> and <Tag attr="x">${blank}</Tag>.
     * Also handles mixed-content cases where the marker appears anywhere
     * in the element's text content alongside other characters.
     */
    private static String removeElementsWithMarkerContent(String xml) {
        // Find an element opening, then locate its matching close, then check
        // whether the content contains a marker. Doing this with regex alone
        // can't handle nested same-named elements correctly, so we do a
        // manual scan.
        StringBuilder out = new StringBuilder(xml.length());
        int cursor = 0;
        while (cursor < xml.length()) {
            int lt = xml.indexOf('<', cursor);
            if (lt < 0) { out.append(xml, cursor, xml.length()); break; }

            // Skip non-element constructs: <!-- --> <? ?> <![CDATA[ ]]>
            if (xml.startsWith("<!--", lt)) {
                int end = xml.indexOf("-->", lt + 4);
                if (end < 0) end = xml.length();
                else end += 3;
                out.append(xml, cursor, end);
                cursor = end;
                continue;
            }
            if (xml.startsWith("<?", lt)) {
                int end = xml.indexOf("?>", lt + 2);
                if (end < 0) end = xml.length();
                else end += 2;
                out.append(xml, cursor, end);
                cursor = end;
                continue;
            }
            if (xml.startsWith("<![CDATA[", lt)) {
                int end = xml.indexOf("]]>", lt + 9);
                if (end < 0) end = xml.length();
                else end += 3;
                out.append(xml, cursor, end);
                cursor = end;
                continue;
            }
            if (xml.startsWith("</", lt)) {
                // Stray close tag at this level — emit and continue
                int gt = xml.indexOf('>', lt);
                if (gt < 0) { out.append(xml, cursor, xml.length()); break; }
                out.append(xml, cursor, gt + 1);
                cursor = gt + 1;
                continue;
            }

            // It's an element opening. Read its name.
            int nameStart = lt + 1;
            int nameEnd = nameStart;
            while (nameEnd < xml.length()) {
                char c = xml.charAt(nameEnd);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '/' || c == '>') break;
                nameEnd++;
            }
            int gt = xml.indexOf('>', nameEnd);
            if (gt < 0) { out.append(xml, cursor, xml.length()); break; }
            String fullName = xml.substring(nameStart, nameEnd);
            boolean selfClose = gt > 0 && xml.charAt(gt - 1) == '/';

            if (selfClose) {
                // <Tag attr=""/> — keep as-is (attributes already cleaned in prior pass)
                out.append(xml, cursor, gt + 1);
                cursor = gt + 1;
                continue;
            }

            int contentStart = gt + 1;
            int closeStart = findMatchingClose(xml, contentStart, fullName);
            if (closeStart < 0) {
                // Unbalanced — keep
                out.append(xml, cursor, xml.length());
                break;
            }
            int closeEnd = xml.indexOf('>', closeStart);
            if (closeEnd < 0) closeEnd = xml.length() - 1;
            String content = xml.substring(contentStart, closeStart);

            // Decision: drop this element if its content contains a marker AND
            //           it has no child elements (i.e. it's a leaf-with-text).
            // If it has child elements, keep the wrapper — the recursive
            // pruneEmptyParentElements pass will deal with cascading deletes.
            boolean hasMarker = content.contains(UNRESOLVED_MARKER);
            boolean hasChildElement = containsChildElement(content);

            if (hasMarker && !hasChildElement) {
                // Drop this whole element (and any preceding whitespace on its line
                // so we don't leave blank lines behind)
                int dropFrom = lt;
                // Walk backwards over spaces/tabs to the start of the line (keep newlines)
                while (dropFrom > cursor && (xml.charAt(dropFrom - 1) == ' ' || xml.charAt(dropFrom - 1) == '\t')) {
                    dropFrom--;
                }
                // Also drop the trailing newline if the element was alone on its line
                int dropTo = closeEnd + 1;
                if (dropTo < xml.length() && xml.charAt(dropTo) == '\n') dropTo++;
                out.append(xml, cursor, dropFrom);
                cursor = dropTo;
                continue;
            }

            // Keep the element opening and continue scanning its content
            out.append(xml, cursor, contentStart);
            cursor = contentStart;
        }
        return out.toString();
    }

    /**
     * Remove parent elements that have no remaining children and no text content.
     * After pruning leaf tags, parents may be left with only whitespace inside.
     * The root element is excluded — we keep an empty root rather than producing
     * an empty body (which servers reject with confusing EOF errors).
     */
    private static String removeEmptyParentElements(String xml, String rootName) {
        // Match <Tag ...> (whitespace only) </Tag>
        Pattern emptyTag = Pattern.compile(
                "<([A-Za-z_][\\w:.\\-]*)\\b[^>]*>\\s*</\\1>\\s*\\n?",
                Pattern.DOTALL);
        Matcher m = emptyTag.matcher(xml);
        StringBuilder result = new StringBuilder();
        while (m.find()) {
            String matchedName = m.group(1);
            if (rootName != null && rootName.equals(matchedName)) {
                // Don't remove the root — preserve as-is
                m.appendReplacement(result, Matcher.quoteReplacement(m.group()));
            } else {
                m.appendReplacement(result, "");
            }
        }
        m.appendTail(result);
        return result.toString();
    }

    /** Does the content contain a child element (not just text + whitespace)? */
    private static boolean containsChildElement(String content) {
        // Skip CDATA, comments, processing instructions when checking
        int i = 0;
        while (i < content.length()) {
            int lt = content.indexOf('<', i);
            if (lt < 0) return false;
            if (content.startsWith("<!--", lt)) {
                int end = content.indexOf("-->", lt + 4);
                if (end < 0) return false;
                i = end + 3;
                continue;
            }
            if (content.startsWith("<?", lt)) {
                int end = content.indexOf("?>", lt + 2);
                if (end < 0) return false;
                i = end + 2;
                continue;
            }
            if (content.startsWith("<![CDATA[", lt)) {
                int end = content.indexOf("]]>", lt + 9);
                if (end < 0) return false;
                i = end + 3;
                continue;
            }
            // Real element (open or close)
            return true;
        }
        return false;
    }

    /** Find the matching closing tag (respecting nesting). */
    private static int findMatchingClose(String xml, int start, String fullName) {
        int depth = 1;
        int idx = start;
        while (idx < xml.length()) {
            int lt = xml.indexOf('<', idx);
            if (lt < 0) return -1;
            if (xml.startsWith("<!--", lt)) {
                int e = xml.indexOf("-->", lt + 4);
                idx = e < 0 ? xml.length() : e + 3;
                continue;
            }
            if (xml.startsWith("<?", lt)) {
                int e = xml.indexOf("?>", lt + 2);
                idx = e < 0 ? xml.length() : e + 2;
                continue;
            }
            if (xml.startsWith("<![CDATA[", lt)) {
                int e = xml.indexOf("]]>", lt + 9);
                idx = e < 0 ? xml.length() : e + 3;
                continue;
            }
            boolean isClose = xml.startsWith("</", lt);
            int nameStart = lt + (isClose ? 2 : 1);
            int nameEnd = nameStart;
            while (nameEnd < xml.length()) {
                char c = xml.charAt(nameEnd);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '/' || c == '>') break;
                nameEnd++;
            }
            String name = xml.substring(nameStart, nameEnd);
            int gt = xml.indexOf('>', nameEnd);
            if (gt < 0) return -1;

            if (name.equals(fullName)) {
                if (isClose) {
                    depth--;
                    if (depth == 0) return lt;
                } else {
                    boolean selfClose = gt > 0 && xml.charAt(gt - 1) == '/';
                    if (!selfClose) depth++;
                }
            }
            idx = gt + 1;
        }
        return -1;
    }
}
