package com.apitest;

import com.apitest.template.TemplateEngine;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the pruning behavior: when a TestData column is blank or missing,
 * the corresponding tag/attribute should be removed from the rendered XML
 * rather than left as <Tag></Tag> (which often breaks XSD validation).
 */
class TemplatePruningTest {

    private static Map<String, String> data(String... kv) {
        Map<String, String> m = new HashMap<>();
        for (int i = 0; i < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return m;
    }

    private static String render(String template, Map<String, String> data) {
        return TemplateEngine.render(template, data, Map.of());
    }

    // ── Basic substitution still works ─────────────────────────────────────

    @Test
    void filledPlaceholdersBehaveNormally() {
        String t = "<r><a>${x}</a></r>";
        assertEquals("<r><a>hello</a></r>", render(t, data("x", "hello")));
    }

    @Test
    void multipleFieldsResolved() {
        String t = "<Order><Id>${id}</Id><Name>${n}</Name></Order>";
        String out = render(t, data("id", "1", "n", "Alice"));
        assertEquals("<Order><Id>1</Id><Name>Alice</Name></Order>", out);
    }

    // ── Single empty field drops the tag ───────────────────────────────────

    @Test
    void blankValueRemovesTag() {
        String t = "<r><a>${x}</a><b>${y}</b></r>";
        String out = render(t, data("x", "hello", "y", ""));
        assertEquals("<r><a>hello</a></r>", out);
    }

    @Test
    void missingColumnAlsoRemovesTag() {
        String t = "<r><a>${x}</a><b>${not_in_data}</b></r>";
        String out = render(t, data("x", "hello"));
        assertEquals("<r><a>hello</a></r>", out);
    }

    // ── Parent with all-blank children gets removed too ────────────────────

    @Test
    void parentWithAllChildrenBlankIsRemoved() {
        String t = "<Order>"
                + "<Id>${id}</Id>"
                + "<Customer>"
                + "<Name>${name}</Name>"
                + "<Phone>${phone}</Phone>"
                + "</Customer>"
                + "</Order>";
        String out = render(t, data("id", "1", "name", "", "phone", ""));
        assertEquals("<Order><Id>1</Id></Order>", out);
    }

    @Test
    void parentWithSomeChildrenKeepsParent() {
        String t = "<Order>"
                + "<Customer>"
                + "<Name>${name}</Name>"
                + "<Phone>${phone}</Phone>"
                + "</Customer>"
                + "</Order>";
        String out = render(t, data("name", "Alice", "phone", ""));
        // Customer kept (has Name), Phone removed
        assertTrue(out.contains("<Name>Alice</Name>"), "Should keep Name: " + out);
        assertFalse(out.contains("Phone"), "Should drop Phone: " + out);
        assertTrue(out.contains("<Customer>"), "Should keep Customer wrapper: " + out);
    }

    // ── Attributes with empty values are dropped ───────────────────────────

    @Test
    void emptyAttributeIsDropped() {
        String t = "<Order ref=\"${ref}\" type=\"${type}\"><x>1</x></Order>";
        String out = render(t, data("ref", "R-100", "type", ""));
        assertTrue(out.contains("ref=\"R-100\""), "Should keep ref: " + out);
        assertFalse(out.contains("type="), "Should drop type: " + out);
        assertTrue(out.contains("<x>1</x>"), "Should keep child: " + out);
    }

    @Test
    void allAttributesEmpty_ElementStillKept() {
        // The element still has content, so it survives even if all attrs drop
        String t = "<Order ref=\"${ref}\" type=\"${type}\"><x>1</x></Order>";
        String out = render(t, data("ref", "", "type", ""));
        assertTrue(out.contains("<x>1</x>"), out);
        assertFalse(out.contains("ref"), out);
        assertFalse(out.contains("type"), out);
    }

    // ── Mixed content with any blank drops the tag ─────────────────────────

    @Test
    void mixedContentWithAnyBlankDropsTag() {
        // When the dropped element is the only child of root, that's "every
        // placeholder unresolved" — the framework now throws to prevent
        // sending an empty request that would just confuse the server.
        String t = "<r><Note>Hello ${name}, your ID is ${id}</Note></r>";
        assertThrows(IllegalStateException.class,
                () -> render(t, data("name", "Alice", "id", "")),
                "Should throw when all root content is dropped");
    }

    @Test
    void mixedContentDropsButRootKeptIfOtherContentRemains() {
        // Mixed content inside one element drops THAT element, but if root
        // has other siblings, root is preserved
        String t = "<r><Other>data</Other><Note>Hello ${name}, your ID is ${id}</Note></r>";
        String out = render(t, data("name", "Alice", "id", ""));
        assertTrue(out.contains("<Other>data</Other>"), out);
        assertFalse(out.contains("Note"), "Note should be dropped: " + out);
    }

    // ── Required placeholders throw ────────────────────────────────────────

    @Test
    void requiredPlaceholderThrowsWhenBlank() {
        String t = "<r><id>${!order_id}</id></r>";
        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> render(t, data("order_id", "")));
        assertTrue(ex.getMessage().contains("Required placeholder"));
        assertTrue(ex.getMessage().contains("order_id"));
    }

    @Test
    void requiredPlaceholderResolvesNormallyWhenFilled() {
        String t = "<r><id>${!order_id}</id></r>";
        assertEquals("<r><id>X100</id></r>", render(t, data("order_id", "X100")));
    }

    // ── Empty root protection ──────────────────────────────────────────────

    @Test
    void allPlaceholdersUnresolvedThrowsHelpfulError() {
        // SOAP-like template — every field is a placeholder
        String t = "<soap:Envelope xmlns:soap=\"x\">"
                + "<soap:Body><Order><Id>${id}</Id></Order></soap:Body>"
                + "</soap:Envelope>";
        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> render(t, data()));
        assertTrue(ex.getMessage().contains("empty request body"),
                "Message: " + ex.getMessage());
        assertTrue(ex.getMessage().contains("soap:Envelope"),
                "Should name root element: " + ex.getMessage());
    }

    @Test
    void rootIsPreservedEvenIfAllInnerContentDrops() {
        // Same template but pruning the root would produce empty body.
        // The framework throws rather than silently sending nothing.
        String t = "<Order><Id>${id}</Id><Name>${name}</Name></Order>";
        assertThrows(IllegalStateException.class,
                () -> render(t, data("id", "", "name", "")));
    }

    // ── Realistic SOAP request ─────────────────────────────────────────────

    @Test
    void realisticSoapRequestWithSparseTestData() {
        String t = "<Order>\n"
                + "  <Id>${order_id}</Id>\n"
                + "  <Customer>\n"
                + "    <Name>${customer_name}</Name>\n"
                + "    <Phone>${customer_phone}</Phone>\n"
                + "    <Email>${customer_email}</Email>\n"
                + "  </Customer>\n"
                + "  <DeliveryDate>${delivery_date}</DeliveryDate>\n"
                + "  <Notes>${notes}</Notes>\n"
                + "</Order>";

        // Only fill in some columns
        Map<String, String> testData = data(
                "order_id", "123",
                "customer_name", "Alice",
                "customer_email", "alice@x.com"
                // customer_phone, delivery_date, notes intentionally absent
        );

        String out = render(t, testData);
        // Filled in:
        assertTrue(out.contains("<Id>123</Id>"), out);
        assertTrue(out.contains("<Name>Alice</Name>"), out);
        assertTrue(out.contains("<Email>alice@x.com</Email>"), out);
        // Dropped:
        assertFalse(out.contains("Phone"), "Phone should be dropped: " + out);
        assertFalse(out.contains("DeliveryDate"), "DeliveryDate should be dropped: " + out);
        assertFalse(out.contains("Notes"), "Notes should be dropped: " + out);
        // Customer wrapper kept (still has Name + Email):
        assertTrue(out.contains("<Customer>"), out);
    }

    // ── Static placeholders (now, uuid) keep working ───────────────────────

    @Test
    void staticPlaceholdersStillWork() {
        String t = "<r><time>${now}</time><id>${uuid}</id><blank>${x}</blank></r>";
        String out = render(t, data());
        assertTrue(out.contains("<time>"), out);
        assertTrue(out.contains("<id>"), out);
        assertFalse(out.contains("blank"), "blank tag should be dropped: " + out);
    }

    // ── Empty literal tags in the template are preserved ───────────────────

    @Test
    void literalEmptyTagInTemplateIsKept() {
        // The user wrote <Empty></Empty> deliberately — no placeholder involved
        String t = "<r><a>${x}</a><Empty></Empty></r>";
        String out = render(t, data("x", "1"));
        assertTrue(out.contains("<Empty></Empty>"),
                "Literal empty tag should be preserved: " + out);
    }

    // ── Non-XML body is unchanged ──────────────────────────────────────────

    @Test
    void jsonBodyIsNotPruned() {
        // For JSON, we don't prune — pass through with markers cleaned up
        String t = "{ \"name\": \"${name}\", \"phone\": \"${phone}\" }";
        String out = render(t, data("name", "Alice", "phone", ""));
        // Phone resolves to empty string (current behavior for non-XML)
        assertTrue(out.contains("\"name\": \"Alice\""), out);
    }
}
