# Security Review - API Test Suite (engine, server, GUI)

Reviewed: engine v2.13.2 (bundled), server v2.8.0 (single app), GUI v1.10.0.
Scope: code vulnerabilities, third-party dependency risks, secret handling, and
input-handling on the browser-facing surface.

## Summary

No blocking issues found. The controls that matter for a shared, browser-facing
tool on a mounted volume are present and covered by tests: path containment, no
process execution, XML parser hardening, secret masking, and output escaping.
Running the engine in-process keeps the subprocess attack surface at zero.

## 1. Dependencies

- GUI: `npm audit` reports 0 vulnerabilities across all dependencies. React 18,
  Vite 6, TanStack Query 5, Tailwind 3, TypeScript 5 are all current.
- Server: only two external dependencies, both Spring Boot starters
  (spring-boot-starter-web, spring-boot-starter-test). The engine is bundled as
  a local Maven artifact. Apache HttpClient (via the engine) is the only other
  runtime library of note.

## 2. Command execution

None. There is no Runtime.exec, ProcessBuilder, or shell invocation anywhere in
the engine or server. Merging the engine in-process removed the previous
subprocess boundary entirely, so there is no command-injection surface.

## 3. Path traversal

File access from the browser is confined. WorkspaceService.resolve() normalizes
every requested path and rejects anything that does not stay within its area
(candidate.startsWith(base)), so a crafted ../ path cannot read or write outside
the workspace. Upload names are validated against '.', '..', and empty.

## 4. XML parsing (XXE)

Every XML parser is hardened. DocumentBuilderFactory instances in the reporter,
comparator, and template engine all disable DOCTYPE declarations
(disallow-doctype-decl), external general and parameter entities, external DTD
loading, and enable secure processing. XXE is not exploitable through any of the
XML paths the tool exercises.

## 5. Output escaping (XSS)

The generated HTML report escapes all user-derived text (&, <, >, ", ') through a
single esc() helper applied at every interpolation point, so response bodies,
suite names, and assertion values cannot inject markup into the report.

## 6. Secret handling

Stored secrets (currently the assistant API key) are masked. The settings service
holds a MASKED set; masked keys are returned to the GUI as a placeholder and never
echoed back in plain text. When the GUI saves settings, the placeholder is
recognized and the stored value is preserved rather than overwritten. No secret is
written to logs.

## 7. Outbound requests (SSRF)

An API testing tool must send requests to the URLs its test author specifies; that
is the tool's purpose, not a flaw. The person writing a suite is the person running
it against their own targets, so there is no privilege boundary being crossed. The
assistant endpoint URL is set in settings by an administrator, not by arbitrary
request input.

## 8. Database assertions

The optional DB assertion feature runs SQL written by the test author against a
database they configure. It is guarded regardless: only SELECT/WITH queries are
permitted, stacked statements (a trailing ';') are rejected, the connection is set
read-only, and a 30-second query timeout bounds any runaway query. The SQL is
author-supplied, not attacker-supplied, so this is defense in depth rather than a
trust boundary.

## 9. Regular-expression assertions

The regex_match operator compiles an author-supplied pattern. A pathological
pattern would only slow the author's own run and is caught and reported as an
invalid regex. No external actor controls this input.

## 10. Deserialization / SQL injection in the app itself

No Java deserialization of untrusted input (ObjectInputStream, XMLDecoder) exists
anywhere. The server itself uses no database and builds no SQL, so it has no
injection surface of its own.

## 11. Denial of service

Uploads are capped at 50 MB (multipart limits in application.properties). Run
artifacts are compacted and gzipped after each run to bound disk growth.

## 12. TLS

Certificate verification is on by default. verify=false is available per
environment for development against self-signed endpoints; it is documented as
development-only and emits a runtime warning when used.

## Deployment note

The application has no built-in authentication by design; it is intended to run
behind an identity-aware proxy (see DEPLOYMENT_GCP.md). Do not expose it directly
to an untrusted network without an authenticating layer in front.
