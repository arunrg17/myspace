# API Test Suite

Excel-driven, multi-protocol API testing framework with structural response comparison.

## What it does

- Reads test cases from a single Excel file (`config/test_suite.xlsx`)
- Builds requests from templates using row data + variables from previous steps
- Sends requests over REST, SOAP, Fabric, or GCP
- Compares responses against expected files, other environments, or other protocols
- Ignores noisy fields like timestamps via XPath / JSONPath patterns
- Saves request and response files per test step
- Generates a self-contained HTML report with summary + drill-down

## Project layout

```
api-test-suite/
├── run.py                          # entry point
├── requirements.txt
├── config/
│   └── test_suite.xlsx             # all test definitions
├── templates/                      # request body templates with ${placeholders}
│   ├── create_order.xml
│   ├── update_order.xml
│   └── get_account.xml
├── expected/                       # expected response files for response_vs_expected mode
│   └── T002_create_order.xml
├── framework/
│   ├── excel_loader.py             # parses the Excel suite into config objects
│   ├── template_engine.py          # ${var} substitution
│   ├── dispatcher.py               # protocol clients (REST/SOAP/Fabric/GCP)
│   ├── comparator.py               # XML/JSON structural diff + cross-format
│   ├── runner.py                   # orchestrates the test run
│   └── reporter.py                 # HTML report generator
├── output/                         # per-run request/response files (auto-created)
└── reports/
    └── report.html                 # generated after each run
```

## Comparison modes

| Mode | What happens |
|---|---|
| `response_vs_expected` | Run the steps, compare the final response to the expected file |
| `env_vs_env` | Run the same steps on two environments, compare the responses |
| `protocol_vs_protocol` | Run on two different sources (e.g. SOAP and REST), compare normalized |
| `chain_only` | Run the steps in order without comparing — useful for setup/smoke |

## Template placeholders

| Placeholder | Source |
|---|---|
| `${col_name}` | A column on the TestData sheet matching the test |
| `${stepN.varname}` | A variable extracted from step N's response |
| `${env.NAME}` | The OS environment variable `NAME` |
| `${now}` | Current UTC ISO timestamp |
| `${uuid}` | Random UUID v4 |

## Ignoring noisy fields

The `IgnoreFields` sheet supports per-test or global (`TestID = *`) patterns:

- `xpath` — for XML responses, e.g. `//*[local-name()='timestamp']`
- `jsonpath` — for JSON responses, e.g. `$.metadata.requestTime`

Matched values are replaced with `__IGNORED__` before comparison.

## Run

```bash
pip install -r requirements.txt
python run.py
```

Optional flags:

```bash
python run.py --suite config/my_suite.xlsx --report reports/run_2026_05_11.html --name "Regression Run"
```

Exit code is `0` if all tests pass, `1` otherwise — works directly in CI/CD.

## Adding a new test

1. Add a row on the `TestSuite` sheet with a new `TestID` and pick a comparison mode
2. Add one or more rows on the `Steps` sheet with the same `TestID` (one row per HTTP call)
3. If steps need values, add a row on `TestData` with the variables
4. If steps post a body, add a template file under `templates/` and reference it on the step
5. If responses have noise, add ignore patterns to `IgnoreFields`

That's it — no code changes needed for new tests.
