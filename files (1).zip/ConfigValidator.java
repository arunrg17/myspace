package com.example;

import com.differ.*;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * ConfigValidator Example - Uses xml-json-differ as a library
 * 
 * This example validates configuration files by comparing them
 * against expected configurations.
 */
public class ConfigValidator {
    
    private DocumentParser parser;
    private DiffEngine engine;
    
    public ConfigValidator() {
        this.parser = new DocumentParser();
        this.engine = new DiffEngine();
    }
    
    /**
     * Validate that actual config matches expected config
     */
    public ValidationResult validateConfig(String expectedPath, 
                                          String actualPath) 
            throws Exception {
        // Read files
        String expected = Files.readString(Paths.get(expectedPath));
        String actual = Files.readString(Paths.get(actualPath));
        
        // Parse
        DiffNode expectedTree = parser.parse(expected, "");
        DiffNode actualTree = parser.parse(actual, "");
        
        // Compare
        DiffResult diff = engine.diff(expectedTree, actualTree);
        
        // Create result
        ValidationResult result = new ValidationResult();
        result.isValid = (diff.getRemoved() == 0 && diff.getModified() == 0);
        result.same = diff.getSame();
        result.added = diff.getAdded();
        result.removed = diff.getRemoved();
        result.modified = diff.getModified();
        
        return result;
    }
    
    /**
     * Get detailed validation report
     */
    public String getValidationReport(String expectedPath, 
                                      String actualPath) 
            throws Exception {
        ValidationResult result = validateConfig(expectedPath, actualPath);
        
        StringBuilder report = new StringBuilder();
        report.append("Configuration Validation Report\n");
        report.append("================================\n\n");
        report.append("Expected: ").append(expectedPath).append("\n");
        report.append("Actual:   ").append(actualPath).append("\n\n");
        report.append("Result:   ").append(result.isValid ? "✓ VALID" : "✗ INVALID").append("\n\n");
        report.append("Statistics:\n");
        report.append("  Same:     ").append(result.same).append("\n");
        report.append("  Added:    ").append(result.added).append("\n");
        report.append("  Removed:  ").append(result.removed).append("\n");
        report.append("  Modified: ").append(result.modified).append("\n");
        
        if (result.removed > 0) {
            report.append("\n⚠️  WARNING: ").append(result.removed)
                  .append(" expected fields are missing!\n");
        }
        if (result.modified > 0) {
            report.append("⚠️  WARNING: ").append(result.modified)
                  .append(" values differ from expected!\n");
        }
        if (result.added > 0) {
            report.append("ℹ️  INFO: ").append(result.added)
                  .append(" extra fields found (will be ignored).\n");
        }
        
        return report.toString();
    }
    
    // Simple result class
    public static class ValidationResult {
        public boolean isValid;
        public int same;
        public int added;
        public int removed;
        public int modified;
    }
    
    // Example usage
    public static void main(String[] args) throws Exception {
        ConfigValidator validator = new ConfigValidator();
        
        String expectedConfig = "config-expected.json";
        String actualConfig = "config-actual.json";
        
        System.out.println(validator.getValidationReport(
            expectedConfig, actualConfig));
    }
}
