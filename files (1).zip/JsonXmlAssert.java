package com.example.test;

import com.differ.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.Assert;

/**
 * JsonXmlAssert - JUnit helper for JSON/XML assertions
 * 
 * Use these assertions in your unit tests to compare JSON/XML files
 * and API responses.
 */
public class JsonXmlAssert {
    
    private static DocumentParser parser = new DocumentParser();
    private static DiffEngine engine = new DiffEngine();
    
    /**
     * Assert that two files are structurally identical
     */
    public static void assertFilesEqual(String file1, String file2) 
            throws Exception {
        assertFilesEqual(file1, file2, 
                        "Files should be identical");
    }
    
    /**
     * Assert with custom message
     */
    public static void assertFilesEqual(String file1, String file2, 
                                       String message) 
            throws Exception {
        String content1 = Files.readString(Paths.get(file1));
        String content2 = Files.readString(Paths.get(file2));
        
        DiffNode tree1 = parser.parse(content1, "");
        DiffNode tree2 = parser.parse(content2, "");
        
        DiffResult result = engine.diff(tree1, tree2);
        
        int differences = result.getAdded() + result.getRemoved() + 
                         result.getModified();
        
        Assert.assertEquals(message + 
                           "\nModified: " + result.getModified() +
                           "\nAdded: " + result.getAdded() +
                           "\nRemoved: " + result.getRemoved(),
                           0, differences);
    }
    
    /**
     * Assert same structure (ignores extra fields)
     */
    public static void assertSameStructure(String file1, String file2) 
            throws Exception {
        String content1 = Files.readString(Paths.get(file1));
        String content2 = Files.readString(Paths.get(file2));
        
        DiffNode tree1 = parser.parse(content1, "");
        DiffNode tree2 = parser.parse(content2, "");
        
        DiffResult result = engine.diff(tree1, tree2);
        
        // Allow added fields, but not removed or modified
        int differences = result.getRemoved() + result.getModified();
        
        Assert.assertEquals("Structure should match (extra fields OK)",
                           0, differences);
    }
    
    /**
     * Assert no unexpected fields were removed
     */
    public static void assertNoMissingFields(String expected, 
                                            String actual) 
            throws Exception {
        String expectedContent = Files.readString(Paths.get(expected));
        String actualContent = Files.readString(Paths.get(actual));
        
        DiffNode expectedTree = parser.parse(expectedContent, "");
        DiffNode actualTree = parser.parse(actualContent, "");
        
        DiffResult result = engine.diff(expectedTree, actualTree);
        
        Assert.assertEquals("Response missing expected fields",
                           0, result.getRemoved());
    }
    
    /**
     * Assert all values match (exact comparison)
     */
    public static void assertValuesEqual(String file1, String file2) 
            throws Exception {
        String content1 = Files.readString(Paths.get(file1));
        String content2 = Files.readString(Paths.get(file2));
        
        DiffNode tree1 = parser.parse(content1, "");
        DiffNode tree2 = parser.parse(content2, "");
        
        DiffResult result = engine.diff(tree1, tree2);
        
        Assert.assertEquals("Value mismatch",
                           0, result.getModified());
    }
    
    /**
     * Get difference report for debugging
     */
    public static String getDifferenceReport(String file1, 
                                            String file2) 
            throws Exception {
        String content1 = Files.readString(Paths.get(file1));
        String content2 = Files.readString(Paths.get(file2));
        
        DiffNode tree1 = parser.parse(content1, "");
        DiffNode tree2 = parser.parse(content2, "");
        
        DiffResult result = engine.diff(tree1, tree2);
        
        StringBuilder report = new StringBuilder();
        report.append("\n=== DIFFERENCE REPORT ===\n");
        report.append("File 1: ").append(file1).append("\n");
        report.append("File 2: ").append(file2).append("\n\n");
        report.append("Same:     ").append(result.getSame()).append("\n");
        report.append("Added:    ").append(result.getAdded()).append("\n");
        report.append("Removed:  ").append(result.getRemoved()).append("\n");
        report.append("Modified: ").append(result.getModified()).append("\n");
        report.append("=======================\n");
        
        return report.toString();
    }
    
    // Example JUnit test using these assertions
    public static class ExampleTests {
        
        // Test files must exist in test resources
        @org.junit.Test
        public void testConfigFilesMatch() throws Exception {
            JsonXmlAssert.assertFilesEqual(
                "src/test/resources/expected-config.json",
                "src/test/resources/actual-config.json"
            );
        }
        
        @org.junit.Test
        public void testApiResponseStructure() throws Exception {
            JsonXmlAssert.assertSameStructure(
                "src/test/resources/api-response-v1.json",
                "src/test/resources/api-response-v2.json"
            );
        }
        
        @org.junit.Test
        public void testNoMissingFields() throws Exception {
            JsonXmlAssert.assertNoMissingFields(
                "src/test/resources/expected-response.json",
                "src/test/resources/actual-response.json"
            );
        }
        
        @org.junit.Test
        public void testWithDetailedReport() throws Exception {
            try {
                JsonXmlAssert.assertValuesEqual(
                    "src/test/resources/expected.xml",
                    "src/test/resources/actual.xml"
                );
            } catch (AssertionError e) {
                String report = JsonXmlAssert.getDifferenceReport(
                    "src/test/resources/expected.xml",
                    "src/test/resources/actual.xml"
                );
                System.out.println(report);
                throw e;
            }
        }
    }
}
