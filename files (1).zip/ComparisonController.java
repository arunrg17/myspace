package com.example.controller;

import com.differ.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;

/**
 * ComparisonController - REST API for XML/JSON comparison
 * 
 * Spring Boot controller that exposes xml-json-differ as REST endpoints.
 * 
 * Endpoints:
 *   POST /api/compare        - Compare two content strings
 *   POST /api/compare/files  - Compare two files
 *   POST /api/report         - Generate HTML report
 */
@RestController
@RequestMapping("/api/compare")
public class ComparisonController {
    
    private final DocumentParser parser = new DocumentParser();
    private final DiffEngine engine = new DiffEngine();
    private final HtmlReportGenerator generator = new HtmlReportGenerator();
    
    /**
     * Compare two content strings
     */
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE,
                produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> compare(@RequestBody CompareRequest request) 
            throws Exception {
        DiffNode tree1 = parser.parse(request.content1, request.format1);
        DiffNode tree2 = parser.parse(request.content2, request.format2);
        
        DiffResult result = engine.diff(tree1, tree2);
        
        return ResponseEntity.ok(new CompareResponse(
            result.getSame(),
            result.getAdded(),
            result.getRemoved(),
            result.getModified(),
            calculateMatchPercentage(result)
        ));
    }
    
    /**
     * Compare two files (by content)
     */
    @PostMapping("/files")
    public ResponseEntity<?> compareFiles(
            @RequestParam String file1Content,
            @RequestParam String file2Content,
            @RequestParam(required = false, defaultValue = "") 
                String format1,
            @RequestParam(required = false, defaultValue = "") 
                String format2) throws Exception {
        
        CompareRequest req = new CompareRequest();
        req.content1 = file1Content;
        req.content2 = file2Content;
        req.format1 = format1.isEmpty() ? "" : format1;
        req.format2 = format2.isEmpty() ? "" : format2;
        
        return compare(req);
    }
    
    /**
     * Generate HTML report
     */
    @PostMapping("/report")
    public ResponseEntity<?> generateReport(
            @RequestBody ReportRequest request) throws Exception {
        
        DiffNode tree1 = parser.parse(request.content1, request.format1);
        DiffNode tree2 = parser.parse(request.content2, request.format2);
        
        DiffResult result = engine.diff(tree1, tree2);
        String html = generator.generate(result, 
                                        request.name1, 
                                        request.name2);
        
        return ResponseEntity.ok()
            .contentType(MediaType.TEXT_HTML)
            .body(html);
    }
    
    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<?> health() {
        return ResponseEntity.ok(new HealthResponse("OK", "xml-json-differ ready"));
    }
    
    // Helper method
    private double calculateMatchPercentage(DiffResult result) {
        int total = Math.max(result.getTotalLeft(), result.getTotalRight());
        if (total == 0) return 100.0;
        return (result.getSame() * 100.0) / total;
    }
    
    // Request/Response DTOs
    public static class CompareRequest {
        public String content1;
        public String content2;
        public String format1 = "";  // "xml", "json", or "" for auto-detect
        public String format2 = "";
    }
    
    public static class CompareResponse {
        public int same;
        public int added;
        public int removed;
        public int modified;
        public double matchPercentage;
        
        public CompareResponse(int same, int added, int removed, 
                             int modified, double match) {
            this.same = same;
            this.added = added;
            this.removed = removed;
            this.modified = modified;
            this.matchPercentage = match;
        }
    }
    
    public static class ReportRequest {
        public String content1;
        public String content2;
        public String format1 = "";
        public String format2 = "";
        public String name1 = "File 1";
        public String name2 = "File 2";
    }
    
    public static class HealthResponse {
        public String status;
        public String message;
        
        public HealthResponse(String status, String message) {
            this.status = status;
            this.message = message;
        }
    }
}

/**
 * Example usage:
 * 
 * curl -X POST http://localhost:8080/api/compare \
 *   -H "Content-Type: application/json" \
 *   -d '{
 *     "content1": "{\"key\": \"value\"}",
 *     "content2": "{\"key\": \"value\", \"extra\": \"field\"}",
 *     "format1": "json",
 *     "format2": "json"
 *   }'
 * 
 * Response:
 * {
 *   "same": 1,
 *   "added": 1,
 *   "removed": 0,
 *   "modified": 0,
 *   "matchPercentage": 50.0
 * }
 */
