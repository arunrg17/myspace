# xml-json-differ - Library Integration Guide

**Version:** 1.0.0  
**Purpose:** Using xml-json-differ JAR as a library in your Java projects

---

## Table of Contents

1. [Overview](#overview)
2. [Maven Integration](#maven-integration)
3. [Gradle Integration](#gradle-integration)
4. [Manual Classpath Integration](#manual-classpath-integration)
5. [API Usage Examples](#api-usage-examples)
6. [Common Use Cases](#common-use-cases)
7. [Error Handling](#error-handling)
8. [Performance Tuning](#performance-tuning)
9. [Best Practices](#best-practices)
10. [FAQ](#faq)

---

## Overview

### Why Use as a Library?

Instead of running xml-json-differ as a standalone CLI tool, you can:
- ✅ Call it programmatically from your Java code
- ✅ Integrate into existing applications
- ✅ Embed in frameworks and platforms
- ✅ Use in test suites and CI/CD
- ✅ Create custom comparison workflows
- ✅ Build on top of comparison logic

### Core Classes Exposed

```
com.differ.DocumentParser    - Parse XML/JSON into trees
com.differ.DiffNode          - Tree node data model
com.differ.DiffEngine        - Comparison algorithm
com.differ.DiffResult        - Results container
com.differ.HtmlReportGenerator - HTML report creation
```

---

## Maven Integration

### Step 1: Add JAR to Local Repository

```bash
# Copy JAR to your project
cp xml-json-differ.jar ./lib/

# Or install to local Maven repo
mvn install:install-file \
  -Dfile=xml-json-differ.jar \
  -DgroupId=com.differ \
  -DartifactId=xml-json-differ \
  -Dversion=1.0.0 \
  -Dpackaging=jar
```

### Step 2: Add Dependency to pom.xml

**Option A: Local Repository**
```xml
<dependencies>
    <dependency>
        <groupId>com.differ</groupId>
        <artifactId>xml-json-differ</artifactId>
        <version>1.0.0</version>
    </dependency>
    
    <!-- You'll also need the dependencies -->
    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-databind</artifactId>
        <version>2.14.0</version>
    </dependency>
    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-core</artifactId>
        <version>2.14.1</version>
    </dependency>
    <dependency>
        <groupId>com.fasterxml.jackson.core</groupId>
        <artifactId>jackson-annotations</artifactId>
        <version>2.14.0</version>
    </dependency>
    <dependency>
        <groupId>org.json</groupId>
        <artifactId>json</artifactId>
        <version>20231013</version>
    </dependency>
</dependencies>
```

**Option B: Fat JAR (All Dependencies Included)**
```xml
<dependency>
    <groupId>com.differ</groupId>
    <artifactId>xml-json-differ</artifactId>
    <version>1.0.0</version>
    <!-- Fat JAR includes all deps -->
</dependency>
```

### Step 3: Add to Classpath in pom.xml

```xml
<build>
    <plugins>
        <plugin>
            <groupId>org.apache.maven.plugins</groupId>
            <artifactId>maven-dependency-plugin</artifactId>
            <executions>
                <execution>
                    <phase>prepare-package</phase>
                    <goals>
                        <goal>copy-dependencies</goal>
                    </goals>
                    <configuration>
                        <outputDirectory>${project.build.directory}/lib</outputDirectory>
                    </configuration>
                </execution>
            </executions>
        </plugin>
    </plugins>
</build>
```

---

## Gradle Integration

### Step 1: Add to build.gradle

```gradle
repositories {
    // If using local maven repo
    mavenLocal()
    
    // Or copy to libs/
    flatDir {
        dirs 'libs'
    }
}

dependencies {
    // Local JAR file
    implementation files('libs/xml-json-differ.jar')
    
    // Or artifact reference
    implementation 'com.differ:xml-json-differ:1.0.0'
    
    // Dependencies (if not using fat JAR)
    implementation 'com.fasterxml.jackson.core:jackson-databind:2.14.0'
    implementation 'com.fasterxml.jackson.core:jackson-core:2.14.1'
    implementation 'com.fasterxml.jackson.core:jackson-annotations:2.14.0'
    implementation 'org.json:json:20231013'
}
```

### Step 2: Create Gradle Task

```gradle
task runDiffer {
    doLast {
        javaexec {
            main = 'com.differ.Main'
            classpath = sourceSets.main.runtimeClasspath
            args = ['file1.xml', 'file2.json', 'output.html']
        }
    }
}
```

---

## Manual Classpath Integration

### Compile and Run with JAR

```bash
# Compile your code with JAR in classpath
javac -cp xml-json-differ.jar:. MyDifferApp.java

# Run with JAR in classpath
java -cp xml-json-differ.jar:. MyDifferApp
```

### IDE Integration (Eclipse/IntelliJ)

**Eclipse:**
1. Right-click Project → Build Path → Configure Build Path
2. Add External JAR → xml-json-differ.jar
3. Check "Javadoc location" and "Source attachment" (optional)

**IntelliJ IDEA:**
1. File → Project Structure → Libraries
2. Click + → Java → Select xml-json-differ.jar
3. Right-click JAR → Attach Sources/Javadoc (optional)

---

## API Usage Examples

### Example 1: Basic Comparison

```java
import com.differ.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class MyDifferApp {
    public static void main(String[] args) throws Exception {
        // Read files
        String content1 = Files.readString(Paths.get("config-v1.json"));
        String content2 = Files.readString(Paths.get("config-v2.json"));
        
        // Parse
        DocumentParser parser = new DocumentParser();
        DiffNode tree1 = parser.parse(content1, "json");
        DiffNode tree2 = parser.parse(content2, "json");
        
        // Compare
        DiffEngine engine = new DiffEngine();
        DiffResult result = engine.diff(tree1, tree2);
        
        // Generate report
        HtmlReportGenerator gen = new HtmlReportGenerator();
        String html = gen.generate(result, "config-v1.json", "config-v2.json");
        
        // Save
        Files.write(Paths.get("comparison.html"), html.getBytes());
        
        // Print summary
        System.out.println("Same: " + result.getSame());
        System.out.println("Added: " + result.getAdded());
        System.out.println("Removed: " + result.getRemoved());
        System.out.println("Modified: " + result.getModified());
    }
}
```

### Example 2: In-Memory Processing

```java
public class ConfigValidator {
    
    private DocumentParser parser = new DocumentParser();
    private DiffEngine engine = new DiffEngine();
    
    public DiffResult validateConfig(String expected, String actual) 
            throws Exception {
        DiffNode expectedTree = parser.parse(expected, "json");
        DiffNode actualTree = parser.parse(actual, "json");
        return engine.diff(expectedTree, actualTree);
    }
    
    public boolean isConfigValid(String expected, String actual) 
            throws Exception {
        DiffResult result = validateConfig(expected, actual);
        return result.getRemoved() == 0 && result.getModified() == 0;
    }
    
    public void reportDifferences(String expected, String actual) 
            throws Exception {
        DiffResult result = validateConfig(expected, actual);
        if (result.getAdded() > 0) {
            System.out.println("WARNING: " + result.getAdded() + 
                             " unexpected fields found");
        }
        if (result.getModified() > 0) {
            System.out.println("ERROR: " + result.getModified() + 
                             " config values differ from expected");
        }
    }
}
```

### Example 3: Comparing XML Files

```java
public class XmlComparer {
    
    public static void compareAndReport(String file1, String file2) 
            throws Exception {
        // Read files
        String xml1 = Files.readString(Paths.get(file1));
        String xml2 = Files.readString(Paths.get(file2));
        
        // Parse XML
        DocumentParser parser = new DocumentParser();
        DiffNode tree1 = parser.parse(xml1, "xml");
        DiffNode tree2 = parser.parse(xml2, "xml");
        
        // Diff
        DiffEngine engine = new DiffEngine();
        DiffResult result = engine.diff(tree1, tree2);
        
        // Print results
        printDiffSummary(result, file1, file2);
        
        // Optionally generate HTML
        HtmlReportGenerator gen = new HtmlReportGenerator();
        String html = gen.generate(result, file1, file2);
        Files.write(Paths.get("xml-diff.html"), html.getBytes());
    }
    
    private static void printDiffSummary(DiffResult result, 
                                        String f1, String f2) {
        System.out.println("Comparison: " + f1 + " vs " + f2);
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        System.out.println("Same:      " + result.getSame());
        System.out.println("Added:     " + result.getAdded());
        System.out.println("Removed:   " + result.getRemoved());
        System.out.println("Modified:  " + result.getModified());
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    }
}
```

### Example 4: Cross-Format Comparison

```java
public class CrossFormatDiffer {
    
    public static void compareXmlToJson(String xmlPath, String jsonPath) 
            throws Exception {
        String xmlContent = Files.readString(Paths.get(xmlPath));
        String jsonContent = Files.readString(Paths.get(jsonPath));
        
        DocumentParser parser = new DocumentParser();
        DiffNode xmlTree = parser.parse(xmlContent, "xml");
        DiffNode jsonTree = parser.parse(jsonContent, "json");
        
        DiffEngine engine = new DiffEngine();
        DiffResult result = engine.diff(xmlTree, jsonTree);
        
        System.out.println("Cross-format comparison:");
        System.out.println("Structural differences: " + 
                         result.getModified());
        System.out.println("Value differences: " + 
                         (result.getAdded() + result.getRemoved()));
    }
}
```

### Example 5: Batch Processing

```java
public class BatchDiffer {
    
    public void compareBatch(String[] files1, String[] files2, 
                            String outputDir) throws Exception {
        DocumentParser parser = new DocumentParser();
        DiffEngine engine = new DiffEngine();
        HtmlReportGenerator gen = new HtmlReportGenerator();
        
        for (int i = 0; i < files1.length; i++) {
            String content1 = Files.readString(Paths.get(files1[i]));
            String content2 = Files.readString(Paths.get(files2[i]));
            
            DiffNode tree1 = parser.parse(content1, autoDetect(files1[i]));
            DiffNode tree2 = parser.parse(content2, autoDetect(files2[i]));
            
            DiffResult result = engine.diff(tree1, tree2);
            
            String html = gen.generate(result, files1[i], files2[i]);
            String outFile = outputDir + "/diff-" + i + ".html";
            Files.write(Paths.get(outFile), html.getBytes());
            
            System.out.println("✓ Processed: " + files1[i] + 
                             " vs " + files2[i]);
        }
    }
    
    private String autoDetect(String filename) {
        if (filename.endsWith(".xml")) return "xml";
        if (filename.endsWith(".json")) return "json";
        return "";  // Auto-detect
    }
}
```

---

## Common Use Cases

### Use Case 1: Test Assertion Library

```java
import org.junit.Assert;

public class XmlJsonAssert {
    
    public static void assertFilesEqual(String file1, String file2) 
            throws Exception {
        DocumentParser parser = new DocumentParser();
        DiffEngine engine = new DiffEngine();
        
        String content1 = Files.readString(Paths.get(file1));
        String content2 = Files.readString(Paths.get(file2));
        
        DiffNode tree1 = parser.parse(content1, "");
        DiffNode tree2 = parser.parse(content2, "");
        DiffResult result = engine.diff(tree1, tree2);
        
        Assert.assertEquals("Files should be identical", 
                           0, result.getModified() + 
                              result.getAdded() + 
                              result.getRemoved());
    }
    
    public static void assertSameStructure(String file1, String file2) 
            throws Exception {
        DocumentParser parser = new DocumentParser();
        DiffEngine engine = new DiffEngine();
        
        String content1 = Files.readString(Paths.get(file1));
        String content2 = Files.readString(Paths.get(file2));
        
        DiffNode tree1 = parser.parse(content1, "");
        DiffNode tree2 = parser.parse(content2, "");
        DiffResult result = engine.diff(tree1, tree2);
        
        Assert.assertEquals("No elements should be removed/added",
                           0, result.getAdded() + result.getRemoved());
    }
}
```

### Use Case 2: REST API Validation

```java
@RestController
@RequestMapping("/api/validate")
public class ValidationController {
    
    private DocumentParser parser = new DocumentParser();
    private DiffEngine engine = new DiffEngine();
    private HtmlReportGenerator gen = new HtmlReportGenerator();
    
    @PostMapping("/compare")
    public ResponseEntity<?> compareConfigs(
            @RequestParam String file1,
            @RequestParam String file2) throws Exception {
        
        String content1 = Files.readString(Paths.get(file1));
        String content2 = Files.readString(Paths.get(file2));
        
        DiffNode tree1 = parser.parse(content1, "");
        DiffNode tree2 = parser.parse(content2, "");
        
        DiffResult result = engine.diff(tree1, tree2);
        
        return ResponseEntity.ok(new ComparisonResponse(
            result.getSame(),
            result.getAdded(),
            result.getRemoved(),
            result.getModified()
        ));
    }
    
    @PostMapping("/report")
    public ResponseEntity<?> generateReport(
            @RequestBody ComparisonRequest req) throws Exception {
        
        DiffNode tree1 = parser.parse(req.content1, "");
        DiffNode tree2 = parser.parse(req.content2, "");
        
        DiffResult result = engine.diff(tree1, tree2);
        String html = gen.generate(result, req.name1, req.name2);
        
        return ResponseEntity.ok()
            .contentType(MediaType.TEXT_HTML)
            .body(html);
    }
}
```

### Use Case 3: Configuration Management

```java
public class ConfigurationValidator {
    
    public void validateDeployment(String expectedConfig, 
                                   String actualConfig) 
            throws Exception {
        DocumentParser parser = new DocumentParser();
        DiffEngine engine = new DiffEngine();
        
        DiffNode expected = parser.parse(expectedConfig, "json");
        DiffNode actual = parser.parse(actualConfig, "json");
        
        DiffResult result = engine.diff(expected, actual);
        
        if (result.getRemoved() > 0) {
            throw new ConfigurationException(
                "Configuration missing " + result.getRemoved() + 
                " required fields");
        }
        
        if (result.getModified() > 0) {
            throw new ConfigurationException(
                "Configuration has " + result.getModified() + 
                " incorrect values");
        }
        
        if (result.getAdded() > 0) {
            log.warn("Configuration has " + result.getAdded() + 
                    " extra fields that will be ignored");
        }
    }
}
```

---

## Error Handling

### Handling Parse Errors

```java
public class SafeDiffer {
    
    public Optional<DiffResult> safeDiff(String file1, String file2) {
        try {
            DocumentParser parser = new DocumentParser();
            DiffEngine engine = new DiffEngine();
            
            String content1 = Files.readString(Paths.get(file1));
            String content2 = Files.readString(Paths.get(file2));
            
            DiffNode tree1 = parser.parse(content1, "");
            DiffNode tree2 = parser.parse(content2, "");
            
            return Optional.of(engine.diff(tree1, tree2));
            
        } catch (IOException e) {
            System.err.println("File read error: " + e.getMessage());
            return Optional.empty();
        } catch (Exception e) {
            System.err.println("Parse error: " + e.getMessage());
            return Optional.empty();
        }
    }
    
    public DiffResult diffWithFallback(String file1, String file2) 
            throws Exception {
        try {
            DocumentParser parser = new DocumentParser();
            String content1 = Files.readString(Paths.get(file1));
            String content2 = Files.readString(Paths.get(file2));
            
            DiffNode tree1 = parser.parse(content1, "xml");
            DiffNode tree2 = parser.parse(content2, "xml");
            
            return new DiffEngine().diff(tree1, tree2);
            
        } catch (Exception xmlError) {
            // Fallback to JSON parsing
            DocumentParser parser = new DocumentParser();
            String content1 = Files.readString(Paths.get(file1));
            String content2 = Files.readString(Paths.get(file2));
            
            DiffNode tree1 = parser.parse(content1, "json");
            DiffNode tree2 = parser.parse(content2, "json");
            
            return new DiffEngine().diff(tree1, tree2);
        }
    }
}
```

---

## Performance Tuning

### Memory Management

```java
public class PerformantDiffer {
    
    public DiffResult diffLargeFiles(String file1, String file2) 
            throws Exception {
        // Increase JVM heap if needed
        // java -Xmx4g MyApp
        
        DocumentParser parser = new DocumentParser();
        DiffEngine engine = new DiffEngine();
        
        String content1 = Files.readString(Paths.get(file1));
        String content2 = Files.readString(Paths.get(file2));
        
        // Parse
        long startTime = System.currentTimeMillis();
        DiffNode tree1 = parser.parse(content1, "");
        DiffNode tree2 = parser.parse(content2, "");
        long parseTime = System.currentTimeMillis() - startTime;
        
        System.out.println("Parse time: " + parseTime + " ms");
        
        // Diff
        startTime = System.currentTimeMillis();
        DiffResult result = engine.diff(tree1, tree2);
        long diffTime = System.currentTimeMillis() - startTime;
        
        System.out.println("Diff time: " + diffTime + " ms");
        System.out.println("Total time: " + (parseTime + diffTime) + " ms");
        
        return result;
    }
}
```

### Parallel Processing

```java
public class ParallelDiffer {
    
    public void compareBatchParallel(List<FilePair> pairs, 
                                     String outputDir) 
            throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(4);
        
        for (FilePair pair : pairs) {
            executor.submit(() -> {
                try {
                    DocumentParser parser = new DocumentParser();
                    DiffEngine engine = new DiffEngine();
                    HtmlReportGenerator gen = new HtmlReportGenerator();
                    
                    String c1 = Files.readString(Paths.get(pair.file1));
                    String c2 = Files.readString(Paths.get(pair.file2));
                    
                    DiffNode t1 = parser.parse(c1, "");
                    DiffNode t2 = parser.parse(c2, "");
                    DiffResult result = engine.diff(t1, t2);
                    
                    String html = gen.generate(result, 
                                              pair.file1, pair.file2);
                    Files.write(Paths.get(outputDir + "/" + 
                               pair.name + ".html"), html.getBytes());
                    
                    System.out.println("✓ " + pair.name);
                } catch (Exception e) {
                    System.err.println("✗ " + pair.name + ": " + 
                                     e.getMessage());
                }
            });
        }
        
        executor.shutdown();
        executor.awaitTermination(10, TimeUnit.MINUTES);
    }
}
```

---

## Best Practices

### 1. Reuse Objects

```java
// ✅ GOOD: Reuse parser and engine
DocumentParser parser = new DocumentParser();
DiffEngine engine = new DiffEngine();

for (String filePair : filePairs) {
    DiffNode tree1 = parser.parse(content1, "json");
    DiffNode tree2 = parser.parse(content2, "json");
    DiffResult result = engine.diff(tree1, tree2);
    // ... process result
}

// ❌ BAD: Creating new objects each time
for (String filePair : filePairs) {
    DocumentParser p = new DocumentParser();  // Wasteful
    DiffEngine e = new DiffEngine();          // Wasteful
    // ...
}
```

### 2. Handle Large Files

```java
// For files > 100 MB
public DiffResult handleLargeFile(String file1, String file2) 
        throws Exception {
    // Increase heap: java -Xmx8g
    // Consider streaming approach for very large files
    
    DocumentParser parser = new DocumentParser();
    DiffEngine engine = new DiffEngine();
    
    String content1 = Files.readString(Paths.get(file1));
    String content2 = Files.readString(Paths.get(file2));
    
    // Parse and diff
    return engine.diff(
        parser.parse(content1, ""),
        parser.parse(content2, "")
    );
}
```

### 3. Format Detection

```java
// ✅ Auto-detect format
DiffNode tree = parser.parse(content, "");  // Detects JSON or XML

// ✅ Explicit format (faster)
DiffNode tree = parser.parse(content, "json");  // Specify explicitly

// ❌ Empty string if format ambiguous
DiffNode tree = parser.parse(content, "");  // Falls back to detection
```

### 4. Error Recovery

```java
public DiffResult safeCompare(String f1, String f2) {
    try {
        return new DiffEngine().diff(
            new DocumentParser().parse(
                Files.readString(Paths.get(f1)), ""),
            new DocumentParser().parse(
                Files.readString(Paths.get(f2)), "")
        );
    } catch (MalformedJsonException e) {
        log.error("Invalid JSON in " + f1 + ": " + e.getMessage());
        throw new ComparisonException("JSON parse error", e);
    } catch (SAXParseException e) {
        log.error("Invalid XML in " + f2 + ": " + e.getMessage());
        throw new ComparisonException("XML parse error", e);
    } catch (IOException e) {
        log.error("File read error: " + e.getMessage());
        throw new ComparisonException("I/O error", e);
    }
}
```

---

## FAQ

**Q: Can I use the JAR as a library?**  
A: Yes! All classes are public and can be called directly.

**Q: Do I need all dependencies?**  
A: No, the fat JAR has all dependencies bundled.

**Q: Can I extend the classes?**  
A: Yes, all classes are extensible (not final).

**Q: How do I handle large files?**  
A: Increase JVM heap: `java -Xmx4g MyApp`

**Q: Is thread-safe?**  
A: DocumentParser and DiffEngine are stateless (thread-safe).

**Q: Can I use in Spring/Quarkus/Micronaut?**  
A: Yes, just add to classpath and inject as beans.

**Q: What about custom HTML themes?**  
A: Subclass HtmlReportGenerator and override css() method.

**Q: Can I stream large files?**  
A: Current implementation loads files in memory. For streaming, extend DocumentParser.

---

## Example: Spring Boot Integration

```java
@Configuration
public class DifferConfiguration {
    
    @Bean
    public DocumentParser documentParser() {
        return new DocumentParser();
    }
    
    @Bean
    public DiffEngine diffEngine() {
        return new DiffEngine();
    }
    
    @Bean
    public HtmlReportGenerator htmlReportGenerator() {
        return new HtmlReportGenerator();
    }
}

@Service
public class ComparisonService {
    
    @Autowired
    private DocumentParser parser;
    
    @Autowired
    private DiffEngine engine;
    
    @Autowired
    private HtmlReportGenerator generator;
    
    public DiffResult compare(String content1, String content2) 
            throws Exception {
        DiffNode tree1 = parser.parse(content1, "");
        DiffNode tree2 = parser.parse(content2, "");
        return engine.diff(tree1, tree2);
    }
    
    public String generateReport(DiffResult result, 
                                 String name1, String name2) {
        return generator.generate(result, name1, name2);
    }
}
```

---

## Conclusion

xml-json-differ is designed to be used both as a CLI tool and as a library. All public APIs are stable and production-ready for integration into your Java applications.

For more information, see [API_DOCUMENTATION.md](API_DOCUMENTATION.md).
