# Changelog

All notable changes to the qTest Test Case Importer are documented here.

Versioning follows [Semantic Versioning](https://semver.org/):
- **MAJOR** version for incompatible or breaking changes
- **MINOR** version for new functionality in a backward-compatible manner
- **PATCH** version for backward-compatible bug fixes

## [2.1.0]

### Changed
- The configuration file is now shipped with the package as a ready-to-edit
  `qtest-config.properties`. The `generate-config` command has been removed, along
  with its supporting code, since the file is provided directly.
- Every method now carries a Javadoc comment describing its purpose, parameters,
  and return value, and inline comments explain the non-obvious logic.

### Removed
- `generate-config` command and the unused timestamp helper it relied on.

## [2.0.0]

### Added
- **Folder (module) management**:
  - `create-folder <path>` command creates a folder hierarchy in qTest
    (e.g. `"Regression\Sprint5"`), creating any missing parent folders.
  - `--folder <path>` option on `import` directs test cases into a specific folder.
  - `--create-folder` flag creates the target folder path if it does not exist.
- **Batch import** via `import-batch <manifest>`:
  - Imports multiple Excel/CSV files in one run.
  - Each file can target a different folder: create a new folder, use an existing
    folder, or import at the project root — specified per-file in the manifest.
  - Manifest format: `<file> | <action> | <folder path>` where action is
    `create`, `existing`, or `root`.
  - All files and folder targets are validated before any import begins.
  - A consolidated success/failure summary and error log is produced.
- Sample manifest file (`sample-manifest.txt`) included.

### Changed
- Internal import pipeline refactored to return structured results, enabling
  aggregation across multiple files in batch mode.
- Module lookups now query qTest level-by-level for accurate path resolution.

## [1.1.1]

### Fixed
- **Test step ordering rejected by qTest** ("testSteps[0].order should be greater
  than 1"). The qTest API expects step order to start at 1, not 0. Reverted to
  1-based ordering and made it configurable via `import.step.start.order` (default 1)
  so instances expecting zero-based ordering can override it without code changes.

## [1.1.0]

### Fixed
- **Excel (.xlsx) reading failure** — The shaded JAR was missing the OOXML
  `WorkbookProvider` service registration because competing `META-INF/services`
  files from POI's modules overwrote each other during packaging. Added the
  Maven Shade `ServicesResourceTransformer` to merge them. Both `.xls` and
  `.xlsx` now work from the fat JAR.
- **log4j `NoClassDefFoundError` at startup** — Replaced the previous log4j-api
  exclusion (which broke POI's class loading) with the `log4j-to-slf4j` bridge
  routed to `slf4j-nop`. The vulnerable `log4j-core` remains absent.

### Changed
- **Test step ordering** — Steps are now zero-indexed to match qTest's internal
  ordering. ALM exports starting at step 1 are automatically shifted so the first
  step becomes order 0.

## [1.0.0]

### Added
- Initial release.
- Bulk import of test cases from ALM-exported Excel/CSV into qTest.
- OAuth authentication via `POST /oauth/token` using standard user credentials.
- ALM multi-row-per-test-case grouping (metadata in first row, steps across rows).
- Configurable field mapping via properties file.
- Automatic dropdown value resolution by label.
- Multi-value field support (array wrapping).
- Dry-run validation mode with sample payload output.
- Batch import with configurable size and delay.
- Per-record error logging.
- Discovery commands: `list-projects`, `list-fields`, `list-modules`.
