package com.migration.qtest;

import com.google.gson.*;
import org.apache.poi.ss.usermodel.*;

import javax.net.ssl.*;
import java.io.*;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Command-line utility for bulk-importing test cases from ALM-exported Excel/CSV
 * files into qTest Manager via its REST API.
 *
 * <p>Key behaviour:
 * <ul>
 *   <li>Reads ALM's multi-row-per-test-case export format, where the first row of
 *       each test case carries all metadata (name, description, status, etc.) and
 *       the following rows carry only step-level data.</li>
 *   <li>Maps Excel columns to qTest fields using a configuration file.</li>
 *   <li>Resolves dropdown values by label and creates folder hierarchies on demand.</li>
 *   <li>Authenticates with standard qTest user credentials (no admin access needed)
 *       via the OAuth token endpoint.</li>
 * </ul>
 *
 * <p>The whole tool is intentionally a single class so it is easy to review, build,
 * and hand off. Sections are separated by banner comments below.
 */
public class QTestImporter {

    private static final String VERSION = "2.1.0";
    private static final int HTTP_TIMEOUT_SECONDS = 30;
    private static final String DEFAULT_CONFIG = "qtest-config.properties";

    // ---- Runtime configuration (populated from the config file) ----
    private String baseUrl;
    private String token;
    private String tokenType;
    private long projectId;
    private Long parentModuleId;
    private boolean skipSsl;
    private int batchSize = 10;
    private int batchDelayMs = 500;
    private int stepStartOrder = 1;
    private HttpClient httpClient;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    /** qTest field definitions for the target project, loaded once per run. */
    private List<FieldDef> fieldDefs;

    /**
     * Fallback column-to-field mapping, used only if the config file contains no
     * {@code mapping.*} entries at all. Normally the config file is authoritative.
     */
    private static final Map<String, String> DEFAULT_MAPPING = new LinkedHashMap<>();
    static {
        DEFAULT_MAPPING.put("Test Case Name", "name");
        DEFAULT_MAPPING.put("Description", "description");
        DEFAULT_MAPPING.put("Prerequisites", "precondition");
        DEFAULT_MAPPING.put("Status", "Status");
        DEFAULT_MAPPING.put("Priority", "Priority");
        DEFAULT_MAPPING.put("Test Type", "Type");
        DEFAULT_MAPPING.put("Automation", "Automation");
        DEFAULT_MAPPING.put("Step Description", "step.description");
        DEFAULT_MAPPING.put("Expected Result", "step.expected");
        DEFAULT_MAPPING.put("Step Name", "step.name");
    }

    // ========================================================================
    // Entry Point
    // ========================================================================

    /**
     * Program entry point. Dispatches the first argument to the matching command.
     * Any exception is reported as an error and exits with a non-zero status.
     *
     * @param args command name followed by command-specific arguments and options
     */
    public static void main(String[] args) {
        printBanner();
        if (args.length < 1) { printUsage(); System.exit(1); }

        QTestImporter app = new QTestImporter();
        String command = args[0].toLowerCase();

        try {
            switch (command) {
                case "login":
                    app.runLogin(args);
                    break;
                case "test-connection":
                    app.initFromConfig(args);
                    app.testConnection();
                    break;
                case "list-projects":
                    app.initFromConfig(args);
                    app.listProjects();
                    break;
                case "list-fields":
                    app.initFromConfig(args);
                    app.listFields();
                    break;
                case "list-modules":
                    app.initFromConfig(args);
                    app.listModules();
                    break;
                case "create-folder":
                    requireArg(args, "create-folder <folderPath>");
                    app.runCreateFolder(args);
                    break;
                case "dry-run":
                    requireArg(args, "dry-run <file.xlsx|csv>");
                    app.runDryRun(args);
                    break;
                case "import":
                    requireArg(args, "import <file.xlsx|csv>");
                    app.runImport(args);
                    break;
                case "import-batch":
                    requireArg(args, "import-batch <manifest>");
                    app.runImportBatch(args);
                    break;
                default:
                    log("ERROR", "Unknown command: " + command);
                    printUsage();
                    System.exit(1);
            }
        } catch (Exception e) {
            log("ERROR", e.getMessage());
            System.exit(1);
        }
    }

    /**
     * Ensures a command was given a positional argument; otherwise prints usage and exits.
     *
     * @param args  the full argument array
     * @param usage short usage hint shown on error
     */
    private static void requireArg(String[] args, String usage) {
        if (args.length < 2) {
            log("ERROR", "Usage: " + usage);
            System.exit(1);
        }
    }

    // ========================================================================
    // Configuration
    // ========================================================================

    /**
     * Loads the configuration file and populates all runtime settings, then builds
     * the HTTP client. When the auth type is {@code password}, this also performs
     * the login and stores the resulting bearer token for the rest of the run.
     *
     * @param args the argument array (scanned for an optional {@code --config} path)
     * @throws Exception if the config file is missing or a required value is absent
     */
    private void initFromConfig(String[] args) throws Exception {
        String configFile = findConfigArg(args);
        Properties props = loadProps(configFile);

        baseUrl = requireProp(props, "qtest.url").replaceAll("/+$", "");
        tokenType = props.getProperty("qtest.token.type", "bearer").trim();
        skipSsl = "true".equalsIgnoreCase(props.getProperty("qtest.skip.ssl", "false").trim());

        String pid = props.getProperty("qtest.project.id", "").trim();
        if (!pid.isEmpty()) projectId = Long.parseLong(pid);

        String mid = props.getProperty("qtest.module.id", "").trim();
        if (!mid.isEmpty()) parentModuleId = Long.parseLong(mid);

        batchSize = Math.max(1, Integer.parseInt(props.getProperty("import.batch.size", "10").trim()));
        batchDelayMs = Math.max(0, Integer.parseInt(props.getProperty("import.batch.delay.ms", "500").trim()));
        stepStartOrder = Integer.parseInt(props.getProperty("import.step.start.order", "1").trim());

        buildHttpClient();

        if ("password".equalsIgnoreCase(tokenType)) {
            String user = requireProp(props, "qtest.username");
            String pass = requireProp(props, "qtest.password");
            log("INFO", "Authenticating as " + user + "...");
            token = loginAndGetToken(user, pass);
            tokenType = "bearer";
            log("OK", "Authentication successful.");
        } else {
            token = requireProp(props, "qtest.token");
        }
    }

    /**
     * Returns the config file path from a {@code --config} option, or the default
     * file name if the option is not present.
     *
     * @param args the argument array
     * @return the config file path to use
     */
    private String findConfigArg(String[] args) {
        String v = findOptionValue(args, "--config");
        return v != null ? v : DEFAULT_CONFIG;
    }

    /**
     * Returns the value that follows a named option (for example, the path after
     * {@code --folder}), or {@code null} if the option is absent or has no value.
     *
     * @param args       the argument array
     * @param optionName the option flag to look for
     * @return the following value, or {@code null}
     */
    private String findOptionValue(String[] args, String optionName) {
        for (int i = 0; i < args.length - 1; i++) {
            if (optionName.equals(args[i])) return args[i + 1];
        }
        return null;
    }

    /**
     * Returns {@code true} if a standalone flag (for example {@code --create-folder})
     * appears anywhere in the argument array.
     *
     * @param args     the argument array
     * @param flagName the flag to look for
     * @return whether the flag is present
     */
    private boolean hasFlag(String[] args, String flagName) {
        for (String a : args) if (flagName.equals(a)) return true;
        return false;
    }

    /**
     * Loads a properties file from disk.
     *
     * @param path the file path
     * @return the parsed {@link Properties}
     * @throws Exception if the file does not exist or cannot be read
     */
    private Properties loadProps(String path) throws Exception {
        File f = new File(path);
        if (!f.exists()) {
            throw new Exception("Config file not found: " + path
                + "\nEdit the bundled " + DEFAULT_CONFIG + " or pass one with --config <file>.");
        }
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(f)) { props.load(fis); }
        return props;
    }

    /**
     * Reads a required property, trimming whitespace.
     *
     * @param p   the properties
     * @param key the property key
     * @return the non-empty value
     * @throws Exception if the value is missing or blank
     */
    private String requireProp(Properties p, String key) throws Exception {
        String v = p.getProperty(key, "").trim();
        if (v.isEmpty()) throw new Exception("Missing required property: " + key);
        return v;
    }

    // ========================================================================
    // HTTP Client & Authentication
    // ========================================================================

    /**
     * Builds the shared {@link HttpClient}. When {@code qtest.skip.ssl} is enabled,
     * installs a trust-all SSL context so self-signed certificates are accepted.
     *
     * @throws Exception if the SSL context cannot be initialised
     */
    private void buildHttpClient() throws Exception {
        HttpClient.Builder builder = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .followRedirects(HttpClient.Redirect.NORMAL);

        if (skipSsl) {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                public void checkClientTrusted(X509Certificate[] c, String a) {}
                public void checkServerTrusted(X509Certificate[] c, String a) {}
            }}, new SecureRandom());
            builder.sslContext(sc);
        }
        httpClient = builder.build();
    }

    /**
     * Authenticates against the qTest OAuth token endpoint using a username and
     * password and returns the resulting access token.
     *
     * <p>The {@code Authorization} header is {@code Basic base64(siteName + ":")},
     * where the site name is derived from the configured URL. The request body uses
     * the OAuth password grant.
     *
     * @param username the qTest login (usually an email address)
     * @param password the qTest password
     * @return the access token to use as a bearer token
     * @throws Exception if the request fails or the response has no access token
     */
    private String loginAndGetToken(String username, String password) throws Exception {
        String siteName = extractSiteName(baseUrl);
        String basicAuth = "Basic " + Base64.getEncoder()
            .encodeToString((siteName + ":").getBytes(StandardCharsets.UTF_8));

        String formBody = "grant_type=password"
            + "&username=" + URLEncoder.encode(username, StandardCharsets.UTF_8)
            + "&password=" + URLEncoder.encode(password, StandardCharsets.UTF_8);

        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + "/oauth/token"))
            .header("Content-Type", "application/x-www-form-urlencoded")
            .header("Authorization", basicAuth)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .POST(HttpRequest.BodyPublishers.ofString(formBody))
            .build();

        HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() < 200 || resp.statusCode() >= 300) {
            throw new Exception("Authentication failed (HTTP " + resp.statusCode() + "): "
                + truncate(resp.body(), 300));
        }

        JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
        if (!json.has("access_token")) {
            throw new Exception("Response missing access_token: " + truncate(resp.body(), 300));
        }
        return json.get("access_token").getAsString();
    }

    /**
     * Derives the qTest site name from a base URL. For example,
     * {@code https://myorg.qtestnet.com} yields {@code myorg}.
     *
     * @param url the configured base URL
     * @return the leading host label, or the host itself if it has no dot
     */
    private String extractSiteName(String url) {
        try {
            String host = URI.create(url).getHost();
            if (host != null && host.contains(".")) return host.substring(0, host.indexOf("."));
            return host != null ? host : "";
        } catch (Exception e) {
            return url.replaceAll("https?://", "").split("[./:]")[0];
        }
    }

    /**
     * Performs an authenticated GET request against the qTest API.
     *
     * @param path the API path (appended to the base URL)
     * @return the response body
     * @throws Exception on a non-2xx response or transport error
     */
    private String httpGet(String path) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + path))
            .header("Accept", "application/json")
            .header("Authorization", "bearer " + token)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .GET().build();
        HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
        checkResponse(resp);
        return resp.body();
    }

    /**
     * Performs an authenticated POST request with a JSON body against the qTest API.
     *
     * @param path the API path (appended to the base URL)
     * @param body the JSON request body
     * @return the response body
     * @throws Exception on a non-2xx response or transport error
     */
    private String httpPost(String path, String body) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create(baseUrl + path))
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .header("Authorization", "bearer " + token)
            .timeout(Duration.ofSeconds(HTTP_TIMEOUT_SECONDS))
            .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
            .build();
        HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
        checkResponse(resp);
        return resp.body();
    }

    /**
     * Throws an exception if the HTTP response status is outside the 2xx range.
     *
     * @param resp the HTTP response to check
     * @throws Exception describing the status code and truncated body
     */
    private void checkResponse(HttpResponse<String> resp) throws Exception {
        int code = resp.statusCode();
        if (code >= 200 && code < 300) return;
        throw new Exception("HTTP " + code + ": " + truncate(resp.body(), 500));
    }

    // ========================================================================
    // Commands: Login & Discovery
    // ========================================================================

    /**
     * Interactive login command. Reads credentials from the config file or prompts
     * for any that are missing, obtains a bearer token, prints it, and optionally
     * writes it back into the config file.
     *
     * @param args the argument array (scanned for an optional {@code --config} path)
     * @throws Exception if login fails
     */
    private void runLogin(String[] args) throws Exception {
        String configFile = findConfigArg(args);
        Properties props = loadProps(configFile);
        baseUrl = requireProp(props, "qtest.url").replaceAll("/+$", "");
        skipSsl = "true".equalsIgnoreCase(props.getProperty("qtest.skip.ssl", "false").trim());
        buildHttpClient();

        String user = props.getProperty("qtest.username", "").trim();
        String pass = props.getProperty("qtest.password", "").trim();

        if (user.isEmpty()) { System.out.print("  Username (email): "); user = readLine(); }
        if (pass.isEmpty()) {
            if (System.console() != null) {
                pass = new String(System.console().readPassword("  Password: "));
            } else {
                System.out.print("  Password: "); pass = readLine();
            }
        }

        String accessToken = loginAndGetToken(user, pass);
        log("OK", "Login successful. Bearer token:");
        System.out.println("\n  " + accessToken + "\n");

        System.out.print("  Save token to " + configFile + "? (y/n): ");
        if ("y".equalsIgnoreCase(readLine())) {
            String content = Files.readString(Path.of(configFile));
            content = content.replaceAll("(?m)^qtest\\.token\\.type=.*$", "qtest.token.type=bearer");
            content = content.replaceAll("(?m)^qtest\\.token=.*$", "qtest.token=" + accessToken);
            Files.writeString(Path.of(configFile), content);
            log("OK", "Saved to " + configFile);
        }
    }

    /**
     * Verifies connectivity and credentials by listing the accessible projects.
     *
     * @throws Exception if the request fails
     */
    private void testConnection() throws Exception {
        log("INFO", "Connecting to " + baseUrl + (skipSsl ? " (SSL skip)" : ""));
        JsonArray projects = JsonParser.parseString(httpGet("/api/v3/projects")).getAsJsonArray();
        log("OK", "Connected. " + projects.size() + " project(s) accessible.");
    }

    /**
     * Prints all projects the authenticated user can access, with their IDs.
     *
     * @throws Exception if the request fails
     */
    private void listProjects() throws Exception {
        JsonArray projects = JsonParser.parseString(httpGet("/api/v3/projects")).getAsJsonArray();
        log("INFO", projects.size() + " project(s):");
        System.out.println();
        System.out.printf("  %-12s %-50s%n", "ID", "NAME");
        System.out.printf("  %-12s %-50s%n", "----------", "----");
        for (JsonElement el : projects) {
            JsonObject p = el.getAsJsonObject();
            System.out.printf("  %-12s %-50s%n", getJsonVal(p, "id"), truncate(getJsonVal(p, "name"), 48));
        }
        System.out.println();
    }

    /**
     * Prints the test case fields for the configured project: the built-in fields
     * that can be mapped directly, followed by the project-specific fields with
     * their IDs, required/multi flags, and allowed dropdown values.
     *
     * @throws Exception if the project is not set or the request fails
     */
    private void listFields() throws Exception {
        requireProject();
        fieldDefs = fetchFieldDefs();
        log("INFO", "Test case fields for project " + projectId + ":\n");

        System.out.println("  BUILT-IN FIELDS (use these as mapping targets directly):");
        System.out.println("  -------------------------------------------------------");
        System.out.printf("  %-25s  %s%n", "name", "Test case title (REQUIRED)");
        System.out.printf("  %-25s  %s%n", "description", "Description text");
        System.out.printf("  %-25s  %s%n", "precondition", "Precondition text");
        System.out.printf("  %-25s  %s%n", "step.description", "Step action text");
        System.out.printf("  %-25s  %s%n", "step.expected", "Step expected result");

        System.out.println("\n  PROJECT FIELDS (use the LABEL as mapping target):");
        System.out.println("  -------------------------------------------------");
        System.out.printf("  %-10s %-30s %-6s %-6s %s%n", "FIELD_ID", "LABEL", "REQ?", "MULTI", "ALLOWED VALUES");
        System.out.printf("  %-10s %-30s %-6s %-6s %s%n", "--------", "-----", "----", "-----", "--------------");
        for (FieldDef fd : fieldDefs) {
            String vals = fd.allowedValues.stream()
                .map(v -> v.label + "(" + v.value + ")")
                .collect(Collectors.joining(", "));
            System.out.printf("  %-10s %-30s %-6s %-6s %s%n",
                fd.id, truncate(fd.label, 28),
                fd.required ? "YES" : "", fd.multiple ? "YES" : "",
                vals.isEmpty() ? "(free text)" : vals);
        }
        System.out.println("\n  Config example: mapping.Status=Status");
        System.out.println("  Values auto-resolve by label (e.g. 'High' -> 724).\n");
    }

    /**
     * Prints the module (folder) hierarchy for the configured project.
     *
     * @throws Exception if the project is not set or the request fails
     */
    private void listModules() throws Exception {
        requireProject();
        JsonArray modules = JsonParser.parseString(
            httpGet("/api/v3/projects/" + projectId + "/modules")).getAsJsonArray();
        log("INFO", "Module tree for project " + projectId + ":\n");
        printModuleTree(modules, 1);
        System.out.println();
    }

    /**
     * Recursively prints a module tree with indentation.
     *
     * @param modules the modules at the current level
     * @param depth   the current indentation depth (1-based)
     */
    private void printModuleTree(JsonArray modules, int depth) {
        for (JsonElement el : modules) {
            JsonObject m = el.getAsJsonObject();
            System.out.printf("%s%-8s %s%n", "  ".repeat(depth), getJsonVal(m, "id"), getJsonVal(m, "name"));
            if (m.has("children") && m.get("children").isJsonArray()) {
                printModuleTree(m.getAsJsonArray("children"), depth + 1);
            }
        }
    }

    /**
     * Ensures a project ID has been configured before running a project-scoped command.
     *
     * @throws Exception if {@code qtest.project.id} is not set
     */
    private void requireProject() throws Exception {
        if (projectId == 0) throw new Exception("Set qtest.project.id in config. Run 'list-projects' to find it.");
    }

    // ========================================================================
    // Commands: Dry Run & Import
    // ========================================================================

    /**
     * Validates an input file without writing anything to qTest. Reads the file,
     * applies the mapping, builds test cases, validates each one, and prints a
     * summary plus a sample JSON payload for the first test case.
     *
     * @param args the argument array; {@code args[1]} is the input file path
     * @throws Exception if setup or file reading fails
     */
    private void runDryRun(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        log("INFO", "Loading field definitions...");
        fieldDefs = fetchFieldDefs();

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());

        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<TestCase> testCases = buildTestCases(headers, dataRows, mapping);

        System.out.println();
        log("DRY-RUN", "Validating " + testCases.size() + " test case(s)...\n");

        int valid = 0, invalid = 0;
        for (int i = 0; i < testCases.size(); i++) {
            TestCase tc = testCases.get(i);
            List<String> errors = validate(tc);
            if (errors.isEmpty()) {
                valid++;
                System.out.printf("  [%3d] OK   %-50s  %d step(s)%n",
                    i + 1, truncate(tc.name, 48), tc.steps.size());
            } else {
                invalid++;
                System.out.printf("  [%3d] FAIL %s%n", i + 1, truncate(tc.name, 55));
                errors.forEach(err -> System.out.println("           - " + err));
            }
        }

        System.out.println();
        log("DRY-RUN", "Valid: " + valid + "  Invalid: " + invalid + "  Total: " + testCases.size());

        if (!testCases.isEmpty()) {
            System.out.println();
            log("INFO", "Sample JSON payload (first test case):");
            System.out.println(gson.toJson(buildPayload(testCases.get(0))));
        }
    }

    /**
     * Imports test cases from a single file. Resolves an optional target folder
     * (creating it when {@code --create-folder} is supplied), builds the test cases,
     * asks for confirmation, then performs the import.
     *
     * @param args the argument array; {@code args[1]} is the input file path.
     *             Recognised options: {@code --folder <path>}, {@code --create-folder}.
     * @throws Exception if setup, folder resolution, or file reading fails
     */
    private void runImport(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        log("INFO", "Loading field definitions...");
        fieldDefs = fetchFieldDefs();

        // Determine the target folder: --folder overrides the config's qtest.module.id.
        Long targetModule = parentModuleId;
        String folderPath = findOptionValue(args, "--folder");
        boolean createFolder = hasFlag(args, "--create-folder");
        if (folderPath != null) {
            targetModule = createFolder
                ? resolveOrCreateModulePath(folderPath)
                : resolveModulePath(folderPath);
        }

        List<String[]> allRows = readFile(args[1]);
        if (allRows.size() < 2) throw new Exception("File has no data rows");
        String[] headers = allRows.get(0);
        List<String[]> dataRows = allRows.subList(1, allRows.size());

        Map<String, String> mapping = resolveMapping(headers, loadMappingFromFile(findConfigArg(args)));
        printMappingSummary(headers, mapping);

        List<TestCase> testCases = buildTestCases(headers, dataRows, mapping);

        System.out.println();
        log("CONFIRM", "Import " + testCases.size() + " test case(s) into project " + projectId + "?");
        if (targetModule != null) log("INFO", "Target module ID: " + targetModule);
        System.out.print("  Type 'yes' to proceed: ");
        if (!"yes".equalsIgnoreCase(readLine())) { log("INFO", "Aborted."); return; }

        ImportResult result = executeImport(testCases, targetModule);
        reportResult(result);
    }

    /**
     * Imports several files in one run, driven by a manifest file. Each manifest
     * line maps one input file to a folder action:
     *
     * <pre>
     *   &lt;file path&gt; | &lt;action&gt; | &lt;folder path&gt;
     * </pre>
     *
     * Actions are {@code create} (create the folder path and any missing parents),
     * {@code existing} (folder must already exist), or {@code root} (no folder).
     * Lines beginning with {@code #} are comments and blank lines are ignored.
     *
     * <p>All files and folder targets are validated up front, so a bad entry stops
     * the run before any data is written. A file-level failure during import is
     * logged and does not abort the remaining files.
     *
     * @param args the argument array; {@code args[1]} is the manifest path
     * @throws Exception if setup fails or the manifest is invalid
     */
    private void runImportBatch(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();

        String manifestPath = args[1];
        File manifest = new File(manifestPath);
        if (!manifest.exists()) throw new Exception("Manifest not found: " + manifestPath);

        log("INFO", "Loading field definitions...");
        fieldDefs = fetchFieldDefs();
        Map<String, String> mapping = loadMappingFromFile(findConfigArg(args));

        List<ManifestEntry> entries = parseManifest(manifest);
        if (entries.isEmpty()) throw new Exception("Manifest has no valid entries");

        log("INFO", entries.size() + " file(s) in manifest");
        System.out.println();

        // Resolve every file path and show the plan before importing anything.
        File baseDir = manifest.getAbsoluteFile().getParentFile();
        for (ManifestEntry e : entries) {
            File f = resolveManifestFile(baseDir, e.filePath);
            if (!f.exists()) throw new Exception("File not found (from manifest): " + e.filePath);
            e.resolvedFile = f;
            System.out.printf("  %-40s -> %-10s %s%n",
                truncate(e.filePath, 38), e.action,
                e.folderPath.isEmpty() ? "(root)" : e.folderPath);
        }

        System.out.println();
        log("CONFIRM", "Import " + entries.size() + " file(s) into project " + projectId + "?");
        System.out.print("  Type 'yes' to proceed: ");
        if (!"yes".equalsIgnoreCase(readLine())) { log("INFO", "Aborted."); return; }

        ImportResult grand = new ImportResult();
        for (int idx = 0; idx < entries.size(); idx++) {
            ManifestEntry e = entries.get(idx);
            System.out.println();
            log("INFO", "[" + (idx + 1) + "/" + entries.size() + "] " + e.filePath);

            try {
                Long targetModule;
                switch (e.action) {
                    case "create":
                        targetModule = resolveOrCreateModulePath(e.folderPath);
                        break;
                    case "existing":
                        targetModule = resolveModulePath(e.folderPath);
                        break;
                    case "root":
                    default:
                        targetModule = null;
                        break;
                }

                List<String[]> allRows = readFile(e.resolvedFile.getPath());
                if (allRows.size() < 2) { log("WARN", "No data rows, skipping."); continue; }
                String[] headers = allRows.get(0);
                List<String[]> dataRows = allRows.subList(1, allRows.size());
                Map<String, String> resolved = resolveMapping(headers, mapping);

                List<TestCase> testCases = buildTestCases(headers, dataRows, resolved);
                ImportResult r = executeImport(testCases, targetModule);
                grand.ok += r.ok;
                grand.fail += r.fail;
                grand.errors.addAll(r.errors);
            } catch (Exception ex) {
                log("ERROR", "File failed: " + ex.getMessage());
                grand.errors.add(e.filePath + " (file-level): " + ex.getMessage());
            }
        }

        System.out.println();
        log("DONE", "Batch complete. Imported: " + grand.ok + "  Failed: " + grand.fail);
        writeErrorLog(grand.errors);
    }

    /**
     * Sends each test case to qTest, one at a time, pausing between batches.
     * Successes and failures are tallied; failures are recorded with their message.
     *
     * @param testCases           the test cases to create
     * @param targetModuleOverride the folder ID to place them in, or {@code null} for root
     * @return an {@link ImportResult} with counts, elapsed time, and error messages
     * @throws Exception if a batch pause is interrupted
     */
    private ImportResult executeImport(List<TestCase> testCases, Long targetModuleOverride) throws Exception {
        ImportResult result = new ImportResult();
        int total = testCases.size();
        long startTime = System.currentTimeMillis();

        for (int i = 0; i < total; i++) {
            TestCase tc = testCases.get(i);
            try {
                String json = gson.toJson(buildPayload(tc, targetModuleOverride));
                String resp = httpPost("/api/v3/projects/" + projectId + "/test-cases", json);
                JsonObject created = JsonParser.parseString(resp).getAsJsonObject();
                result.ok++;
                System.out.printf("  [%3d/%d] OK   %-45s -> %s%n",
                    i + 1, total, truncate(tc.name, 43), getJsonVal(created, "pid"));
            } catch (Exception e) {
                result.fail++;
                String msg = truncate(e.getMessage(), 120);
                result.errors.add(tc.name + ": " + msg);
                System.out.printf("  [%3d/%d] FAIL %-40s %s%n",
                    i + 1, total, truncate(tc.name, 38), msg);
            }

            // Pause after every full batch to be gentle on the API.
            if (i < total - 1 && (i + 1) % batchSize == 0) {
                log("INFO", "Batch pause (" + batchDelayMs + "ms)...");
                Thread.sleep(batchDelayMs);
            }
        }

        result.elapsedSeconds = (System.currentTimeMillis() - startTime) / 1000;
        return result;
    }

    /**
     * Prints the final summary line for a single-file import and writes an error
     * log if there were any failures.
     *
     * @param r the result to report
     * @throws Exception if writing the error log fails
     */
    private void reportResult(ImportResult r) throws Exception {
        System.out.println();
        log("DONE", String.format("Imported: %d  Failed: %d  Total: %d  Time: %ds",
            r.ok, r.fail, r.ok + r.fail, r.elapsedSeconds));
        writeErrorLog(r.errors);
    }

    /**
     * Writes failed-import messages to a timestamped log file. Does nothing when
     * there are no errors.
     *
     * @param errors the collected error messages
     * @throws Exception if the file cannot be written
     */
    private void writeErrorLog(List<String> errors) throws Exception {
        if (errors.isEmpty()) return;
        String errFile = "import-errors-" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date()) + ".log";
        Files.writeString(Path.of(errFile), String.join("\n", errors));
        log("INFO", "Error details: " + errFile);
    }

    // ========================================================================
    // Manifest Parsing (batch import)
    // ========================================================================

    /**
     * Parses a batch manifest file into entries. Each non-comment line is split on
     * {@code |} into a file path, an action, and an optional folder path. Unknown
     * actions fall back to {@code root}; {@code create}/{@code existing} actions
     * require a folder path.
     *
     * @param manifest the manifest file
     * @return the parsed entries
     * @throws Exception if the file cannot be read or an entry is invalid
     */
    private List<ManifestEntry> parseManifest(File manifest) throws Exception {
        List<ManifestEntry> entries = new ArrayList<>();
        List<String> lines = Files.readAllLines(manifest.toPath(), StandardCharsets.UTF_8);

        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) continue;

            String[] parts = trimmed.split("\\|");
            if (parts.length < 2) {
                log("WARN", "Skipping invalid manifest line: " + trimmed);
                continue;
            }

            ManifestEntry e = new ManifestEntry();
            e.filePath = parts[0].trim();
            e.action = parts[1].trim().toLowerCase();
            e.folderPath = parts.length >= 3 ? parts[2].trim() : "";

            if (!e.action.equals("create") && !e.action.equals("existing") && !e.action.equals("root")) {
                log("WARN", "Unknown action '" + e.action + "' for " + e.filePath + ", defaulting to 'root'");
                e.action = "root";
            }
            if ((e.action.equals("create") || e.action.equals("existing")) && e.folderPath.isEmpty()) {
                throw new Exception("Manifest action '" + e.action + "' requires a folder path: " + e.filePath);
            }
            entries.add(e);
        }
        return entries;
    }

    /**
     * Resolves a manifest file path. Absolute or already-existing paths are used
     * as-is; otherwise the path is resolved relative to the manifest's directory.
     *
     * @param baseDir  the manifest's directory
     * @param filePath the path from the manifest line
     * @return the resolved file
     */
    private File resolveManifestFile(File baseDir, String filePath) {
        File f = new File(filePath);
        if (f.isAbsolute() || f.exists()) return f;
        return new File(baseDir, filePath);
    }

    // ========================================================================
    // Module (Folder) Management
    // ========================================================================

    /**
     * Creates a folder path in qTest (and any missing parent folders) and reports
     * the resulting module ID.
     *
     * @param args the argument array; {@code args[1]} is the folder path
     * @throws Exception if setup or creation fails
     */
    private void runCreateFolder(String[] args) throws Exception {
        initFromConfig(args);
        requireProject();
        String folderPath = args[1];
        Long id = resolveOrCreateModulePath(folderPath);
        log("OK", "Folder ready: '" + folderPath + "' -> module ID " + id);
    }

    /**
     * Resolves a separator-delimited module path (for example {@code Regression\Sprint5})
     * to the ID of its deepest folder. Does not create anything.
     *
     * @param path the folder path
     * @return the deepest module ID, or {@code null} for an empty path
     * @throws Exception if any segment does not exist
     */
    private Long resolveModulePath(String path) throws Exception {
        List<String> segments = splitPath(path);
        if (segments.isEmpty()) return null;

        List<JsonObject> currentLevel = fetchModules(null);
        Long resolvedId = null;

        for (String segment : segments) {
            JsonObject match = findModuleByName(currentLevel, segment);
            if (match == null) {
                throw new Exception("Module not found: '" + segment + "' in path '" + path
                    + "'. Use --create-folder or action 'create' to create it.");
            }
            resolvedId = getJsonLong(match, "id");
            currentLevel = fetchModules(resolvedId);
        }
        log("INFO", "Resolved folder '" + path + "' to module ID " + resolvedId);
        return resolvedId;
    }

    /**
     * Resolves a module path, creating any missing segments along the way.
     *
     * @param path the folder path
     * @return the deepest module ID, or {@code null} for an empty path
     * @throws Exception if a folder cannot be created
     */
    private Long resolveOrCreateModulePath(String path) throws Exception {
        List<String> segments = splitPath(path);
        if (segments.isEmpty()) return null;

        List<JsonObject> currentLevel = fetchModules(null);
        Long parentId = null;

        for (String segment : segments) {
            JsonObject match = findModuleByName(currentLevel, segment);
            if (match != null) {
                parentId = getJsonLong(match, "id");
            } else {
                parentId = createModule(segment, parentId);
                log("OK", "Created folder '" + segment + "' (ID " + parentId + ")");
            }
            currentLevel = fetchModules(parentId);
        }
        return parentId;
    }

    /**
     * Fetches the child modules under a given parent (or the root modules when
     * {@code parentId} is {@code null}).
     *
     * @param parentId the parent module ID, or {@code null} for the root
     * @return the modules at that level
     * @throws Exception if the request fails
     */
    private List<JsonObject> fetchModules(Long parentId) throws Exception {
        String path = "/api/v3/projects/" + projectId + "/modules";
        if (parentId != null) path += "?parentId=" + parentId;
        JsonArray arr = JsonParser.parseString(httpGet(path)).getAsJsonArray();
        List<JsonObject> modules = new ArrayList<>();
        for (JsonElement el : arr) modules.add(el.getAsJsonObject());
        return modules;
    }

    /**
     * Finds a module by name within a level, case-insensitively.
     *
     * @param modules the modules to search
     * @param name    the folder name to match
     * @return the matching module, or {@code null}
     */
    private JsonObject findModuleByName(List<JsonObject> modules, String name) {
        for (JsonObject m : modules) {
            if (name.equalsIgnoreCase(getJsonVal(m, "name"))) return m;
        }
        return null;
    }

    /**
     * Creates a single module under a parent (or at the root when {@code parentId}
     * is {@code null}) and returns its new ID.
     *
     * @param name     the new folder name
     * @param parentId the parent module ID, or {@code null} for the root
     * @return the created module's ID
     * @throws Exception if the request fails
     */
    private Long createModule(String name, Long parentId) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("name", name);
        String path = "/api/v3/projects/" + projectId + "/modules";
        if (parentId != null) path += "?parentId=" + parentId;
        String resp = httpPost(path, gson.toJson(body));
        JsonObject created = JsonParser.parseString(resp).getAsJsonObject();
        return getJsonLong(created, "id");
    }

    /**
     * Splits a folder path into segments, accepting both backslash and forward-slash
     * separators and ignoring empty segments.
     *
     * @param path the folder path
     * @return the trimmed, non-empty segments in order
     */
    private List<String> splitPath(String path) {
        List<String> segments = new ArrayList<>();
        if (path == null) return segments;
        for (String part : path.split("[\\\\/]")) {
            String t = part.trim();
            if (!t.isEmpty()) segments.add(t);
        }
        return segments;
    }

    // ========================================================================
    // qTest Field Definitions
    // ========================================================================

    /**
     * Fetches the test case field definitions for the configured project, including
     * each field's ID, label, required and multi-value flags, and allowed values.
     *
     * @return the field definitions
     * @throws Exception if the request fails
     */
    private List<FieldDef> fetchFieldDefs() throws Exception {
        JsonArray raw = JsonParser.parseString(
            httpGet("/api/v3/projects/" + projectId + "/settings/test-cases/fields")).getAsJsonArray();

        List<FieldDef> result = new ArrayList<>();
        for (JsonElement el : raw) {
            JsonObject f = el.getAsJsonObject();
            FieldDef fd = new FieldDef();
            fd.id = getJsonVal(f, "id");
            fd.label = getJsonVal(f, "label");
            fd.required = f.has("required") && f.get("required").getAsBoolean();
            fd.multiple = f.has("multiple") && f.get("multiple").getAsBoolean();
            fd.allowedValues = new ArrayList<>();

            if (f.has("allowed_values") && f.get("allowed_values").isJsonArray()) {
                for (JsonElement av : f.getAsJsonArray("allowed_values")) {
                    JsonObject v = av.getAsJsonObject();
                    AllowedValue val = new AllowedValue();
                    val.label = getJsonVal(v, "label");
                    val.value = getJsonVal(v, "value");
                    fd.allowedValues.add(val);
                }
            }
            result.add(fd);
        }
        return result;
    }

    /**
     * Finds a field definition by its label, case-insensitively.
     *
     * @param label the qTest field label
     * @return the matching field definition, or {@code null}
     */
    private FieldDef findFieldDef(String label) {
        if (fieldDefs == null) return null;
        for (FieldDef fd : fieldDefs) {
            if (label.equalsIgnoreCase(fd.label)) return fd;
        }
        return null;
    }

    /**
     * Resolves a raw dropdown label (such as {@code "High"}) to its qTest internal
     * value ID by matching against the field's allowed values, case-insensitively.
     *
     * @param fd       the field definition
     * @param rawValue the value from the input file
     * @return the matching internal value, or {@code null} if there is no match or
     *         the field has no allowed values
     */
    private String resolveAllowedValue(FieldDef fd, String rawValue) {
        if (fd.allowedValues == null || fd.allowedValues.isEmpty()) return null;
        String target = rawValue.trim().toLowerCase();
        for (AllowedValue av : fd.allowedValues) {
            if (av.label.trim().toLowerCase().equals(target)) return av.value;
        }
        return null;
    }

    // ========================================================================
    // Mapping: Config File -> Column-to-Field Mapping
    // ========================================================================

    /**
     * Reads {@code mapping.*} lines directly from the config file rather than via
     * {@link Properties}, because {@code Properties.load} treats spaces as key/value
     * separators, which would break column names like {@code "Test Case Name"}.
     *
     * <p>Each line is split on the LAST {@code =}, so
     * {@code mapping.Test Case Name=name} yields column {@code "Test Case Name"} and
     * target {@code "name"}. If no mapping lines are found, the built-in defaults
     * are used as a fallback.
     *
     * @param configPath the config file path
     * @return the column-to-target mapping
     * @throws Exception if the file cannot be read
     */
    private Map<String, String> loadMappingFromFile(String configPath) throws Exception {
        Map<String, String> mapping = new LinkedHashMap<>();
        List<String> lines = Files.readAllLines(Path.of(configPath), StandardCharsets.UTF_8);

        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.startsWith("#") || trimmed.isEmpty()) continue;
            if (!trimmed.startsWith("mapping.")) continue;

            String afterPrefix = trimmed.substring("mapping.".length());
            int eqIdx = afterPrefix.lastIndexOf('=');
            if (eqIdx <= 0) continue;

            String col = afterPrefix.substring(0, eqIdx).trim();
            String target = afterPrefix.substring(eqIdx + 1).trim();
            if (!col.isEmpty() && !target.isEmpty()) {
                mapping.put(col, target);
            }
        }

        if (mapping.isEmpty()) {
            log("WARN", "No mapping.* entries in config. Using defaults.");
            mapping.putAll(DEFAULT_MAPPING);
        }
        return mapping;
    }

    /**
     * Produces a per-header mapping for the actual file headers. Each header is
     * matched against the configured mapping (exact first, then case-insensitive);
     * unmatched headers are marked {@code __skip__}.
     *
     * @param headers the file's header row
     * @param mapping the configured column-to-target mapping
     * @return a header-to-target map covering every header
     */
    private Map<String, String> resolveMapping(String[] headers, Map<String, String> mapping) {
        Map<String, String> resolved = new LinkedHashMap<>();
        for (String h : headers) {
            String ht = h.trim();
            String found = mapping.get(ht);
            if (found == null) {
                for (Map.Entry<String, String> e : mapping.entrySet()) {
                    if (e.getKey().equalsIgnoreCase(ht)) { found = e.getValue(); break; }
                }
            }
            resolved.put(ht, found != null ? found : "__skip__");
        }
        return resolved;
    }

    /**
     * Prints how each file header maps to a qTest field, marking skipped columns.
     *
     * @param headers the file's header row
     * @param mapping the resolved header-to-target map
     */
    private void printMappingSummary(String[] headers, Map<String, String> mapping) {
        System.out.println();
        log("INFO", "Field mapping:");
        System.out.printf("  %-30s  ->  %s%n", "EXCEL COLUMN", "QTEST FIELD");
        System.out.printf("  %-30s      %s%n", "----------------------------", "-------------------");
        for (String h : headers) {
            String target = mapping.getOrDefault(h.trim(), "__skip__");
            boolean skip = "__skip__".equals(target);
            System.out.printf("  %-30s  ->  %s%s%n", truncate(h, 28), target, skip ? " (skipped)" : "");
        }
    }

    // ========================================================================
    // Test Case Builder - ALM Multi-Row Grouping
    // ========================================================================

    /**
     * Builds test cases from ALM-exported rows.
     *
     * <p>ALM export format: a test case with N steps spans N rows. The first row
     * holds all metadata (name, description, status, etc.) plus the first step's
     * data; rows 2..N have blank metadata columns and only step data.
     *
     * <p>Grouping rule: iterate rows in order. A row with a non-empty name column
     * starts a new test case and its metadata is read from that row. A row with an
     * empty name column is a continuation step that belongs to the test case most
     * recently started. Step data is collected from every row, including the first.
     *
     * <p>If no column maps to {@code name}, each row becomes its own test case.
     *
     * @param headers the file's header row
     * @param rows    the data rows (header excluded)
     * @param mapping the resolved header-to-target map
     * @return the assembled test cases in input order
     */
    private List<TestCase> buildTestCases(String[] headers, List<String[]> rows, Map<String, String> mapping) {
        int nameIdx = findMappedIndex(headers, mapping, "name");
        int stepDescIdx = findMappedIndex(headers, mapping, "step.description");
        int stepExpIdx = findMappedIndex(headers, mapping, "step.expected");

        if (nameIdx < 0) {
            log("WARN", "No column mapped to 'name'. Each row becomes a separate test case.");
        }

        List<TestCase> result = new ArrayList<>();
        TestCase currentTc = null;

        for (String[] row : rows) {
            String nameValue = (nameIdx >= 0 && nameIdx < row.length) ? row[nameIdx].trim() : "";
            boolean isNewTestCase = !nameValue.isEmpty();

            if (nameIdx < 0) {
                // No name column mapped: treat every row as its own test case.
                isNewTestCase = true;
                nameValue = "Row_" + (result.size() + 1);
            }

            if (isNewTestCase) {
                // Start a new test case and read its metadata from this row.
                currentTc = new TestCase();
                currentTc.name = nameValue;
                result.add(currentTc);

                for (int i = 0; i < headers.length; i++) {
                    String target = mapping.getOrDefault(headers[i].trim(), "__skip__");
                    String value = safeGet(row, i);
                    if (value.isEmpty() || "__skip__".equals(target)) continue;

                    switch (target) {
                        case "name":
                        case "step.description":
                        case "step.expected":
                        case "step.name":
                            break; // handled separately
                        case "description":
                            currentTc.description = value;
                            break;
                        case "precondition":
                            currentTc.precondition = value;
                            break;
                        default:
                            currentTc.properties.put(target, value);
                            break;
                    }
                }
            }

            // Collect step data from this row (applies to first and continuation rows).
            if (currentTc != null) {
                String stepDesc = safeGet(row, stepDescIdx);
                String stepExp = safeGet(row, stepExpIdx);
                if (!stepDesc.isEmpty() || !stepExp.isEmpty()) {
                    TestStep step = new TestStep();
                    step.description = stepDesc;
                    step.expected = stepExp;
                    currentTc.steps.add(step);
                }
            }
        }

        log("INFO", result.size() + " test case(s) built from " + rows.size() + " row(s)");
        return result;
    }

    // ========================================================================
    // Payload Builder & Validation
    // ========================================================================

    /**
     * Builds the qTest API payload for a test case, using the configured default
     * target module.
     *
     * @param tc the test case
     * @return the JSON payload
     */
    private JsonObject buildPayload(TestCase tc) {
        return buildPayload(tc, parentModuleId);
    }

    /**
     * Builds the qTest API payload for a test case.
     *
     * <p>Property values are resolved against the field's allowed values where
     * applicable. Numeric values are sent as numbers; multi-value fields are sent
     * as a single-element array, as the qTest API requires. Steps are numbered from
     * {@code import.step.start.order} (default 1).
     *
     * @param tc       the test case
     * @param moduleId the target folder ID, or {@code null} for none
     * @return the JSON payload
     */
    private JsonObject buildPayload(TestCase tc, Long moduleId) {
        JsonObject obj = new JsonObject();
        obj.addProperty("name", tc.name);
        if (!tc.description.isEmpty()) obj.addProperty("description", tc.description);
        if (!tc.precondition.isEmpty()) obj.addProperty("precondition", tc.precondition);
        if (moduleId != null) obj.addProperty("parent_id", moduleId);

        if (!tc.properties.isEmpty()) {
            JsonArray props = new JsonArray();
            for (Map.Entry<String, String> entry : tc.properties.entrySet()) {
                FieldDef fd = findFieldDef(entry.getKey());
                if (fd == null) continue;

                JsonObject prop = new JsonObject();
                prop.addProperty("field_id", Long.parseLong(fd.id));
                String resolved = resolveAllowedValue(fd, entry.getValue());
                String finalValue = resolved != null ? resolved : entry.getValue();

                if (fd.multiple && finalValue.matches("-?\\d+")) {
                    JsonArray arr = new JsonArray();
                    arr.add(Long.parseLong(finalValue));
                    prop.add("field_value", arr);
                } else if (finalValue.matches("-?\\d+")) {
                    prop.addProperty("field_value", Long.parseLong(finalValue));
                } else {
                    prop.addProperty("field_value", finalValue);
                }
                props.add(prop);
            }
            if (props.size() > 0) obj.add("properties", props);
        }

        if (!tc.steps.isEmpty()) {
            JsonArray steps = new JsonArray();
            for (int i = 0; i < tc.steps.size(); i++) {
                TestStep s = tc.steps.get(i);
                JsonObject step = new JsonObject();
                step.addProperty("description", s.description);
                step.addProperty("expected", s.expected);
                step.addProperty("order", stepStartOrder + i);
                steps.add(step);
            }
            obj.add("test_steps", steps);
        }
        return obj;
    }

    /**
     * Validates a test case before import and returns any problems found: an empty
     * or over-long name, property values that do not resolve against a field's
     * allowed values, unknown field labels, and required fields that are missing.
     *
     * @param tc the test case to validate
     * @return a list of human-readable problems (empty if the test case is valid)
     */
    private List<String> validate(TestCase tc) {
        List<String> errors = new ArrayList<>();
        if (tc.name.isEmpty()) errors.add("Name is empty");
        if (tc.name.length() > 500) errors.add("Name exceeds 500 characters");

        for (Map.Entry<String, String> e : tc.properties.entrySet()) {
            FieldDef fd = findFieldDef(e.getKey());
            if (fd == null) {
                errors.add("Unknown field: '" + e.getKey() + "'");
            } else if (!fd.allowedValues.isEmpty() && resolveAllowedValue(fd, e.getValue()) == null) {
                String available = fd.allowedValues.stream()
                    .map(v -> v.label).limit(8).collect(Collectors.joining(", "));
                errors.add("Cannot resolve '" + e.getValue() + "' for field '" + fd.label
                    + "'. Available: " + available);
            }
        }

        if (fieldDefs != null) {
            for (FieldDef fd : fieldDefs) {
                if (fd.required && !fd.label.equalsIgnoreCase("Name")
                    && !tc.properties.containsKey(fd.label)) {
                    errors.add("Required field missing: " + fd.label);
                }
            }
        }
        return errors;
    }

    // ========================================================================
    // File Readers: Excel (.xlsx, .xls) and CSV/TSV
    // ========================================================================

    /**
     * Reads an input file into rows of string cells, choosing the reader by file
     * extension.
     *
     * @param path the file path
     * @return the rows, including the header row as the first element
     * @throws Exception if the file is missing or the format is unsupported
     */
    private List<String[]> readFile(String path) throws Exception {
        File file = new File(path);
        if (!file.exists()) throw new Exception("File not found: " + path);

        String name = file.getName().toLowerCase();
        if (name.endsWith(".xlsx")) return readExcel(file);
        if (name.endsWith(".xls")) return readExcel(file);
        if (name.endsWith(".csv")) return readCsv(file, ',');
        if (name.endsWith(".tsv")) return readCsv(file, '\t');
        throw new Exception("Unsupported format. Use .xlsx, .xls, or .csv");
    }

    /**
     * Reads the first sheet of an Excel workbook (.xlsx or .xls) into rows. Cells
     * are formatted to their displayed text; fully blank rows are skipped.
     *
     * @param file the workbook file
     * @return the non-empty rows
     * @throws Exception if the workbook cannot be opened or read
     */
    private List<String[]> readExcel(File file) throws Exception {
        log("INFO", "Reading: " + file.getName());
        List<String[]> rows = new ArrayList<>();

        try (Workbook wb = WorkbookFactory.create(file)) {
            Sheet sheet = wb.getSheetAt(0);
            DataFormatter fmt = new DataFormatter();

            for (Row row : sheet) {
                int lastCol = row.getLastCellNum();
                if (lastCol < 0) continue;

                String[] values = new String[lastCol];
                boolean hasData = false;
                for (int c = 0; c < lastCol; c++) {
                    Cell cell = row.getCell(c, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                    values[c] = (cell != null) ? fmt.formatCellValue(cell).trim() : "";
                    if (!values[c].isEmpty()) hasData = true;
                }
                if (hasData) rows.add(values);
            }
        }

        log("INFO", "Read " + rows.size() + " row(s)");
        return rows;
    }

    /**
     * Reads a delimited text file (CSV or TSV) into rows using a streaming RFC 4180
     * parser that handles quoted fields, escaped quotes ({@code ""}), and newlines
     * embedded inside quoted fields.
     *
     * @param file  the delimited file
     * @param delim the field delimiter ({@code ,} for CSV, tab for TSV)
     * @return the parsed rows
     * @throws Exception if the file cannot be read
     */
    private List<String[]> readCsv(File file, char delim) throws Exception {
        log("INFO", "Reading: " + file.getName());
        List<String[]> rows = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            List<String> fields = new ArrayList<>();
            StringBuilder current = new StringBuilder();
            boolean inQuotes = false;
            int ch;

            while ((ch = br.read()) != -1) {
                char c = (char) ch;
                if (inQuotes) {
                    if (c == '"') {
                        int next = br.read();
                        if (next == '"') {
                            current.append('"'); // escaped quote
                        } else {
                            inQuotes = false;
                            if (next == -1 || (char) next == '\n') {
                                fields.add(current.toString());
                                rows.add(fields.toArray(new String[0]));
                                fields = new ArrayList<>();
                                current = new StringBuilder();
                            } else if ((char) next == '\r') {
                                br.read(); // consume LF after CR
                                fields.add(current.toString());
                                rows.add(fields.toArray(new String[0]));
                                fields = new ArrayList<>();
                                current = new StringBuilder();
                            } else if ((char) next == delim) {
                                fields.add(current.toString());
                                current = new StringBuilder();
                            } else {
                                current.append((char) next);
                            }
                        }
                    } else {
                        current.append(c);
                    }
                } else {
                    if (c == '"') {
                        inQuotes = true;
                    } else if (c == delim) {
                        fields.add(current.toString());
                        current = new StringBuilder();
                    } else if (c == '\n') {
                        fields.add(current.toString());
                        rows.add(fields.toArray(new String[0]));
                        fields = new ArrayList<>();
                        current = new StringBuilder();
                    } else if (c == '\r') {
                        br.read(); // consume LF
                        fields.add(current.toString());
                        rows.add(fields.toArray(new String[0]));
                        fields = new ArrayList<>();
                        current = new StringBuilder();
                    } else {
                        current.append(c);
                    }
                }
            }
            if (!current.toString().isEmpty() || !fields.isEmpty()) {
                fields.add(current.toString());
                rows.add(fields.toArray(new String[0]));
            }
        }

        log("INFO", "Read " + rows.size() + " row(s)");
        return rows;
    }

    // ========================================================================
    // Utilities
    // ========================================================================

    /**
     * Returns the index of the first header that maps to the given target, or -1.
     *
     * @param headers the file's header row
     * @param mapping the resolved header-to-target map
     * @param target  the target to find (for example {@code "name"})
     * @return the column index, or -1 if no header maps to the target
     */
    private int findMappedIndex(String[] headers, Map<String, String> mapping, String target) {
        for (int i = 0; i < headers.length; i++) {
            if (target.equals(mapping.getOrDefault(headers[i].trim(), ""))) return i;
        }
        return -1;
    }

    /**
     * Safely reads and trims a cell from a row, returning an empty string when the
     * index is out of range.
     *
     * @param row the row
     * @param idx the column index
     * @return the trimmed cell value, or an empty string
     */
    private String safeGet(String[] row, int idx) {
        return (idx >= 0 && idx < row.length) ? row[idx].trim() : "";
    }

    /**
     * Safely extracts a JSON value as a string, handling numbers, booleans, and nulls.
     *
     * @param obj the JSON object
     * @param key the key to read
     * @return the value as a string, or an empty string if missing or null
     */
    private static String getJsonVal(JsonObject obj, String key) {
        if (!obj.has(key) || obj.get(key).isJsonNull()) return "";
        JsonElement el = obj.get(key);
        if (el.isJsonPrimitive()) return el.getAsString();
        return el.toString();
    }

    /**
     * Safely extracts a JSON value as a {@link Long}.
     *
     * @param obj the JSON object
     * @param key the key to read
     * @return the value as a Long, or {@code null} if missing, null, or non-numeric
     */
    private static Long getJsonLong(JsonObject obj, String key) {
        if (!obj.has(key) || obj.get(key).isJsonNull()) return null;
        try { return obj.get(key).getAsLong(); }
        catch (Exception e) { return null; }
    }

    /**
     * Truncates a string to a maximum length, appending an ellipsis when shortened.
     *
     * @param s the input string (may be {@code null})
     * @param n the maximum length
     * @return the original string, or a truncated version ending in {@code ...}
     */
    private static String truncate(String s, int n) {
        return (s == null || s.length() <= n) ? s : s.substring(0, n - 3) + "...";
    }

    /**
     * Reads a line of input from the console or standard input, trimmed.
     *
     * @return the trimmed input line
     * @throws IOException if reading fails
     */
    private static String readLine() throws IOException {
        if (System.console() != null) return System.console().readLine().trim();
        return new BufferedReader(new InputStreamReader(System.in)).readLine().trim();
    }

    /**
     * Prints a timestamped, colour-coded log line.
     *
     * @param level the level tag (OK, ERROR, WARN, INFO, DRY-RUN, CONFIRM, DONE)
     * @param msg   the message text
     */
    private static void log(String level, String msg) {
        String ts = new SimpleDateFormat("HH:mm:ss").format(new Date());
        String color;
        switch (level) {
            case "OK": case "DONE": color = "\033[32m"; break;
            case "ERROR": color = "\033[31m"; break;
            case "WARN": color = "\033[33m"; break;
            case "DRY-RUN": color = "\033[36m"; break;
            case "CONFIRM": color = "\033[35m"; break;
            default: color = "\033[0m"; break;
        }
        System.out.printf("%s [%s%-7s\033[0m] %s%n", ts, color, level, msg);
    }

    /** Prints the tool banner with its version. */
    private static void printBanner() {
        System.out.println();
        System.out.println("  qTest Test Case Importer v" + VERSION);
        System.out.println("  --------------------------------");
        System.out.println();
    }

    /** Prints the command and option reference. */
    private static void printUsage() {
        System.out.println("  Commands:");
        System.out.println("    login                      Authenticate and get bearer token");
        System.out.println("    test-connection            Verify connectivity");
        System.out.println("    list-projects              List available projects");
        System.out.println("    list-fields                List test case field definitions");
        System.out.println("    list-modules               List module/folder tree");
        System.out.println("    create-folder <path>       Create a folder path (e.g. \"Regression\\Sprint5\")");
        System.out.println("    dry-run <file.xlsx|csv>    Validate without importing");
        System.out.println("    import  <file.xlsx|csv>    Import test cases");
        System.out.println("    import-batch <manifest>    Import multiple files per a manifest");
        System.out.println();
        System.out.println("  Options:");
        System.out.println("    --config <file>            Config file (default: " + DEFAULT_CONFIG + ")");
        System.out.println("    --folder <path>            Target folder for import (with 'import')");
        System.out.println("    --create-folder            Create the --folder path if it doesn't exist");
        System.out.println();
        System.out.println("  Examples:");
        System.out.println("    import tests.xlsx --folder \"Regression\\Sprint5\" --create-folder");
        System.out.println("    import tests.xlsx --folder \"Existing Folder\"");
        System.out.println("    import-batch manifest.txt");
        System.out.println();
    }

    // ========================================================================
    // Data Classes
    // ========================================================================

    /** A qTest test case field definition and its allowed values. */
    static class FieldDef {
        String id;
        String label;
        boolean required;
        boolean multiple;
        List<AllowedValue> allowedValues = new ArrayList<>();
    }

    /** A single allowed value for a dropdown field: display label and internal value. */
    static class AllowedValue {
        String label;
        String value;
    }

    /** A test case assembled from the input file, ready to be sent to qTest. */
    static class TestCase {
        String name = "";
        String description = "";
        String precondition = "";
        Map<String, String> properties = new LinkedHashMap<>();
        List<TestStep> steps = new ArrayList<>();
    }

    /** A single test step: action description and expected result. */
    static class TestStep {
        String description = "";
        String expected = "";
    }

    /** Aggregated outcome of an import: success/failure counts, time, and errors. */
    static class ImportResult {
        int ok = 0;
        int fail = 0;
        long elapsedSeconds = 0;
        List<String> errors = new ArrayList<>();
    }

    /** One line of a batch manifest: a file plus its folder action and path. */
    static class ManifestEntry {
        String filePath = "";
        String action = "";       // create | existing | root
        String folderPath = "";
        File resolvedFile;
    }
}
