# Changelog

## 2.6.0 — 2026-05-18

### Features

- **Dual endpoints for vs_protocol.** Pipe-separated values in the Endpoint
  column: `/fabric/datasets|/apigee/v1/datasets`. First part goes to
  Source A, second to Source B. No pipe = same endpoint for both.

- **Database validation assertions.** New operators:
  - `db_equals`   — run SQL query, compare first column/row to ExpectedValue
  - `db_contains` — run SQL query, check result contains ExpectedValue
  - `db_exists`   — run SQL query, check at least one row returned
  
  SQL query goes in the Path column. DB connection configured per
  environment via `DbURL`, `DbUser`, `DbPassword`, `DbDriver` columns.
  Passwords support `${env.}` and `${file.}`.

- **New assertion operators:**
  - `one_of`        — value is one of comma-separated options (e.g. `OK,SUCCESS,PASS`)
  - `not_null`      — alias for exists
  - `not_contains`  — actual does not contain expected
  - `has_children`  — XML node or JSON object/array at path has children
  - `count_equals`  — number of nodes matching path == expected number

### Cleanup

- Removed all traces of user-shared content references
- XXE hardening verified on all XML parser entry points
- No hardcoded credentials
- No dead code or commented-out blocks

## 2.5.0 — 2026-05-18

### Features

- **Automatic token fetch from the Environments sheet.** Two new columns:
  - `TokenURL` — the full URL of your OAuth / Glue token endpoint
  - `TokenBody` — the form-urlencoded body (supports `${env.}` and
    `${file.}` placeholders)

  When configured, the runner automatically POSTs to the token URL with
  `Content-Type: application/x-www-form-urlencoded` before any test step
  runs, extracts `access_token` from the JSON response, and injects
  `Authorization: Bearer <token>` into every request header. No template
  file, no extra step in the Steps sheet, no manual wiring.

  Example Environments row:
  ```
  EnvName:   DEV_REST
  TokenURL:  https://auth.example.com/oauth/token
  TokenBody: grant_type=client_credentials&client_id=${env.CLIENT_ID}&client_secret=${env.CLIENT_SECRET}
  ```

  The token fetch appears as "Step 0" in the HTML report so you can see
  the request/response and timing. If the token fetch fails, the test
  immediately fails with a clear error.

## 2.4.1 — 2026-05-17

### Bug fixes

- **Full URLs in the Endpoint column are now used as-is.** When a step's
  endpoint starts with `http://` or `https://` (e.g. a token service on a
  different host), the runner no longer prepends the environment's BaseURL.
  Previously, `https://auth.example.com/oauth/token` in the Endpoint column
  with BaseURL `https://dev-api.example.com` produced the broken URL
  `https://dev-api.example.com/https://auth.example.com/oauth/token`.

## 2.4.0 — 2026-05-17

### Features

- **Apigee protocol support.** Set `Protocol = apigee` in the Environments
  sheet. Defaults Content-Type to `application/json`. Works with the new
  `apikey` auth type for `x-api-key` header injection.

- **New `apikey` auth type.** Set `AuthType = apikey` and `AuthValue` to
  your API key (literal, `${env.VAR}`, or `${file.path:key}`). Injects
  the key as the `x-api-key` header.

- **Form-urlencoded body for OAuth token requests.** For token endpoints
  that require `Content-Type: application/x-www-form-urlencoded`, set
  the Content-Type in ExtraHeaders and write the body template as plain
  key=value pairs:
  ```
  grant_type=client_credentials&client_id=${client_id}&client_secret=${client_secret}
  ```
  No XML template needed — the framework sends the body exactly as
  written with the specified Content-Type.

- **Certificate passwords from config files.** SSL passwords now support
  `${file./path/to/ssl.properties:key_name}` in addition to `${env.VAR}`.
  The same syntax works for AuthValue. Create a `.properties` file:
  ```properties
  trust_password=changeit
  key_password=secret123
  apigee_key=my-api-key-here
  ```
  Then reference it in the Environments sheet:
  ```
  trust_password=${file./config/ssl.properties:trust_password}
  ```

### Notes on source A vs B headers

Source A and source B are separate Environment rows in the Excel, each
with their own `ExtraHeaders`, `AuthType`, `AuthValue`, and `SslConfig`.
They can be completely different — different headers, different auth,
different certificates. The runner processes each source independently.

## 2.3.1 — 2026-05-17


### Bug fixes

- **Template and expected-file path resolution fixed.** Paths in the Excel
  `BodyTemplate` and `ExpectedFile` columns now resolve via a fallback
  chain: first against the configured directory (`--templates-dir` /
  `--expected-dir`), then against `--project-root`. This fixes the
  double-directory bug where writing `templates/req.xml` in the Excel
  while `--templates-dir` was already set to `<project>/templates` caused
  the runner to look for `templates/templates/req.xml`.
  
  All three forms now work:
  - `req.xml` → resolved against `--templates-dir`
  - `templates/req.xml` → tries `--templates-dir` first, falls back to
    `--project-root`
  - Absolute paths → used as-is
  
  The error message now lists both attempted paths so you can see where
  it looked.

## 2.3.0 — 2026-05-17


### Features

- **Per-step ExtraHeaders** for dynamic authentication flows. Steps sheet
  now has an `ExtraHeaders` column. Headers specified here override the
  environment's default headers for that step. Both environment-level and
  step-level headers support placeholders like `${step1.token}`.
  
  **Use case:** OAuth / token-based auth where you need to fetch a fresh
  token before each test run:
  
  ```
  Step 1: POST /auth/token → extracts token to ${step1.access_token}
  Step 2: POST /api/service → ExtraHeaders: Authorization: Bearer ${step1.access_token}
  ```
  
  The token is fetched dynamically as the first step and reused in
  subsequent steps. Supports the same semicolon/newline formats as
  environment headers.

- **TemplateGenerator** updated to include the new `ExtraHeaders` column
  in the generated Steps sheet template.

## 2.2.1 — 2026-05-16


### Bug fixes

- **ExtraHeaders column now supports semicolon-delimited format.** REST
  services often need many headers; entering them on separate lines in an
  Excel cell was awkward. The parser now accepts both:
  - Newline-delimited (original): `Authorization: Bearer xyz\nX-Custom: val`
  - Semicolon-delimited (new): `Authorization: Bearer xyz; X-Custom: val`
  - Both formats can mix in the same cell. Header values can contain
    colons (only the first colon per header is the delimiter).

## 2.2.0 — 2026-05-16


### Features

- **Full path configuration via CLI.** Every directory the runner reads or
  writes is now overridable from the command line — `--templates-dir`,
  `--expected-dir`, `--output-dir`, `--project-root`, plus the existing
  `--suite` and `--report`. Means you can ship just the jar to a teammate
  and have them point the flags at their own files; no matching directory
  layout required at the runner's working directory.
- **`RunConfig` bundle** in `com.apitest.runner` carries all paths
  programmatically. New `Runner.runAll(RunConfig)` and
  `Runner.runTest(TestCase, TestSuite, RunConfig, Path)` overloads. The
  previous single-path entry points (`runAll(Path, Path)`, `runTest(TestCase,
  TestSuite, Path, Path)`) are kept for backward compatibility.
- **Helpful startup banner** prints the resolved paths so users can see
  exactly where the runner is reading from and writing to.

### Bug fixes

- **Comparison tab no longer truncates payloads at 5000 chars.** Large
  responses (typical SOAP business payloads) showed only the first
  5000 characters in the prepared-payloads side-by-side view. Truncation
  removed; the pane is scrollable via CSS so the page itself doesn't
  blow up, and a header shows the total character count for each side.

## 2.1.1 — 2026-05-16


### Bug fixes

- **Test status now correctly reports FAIL when source B fails in vs_env /
  vs_protocol mode.** Previously, when source A succeeded but source B
  hit a socket exception (or other dispatch error), the test was
  incorrectly reported as PASS in the HTML report. Root cause: the final
  status-resolve block at the end of `runTest` was overwriting the FAIL
  set earlier by the vs_env branch with a default PASS. Fixed by making
  the final block preserve any explicit FAIL or ERROR set previously.
- **Overview tab now indicates Source A and Source B status individually.**
  Each Source cell shows a small pill (`ok` or `failed`) so users can
  immediately see which side had a problem without drilling into the
  Steps tab.

### Tests

- Added `StatusOverrideRegressionTest` covering the four key paths:
  vs_env B-failure, vs_env all-ok, vs_env assertion-fail, ERROR-preserved.

## 2.1.0 — 2026-05-15


### Features

- **CDATA-aware comparison.** When the actual response wraps the business
  payload inside CDATA (a common SOAP pattern such as
  `<arg0><![CDATA[<RealPayload>...</RealPayload>]]></arg0>`), the
  comparator now unwraps it before structural diff so you can compare
  against a clean expected XML file. Also handles escaped XML
  (`&lt;...&gt;`) and SOAP-in-SOAP nested wrappers.
- **Smart comparison anchor.** When the expected file's top-level element
  exists somewhere inside the unwrapped actual response, comparison
  automatically anchors on that element. Lets users write expected files
  that contain only the business payload without having to mirror the
  full SOAP envelope structure.

### Improvements

- **Differences tab readability:**
  - `added` / `removed` rows now show `(missing)` on the absent side
    instead of repeating the value in both columns
  - Empty values render as `(empty)` instead of an indistinguishable blank
  - Long values truncate at 300 chars with a footer indicating how many
    more chars were elided
  - Table layout uses fixed widths for Kind/Path so the value columns get
    consistent space; word-break prevents overflow

### Security

- **XXE hardening across all XML parsers.** Every `DocumentBuilderFactory`
  now disables doctype declarations, external general/parameter entities,
  external DTD loading, XInclude, and entity expansion. Defense-in-depth
  against the small but real risk of a malicious response triggering an
  XXE-style attack on the test harness.

### Cleanup

- Removed unused `Demo.java` scaffolding.
- All snippets/identifiers from real-world test runs replaced with
  neutral example domain names. No proprietary references remain in the
  codebase.
- `serialVersionUID` added to `ExtractionException`.

## 2.0.2 — 2026-05-15

### Bug fixes

- **No more `xmlns=""` artifacts.** The namespace-aware DOM parser sometimes
  inserted redundant `xmlns=""` declarations on child elements during
  round-trip. A new cleanup pass walks the tree and removes empty default
  namespace declarations when the parent already had no default namespace.
- **No more line-wrapping inside element open tags.** The Transformer's
  pretty-print was wrapping long opening tags across multiple lines (e.g.
  `<arg0\n   xmlns="">`), which some strict server parsers reject. Indent
  is now disabled in the serializer; output is single-line clean XML.
- **No more visible blank lines inside the request.** After pruning, the
  original template's indentation whitespace was left as text nodes between
  elements, producing visible gaps in the output. A cleanup pass removes
  whitespace-only text nodes between structural elements.

## 2.0.1 — 2026-05-15

### Bug fixes

- **CDATA-wrapped inner XML now cleaned correctly.** When a template uses
  `<arg0><![CDATA[<inner>...${field}...</inner>]]></arg0>` to wrap a
  business payload, unresolved placeholders inside the CDATA now have their
  surrounding tags removed via string-level cleanup (the parser can't walk
  into CDATA as elements). Surviving filled tags are preserved; empty
  wrappers cascade away within the CDATA.
- **CDATA sections preserved through the output.** Previously the
  Transformer was converting CDATA back to escaped entities. Now the
  serializer explicitly lists CDATA-containing element names so they
  round-trip as `<![CDATA[...]]>`.
- **DROP marker no longer leaks to output** even when an element has
  attributes and the placeholder was its only content. The element is
  dropped per the spec, regardless of attributes.

## 2.0.0 — 2026-05-15

### Behavior changes (breaking)

- **Template engine rewritten using DOM-walk + cascade pruning.** Old
  regex-based heuristics replaced with a real XML parser. Handles namespaces,
  nested structures, attributes, repeating siblings correctly.
- **Placeholder syntax is `${name}` only.** The `&{name}` form is no longer
  recognized (was briefly experimental in pre-release builds).
- **Blank/missing placeholder values now drop the surrounding tag.** This
  matches the requirements spec. A leaf with `<Phone>${phone}</Phone>` and
  blank `phone` cell renders with no `<Phone>` element at all.
- **Parent cascade cleanup.** When all children of a parent are pruned and
  the parent has no other content (no real attrs, no text), the parent
  itself is removed. Cascades up.
- **Namespace declarations don't block cascade.** `xmlns` and `xmlns:*` are
  not counted as "real" attributes — so `<execute xmlns="..."/>` cascades
  away properly when its content was just a placeholder.
- **Root element is never auto-removed.** If pruning empties everything,
  the body is `<Root></Root>` rather than nothing — better diagnostics.

### Reliability improvements

- **Per-test error isolation.** Template-not-found, dispatch errors, SSL
  failures, variable-extraction errors — all now produce a failed step in
  the report instead of an uncaught exception that killed the suite. The
  next test always runs.
- **RenderLog persisted to disk.** Each step's render log is saved next
  to its `request.txt`/`response.txt` under `output/.../step.../render-log.txt`.
  Shows which placeholders were missing, which tags were dropped, which
  parents cascaded.
- **Step errors shown in HTML report.** When a step fails for any reason
  (template error, dispatch error, etc.), the report shows the full
  rendered log inline with the failed step.

### Other

- Version badge added to HTML report header.
- `Required` placeholder syntax `${!name}` documented — raises a clear
  error if the column is blank/missing.

## 1.0.0 — earlier

- Initial Java port from the original UFT/VBScript suite.
- Excel-driven test definition (5 sheets: Environments, TestSuite, Steps,
  TestData, Assertions).
- Four protocols: REST, SOAP, Fabric, GCP.
- Five comparison modes; nine assertion operators.
- Self-contained HTML report.
- Parser-free `SimpleXmlWalker` for assertion extraction (handles
  SOAP-in-SOAP, CDATA-wrapped inner XML).
