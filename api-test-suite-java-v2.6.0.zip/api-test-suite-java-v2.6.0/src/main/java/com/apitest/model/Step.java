package com.apitest.model;

import java.util.List;
import java.util.Map;

/**
 * A single HTTP request in a test sequence.
 *
 * <p>For {@code vs_protocol} mode where Source A and Source B have different
 * endpoint paths, use pipe-separated endpoints: {@code /fabric/orders|/apigee/v1/orders}.
 * The first part goes to Source A, the second to Source B. If no pipe is
 * present, the same endpoint is used for both.
 *
 * <p>Each step can override the environment's default headers via
 * {@code extraHeaders}.
 */
public record Step(
        String testId,
        int order,
        String name,
        String method,
        String endpoint,
        String endpointB,
        String bodyTemplate,
        Map<String, String> extractVars,
        List<Integer> expectedStatus,
        Map<String, String> extraHeaders
) {}
