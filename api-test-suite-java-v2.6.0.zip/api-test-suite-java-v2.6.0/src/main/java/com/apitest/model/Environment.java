package com.apitest.model;

import java.util.Map;

/**
 * A named environment (DEV, UAT, PROD, etc.).
 *
 * <p>For environments that require a dynamic auth token (OAuth, Glue, etc.),
 * fill in the token columns on the Environments sheet:
 * <ul>
 *   <li>{@code TokenURL}     — full URL of the token endpoint
 *   <li>{@code TokenBody}    — form body (e.g. grant_type=client_credentials&amp;...)
 *   <li>{@code TokenHeaders} — headers for the token request (e.g. Content-Type: application/x-www-form-urlencoded)
 * </ul>
 *
 * <p>Before any test step runs, the runner POSTs to the token URL with
 * the given headers and body, extracts {@code access_token} from the
 * JSON response, and injects it as {@code Authorization: Bearer} on
 * all subsequent requests.
 */
public record Environment(
        String name,
        String protocol,
        String baseUrl,
        String authType,
        String authValue,
        Map<String, String> extraHeaders,
        String sslConfig,
        String tokenUrl,
        String tokenBody,
        Map<String, String> tokenHeaders,
        String dbUrl,
        String dbUser,
        String dbPassword,
        String dbDriver
) {
    /** Backward-compatible constructor — no token and no SSL. */
    public Environment(String name, String protocol, String baseUrl,
                       String authType, String authValue, Map<String, String> extraHeaders) {
        this(name, protocol, baseUrl, authType, authValue, extraHeaders,
                "", "", "", Map.of(), "", "", "", "");
    }

    /** Backward-compatible constructor — no token fields. */
    public Environment(String name, String protocol, String baseUrl,
                       String authType, String authValue, Map<String, String> extraHeaders,
                       String sslConfig) {
        this(name, protocol, baseUrl, authType, authValue, extraHeaders,
                sslConfig, "", "", Map.of(), "", "", "", "");
    }
}
