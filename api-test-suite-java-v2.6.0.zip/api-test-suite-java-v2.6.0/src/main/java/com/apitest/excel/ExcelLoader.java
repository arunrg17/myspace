package com.apitest.excel;

import com.apitest.model.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.nio.file.Path;
import java.util.*;

/**
 * Load test suite configuration from the Excel workbook.
 *
 * Required sheets:
 *   Environments  — named endpoints (DEV/UAT/PROD) for any protocol
 *   TestSuite     — one row per test case
 *   Steps         — one row per request (multiple steps per TestID allowed)
 *
 * Optional sheets:
 *   TestData      — variable values per test
 *   Assertions    — field-level assertions + ignore directives
 */
public class ExcelLoader {

    public static TestSuite load(Path path) throws Exception {
        try (FileInputStream fis = new FileInputStream(path.toFile());
             Workbook wb = new XSSFWorkbook(fis)) {

            Map<String, Environment> envs = loadEnvironments(wb);
            Map<String, TestCase> tests = loadTestSuite(wb);
            loadSteps(wb, tests);
            loadTestData(wb, tests);
            loadAssertions(wb, tests);

            // Sort steps per test
            for (TestCase tc : tests.values()) {
                tc.steps.sort(Comparator.comparingInt(Step::order));
            }

            return new TestSuite(envs, new ArrayList<>(tests.values()));
        }
    }

    // ------------------------------------------------------------------

    private static Map<String, Environment> loadEnvironments(Workbook wb) {
        Map<String, Environment> envs = new LinkedHashMap<>();
        Sheet sheet = requireSheet(wb, "Environments");
        Map<String, Integer> cols = headerColumns(sheet);

        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String name = cellStr(row, cols, "EnvName");
            if (name.isEmpty()) continue;

            envs.put(name, new Environment(
                    name,
                    cellStr(row, cols, "Protocol"),
                    cellStr(row, cols, "BaseURL"),
                    cellStr(row, cols, "AuthType"),
                    cellStr(row, cols, "AuthValue"),
                    parseHeaders(cellStr(row, cols, "ExtraHeaders")),
                    cellStr(row, cols, "SslConfig"),
                    cellStr(row, cols, "TokenURL"),
                    cellStr(row, cols, "TokenBody"),
                    parseHeaders(cellStr(row, cols, "TokenHeaders")),
                    cellStr(row, cols, "DbURL"),
                    cellStr(row, cols, "DbUser"),
                    cellStr(row, cols, "DbPassword"),
                    cellStr(row, cols, "DbDriver")
            ));
        }
        return envs;
    }

    private static Map<String, TestCase> loadTestSuite(Workbook wb) {
        Map<String, TestCase> tests = new LinkedHashMap<>();
        Sheet sheet = requireSheet(wb, "TestSuite");
        Map<String, Integer> cols = headerColumns(sheet);

        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String enabled = cellStr(row, cols, "Enabled").trim().toUpperCase(Locale.ROOT);
            if (!"Y".equals(enabled) && !"YES".equals(enabled) && !"TRUE".equals(enabled)) continue;

            String testId = cellStr(row, cols, "TestID");
            if (testId.isEmpty()) continue;

            TestCase tc = new TestCase();
            tc.testId = testId;
            tc.name = cellStr(row, cols, "TestName");
            tc.description = cellStr(row, cols, "Description");
            tc.comparisonMode = cellStr(row, cols, "ComparisonMode");
            tc.sourceA = cellStr(row, cols, "SourceA");
            tc.sourceB = cellStr(row, cols, "SourceB");
            tc.expectedFile = cellStr(row, cols, "ExpectedFile");
            tc.enabled = true;
            tests.put(tc.testId, tc);
        }
        return tests;
    }

    private static void loadSteps(Workbook wb, Map<String, TestCase> tests) {
        Sheet sheet = requireSheet(wb, "Steps");
        Map<String, Integer> cols = headerColumns(sheet);

        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String tid = cellStr(row, cols, "TestID");
            TestCase tc = tests.get(tid);
            if (tc == null) continue;

            // Endpoint supports pipe-separated format for vs_protocol:
            //   /fabric/orders|/apigee/v1/orders
            // First part = Source A, second = Source B.
            // If no pipe, same endpoint for both.
            String rawEndpoint = cellStr(row, cols, "Endpoint");
            String endpointA = rawEndpoint;
            String endpointB = "";
            int pipe = rawEndpoint.indexOf('|');
            if (pipe >= 0) {
                endpointA = rawEndpoint.substring(0, pipe).trim();
                endpointB = rawEndpoint.substring(pipe + 1).trim();
            }

            Step step = new Step(
                    tid,
                    (int) cellNum(row, cols, "StepOrder", 1),
                    cellStr(row, cols, "StepName"),
                    cellStr(row, cols, "Method").toUpperCase(Locale.ROOT),
                    endpointA,
                    endpointB,
                    cellStr(row, cols, "BodyTemplate"),
                    parseExtractVars(cellStr(row, cols, "ExtractVars")),
                    parseStatus(cellStr(row, cols, "ExpectedStatus")),
                    parseHeaders(cellStr(row, cols, "ExtraHeaders"))
            );
            tc.steps.add(step);
        }
    }

    private static void loadTestData(Workbook wb, Map<String, TestCase> tests) {
        Sheet sheet = wb.getSheet("TestData");
        if (sheet == null) return;

        Map<String, Integer> cols = headerColumns(sheet);
        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String tid = cellStr(row, cols, "TestID");
            TestCase tc = tests.get(tid);
            if (tc == null) continue;

            for (Map.Entry<String, Integer> e : cols.entrySet()) {
                if ("TestID".equals(e.getKey())) continue;
                String value = cellStr(row, cols, e.getKey());
                tc.data.put(e.getKey(), value);
            }
        }
    }

    private static void loadAssertions(Workbook wb, Map<String, TestCase> tests) {
        Sheet sheet = wb.getSheet("Assertions");
        if (sheet == null) return;

        Map<String, Integer> cols = headerColumns(sheet);
        for (Row row : sheet) {
            if (row.getRowNum() == 0 || isBlankRow(row)) continue;

            String target = cellStr(row, cols, "TestID");
            String path = cellStr(row, cols, "Path");
            if (path.isEmpty()) continue;

            Assertion a = new Assertion(
                    path,
                    cellStr(row, cols, "PathType"),
                    cellStr(row, cols, "Operator").toLowerCase(Locale.ROOT),
                    cellStr(row, cols, "ExpectedValue"),
                    cellStr(row, cols, "Description")
            );

            if ("*".equals(target)) {
                for (TestCase tc : tests.values()) tc.assertions.add(a);
            } else {
                TestCase tc = tests.get(target);
                if (tc != null) tc.assertions.add(a);
            }
        }
    }

    // ------------------------------------------------------------------

    private static Sheet requireSheet(Workbook wb, String name) {
        Sheet s = wb.getSheet(name);
        if (s == null) throw new IllegalStateException("Required sheet missing: " + name);
        return s;
    }

    private static Map<String, Integer> headerColumns(Sheet sheet) {
        Row header = sheet.getRow(0);
        Map<String, Integer> out = new LinkedHashMap<>();
        if (header == null) return out;
        for (Cell c : header) {
            String v = cellStringValue(c);
            if (!v.isEmpty()) out.put(v, c.getColumnIndex());
        }
        return out;
    }

    private static boolean isBlankRow(Row row) {
        if (row == null) return true;
        for (Cell c : row) {
            String v = cellStringValue(c);
            if (!v.isEmpty()) return false;
        }
        return true;
    }

    private static String cellStr(Row row, Map<String, Integer> cols, String key) {
        Integer idx = cols.get(key);
        if (idx == null) return "";
        return cellStringValue(row.getCell(idx));
    }

    private static double cellNum(Row row, Map<String, Integer> cols, String key, double def) {
        Integer idx = cols.get(key);
        if (idx == null) return def;
        Cell c = row.getCell(idx);
        if (c == null) return def;
        try {
            if (c.getCellType() == CellType.NUMERIC) return c.getNumericCellValue();
            String s = cellStringValue(c);
            if (s.isEmpty()) return def;
            return Double.parseDouble(s);
        } catch (Exception e) {
            return def;
        }
    }

    private static String cellStringValue(Cell c) {
        if (c == null) return "";
        try {
            return switch (c.getCellType()) {
                case STRING -> c.getStringCellValue().trim();
                case NUMERIC -> {
                    double d = c.getNumericCellValue();
                    if (d == Math.floor(d) && !Double.isInfinite(d)) {
                        yield Long.toString((long) d);
                    } else {
                        yield Double.toString(d);
                    }
                }
                case BOOLEAN -> Boolean.toString(c.getBooleanCellValue());
                case FORMULA -> {
                    try { yield c.getStringCellValue().trim(); }
                    catch (Exception ex) { yield Double.toString(c.getNumericCellValue()); }
                }
                default -> "";
            };
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Parse extra headers from the ExtraHeaders column.
     *
     * Supports two formats:
     *   1. One header per line (newline-delimited):
     *        Authorization: Bearer xyz
     *        X-Custom: value
     *
     *   2. Semicolon-delimited on a single line:
     *        Authorization: Bearer xyz; X-Custom: value
     *
     * The semicolon format is often easier to edit in Excel cells.
     * Both formats can be mixed.
     */
    private static Map<String, String> parseHeaders(String raw) {
        Map<String, String> out = new LinkedHashMap<>();
        if (raw == null || raw.isEmpty()) return out;
        
        // Split on newline first, then each line by semicolon
        for (String line : raw.split("\\r?\\n")) {
            // Split by semicolon to support single-line format
            for (String part : line.split(";")) {
                int idx = part.indexOf(':');
                if (idx > 0) {
                    out.put(part.substring(0, idx).trim(), part.substring(idx + 1).trim());
                }
            }
        }
        return out;
    }

    private static Map<String, String> parseExtractVars(String raw) {
        Map<String, String> out = new LinkedHashMap<>();
        if (raw == null || raw.isEmpty()) return out;
        for (String part : raw.split(",")) {
            int eq = part.indexOf('=');
            if (eq > 0) {
                out.put(part.substring(0, eq).trim(), part.substring(eq + 1).trim());
            }
        }
        return out;
    }

    private static List<Integer> parseStatus(String raw) {
        if (raw == null || raw.isEmpty()) return List.of(200, 201, 204);
        List<Integer> out = new ArrayList<>();
        for (String s : raw.split(",")) {
            try { out.add(Integer.parseInt(s.trim())); }
            catch (NumberFormatException ignore) {}
        }
        return out.isEmpty() ? List.of(200, 201, 204) : out;
    }
}
