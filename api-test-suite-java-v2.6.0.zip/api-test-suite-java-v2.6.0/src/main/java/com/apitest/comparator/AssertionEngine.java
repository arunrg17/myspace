package com.apitest.comparator;

import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Runs field-level assertions against a response payload.
 *
 * Operators:
 *   equals          actual == expected
 *   not_equals      actual != expected
 *   contains        actual contains expected (substring)
 *   not_contains    actual does not contain expected
 *   exists          path resolves to a non-empty value
 *   not_exists      path does not resolve / is empty
 *   not_null        alias for exists
 *   greater_than    numeric: actual > expected
 *   less_than       numeric: actual < expected
 *   regex_match     actual matches expected as a regex
 *   one_of          actual is one of comma-separated values (e.g. "OK,SUCCESS,PASS")
 *   has_children    XML node at path has child elements
 *   count_equals    number of nodes matching XPath/JSONPath == expected
 *   db_equals       run SQL query (in Path), compare single result to ExpectedValue
 *   db_contains     run SQL query, check result contains ExpectedValue
 *   db_exists       run SQL query, check it returns at least one row
 *   ignore          (handled by Comparator, not asserted here)
 */
public class AssertionEngine {

    public static List<AssertionResult> evaluate(String responseBody, List<Assertion> assertions) {
        return evaluate(responseBody, assertions, null);
    }

    /**
     * Evaluate assertions. For db_* operators, the environment provides
     * the JDBC connection details.
     */
    public static List<AssertionResult> evaluate(String responseBody, List<Assertion> assertions,
                                                  com.apitest.model.Environment env) {
        List<AssertionResult> results = new ArrayList<>();
        if (assertions == null) return results;

        for (Assertion a : assertions) {
            if ("ignore".equalsIgnoreCase(a.operator())) continue;

            AssertionResult r = new AssertionResult();
            r.path = a.path();
            r.operator = a.operator();
            r.expectedValue = a.expectedValue();
            r.description = a.description();

            String op = a.operator() == null ? "" : a.operator().toLowerCase();

            // DB assertions — query the database, not the response body
            if (op.startsWith("db_")) {
                evaluateDb(r, a, env);
                results.add(r);
                continue;
            }

            // Friendly validation
            String path = a.path() == null ? "" : a.path().trim();
            String pathType = a.pathType() == null ? "" : a.pathType().trim().toLowerCase();
            if ("xpath".equals(pathType) && path.startsWith("$")) {
                r.actualValue = "";
                r.passed = false;
                r.message = "Path starts with '$' but PathType is 'xpath'. "
                          + "Use '//Tag' for XPath, or set PathType to 'jsonpath' for $.field syntax.";
                results.add(r);
                continue;
            }
            if ("jsonpath".equals(pathType) && (path.startsWith("/") || path.startsWith("//"))) {
                r.actualValue = "";
                r.passed = false;
                r.message = "Path starts with '/' but PathType is 'jsonpath'. "
                          + "Use '$.field' for JSONPath, or set PathType to 'xpath' for //Tag syntax.";
                results.add(r);
                continue;
            }

            try {
                // count_equals and has_children need special extraction
                if ("count_equals".equals(op)) {
                    int count = Comparator.countMatches(responseBody, a.path());
                    r.actualValue = String.valueOf(count);
                    try {
                        int expected = Integer.parseInt(a.expectedValue());
                        r.passed = count == expected;
                        r.message = r.passed ? "" : "expected count " + expected + ", got " + count;
                    } catch (NumberFormatException ex) {
                        r.passed = false;
                        r.message = "ExpectedValue must be a number for count_equals";
                    }
                } else if ("has_children".equals(op)) {
                    boolean has = Comparator.hasChildren(responseBody, a.path());
                    r.actualValue = has ? "(has children)" : "(no children)";
                    r.passed = has;
                    r.message = r.passed ? "" : "node has no child elements";
                } else {
                    r.actualValue = Comparator.extractVariable(responseBody, a.path());
                    evaluateOne(r, a);
                }
            } catch (Comparator.ExtractionException ex) {
                r.actualValue = "";
                r.passed = false;
                r.message = ex.getMessage();
            }
            results.add(r);
        }
        return results;
    }

    private static void evaluateOne(AssertionResult r, Assertion a) {
        String op = a.operator() == null ? "" : a.operator().toLowerCase();
        String expected = a.expectedValue() == null ? "" : a.expectedValue();
        String actual = r.actualValue == null ? "" : r.actualValue;

        switch (op) {
            case "equals" -> {
                r.passed = actual.equals(expected);
                r.message = r.passed ? "" : "expected '" + expected + "', got '" + actual + "'";
            }
            case "not_equals" -> {
                r.passed = !actual.equals(expected);
                r.message = r.passed ? "" : "expected NOT '" + expected + "', got '" + actual + "'";
            }
            case "contains" -> {
                r.passed = actual.contains(expected);
                r.message = r.passed ? "" : "expected to contain '" + expected + "', got '" + actual + "'";
            }
            case "not_contains" -> {
                r.passed = !actual.contains(expected);
                r.message = r.passed ? "" : "expected NOT to contain '" + expected + "', got '" + actual + "'";
            }
            case "exists", "not_null" -> {
                r.passed = !actual.isEmpty();
                r.message = r.passed ? "" : "path resolved to empty";
            }
            case "not_exists" -> {
                r.passed = actual.isEmpty();
                r.message = r.passed ? "" : "expected no value, got '" + actual + "'";
            }
            case "greater_than" -> {
                try {
                    double a1 = Double.parseDouble(actual);
                    double e1 = Double.parseDouble(expected);
                    r.passed = a1 > e1;
                    r.message = r.passed ? "" : a1 + " is not greater than " + e1;
                } catch (NumberFormatException ex) {
                    r.passed = false;
                    r.message = "non-numeric values";
                }
            }
            case "less_than" -> {
                try {
                    double a1 = Double.parseDouble(actual);
                    double e1 = Double.parseDouble(expected);
                    r.passed = a1 < e1;
                    r.message = r.passed ? "" : a1 + " is not less than " + e1;
                } catch (NumberFormatException ex) {
                    r.passed = false;
                    r.message = "non-numeric values";
                }
            }
            case "regex_match" -> {
                try {
                    r.passed = Pattern.compile(expected).matcher(actual).find();
                    r.message = r.passed ? "" : "'" + actual + "' does not match /" + expected + "/";
                } catch (Exception ex) {
                    r.passed = false;
                    r.message = "invalid regex: " + ex.getMessage();
                }
            }
            case "one_of" -> {
                // ExpectedValue is comma-separated: "OK,SUCCESS,PASS"
                String[] options = expected.split(",");
                boolean found = false;
                for (String opt : options) {
                    if (actual.equals(opt.trim())) { found = true; break; }
                }
                r.passed = found;
                r.message = r.passed ? "" : "'" + actual + "' is not one of [" + expected + "]";
            }
            default -> {
                r.passed = false;
                r.message = "unknown operator: " + op;
            }
        }
    }

    /**
     * Run a database assertion. The Path field contains the SQL query,
     * with ${placeholder} support for step variables. The query should
     * return a single value (first column of first row).
     */
    private static void evaluateDb(AssertionResult r, Assertion a,
                                    com.apitest.model.Environment env) {
        String op = a.operator() == null ? "" : a.operator().toLowerCase();

        if (env == null || env.dbUrl() == null || env.dbUrl().isEmpty()) {
            r.passed = false;
            r.actualValue = "";
            r.message = "No database configured on this environment (DbURL is empty)";
            return;
        }

        String sql = a.path();
        if (sql == null || sql.isEmpty()) {
            r.passed = false;
            r.message = "Path (SQL query) is empty";
            return;
        }

        try {
            // Resolve password from ${env.} or ${file.} syntax
            String password = com.apitest.dispatcher.SslConfig.resolveSecret(env.dbPassword());
            String user = com.apitest.dispatcher.SslConfig.resolveSecret(env.dbUser());
            String dbUrl = com.apitest.dispatcher.SslConfig.resolveSecret(env.dbUrl());

            // Load driver if specified
            if (env.dbDriver() != null && !env.dbDriver().isEmpty()) {
                Class.forName(env.dbDriver());
            }

            try (java.sql.Connection conn = java.sql.DriverManager.getConnection(dbUrl, user, password);
                 java.sql.Statement stmt = conn.createStatement();
                 java.sql.ResultSet rs = stmt.executeQuery(sql)) {

                switch (op) {
                    case "db_exists" -> {
                        r.passed = rs.next();
                        r.actualValue = r.passed ? "(row exists)" : "(no rows)";
                        r.message = r.passed ? "" : "query returned no rows";
                    }
                    case "db_equals" -> {
                        if (rs.next()) {
                            r.actualValue = rs.getString(1);
                            String expected = a.expectedValue() == null ? "" : a.expectedValue();
                            r.passed = expected.equals(r.actualValue);
                            r.message = r.passed ? "" : "expected '" + expected + "', got '" + r.actualValue + "'";
                        } else {
                            r.actualValue = "(no rows)";
                            r.passed = false;
                            r.message = "query returned no rows";
                        }
                    }
                    case "db_contains" -> {
                        if (rs.next()) {
                            r.actualValue = rs.getString(1);
                            String expected = a.expectedValue() == null ? "" : a.expectedValue();
                            r.passed = r.actualValue != null && r.actualValue.contains(expected);
                            r.message = r.passed ? "" : "'" + r.actualValue + "' does not contain '" + expected + "'";
                        } else {
                            r.actualValue = "(no rows)";
                            r.passed = false;
                            r.message = "query returned no rows";
                        }
                    }
                    default -> {
                        r.passed = false;
                        r.message = "unknown db operator: " + op;
                    }
                }
            }
        } catch (Exception ex) {
            r.passed = false;
            r.actualValue = "";
            r.message = "DB error: " + ex.getClass().getSimpleName() + ": " + ex.getMessage();
        }
    }
}
