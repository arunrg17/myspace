package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.List;

/**
 * Renders PDF pages as images and overlays precise highlight boxes
 * on text regions that the diff identified as different.
 *
 * <h2>Highlighting precision</h2>
 * <ul>
 *   <li>Only lines classified as ADDED, REMOVED, or CHANGED are highlighted.</li>
 *   <li>SAME lines are never highlighted.</li>
 *   <li>Text in ignored zones (header, footer, margins) is never highlighted —
 *       the same zone exclusion logic used during extraction is applied here.</li>
 *   <li>Highlights are drawn tight around the actual text bounding box,
 *       not around the whole line or arbitrary regions.</li>
 * </ul>
 */
final class PageRenderer {

    /** Render resolution. 150 DPI = clear and readable, reasonable file size. */
    private static final float DPI = 150f;

    // Highlight fill colours (semi-transparent)
    private static final Color FILL_REMOVED = new Color(229,  83,  83, 70);  // red
    private static final Color FILL_ADDED   = new Color( 67, 160,  71, 70);  // green
    private static final Color FILL_CHANGED = new Color(251, 140,   0, 70);  // amber

    // Highlight border colours (opaque)
    private static final Color BORDER_REMOVED = new Color(198,  40,  40);
    private static final Color BORDER_ADDED   = new Color( 46, 125,  50);
    private static final Color BORDER_CHANGED = new Color(230,  81,   0);

    private PageRenderer() {}

    // ════════════════════════════════════════════════════════════════════════
    //  DATA TYPES
    // ════════════════════════════════════════════════════════════════════════

    /** A rendered page as a base64 PNG string plus dimensions. */
    static final class RenderedPage {
        final int    pageIndex;
        final String base64Png;
        final int    widthPx;
        final int    heightPx;

        RenderedPage(int i, String b64, int w, int h) {
            pageIndex = i; base64Png = b64; widthPx = w; heightPx = h;
        }
    }

    /** A tight bounding box around a piece of text that needs highlighting. */
    private static final class TextBox {
        final PDFComparator.DiffType type;
        final float x, y, w, h;   // PDF user-space coordinates (points, origin bottom-left)

        TextBox(PDFComparator.DiffType t, float x, float y, float w, float h) {
            type = t; this.x = x; this.y = y; this.w = w; this.h = h;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Render all pages of a PDF to base64 PNG images.
     * Highlights are drawn on top where diff text was found on each page.
     *
     * @param pdfFile  the PDF to render
     * @param side     "left" (PDF1) or "right" (PDF2) — determines which diff rows to highlight
     * @param diff     the full diff result
     * @param config   filter config — used to re-apply zone exclusions
     * @return one RenderedPage per page of the PDF
     */
    static List<RenderedPage> render(File pdfFile,
                                      String side,
                                      List<PDFComparator.DiffRow> diff,
                                      FilterConfig config) throws IOException {

        // Step 1: build a map of {normalisedText → DiffType} for lines that changed
        // We only care about lines on the relevant side
        Map<String, PDFComparator.DiffType> diffMap = buildDiffMap(diff, side);

        // Step 2: walk the PDF extracting text positions, matching to diffMap
        // Zone exclusions are applied here — text in ignored zones is skipped
        Map<Integer, List<TextBox>> boxesByPage = collectTextBoxes(pdfFile, diffMap, config);

        // Step 3: render each page and overlay the highlight boxes
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                List<TextBox> boxes = boxesByPage.getOrDefault(p, Collections.emptyList());
                if (!boxes.isEmpty()) {
                    PDPage page = doc.getPage(p);
                    drawHighlights(img, page, boxes);
                }
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BUILD DIFF MAP
    //  Only lines that actually differ on this side are included.
    //  SAME lines are excluded — they are never highlighted.
    // ════════════════════════════════════════════════════════════════════════

    private static Map<String, PDFComparator.DiffType> buildDiffMap(
            List<PDFComparator.DiffRow> diff, String side) {

        Map<String, PDFComparator.DiffType> map = new LinkedHashMap<>();
        boolean isLeft = "left".equals(side);

        for (PDFComparator.DiffRow row : diff) {
            if (row.type == PDFComparator.DiffType.SAME) continue;

            // For left side: show REMOVED and CHANGED lines
            // For right side: show ADDED and CHANGED lines
            String text = isLeft ? row.left : row.right;
            if (text == null || text.trim().isEmpty()) continue;

            boolean relevant = isLeft
                ? (row.type == PDFComparator.DiffType.REMOVED || row.type == PDFComparator.DiffType.CHANGED)
                : (row.type == PDFComparator.DiffType.ADDED   || row.type == PDFComparator.DiffType.CHANGED);

            if (relevant) {
                map.put(text.trim(), row.type);
            }
        }
        return map;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  COLLECT TEXT BOXES
    //  Walk the PDF extracting character positions for each diff line.
    //  Zone exclusions are applied identically to extraction — so text in
    //  ignored zones (header, footer, margins) is never in the diff map
    //  and therefore never highlighted.
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, List<TextBox>> collectTextBoxes(
            File pdfFile,
            Map<String, PDFComparator.DiffType> diffMap,
            FilterConfig config) throws IOException {

        Map<Integer, List<TextBox>> result = new HashMap<>();
        if (diffMap.isEmpty()) return result;

        try (PDDocument doc = PDDocument.load(pdfFile)) {
            BoxCollector collector = new BoxCollector(config, diffMap);
            collector.getText(doc);
            result.putAll(collector.result);
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BOX COLLECTOR — PDFTextStripper subclass
    // ════════════════════════════════════════════════════════════════════════

    private static final class BoxCollector extends PDFTextStripper {

        private final FilterConfig config;
        private final Map<String, PDFComparator.DiffType> diffMap;
        final Map<Integer, List<TextBox>> result = new HashMap<>();

        // Accumulate characters for the current line
        private final StringBuilder lineBuf = new StringBuilder();
        private final List<float[]> charPositions = new ArrayList<>(); // [x, y, w, h] per char
        private int  currentPage = 0;
        private float pageH = 792f;
        private float pageW = 595f;

        BoxCollector(FilterConfig config, Map<String, PDFComparator.DiffType> diffMap)
                throws IOException {
            super();
            this.config  = config;
            this.diffMap = diffMap;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle box = page.getMediaBox();
            pageH = box.getHeight();
            pageW = box.getWidth();
            currentPage = getCurrentPageNo() - 1;
            flushLine();  // flush any pending line from previous page
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions) throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }

            // Compute average position to apply zone exclusions
            float sumX = 0, sumY = 0;
            for (TextPosition tp : positions) { sumX += tp.getX(); sumY += tp.getY(); }
            float avgX = sumX / positions.size();
            float avgY = sumY / positions.size();
            float yTop = pageH - avgY;

            // Apply same zone exclusions as text extraction — text in ignored
            // zones is not in the diffMap and must not be highlighted
            if (config.isIgnoreHeader()      && yTop  < pageH * (config.getHeaderPct()  / 100.0)) return;
            if (config.isIgnoreFooter()      && yTop  > pageH * ((100.0 - config.getFooterPct())  / 100.0)) return;
            if (config.isIgnoreLeftMargin()  && avgX  < pageW * (config.getMarginPct()  / 100.0)) return;
            if (config.isIgnoreRightMargin() && avgX  > pageW * ((100.0 - config.getMarginPct())  / 100.0)) return;

            // Accumulate into current line buffer
            lineBuf.append(text);
            for (TextPosition tp : positions) {
                charPositions.add(new float[]{ tp.getX(), tp.getY(), tp.getWidth(), tp.getHeight() });
            }

            super.writeString(text, positions);
        }

        @Override
        protected void writeLineSeparator() throws IOException {
            flushLine();
            super.writeLineSeparator();
        }

        @Override
        protected void endPage(PDPage page) throws IOException {
            flushLine();
            super.endPage(page);
        }

        /** Try to match accumulated line buffer to a diff line; emit a TextBox if matched. */
        private void flushLine() {
            String lineText = lineBuf.toString().trim();
            lineBuf.setLength(0);

            if (lineText.isEmpty() || charPositions.isEmpty()) {
                charPositions.clear();
                return;
            }

            PDFComparator.DiffType matchType = findMatch(lineText);
            if (matchType != null && !charPositions.isEmpty()) {
                // Compute tight bounding box over all characters in this line
                float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
                float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
                for (float[] cp : charPositions) {
                    minX = Math.min(minX, cp[0]);
                    minY = Math.min(minY, cp[1] - cp[3]);  // y - height (PDF Y-up)
                    maxX = Math.max(maxX, cp[0] + cp[2]);  // x + width
                    maxY = Math.max(maxY, cp[1]);           // baseline
                }
                float boxX = minX;
                float boxY = minY;
                float boxW = maxX - minX;
                float boxH = maxY - minY;

                // Add small padding for readability
                float pad = 1.5f;
                result.computeIfAbsent(currentPage, k -> new ArrayList<>())
                    .add(new TextBox(matchType, boxX - pad, boxY - pad, boxW + pad * 2, boxH + pad * 2));
            }

            charPositions.clear();
        }

        private PDFComparator.DiffType findMatch(String lineText) {
            // Exact match
            if (diffMap.containsKey(lineText)) return diffMap.get(lineText);

            // Partial match: the extracted run may be a fragment of a longer diff line
            for (Map.Entry<String, PDFComparator.DiffType> entry : diffMap.entrySet()) {
                String diffText = entry.getKey();
                // Only match if the fragment is meaningful (avoid matching single chars)
                if (lineText.length() >= 4 && diffText.length() >= 4
                        && diffText.contains(lineText)) {
                    return entry.getValue();
                }
            }
            return null;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DRAW HIGHLIGHTS
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Draw highlight rectangles on the rendered page image.
     * Converts PDF coordinates (points, Y-up, bottom-left origin) to
     * pixel coordinates (Y-down, top-left origin).
     */
    private static void drawHighlights(BufferedImage img, PDPage page,
                                        List<TextBox> boxes) {
        PDRectangle media = page.getMediaBox();
        float pdfW = media.getWidth();
        float pdfH = media.getHeight();
        float scaleX = (float) img.getWidth()  / pdfW;
        float scaleY = (float) img.getHeight() / pdfH;

        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,      RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL,    RenderingHints.VALUE_STROKE_PURE);

        for (TextBox box : boxes) {
            // PDF: origin bottom-left, Y increases up
            // Image: origin top-left, Y increases down
            int px = Math.round(box.x  * scaleX);
            int py = Math.round((pdfH - box.y - box.h) * scaleY);
            int pw = Math.max(Math.round(box.w * scaleX), 4);
            int ph = Math.max(Math.round(box.h * scaleY), 4);

            // Guard: keep within image bounds
            px = Math.max(0, Math.min(px, img.getWidth()  - 1));
            py = Math.max(0, Math.min(py, img.getHeight() - 1));
            pw = Math.min(pw, img.getWidth()  - px);
            ph = Math.min(ph, img.getHeight() - py);
            if (pw <= 0 || ph <= 0) continue;

            Color fill, border;
            switch (box.type) {
                case REMOVED: fill = FILL_REMOVED; border = BORDER_REMOVED; break;
                case ADDED:   fill = FILL_ADDED;   border = BORDER_ADDED;   break;
                case CHANGED: fill = FILL_CHANGED; border = BORDER_CHANGED; break;
                default: continue;
            }

            g.setColor(fill);
            g.fillRect(px, py, pw, ph);
            g.setColor(border);
            g.setStroke(new BasicStroke(1.2f));
            g.drawRect(px, py, pw, ph);
        }
        g.dispose();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BASE64 PNG ENCODER
    // ════════════════════════════════════════════════════════════════════════

    private static String toPng(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }
}
