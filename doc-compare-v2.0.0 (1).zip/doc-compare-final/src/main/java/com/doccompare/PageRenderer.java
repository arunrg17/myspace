package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.List;

/**
 * Renders PDF pages with precise highlight boxes on differing lines.
 *
 * <h2>Two-pass design — this is the key to correctness</h2>
 *
 * <p>Previous versions tried to collect line positions using PDFBox
 * {@code writeString()} / {@code writeLineSeparator()} callbacks while
 * also counting line numbers. This fails because:
 * <ul>
 *   <li>{@code writeLineSeparator()} fires between every text run in PDF
 *       stream order, NOT in visual reading order.</li>
 *   <li>Vertical margin text (COSREP IDs), multi-column layouts, and
 *       text-run boundaries all cause the callback line counter to diverge
 *       from the line counter in {@code getText()} (which is sorted by
 *       position and groups runs into logical lines).</li>
 *   <li>Result: wrong lines get highlighted.</li>
 * </ul>
 *
 * <p>This version uses two completely independent passes:
 * <ol>
 *   <li><b>Pass 1 — line number extraction:</b> Call
 *       {@code PDFComparator.extractLines()} — exactly the same method used
 *       during comparison. This produces the authoritative list of
 *       (lineNumber, text) pairs. Line numbers here are guaranteed to match
 *       the diff result.</li>
 *   <li><b>Pass 2 — position collection:</b> Walk the PDF with a custom
 *       stripper that records every text run's (text, page, x, y) after
 *       applying zone filters. Runs are then grouped by Y-coordinate
 *       proximity to reconstruct visual lines with their positions.</li>
 *   <li><b>Matching:</b> For each extracted line that needs highlighting,
 *       find the best-matching position group using token overlap similarity.
 *       This is robust to minor text differences from multi-run lines.</li>
 * </ol>
 *
 * <p>Because line numbers come from the exact same code path as the diff,
 * and positions come from independent spatial grouping, the two can never
 * go out of sync.
 */
final class PageRenderer {

    private static final float DPI   = 150f;

    // Highlight colours
    private static final Color FILL_REM = new Color(220,  50,  50,  55);
    private static final Color FILL_ADD = new Color( 40, 160,  40,  55);
    private static final Color FILL_CHG = new Color(240, 130,   0,  55);
    private static final Color LINE_REM = new Color(180,  20,  20, 210);
    private static final Color LINE_ADD = new Color( 20, 130,  20, 210);
    private static final Color LINE_CHG = new Color(200,  90,   0, 210);

    private PageRenderer() {}

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC DATA
    // ════════════════════════════════════════════════════════════════════════

    static final class RenderedPage {
        final int    pageIndex;
        final String base64Png;
        final int    widthPx;
        final int    heightPx;
        RenderedPage(int i, String b64, int w, int h) {
            pageIndex = i; base64Png = b64; widthPx = w; heightPx = h;
        }
    }

    /** One text run collected from the PDF with its spatial coordinates. */
    private static final class TextRun {
        final String text;
        final int    page;       // 0-based
        final float  xLeft;      // PDF points, from left
        final float  xRight;
        final float  yTop;       // PDF points, from TOP of page (converted from PDF Y-up)
        final float  yBottom;
        TextRun(String t, int p, float xl, float xr, float yt, float yb) {
            text=t; page=p; xLeft=xl; xRight=xr; yTop=yt; yBottom=yb;
        }
    }

    /** A visual line reconstructed by grouping runs with similar Y coordinates. */
    private static final class VisualLine {
        final int   page;
        final float yTop;
        final float yBottom;
        final float xLeft;
        final float xRight;
        final String combinedText;   // all runs joined for matching
        VisualLine(int p, float yt, float yb, float xl, float xr, String txt) {
            page=p; yTop=yt; yBottom=yb; xLeft=xl; xRight=xr; combinedText=txt;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    static List<RenderedPage> render(File pdfFile,
                                      String side,
                                      List<PDFComparator.DiffRow> diff,
                                      FilterConfig config) throws IOException {
        // ── Pass 1: get the exact same lines (and line numbers) as the diff ──
        String[] extractedLines;
        try {
            extractedLines = PDFComparator.extractLines(pdfFile, config);
        } catch (Exception ex) {
            throw new IOException("Text extraction failed: " + ex.getMessage(), ex);
        }

        // ── Build highlight map: lineNumber → DiffType (only diff lines) ──
        Map<Integer, PDFComparator.DiffType> hlMap = buildHighlightMap(diff, side);

        if (hlMap.isEmpty()) {
            // No diffs on this side — render plain pages
            return renderPlain(pdfFile);
        }

        // ── Pass 2: collect all text runs with spatial coordinates ──
        List<TextRun> runs = collectRuns(pdfFile, config);

        // Group runs into visual lines by page and Y-proximity
        Map<Integer, List<VisualLine>> visualLinesByPage = groupIntoLines(runs);

        // ── Match extracted lines to visual lines ──
        // For each line number in hlMap, find the matching visual line
        Map<Integer, List<VisualLine>> highlightsByPage = new HashMap<>();
        for (Map.Entry<Integer, PDFComparator.DiffType> entry : hlMap.entrySet()) {
            int lineNo = entry.getKey();
            if (lineNo < 1 || lineNo > extractedLines.length) continue;
            String lineText = extractedLines[lineNo - 1];  // 0-indexed array

            // Find the visual line across all pages that best matches this text
            VisualLine best = findBestMatch(lineText, visualLinesByPage);
            if (best != null) {
                highlightsByPage.computeIfAbsent(best.page, k -> new ArrayList<>())
                    .add(best);
                // Tag this visual line with the diff type for drawing
                taggedTypes.put(best, entry.getValue());
            }
        }

        // ── Render pages with highlights ──
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                List<VisualLine> pageHL = highlightsByPage.getOrDefault(p, Collections.emptyList());
                if (!pageHL.isEmpty()) {
                    drawHighlights(img, doc.getPage(p), pageHL);
                }
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        } finally {
            taggedTypes.clear();
        }
        return result;
    }

    // Thread-local map to pass DiffType to drawHighlights without changing VisualLine
    private static final Map<VisualLine, PDFComparator.DiffType> taggedTypes =
        new IdentityHashMap<>();

    // ════════════════════════════════════════════════════════════════════════
    //  HIGHLIGHT MAP
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, PDFComparator.DiffType> buildHighlightMap(
            List<PDFComparator.DiffRow> diff, String side) {
        Map<Integer, PDFComparator.DiffType> map = new LinkedHashMap<>();
        boolean isLeft = "left".equals(side);
        for (PDFComparator.DiffRow row : diff) {
            if (row.type == PDFComparator.DiffType.SAME) continue;
            boolean relevant = isLeft
                ? (row.type == PDFComparator.DiffType.REMOVED || row.type == PDFComparator.DiffType.CHANGED)
                : (row.type == PDFComparator.DiffType.ADDED   || row.type == PDFComparator.DiffType.CHANGED);
            if (!relevant) continue;
            int lineNo = isLeft ? row.leftLineNo : row.rightLineNo;
            if (lineNo > 0) map.put(lineNo, row.type);
        }
        return map;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PASS 2: COLLECT TEXT RUNS
    //  Walks the PDF collecting (text, page, x, y) for every run,
    //  applying the same zone filters as extraction so excluded text
    //  is never available to match against.
    // ════════════════════════════════════════════════════════════════════════

    private static List<TextRun> collectRuns(File pdfFile, FilterConfig config)
            throws IOException {
        RunCollector collector = new RunCollector(config);
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            collector.getText(doc);
        }
        return collector.runs;
    }

    private static final class RunCollector extends PDFTextStripper {
        private final FilterConfig config;
        final List<TextRun> runs = new ArrayList<>();
        private int   page = 0;
        private float pageH = 842f;
        private float pageW = 595f;

        RunCollector(FilterConfig config) throws IOException {
            super();
            this.config = config;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage pg) throws IOException {
            PDRectangle box = pg.getMediaBox();
            pageH = box.getHeight();
            pageW = box.getWidth();
            page  = getCurrentPageNo() - 1;
            super.startPage(pg);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions)
                throws IOException {
            if (positions == null || positions.isEmpty() || text.trim().isEmpty()) {
                super.writeString(text, positions);
                return;
            }

            // Compute bounding box of this run
            float minX = Float.MAX_VALUE, maxX = -Float.MAX_VALUE;
            float minYBase = Float.MAX_VALUE, maxYTop = -Float.MAX_VALUE;
            float sumX = 0, sumY = 0;
            for (TextPosition tp : positions) {
                sumX += tp.getX();
                sumY += tp.getY();
                minX    = Math.min(minX, tp.getX());
                maxX    = Math.max(maxX, tp.getX() + tp.getWidth());
                minYBase = Math.min(minYBase, tp.getY());
                maxYTop  = Math.max(maxYTop,  tp.getY() + tp.getHeight());
            }
            float avgX  = sumX / positions.size();
            float avgY  = sumY / positions.size();

            // PDF Y-up → top-origin (Y-down from top of page)
            float yTopFromPageTop    = pageH - maxYTop;
            float yBottomFromPageTop = pageH - minYBase;

            // Apply zone filters — same logic as ZoneAwareStripper
            float yFromTop = pageH - avgY;
            if (config.isIgnoreHeader()      && yFromTop  < pageH * (config.getHeaderPct() / 100.0)) return;
            if (config.isIgnoreFooter()      && yFromTop  > pageH * ((100.0 - config.getFooterPct()) / 100.0)) return;
            if (config.isIgnoreLeftMargin()  && avgX      < pageW * (config.getMarginPct() / 100.0)) return;
            if (config.isIgnoreRightMargin() && avgX      > pageW * ((100.0 - config.getMarginPct()) / 100.0)) return;

            runs.add(new TextRun(text, page, minX, maxX,
                yTopFromPageTop, yBottomFromPageTop));
            super.writeString(text, positions);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  GROUP RUNS INTO VISUAL LINES
    //  Runs on the same visual line share approximately the same Y coordinate.
    //  Tolerance of 3 points handles minor baseline variation in multi-size text.
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, List<VisualLine>> groupIntoLines(List<TextRun> runs) {
        // Separate by page first
        Map<Integer, List<TextRun>> byPage = new LinkedHashMap<>();
        for (TextRun r : runs) {
            byPage.computeIfAbsent(r.page, k -> new ArrayList<>()).add(r);
        }

        Map<Integer, List<VisualLine>> result = new LinkedHashMap<>();
        float Y_TOLERANCE = 3.0f;  // points

        for (Map.Entry<Integer, List<TextRun>> entry : byPage.entrySet()) {
            int pageIdx = entry.getKey();
            List<TextRun> pageRuns = entry.getValue();
            // Sort by Y then X
            pageRuns.sort(Comparator.comparingDouble((TextRun r) -> r.yTop)
                                    .thenComparingDouble(r -> r.xLeft));

            List<VisualLine> lines = new ArrayList<>();
            List<TextRun> group = new ArrayList<>();

            for (TextRun run : pageRuns) {
                if (group.isEmpty()) {
                    group.add(run);
                } else {
                    // Check if this run belongs to the current line
                    float groupYCenter = group.stream()
                        .mapToDouble(r -> (r.yTop + r.yBottom) / 2.0f).average().orElse(0);
                    float runYCenter = (run.yTop + run.yBottom) / 2.0f;

                    if (Math.abs(runYCenter - groupYCenter) <= Y_TOLERANCE) {
                        group.add(run);
                    } else {
                        lines.add(toVisualLine(pageIdx, group));
                        group.clear();
                        group.add(run);
                    }
                }
            }
            if (!group.isEmpty()) lines.add(toVisualLine(pageIdx, group));
            result.put(pageIdx, lines);
        }
        return result;
    }

    private static VisualLine toVisualLine(int page, List<TextRun> group) {
        float yTop    = group.stream().mapToDouble(r -> r.yTop).min().orElse(0);
        float yBottom = group.stream().mapToDouble(r -> r.yBottom).max().orElse(0);
        float xLeft   = group.stream().mapToDouble(r -> r.xLeft).min().orElse(0);
        float xRight  = group.stream().mapToDouble(r -> r.xRight).max().orElse(0);
        // Sort runs left-to-right and join their text
        group.sort(Comparator.comparingDouble(r -> r.xLeft));
        StringBuilder sb = new StringBuilder();
        for (TextRun r : group) {
            if (sb.length() > 0 && !r.text.startsWith(" ")) sb.append(" ");
            sb.append(r.text.trim());
        }
        return new VisualLine(page, yTop, yBottom, xLeft, xRight, sb.toString().trim());
    }

    // ════════════════════════════════════════════════════════════════════════
    //  FIND BEST MATCH
    //  Finds the visual line whose text best matches the extracted line text.
    //  Uses token overlap (Jaccard similarity) which is robust to:
    //    - Minor whitespace/punctuation differences
    //    - Bullet characters stripped by processLine
    //    - Multi-run lines joined differently
    // ════════════════════════════════════════════════════════════════════════

    private static VisualLine findBestMatch(String extractedText,
                                             Map<Integer, List<VisualLine>> linesByPage) {
        String normExt = normaliseForMatch(extractedText);
        if (normExt.isEmpty()) return null;

        VisualLine best      = null;
        double     bestScore = 0.45;  // minimum threshold

        for (List<VisualLine> pageLines : linesByPage.values()) {
            for (VisualLine vl : pageLines) {
                String normVL = normaliseForMatch(vl.combinedText);
                double score  = tokenOverlap(normExt, normVL);
                if (score > bestScore) {
                    bestScore = score;
                    best      = vl;
                }
            }
        }
        return best;
    }

    /** Strip noise characters before matching: bullets, control chars, extra spaces. */
    private static String normaliseForMatch(String s) {
        if (s == null) return "";
        return s.replaceAll("[\\x00-\\x1f\u007f\u2022\u2023\u25aa\u25cf\uf0b7•]", " ")
                .replaceAll("\\s+", " ")
                .trim()
                .toLowerCase();
    }

    /** Jaccard token overlap between two strings. */
    private static double tokenOverlap(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0.0;
        Set<String> ta = new HashSet<>(Arrays.asList(a.split("\\s+")));
        Set<String> tb = new HashSet<>(Arrays.asList(b.split("\\s+")));
        ta.remove(""); tb.remove("");
        if (ta.isEmpty() || tb.isEmpty()) return 0.0;
        Set<String> intersection = new HashSet<>(ta);
        intersection.retainAll(tb);
        Set<String> union = new HashSet<>(ta);
        union.addAll(tb);
        return (double) intersection.size() / union.size();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DRAW HIGHLIGHTS
    // ════════════════════════════════════════════════════════════════════════

    private static void drawHighlights(BufferedImage img, PDPage page,
                                        List<VisualLine> lines) {
        PDRectangle media = page.getMediaBox();
        float pdfW  = media.getWidth();
        float pdfH  = media.getHeight();
        float scaleX = (float) img.getWidth()  / pdfW;
        float scaleY = (float) img.getHeight() / pdfH;

        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,   RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

        for (VisualLine vl : lines) {
            PDFComparator.DiffType type = taggedTypes.get(vl);
            if (type == null) continue;

            // vl.yTop/yBottom are already in top-origin coordinates (from RunCollector)
            int px = Math.max(0, (int)(vl.xLeft  * scaleX) - 2);
            int py = Math.max(0, (int)(vl.yTop   * scaleY) - 1);
            int pr = Math.min(img.getWidth()  - 1, (int)(vl.xRight  * scaleX) + 2);
            int pb = Math.min(img.getHeight() - 1, (int)(vl.yBottom * scaleY) + 2);
            int pw = Math.max(4, pr - px);
            int ph = Math.max(3, pb - py);

            Color fill, border;
            switch (type) {
                case REMOVED: fill = FILL_REM; border = LINE_REM; break;
                case ADDED:   fill = FILL_ADD; border = LINE_ADD; break;
                case CHANGED: fill = FILL_CHG; border = LINE_CHG; break;
                default: continue;
            }

            g.setColor(fill);
            g.fillRect(px, py, pw, ph);
            g.setColor(border);
            g.setStroke(new BasicStroke(1.0f));
            g.drawRect(px, py, pw, ph);
        }
        g.dispose();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PLAIN RENDER (no diffs on this side)
    // ════════════════════════════════════════════════════════════════════════

    private static List<RenderedPage> renderPlain(File pdfFile) throws IOException {
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PNG ENCODER
    // ════════════════════════════════════════════════════════════════════════

    private static String toPng(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }
}
