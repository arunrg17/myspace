package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Renders PDF pages as images with precise highlight boxes on differing lines.
 *
 * <h2>Two-pass design</h2>
 * <p>Pass 1: call {@link PDFComparator#extractLines} — the exact method used
 * during comparison — to get (lineNumber, text) pairs. These line numbers
 * match the diff result by construction.
 *
 * <p>Pass 2: walk the PDF with {@link RunCollector} to record every text run's
 * coordinates after applying zone filters. Group runs by Y-proximity into
 * visual lines.
 *
 * <p>Matching: for each line number that needs highlighting, find the visual
 * line whose text best matches using Jaccard token overlap. Draw a highlight
 * box at the visual line's coordinates.
 *
 * <p>Result: only lines classified as ADDED/REMOVED/CHANGED by the diff are
 * highlighted. SAME lines are structurally impossible to highlight.
 */
final class PageRenderer {

    private static final float DPI = 150f;

    private static final Color FILL_REM  = new Color(220,  50,  50,  55);
    private static final Color FILL_ADD  = new Color( 40, 160,  40,  55);
    private static final Color FILL_CHG  = new Color(240, 130,   0,  55);
    private static final Color BORDER_REM = new Color(180,  20,  20, 210);
    private static final Color BORDER_ADD = new Color( 20, 130,  20, 210);
    private static final Color BORDER_CHG = new Color(200,  90,   0, 210);

    private PageRenderer() {}

    // ── Public types ─────────────────────────────────────────────────────────

    static final class RenderedPage {
        final int    pageIndex;
        final String base64Png;
        final int    widthPx;
        final int    heightPx;

        RenderedPage(int i, String b64, int w, int h) {
            pageIndex = i; base64Png = b64; widthPx = w; heightPx = h;
        }
    }

    // ── Private data types ───────────────────────────────────────────────────

    /** One text run extracted from the PDF with its bounding coordinates. */
    private static final class TextRun {
        final String text;
        final int    page;
        /** Y from top of page (converted from PDF Y-up). */
        final float  yTop;
        final float  yBottom;
        final float  xLeft;
        final float  xRight;

        TextRun(String t, int p, float yt, float yb, float xl, float xr) {
            text = t; page = p; yTop = yt; yBottom = yb; xLeft = xl; xRight = xr;
        }
    }

    /** A visual line formed by grouping runs with similar Y coordinates. */
    private static final class VisualLine {
        final int    page;
        final float  yTop;
        final float  yBottom;
        final float  xLeft;
        final float  xRight;
        final String combinedText;

        VisualLine(int p, float yt, float yb, float xl, float xr, String txt) {
            page = p; yTop = yt; yBottom = yb; xLeft = xl; xRight = xr;
            combinedText = txt;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    static List<RenderedPage> render(File pdfFile,
                                      String side,
                                      List<PDFComparator.DiffRow> diff,
                                      FilterConfig config) throws IOException {
        // Pass 1: get extracted lines — same line numbers as the diff
        final String[] extractedLines;
        try {
            extractedLines = PDFComparator.extractLines(pdfFile, config);
        } catch (Exception ex) {
            throw new IOException("Text extraction failed: " + ex.getMessage(), ex);
        }

        // Build highlight map: lineNumber → DiffType (ADDED/REMOVED/CHANGED only)
        Map<Integer, PDFComparator.DiffType> hlMap = buildHighlightMap(diff, side);
        if (hlMap.isEmpty()) {
            return renderPlain(pdfFile);
        }

        // Pass 2: collect text runs with coordinates (zone-filtered)
        List<TextRun> runs = collectRuns(pdfFile, config);

        // Group runs into visual lines
        Map<Integer, List<VisualLine>> visualLinesByPage = groupIntoLines(runs);

        // Match each diff line number to a visual line
        // Use a separate map to associate each VisualLine with its DiffType
        Map<VisualLine, PDFComparator.DiffType> typeByLine = new LinkedHashMap<>();
        Map<Integer, List<VisualLine>> highlightsByPage    = new LinkedHashMap<>();

        for (Map.Entry<Integer, PDFComparator.DiffType> entry : hlMap.entrySet()) {
            int lineNo = entry.getKey();
            if (lineNo < 1 || lineNo > extractedLines.length) continue;
            String lineText = extractedLines[lineNo - 1];

            VisualLine best = findBestMatch(lineText, visualLinesByPage);
            if (best != null) {
                typeByLine.put(best, entry.getValue());
                highlightsByPage.computeIfAbsent(best.page, k -> new ArrayList<>()).add(best);
            }
        }

        // Render pages with highlight overlays
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                List<VisualLine> pageHL =
                    highlightsByPage.getOrDefault(p, Collections.<VisualLine>emptyList());
                if (!pageHL.isEmpty()) {
                    drawHighlights(img, doc.getPage(p), pageHL, typeByLine);
                }
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HIGHLIGHT MAP
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, PDFComparator.DiffType> buildHighlightMap(
            List<PDFComparator.DiffRow> diff, String side) {

        Map<Integer, PDFComparator.DiffType> map = new LinkedHashMap<>();
        boolean isLeft = "left".equals(side);

        for (PDFComparator.DiffRow row : diff) {
            if (row.type == PDFComparator.DiffType.SAME) continue;

            boolean relevant = isLeft
                ? (row.type == PDFComparator.DiffType.REMOVED
                   || row.type == PDFComparator.DiffType.CHANGED)
                : (row.type == PDFComparator.DiffType.ADDED
                   || row.type == PDFComparator.DiffType.CHANGED);
            if (!relevant) continue;

            int lineNo = isLeft ? row.leftLineNo : row.rightLineNo;
            if (lineNo > 0) map.put(lineNo, row.type);
        }
        return map;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PASS 2: COLLECT TEXT RUNS
    // ════════════════════════════════════════════════════════════════════════

    private static List<TextRun> collectRuns(File pdfFile, FilterConfig config)
            throws IOException {
        RunCollector collector = new RunCollector(config);
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            collector.getText(doc);
        }
        return collector.runs;
    }

    /**
     * Collects every accepted text run with its spatial bounding box.
     * Applies identical zone filters to ZoneAwareStripper in PDFComparator.
     */
    private static final class RunCollector extends PDFTextStripper {

        private final FilterConfig config;
        final List<TextRun> runs = new ArrayList<>();

        private int   currentPage = 0;
        private float pageH       = 842f;
        private float pageW       = 595f;

        RunCollector(FilterConfig config) throws IOException {
            super();
            this.config = config;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle box = page.getMediaBox();
            pageH = box.getHeight();
            pageW = box.getWidth();
            currentPage = getCurrentPageNo() - 1;  // convert to 0-based
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions)
                throws IOException {
            if (positions == null || positions.isEmpty() || text.trim().isEmpty()) {
                super.writeString(text, positions);
                return;
            }

            // Compute average and bounding box from character positions
            float sumX = 0f, sumY = 0f;
            float minX =  Float.MAX_VALUE, maxX = -Float.MAX_VALUE;
            float minYBase = Float.MAX_VALUE, maxYTop = -Float.MAX_VALUE;

            for (TextPosition tp : positions) {
                sumX += tp.getX();
                sumY += tp.getY();
                minX     = Math.min(minX,     tp.getX());
                maxX     = Math.max(maxX,     tp.getX() + tp.getWidth());
                // PDFBox Y is baseline; add height to get top of glyph
                minYBase = Math.min(minYBase, tp.getY());
                maxYTop  = Math.max(maxYTop,  tp.getY() + tp.getHeight());
            }
            float avgX = sumX / positions.size();
            float avgY = sumY / positions.size();

            // Zone filters — identical to ZoneAwareStripper
            float yFromTop = pageH - avgY;
            if (config.isIgnoreHeader()
                    && yFromTop < pageH * (config.getHeaderPct() / 100.0)) {
                return;
            }
            if (config.isIgnoreFooter()
                    && yFromTop > pageH * ((100.0 - config.getFooterPct()) / 100.0)) {
                return;
            }
            if (config.isIgnoreLeftMargin()
                    && avgX < pageW * (config.getMarginPct() / 100.0)) {
                return;
            }
            if (config.isIgnoreRightMargin()
                    && avgX > pageW * ((100.0 - config.getMarginPct()) / 100.0)) {
                return;
            }

            // Convert PDF Y-up to image Y-down (top-origin coordinates)
            float yTopImg    = pageH - maxYTop;
            float yBottomImg = pageH - minYBase;

            runs.add(new TextRun(text, currentPage, yTopImg, yBottomImg, minX, maxX));
            super.writeString(text, positions);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  GROUP RUNS INTO VISUAL LINES
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, List<VisualLine>> groupIntoLines(List<TextRun> runs) {
        // Separate by page
        Map<Integer, List<TextRun>> byPage = new LinkedHashMap<>();
        for (TextRun r : runs) {
            byPage.computeIfAbsent(r.page, k -> new ArrayList<>()).add(r);
        }

        final float Y_TOLERANCE = 3.0f;  // points — handles minor baseline variation
        Map<Integer, List<VisualLine>> result = new LinkedHashMap<>();

        for (Map.Entry<Integer, List<TextRun>> entry : byPage.entrySet()) {
            int pageIdx = entry.getKey();
            List<TextRun> pageRuns = new ArrayList<>(entry.getValue());

            // Sort by Y (top) then X (left)
            Collections.sort(pageRuns, new Comparator<TextRun>() {
                @Override
                public int compare(TextRun a, TextRun b) {
                    int c = Float.compare(a.yTop, b.yTop);
                    return c != 0 ? c : Float.compare(a.xLeft, b.xLeft);
                }
            });

            List<VisualLine> lines = new ArrayList<>();
            List<TextRun>    group = new ArrayList<>();

            for (TextRun run : pageRuns) {
                if (group.isEmpty()) {
                    group.add(run);
                } else {
                    float groupYCenter = groupYCenter(group);
                    float runYCenter   = (run.yTop + run.yBottom) / 2.0f;
                    if (Math.abs(runYCenter - groupYCenter) <= Y_TOLERANCE) {
                        group.add(run);
                    } else {
                        lines.add(buildVisualLine(pageIdx, group));
                        group.clear();
                        group.add(run);
                    }
                }
            }
            if (!group.isEmpty()) lines.add(buildVisualLine(pageIdx, group));
            result.put(pageIdx, lines);
        }
        return result;
    }

    private static float groupYCenter(List<TextRun> group) {
        float sum = 0f;
        for (TextRun r : group) sum += (r.yTop + r.yBottom) / 2.0f;
        return sum / group.size();
    }

    private static VisualLine buildVisualLine(int page, List<TextRun> group) {
        float yTop    = group.get(0).yTop;
        float yBottom = group.get(0).yBottom;
        float xLeft   = group.get(0).xLeft;
        float xRight  = group.get(0).xRight;

        for (TextRun r : group) {
            if (r.yTop    < yTop)    yTop    = r.yTop;
            if (r.yBottom > yBottom) yBottom = r.yBottom;
            if (r.xLeft   < xLeft)   xLeft   = r.xLeft;
            if (r.xRight  > xRight)  xRight  = r.xRight;
        }

        // Sort runs left-to-right, then join text
        Collections.sort(group, new Comparator<TextRun>() {
            @Override
            public int compare(TextRun a, TextRun b) {
                return Float.compare(a.xLeft, b.xLeft);
            }
        });
        StringBuilder sb = new StringBuilder();
        for (TextRun r : group) {
            String t = r.text.trim();
            if (t.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(t);
        }
        return new VisualLine(page, yTop, yBottom, xLeft, xRight, sb.toString().trim());
    }

    // ════════════════════════════════════════════════════════════════════════
    //  FIND BEST MATCH
    //  Jaccard token overlap — robust to bullet characters and run boundaries.
    // ════════════════════════════════════════════════════════════════════════

    private static VisualLine findBestMatch(String extractedText,
                                             Map<Integer, List<VisualLine>> linesByPage) {
        String normExt = normalise(extractedText);
        if (normExt.isEmpty()) return null;

        VisualLine best      = null;
        double     bestScore = 0.45;  // minimum threshold

        for (List<VisualLine> pageLines : linesByPage.values()) {
            for (VisualLine vl : pageLines) {
                double score = tokenOverlap(normExt, normalise(vl.combinedText));
                if (score > bestScore) {
                    bestScore = score;
                    best      = vl;
                }
            }
        }
        return best;
    }

    private static String normalise(String s) {
        if (s == null) return "";
        // Strip control characters, bullet symbols
        return s.replaceAll("[\\x00-\\x1f\u007f\u2022\u2023\u25aa\u25cf\uf0b7\u007f]", " ")
                .replaceAll("\\s+", " ")
                .trim()
                .toLowerCase();
    }

    private static double tokenOverlap(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0.0;
        Set<String> ta = new HashSet<>(Arrays.asList(a.split("\\s+")));
        Set<String> tb = new HashSet<>(Arrays.asList(b.split("\\s+")));
        ta.remove(""); tb.remove("");
        if (ta.isEmpty() || tb.isEmpty()) return 0.0;
        Set<String> intersection = new HashSet<>(ta);
        intersection.retainAll(tb);
        Set<String> union = new HashSet<>(ta);
        union.addAll(tb);
        return (double) intersection.size() / union.size();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DRAW HIGHLIGHTS
    // ════════════════════════════════════════════════════════════════════════

    private static void drawHighlights(BufferedImage img,
                                        PDPage page,
                                        List<VisualLine> lines,
                                        Map<VisualLine, PDFComparator.DiffType> typeByLine) {
        PDRectangle media = page.getMediaBox();
        float pdfW  = media.getWidth();
        float pdfH  = media.getHeight();
        float scaleX = (float) img.getWidth()  / pdfW;
        float scaleY = (float) img.getHeight() / pdfH;

        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                           RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL,
                           RenderingHints.VALUE_STROKE_PURE);

        for (VisualLine vl : lines) {
            PDFComparator.DiffType type = typeByLine.get(vl);
            if (type == null) continue;

            // yTop / yBottom are already in top-origin PDF coords (from RunCollector)
            int px = Math.max(0,               (int)(vl.xLeft  * scaleX) - 2);
            int py = Math.max(0,               (int)(vl.yTop   * scaleY) - 1);
            int pr = Math.min(img.getWidth(),  (int)(vl.xRight * scaleX) + 2);
            int pb = Math.min(img.getHeight(), (int)(vl.yBottom * scaleY) + 2);
            int pw = Math.max(4, pr - px);
            int ph = Math.max(3, pb - py);

            Color fill, border;
            switch (type) {
                case REMOVED: fill = FILL_REM; border = BORDER_REM; break;
                case ADDED:   fill = FILL_ADD; border = BORDER_ADD; break;
                case CHANGED: fill = FILL_CHG; border = BORDER_CHG; break;
                default: continue;
            }

            g.setColor(fill);
            g.fillRect(px, py, pw, ph);
            g.setColor(border);
            g.setStroke(new BasicStroke(1.0f));
            g.drawRect(px, py, pw, ph);
        }
        g.dispose();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PLAIN RENDER (no diffs)
    // ════════════════════════════════════════════════════════════════════════

    private static List<RenderedPage> renderPlain(File pdfFile) throws IOException {
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BASE64 PNG
    // ════════════════════════════════════════════════════════════════════════

    private static String toPng(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }
}
