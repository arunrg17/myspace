package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import com.apitest.model.Environment;
import com.apitest.testdb.FakeDriver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Regression coverage for the per-step assertion and multi-row DB features:
 * the {@code db_rows} set operator, the step-binding field on assertions, and
 * the actionable message when a JDBC driver is missing. DB access is exercised
 * through a small in-JVM fake driver so the test needs no external database.
 */
class PerStepAndDbRowsTest {

    private Environment env(String driver) {
        return new Environment("t", "rest", "http://localhost",
                "none", "", Map.of(), "", "", "", Map.of(),
                "jdbc:fake:mem", "u", "p", driver);
    }

    @BeforeEach
    void seed() throws Exception {
        Class.forName("com.apitest.testdb.FakeDriver");
        FakeDriver.PORTFOLIOS.clear();
        FakeDriver.PORTFOLIOS.put("PF-100", "ACTIVE");
        FakeDriver.PORTFOLIOS.put("PF-101", "ACTIVE");
        FakeDriver.PORTFOLIOS.put("PF-102", "ACTIVE");
    }

    private AssertionResult one(Assertion a) {
        List<AssertionResult> r = AssertionEngine.evaluate("{}", List.of(a), env("com.apitest.testdb.FakeDriver"));
        assertEquals(1, r.size());
        return r.get(0);
    }

    @Test
    void dbRowsExactSetMatches() {
        AssertionResult r = one(new Assertion(
                "SELECT portfolio_number FROM portfolios WHERE customer_id='C1'",
                "", "db_rows", "PF-100,PF-101,PF-102", "", 0));
        assertTrue(r.passed, r.message);
    }

    @Test
    void dbRowsOrderIndependent() {
        AssertionResult r = one(new Assertion(
                "SELECT portfolio_number FROM portfolios WHERE customer_id='C1'",
                "", "db_rows", "PF-102,PF-100,PF-101", "", 0));
        assertTrue(r.passed, r.message);
    }

    @Test
    void dbRowsReportsMissing() {
        AssertionResult r = one(new Assertion(
                "SELECT portfolio_number FROM portfolios WHERE customer_id='C1'",
                "", "db_rows", "PF-100,PF-101,PF-102,PF-999", "", 0));
        assertFalse(r.passed);
        assertTrue(r.message.contains("PF-999"), r.message);
    }

    @Test
    void dbRowsReportsUnexpected() {
        AssertionResult r = one(new Assertion(
                "SELECT portfolio_number FROM portfolios WHERE customer_id='C1'",
                "", "db_rows", "PF-100,PF-101", "", 0));
        assertFalse(r.passed);
        assertTrue(r.message.contains("PF-102"), r.message);
    }

    @Test
    void dbRowsEmptyExpectedMeansMultiple() {
        AssertionResult r = one(new Assertion(
                "SELECT portfolio_number FROM portfolios WHERE customer_id='C1'",
                "", "db_rows", "", "", 0));
        assertTrue(r.passed, r.message);
    }

    @Test
    void dbEqualsCountZeroForDeletedRow() {
        AssertionResult r = one(new Assertion(
                "SELECT COUNT(*) FROM portfolios WHERE portfolio_number='PF-777'",
                "", "db_equals", "0", "", 0));
        assertTrue(r.passed, r.message);
    }

    @Test
    void missingDriverGivesActionableMessage() {
        List<AssertionResult> r = AssertionEngine.evaluate("{}",
                List.of(new Assertion("SELECT 1 FROM dual", "", "db_exists", "", "", 0)),
                env("oracle.jdbc.OracleDriver"));
        assertFalse(r.get(0).passed);
        assertTrue(r.get(0).message.contains("ojdbc11.jar"), r.get(0).message);
        assertTrue(r.get(0).message.contains("classpath"), r.get(0).message);
    }

    @Test
    void assertionStepBindingField() {
        Assertion bound = new Assertion("$.x", "jsonpath", "exists", "", "", 2);
        assertTrue(bound.isStepScoped());
        assertEquals(2, bound.stepOrder());
        Assertion unbound = new Assertion("$.x", "jsonpath", "exists", "", "");
        assertFalse(unbound.isStepScoped());
        assertEquals(0, unbound.stepOrder());
    }

    @Test
    void dbEqualsOnMultiRowQueryFailsAndPointsToDbRows() {
        // The seed has three portfolios, so this query returns three rows.
        // db_equals is single-value: rather than compare against just the first
        // row it must fail and name the right operator.
        AssertionResult r = one(new Assertion(
                "SELECT portfolio_number FROM portfolios", "sql", "db_equals", "PF-100", "", 0));
        assertFalse(r.passed);
        assertTrue(r.message.contains("multiple rows"), r.message);
        assertTrue(r.message.contains("db_rows"), r.message);
    }

    @Test
    void dbContainsOnMultiRowQueryFailsAndPointsToDbRows() {
        AssertionResult r = one(new Assertion(
                "SELECT portfolio_number FROM portfolios", "sql", "db_contains", "PF-1", "", 0));
        assertFalse(r.passed);
        assertTrue(r.message.contains("db_rows"), r.message);
    }

    @Test
    void dbRowsComparesTheWholeSet() {
        AssertionResult r = one(new Assertion(
                "SELECT portfolio_number FROM portfolios", "sql", "db_rows",
                "PF-100,PF-101,PF-102", "", 0));
        assertTrue(r.passed, r.message);
        assertTrue(r.actualValue.contains("PF-100"));
        assertTrue(r.actualValue.contains("PF-102"));
    }
}
