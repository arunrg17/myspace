#!/bin/bash
# Build doc-compare.jar
# Requires: Java 11+ and Maven 3.6+
set -e
cd "$(dirname "$0")"
echo "Building doc-compare.jar with Maven..."
mvn clean package
echo ""
echo "Build complete!"
echo "  JAR location: target/doc-compare.jar"
echo "  Size: $(du -h target/doc-compare.jar 2>/dev/null | cut -f1)"
