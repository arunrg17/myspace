package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Renders PDF pages as images and highlights visual differences using
 * pixel-level comparison — the same approach used by Adobe Acrobat Compare
 * and Beyond Compare.
 *
 * <h2>How it works</h2>
 * <ol>
 *   <li>Both PDFs are rendered to images at the same DPI.</li>
 *   <li>For each corresponding page pair, every pixel is compared.</li>
 *   <li>Pixels that differ by more than a threshold are marked as changed.</li>
 *   <li>Changed pixels are grouped into rectangular regions with a small
 *       gap-fill tolerance so adjacent changed characters form one box.</li>
 *   <li>Highlight boxes are drawn over the changed regions on both pages.</li>
 * </ol>
 *
 * <h2>Why this is correct</h2>
 * <p>This approach requires no text extraction, no line numbering, no counter
 * synchronisation, and no text matching. Identical content produces zero pixel
 * difference and therefore zero highlights. Only visually different content
 * is highlighted — regardless of PDF structure, column layout, table format,
 * font, or encoding.
 */
final class PageRenderer {

    /** Render DPI — higher = more precise diff but larger images. */
    private static final float DPI = 150f;

    /** Pixel difference threshold (0–255).
     *  15 safely ignores font anti-aliasing noise (2–5px) while catching
     *  any genuine text/image difference (50–255px range). */
    private static final int   PIXEL_THRESHOLD = 15;

    /** Gap fill: rows within this many unchanged pixels are merged into one box. */
    private static final int   GAP_FILL_PX = 6;

    /** Minimum changed region height in pixels — filters single-pixel noise. */
    private static final int   MIN_BOX_HEIGHT = 6;

    /** Minimum changed region width in pixels.
     *  Set to 4 so small single-character changes (e.g. "11:34" vs "11:37",
     *  only 2 glyphs differ = ~5px) are still highlighted.
     *  The ±3px padding added when building rectangles means the actual
     *  rendered box will be at least 10px wide. */
    private static final int   MIN_BOX_WIDTH  = 4;

    private static final Color FILL_DIFF   = new Color(255, 140,   0,  70);
    private static final Color BORDER_DIFF = new Color(200,  80,   0, 230);

    private PageRenderer() {}

    // ── Public output ─────────────────────────────────────────────────────────

    static final class RenderedPage {
        final int    pageIndex;
        final String base64Png;
        final int    widthPx;
        final int    heightPx;

        RenderedPage(int i, String b64, int w, int h) {
            pageIndex = i; base64Png = b64; widthPx = w; heightPx = h;
        }
    }

    // ── Highlight rectangle ───────────────────────────────────────────────────

    private static final class Rect {
        int x1, y1, x2, y2;
        Rect(int x1, int y1, int x2, int y2) {
            this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
        }
        int w() { return x2 - x1; }
        int h() { return y2 - y1; }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    //
    //  Renders both PDFs and returns highlighted page images.
    //  Both lists are returned together to avoid loading each PDF twice.
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Render both PDFs with pixel-diff highlights.
     *
     * @return two-element array: [0] = pages from pdf1 (left),
     *                            [1] = pages from pdf2 (right)
     */
    static List<RenderedPage>[] renderBoth(File pdf1, File pdf2) throws IOException {
        // Render both PDFs to raw images
        List<BufferedImage> raw1 = renderRaw(pdf1);
        List<BufferedImage> raw2 = renderRaw(pdf2);

        int numPages = Math.max(raw1.size(), raw2.size());

        @SuppressWarnings("unchecked")
        List<RenderedPage>[] result = new List[]{
            new ArrayList<>(),
            new ArrayList<>()
        };

        for (int p = 0; p < numPages; p++) {
            BufferedImage img1 = p < raw1.size() ? raw1.get(p) : blankPage(raw1);
            BufferedImage img2 = p < raw2.size() ? raw2.get(p) : blankPage(raw2);

            // Ensure same dimensions for pixel comparison
            img1 = normaliseSize(img1, img2.getWidth(), img2.getHeight());
            img2 = normaliseSize(img2, img1.getWidth(), img1.getHeight());

            // Find changed regions
            List<Rect> diffs = findDiffRegions(img1, img2);

            // Draw highlights on copies of the originals
            BufferedImage out1 = copyImage(img1);
            BufferedImage out2 = copyImage(img2);

            if (!diffs.isEmpty()) {
                drawHighlights(out1, diffs);
                drawHighlights(out2, diffs);
            }

            result[0].add(new RenderedPage(p, toPng(out1), out1.getWidth(), out1.getHeight()));
            result[1].add(new RenderedPage(p, toPng(out2), out2.getWidth(), out2.getHeight()));
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  RENDER PDF TO IMAGES
    // ════════════════════════════════════════════════════════════════════════

    private static List<BufferedImage> renderRaw(File pdfFile) throws IOException {
        List<BufferedImage> pages = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                pages.add(renderer.renderImageWithDPI(p, DPI, ImageType.RGB));
            }
        }
        return pages;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PIXEL DIFF — core algorithm
    //
    //  1. Compare pixels — build a boolean mask of changed pixels.
    //  2. Project mask onto rows and columns to find changed bands.
    //  3. Group consecutive changed rows into horizontal bands.
    //  4. Within each band, find left/right extent of changed pixels.
    //  5. Apply gap fill so adjacent glyphs form one continuous box.
    // ════════════════════════════════════════════════════════════════════════

    private static List<Rect> findDiffRegions(BufferedImage a, BufferedImage b) {
        int W = a.getWidth();
        int H = a.getHeight();

        // Build change mask
        boolean[] changed = new boolean[W * H];
        int[] pixA = a.getRGB(0, 0, W, H, null, 0, W);
        int[] pixB = b.getRGB(0, 0, W, H, null, 0, W);

        for (int i = 0; i < pixA.length; i++) {
            int rA = (pixA[i] >> 16) & 0xFF;
            int gA = (pixA[i] >>  8) & 0xFF;
            int bA =  pixA[i]        & 0xFF;
            int rB = (pixB[i] >> 16) & 0xFF;
            int gB = (pixB[i] >>  8) & 0xFF;
            int bB =  pixB[i]        & 0xFF;

            int dr = Math.abs(rA - rB);
            int dg = Math.abs(gA - gB);
            int db = Math.abs(bA - bB);

            if (Math.max(dr, Math.max(dg, db)) > PIXEL_THRESHOLD) {
                changed[i] = true;
            }
        }

        // Project onto rows: which rows have any changed pixel?
        boolean[] changedRow = new boolean[H];
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (changed[y * W + x]) {
                    changedRow[y] = true;
                    break;
                }
            }
        }

        // Apply row gap fill — merge bands separated by <= GAP_FILL_PX unchanged rows
        for (int y = 1; y < H - 1; y++) {
            if (!changedRow[y]) {
                // Check if there's a changed row within GAP_FILL_PX above and below
                boolean above = false, below = false;
                for (int dy = 1; dy <= GAP_FILL_PX && y - dy >= 0; dy++) {
                    if (changedRow[y - dy]) { above = true; break; }
                }
                for (int dy = 1; dy <= GAP_FILL_PX && y + dy < H; dy++) {
                    if (changedRow[y + dy]) { below = true; break; }
                }
                if (above && below) changedRow[y] = true;
            }
        }

        // Extract contiguous row bands
        List<Rect> rects = new ArrayList<>();
        int bandStart = -1;
        for (int y = 0; y <= H; y++) {
            boolean active = (y < H) && changedRow[y];
            if (active && bandStart < 0) {
                bandStart = y;
            } else if (!active && bandStart >= 0) {
                int bandEnd = y - 1;
                // Find x extent within this band
                int x1 = W, x2 = -1;
                for (int row = bandStart; row <= bandEnd; row++) {
                    for (int col = 0; col < W; col++) {
                        if (changed[row * W + col]) {
                            if (col < x1) x1 = col;
                            if (col > x2) x2 = col;
                        }
                    }
                }
                if (x2 >= x1 && (bandEnd - bandStart) >= MIN_BOX_HEIGHT
                        && (x2 - x1) >= MIN_BOX_WIDTH) {
                    // Add padding
                    rects.add(new Rect(
                        Math.max(0,     x1 - 3),
                        Math.max(0,     bandStart - 2),
                        Math.min(W - 1, x2 + 3),
                        Math.min(H - 1, bandEnd  + 2)
                    ));
                }
                bandStart = -1;
            }
        }
        return rects;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DRAW HIGHLIGHTS
    // ════════════════════════════════════════════════════════════════════════

    private static void drawHighlights(BufferedImage img, List<Rect> rects) {
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                           RenderingHints.VALUE_ANTIALIAS_ON);
        for (Rect r : rects) {
            g.setColor(FILL_DIFF);
            g.fillRect(r.x1, r.y1, r.w(), r.h());
            g.setColor(BORDER_DIFF);
            g.setStroke(new BasicStroke(1.2f));
            g.drawRect(r.x1, r.y1, r.w(), r.h());
        }
        g.dispose();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private static BufferedImage blankPage(List<BufferedImage> reference) {
        if (reference.isEmpty()) return new BufferedImage(595, 842, BufferedImage.TYPE_INT_RGB);
        BufferedImage ref = reference.get(0);
        BufferedImage blank = new BufferedImage(ref.getWidth(), ref.getHeight(),
            BufferedImage.TYPE_INT_RGB);
        Graphics2D g = blank.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, blank.getWidth(), blank.getHeight());
        g.dispose();
        return blank;
    }

    private static BufferedImage normaliseSize(BufferedImage img, int targetW, int targetH) {
        if (img.getWidth() == targetW && img.getHeight() == targetH) return img;
        // Pad or crop to match — padding with white is safer than scaling
        BufferedImage out = new BufferedImage(targetW, targetH, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, targetW, targetH);
        g.drawImage(img, 0, 0, null);
        g.dispose();
        return out;
    }

    private static BufferedImage copyImage(BufferedImage src) {
        BufferedImage copy = new BufferedImage(src.getWidth(), src.getHeight(), src.getType());
        Graphics2D g = copy.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return copy;
    }

    private static String toPng(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }
}
