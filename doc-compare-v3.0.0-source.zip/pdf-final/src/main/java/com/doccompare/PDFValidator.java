package com.doccompare;

import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.PDXObject;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Validates a single PDF against a set of rules from {@link ValidationConfig}.
 *
 * <h2>How rules are evaluated</h2>
 * <p>The validator runs <strong>two extraction passes</strong>:
 * <ol>
 *   <li><b>Body extraction</b> — text outside left and right margin zones, per page.
 *       Used for content rules and page-specific rules.</li>
 *   <li><b>Margin extraction</b> — text inside the margin zones, captured separately
 *       per side. This handles vertical text on the left margin (like COSREP IDs)
 *       which PDFBox places by raw glyph position.</li>
 * </ol>
 *
 * <p>Image rules are checked by walking each page's resources and counting
 * {@link PDImageXObject} entries.
 *
 * <h2>Order checks ({@code mustContainBetween})</h2>
 * <p>The full document text is concatenated in reading order. The check passes if:
 * {@code indexOf(before) < indexOf(target) < indexOf(after)} (all positive).
 */
public final class PDFValidator {

    private static final Logger LOG = Logger.getLogger(PDFValidator.class.getName());

    static {
        Logger.getLogger("org.apache.pdfbox").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.pdfbox.pdmodel.font").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.fontbox").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.fontbox.cmap").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.fontbox.ttf").setLevel(Level.SEVERE);
    }

    private PDFValidator() {}

    public static final int EXIT_PASS  = 0;
    public static final int EXIT_FAIL  = 1;
    public static final int EXIT_ERROR = 2;

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Validate a PDF against the rules in {@code config}.
     *
     * @return validation result. Always non-null. If the PDF could not be opened,
     *         the status is {@link ValidationResult.Status#ERROR}.
     */
    public static ValidationResult validate(ValidationConfig config) {
        try {
            return doValidate(config);
        } catch (Exception ex) {
            LOG.log(Level.SEVERE, "Validation error", ex);
            return ValidationResult.error(
                config.getPdfPath(),
                config.getReportPath(),
                ex.getClass().getSimpleName() + ": " + ex.getMessage()
            );
        }
    }

    private static ValidationResult doValidate(ValidationConfig config) throws Exception {
        File pdfFile = new File(config.getPdfPath());
        if (!pdfFile.isFile() || !pdfFile.canRead()) {
            throw new IOException("Cannot read PDF: " + pdfFile.getAbsolutePath());
        }

        PdfData data = extractPdfData(pdfFile, config.getMarginPct());
        List<ValidationResult.RuleResult> results = new ArrayList<>();

        for (ValidationConfig.Rule rule : config.getRules()) {
            results.add(evaluate(rule, data));
        }

        boolean allPassed = true;
        for (ValidationResult.RuleResult r : results) {
            if (!r.passed) { allPassed = false; break; }
        }

        // Write HTML report if requested
        String reportPath = null;
        if (config.getReportPath() != null && !config.getReportPath().isEmpty()) {
            File out = new File(config.getReportPath());
            File parent = out.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            String html = ValidationReportBuilder.build(
                config.getPdfPath(), data.totalPages, results, allPassed);
            Files.write(out.toPath(), html.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            reportPath = out.getAbsolutePath();
        }

        return allPassed
            ? ValidationResult.success(data.totalPages, pdfFile.getAbsolutePath(), reportPath, results)
            : ValidationResult.failure(data.totalPages, pdfFile.getAbsolutePath(), reportPath, results);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  RULE EVALUATION
    // ════════════════════════════════════════════════════════════════════════

    private static ValidationResult.RuleResult evaluate(ValidationConfig.Rule rule, PdfData data) {
        switch (rule.type) {
            case MUST_CONTAIN: {
                List<Integer> foundPages = findAllPagesInBody(data, rule.primary, rule.caseSensitive);
                if (!foundPages.isEmpty()) {
                    if (foundPages.size() == data.totalPages) {
                        return pass(rule, "Found on all " + data.totalPages + " pages");
                    }
                    return pass(rule, "Found on " + foundPages.size() + " page(s): " + foundPages);
                }
                return fail(rule, "Text not found anywhere in body");
            }

            case MUST_NOT_CONTAIN: {
                int pageFound = findInBody(data, rule.primary, rule.caseSensitive);
                if (pageFound < 0) {
                    return pass(rule, "Text correctly absent");
                }
                return fail(rule, "Text was found on page " + pageFound + " (expected absent)");
            }

            case MUST_CONTAIN_LEFT_MARGIN: {
                int p = findInMargin(data.leftMarginByPage, rule.primary, rule.caseSensitive);
                return p > 0
                    ? pass(rule, "Found in left margin on page " + p)
                    : fail(rule, "Not found in left margin of any page");
            }

            case MUST_CONTAIN_RIGHT_MARGIN: {
                int p = findInMargin(data.rightMarginByPage, rule.primary, rule.caseSensitive);
                return p > 0
                    ? pass(rule, "Found in right margin on page " + p)
                    : fail(rule, "Not found in right margin of any page");
            }

            case MUST_CONTAIN_ALL_PAGES: {
                List<Integer> missing = new ArrayList<>();
                String needle = normalizeWhitespace(rule.primary);
                for (int i = 1; i <= data.totalPages; i++) {
                    String body = normalizeWhitespace(data.bodyByPage.getOrDefault(i, ""));
                    if (!containsText(body, needle, rule.caseSensitive)) {
                        missing.add(i);
                    }
                }
                return missing.isEmpty()
                    ? pass(rule, "Found on all " + data.totalPages + " pages")
                    : fail(rule, "Missing on pages: " + missing);
            }

            case MUST_CONTAIN_ANY_PAGE: {
                for (int i = 1; i <= data.totalPages; i++) {
                    String body = data.bodyByPage.getOrDefault(i, "");
                    if (containsText(body, rule.primary, rule.caseSensitive)) {
                        return pass(rule, "Found on page " + i);
                    }
                }
                return fail(rule, "Not found on any page");
            }

            case MUST_CONTAIN_ON_PAGE: {
                if (rule.pageNumber < 1 || rule.pageNumber > data.totalPages) {
                    return fail(rule, "Page " + rule.pageNumber + " does not exist (PDF has "
                        + data.totalPages + " pages)");
                }
                String body = normalizeWhitespace(data.bodyByPage.getOrDefault(rule.pageNumber, ""));
                String needle = normalizeWhitespace(rule.primary);
                return containsText(body, needle, rule.caseSensitive)
                    ? pass(rule, "Found on page " + rule.pageNumber)
                    : fail(rule, "Not found on page " + rule.pageNumber);
            }

            case MUST_CONTAIN_BETWEEN: {
                // Normalize whitespace in full text so table cells separated by
                // tabs, multiple spaces, or newlines are still matched.
                // E.g. "255243\t14,08\t3 BANKEN..." becomes "255243 14,08 3 BANKEN..."
                String full = normalizeWhitespace(data.fullBodyText);
                String target = normalizeWhitespace(rule.primary);
                String before = normalizeWhitespace(rule.before);
                String after  = normalizeWhitespace(rule.after);

                int idxBefore = indexOfText(full, before, rule.caseSensitive);
                if (idxBefore < 0) return fail(rule, "'before' anchor not found: " + rule.before);
                int idxAfter = indexOfText(full, after, rule.caseSensitive, idxBefore + before.length());
                if (idxAfter < 0) return fail(rule, "'after' anchor not found after 'before'");
                int idxTarget = indexOfText(full, target, rule.caseSensitive, idxBefore + before.length());
                if (idxTarget < 0 || idxTarget >= idxAfter) {
                    return fail(rule, "Target not found between the two anchors");
                }
                return pass(rule, "Target appears between anchors");
            }

            case MUST_HAVE_IMAGE: {
                if (data.totalImages > 0) {
                    return pass(rule, "Found " + data.totalImages + " image(s) in document");
                }
                return fail(rule, "No images found in document");
            }

            case MUST_HAVE_IMAGE_ALL_PAGES: {
                List<Integer> noImage = new ArrayList<>();
                for (int i = 1; i <= data.totalPages; i++) {
                    if (data.imagesByPage.getOrDefault(i, 0) <= 0) noImage.add(i);
                }
                return noImage.isEmpty()
                    ? pass(rule, "Image found on all " + data.totalPages + " pages")
                    : fail(rule, "Pages without image: " + noImage);
            }

            case MIN_PAGES: {
                return data.totalPages >= rule.number
                    ? pass(rule, "Has " + data.totalPages + " pages (>= " + rule.number + ")")
                    : fail(rule, "Has only " + data.totalPages + " pages (need >= " + rule.number + ")");
            }

            case MAX_PAGES: {
                return data.totalPages <= rule.number
                    ? pass(rule, "Has " + data.totalPages + " pages (<= " + rule.number + ")")
                    : fail(rule, "Has " + data.totalPages + " pages (max allowed " + rule.number + ")");
            }

            default:
                return fail(rule, "Unknown rule type: " + rule.type);
        }
    }

    private static ValidationResult.RuleResult pass(ValidationConfig.Rule r, String detail) {
        return new ValidationResult.RuleResult(r, true, detail);
    }
    private static ValidationResult.RuleResult fail(ValidationConfig.Rule r, String detail) {
        return new ValidationResult.RuleResult(r, false, detail);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TEXT SEARCH HELPERS
    // ════════════════════════════════════════════════════════════════════════

    /** Returns the page number where text first appears, or -1 if not found. */
    private static int findInBody(PdfData data, String needle, boolean caseSensitive) {
        String normNeedle = normalizeWhitespace(needle);
        for (int i = 1; i <= data.totalPages; i++) {
            String body = normalizeWhitespace(data.bodyByPage.getOrDefault(i, ""));
            if (containsText(body, normNeedle, caseSensitive)) return i;
        }
        return -1;
    }

    /** Returns ALL page numbers where text appears. */
    private static List<Integer> findAllPagesInBody(PdfData data, String needle, boolean caseSensitive) {
        String normNeedle = normalizeWhitespace(needle);
        List<Integer> pages = new ArrayList<>();
        for (int i = 1; i <= data.totalPages; i++) {
            String body = normalizeWhitespace(data.bodyByPage.getOrDefault(i, ""));
            if (containsText(body, normNeedle, caseSensitive)) pages.add(i);
        }
        return pages;
    }

    private static int findInMargin(Map<Integer, String> marginByPage, String needle, boolean cs) {
        for (Map.Entry<Integer, String> e : marginByPage.entrySet()) {
            if (containsText(e.getValue(), needle, cs)) return e.getKey();
        }
        return -1;
    }

    private static boolean containsText(String haystack, String needle, boolean caseSensitive) {
        if (haystack == null || needle == null || needle.isEmpty()) return false;
        if (caseSensitive) return haystack.contains(needle);
        return haystack.toLowerCase().contains(needle.toLowerCase());
    }

    /**
     * Collapses all runs of whitespace (spaces, tabs, newlines, non-breaking spaces)
     * into a single space. This allows matching text that PDFBox extracted from table
     * cells where columns are separated by tabs or variable spacing.
     *
     * <p>Example: {@code "255243\t14,08\t3 BANKEN"} becomes {@code "255243 14,08 3 BANKEN"}.
     */
    private static String normalizeWhitespace(String text) {
        if (text == null) return "";
        return text.replaceAll("[\\s\\u00A0]+", " ").trim();
    }

    private static int indexOfText(String haystack, String needle, boolean caseSensitive) {
        return indexOfText(haystack, needle, caseSensitive, 0);
    }

    private static int indexOfText(String haystack, String needle, boolean caseSensitive, int from) {
        if (haystack == null || needle == null || needle.isEmpty()) return -1;
        if (caseSensitive) return haystack.indexOf(needle, from);
        return haystack.toLowerCase().indexOf(needle.toLowerCase(), from);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PDF DATA EXTRACTION
    // ════════════════════════════════════════════════════════════════════════

    /** Holds all extracted information about a PDF for rule evaluation. */
    private static final class PdfData {
        int totalPages;
        int totalImages;
        Map<Integer, String>  bodyByPage         = new LinkedHashMap<>();
        Map<Integer, String>  leftMarginByPage   = new LinkedHashMap<>();
        Map<Integer, String>  rightMarginByPage  = new LinkedHashMap<>();
        Map<Integer, Integer> imagesByPage       = new HashMap<>();
        String                fullBodyText       = "";
    }

    private static PdfData extractPdfData(File pdfFile, double marginPct) throws IOException {
        PdfData data = new PdfData();

        try (PDDocument doc = PDDocument.load(pdfFile)) {
            data.totalPages = doc.getNumberOfPages();

            // --- Pass 1: body text per page (margins excluded) ---
            for (int p = 0; p < data.totalPages; p++) {
                BodyExtractor body = new BodyExtractor(marginPct);
                body.setStartPage(p + 1);
                body.setEndPage(p + 1);
                String text = body.getText(doc);
                data.bodyByPage.put(p + 1, text);
            }

            // --- Pass 2: left and right margin text per page ---
            for (int p = 0; p < data.totalPages; p++) {
                MarginExtractor mLeft  = new MarginExtractor(marginPct, true);
                mLeft.setStartPage(p + 1); mLeft.setEndPage(p + 1);
                data.leftMarginByPage.put(p + 1, mLeft.getText(doc));

                MarginExtractor mRight = new MarginExtractor(marginPct, false);
                mRight.setStartPage(p + 1); mRight.setEndPage(p + 1);
                data.rightMarginByPage.put(p + 1, mRight.getText(doc));
            }

            // --- Build full body text in reading order ---
            StringBuilder full = new StringBuilder();
            for (int p = 1; p <= data.totalPages; p++) {
                full.append(data.bodyByPage.getOrDefault(p, ""));
                full.append('\n');
            }
            data.fullBodyText = full.toString();

            // --- Image counts per page ---
            for (int p = 0; p < data.totalPages; p++) {
                int count = countImagesOnPage(doc.getPage(p));
                data.imagesByPage.put(p + 1, count);
                data.totalImages += count;
            }
        }
        return data;
    }

    /** Counts images on a single page (recurses into form XObjects). */
    private static int countImagesOnPage(PDPage page) {
        try {
            return countImagesIn(page.getResources(), 0);
        } catch (IOException e) {
            return 0;
        }
    }

    private static int countImagesIn(PDResources res, int depth) throws IOException {
        if (res == null || depth > 4) return 0;  // depth limit prevents infinite recursion
        int count = 0;
        for (COSName name : res.getXObjectNames()) {
            PDXObject xo = res.getXObject(name);
            if (xo instanceof PDImageXObject) {
                count++;
            } else if (xo != null) {
                // Form XObject — check its resources too
                try {
                    java.lang.reflect.Method m = xo.getClass().getMethod("getResources");
                    Object inner = m.invoke(xo);
                    if (inner instanceof PDResources) {
                        count += countImagesIn((PDResources) inner, depth + 1);
                    }
                } catch (Exception ignored) {}
            }
        }
        return count;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BODY EXTRACTOR — text OUTSIDE margin zones
    // ════════════════════════════════════════════════════════════════════════

    private static final class BodyExtractor extends PDFTextStripper {
        private final double marginPct;
        private float pageW = 595f;

        BodyExtractor(double marginPct) throws IOException {
            super();
            this.marginPct = marginPct;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle b = page.getMediaBox();
            pageW = b.getWidth();
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions) throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }
            // Average X — drop runs that are inside left/right margin zones
            float sumX = 0;
            for (TextPosition tp : positions) sumX += tp.getX();
            float avgX = sumX / positions.size();
            double leftBoundary  = pageW * (marginPct / 100.0);
            double rightBoundary = pageW * ((100.0 - marginPct) / 100.0);
            if (avgX < leftBoundary || avgX > rightBoundary) {
                return; // skip — belongs to margin
            }
            super.writeString(text, positions);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MARGIN EXTRACTOR — text INSIDE one margin (handles vertical glyphs)
    // ════════════════════════════════════════════════════════════════════════

    private static final class MarginExtractor extends PDFTextStripper {
        private final double  marginPct;
        private final boolean isLeftMargin;
        private float pageW = 595f;

        MarginExtractor(double marginPct, boolean isLeftMargin) throws IOException {
            super();
            this.marginPct    = marginPct;
            this.isLeftMargin = isLeftMargin;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle b = page.getMediaBox();
            pageW = b.getWidth();
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions) throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }
            float sumX = 0;
            for (TextPosition tp : positions) sumX += tp.getX();
            float avgX = sumX / positions.size();
            double leftBoundary  = pageW * (marginPct / 100.0);
            double rightBoundary = pageW * ((100.0 - marginPct) / 100.0);

            boolean inThisMargin = isLeftMargin
                ? (avgX < leftBoundary)
                : (avgX > rightBoundary);

            if (!inThisMargin) return;
            super.writeString(text, positions);
        }
    }
}
