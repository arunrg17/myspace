package com.doccompare;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Result of running a {@link ValidationConfig} against a PDF.
 *
 * <p>Each rule produces a {@link RuleResult} indicating whether it passed,
 * with a human-readable detail message. The overall {@link Status} is
 * {@code PASS} only if every rule passed.
 */
public final class ValidationResult {

    public enum Status { PASS, FAIL, ERROR }

    /** Outcome of one rule. */
    public static final class RuleResult {
        public final ValidationConfig.Rule rule;
        public final boolean               passed;
        public final String                detail;

        RuleResult(ValidationConfig.Rule rule, boolean passed, String detail) {
            this.rule   = rule;
            this.passed = passed;
            this.detail = detail;
        }
    }

    private final Status           status;
    private final int              pdfPages;
    private final String           pdfPath;
    private final String           reportPath;
    private final List<RuleResult> ruleResults;
    private final String           errorMessage;

    private ValidationResult(Status status, int pdfPages, String pdfPath, String reportPath,
                              List<RuleResult> ruleResults, String errorMessage) {
        this.status       = status;
        this.pdfPages     = pdfPages;
        this.pdfPath      = pdfPath;
        this.reportPath   = reportPath;
        this.ruleResults  = Collections.unmodifiableList(ruleResults);
        this.errorMessage = errorMessage;
    }

    public boolean          isPassed()        { return status == Status.PASS; }
    public Status           getStatus()       { return status; }
    public int              getPdfPages()     { return pdfPages; }
    public String           getPdfPath()      { return pdfPath; }
    public String           getReportPath()   { return reportPath; }
    public List<RuleResult> getRuleResults()  { return ruleResults; }
    public String           getErrorMessage() { return errorMessage; }

    public int getPassedCount() {
        int n = 0;
        for (RuleResult r : ruleResults) if (r.passed) n++;
        return n;
    }

    public int getFailedCount() {
        int n = 0;
        for (RuleResult r : ruleResults) if (!r.passed) n++;
        return n;
    }

    /** Returns a summary line: "PASS — 7/7 rules" or "FAIL — 5/7 rules (2 failed)". */
    public String getSummary() {
        if (status == Status.ERROR) {
            return "ERROR — " + (errorMessage != null ? errorMessage : "unknown");
        }
        int passed = getPassedCount();
        int total  = ruleResults.size();
        if (status == Status.PASS) {
            return "PASS — " + passed + "/" + total + " rules passed";
        }
        return "FAIL — " + passed + "/" + total + " rules passed ("
             + (total - passed) + " failed). Report: " + reportPath;
    }

    /** Returns a multiline list of failed rules — useful for assertion messages. */
    public String getFailureDetails() {
        StringBuilder sb = new StringBuilder();
        for (RuleResult r : ruleResults) {
            if (!r.passed) {
                sb.append("  ✗ ").append(r.rule.description());
                if (r.detail != null && !r.detail.isEmpty()) {
                    sb.append(" — ").append(r.detail);
                }
                sb.append('\n');
            }
        }
        return sb.toString();
    }

    @Override
    public String toString() { return getSummary(); }

    // ── Factories ────────────────────────────────────────────────────────────

    static ValidationResult success(int pages, String pdfPath, String reportPath,
                                     List<RuleResult> rules) {
        return new ValidationResult(Status.PASS, pages, pdfPath, reportPath, rules, null);
    }

    static ValidationResult failure(int pages, String pdfPath, String reportPath,
                                     List<RuleResult> rules) {
        return new ValidationResult(Status.FAIL, pages, pdfPath, reportPath, rules, null);
    }

    static ValidationResult error(String pdfPath, String reportPath, String errorMessage) {
        return new ValidationResult(Status.ERROR, 0, pdfPath, reportPath,
            new ArrayList<>(), errorMessage);
    }
}
