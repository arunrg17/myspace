package com.doccompare;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/**
 * Configuration for single-PDF validation.
 *
 * <p>A {@code ValidationConfig} is a collection of rules describing what must be true
 * about a PDF for it to be considered valid. Rules are checked by {@link PDFValidator}
 * and the result is captured in {@link ValidationResult}.
 *
 * <h2>Rule types</h2>
 * <ul>
 *   <li>Content rules — text must / must not appear in the body</li>
 *   <li>Margin rules — text must appear in the left or right margin (handles vertical text)</li>
 *   <li>Page rules — text must appear on all / any / a specific page</li>
 *   <li>Order rules — target text must appear between two other texts</li>
 *   <li>Image rules — PDF must have at least one embedded image (e.g. logo)</li>
 *   <li>Page count rules — min / max pages</li>
 * </ul>
 *
 * <h2>Building</h2>
 * <pre>{@code
 * ValidationConfig cfg = new ValidationConfig.Builder()
 *     .pdf("Actual.pdf")
 *     .report("validation.html")
 *     .mustContain("Account 1234567890")
 *     .mustContainInLeftMargin("MARGIN-ID-001")
 *     .mustContainOnAllPages("Internal Use Only")
 *     .mustContainBetween("target", "Section Start:", "Section End:")
 *     .mustHaveImage()
 *     .build();
 * }</pre>
 *
 * <h2>Loading from a properties file</h2>
 * <pre>{@code
 * ValidationConfig cfg = new ValidationConfig.Builder()
 *     .pdf("Actual.pdf")
 *     .report("validation.html")
 *     .rulesFile("rules.properties")
 *     .build();
 * }</pre>
 */
public final class ValidationConfig {

    /** A single validation rule. */
    public static final class Rule {

        public enum Type {
            MUST_CONTAIN,
            MUST_NOT_CONTAIN,
            MUST_CONTAIN_LEFT_MARGIN,
            MUST_CONTAIN_RIGHT_MARGIN,
            MUST_CONTAIN_ALL_PAGES,
            MUST_CONTAIN_ANY_PAGE,
            MUST_CONTAIN_ON_PAGE,
            MUST_CONTAIN_BETWEEN,
            MUST_HAVE_IMAGE,
            MUST_HAVE_IMAGE_ALL_PAGES,
            MIN_PAGES,
            MAX_PAGES
        }

        public final Type     type;
        public final String   primary;       // main text/regex/label
        public final String   before;        // for MUST_CONTAIN_BETWEEN
        public final String   after;         // for MUST_CONTAIN_BETWEEN
        public final int      pageNumber;    // for MUST_CONTAIN_ON_PAGE (1-based)
        public final int      number;        // for MIN_PAGES / MAX_PAGES
        public final boolean  caseSensitive;

        Rule(Type type, String primary, String before, String after,
             int pageNumber, int number, boolean caseSensitive) {
            this.type          = type;
            this.primary       = primary;
            this.before        = before;
            this.after         = after;
            this.pageNumber    = pageNumber;
            this.number        = number;
            this.caseSensitive = caseSensitive;
        }

        /** Human-readable description used in reports. */
        public String description() {
            switch (type) {
                case MUST_CONTAIN:
                    return "Must contain: \"" + primary + "\"";
                case MUST_NOT_CONTAIN:
                    return "Must NOT contain: \"" + primary + "\"";
                case MUST_CONTAIN_LEFT_MARGIN:
                    return "Must contain in left margin: \"" + primary + "\"";
                case MUST_CONTAIN_RIGHT_MARGIN:
                    return "Must contain in right margin: \"" + primary + "\"";
                case MUST_CONTAIN_ALL_PAGES:
                    return "Must appear on every page: \"" + primary + "\"";
                case MUST_CONTAIN_ANY_PAGE:
                    return "Must appear on at least one page: \"" + primary + "\"";
                case MUST_CONTAIN_ON_PAGE:
                    return "Must appear on page " + pageNumber + ": \"" + primary + "\"";
                case MUST_CONTAIN_BETWEEN:
                    return "Must appear between \"" + before + "\" and \"" + after
                         + "\": \"" + primary + "\"";
                case MUST_HAVE_IMAGE:
                    return "PDF must contain at least one image";
                case MUST_HAVE_IMAGE_ALL_PAGES:
                    return "Every page must contain at least one image";
                case MIN_PAGES:
                    return "Must have at least " + number + " page(s)";
                case MAX_PAGES:
                    return "Must have at most " + number + " page(s)";
                default:
                    return type.toString();
            }
        }
    }

    private final String     pdfPath;
    private final String     reportPath;
    private final List<Rule> rules;
    private final double     marginPct;       // % defining left/right margin zones
    private final boolean    caseSensitive;   // global default

    private ValidationConfig(Builder b) {
        this.pdfPath       = b.pdfPath;
        this.reportPath    = b.reportPath;
        this.rules         = Collections.unmodifiableList(new ArrayList<>(b.rules));
        this.marginPct     = b.marginPct;
        this.caseSensitive = b.caseSensitive;
    }

    public String     getPdfPath()       { return pdfPath; }
    public String     getReportPath()    { return reportPath; }
    public List<Rule> getRules()         { return rules; }
    public double     getMarginPct()     { return marginPct; }
    public boolean    isCaseSensitive()  { return caseSensitive; }

    // ════════════════════════════════════════════════════════════════════════
    //  BUILDER
    // ════════════════════════════════════════════════════════════════════════

    public static final class Builder {
        private String     pdfPath;
        private String     reportPath;
        private double     marginPct     = 8.0;
        private boolean    caseSensitive = false;
        private List<Rule> rules         = new ArrayList<>();

        public Builder pdf(String path)       { this.pdfPath = path; return this; }
        public Builder report(String path)    { this.reportPath = path; return this; }
        public Builder marginPct(double pct)  { this.marginPct = pct; return this; }
        public Builder caseSensitive(boolean v){ this.caseSensitive = v; return this; }

        public Builder mustContain(String text) {
            rules.add(new Rule(Rule.Type.MUST_CONTAIN, text, null, null, 0, 0, caseSensitive));
            return this;
        }

        public Builder mustNotContain(String text) {
            rules.add(new Rule(Rule.Type.MUST_NOT_CONTAIN, text, null, null, 0, 0, caseSensitive));
            return this;
        }

        public Builder mustContainInLeftMargin(String text) {
            rules.add(new Rule(Rule.Type.MUST_CONTAIN_LEFT_MARGIN, text, null, null, 0, 0, caseSensitive));
            return this;
        }

        public Builder mustContainInRightMargin(String text) {
            rules.add(new Rule(Rule.Type.MUST_CONTAIN_RIGHT_MARGIN, text, null, null, 0, 0, caseSensitive));
            return this;
        }

        public Builder mustContainOnAllPages(String text) {
            rules.add(new Rule(Rule.Type.MUST_CONTAIN_ALL_PAGES, text, null, null, 0, 0, caseSensitive));
            return this;
        }

        public Builder mustContainOnAnyPage(String text) {
            rules.add(new Rule(Rule.Type.MUST_CONTAIN_ANY_PAGE, text, null, null, 0, 0, caseSensitive));
            return this;
        }

        public Builder mustContainOnPage(int pageNumber, String text) {
            rules.add(new Rule(Rule.Type.MUST_CONTAIN_ON_PAGE, text, null, null,
                pageNumber, 0, caseSensitive));
            return this;
        }

        /** Validates that {@code target} appears between {@code before} and {@code after}
         *  somewhere in the document text (in reading order). */
        public Builder mustContainBetween(String target, String before, String after) {
            rules.add(new Rule(Rule.Type.MUST_CONTAIN_BETWEEN, target, before, after, 0, 0, caseSensitive));
            return this;
        }

        public Builder mustHaveImage() {
            rules.add(new Rule(Rule.Type.MUST_HAVE_IMAGE, null, null, null, 0, 0, false));
            return this;
        }

        public Builder mustHaveImageOnAllPages() {
            rules.add(new Rule(Rule.Type.MUST_HAVE_IMAGE_ALL_PAGES, null, null, null, 0, 0, false));
            return this;
        }

        public Builder minPages(int n) {
            rules.add(new Rule(Rule.Type.MIN_PAGES, null, null, null, 0, n, false));
            return this;
        }

        public Builder maxPages(int n) {
            rules.add(new Rule(Rule.Type.MAX_PAGES, null, null, null, 0, n, false));
            return this;
        }

        /**
         * Loads rules from a properties file with these keys (numbered 1..N):
         * <pre>
         *   must.contain.1=Account 1234567890
         *   must.not.contain.1=FEHLER
         *   must.contain.left-margin.1=MARGIN-ID-001
         *   must.contain.right-margin.1=Page 1
         *   must.contain.all-pages.1=Internal Use Only
         *   must.contain.any-page.1=Anhang
         *   must.contain.page.1=1=Bericht über die Kosten
         *   must.contain.between.1=target|Section Start:|Section End:
         *   must.have.image=true
         *   must.have.image.all-pages=true
         *   min.pages=5
         *   max.pages=50
         *   margin.pct=8.0
         *   case.sensitive=false
         * </pre>
         */
        public Builder rulesFile(String propertiesPath) throws IOException {
            Properties p = new Properties();
            // CRITICAL: Properties.load(InputStream) reads ISO-8859-1 by default,
            // which corrupts German characters like ü ö ä ß (ü becomes Ã¼).
            // We must use load(Reader) with explicit UTF-8 encoding.
            try (java.io.InputStreamReader reader = new java.io.InputStreamReader(
                    new FileInputStream(propertiesPath), java.nio.charset.StandardCharsets.UTF_8)) {
                p.load(reader);
            }
            return rulesFromProperties(p);
        }

        public Builder rulesFromProperties(Properties p) {
            // Global settings
            String mp = p.getProperty("margin.pct");
            if (mp != null) try { marginPct = Double.parseDouble(mp.trim()); } catch (Exception ignored) {}

            String cs = p.getProperty("case.sensitive");
            if (cs != null) caseSensitive = "true".equalsIgnoreCase(cs.trim());

            // Numbered rules (must.contain.1, must.contain.2, ...)
            forEachNumbered(p, "must.contain.",            this::mustContain);
            forEachNumbered(p, "must.not.contain.",        this::mustNotContain);
            forEachNumbered(p, "must.contain.left-margin.", this::mustContainInLeftMargin);
            forEachNumbered(p, "must.contain.right-margin.",this::mustContainInRightMargin);
            forEachNumbered(p, "must.contain.all-pages.",  this::mustContainOnAllPages);
            forEachNumbered(p, "must.contain.any-page.",   this::mustContainOnAnyPage);

            // Page-specific: must.contain.page.1=1=Bericht über die Kosten
            //                must.contain.page.2=5=Summary Total
            forEachNumbered(p, "must.contain.page.", value -> {
                int eq = value.indexOf('=');
                if (eq <= 0) return;
                try {
                    int pageNum = Integer.parseInt(value.substring(0, eq).trim());
                    String text = value.substring(eq + 1);
                    mustContainOnPage(pageNum, text);
                } catch (NumberFormatException ignored) {}
            });

            // Between: must.contain.between.1=target|before|after
            forEachNumbered(p, "must.contain.between.", value -> {
                String[] parts = value.split("\\|", 3);
                if (parts.length == 3) {
                    mustContainBetween(parts[0], parts[1], parts[2]);
                }
            });

            // Boolean flags
            if ("true".equalsIgnoreCase(p.getProperty("must.have.image", ""))) mustHaveImage();
            if ("true".equalsIgnoreCase(p.getProperty("must.have.image.all-pages", ""))) mustHaveImageOnAllPages();

            // Page count
            String minP = p.getProperty("min.pages");
            if (minP != null) try { minPages(Integer.parseInt(minP.trim())); } catch (Exception ignored) {}
            String maxP = p.getProperty("max.pages");
            if (maxP != null) try { maxPages(Integer.parseInt(maxP.trim())); } catch (Exception ignored) {}

            return this;
        }

        @FunctionalInterface
        private interface RuleAdder { void add(String value); }

        private static void forEachNumbered(Properties p, String prefix, RuleAdder adder) {
            for (int i = 1; i < 1000; i++) {
                String value = p.getProperty(prefix + i);
                if (value == null) break;
                if (!value.trim().isEmpty()) adder.add(value);
            }
        }

        public ValidationConfig build() {
            if (pdfPath == null || pdfPath.isEmpty())
                throw new IllegalStateException("pdf path is required");
            return new ValidationConfig(this);
        }
    }
}
