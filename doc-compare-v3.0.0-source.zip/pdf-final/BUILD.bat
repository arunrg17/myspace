@echo off
REM Build doc-compare.jar on Windows
REM Requires: Java 11+ and Maven 3.6+
cd /d "%~dp0"
echo Building doc-compare.jar with Maven...
mvn clean package
if %ERRORLEVEL% EQU 0 (
    echo.
    echo Build complete!
    echo   JAR location: target\doc-compare.jar
)
