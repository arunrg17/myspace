package com.apitest.server.service;

import com.apitest.model.TestResult;
import com.apitest.reporter.JsonReport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** The render-from-JSON capability, which needs no Excel or network. */
class EngineServiceTest {

    @Test
    void renderFromJsonRebuildsTheReport(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        EngineService engine = new EngineService(ws);

        TestResult r = new TestResult();
        r.testId = "T1"; r.name = "Sample"; r.status = "PASS"; r.durationMs = 5;
        String json = JsonReport.toJson(List.of(r), "Suite");

        String html = engine.renderFromJson(json);
        assertTrue(html.startsWith("<!DOCTYPE html>"));
        assertTrue(html.contains("Sample"));
        assertTrue(html.contains("Sample"));            // the test result is rendered
        assertFalse(html.contains("src=\"http"));        // self-contained
    }

    @Test
    void renderRejectsGarbage(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        EngineService engine = new EngineService(ws);
        assertThrows(Exception.class, () -> engine.renderFromJson("{not a report}"));
    }

    @Test
    void validateReportsMissingWorkbook(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        EngineService engine = new EngineService(ws);
        // A workbook that isn't there surfaces as ok=false, not an exception.
        assertThrows(Exception.class, () -> engine.validate("nope.xlsx"));
    }
}
