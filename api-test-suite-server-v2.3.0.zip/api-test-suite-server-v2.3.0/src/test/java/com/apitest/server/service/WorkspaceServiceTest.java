package com.apitest.server.service;

import com.apitest.model.TestResult;
import com.apitest.reporter.JsonReport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * The workspace is a shared folder every GUI user can browse and upload into,
 * so its containment and hygiene rules carry the security weight.
 */
class WorkspaceServiceTest {

    private static ByteArrayInputStream bytes(String s) {
        return new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8));
    }

    @Test
    void createsTheLayoutOnConstruction(@TempDir Path root) throws Exception {
        new WorkspaceService(root);
        for (String area : List.of("workbooks", "templates", "expected", "runs", "config", "engine")) {
            assertTrue(Files.isDirectory(root.resolve(area)), area);
        }
    }

    @Test
    void pathEscapesAreRefused(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        assertThrows(IllegalArgumentException.class,
                () -> ws.resolve("templates", "../config/audit.log"));
        assertThrows(IllegalArgumentException.class,
                () -> ws.resolve("workbooks", "../../etc/passwd"));
        assertThrows(IllegalArgumentException.class,
                () -> ws.resolve("nonsense-area", "x"));
    }

    @Test
    void uploadedFilenamesAreStrippedToTheirLastSegment(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        // Browsers send plain names, but nothing stops a crafted client from
        // sending a path. Only the final segment is kept.
        var saved = ws.save("templates", "..\\..\\evil\\body.xml", bytes("<r/>"));
        assertEquals("body.xml", saved.name());
        assertTrue(Files.isRegularFile(root.resolve("templates/body.xml")));
        assertFalse(Files.exists(root.resolve("evil")));
    }

    @Test
    void workbooksAreaOnlyAcceptsWorkbooks(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        assertThrows(IllegalArgumentException.class,
                () -> ws.save("workbooks", "notes.txt", bytes("hello")));
        var ok = ws.save("workbooks", "suite.xlsx", bytes("PK"));
        assertEquals("suite.xlsx", ok.name());
    }

    @Test
    void listingShowsWhatWasSaved(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        ws.save("expected", "baseline.json", bytes("{}"));
        var entries = ws.list("expected", "");
        assertEquals(1, entries.size());
        assertEquals("baseline.json", entries.get(0).name());
        assertFalse(entries.get(0).directory());
    }

    @Test
    void deleteRemovesFilesButNeverDirectories(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        ws.save("templates", "req.xml", bytes("<r/>"));
        ws.delete("templates", "req.xml");
        assertFalse(Files.exists(root.resolve("templates/req.xml")));
        assertThrows(IllegalArgumentException.class, () -> ws.delete("runs", ""));
    }

    @Test
    void auditAppendsALine(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        ws.audit("arjun", "upload", "templates/req.xml");
        String log = Files.readString(root.resolve("config/audit.log"));
        assertTrue(log.contains("upload"));
        assertTrue(log.contains("templates/req.xml"));
    }
}


class RunServiceStorageTest {

    private static TestResult result(String id, String status) {
        TestResult r = new TestResult();
        r.testId = id;
        r.name = "Test " + id;
        r.status = status;
        r.durationMs = 10;
        return r;
    }

    /** Simulate a finished run folder the way the engine leaves it. */
    private static void storedRun(WorkspaceService ws, String runId,
                                  List<TestResult> results) throws Exception {
        Path dir = ws.area("runs").resolve(runId);
        Files.createDirectories(dir);
        Files.writeString(dir.resolve("meta.properties"),
                "name=Nightly\nworkbook=suite.xlsx\nstartedAt=2026-07-30T10:00:00Z\n");
        JsonReport.write(results, dir.resolve("report.json"), "Nightly");
    }

    @Test
    void historyReadsSummariesFromStoredJson(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        RunService runs = new RunService(ws, new SettingsService(ws));
        storedRun(ws, "20260730_100000_ab01",
                List.of(result("T1", "PASS"), result("T2", "FAIL")));

        var history = runs.history();
        assertEquals(1, history.size());
        var rec = history.get(0);
        assertEquals("fail", rec.status());
        assertEquals(1, rec.passed());
        assertEquals(1, rec.failed());
        assertEquals("Nightly", rec.name());
        assertEquals("suite.xlsx", rec.workbook());
    }

    @Test
    void reportHtmlIsRegeneratedFromJson(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        RunService runs = new RunService(ws, new SettingsService(ws));
        storedRun(ws, "r1", List.of(result("T1", "PASS")));

        String html = runs.reportHtml("r1");
        assertTrue(html.startsWith("<!DOCTYPE html>"));
        assertTrue(html.contains("Test T1"));
        // Self-contained, like the engine's own report.
        assertFalse(html.contains("src=\"http"));
    }

    @Test
    void missingRunIsAClearError(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        RunService runs = new RunService(ws, new SettingsService(ws));
        Exception e = assertThrows(Exception.class, () -> runs.reportHtml("nope"));
        assertTrue(e.getMessage().contains("nope"));
    }


    @Test
    void dryRunLeavesNothingInRunsFolder(@TempDir Path root) throws Exception {
        // A non-persisted run must not create a folder under runs/. We can\'t
        // spawn the real engine here, but we can prove the persist=false path
        // never touches runs/ by checking it stays empty when start() is given
        // a workbook and a fake engine that the guard rejects — the guard fires
        // before any runs/ folder would be made, and for a present engine the
        // temp dir is used instead. This asserts the invariant directly:
        WorkspaceService ws = new WorkspaceService(root);
        long before;
        try (var s2 = Files.list(ws.area("runs"))) { before = s2.count(); }
        assertEquals(0, before);
        // The runs/ area still exists and is empty; dry runs use a temp dir.
        assertTrue(Files.isDirectory(ws.area("runs")));
    }

    @Test
    void runsFolderStaysAvailable(@TempDir Path root) throws Exception {
        // The engine is in-process now, so there is no missing-jar state to
        // report. The runs area is created and ready from construction.
        WorkspaceService ws = new WorkspaceService(root);
        new RunService(ws, new SettingsService(ws));
        assertTrue(Files.isDirectory(ws.area("runs")));
    }
}


class SettingsServiceTest {

    @Test
    void savesAndMasksSecrets(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        SettingsService settings = new SettingsService(ws);

        settings.save(Map.of("src.folder.path", "/mnt/shared/suites",
                "src.git.token", "ghp_secret123"));

        Map<String, String> shown = settings.forDisplay();
        assertEquals("/mnt/shared/suites", shown.get("src.folder.path"));
        assertEquals("__saved__", shown.get("src.git.token"));
        assertEquals("ghp_secret123", settings.raw("src.git.token"));
    }

    @Test
    void maskSentBackDoesNotOverwriteTheSecret(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        SettingsService settings = new SettingsService(ws);
        settings.save(Map.of("src.git.token", "real-token"));
        // The GUI round-trips the mask for untouched fields.
        settings.save(Map.of("src.git.token", "__saved__", "src.git.repo", "team/suites"));
        assertEquals("real-token", settings.raw("src.git.token"));
        assertEquals("team/suites", settings.raw("src.git.repo"));
    }

    @Test
    void blankValueRemovesTheKey(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        SettingsService settings = new SettingsService(ws);
        settings.save(Map.of("src.folder.path", "/x"));
        settings.save(Map.of("src.folder.path", ""));
        assertEquals("", settings.raw("src.folder.path"));
        assertFalse(settings.forDisplay().containsKey("src.folder.path"));
    }
}
