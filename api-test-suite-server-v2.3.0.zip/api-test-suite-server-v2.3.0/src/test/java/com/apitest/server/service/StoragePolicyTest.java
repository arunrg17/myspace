package com.apitest.server.service;

import com.apitest.model.CompareResult;
import com.apitest.model.StepResult;
import com.apitest.model.TestResult;
import com.apitest.reporter.JsonReport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** The storage options: trim, truncate, gzip — and that reading handles both forms. */
class StoragePolicyTest {

    private TestResult big() {
        TestResult r = new TestResult();
        r.testId = "T1"; r.name = "big"; r.status = "PASS"; r.comparisonMode = "vs_expected";
        String body = "x".repeat(50_000);
        StepResult s = new StepResult();
        s.order = 1; s.method = "GET"; s.url = "u"; s.status = 200; s.passed = true;
        s.requestBody = body; s.responseBody = body;
        r.stepsA.add(s);
        CompareResult cr = new CompareResult();
        cr.matched = true; cr.preparedExpected = body; cr.preparedActual = body;
        r.compareResult = cr;
        return r;
    }

    @Test
    void defaultKeepsEverythingPlain(@TempDir Path dir) throws Exception {
        StoragePolicy.defaults().write(List.of(big()), dir, "S");
        assertTrue(Files.isRegularFile(dir.resolve("report.json")));
        assertFalse(Files.isRegularFile(dir.resolve("report.json.gz")));
        JsonReport.Envelope env = StoragePolicy.read(dir);
        assertNotNull(env.results.get(0).compareResult.preparedExpected);
    }

    @Test
    void trimDropsPreparedCopies(@TempDir Path dir) throws Exception {
        new StoragePolicy(true, false, 20_000, false).write(List.of(big()), dir, "S");
        JsonReport.Envelope env = StoragePolicy.read(dir);
        assertNull(env.results.get(0).compareResult.preparedExpected);
        assertNull(env.results.get(0).compareResult.preparedActual);
        // the real body is still there
        assertEquals(50_000, env.results.get(0).stepsA.get(0).responseBody.length());
    }

    @Test
    void truncateClipsBodiesWithNote(@TempDir Path dir) throws Exception {
        new StoragePolicy(false, true, 1000, false).write(List.of(big()), dir, "S");
        JsonReport.Envelope env = StoragePolicy.read(dir);
        String body = env.results.get(0).stepsA.get(0).responseBody;
        assertTrue(body.length() < 2000);
        assertTrue(body.contains("truncated"));
    }

    @Test
    void gzipStoresCompressedAndReadsBack(@TempDir Path dir) throws Exception {
        new StoragePolicy(false, false, 20_000, true).write(List.of(big()), dir, "S");
        assertTrue(Files.isRegularFile(dir.resolve("report.json.gz")));
        assertFalse(Files.isRegularFile(dir.resolve("report.json")));
        // compressed file is far smaller than the raw JSON
        long gz = Files.size(dir.resolve("report.json.gz"));
        long raw = JsonReport.toJson(List.of(big()), "S").length();
        assertTrue(gz < raw / 5, "gzip should be <20% of raw");
        // and it round-trips
        JsonReport.Envelope env = StoragePolicy.read(dir);
        assertEquals("T1", env.results.get(0).testId);
    }
}
