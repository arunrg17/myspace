package com.apitest.server.service;

import com.apitest.model.TestResult;
import com.apitest.reporter.JsonReport;
import com.apitest.reporter.Reporter;
import com.apitest.runner.RunConfig;
import com.apitest.runner.Runner;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.stream.Stream;

/**
 * Runs suites in-process and owns everything under {@code runs/}.
 *
 * <p>The engine is part of this application, not a separate jar. A run executes
 * on a worker thread by calling {@link Runner#runAll} directly — no subprocess,
 * nothing to place on the volume. Each run still gets its own folder holding a
 * frozen copy of the workbook, a console log of the progress lines, and the
 * results as {@code report.json}. Only the JSON is stored; the HTML report is
 * regenerated from it on demand, so a long-lived archive stays small.
 *
 * <p>Runs are isolated from each other: one thread per run, its own output
 * folder, and its own cancellation flag. One wedged or failing suite cannot
 * affect another, and the engine already captures per-test errors so a single
 * bad test never aborts the run.
 */
public class RunService {

    /** A handle to a started run. */
    public record RunHandle(String runId) {}

    /** What the GUI needs to list a past run. */
    public record RunRecord(String runId, String name, String workbook, String status,
                            int passed, int failed, int errored, String startedAt,
                            long durationMs) {}

    private final WorkspaceService workspace;
    private final SettingsService settings;
    private final ExecutorService pool = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "apitest-run");
        t.setDaemon(true);
        return t;
    });
    /** Cancellation flags for in-flight runs. */
    private final Map<String, AtomicBoolean> active = new ConcurrentHashMap<>();
    /** Where each run's files live (runs/<id>, or a temp dir for a dry run). */
    private final Map<String, Path> runDirs = new ConcurrentHashMap<>();

    public RunService(WorkspaceService workspace, SettingsService settings) {
        this.workspace = workspace;
        this.settings = settings;
    }

    /**
     * Start a run on a worker thread. Progress lines go to {@code onLine} as
     * each test starts and finishes; {@code onDone} fires once with an exit-like
     * code (0 all passed, 1 failures/errors, 130 cancelled, -1 internal error).
     */
    public RunHandle start(String workbookRel, String runName,
                           Consumer<String> onLine, Consumer<Integer> onDone) throws IOException {
        return start(workbookRel, runName, true, onLine, onDone);
    }

    /**
     * Start a run.
     *
     * <p>When {@code persist} is false the run executes in a temporary folder
     * deleted on completion: the report and console still stream to the browser,
     * but nothing is written under {@code runs/}. That is for the dry runs done
     * while automating a new service, which would otherwise fill the volume with
     * results nobody keeps.
     */
    public RunHandle start(String workbookRel, String runName, boolean persist,
                           Consumer<String> onLine, Consumer<Integer> onDone) throws IOException {
        Path workbook = workspace.fileForDownload("workbooks", workbookRel);

        String runId = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")
                .format(java.time.LocalDateTime.now()) + "_" + Integer.toHexString(
                        (workbookRel + System.nanoTime()).hashCode()).substring(0, 4);
        Path runDir = persist
                ? workspace.area("runs").resolve(runId)
                : Files.createTempDirectory("apitest-dryrun-");
        Files.createDirectories(runDir);
        runDirs.put(runId, runDir);

        // Freeze the workbook so the record of what ran survives later edits to
        // the shared copy.
        Path frozen = runDir.resolve(workbook.getFileName().toString());
        Files.copy(workbook, frozen, StandardCopyOption.REPLACE_EXISTING);
        String name = runName == null || runName.isBlank() ? "API test run" : runName;
        Files.writeString(runDir.resolve("meta.properties"),
                "name=" + escape(name) + "\n"
                + "workbook=" + escape(workbookRel) + "\n"
                + "startedAt=" + Instant.now() + "\n");

        AtomicBoolean cancelled = new AtomicBoolean(false);
        active.put(runId, cancelled);

        RunConfig cfg = new RunConfig(
                frozen,
                runDir.resolve("report.html"),
                workspace.root(),
                workspace.area("templates"),
                workspace.area("expected"),
                runDir,
                name);

        pool.submit(() -> {
            int code;
            try (var console = Files.newBufferedWriter(runDir.resolve("console.log"))) {
                Consumer<String> sink = line -> {
                    try {
                        console.write(line);
                        console.newLine();
                        console.flush();
                    } catch (IOException ignored) { }
                    onLine.accept(line);
                };
                try {
                    StoragePolicy policy = StoragePolicy.from(settings);
                    List<TestResult> results = Runner.runAll(cfg, sink, cancelled::get);
                    policy.write(results, runDir, name);
                    boolean anyBad = results.stream()
                            .anyMatch(r -> !"PASS".equals(r.status));
                    code = cancelled.get() ? 130 : (anyBad ? 1 : 0);
                    // cancel() already recorded the cancelled flag on disk the
                    // moment it was requested, so history is correct no matter
                    // how we exit here.
                    sink.accept(cancelled.get() ? "  Run cancelled" : summaryLine(results));
                } catch (Exception e) {
                    // If the run was cancelled, an interrupted in-flight call can
                    // surface as an exception — that is still a cancellation, not
                    // an error. cancel() has already flagged it on disk.
                    code = cancelled.get() ? 130 : -1;
                    sink.accept(cancelled.get() ? "  Run cancelled"
                            : "[error] " + e.getClass().getSimpleName() + ": " + e.getMessage());
                }
            } catch (IOException e) {
                onLine.accept("[error] could not open console log: " + e.getMessage());
                code = -1;
            } finally {
                active.remove(runId);
                if (!persist) {
                    deleteQuietly(runDir);
                    runDirs.remove(runId);
                } else {
                    // The frozen workbook and console log are kept only as a
                    // record — nothing reads them back at request time — and the
                    // workbook especially can be large. Gzip both now that the
                    // run is done, so a kept run's folder stays small.
                    gzipInPlace(runDir.resolve(frozen.getFileName().toString()));
                    gzipInPlace(runDir.resolve("console.log"));
                    // The engine also drops per-test request.txt / response.txt
                    // debug files under a timestamped subfolder. Everything in
                    // them is already in report.json (which the HTML report is
                    // rebuilt from), so for large suites they are pure
                    // duplication — the real space hog. Compact that tree:
                    // gzip each text file in place, keeping the folder browsable
                    // but small.
                    StoragePolicy policy = StoragePolicy.from(settings);
                    compactArtifacts(runDir, policy);
                }
            }
            onDone.accept(code);
        });

        workspace.audit(null, persist ? "run.start" : "run.start.dry",
                runId + " " + workbookRel);
        return new RunHandle(runId);
    }

    private static String summaryLine(List<TestResult> results) {
        long passed = results.stream().filter(r -> "PASS".equals(r.status)).count();
        long failed = results.stream().filter(r -> "FAIL".equals(r.status)).count();
        long errored = results.stream().filter(r -> !"PASS".equals(r.status) && !"FAIL".equals(r.status)).count();
        return "  " + passed + " passed \u00b7 " + failed + " failed \u00b7 " + errored + " errored";
    }

    /** Ask an in-flight run to stop; it ends after the current test. */
    public boolean cancel(String runId) {
        AtomicBoolean flag = active.get(runId);
        if (flag == null) return false;
        flag.set(true);
        // Mark the run cancelled on disk immediately, the moment the request
        // arrives — not when the run finishes. However the run then ends (clean
        // break between tests, or an exception from an interrupted in-flight
        // call), history will read this and show "cancelled" rather than
        // treating the unfinished run as an error.
        Path dir = runDirs.get(runId);
        if (dir != null) {
            try {
                Files.writeString(dir.resolve("meta.properties"),
                        "cancelled=true\n", java.nio.file.StandardOpenOption.APPEND,
                        java.nio.file.StandardOpenOption.CREATE);
            } catch (IOException ignored) { }
        }
        workspace.audit(null, "run.cancel", runId);
        return true;
    }

    /** Run ids currently executing, so a returning browser can re-attach. */
    public java.util.Set<String> activeRuns() {
        return new java.util.HashSet<>(active.keySet());
    }

    /** Whether a specific run is still executing. */
    public boolean isActive(String runId) {
        return active.containsKey(runId);
    }

    /** The stored results of a finished run, or null when it has none. */
    public JsonReport.Envelope results(String runId) throws IOException {
        Path dir = runDirs.getOrDefault(runId, workspace.resolve("runs", runId));
        return StoragePolicy.read(dir);
    }

    /**
     * The HTML report for a stored run, regenerated from its JSON. Identical to
     * what the engine would have written — same renderer, same data.
     */
    public String reportHtml(String runId) throws IOException {
        JsonReport.Envelope env = results(runId);
        if (env == null) throw new IOException("Run " + runId + " has no stored results");
        return Reporter.renderHtml(env.results, env.suiteName);
    }

    /** All stored runs, newest first. */
    public List<RunRecord> history() throws IOException {
        Path runs = workspace.area("runs");
        List<RunRecord> out = new ArrayList<>();
        try (Stream<Path> dirs = Files.list(runs)) {
            for (Path dir : dirs.filter(Files::isDirectory).toList()) {
                out.add(record(dir));
            }
        }
        out.sort(Comparator.comparing(RunRecord::startedAt).reversed());
        return out;
    }

    private RunRecord record(Path runDir) {
        String runId = runDir.getFileName().toString();
        String name = "", workbook = "", startedAt = "";
        boolean wasCancelled = false;
        Path meta = runDir.resolve("meta.properties");
        if (Files.isRegularFile(meta)) {
            try {
                var props = new java.util.Properties();
                try (var in = Files.newInputStream(meta)) { props.load(in); }
                name = props.getProperty("name", "");
                workbook = props.getProperty("workbook", "");
                startedAt = formatStarted(props.getProperty("startedAt", ""));
                wasCancelled = "true".equals(props.getProperty("cancelled", ""));
            } catch (IOException ignored) { }
        }
        int passed = 0, failed = 0, errored = 0;
        long durationMs = 0;
        String status = "running";
        if (StoragePolicy.hasResults(runDir)) {
            try {
                JsonReport.Summary s = StoragePolicy.read(runDir).summary;
                passed = s.passed; failed = s.failed; errored = s.errored;
                durationMs = s.durationMs;
                status = wasCancelled ? "cancelled"
                        : s.errored > 0 ? "error" : s.failed > 0 ? "fail" : "pass";
            } catch (IOException e) {
                status = "error";
            }
        } else if (wasCancelled) {
            status = "cancelled";
        } else if (!active.containsKey(runId)) {
            status = "error";
        }
        return new RunRecord(runId, name, workbook, status, passed, failed, errored,
                startedAt, durationMs);
    }

    /**
     * Compact the per-test debug artifacts (request.txt / response.txt /
     * render-log.txt) the engine writes under a timestamped subfolder of the
     * run. Everything in them is already in report.json, from which the HTML
     * report is rebuilt, so they are redundant on the server.
     *
     * <p>When the user has turned on any result-storage saving (trim, truncate
     * or gzip), the whole artifact tree is removed — report.json is the source
     * of truth and these files were the largest duplicated cost. When no saving
     * is selected, the files are gzipped in place instead, so nothing is lost
     * but the folder still shrinks.
     */
    private static void compactArtifacts(Path runDir, StoragePolicy policy) {
        boolean anySaving = policy.trimPrepared || policy.truncateBodies || policy.gzip;
        try (Stream<Path> entries = Files.list(runDir)) {
            for (Path entry : entries.filter(Files::isDirectory).toList()) {
                // The engine's artifact root is a timestamped folder; the run's
                // own known subfolders are never directories here.
                if (anySaving) {
                    deleteQuietly(entry);
                } else {
                    gzipTree(entry);
                }
            }
        } catch (IOException ignored) { }
    }

    /** Gzip every regular file under a directory tree, in place. */
    private static void gzipTree(Path dir) {
        try (Stream<Path> walk = Files.walk(dir)) {
            for (Path p : walk.filter(Files::isRegularFile).toList()) {
                gzipInPlace(p);
            }
        } catch (IOException ignored) { }
    }

    /**
     * Replace a file with its gzipped form ({@code name.gz}), deleting the
     * original. Best-effort: on any error the original is left untouched.
     */
    private static void gzipInPlace(Path file) {
        if (!Files.isRegularFile(file)) return;
        Path gz = file.resolveSibling(file.getFileName().toString() + ".gz");
        try {
            try (var in = Files.newInputStream(file);
                 var out = new java.util.zip.GZIPOutputStream(Files.newOutputStream(gz))) {
                in.transferTo(out);
            }
            Files.deleteIfExists(file);
        } catch (IOException e) {
            try { Files.deleteIfExists(gz); } catch (IOException ignored) { }
        }
    }

    /**
     * At-a-glance figures for the dashboard, built from stored run summaries.
     * Reads only the JSON summaries (not full results), so it stays cheap even
     * with a long history.
     */
    public Map<String, Object> dashboard(int maxRuns) throws IOException {
        List<RunRecord> all = history();
        List<RunRecord> recent = all.stream()
                .filter(r -> !"running".equals(r.status()))
                .limit(maxRuns)
                .toList();

        int runs = recent.size();
        long totalTests = 0, totalPassed = 0, totalFailed = 0, totalErrored = 0;
        long cancelled = 0;
        // Pass rate per run, newest first, for a small trend line.
        List<Map<String, Object>> trend = new java.util.ArrayList<>();
        // Slowest runs by duration.
        List<Map<String, Object>> slowest = new java.util.ArrayList<>();

        for (RunRecord r : recent) {
            int tests = r.passed() + r.failed() + r.errored();
            totalTests += tests;
            totalPassed += r.passed();
            totalFailed += r.failed();
            totalErrored += r.errored();
            if ("cancelled".equals(r.status())) cancelled++;
            int rate = tests == 0 ? 0 : (int) Math.round(100.0 * r.passed() / tests);
            trend.add(Map.of("runId", r.runId(), "name", r.name(),
                    "startedAt", r.startedAt(), "passRate", rate,
                    "status", r.status()));
            slowest.add(Map.of("runId", r.runId(), "name", r.name(),
                    "durationMs", r.durationMs(), "tests", tests));
        }

        slowest.sort((a, b) -> Long.compare((long) b.get("durationMs"), (long) a.get("durationMs")));
        List<Map<String, Object>> topSlow = slowest.stream().limit(5).toList();

        int overallRate = totalTests == 0 ? 0
                : (int) Math.round(100.0 * totalPassed / totalTests);

        // trend is newest-first from history; reverse so the sparkline reads
        // left-to-right oldest→newest.
        java.util.Collections.reverse(trend);

        Map<String, Object> out = new java.util.LinkedHashMap<>();
        out.put("runs", runs);
        out.put("totalTests", totalTests);
        out.put("passed", totalPassed);
        out.put("failed", totalFailed);
        out.put("errored", totalErrored);
        out.put("cancelled", cancelled);
        out.put("overallPassRate", overallRate);
        out.put("trend", trend);
        out.put("slowest", topSlow);
        out.put("lastRun", recent.isEmpty() ? null : Map.of(
                "runId", recent.get(0).runId(),
                "name", recent.get(0).name(),
                "status", recent.get(0).status(),
                "startedAt", recent.get(0).startedAt()));
        return out;
    }

    private static void deleteQuietly(Path dir) {
        try (Stream<Path> walk = Files.walk(dir)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (IOException ignored) { }
            });
        } catch (IOException ignored) { }
    }

    /**
     * Turn the stored ISO instant (e.g. 2026-08-12T13:55:18.123456Z) into a
     * plain second-precision local timestamp for display, matching the report.
     */
    private static String formatStarted(String iso) {
        if (iso == null || iso.isBlank()) return "";
        try {
            return java.time.LocalDateTime.ofInstant(
                            java.time.Instant.parse(iso), java.time.ZoneId.systemDefault())
                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        } catch (Exception e) {
            // Unknown format: strip any fractional seconds rather than fail.
            int dot = iso.indexOf('.');
            return dot > 0 ? iso.substring(0, dot) : iso;
        }
    }

    private static String escape(String v) {
        return v == null ? "" : v.replace("\\", "\\\\").replace("\n", " ");
    }
}
