package com.apitest.server;

import com.apitest.server.service.EngineService;
import com.apitest.server.service.RunService;
import com.apitest.server.service.SettingsService;
import com.apitest.server.service.WorkspaceService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.nio.file.Path;

/**
 * The API test suite as a single Spring Boot application.
 *
 * <p>The test engine is part of this app, not a separate jar: runs execute
 * in-process on worker threads and every engine capability is reached through
 * the service layer. All state lives under one configured workspace root — the
 * mounted pod volume — so the app itself is stateless and can be restarted or
 * rescheduled freely. Set the root with {@code apitest.workspace} (property,
 * environment variable {@code APITEST_WORKSPACE}, or --apitest.workspace=...).
 */
@SpringBootApplication
@EnableConfigurationProperties(ApiTestServerApplication.WorkspaceProperties.class)
public class ApiTestServerApplication {

    @ConfigurationProperties(prefix = "apitest")
    public record WorkspaceProperties(String workspace) {
        public WorkspaceProperties {
            if (workspace == null || workspace.isBlank()) workspace = "./workspace";
        }
    }

    public static void main(String[] args) {
        SpringApplication.run(ApiTestServerApplication.class, args);
    }

    @Bean
    public WorkspaceService workspaceService(WorkspaceProperties props) throws IOException {
        return new WorkspaceService(Path.of(props.workspace()));
    }

    @Bean
    public RunService runService(WorkspaceService workspace, SettingsService settings) {
        return new RunService(workspace, settings);
    }

    @Bean
    public EngineService engineService(WorkspaceService workspace) {
        return new EngineService(workspace);
    }

    @Bean
    public SettingsService settingsService(WorkspaceService workspace) {
        return new SettingsService(workspace);
    }
}
