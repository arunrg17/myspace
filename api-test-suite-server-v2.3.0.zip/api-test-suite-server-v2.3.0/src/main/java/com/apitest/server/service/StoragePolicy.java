package com.apitest.server.service;

import com.apitest.model.StepResult;
import com.apitest.model.TestResult;
import com.apitest.reporter.JsonReport;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * How run results are stored on the volume. The choices are settings the user
 * picks in the GUI, so a team can trade readability for space:
 *
 * <ul>
 *   <li><b>trimPrepared</b> — drop the normalized copies of the payloads that
 *       the comparator keeps ({@code preparedExpected}/{@code preparedActual}).
 *       They are re-derivable from the raw bodies and roughly double payload
 *       storage, so dropping them is the single biggest saving with no loss of
 *       the actual request/response.
 *   <li><b>truncateBodies</b> — cap each stored request/response body at a
 *       size, replacing the tail with a short note. Keeps a report browsable
 *       when a payload is megabytes long; the full body is still what was sent,
 *       just clipped in the stored record.
 *   <li><b>gzip</b> — store {@code report.json.gz} instead of {@code report.json}.
 *       JSON compresses extremely well (often 85–95%), and the report is only
 *       ever read back by this app, so the on-disk form need not be plain text.
 * </ul>
 *
 * <p>All three are independent and off by default, so behaviour does not change
 * until a user opts in. Reading transparently handles either a plain or a
 * gzipped file, so turning gzip on or off does not strand older runs.
 */
public final class StoragePolicy {

    public final boolean trimPrepared;
    public final boolean truncateBodies;
    public final int maxBodyChars;
    public final boolean gzip;

    public StoragePolicy(boolean trimPrepared, boolean truncateBodies,
                         int maxBodyChars, boolean gzip) {
        this.trimPrepared = trimPrepared;
        this.truncateBodies = truncateBodies;
        this.maxBodyChars = maxBodyChars <= 0 ? 20_000 : maxBodyChars;
        this.gzip = gzip;
    }

    /** The default: everything off, plain readable JSON, nothing trimmed. */
    public static StoragePolicy defaults() {
        return new StoragePolicy(false, false, 20_000, false);
    }

    /** Read the policy from the shared settings. */
    public static StoragePolicy from(SettingsService settings) {
        return new StoragePolicy(
                settings.getBool("storage.trim.prepared", false),
                settings.getBool("storage.truncate.bodies", false),
                settings.getInt("storage.truncate.maxchars", 20_000),
                settings.getBool("storage.gzip", false));
    }

    /** The file name results should be written to under this policy. */
    public String fileName() {
        return gzip ? "report.json.gz" : "report.json";
    }

    /**
     * Apply the trimming rules to the results in place, then write them —
     * gzipped or plain per the policy — to the run folder. Returns the path
     * actually written.
     */
    public Path write(List<TestResult> results, Path runDir, String suiteName) throws IOException {
        if (trimPrepared || truncateBodies) {
            for (TestResult r : results) {
                if (trimPrepared && r.compareResult != null) {
                    r.compareResult.preparedExpected = null;
                    r.compareResult.preparedActual = null;
                }
                if (truncateBodies) {
                    truncateSteps(r.stepsA);
                    truncateSteps(r.stepsB);
                }
            }
        }
        String json = JsonReport.toJson(results, suiteName);
        Path out = runDir.resolve(fileName());
        if (gzip) {
            try (OutputStream os = new GZIPOutputStream(Files.newOutputStream(out))) {
                os.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
        } else {
            Files.writeString(out, json);
        }
        return out;
    }

    private void truncateSteps(List<StepResult> steps) {
        if (steps == null) return;
        for (StepResult s : steps) {
            s.requestBody = clip(s.requestBody);
            s.responseBody = clip(s.responseBody);
        }
    }

    private String clip(String body) {
        if (body == null || body.length() <= maxBodyChars) return body;
        int shown = maxBodyChars;
        return body.substring(0, shown)
                + "\n… [truncated " + (body.length() - shown) + " more characters; "
                + "raw body was " + body.length() + " characters]";
    }

    /**
     * Read a run's results, whichever form is on disk. Prefers a gzipped file
     * when both exist. Returns null when neither is present.
     */
    public static JsonReport.Envelope read(Path runDir) throws IOException {
        Path gz = runDir.resolve("report.json.gz");
        Path plain = runDir.resolve("report.json");
        if (Files.isRegularFile(gz)) {
            try (InputStream in = new GZIPInputStream(Files.newInputStream(gz))) {
                return JsonReport.fromJson(new String(in.readAllBytes(),
                        java.nio.charset.StandardCharsets.UTF_8));
            }
        }
        if (Files.isRegularFile(plain)) {
            return JsonReport.read(plain);
        }
        return null;
    }

    /** True when a run folder has results in either form. */
    public static boolean hasResults(Path runDir) {
        return Files.isRegularFile(runDir.resolve("report.json.gz"))
                || Files.isRegularFile(runDir.resolve("report.json"));
    }
}
