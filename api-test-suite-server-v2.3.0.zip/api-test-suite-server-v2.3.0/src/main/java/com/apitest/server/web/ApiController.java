package com.apitest.server.web;

import com.apitest.server.service.EngineService;
import com.apitest.server.service.RunService;
import com.apitest.server.service.SettingsService;
import com.apitest.server.service.WorkspaceService;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The HTTP contract the GUI talks to. Kept as thin adapters over the service
 * layer — every rule (containment, hygiene, storage) lives in the services,
 * which carry their own tests.
 */
@RestController
@RequestMapping("/api")
public class ApiController {

    private final WorkspaceService workspace;
    private final RunService runs;
    private final EngineService engine;
    private final SettingsService settings;

    /** Live SSE subscribers per run. */
    private final Map<String, SseEmitter> streams = new ConcurrentHashMap<>();
    /** Console lines buffered until (and after) the subscriber attaches. */
    private final Map<String, List<String>> consoles = new ConcurrentHashMap<>();
    private final Map<String, Map<String, Object>> summaries = new ConcurrentHashMap<>();

    public ApiController(WorkspaceService workspace, RunService runs,
                         EngineService engine, SettingsService settings) {
        this.workspace = workspace;
        this.runs = runs;
        this.engine = engine;
        this.settings = settings;
    }

    // ── context ──────────────────────────────────────────────────────────

    @GetMapping("/context")
    public Map<String, Object> context() throws IOException {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("root", workspace.root().toString());
        out.put("engine", "in-process");
        out.put("version", com.apitest.Version.VERSION);
        out.put("templates", workspace.area("templates").toString());
        out.put("templatesOk", Files.isDirectory(workspace.area("templates")));
        out.put("expected", workspace.area("expected").toString());
        out.put("expectedOk", Files.isDirectory(workspace.area("expected")));
        out.put("output", workspace.area("runs").toString());
        out.put("workbooks", workspace.workbooks().stream()
                .map(WorkspaceService.Entry::name).toList());
        return out;
    }

    // ── workspace file management ────────────────────────────────────────

    @GetMapping("/files")
    public Map<String, Object> listFiles(@RequestParam String area,
                                         @RequestParam(defaultValue = "") String path) {
        try {
            return Map.of("entries", workspace.list(area, path));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PostMapping("/files")
    public Map<String, Object> upload(@RequestParam String area,
                                      @RequestHeader("X-Filename") String filename,
                                      InputStream body,
                                      @RequestHeader(value = "X-User", required = false) String user) {
        try {
            var saved = workspace.save(area, filename, body);
            workspace.audit(user, "upload", area + "/" + saved.path());
            return Map.of("saved", saved.path(), "bytes", saved.size());
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @GetMapping("/files/download")
    public ResponseEntity<FileSystemResource> download(@RequestParam String area,
                                                       @RequestParam String path) {
        try {
            Path file = workspace.fileForDownload(area, path);
            return ResponseEntity.ok()
                    .header("Content-Disposition",
                            "attachment; filename=\"" + file.getFileName() + "\"")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new FileSystemResource(file));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
    }

    @DeleteMapping("/files")
    public Map<String, Object> delete(@RequestParam String area, @RequestParam String path,
                                      @RequestHeader(value = "X-User", required = false) String user) {
        try {
            workspace.delete(area, path);
            workspace.audit(user, "delete", area + "/" + path);
            return Map.of("deleted", path);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    /** Workbook upload endpoint the existing GUI already calls. */
    @PostMapping("/upload")
    public Map<String, Object> uploadWorkbook(@RequestHeader("X-Filename") String filename,
                                              InputStream body) {
        return upload("workbooks", filename, body, null);
    }

    // ── runs ─────────────────────────────────────────────────────────────

    @PostMapping(value = "/run", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> run(@RequestParam String workbook,
                                   @RequestParam(defaultValue = "API test run") String name,
                                   @RequestParam(defaultValue = "true") boolean save) {
        try {
            List<String> console = new java.util.concurrent.CopyOnWriteArrayList<>();
            // The pump thread can emit before start() returns the runId, so the
            // callbacks wait on this latch until registration has happened.
            var registered = new java.util.concurrent.CountDownLatch(1);
            var runIdHolder = new java.util.concurrent.atomic.AtomicReference<String>("");

            var handle = runs.start(workbook, name, save,
                    line -> {
                        await(registered);
                        console.add(line);
                        SseEmitter emitter = streams.get(runIdHolder.get());
                        if (emitter != null) {
                            try {
                                emitter.send(SseEmitter.event().name("line").data(line));
                            } catch (IOException ignored) { }
                        }
                    },
                    exit -> {
                        await(registered);
                        // A dry run's folder is about to be deleted, so capture
                        // its report now while it still exists on disk.
                        if (!save) captureDryRun(runIdHolder.get());
                        finish(runIdHolder.get(), exit);
                    });

            runIdHolder.set(handle.runId());
            consoles.put(handle.runId(), console);
            registered.countDown();
            return Map.of("runId", handle.runId());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    /** Rendered reports for dry runs, held in memory only (never on the volume). */
    private final Map<String, String> dryRunReports = new ConcurrentHashMap<>();

    private void captureDryRun(String runId) {
        try {
            var env = runs.results(runId);
            if (env != null) {
                dryRunReports.put(runId,
                        com.apitest.reporter.Reporter.renderHtml(env.results, env.suiteName));
            }
        } catch (IOException ignored) {
            // No results to capture (e.g. the workbook failed to load).
        }
    }

    private static void await(java.util.concurrent.CountDownLatch latch) {
        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void finish(String runId, int exit) {
        Map<String, Object> summary = new LinkedHashMap<>();
        try {
            var env = runs.results(runId);
            if (env != null) {
                summary.put("passed", env.summary.passed);
                summary.put("failed", env.summary.failed);
                summary.put("errored", env.summary.errored);
                summary.put("durationMs", env.summary.durationMs);
                summary.put("status", env.summary.errored > 0 ? "error"
                        : env.summary.failed > 0 ? "fail" : "pass");
            } else {
                summary.put("passed", 0);
                summary.put("failed", 0);
                summary.put("errored", 0);
                summary.put("durationMs", 0);
                summary.put("status", exit == 143 || exit == 137 ? "cancelled" : "error");
            }
        } catch (IOException e) {
            summary.put("status", "error");
        }
        summary.put("exit", exit);
        summary.put("report", "/api/reports/" + runId + "/html");
        summaries.put(runId, summary);

        SseEmitter emitter = streams.remove(runId);
        if (emitter != null) {
            try {
                emitter.send(SseEmitter.event().name("done")
                        .data(summary, MediaType.APPLICATION_JSON));
                emitter.complete();
            } catch (IOException ignored) { }
        }
    }

    @GetMapping("/stream")
    public SseEmitter stream(@RequestParam String runId) {
        SseEmitter emitter = new SseEmitter(0L);
        // Replay whatever printed before the subscriber attached.
        List<String> console = consoles.get(runId);
        try {
            if (console != null) {
                for (String line : console) {
                    emitter.send(SseEmitter.event().name("line").data(line));
                }
            }
            Map<String, Object> done = summaries.get(runId);
            if (done != null) {
                emitter.send(SseEmitter.event().name("done")
                        .data(done, MediaType.APPLICATION_JSON));
                emitter.complete();
                return emitter;
            }
        } catch (IOException e) {
            emitter.completeWithError(e);
            return emitter;
        }
        streams.put(runId, emitter);
        emitter.onCompletion(() -> streams.remove(runId, emitter));
        emitter.onTimeout(() -> streams.remove(runId, emitter));
        return emitter;
    }

    @PostMapping(value = "/cancel", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> cancel(@RequestParam String runId) {
        return Map.of("cancelled", runs.cancel(runId));
    }

    // ── history, results, reports, trends ────────────────────────────────

    /**
     * Runs still executing right now, so a browser returning to the run screen
     * can re-attach to one it started earlier instead of showing Idle. Each id
     * can be streamed again at /stream, which replays the console from the top.
     */
    @GetMapping("/active")
    public Map<String, Object> active() {
        return Map.of("runIds", new java.util.ArrayList<>(runs.activeRuns()));
    }

    /** Aggregated figures for the dashboard overview. */
    @GetMapping("/dashboard")
    public Map<String, Object> dashboard() throws IOException {
        return runs.dashboard(50);
    }

    @GetMapping("/history")
    public Map<String, Object> history() throws IOException {
        return Map.of("entries", runs.history().stream().map(r -> Map.of(
                "runId", r.runId(), "name", r.name(), "workbook", r.workbook(),
                "status", r.status(), "passed", r.passed(), "failed", r.failed(),
                "errored", r.errored(), "startedAt", r.startedAt(),
                "report", "/api/reports/" + r.runId() + "/html")).toList());
    }

    @GetMapping("/results")
    public Map<String, Object> results(@RequestParam("report") String runId) {
        try {
            var env = runs.results(extractRunId(runId));
            if (env == null) return Map.of("entries", List.of());
            return Map.of("entries", env.results.stream().map(t -> Map.of(
                    "id", t.testId == null ? "" : t.testId,
                    "title", t.name == null ? "" : t.name,
                    "status", t.status == null ? "" : t.status,
                    "mode", t.comparisonMode == null ? "" : t.comparisonMode,
                    "ms", t.durationMs)).toList());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
    }

    /** The GUI historically passed a report path; accept a bare runId too. */
    private static String extractRunId(String reportRef) {
        String s = reportRef.replace('\\', '/');
        if (s.contains("/reports/")) {
            s = s.substring(s.indexOf("/reports/") + "/reports/".length());
        }
        int slash = s.indexOf('/');
        return slash < 0 ? s : s.substring(0, slash);
    }

    /** The stored JSON itself, for tooling and export (always plain JSON). */
    @GetMapping(value = "/reports/{runId}/json", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> reportJson(@PathVariable String runId) {
        try {
            var env = runs.results(runId);
            if (env == null) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No results for " + runId);
            }
            // Re-serialize so the caller always gets plain JSON even when the
            // run is stored gzipped on the volume.
            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"report.json\"")
                    .body(com.apitest.reporter.JsonReport.toJson(env.results, env.suiteName));
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    /** The report, regenerated from stored JSON at request time. */
    @GetMapping(value = "/reports/{runId}/html", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> reportHtml(@PathVariable String runId,
                                             @RequestParam(defaultValue = "false") boolean download) {
        String html;
        String dry = dryRunReports.get(runId);
        if (dry != null) {
            html = dry;
        } else {
            try {
                html = runs.reportHtml(runId);
            } catch (IOException e) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
            }
        }
        // The report is one self-contained HTML file — all CSS and JS inlined —
        // so a downloaded copy works fully offline, every tab and link intact.
        // download=true makes the browser save it; otherwise it opens inline.
        ResponseEntity.BodyBuilder b = ResponseEntity.ok().contentType(MediaType.TEXT_HTML);
        if (download) {
            b.header("Content-Disposition", "attachment; filename=\"report-" + runId + ".html\"");
        }
        return b.body(html);
    }

    // ── engine capabilities (in-process) ────────────────────────────────

    /** Structural check of a workbook: does it parse, what is in it, problems. */
    @GetMapping("/validate")
    public Map<String, Object> validate(@RequestParam String workbook) {
        try {
            return engine.validate(workbook);
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    /** Preview a test's resolved endpoint and body without sending anything. */
    @GetMapping("/preview")
    public Map<String, Object> preview(@RequestParam String workbook,
                                       @RequestParam String testId,
                                       @RequestParam(defaultValue = "A") String source) {
        try {
            return engine.preview(workbook, testId, source);
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    /** Run exactly one test and return its result envelope. */
    @PostMapping(value = "/run-single", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> runSingle(@RequestParam String workbook,
                                         @RequestParam String testId) {
        try {
            var env = engine.runSingle(workbook, testId);
            var first = env.results.isEmpty() ? null : env.results.get(0);
            return Map.of(
                    "status", first == null ? "ERROR" : first.status,
                    "summary", Map.of("passed", env.summary.passed,
                            "failed", env.summary.failed, "errored", env.summary.errored),
                    "result", first == null ? Map.of() : Map.of(
                            "id", first.testId == null ? "" : first.testId,
                            "title", first.name == null ? "" : first.name,
                            "mode", first.comparisonMode == null ? "" : first.comparisonMode,
                            "ms", first.durationMs));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    /** Render a report from a results JSON posted in the body (results.json). */
    @PostMapping(value = "/render", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.TEXT_HTML_VALUE)
    public String render(@RequestBody String resultsJson) {
        try {
            return engine.renderFromJson(resultsJson);
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Not a valid results file: " + e.getMessage());
        }
    }

    // ── settings and sources ─────────────────────────────────────────────

    @GetMapping("/settings")
    public Map<String, String> settings() throws IOException {
        return settings.forDisplay();
    }

    @PostMapping(value = "/settings", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> saveSettings(@RequestParam Map<String, String> form)
            throws IOException {
        settings.save(form);
        return Map.of("saved", true);
    }

    /**
     * Download a starter workbook. First-time users get a correctly-structured
     * template — the six sheets with headers and a couple of example rows — so
     * they are not building the workbook from a blank page.
     *
     * <p>The file served is config/test_suite_template.xlsx in the workspace,
     * so a team can drop in its own house template and everyone downloads that.
     */
    @GetMapping("/template")
    public ResponseEntity<FileSystemResource> template() {
        Path template = workspace.area("config").resolve("test_suite_template.xlsx");
        if (!Files.isRegularFile(template)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "No template is installed. Place test_suite_template.xlsx in the "
                    + "workspace config/ folder.");
        }
        return ResponseEntity.ok()
                .header("Content-Disposition",
                        "attachment; filename=\"test_suite_template.xlsx\"")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(new FileSystemResource(template));
    }

    /** Whether a template is available to download (drives the GUI button). */
    @GetMapping("/template/available")
    public Map<String, Object> templateAvailable() {
        return Map.of("available",
                Files.isRegularFile(workspace.area("config").resolve("test_suite_template.xlsx")));
    }

    /**
     * Workbooks visible in the configured shared folder (src.folder.path), so
     * teams can keep suites outside the workspace and pull them in on demand.
     */
    @GetMapping("/sources/list")
    public Map<String, Object> sourcesList(@RequestParam String type) throws IOException {
        if (!"folder".equals(type)) {
            return Map.of("items", List.of(),
                    "error", "Source type '" + type + "' is not configured on this server");
        }
        String configured = settings.raw("src.folder.path");
        if (configured.isBlank()) {
            return Map.of("items", List.of(), "error",
                    "No shared folder configured. Set it under Settings → Workbook sources.");
        }
        Path dir = Path.of(configured);
        if (!Files.isDirectory(dir)) {
            return Map.of("items", List.of(), "error", "Not a directory: " + configured);
        }
        try (var children = Files.list(dir)) {
            return Map.of("items", children
                    .filter(p -> WorkspaceService.extension(p.getFileName().toString())
                            .matches("xlsx|xlsm"))
                    .map(p -> {
                        try {
                            return Map.of("name", p.getFileName().toString(),
                                    "path", p.toString(), "size", Files.size(p));
                        } catch (IOException e) {
                            return Map.of("name", p.getFileName().toString(),
                                    "path", p.toString(), "size", 0L);
                        }
                    }).toList());
        }
    }

    /** Copy a workbook from the shared folder into the workspace. */
    @PostMapping(value = "/sources/fetch", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> sourcesFetch(@RequestParam String type, @RequestParam String path)
            throws IOException {
        if (!"folder".equals(type)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Source type '" + type + "' is not configured on this server");
        }
        String configured = settings.raw("src.folder.path");
        Path source = Path.of(path).toAbsolutePath().normalize();
        if (configured.isBlank()
                || !source.startsWith(Path.of(configured).toAbsolutePath().normalize())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Path is outside the configured shared folder");
        }
        try (InputStream in = Files.newInputStream(source)) {
            var saved = workspace.save("workbooks", source.getFileName().toString(), in);
            workspace.audit(null, "fetch", saved.path() + " <- " + source);
            return Map.of("saved", saved.path(), "bytes", saved.size());
        }
    }

    /**
     * Look for OneDrive / SharePoint folders that have been synced to this
     * machine, so the user can pick one instead of typing a path. Synced
     * libraries appear as ordinary folders under the user's home — commonly
     * "OneDrive", "OneDrive - <Company>", or a company-named folder holding
     * synced document libraries. This lists those top-level candidates; the
     * user picks one and can then drill in by editing the path.
     */
    @GetMapping("/sources/discover")
    public Map<String, Object> discover() {
        List<Map<String, String>> found = new java.util.ArrayList<>();
        String home = System.getProperty("user.home", "");
        if (!home.isBlank()) {
            Path homePath = Path.of(home);
            try (var top = Files.list(homePath)) {
                top.filter(Files::isDirectory)
                   .filter(p -> {
                       String n = p.getFileName().toString();
                       return n.startsWith("OneDrive")           // personal + business
                               || n.contains("SharePoint")
                               || n.toLowerCase().contains("- ");  // "Company - Documents" style
                   })
                   .forEach(p -> found.add(Map.of(
                           "name", p.getFileName().toString(),
                           "path", p.toString())));
            } catch (IOException ignored) {
                // Home not listable — just return nothing found.
            }
        }
        return Map.of("items", found);
    }

    // ── assistant endpoints the GUI probes; not wired on this server ─────

    @GetMapping("/ai/config")
    public Map<String, Object> aiConfig() {
        return Map.of("configured", false, "urlSet", false, "summary", "", "responsePath", "");
    }

    @PostMapping("/ai/ask")
    public Map<String, Object> aiAsk() {
        return Map.of("error", "The assistant is not configured on this server.");
    }
}
