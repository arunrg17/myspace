package com.apitest.server.service;

import com.apitest.excel.ExcelLoader;
import com.apitest.model.Step;
import com.apitest.model.TestCase;
import com.apitest.model.TestResult;
import com.apitest.model.TestSuite;
import com.apitest.reporter.JsonReport;
import com.apitest.reporter.Reporter;
import com.apitest.runner.RunConfig;
import com.apitest.runner.Runner;
import com.apitest.template.TemplateEngine;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Engine capabilities exposed for the GUI to call directly, in-process.
 *
 * <p>These are the read-only and single-shot operations that used to require
 * running the whole jar: checking a workbook parses, seeing what a request will
 * look like once placeholders resolve, running one test in isolation, and
 * turning a stored results file back into its HTML report. None of them send
 * traffic except {@link #runSingle}, which runs exactly one test.
 */
public class EngineService {

    private final WorkspaceService workspace;

    public EngineService(WorkspaceService workspace) {
        this.workspace = workspace;
    }

    // ── validate / parse ─────────────────────────────────────────────────

    /** A structural check of a workbook: does it parse, and what is in it. */
    public Map<String, Object> validate(String workbookRel) throws IOException {
        Path workbook = workspace.fileForDownload("workbooks", workbookRel);
        Map<String, Object> out = new LinkedHashMap<>();
        try {
            TestSuite suite = ExcelLoader.load(workbook);
            out.put("ok", true);
            out.put("environments", new ArrayList<>(suite.environments().keySet()));

            List<Map<String, Object>> tests = new ArrayList<>();
            List<String> problems = new ArrayList<>();
            for (TestCase tc : suite.tests()) {
                Map<String, Object> t = new LinkedHashMap<>();
                t.put("testId", tc.testId);
                t.put("name", tc.name);
                t.put("mode", tc.comparisonMode);
                t.put("enabled", tc.enabled);
                t.put("steps", tc.steps.size());
                t.put("assertions", tc.assertions == null ? 0 : tc.assertions.size());
                tests.add(t);

                // Surface the mistakes that only show up at run time otherwise.
                if (tc.sourceA != null && !tc.sourceA.isBlank()
                        && !suite.environments().containsKey(tc.sourceA)) {
                    problems.add(tc.testId + ": SourceA '" + tc.sourceA + "' is not defined");
                }
                boolean needsB = "vs_env".equals(tc.comparisonMode)
                        || "vs_protocol".equals(tc.comparisonMode);
                if (needsB) {
                    if (tc.sourceB == null || tc.sourceB.isBlank()) {
                        problems.add(tc.testId + ": " + tc.comparisonMode + " needs a SourceB");
                    } else if (!suite.environments().containsKey(tc.sourceB)) {
                        problems.add(tc.testId + ": SourceB '" + tc.sourceB + "' is not defined");
                    }
                }
                if ("vs_expected".equals(tc.comparisonMode)
                        && (tc.expectedFile == null || tc.expectedFile.isBlank())) {
                    problems.add(tc.testId + ": vs_expected needs an ExpectedFile");
                }
                if (tc.steps.isEmpty()) {
                    problems.add(tc.testId + ": has no steps");
                }
            }
            out.put("tests", tests);
            out.put("problems", problems);
        } catch (Exception e) {
            out.put("ok", false);
            out.put("error", e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
        }
        return out;
    }

    // ── preview a resolved request ───────────────────────────────────────

    /**
     * Show what a step's endpoint and body look like once placeholders resolve,
     * without sending anything. Step variables from earlier steps are not known
     * outside a run, so only TestData values and the always-available tokens
     * ({@code now}, {@code uuid}, {@code env.*}) resolve; unresolved ones are
     * shown as they stand.
     */
    public Map<String, Object> preview(String workbookRel, String testId, String source)
            throws IOException {
        Path workbook = workspace.fileForDownload("workbooks", workbookRel);
        String src = "B".equalsIgnoreCase(source) ? "B" : "A";

        TestSuite suite;
        try {
            suite = ExcelLoader.load(workbook);
        } catch (Exception e) {
            return Map.of("ok", false, "error", "Workbook did not parse: " + e.getMessage());
        }

        TestCase tc = suite.tests().stream()
                .filter(t -> t.testId.equals(testId)).findFirst().orElse(null);
        if (tc == null) return Map.of("ok", false, "error", "No test '" + testId + "'");

        Map<String, String> data = tc.data == null ? Map.of() : tc.data;
        Map<Integer, Map<String, String>> noStepVars = Map.of();

        List<Map<String, Object>> steps = new ArrayList<>();
        for (Step step : tc.steps) {
            Map<String, Object> s = new LinkedHashMap<>();
            s.put("order", step.order());
            s.put("name", step.name());
            s.put("method", step.methodFor(src));

            String endpoint = TemplateEngine.render(step.endpointFor(src), data, noStepVars);
            s.put("endpoint", endpoint);

            String templateRef = step.bodyTemplateFor(src);
            if (templateRef != null && !templateRef.isBlank()) {
                try {
                    String body = TemplateEngine.renderFile(templateRef, data, noStepVars,
                            workspace.area("templates"), workspace.root(),
                            new TemplateEngine.RenderLog());
                    s.put("body", body);
                } catch (Exception e) {
                    s.put("bodyError", "Template '" + templateRef + "': " + e.getMessage());
                }
            }
            s.put("expectedStatus", step.expectedStatus());
            steps.add(s);
        }

        return Map.of("ok", true, "testId", testId, "source", src, "steps", steps,
                "note", "Step variables resolve only during a run, so ${stepN.*} may appear unresolved here.");
    }

    // ── run a single test ────────────────────────────────────────────────

    /** Run exactly one test from a workbook and return its result envelope. */
    public JsonReport.Envelope runSingle(String workbookRel, String testId) throws Exception {
        Path workbook = workspace.fileForDownload("workbooks", workbookRel);
        TestSuite suite = ExcelLoader.load(workbook);
        TestCase tc = suite.tests().stream()
                .filter(t -> t.testId.equals(testId)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No test '" + testId + "'"));

        Path outputRoot = Files.createTempDirectory("apitest-single-");
        try {
            RunConfig cfg = new RunConfig(workbook, outputRoot.resolve("report.html"),
                    workspace.root(), workspace.area("templates"),
                    workspace.area("expected"), outputRoot, "Single test " + testId);
            TestResult result = Runner.runTest(tc, suite, cfg, outputRoot);
            return JsonReport.envelope(List.of(result), "Single test " + testId);
        } finally {
            deleteQuietly(outputRoot);
        }
    }

    // ── render a report from stored JSON ─────────────────────────────────

    /** Regenerate the HTML report from a results envelope supplied as JSON. */
    public String renderFromJson(String json) throws IOException {
        JsonReport.Envelope env = JsonReport.fromJson(json);
        return Reporter.renderHtml(env.results, env.suiteName);
    }

    private static void deleteQuietly(Path dir) {
        try (var walk = Files.walk(dir)) {
            walk.sorted(java.util.Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (IOException ignored) { }
            });
        } catch (IOException ignored) { }
    }
}
