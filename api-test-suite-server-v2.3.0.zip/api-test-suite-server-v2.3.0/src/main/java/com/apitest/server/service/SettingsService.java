package com.apitest.server.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * Key-value settings persisted in the workspace, shared by every user of the
 * GUI. Secret-ish values are stored but never echoed back — the GUI receives a
 * marker instead, matching what it already expects.
 */
public class SettingsService {

    private static final Set<String> MASKED = Set.of("src.git.token");
    private static final String MASK = "__saved__";

    private final Path file;

    public SettingsService(WorkspaceService workspace) {
        this.file = workspace.area("config").resolve("server-settings.properties");
    }

    public synchronized Map<String, String> forDisplay() throws IOException {
        Map<String, String> out = new LinkedHashMap<>();
        Properties props = load();
        for (String key : props.stringPropertyNames()) {
            String value = props.getProperty(key, "");
            out.put(key, MASKED.contains(key) && !value.isEmpty() ? MASK : value);
        }
        return out;
    }

    public synchronized String raw(String key) throws IOException {
        return load().getProperty(key, "");
    }

    /** A boolean setting, defaulting when unset or unparseable. */
    public synchronized boolean getBool(String key, boolean fallback) {
        try {
            String v = load().getProperty(key, "");
            return v.isBlank() ? fallback : Boolean.parseBoolean(v.trim());
        } catch (IOException e) {
            return fallback;
        }
    }

    /** An integer setting, defaulting when unset or unparseable. */
    public synchronized int getInt(String key, int fallback) {
        try {
            String v = load().getProperty(key, "");
            return v.isBlank() ? fallback : Integer.parseInt(v.trim());
        } catch (IOException | NumberFormatException e) {
            return fallback;
        }
    }

    public synchronized void save(Map<String, String> updates) throws IOException {
        Properties props = load();
        for (Map.Entry<String, String> e : updates.entrySet()) {
            // The GUI sends the mask back for untouched secrets; keep the
            // stored value in that case.
            if (MASK.equals(e.getValue())) continue;
            if (e.getValue() == null || e.getValue().isBlank()) {
                props.remove(e.getKey());
            } else {
                props.setProperty(e.getKey(), e.getValue());
            }
        }
        try (var out = Files.newOutputStream(file)) {
            props.store(out, "api-test-suite server settings");
        }
    }

    private Properties load() throws IOException {
        Properties props = new Properties();
        if (Files.isRegularFile(file)) {
            try (var in = Files.newInputStream(file)) {
                props.load(in);
            }
        }
        return props;
    }
}
