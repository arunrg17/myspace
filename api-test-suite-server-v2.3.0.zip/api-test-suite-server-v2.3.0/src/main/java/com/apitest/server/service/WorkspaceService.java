package com.apitest.server.service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Stream;

/**
 * All access to the shared workspace — the mounted pod volume every user of the
 * GUI works against.
 *
 * <p>Layout under the configured root:
 *
 * <pre>
 *   workbooks/   uploaded Excel suites
 *   templates/   request body templates
 *   expected/    baseline files for vs_expected
 *   runs/        one folder per run: workbook copy, report.json, console.log
 *   config/      server settings, audit log
 *   engine/      the runner jar
 * </pre>
 *
 * <p>Every path from the outside is resolved through {@link #resolve}, which
 * confines it to its area. The GUI lets anyone browse and upload, so a request
 * must never be able to name a file outside the workspace — the same rule the
 * engine applies to workbook-supplied paths.
 */
public class WorkspaceService {

    /** The browsable areas, in the order the GUI shows them. */
    public static final Set<String> AREAS = Set.of("workbooks", "templates", "expected", "runs");

    private static final Set<String> WORKBOOK_EXT = Set.of("xlsx", "xlsm");

    private final Path root;

    public WorkspaceService(Path root) throws IOException {
        this.root = root.toAbsolutePath().normalize();
        for (String area : AREAS) Files.createDirectories(this.root.resolve(area));
        Files.createDirectories(this.root.resolve("config"));
        Files.createDirectories(this.root.resolve("engine"));
    }

    public Path root() {
        return root;
    }

    public Path area(String name) {
        if (!AREAS.contains(name) && !"config".equals(name) && !"engine".equals(name)) {
            throw new IllegalArgumentException("Unknown workspace area: " + name);
        }
        return root.resolve(name);
    }

    /**
     * Resolve a user-supplied relative path inside an area, refusing anything
     * that escapes it.
     */
    public Path resolve(String areaName, String relative) {
        Path base = area(areaName);
        if (relative == null || relative.isBlank()) return base;
        Path candidate = base.resolve(relative).normalize();
        if (!candidate.startsWith(base)) {
            throw new IllegalArgumentException(
                    "Path escapes the " + areaName + " area: " + relative);
        }
        return candidate;
    }

    /** One entry in a directory listing. */
    public record Entry(String name, String path, boolean directory, long size, String modified) {}

    /** List an area (or a folder inside it), directories first, newest files first. */
    public List<Entry> list(String areaName, String relative) throws IOException {
        Path dir = resolve(areaName, relative);
        if (!Files.isDirectory(dir)) return List.of();
        List<Entry> out = new ArrayList<>();
        try (Stream<Path> children = Files.list(dir)) {
            for (Path p : children.sorted().toList()) {
                boolean isDir = Files.isDirectory(p);
                out.add(new Entry(
                        p.getFileName().toString(),
                        area(areaName).relativize(p).toString().replace('\\', '/'),
                        isDir,
                        isDir ? 0 : Files.size(p),
                        Files.getLastModifiedTime(p).toInstant().toString()));
            }
        }
        out.sort(Comparator.comparing((Entry e) -> !e.directory())
                .thenComparing(Entry::modified, Comparator.reverseOrder()));
        return out;
    }

    /** Save an upload into an area. Returns the stored relative path. */
    public Entry save(String areaName, String filename, InputStream body) throws IOException {
        String clean = sanitizeFilename(filename);
        if ("workbooks".equals(areaName) && !WORKBOOK_EXT.contains(extension(clean))) {
            throw new IllegalArgumentException(
                    "Only .xlsx/.xlsm files belong in workbooks (got '" + clean + "')");
        }
        Path target = resolve(areaName, clean);
        Files.createDirectories(target.getParent());
        Files.copy(body, target, StandardCopyOption.REPLACE_EXISTING);
        return new Entry(clean, clean, false, Files.size(target),
                Files.getLastModifiedTime(target).toInstant().toString());
    }

    public Path fileForDownload(String areaName, String relative) throws IOException {
        Path p = resolve(areaName, relative);
        if (!Files.isRegularFile(p)) throw new IOException("Not found: " + relative);
        return p;
    }

    /** Delete a file (not a directory — runs are removed through RunService). */
    public void delete(String areaName, String relative) throws IOException {
        Path p = resolve(areaName, relative);
        if (Files.isDirectory(p)) {
            throw new IllegalArgumentException("Refusing to delete a directory: " + relative);
        }
        Files.deleteIfExists(p);
    }

    /** Workbooks available to run, newest first. */
    public List<Entry> workbooks() throws IOException {
        return list("workbooks", "").stream()
                .filter(e -> !e.directory() && WORKBOOK_EXT.contains(extension(e.name())))
                .toList();
    }

    /**
     * Append one line to the audit log. Uploads, deletions and runs all leave a
     * trace, which is the level of check-in/check-out a shared folder needs
     * before someone asks for full version control.
     */
    public synchronized void audit(String user, String action, String detail) {
        String line = Instant.now() + "\t" + (user == null || user.isBlank() ? "-" : user)
                + "\t" + action + "\t" + detail + System.lineSeparator();
        try {
            Files.writeString(root.resolve("config/audit.log"), line,
                    java.nio.file.StandardOpenOption.CREATE,
                    java.nio.file.StandardOpenOption.APPEND);
        } catch (IOException ignored) {
            // The audit log must never take the workspace down with it.
        }
    }

    static String sanitizeFilename(String filename) {
        if (filename == null || filename.isBlank()) {
            throw new IllegalArgumentException("A filename is required");
        }
        // Keep only the final segment, whatever the client sent.
        String name = filename.replace('\\', '/');
        name = name.substring(name.lastIndexOf('/') + 1).trim();
        if (name.isEmpty() || name.equals(".") || name.equals("..")) {
            throw new IllegalArgumentException("Not a usable filename: " + filename);
        }
        return name;
    }

    public static String extension(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }
}
