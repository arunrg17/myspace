Copy workspace-seed/config/* into your APITEST_WORKSPACE volume before first run (optional). Engine is bundled.
