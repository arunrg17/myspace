# API Test Suite — Server

Single Spring Boot application for the Excel-driven API test suite. It serves the
React GUI, manages the shared workspace on a mounted volume, and runs suites
**in-process** — the test engine is bundled into this app, not a separate jar.
Results are stored as JSON, and the identical HTML report is regenerated on
demand whenever someone opens one.

## How it fits together

```
Browser (React GUI)
   │  /api/...
   ▼
Spring Boot app (this module, stateless)
   │  engine bundled in — runs execute in-process, one thread per run
   ▼
Workspace on the mounted volume        ← the only state
```

The app keeps nothing locally. Everything lives under one configured root —
the pod's mounted volume — so the pod can be restarted or rescheduled freely,
and several replicas can share the same volume. There is no engine jar to place
on the volume: the engine is part of this application.

## The workspace

```
${apitest.workspace}/          e.g. /data/apitest (the volume mount)
├── workbooks/                 uploaded Excel suites
├── templates/                 request body templates
├── expected/                  baseline files for vs_expected
├── runs/                      one folder per run (see below)
└── config/                    server-settings.properties, audit.log,
                               test_suite_template.xlsx
```

(An `engine/` folder is no longer needed — the engine runs in-process.)

Each run folder holds a frozen copy of the workbook that ran, `console.log`,
`meta.properties`, and `report.json` — the run's full results as data. **Only
the JSON is stored.** The HTML report is regenerated from it at
`/api/reports/{runId}/html` each time it is opened, byte-identical to what the
engine would have written, at a fraction of the storage (the HTML inlines all
of its CSS and JS into every copy; the JSON is typically 10–50 kB per run).

Uploads, deletions, fetches and runs are appended to `config/audit.log` with a
timestamp and, when the client sends an `X-User` header, the user.

## Configuration

| Property | Environment variable | Default | Meaning |
|---|---|---|---|
| `apitest.workspace` | `APITEST_WORKSPACE` | `./workspace` | Root of the shared workspace |
| `server.port` | `SERVER_PORT` | `8080` | HTTP port |

## Running it

```bash
# build (engine first, so the app bundles it from the local repository)
cd api-test-suite        && mvn install
cd ../api-test-suite-server && mvn package

# run
java -jar target/api-test-suite-server-2.0.0.jar \
     --apitest.workspace=/data/apitest
```

The engine is bundled into the application jar — there is nothing extra to place
on the volume.

### On the pod

Mount the volume and point the workspace at it:

```yaml
env:
  - name: APITEST_WORKSPACE
    value: /data/apitest
volumeMounts:
  - name: apitest-data
    mountPath: /data/apitest
```

Health endpoint for probes: `GET /api/context` returns 200 once the workspace
is ready.

### Serving the GUI

Build the frontend and copy it into the server's static resources before
packaging:

```bash
cd api-test-suite-web && npm install && npm run build
cp -r dist/* ../api-test-suite-server/src/main/resources/static/
```

During frontend development, `vite` proxies `/api` to `localhost:8080` instead.

## API

| Endpoint | What it does |
|---|---|
| `GET /api/context` | Workspace paths, engine presence and version, available workbooks |
| `GET/POST/DELETE /api/files?area=&path=` | Browse, upload (`X-Filename` header), delete within an area |
| `GET /api/files/download?area=&path=` | Download a file |
| `POST /api/run` | Start a run (`workbook`, `name`, `save`) → `{ runId }`. `save=false` for a dry run |
| `GET /api/template` | Download the starter workbook (config/test_suite_template.xlsx) |
| `GET /api/template/available` | Whether a template is installed (drives the GUI button) |
| `GET /api/stream?runId=` | SSE: `line` events (with replay), one `done` event with the summary |
| `POST /api/cancel` | Stop a running suite |
| `GET /api/history` | Stored runs, newest first, from the JSON summaries |
| `GET /api/results?report=` | Per-test outcomes for one run |
| `GET /api/reports/{runId}/html` | The report, regenerated from stored JSON |
| `GET /api/reports/{runId}/json` | The stored JSON itself, for tooling |
| `GET /api/validate?workbook=` | Structural check: does the workbook parse, what is in it, problems found — no traffic sent |
| `GET /api/preview?workbook=&testId=&source=` | A test's resolved endpoint and body after placeholders, without sending |
| `POST /api/run-single` | Run exactly one test (`workbook`, `testId`) |
| `POST /api/render` | Render report HTML from a results JSON posted in the body |
| `GET /api/reports/{runId}/html?download=true` | Download the self-contained HTML report (works offline) |
| `GET /api/active` | Run ids executing now, so a returning browser can re-attach |
| `GET /api/trends` | Recurring failures across recent runs |
| `GET/POST /api/settings` | Shared settings; secret values are masked in responses |
| `GET /api/sources/list`, `POST /api/sources/fetch` | Browse a configured shared folder and copy a workbook in |

Every path parameter is confined to its workspace area — `../` escapes are
refused, upload filenames are reduced to their final segment, and the
workbooks area accepts only `.xlsx`/`.xlsm`. The same containment rule the
engine applies to workbook-supplied paths.

## First-time template

Place `test_suite_template.xlsx` in the workspace `config/` folder. The GUI then
shows a "Download blank template" button on the run screen, and the six-sheet
template — headers and example rows already filled — is served from
`/api/template`. A team can drop in its own house template and everyone
downloads that one.

## Result storage

Each run's results are stored as JSON under `runs/<id>/`. For large suites with
big request/response bodies these files can grow; three options under
**Settings → Result storage** trade a little readability for much smaller
storage, applied to new runs:

- **Drop duplicate normalised payloads** — the comparator keeps a second,
  normalised copy of each payload for diffing; dropping it roughly halves size
  with no loss of the actual request or response (~50% smaller).
- **Truncate very large bodies** — caps each stored body with a note showing how
  much was clipped.
- **Compress stored results (gzip)** — stores `report.json.gz`; keeps all data,
  typically 90%+ smaller, read back automatically.

Reading transparently handles either a plain or gzipped file, so turning the
options on or off never strands older runs.

## Dry runs (not saving to the volume)

The run screen has a "Save results and logs to the server" toggle. With it on,
the run is kept under `runs/` and appears in history. With it off, the run
executes in a temporary folder that is deleted when it finishes — the report and
console still stream to the browser, but nothing lands on the volume. This is
for the dry runs done while automating a new service, which would otherwise fill
the volume with results nobody keeps.

## Build note

The service layer (`service/`) has no Spring dependency and carries its own
tests; the web layer (`web/`) is a thin adapter over it. If your build
environment restricts Maven Central, mirror `spring-boot-starter-web` and
`spring-boot-starter-test` through your Artifactory — those two are the only
external dependencies.
