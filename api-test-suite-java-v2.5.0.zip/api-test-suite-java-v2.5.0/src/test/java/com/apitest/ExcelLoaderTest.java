package com.apitest;

import com.apitest.excel.ExcelLoader;
import com.apitest.excel.TemplateGenerator;
import com.apitest.model.TestCase;
import com.apitest.model.TestSuite;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

class ExcelLoaderTest {

    /** Check if the full POI runtime is available (not just stubs). */
    private static boolean poiAvailable() {
        try {
            Class.forName("org.apache.poi.xssf.usermodel.XSSFWorkbook")
                    .getConstructor().newInstance();
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    @Test
    void generateAndLoadRoundTrip(@TempDir Path tmp) throws Exception {
        assumeTrue(poiAvailable(), "Full POI runtime required (skipped in sandbox)");
        Path xlsx = tmp.resolve("test_suite.xlsx");
        TemplateGenerator.generate(xlsx);
        assertTrue(java.nio.file.Files.exists(xlsx));

        TestSuite suite = ExcelLoader.load(xlsx);

        // Environments
        assertTrue(suite.environments().containsKey("DEV_REST"));
        assertTrue(suite.environments().containsKey("DEV_SOAP"));
        assertTrue(suite.environments().containsKey("APIGEE_DEV"));
        assertEquals("rest", suite.environments().get("DEV_REST").protocol());
        assertEquals("apigee", suite.environments().get("APIGEE_DEV").protocol());

        // Tests — Enabled=Y rows only (T011, T012 are disabled)
        assertTrue(suite.tests().size() >= 8);

        // T003 = vs_expected with 1 step
        TestCase t003 = suite.tests().stream()
                .filter(t -> "T003".equals(t.testId))
                .findFirst().orElseThrow();
        assertEquals("vs_expected", t003.comparisonMode);
        assertEquals(1, t003.steps.size());

        // T007 = chain with 4 steps (create, update, verify, delete)
        TestCase t007 = suite.tests().stream()
                .filter(t -> "T007".equals(t.testId))
                .findFirst().orElseThrow();
        assertEquals("chain", t007.comparisonMode);
        assertEquals(4, t007.steps.size());
        assertEquals(1, t007.steps.get(0).order());
        assertEquals(4, t007.steps.get(3).order());

        // T006 has field-level assertions
        TestCase t006 = suite.tests().stream()
                .filter(t -> "T006".equals(t.testId))
                .findFirst().orElseThrow();
        assertTrue(t006.assertions.size() >= 5,
                "T006 should have its own assertions plus the global '*' ignores");

        // Global * assertions are applied to all tests
        TestCase t001 = suite.tests().stream()
                .filter(t -> "T001".equals(t.testId))
                .findFirst().orElseThrow();
        boolean t001HasGlobalIgnore = t001.assertions.stream()
                .anyMatch(a -> "ignore".equals(a.operator()) && a.path().contains("traceId"));
        assertTrue(t001HasGlobalIgnore, "Global * ignores should propagate to T001");

        // T011 (Enabled=N) should be skipped
        boolean t011Present = suite.tests().stream().anyMatch(t -> "T011".equals(t.testId));
        assertFalse(t011Present, "Disabled tests should not be loaded");

        // T008 has per-step ExtraHeaders (dynamic token flow)
        TestCase t008 = suite.tests().stream()
                .filter(t -> "T008".equals(t.testId))
                .findFirst().orElseThrow();
        assertEquals(2, t008.steps.size());
        // Step 1 should have Content-Type header
        assertFalse(t008.steps.get(0).extraHeaders().isEmpty(),
                "Token fetch step should have ExtraHeaders");
        // Step 2 should have Authorization header
        assertTrue(t008.steps.get(1).extraHeaders().containsKey("Authorization"),
                "Protected API step should have Authorization header");
    }
}
