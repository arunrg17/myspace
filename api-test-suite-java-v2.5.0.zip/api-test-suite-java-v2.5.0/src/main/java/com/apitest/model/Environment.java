package com.apitest.model;

import java.util.Map;

/**
 * A named environment (DEV, UAT, PROD, etc.).
 *
 * <p>For environments that require a dynamic auth token (OAuth, Glue, etc.),
 * fill in {@code tokenUrl} and {@code tokenBody}. Before any test step runs,
 * the runner will POST to {@code tokenUrl} with {@code tokenBody} as
 * {@code application/x-www-form-urlencoded}, extract the {@code access_token}
 * from the JSON response, and inject it as the {@code Authorization: Bearer}
 * header automatically. No template file needed.
 *
 * <p>Example Environments sheet row:
 * <pre>
 *   TokenURL:  https://auth.example.com/oauth/token
 *   TokenBody: grant_type=client_credentials&amp;client_id=${env.CID}&amp;client_secret=${env.CSEC}
 * </pre>
 */
public record Environment(
        String name,
        String protocol,
        String baseUrl,
        String authType,
        String authValue,
        Map<String, String> extraHeaders,
        String sslConfig,
        String tokenUrl,
        String tokenBody
) {
    /** Backward-compatible constructor — no token and no SSL. */
    public Environment(String name, String protocol, String baseUrl,
                       String authType, String authValue, Map<String, String> extraHeaders) {
        this(name, protocol, baseUrl, authType, authValue, extraHeaders, "", "", "");
    }

    /** Backward-compatible constructor — no token fields. */
    public Environment(String name, String protocol, String baseUrl,
                       String authType, String authValue, Map<String, String> extraHeaders,
                       String sslConfig) {
        this(name, protocol, baseUrl, authType, authValue, extraHeaders, sslConfig, "", "");
    }
}
