@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RTCC - diagnostic
set "LOG=%~dp0RTCC-diagnostic.txt"

echo RTCC diagnostic> "%LOG%"
echo %date% %time%>> "%LOG%"

echo ============================================================
echo   RTCC diagnostic - copy everything below if you need help
echo ============================================================
echo.
echo Folder          : %~dp0
echo Folder: %~dp0>> "%LOG%"
echo Windows         : %OS%  %PROCESSOR_ARCHITECTURE%
echo Windows: %OS% %PROCESSOR_ARCHITECTURE%>> "%LOG%"
echo User            : %USERNAME%
echo.

echo --- Files in this folder ---
dir /b
echo --- Files --->> "%LOG%"
dir /b>> "%LOG%"
echo.

if exist "%~dp0RTCC.jar" echo RTCC.jar        : FOUND
if not exist "%~dp0RTCC.jar" echo RTCC.jar        : MISSING
if exist "%~dp0RTCC.jar" echo RTCC.jar: FOUND>> "%LOG%"
if not exist "%~dp0RTCC.jar" echo RTCC.jar: MISSING>> "%LOG%"

if exist "%~dp0jre\bin\java.exe" echo Bundled Java    : FOUND
if not exist "%~dp0jre\bin\java.exe" echo Bundled Java    : MISSING
if exist "%~dp0jre\bin\java.exe" echo Bundled Java: FOUND>> "%LOG%"
if not exist "%~dp0jre\bin\java.exe" echo Bundled Java: MISSING>> "%LOG%"

where java.exe >nul 2>&1
if errorlevel 1 echo System Java     : not on PATH
if not errorlevel 1 echo System Java     : on PATH
echo.

set "JAVA_EXE=%~dp0jre\bin\java.exe"
if exist "%JAVA_EXE%" goto :ver
set "JAVA_EXE=java"

:ver
echo --- Java version ---
"%JAVA_EXE%" -version 2>&1
"%JAVA_EXE%" -version >> "%LOG%" 2>&1
echo.

echo --- Starting RTCC ---
echo Any error appears below. Close RTCC to return here.
echo.
"%JAVA_EXE%" -jar "%~dp0RTCC.jar" 2>&1
echo.
echo RTCC exited with code %errorlevel%.
echo Exit code: %errorlevel%>> "%LOG%"
echo.
echo A copy of this report was saved to RTCC-diagnostic.txt
echo.
pause
