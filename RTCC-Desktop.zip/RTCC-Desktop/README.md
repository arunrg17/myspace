# RTCC — Requirement-to-Test Case Compiler (Desktop)

Turns written requirements into executable test cases. Runs entirely on your
machine — nothing is sent anywhere.

## Run it

**Windows** — double-click **`RTCC.bat`**

**macOS / Linux** — `./RTCC.sh` (or `java -jar RTCC.jar`)

Java 11 or newer is required. If the launcher reports Java is missing, install
Temurin JRE 21 from https://adoptium.net and run it again.

## If RTCC.bat does not start

Run **`RTCC-debug.bat`** instead. It keeps the window open and prints exactly
what is wrong — missing jar, missing Java, or a Java error.

Common causes:

| Symptom | Cause | Fix |
|---|---|---|
| Nothing at all happens | The .bat was opened from inside the .zip | Extract the zip to a real folder first |
| Window flashes and closes | `RTCC.jar` is not beside the .bat | Keep `RTCC.bat` and `RTCC.jar` in the same folder |
| "Java was not found" | No Java, or not on PATH | Install Temurin JRE 21 from https://adoptium.net |
| Java is installed but not found | PATH not set for your account | `setx JAVA_HOME "C:\Program Files\Eclipse Adoptium\jre-21"` then reopen |

`RTCC.bat` uses `javaw`, so the app starts with no console window behind it. It
looks for Java on the PATH, then `JAVA_HOME`, then the usual install folders
under `Program Files`.

## Using it

1. **Requirement documents** — type or paste requirements, one rule per line.
   *Add* creates another document, *Load file* imports `.txt` / `.md` / `.csv`.
   Each document is tracked separately, so every test case records where it came from.
2. **Flow diagram** *(optional)* — the steps of a user journey. This drives the
   end-to-end case. If the documents are left empty, the flow text is parsed as
   requirements rather than ignored.
3. **Generation settings** — pick test types, detail level and a cap.
4. **Generate test cases** — results fill the table; click a row for the full case.
5. **Export** — `.xlsx`, CSV, JSON, Markdown, plain text, or copy to clipboard.

## What the engine does

Each requirement is parsed into structure — actor, action, permitted vs
prohibited, and its constraints — and cases are written from that structure.
It is not template-filling: the wording of a case reflects what was understood.

| Constraint | Example wording | Cases produced |
|---|---|---|
| Time window | "login before 9 am and after 6 pm" | in-window, out-of-window, minute-exact boundary |
| Minimum / maximum | "minimum order is 10 euros" | passing value, failing value, inclusive boundary |
| Field length | "password minimum 8 characters" | accepted length, boundary pair |
| Attempt lockout | "locked after 3 failed attempts" | lock at N, no lock at N-1 |
| Response time | "must respond within 500 ms" | 95th-percentile load check |
| Displayed message | "a thank you msg is displayed" | shown on success, *not* shown on failure |
| Exclusivity | "only German customers ... not others" | denial case, server-side bypass check |
| Prohibition | "non-German users cannot login" | denial case with audit-log check |

Common typos are tolerated (`minus`, `minimun`, `mininum`, `maximun`, `atleast`).
Conditions such as "only **when** the minimum is reached" are read as conditions,
not as user groups.

Integration cases appear only when a requirement genuinely spans components
(API, service, queue, database, webhook). Regression is treated as a suite-level
concern: at most two, aimed at the sharpest cases.

## Project layout

```
src/com/rtcc/
  Main.java                 entry point
  model/                    TestCase, ReqDoc, Requirement, Constraint
  engine/
    Analyzer.java           statement splitting, actor/action/modality
    Constraints.java        rule extraction
    TestBuilder.java        writes the cases
    Engine.java             orchestration, interleaving, capping
    Verbs.java              verb normalisation
  export/Exporters.java     xlsx, csv, json, markdown, text
  ui/                       MainWindow, Theme, TypeChip
```

## Rebuilding

Needs a JDK (not just a JRE).

**Windows** — `build.bat`   **macOS / Linux** — `./build.sh`

No external dependencies: plain Java SE and Swing. The `.xlsx` writer is built
on `java.util.zip`, so there is no Apache POI to manage.

## Note on Excel files

Export produces a real `.xlsx` (OOXML). Earlier builds wrote an HTML table named
`.xls`, which is what made Excel report a corrupt file — that is fixed. The sheet
opens with a frozen header row and autofilter enabled.
