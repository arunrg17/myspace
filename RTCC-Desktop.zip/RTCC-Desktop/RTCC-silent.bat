@echo off
REM Starts RTCC with no console window. Use this once RTCC.bat works.
setlocal EnableExtensions
cd /d "%~dp0"
set "JAVAW=%~dp0jre\bin\javaw.exe"
if exist "%JAVAW%" goto :go
set "JAVAW=javaw"
:go
start "RTCC" "%JAVAW%" -jar "%~dp0RTCC.jar"
exit /b 0
