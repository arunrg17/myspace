#!/usr/bin/env bash
# Rebuild RTCC.jar from source. Requires a JDK 11+.
set -e
cd "$(dirname "$0")"
rm -rf build/classes && mkdir -p build/classes
find src -name "*.java" > build/sources.txt
javac -d build/classes --release 11 -encoding UTF-8 @build/sources.txt
jar --create --file RTCC.jar --main-class com.rtcc.Main -C build/classes .
echo "Done. Run ./RTCC.sh"
