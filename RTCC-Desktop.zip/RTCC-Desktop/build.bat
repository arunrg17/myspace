@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RTCC - build from source

REM Rebuild RTCC.jar from source. Requires a JDK (not just a JRE).

where javac.exe >nul 2>&1
if errorlevel 1 (
    echo.
    echo   [ERROR] javac was not found.
    echo   Building needs a JDK, not just a JRE.
    echo   Install Temurin JDK 21 from https://adoptium.net
    echo.
    pause
    exit /b 1
)

echo Compiling...
if exist build\classes rmdir /s /q build\classes
mkdir build\classes
dir /s /b src\*.java > build\sources.txt
javac -d build\classes --release 11 -encoding UTF-8 @build\sources.txt
if errorlevel 1 (
    echo.
    echo   [ERROR] Compilation failed - see the messages above.
    pause
    exit /b 1
)

echo Packaging RTCC.jar...
jar --create --file RTCC.jar --main-class com.rtcc.Main -C build\classes .
if errorlevel 1 (
    echo.
    echo   [ERROR] Packaging failed.
    pause
    exit /b 1
)

echo.
echo Build complete. Double-click RTCC.bat to run.
pause
