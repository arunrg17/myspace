package com.rtcc;

import com.rtcc.ui.MainWindow;

import javax.swing.*;

/** Application entry point. */
public class Main {
    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) { }
            new MainWindow().setVisible(true);
        });
    }
}
