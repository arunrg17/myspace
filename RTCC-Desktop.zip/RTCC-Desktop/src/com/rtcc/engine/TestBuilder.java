package com.rtcc.engine;

import com.rtcc.model.Constraint;
import com.rtcc.model.Requirement;
import com.rtcc.model.TestCase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.rtcc.engine.Analyzer.*;

/** Writes executable test cases from an analysed requirement. */
final class TestBuilder {

    private TestBuilder() {}

    static List<TestCase> build(Requirement r, List<String> want, String app) {
        List<TestCase> out = new ArrayList<>();
        String actor = r.actor != null ? r.actor : "the user";
        String act = r.action != null ? r.action : "perform the action described in " + r.id;

        Constraint tw    = r.find("time-window");
        Constraint money = r.find("money") != null ? r.find("money")
                         : (r.find("count") != null ? r.find("count") : r.find("threshold"));
        Constraint len   = r.find("length");
        Constraint lock  = r.find("lockout");
        Constraint sla   = r.find("sla");
        Constraint disp  = r.find("display");
        Constraint excl  = r.find("exclusive");

        // ── TIME WINDOW ──
        if (tw != null) {
            if (want.contains("Functional")) {
                for (int i = 0; i < tw.allowed.size(); i++) {
                    int[] seg = tw.allowed.get(i);
                    String label = tw.allowedLabels.get(i);
                    String sample = fmtTime(seg[0] == 0 ? Math.max(0, seg[1] - 59) : Math.min(seg[1], seg[0] + 59));
                    out.add(tc("Functional", cap(actor) + " can " + act + " " + label,
                        "System clock: " + sample + " (local time)",
                        Arrays.asList(
                            "Set the test environment clock to " + sample + " local time.",
                            "Open " + app + " as " + actor + " with valid, active credentials.",
                            "Attempt to " + act + ".",
                            "Observe whether the request is accepted."),
                        "\"" + cap(act) + "\" succeeds for " + actor + " at " + sample
                            + "; no time-restriction error is shown."));
                }
            }
            if (want.contains("Negative") && tw.forbidden != null) {
                String mid = fmtTime((tw.forbidden[0] + tw.forbidden[1]) / 2);
                out.add(tc("Negative",
                    cap(actor) + " cannot " + act + " inside the restricted window (" + tw.forbiddenLabel + ")",
                    "System clock: " + mid + " (inside " + tw.forbiddenLabel + ")",
                    Arrays.asList(
                        "Set the test environment clock to " + mid + " local time.",
                        "Open " + app + " as " + actor + " with valid, active credentials.",
                        "Attempt to " + act + ".",
                        "Observe the response and check that no session/transaction is created."),
                    "The attempt is rejected with a message stating the service is only available "
                        + String.join(" and ", tw.allowedLabels) + ". No session or record is created."));
            }
            if (want.contains("Boundary")) {
                for (int[] b : tw.bounds) {
                    String in = fmtTime(b[0]), outT = fmtTime(b[1]);
                    out.add(tc("Boundary",
                        "Time boundary at " + outT + ": " + in + " allowed, " + outT + " rejected",
                        "Two runs \u2014 clock at " + in + ", then at " + outT,
                        Arrays.asList(
                            "Set the clock to " + in + " and attempt to " + act + ".",
                            "Record the outcome.",
                            "Set the clock to " + outT + " and repeat the same attempt.",
                            "Compare both outcomes."),
                        "At " + in + " the attempt succeeds; at " + outT
                            + " it is rejected. The cut-off is applied to the minute."));
                }
            }
        }

        // ── PROHIBITION / EXCLUSIVITY ──
        if (r.prohibit || excl != null) {
            String barred = r.prohibit ? actor
                    : (excl != null && excl.group != null ? "users outside \"" + excl.group + "\"" : "unauthorised users");
            if (want.contains("Negative")) {
                out.add(tc("Negative", cap(barred) + " cannot " + act,
                    "Test account belonging to: " + barred,
                    Arrays.asList(
                        "Provision a test account that belongs to " + barred + ".",
                        "Open " + app + " and authenticate with that account.",
                        "Attempt to " + act + ".",
                        "Check the response message and the audit log entry."),
                    "The attempt is refused with an access-denied message. No session, order or transaction "
                        + "is created, and the refusal is recorded in the audit log."));
            }
            if (want.contains("Security")) {
                out.add(tc("Security", "The restriction on " + barred + " cannot be bypassed client-side",
                    "Direct API call / modified request parameters",
                    Arrays.asList(
                        "Capture the request the UI sends when an authorised user performs \"" + act + "\".",
                        "Replay that request using the credentials of " + barred + ".",
                        "Repeat with the restricting field (locale, role, region flag) altered in the payload.",
                        "Inspect the HTTP status and response body."),
                    "Every replayed request is rejected server-side (HTTP 401/403). The restriction is enforced "
                        + "on the server, not only hidden in the UI."));
            }
        }

        // ── MIN / MAX VALUE ──
        if (money != null) {
            String subj = money.subject != null ? money.subject : "value";
            String unit = money.unit != null ? " " + money.unit : "";
            double v = money.value;
            double pass = "min".equals(money.dir) ? v + (v >= 10 ? 5 : 2) : Math.max(1, v - 1);
            double fail = "min".equals(money.dir) ? Math.max(0, round2(v - 0.01)) : round2(v + 0.01);
            if (want.contains("Functional")) {
                out.add(tc("Functional",
                    cap(art(subj)) + " " + subj + " of " + num(pass) + unit + " passes the " + money.dir + " " + num(v) + unit + " rule",
                    subj + " total = " + num(pass) + unit,
                    Arrays.asList(
                        "Log in to " + app + " with a valid account.",
                        "Build " + art(subj) + " " + subj + " with a total of exactly " + num(pass) + unit + ".",
                        "Proceed to the confirmation step.",
                        "Observe whether the " + subj + " is accepted."),
                    "The " + subj + " is accepted and confirmation is shown. No threshold warning appears."));
            }
            if (want.contains("Negative")) {
                out.add(tc("Negative",
                    cap(art(subj)) + " " + subj + " of " + num(fail) + unit + " is rejected by the " + money.dir + " " + num(v) + unit + " rule",
                    subj + " total = " + num(fail) + unit,
                    Arrays.asList(
                        "Log in to " + app + " with a valid account.",
                        "Build " + art(subj) + " " + subj + " with a total of " + num(fail) + unit + ".",
                        "Attempt to proceed to the confirmation step.",
                        "Read the validation message shown."),
                    "Progress is blocked and a message states the " + money.dir + "imum " + subj + " is "
                        + num(v) + unit + ". Nothing is submitted or charged."));
            }
            if (want.contains("Boundary")) {
                out.add(tc("Boundary",
                    "Boundary at " + num(v) + unit + ": " + num(v) + " accepted, " + num(fail) + " rejected",
                    "Run 1: " + num(v) + unit + " \u2014 Run 2: " + num(fail) + unit,
                    Arrays.asList(
                        "Build " + art(subj) + " " + subj + " totalling exactly " + num(v) + unit + " and try to proceed.",
                        "Record the outcome.",
                        "Adjust the " + subj + " to " + num(fail) + unit + " and try again.",
                        "Compare both outcomes."),
                    "Exactly " + num(v) + unit + " is accepted (the limit is inclusive); " + num(fail) + unit
                        + " is rejected with the threshold message."));
            }
        }

        // ── LENGTH ──
        if (len != null) {
            String f = len.subject != null ? len.subject : "field";
            int n = (int) len.value;
            if (want.contains("Functional")) {
                out.add(tc("Functional", cap(art(f)) + " " + f + " of " + (n + 2) + " characters is accepted",
                    f + " = " + (n + 2) + " characters",
                    Arrays.asList("Open the " + f + " entry screen.",
                        "Enter a value of exactly " + (n + 2) + " characters.", "Submit the form."),
                    "The value is accepted and the form submits without a length error."));
            }
            if (want.contains("Boundary")) {
                out.add(tc("Boundary", "Length boundary: " + n + " characters accepted, " + (n - 1) + " rejected",
                    "Run 1: " + n + " chars \u2014 Run 2: " + (n - 1) + " chars",
                    Arrays.asList(
                        "Enter " + art(f) + " " + f + " of exactly " + n + " characters and submit.",
                        "Record the outcome.",
                        "Enter " + art(f) + " " + f + " of exactly " + (n - 1) + " characters and submit.",
                        "Compare both outcomes."),
                    n + " characters is accepted; " + (n - 1) + " is rejected with a message naming the "
                        + n + "-character minimum."));
            }
        }

        // ── LOCKOUT ──
        if (lock != null) {
            int n = lock.attempts;
            if (want.contains("Functional")) {
                out.add(tc("Functional", "Account locks after " + n + " consecutive failed attempts",
                    n + " wrong passwords, then 1 correct password",
                    Arrays.asList("Use a known-good test account.",
                        "Submit an incorrect password " + n + " times in a row.",
                        "Submit the correct password on attempt " + (n + 1) + ".",
                        "Check the account status in the admin console."),
                    "After the " + ord(n) + " failure the account is locked; the correct password is refused "
                        + "and the account shows as locked."));
            }
            if (want.contains("Boundary")) {
                out.add(tc("Boundary", "Attempt boundary: " + (n - 1) + " failures do not lock the account",
                    (n - 1) + " wrong passwords, then 1 correct password",
                    Arrays.asList("Use a known-good test account.",
                        "Submit an incorrect password " + (n - 1) + " times.",
                        "Submit the correct password.",
                        "Check that login succeeds and the counter resets."),
                    "Login succeeds after " + (n - 1) + " failures and the failure counter resets to zero."));
            }
        }

        // ── SLA ──
        if (sla != null && want.contains("Performance")) {
            String slaUnit = ("1".equals(sla.slaValue) && !"ms".equals(sla.slaUnit))
                           ? sla.slaUnit.replaceAll("s$", "") : sla.slaUnit;
            out.add(tc("Performance", "Response completes within " + sla.slaValue + " " + slaUnit,
                "100 sequential requests under normal load",
                Arrays.asList(
                    "Point a load tool (JMeter/k6) at the endpoint described in " + r.id + ".",
                    "Send 100 sequential requests with representative payloads.",
                    "Record the mean and 95th-percentile response times.",
                    "Compare the 95th percentile against the " + sla.slaValue + " " + slaUnit + " target."),
                "The 95th-percentile response time is at or below " + sla.slaValue + " " + slaUnit
                    + " with no errors."));
        }

        // ── DISPLAYED MESSAGE ──
        if (disp != null) {
            String evt = triggerNoun(disp.trigger);
            String rawTrig = disp.trigger != null ? disp.trigger : "the action";
            if (want.contains("Functional")) {
                out.add(tc("Functional", "The " + disp.what + " is shown after a successful " + evt,
                    "One successful " + evt + " on a valid account",
                    Arrays.asList("Log in to " + app + " with a valid account.",
                        "Complete " + art(evt) + " " + evt + " end to end (" + rawTrig + ").",
                        "Observe the screen immediately after the final confirmation.",
                        "Compare the wording against the approved copy."),
                    "The " + disp.what + " appears immediately after the " + evt
                        + " is confirmed, with the approved wording."));
            }
            if (want.contains("Negative")) {
                out.add(tc("Negative", "The " + disp.what + " is not shown when the " + evt + " fails",
                    "Forced failure: declined payment or stubbed 500 response",
                    Arrays.asList(
                        "Force the operation to fail (decline the payment or stub a 500 from the backend).",
                        "Attempt " + art(evt) + " " + evt + " so that it fails at the final step.",
                        "Observe the screen."),
                    "An error message is shown and the " + disp.what + " does not appear, so the user is never "
                        + "told a failed " + evt + " succeeded."));
            }
        }

        // ── PERFORMANCE ──────────────────────────────────────────────
        if (want.contains("Performance")) {
            Constraint conc  = r.find("concurrency");
            Constraint thru  = r.find("throughput");
            Constraint vol   = r.find("volume");
            Constraint win   = r.find("batch-window");
            Constraint avail = r.find("availability");
            Constraint scal  = r.find("scalability");
            boolean perfMade = sla != null;

            if (conc != null) {
                perfMade = true;
                out.add(tc("Performance",
                    "Load: " + conc.people + " concurrent " + conc.people_unit + " sustained without degradation",
                    conc.people + " virtual " + conc.people_unit + ", 30-minute steady-state run",
                    Arrays.asList(
                        "Build a load script covering the journey in " + r.id + " with realistic think-time and data variation.",
                        "Ramp to " + conc.people + " concurrent " + conc.people_unit + " over 5 minutes, then hold for 30 minutes.",
                        "Record response times (mean, 90th, 95th, 99th), error rate and throughput throughout.",
                        "Watch CPU, memory, DB connections and thread pools on the servers for saturation.",
                        "Ramp down and confirm the system returns to its idle baseline."),
                    "The system carries " + conc.people + " concurrent " + conc.people_unit + " for the full window with error rate "
                  + "below 1%, response times inside the agreed SLA, and no resource exhaustion or memory growth across the run."));
                out.add(tc("Performance",
                    "Breakpoint: behaviour beyond " + conc.people + " concurrent " + conc.people_unit,
                    "Ramp past " + conc.people + " until failure",
                    Arrays.asList(
                        "Ramp load past " + conc.people + " " + conc.people_unit + " in steps of 10%, holding each step for 5 minutes.",
                        "Record the point at which response times breach the SLA or errors begin.",
                        "Continue until the system refuses work, then stop the load.",
                        "Confirm the system recovers by itself once load is removed."),
                    "The breakpoint is documented. Beyond it the system degrades gracefully \u2014 queuing or rejecting cleanly, "
                  + "not corrupting data or crashing \u2014 and recovers unaided when load stops."));
            }
            if (thru != null) {
                perfMade = true;
                String one = thru.item.replaceAll("s$", "");
                out.add(tc("Performance",
                    "Throughput: " + thru.count + " " + thru.item + " per " + thru.per + " sustained",
                    thru.count + " " + thru.item + "/" + thru.per + " for 1 hour",
                    Arrays.asList(
                        "Configure the load tool to drive a constant " + thru.count + " " + thru.item + " per " + thru.per + ".",
                        "Sustain that rate for one hour with production-like payloads.",
                        "Record achieved throughput, queue depth and error rate every minute.",
                        "Verify every accepted " + one + " is persisted exactly once (no loss, no duplicates)."),
                    "The target rate of " + thru.count + " " + thru.item + " per " + thru.per + " is met for the full hour, "
                  + "queues stay stable rather than growing, and record counts reconcile end to end."));
            }
            if (vol != null || win != null) {
                perfMade = true;
                String n  = vol != null ? String.valueOf(vol.count) : "the full production";
                String it = vol != null ? vol.item : "records";
                String lim = win != null ? (win.window + " " + win.windowUnit) : "the agreed window";
                out.add(tc("Performance",
                    "Volume: " + n + " " + it + " processed within " + lim,
                    n + " " + it + " (production-like distribution, including outliers)",
                    Arrays.asList(
                        "Load a dataset of " + n + " " + it + " that mirrors production in size and shape.",
                        "Start the run described in " + r.id + " and record the start time.",
                        "Measure total elapsed time, and check the log for retries, timeouts and skipped items.",
                        "Reconcile input against output counts and spot-check records at the start, middle and end."),
                    "All " + n + " " + it + " are processed inside " + lim + ", counts reconcile exactly, and no item is "
                  + "silently dropped or processed twice."));
            }
            if (avail != null) {
                perfMade = true;
                out.add(tc("Performance",
                    "Availability: service meets " + avail.pct + "% during planned and unplanned events",
                    "Rolling 30-day monitoring window plus one forced node failure",
                    Arrays.asList(
                        "Confirm uptime monitoring and alerting cover every component in " + r.id + ".",
                        "Review the last 30 days of monitoring data and calculate achieved availability.",
                        "In the test environment, kill one node while under load and time the recovery.",
                        "Check whether in-flight requests failed or were retried transparently."),
                    "Measured availability is at or above " + avail.pct + "%. A single node failure does not take the service "
                  + "down, and recovery happens within the agreed RTO."));
            }
            if (scal != null && conc == null) {
                perfMade = true;
                out.add(tc("Performance",
                    "Peak load: \"" + trim(r.raw, 42) + "\" holds up at forecast peak",
                    "Peak profile agreed with the business (state the multiplier used)",
                    Arrays.asList(
                        "Agree the peak profile with the business and record the multiplier over normal load.",
                        "Run the peak profile for the duration the peak is expected to last.",
                        "Record response times, error rate and resource use against the normal-load baseline.",
                        "Repeat with a sudden spike to peak rather than a gradual ramp."),
                    "Peak load is carried within SLA. A sudden spike may queue but must not drop work or return errors to users."));
            }
            boolean interactive = r.action != null && r.action.toLowerCase().matches(
                ".*\\b(log in|log out|sign in|sign up|register|place an order|check out|complete payment|complete a purchase|"
              + "access|view|download|upload|submit|search|transfer|withdraw|approve|create|update|delete|book|cancel|apply|"
              + "pay|send|open|generate|export|import)\\b.*");
            if (!perfMade && interactive) {
                out.add(tc("Performance",
                    "Response time baseline for \"" + act + "\" (no target stated in " + r.id + ")",
                    "50 sequential runs on a quiet system, single user",
                    Arrays.asList(
                        "NOTE: " + r.id + " states no performance target \u2014 agree one with the business before signing this off.",
                        "On an idle environment, perform \"" + act + "\" 50 times, recording each end-to-end duration.",
                        "Report mean, 90th and 95th percentile, and the slowest run.",
                        "Repeat once under normal working load and compare the two sets."),
                    "A documented baseline exists for \"" + act + "\", and the measured 95th percentile is agreed as the target "
                  + "for later regression runs. Any figure the business rejects becomes a defect against the requirement."));
            }
        }

        // ── SECURITY (beyond prohibition / exclusivity) ───────────────
        if (want.contains("Security")) {
            List<TestCase> sec = new ArrayList<>();
            if (r.secTransport) sec.add(tc("Security",
                "Transport security: data behind \"" + trim(r.raw, 42) + "\" is never sent in clear text",
                "Network capture (Wireshark/Fiddler) plus an SSL Labs scan",
                Arrays.asList(
                    "Capture traffic while performing the action in " + r.id + ".",
                    "Confirm every request and response uses TLS 1.2 or higher, and that no payload is readable in the capture.",
                    "Attempt the same call over plain HTTP and observe the response.",
                    "Scan the endpoint for weak ciphers, expired certificates and protocol downgrade."),
                "All traffic is encrypted in transit. Plain HTTP is refused or redirected to HTTPS, weak ciphers are disabled, "
              + "and the certificate is valid and trusted."));

            if (r.secStorage) sec.add(tc("Security",
                "Data at rest: values behind \"" + trim(r.raw, 42) + "\" are not readable in storage",
                "Direct read access to the database/file store in a test environment",
                Arrays.asList(
                    "Create a record through the UI using a recognisable marker value.",
                    "Query the underlying table or file store directly for that marker.",
                    "Confirm the sensitive field is encrypted, hashed or masked \u2014 never plain text.",
                    "For credentials, confirm a salted one-way hash is used, not reversible encryption.",
                    "Check logs, exports and error messages for the same value leaking in clear."),
                "The sensitive value cannot be read from storage, logs, exports or error output. Credentials are salted and "
              + "hashed, so the stored form cannot be reversed to the original."));

            if (r.secSession) sec.add(tc("Security",
                "Session handling behind \"" + trim(r.raw, 42) + "\"",
                "Two browsers, one valid session, captured session token",
                Arrays.asList(
                    "Log in and record the session token.",
                    "Leave the session idle past the timeout stated or agreed, then attempt a protected action.",
                    "Log out, then replay a previously captured request using the old token.",
                    "Log in again and confirm a new token is issued rather than the old one being reused."),
                "Idle sessions expire and are refused server-side. Tokens are invalidated at logout and cannot be replayed. "
              + "A fresh token is issued at each login, so session fixation is not possible."));

            if (r.secAuthz) sec.add(tc("Security",
                "Authorisation: \"" + trim(r.raw, 42) + "\" cannot be reached by a lesser role",
                "One privileged account and one standard account",
                Arrays.asList(
                    "Perform the action in " + r.id + " as the privileged role and capture the request.",
                    "Log in as a standard user and replay that exact request.",
                    "Repeat with the role or entitlement field in the payload or token altered.",
                    "Change the record identifier in the URL to one belonging to another user (IDOR check)."),
                "Every attempt by the lesser role is refused server-side with 401/403. Authorisation is evaluated on the server "
              + "from the session, never from a client-supplied field, and records belonging to others are not reachable."));

            if (r.secInjection) sec.add(tc("Security",
                "Input handling: free text in \"" + trim(r.raw, 40) + "\" is not executable",
                "Payloads: <img src=x onerror=alert(1)>, ' OR 1=1 --, =cmd|'/c calc'!A1, 5000-character string",
                Arrays.asList(
                    "Submit an HTML/JS payload in the free-text field, then view the record wherever it is displayed.",
                    "Submit an SQL payload and confirm the query is parameterised, not concatenated.",
                    "Export the record to CSV and open it \u2014 check for spreadsheet formula injection.",
                    "Submit an over-long string and a Unicode/emoji string, and observe how they are handled."),
                "Input is stored as data and rendered escaped, so nothing executes in the browser, the database or a "
              + "spreadsheet. Over-long input is rejected with a clear message rather than truncated or causing an error."));

            if (r.secAudit) sec.add(tc("Security",
                "Audit trail for \"" + trim(r.raw, 42) + "\"",
                "One successful action and one refused attempt",
                Arrays.asList(
                    "Perform the action in " + r.id + " successfully and note the timestamp.",
                    "Attempt it again in a way that is refused.",
                    "Inspect the audit log for both events.",
                    "Attempt to edit or delete an audit entry as an ordinary user, and as an administrator."),
                "Both the success and the refusal are logged with who, what, when and from where. Sensitive values are not "
              + "written in clear. Audit entries cannot be altered or removed through the application."));

            if (r.secAuth && !r.secStorage && !r.secSession) sec.add(tc("Security",
                "Credential handling behind \"" + trim(r.raw, 40) + "\"",
                "Valid and invalid credentials, plus network capture",
                Arrays.asList(
                    "Submit valid credentials and capture the request; confirm they are not placed in the URL or query string.",
                    "Submit invalid credentials and compare the error message and response time against a valid-user failure.",
                    "Check server and browser logs for the credential appearing in clear text.",
                    "Confirm the credential field is not cached or autocompleted where policy forbids it."),
                "Credentials travel only in an encrypted request body, never appear in URLs or logs, and the failure message "
              + "does not reveal whether the username exists."));

            for (int i = 0; i < sec.size() && i < 3; i++) out.add(sec.get(i));
        }

        // ── INTEGRATION (only when the requirement really spans components) ──
        if (want.contains("Integration") && r.integration) {
            out.add(tc("Integration",
                "Data behind \"" + trim(r.raw, 55) + "\" stays consistent across components",
                "One end-to-end transaction traced through UI \u2192 API \u2192 store",
                Arrays.asList(
                    "Trigger the behaviour in " + r.id + " from the UI on " + app + ".",
                    "Capture the outbound API request and the downstream response.",
                    "Verify the record written to the database/queue matches what the UI submitted.",
                    "Stub the downstream service to fail once and confirm the retry/error path behaves as designed."),
                "The same values appear in the UI, the API payload and the persisted record. A downstream "
                    + "failure surfaces a handled error rather than a partial write."));
        }

        // ── FALLBACK when nothing structural was found ──
        if (out.isEmpty()) {
            if (want.contains("Functional")) {
                out.add(tc("Functional",
                    r.action != null ? cap(actor) + " can " + act : "Verify: " + trim(r.raw, 70),
                    "Valid account and data as described in " + r.id,
                    Arrays.asList("Prepare the preconditions stated in " + r.id + ".",
                        "Open " + app + " as " + actor + ".",
                        r.action != null ? "Attempt to " + act + "."
                                         : "Exercise the behaviour described: " + trim(r.raw, 90),
                        "Compare the observed behaviour against the wording of " + r.id + "."),
                    "The observed behaviour matches " + r.id + " exactly: " + trim(r.raw, 120)));
            }
            if (want.contains("Negative")) {
                out.add(tc("Negative", "The rule in " + r.id + " is enforced when it is violated",
                    "Input that deliberately breaks the rule: " + trim(r.raw, 70),
                    Arrays.asList("Prepare data that violates " + r.id + " (\"" + trim(r.raw, 80) + "\").",
                        "Open " + app + " as " + actor + ".",
                        "Submit that data / attempt the action anyway.",
                        "Read the response and check the backend that nothing was saved."),
                    "The attempt is rejected with a message that names the rule. No record is created or "
                        + "changed, and the failure is logged."));
            }
        }

        for (TestCase t : out) { t.requirement = r.id + ": " + r.raw; t.sourceDoc = r.sourceDoc; }
        return out;
    }

    private static String triggerNoun(String t) {
        if (t == null) return "action";
        String[] w = t.trim().split("\\s+");
        String last = w[w.length - 1].toLowerCase().replaceAll("s$", "");
        return last.length() >= 3 ? last : "action";
    }

    private static TestCase tc(String type, String title, String data, List<String> steps, String expected) {
        TestCase t = new TestCase();
        t.type = type; t.title = title; t.testData = data;
        t.steps = new ArrayList<>(steps); t.expected = expected;
        return t;
    }
}
