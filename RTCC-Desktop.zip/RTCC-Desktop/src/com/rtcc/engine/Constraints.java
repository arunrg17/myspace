package com.rtcc.engine;

import com.rtcc.model.Constraint;
import com.rtcc.model.Requirement;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Extracts testable rules (time windows, thresholds, lockouts, SLAs, messages). */
final class Constraints {

    private Constraints() {}

    private static final Pattern TIME = Pattern.compile(
            "\\b(before|after|from|until|till|by)\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|a\\.m\\.|p\\.m\\.|o'clock|hrs|hours)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern BETWEEN = Pattern.compile(
            "\\bbetween\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?\\s+and\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern NOT_A_TIME = Pattern.compile(
            "^\\s*(failed|invalid|unsuccessful|attempts?|tries|days?|weeks?|months?|items?|records?|users?|"
          + "characters?|chars?|euros?|dollars?)", Pattern.CASE_INSENSITIVE);

    private static final String MIN_WORD =
            "\\b(minimum|minimun|mininum|minium|minmum|min\\.?|minus|at least|atleast|no less than|not less than|lower limit)\\b";
    private static final String MAX_WORD =
            "\\b(maximum|maximun|maxium|maxmum|max\\.?|at most|no more than|not more than|upper limit|up to|capped at)\\b";
    private static final Pattern SUBJ_WORD = Pattern.compile(
            "\\b(order|cart|basket|amount|value|total|price|payment|purchase|transfer|password|username|file|name|quantity|limit)\\b",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern LOCKOUT = Pattern.compile(
            "\\b(?:lock|block|disable|suspend)\\w*\\b[^.]{0,40}?\\bafter\\s+(\\d+)\\s+"
          + "(?:failed\\s+|invalid\\s+|unsuccessful\\s+)?(?:attempts?|tries|logins?)", Pattern.CASE_INSENSITIVE);
    private static final String T_UNITS =
            "(ms|millisecond|milliseconds|s|sec|secs|second|seconds|min|mins|minute|minutes)";
    private static final Pattern SLA = Pattern.compile(
            "\\b(?:within|under|less than|no more than|not exceed|below|<=?)\\s*(\\d+(?:\\.\\d+)?)\\s*"
          + T_UNITS + "\\b", Pattern.CASE_INSENSITIVE);
    /** "the response should be in 10 sec", "must respond in 3 seconds", "response time of 500 ms". */
    private static final Pattern SLA_LOOSE = Pattern.compile(
            "\\b(response|respond\\w*|reply|replies|load|loads|loading|render\\w*|complete\\w*|finish\\w*|"
          + "return\\w*|process\\w*|display\\w*|refresh\\w*)\\b"
          + "[^.]{0,35}?\\b(?:in|of|to|within|under|below|less than|no more than|not exceed|<=?)\\s*"
          + "(\\d+(?:\\.\\d+)?)\\s*" + T_UNITS + "\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern DISPLAY = Pattern.compile(
            "\\b((?:[\\w'-]+\\s+){0,3})(message|msg|notification|confirmation|alert|banner|popup|toast)\\b"
          + "[^.]{0,25}?\\b(?:is|are|shall be|should be|must be|will be|gets?)\\s+"
          + "(displayed|shown|presented|visible|returned)", Pattern.CASE_INSENSITIVE);
    private static final Pattern DISPLAY_STOP = Pattern.compile(
            "^(a|an|the|every|each|time|times|when|after|upon|on|then|and|customer|customers|user|users|"
          + "client|clients|is|are|be|place|places|placed|placing|receive|receives|get|gets)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern TRIGGER = Pattern.compile(
            "\\b(?:every time|each time|when|after|upon|once)\\s+(?:the\\s+|a\\s+)?(?:customers?|users?|clients?)?\\s*"
          + "([\\w' -]{3,40}?)(?:,|\\s+a\\s+|\\s+the\\s+|$)", Pattern.CASE_INSENSITIVE);
    private static final Pattern ONLY_COND = Pattern.compile(
            "\\bonly\\s+(when|while|if|after|before|once|during|where|on)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern ONLY_GROUP = Pattern.compile(
            "\\bonly\\s+([\\w' -]{3,40}?)\\s+(?:can|may|shall|are|is)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern BAD_GROUP = Pattern.compile(
            "\\b(when|while|if|after|before|once|during|minimum|maximum|amount|reached|time|value|order button)\\b",
            Pattern.CASE_INSENSITIVE);

    static List<Constraint> extract(String text, Requirement r) {
        List<Constraint> cs = new ArrayList<>();

        // ── time window ──
        List<int[]> pts = new ArrayList<>();     // {relCode 0=before 1=after, minute}
        Matcher m = TIME.matcher(text);
        while (m.find()) {
            String tail = text.substring(Math.min(m.end(), text.length()),
                                         Math.min(m.end() + 26, text.length()));
            if (m.group(3) == null && m.group(4) == null) continue;      // bare number is not a clock time
            if (NOT_A_TIME.matcher(tail).find()) continue;
            int rel = m.group(1).toLowerCase().matches("before|until|till|by") ? 0 : 1;
            pts.add(new int[]{rel, Analyzer.to24(m.group(2), m.group(3), m.group(4))});
        }
        Matcher bm = BETWEEN.matcher(text);
        if (bm.find()) {
            pts.add(new int[]{1, Analyzer.to24(bm.group(1), bm.group(2), bm.group(3))});
            pts.add(new int[]{0, Analyzer.to24(bm.group(4), bm.group(5), bm.group(6))});
        }
        if (!pts.isEmpty()) {
            Integer before = null, after = null;
            for (int[] p : pts) {
                if (p[0] == 0) before = (before == null) ? p[1] : Math.min(before, p[1]);
                else after = (after == null) ? p[1] : Math.max(after, p[1]);
            }
            Constraint c = new Constraint("time-window");
            if (before != null && after != null && after > before) {
                c.allowed.add(new int[]{0, before - 1});
                c.allowedLabels.add("before " + Analyzer.fmtTime(before));
                c.allowed.add(new int[]{after + 1, 1439});
                c.allowedLabels.add("after " + Analyzer.fmtTime(after));
                c.forbidden = new int[]{before, after};
                c.forbiddenLabel = Analyzer.fmtTime(before) + "\u2013" + Analyzer.fmtTime(after);
                c.bounds.add(new int[]{before - 1, before});
                c.bounds.add(new int[]{after + 1, after});
            } else if (before != null) {
                c.allowed.add(new int[]{0, before - 1});
                c.allowedLabels.add("before " + Analyzer.fmtTime(before));
                c.forbidden = new int[]{before, 1439};
                c.forbiddenLabel = Analyzer.fmtTime(before) + " onwards";
                c.bounds.add(new int[]{before - 1, before});
            } else {
                c.allowed.add(new int[]{after + 1, 1439});
                c.allowedLabels.add("after " + Analyzer.fmtTime(after));
                c.forbidden = new int[]{0, after};
                c.forbiddenLabel = "up to and including " + Analyzer.fmtTime(after);
                c.bounds.add(new int[]{after + 1, after});
            }
            if (!c.allowed.isEmpty()) cs.add(c);
        }

        // ── min / max ──
        Matcher minM = Pattern.compile(MIN_WORD + "[^\\d]{0,45}(\\d+(?:[.,]\\d+)?)\\s*([a-z\u20ac$\u00a3%]+)?",
                Pattern.CASE_INSENSITIVE).matcher(text);
        if (minM.find() && (!minM.group(1).equalsIgnoreCase("minus") || SUBJ_WORD.matcher(text).find()))
            cs.add(numeric("min", minM.group(2), minM.group(3), text));
        Matcher maxM = Pattern.compile(MAX_WORD + "[^\\d]{0,45}(\\d+(?:[.,]\\d+)?)\\s*([a-z\u20ac$\u00a3%]+)?",
                Pattern.CASE_INSENSITIVE).matcher(text);
        if (maxM.find()) cs.add(numeric("max", maxM.group(2), maxM.group(3), text));

        // ── lockout ──
        Matcher lm = LOCKOUT.matcher(text);
        if (lm.find()) { Constraint c = new Constraint("lockout"); c.attempts = Integer.parseInt(lm.group(1)); cs.add(c); }

        // ── SLA ──
        Matcher sm = SLA.matcher(text);
        String slaVal = null, slaRaw = null;
        if (sm.find()) { slaVal = sm.group(1); slaRaw = sm.group(2); }
        else {
            Matcher sl = SLA_LOOSE.matcher(text);
            if (sl.find()) { slaVal = sl.group(2); slaRaw = sl.group(3); }
        }
        if (slaVal != null) {
            Constraint c = new Constraint("sla");
            c.slaValue = slaVal;
            String u = slaRaw.toLowerCase();
            c.slaUnit = (u.startsWith("ms") || u.startsWith("milli")) ? "ms"
                      : (u.startsWith("min") ? "minutes" : "seconds");
            cs.add(c);
        }

        // ── displayed message ──
        Matcher dm = DISPLAY.matcher(text);
        if (dm.find()) {
            Constraint c = new Constraint("display");
            StringBuilder w = new StringBuilder();
            for (String word : dm.group(1).trim().split("\\s+"))
                if (!word.isEmpty() && !DISPLAY_STOP.matcher(word).matches()) w.append(word).append(' ');
            String noun = dm.group(2).equalsIgnoreCase("msg") ? "message" : dm.group(2).toLowerCase();
            c.what = (w + noun).trim();
            Matcher tm = TRIGGER.matcher(text);
            c.trigger = tm.find() ? tm.group(1).trim() : null;
            cs.add(c);
        }

        // ── exclusivity ("only X can", "not others") but not "only when ..." ──
        if (Pattern.compile("\\bnot others\\b|\\bno one else\\b|\\bonly\\b", Pattern.CASE_INSENSITIVE).matcher(text).find()
                && !ONLY_COND.matcher(text).find()) {
            Matcher om = ONLY_GROUP.matcher(text);
            String grp = om.find() ? om.group(1).trim() : r.actor;
            if (grp != null && (BAD_GROUP.matcher(grp).find() || grp.split("\\s+").length > 5)) grp = null;
            if (grp != null || Pattern.compile("\\bnot others\\b|\\bno one else\\b", Pattern.CASE_INSENSITIVE).matcher(text).find()) {
                Constraint c = new Constraint("exclusive");
                c.group = grp;
                cs.add(c);
            }
        }
        // ── performance shapes beyond a plain response-time SLA ──
        Matcher cm = Pattern.compile(
            "(\\d[\\d,]*)\\s*(?:concurrent|simultaneous|parallel|active)\\s*"
          + "(users?|sessions?|requests?|connections?|clients?|customers?)", Pattern.CASE_INSENSITIVE).matcher(text);
        if (cm.find()) {
            Constraint c = new Constraint("concurrency");
            c.people = Integer.parseInt(cm.group(1).replace(",", ""));
            c.people_unit = cm.group(2).toLowerCase();
            cs.add(c);
        }

        Matcher tm2 = Pattern.compile(
            "(\\d[\\d,]*)\\s*(transactions?|requests?|orders?|records?|messages?|payments?|items?|calls?)\\s*"
          + "(?:per|/|a|each)\\s*(second|sec|minute|min|hour|hr|day)", Pattern.CASE_INSENSITIVE).matcher(text);
        Integer thruVal = null;
        if (tm2.find()) {
            Constraint c = new Constraint("throughput");
            c.count = Integer.parseInt(tm2.group(1).replace(",", ""));
            thruVal = c.count;
            c.item = tm2.group(2).toLowerCase();
            c.per = tm2.group(3).toLowerCase();
            cs.add(c);
        }

        Matcher vm = Pattern.compile(
            "(?:process|handle|import|export|load|generate|reconcile)\\w*\\s+(?:up to\\s+)?(\\d[\\d,]*)\\s*"
          + "(records?|rows?|files?|transactions?|orders?|messages?)", Pattern.CASE_INSENSITIVE).matcher(text);
        if (vm.find()) {
            int v = Integer.parseInt(vm.group(1).replace(",", ""));
            if (thruVal == null || thruVal != v) {            // throughput already covers that number
                Constraint c = new Constraint("volume");
                c.count = v;
                c.item = vm.group(2).toLowerCase();
                cs.add(c);
            }
        }

        Matcher wm = Pattern.compile(
            "\\b(?:batch|job|report|file|feed|run|reconciliation)\\b[^.]{0,50}?"
          + "\\b(?:complete|completed|finish|finished|run|process|processed|generate|generated|deliver|delivered|import|export)\\w*\\b[^.]{0,45}?\\s"
          + "(?:in|within|by|before)\\s*(\\d+(?:\\.\\d+)?)\\s*(minutes?|mins?|hours?|hrs?)",
            Pattern.CASE_INSENSITIVE).matcher(text);
        if (wm.find()) {
            Constraint c = new Constraint("batch-window");
            c.window = wm.group(1); c.windowUnit = wm.group(2).toLowerCase();
            cs.add(c);
        }

        Matcher am = Pattern.compile("(\\d{2}(?:\\.\\d+)?)\\s*%\\s*(?:uptime|availability|available)",
                Pattern.CASE_INSENSITIVE).matcher(text);
        if (am.find()) { Constraint c = new Constraint("availability"); c.pct = am.group(1); cs.add(c); }

        if (Pattern.compile("\\b(peak|peak hours?|scal(?:e|ing|ability)|stress|spike|surge|high load|"
                + "month.?end|year.?end|black friday|busy period)\\b", Pattern.CASE_INSENSITIVE).matcher(text).find())
            cs.add(new Constraint("scalability"));

        // ── which kinds of security testing this requirement needs ──
        r.secTransport = find(text, "\\b(https?|tls|ssl|in transit|transmit\\w*|certificate|secure channel|man.in.the.middle)\\b");
        r.secStorage   = find(text, "\\b(encrypt\\w*|hash\\w*|salt\\w*|at rest|masked?|redact\\w*|stored? securely|pii|"
                                  + "personal data|card number|iban|account number)\\b");
        r.secSession   = find(text, "\\b(session|idle|inactivity|time.?out|timed? out|auto.?logout|log ?out|token expir\\w*|jwt|cookie)\\b");
        r.secAuthz     = find(text, "\\b(role|roles|permission|privilege|admin|administrator|authoris\\w*|authoriz\\w*|"
                                  + "access control|entitlement|approve|approval)\\b");
        r.secInjection = find(text, "\\b(comment|free.?text|notes?|description|search|input|upload|attachment|file ?name|"
                                  + "message|feedback|remark)\\b");
        r.secAudit     = find(text, "\\b(audit|traceab\\w*|log(?:ged|ging|s)?|history|who (?:did|changed|approved)|non.?repudiation)\\b");
        r.secAuth      = find(text, "\\b(password|passcode|login|log ?in|credential|mfa|2fa|otp|biometric|authenticat\\w*)\\b");

        return cs;
    }

    private static boolean find(String text, String regex) {
        return Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(text).find();
    }

    private static Constraint numeric(String dir, String valStr, String unitRaw, String text) {
        double val = Double.parseDouble(valStr.replace(',', '.'));
        String unit = unitRaw == null ? "" : unitRaw.toLowerCase().replaceAll("[.,]$", "");
        String kind = "threshold";
        if (unit.matches("chars?|characters?")) kind = "length";
        else if (unit.matches("euros?|eur|\u20ac|dollars?|usd|\\$|pounds?|gbp|\u00a3")) kind = "money";
        else if (unit.matches("items?|products?")) kind = "count";
        Constraint c = new Constraint(kind);
        c.dir = dir; c.value = val; c.unit = unit.isEmpty() ? null : unit;
        Matcher sm = SUBJ_WORD.matcher(text);
        c.subject = sm.find() ? sm.group(1).toLowerCase() : null;
        return c;
    }
}
