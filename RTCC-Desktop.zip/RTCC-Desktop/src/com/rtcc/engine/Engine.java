package com.rtcc.engine;

import com.rtcc.model.ReqDoc;
import com.rtcc.model.Requirement;
import com.rtcc.model.TestCase;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Offline test-case engine v3.2.
 *
 * Requirements are split into statements, each statement is analysed into
 * structure, and test cases are written from that structure — no templates
 * stuffed with raw requirement text.
 */
public final class Engine {

    private static final List<String> TYPE_ORDER = Arrays.asList(
            "E2E", "Functional", "Negative", "Boundary", "Security", "Integration", "Performance", "Regression");

    private static final Map<String, String> PRIORITY = new HashMap<>();
    static {
        PRIORITY.put("E2E", "HIGH");       PRIORITY.put("Functional", "HIGH");
        PRIORITY.put("Negative", "HIGH");  PRIORITY.put("Security", "HIGH");
        PRIORITY.put("Boundary", "MEDIUM");PRIORITY.put("Integration", "MEDIUM");
        PRIORITY.put("Performance", "MEDIUM"); PRIORITY.put("Regression", "MEDIUM");
    }

    private static final Pattern FEATURE = Pattern.compile(
            "\\b([A-Z][\\w']*(?:\\s+[A-Za-z][\\w']*)?\\s+(?:app|application|portal|system|platform|shop|bank|banking))\\b");

    private Engine() {}

    public static List<TestCase> generate(String flowText, List<ReqDoc> docs,
                                          List<String> types, String detail, int maxCases) {
        if (types == null || types.isEmpty()) types = Collections.singletonList("Functional");

        // documents with content; fall back to the flow text when there are none
        List<ReqDoc> units = new ArrayList<>();
        if (docs != null) for (ReqDoc d : docs) if (d.hasContent()) units.add(d);
        if (units.isEmpty() && flowText != null && !flowText.trim().isEmpty())
            units.add(new ReqDoc("Flow diagram", flowText));

        StringBuilder all = new StringBuilder();
        for (ReqDoc d : units) all.append(d.content).append('\n');
        String feature = deriveFeature(flowText, all.toString());

        Map<String, List<TestCase>> buckets = new LinkedHashMap<>();
        Set<String> seen = new HashSet<>();
        int seq = 0;

        for (ReqDoc unit : units) {
            for (String stmt : Analyzer.splitStatements(unit.content)) {
                Requirement r = Analyzer.analyze(stmt, ++seq);
                r.sourceDoc = unit.name;
                for (TestCase t : TestBuilder.build(r, types, feature)) {
                    String key = t.type + "|" + t.title.toLowerCase();
                    if (!seen.add(key)) continue;
                    buckets.computeIfAbsent(t.type, k -> new ArrayList<>()).add(t);
                }
            }
        }

        // end-to-end journey from the flow diagram
        List<String> flowSteps = new ArrayList<>();
        if (flowText != null) {
            for (String l : flowText.split("\\r?\\n+")) {
                String s = l.trim().replaceAll("^\\s*(?:\\d+[.)]|[-*\u2022>\u2192])\\s*", "");
                if (s.length() > 2) flowSteps.add(s);
            }
        }
        String e2eType = types.contains("E2E") ? "E2E" : (types.contains("Functional") ? "Functional" : null);
        if (e2eType != null && flowSteps.size() >= 2) {
            TestCase e = new TestCase();
            e.type = e2eType;
            e.title = "End-to-end happy path through " + feature;
            e.testData = "Valid account and standard test data for the whole journey";
            e.requirement = "FLOW: End-to-end process flow";
            e.sourceDoc = "Flow diagram";
            for (String s : flowSteps) e.steps.add(Analyzer.cap(s.replaceAll("\\.$", "")) + ".");
            e.steps.add("Refresh and re-open the record to confirm the final state was persisted.");
            e.expected = "Every step completes without error, the journey ends in the expected state, "
                       + "and that state survives a refresh.";
            buckets.computeIfAbsent(e2eType, k -> new ArrayList<>()).add(0, e);
        }

        // regression is a suite-level concern: at most two, aimed at the sharpest cases
        if (types.contains("Regression")) {
            List<TestCase> pool = new ArrayList<>();
            for (String k : Arrays.asList("Negative", "Boundary", "Functional", "Security"))
                if (buckets.containsKey(k)) pool.addAll(buckets.get(k));
            List<TestCase> regs = new ArrayList<>();
            Set<String> usedReq = new HashSet<>();
            for (TestCase t : pool) {
                if (regs.size() >= 2) break;
                String rid = t.requirement.split(":")[0];
                if (!usedReq.add(rid)) continue;
                TestCase g = new TestCase();
                g.type = "Regression";
                g.title = "Regression: " + Character.toLowerCase(t.title.charAt(0)) + t.title.substring(1)
                        + " \u2014 still true after the latest build";
                g.testData = "Current release build, plus the baseline result recorded for " + rid;
                g.requirement = t.requirement;
                g.sourceDoc = t.sourceDoc;
                g.steps = Arrays.asList(
                        "Deploy the current build to the test environment.",
                        "Re-run " + rid + " using exactly the data from the baseline run: "
                                + (t.testData.isEmpty() ? "as recorded" : t.testData),
                        "Compare outcome, on-screen messages and the stored record against the baseline.",
                        "Spot-check the two features nearest to this one for side effects.");
                g.expected = "Identical to the baseline: same outcome, same messages, no new defects in "
                           + "adjacent features.";
                regs.add(g);
            }
            if (!regs.isEmpty()) buckets.put("Regression", regs);
        }

        // interleave by type so the cap never starves a category
        List<TestCase> ordered = new ArrayList<>();
        for (int idx = 0, more = 1; more == 1; idx++) {
            more = 0;
            for (String type : TYPE_ORDER) {
                List<TestCase> b = buckets.get(type);
                if (b != null && idx < b.size()) { ordered.add(b.get(idx)); more = 1; }
            }
        }

        int limit = Math.max(1, maxCases);
        List<TestCase> result = new ArrayList<>();
        for (int i = 0; i < ordered.size() && i < limit; i++) {
            TestCase t = ordered.get(i);
            t.id = String.format("TC-%03d", i + 1);
            t.priority = PRIORITY.getOrDefault(t.type, "MEDIUM");

            List<String> steps = new ArrayList<>(t.steps);
            if ("Brief".equals(detail) && steps.size() > 3) steps = steps.subList(0, 3);
            if ("Detailed".equals(detail))
                steps.add("Record the actual result, evidence (screenshot/log) and pass/fail verdict.");
            t.steps = steps;

            String rid = t.requirement.contains(":") ? t.requirement.split(":")[0] : t.requirement;
            StringBuilder pre = new StringBuilder("Test environment available and ");
            pre.append("Flow diagram".equals(t.sourceDoc) ? "the flow under test is deployed" : rid + " is deployed").append('.');
            if (!"Brief".equals(detail) && !t.testData.isEmpty()) pre.append(" Test data: ").append(t.testData).append('.');
            t.preconditions = pre.toString();

            t.tags = new ArrayList<>(Arrays.asList(t.type.toLowerCase(), rid.toLowerCase(), "offline-generated"));
            if (t.sourceDoc != null && !t.sourceDoc.isEmpty())
                t.tags.add(t.sourceDoc.toLowerCase().replaceAll("\\s+", "-"));
            result.add(t);
        }
        return result;
    }

    private static String deriveFeature(String flow, String reqs) {
        String src = (reqs == null ? "" : reqs) + " " + (flow == null ? "" : flow);
        Matcher m = FEATURE.matcher(src);
        return m.find() ? m.group(1).replaceAll("\\s+", " ").trim() : "the application";
    }
}
