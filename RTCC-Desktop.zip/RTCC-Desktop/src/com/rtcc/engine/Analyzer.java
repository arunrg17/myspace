package com.rtcc.engine;

import com.rtcc.model.Constraint;
import com.rtcc.model.Requirement;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns free-text requirements into structure: actor, action, permitted vs
 * prohibited, and the constraints that can actually be tested.
 * Port of the JavaScript offline engine v3.2.
 */
public final class Analyzer {

    private Analyzer() {}

    // ── statement splitting ───────────────────────────────────────────
    private static final Pattern AND_SPLIT = Pattern.compile("\\s+and\\s+", Pattern.CASE_INSENSITIVE);
    private static final Pattern CLAUSE = Pattern.compile(
            "\\b(is|are|was|were|shall|should|must|can|cannot|may|will|display|displayed|shown|show|"
          + "receive|receives|send|sends|get|gets|see|sees)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern TIME_PAIR_LEFT  = Pattern.compile("\\b(before|after|from|until|between|by)\\s+\\d", Pattern.CASE_INSENSITIVE);
    private static final Pattern TIME_PAIR_RIGHT = Pattern.compile("^(before|after|from|until|by)\\s+\\d", Pattern.CASE_INSENSITIVE);

    public static List<String> splitStatements(String block) {
        List<String> out = new ArrayList<>();
        if (block == null) return out;
        for (String line : block.split("\\r?\\n+")) {
            line = line.trim().replaceAll("^[-*\u2022]\\s*", "");
            if (line.length() < 8) continue;
            for (String part : line.split("(?i:;|\\.\\s+(?=[A-Z])|,\\s+and\\s+|,?\\s+also\\s+|,\\s*(?:additionally|in addition|furthermore|plus)\\s+)")) {
                part = part.trim();
                if (part.isEmpty()) continue;
                boolean split = false;
                Matcher m = AND_SPLIT.matcher(part);
                while (m.find()) {
                    String left = part.substring(0, m.start()).trim();
                    String right = part.substring(m.end()).trim();
                    boolean rightIsClause = right.split("\\s+").length >= 5 && CLAUSE.matcher(right).find();
                    boolean timePair = TIME_PAIR_LEFT.matcher(left).find() && TIME_PAIR_RIGHT.matcher(right).find();
                    if (rightIsClause && !timePair) {
                        out.add(left); out.add(right); split = true; break;
                    }
                }
                if (!split) out.add(part);
            }
        }
        List<String> keep = new ArrayList<>();
        for (String s : out) if (s.trim().length() >= 8) keep.add(s.trim());
        return keep;
    }

    // ── requirement analysis ──────────────────────────────────────────
    private static final Pattern REQ_ID = Pattern.compile(
            "^([A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*-\\d+)\\s*[:\\-]\\s*(.+)$");
    private static final Pattern APP_PREFIX = Pattern.compile(
            "^[A-Z][\\w' -]{2,30}?\\s+(app|application|system|portal|platform|site|website)\\s*[,:]?\\s+(the\\s+)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern MODAL = Pattern.compile(
            "\\b(can\\s?not|cannot|can't|may not|must not|shall not|should not|is not allowed to|"
          + "are not allowed to|is not permitted to|are not permitted to|can|may|shall|must|should|will|"
          + "is able to|are able to)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern ACTION_CUT = Pattern.compile(
            "\\b(before|after|between|from|until|till|by|within|only|when|if|unless|with|minimum|maximum|"
          + "at least|no more than|less than|more than)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern INTEGRATION = Pattern.compile(
            "\\b(api|endpoint|service|services|integration|integrates?|interface|downstream|upstream|queue|"
          + "kafka|mq|webhook|third.?party|external system|micro.?service|database|db|batch|sync|synchron|"
          + "feed|import|export|middleware|gateway)\\b", Pattern.CASE_INSENSITIVE);

    public static Requirement analyze(String raw, int seq) {
        Requirement r = new Requirement();
        String text = raw.trim().replaceAll("\\s+", " ");

        Matcher idm = REQ_ID.matcher(text);
        if (idm.matches()) { r.id = idm.group(1).toUpperCase(); text = idm.group(2).trim(); }
        else r.id = String.format("REQ-%03d", seq);

        r.raw = text;
        r.integration = INTEGRATION.matcher(text).find();

        String work = APP_PREFIX.matcher(text).replaceFirst("");
        Matcher mm = MODAL.matcher(work);
        if (mm.find()) {
            String subj = work.substring(0, mm.start()).trim().replaceAll("^(?i)(the|a|an)\\s+", "");
            String rest = work.substring(mm.end()).trim().replaceAll("^(?i)(be|been|being)\\s+", "");
            r.prohibit = mm.group(1).toLowerCase().matches(".*(not|n't).*");
            if (!subj.isEmpty() && subj.split("\\s+").length <= 7) r.actor = subj;

            String cut = ACTION_CUT.split(rest)[0].trim().replaceAll("[,.]$", "");
            if (!cut.isEmpty() && cut.split("\\s+").length <= 5) r.action = Verbs.normalize(cut);
        }
        r.constraints = Constraints.extract(text, r);
        return r;
    }

    // ── shared helpers ────────────────────────────────────────────────
    public static int to24(String h, String mi, String ampm) {
        int hh = Integer.parseInt(h);
        int mm = (mi == null || mi.isEmpty()) ? 0 : Integer.parseInt(mi);
        if (ampm != null && !ampm.isEmpty()) {
            String a = ampm.toLowerCase().replace(".", "");
            if (a.startsWith("pm") && hh < 12) hh += 12;
            if (a.startsWith("am") && hh == 12) hh = 0;
        }
        if (hh > 23) hh = 23;
        return hh * 60 + mm;
    }

    public static String fmtTime(int mins) {
        mins = ((mins % 1440) + 1440) % 1440;
        return String.format("%02d:%02d", mins / 60, mins % 60);
    }

    public static String cap(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    public static String trim(String s, int n) {
        if (s == null) return "";
        return s.length() > n ? s.substring(0, n - 1) + "\u2026" : s;
    }

    public static String art(String w) {
        return (w != null && !w.isEmpty() && "aeiouAEIOU".indexOf(w.charAt(0)) >= 0) ? "an" : "a";
    }

    public static String ord(int n) {
        int v = n % 100;
        if (v >= 11 && v <= 13) return n + "th";
        switch (n % 10) {
            case 1: return n + "st";
            case 2: return n + "nd";
            case 3: return n + "rd";
            default: return n + "th";
        }
    }

    public static String gerund(String phrase) {
        String[] w = phrase.trim().split("\\s+");
        String v = w[0];
        if (v.endsWith("e") && !v.endsWith("ee")) v = v.substring(0, v.length() - 1) + "ing";
        else if (v.matches("(?i)log|set|put|run|get|cut|sit")) v = v + v.charAt(v.length() - 1) + "ing";
        else v = v + "ing";
        w[0] = v;
        return String.join(" ", w);
    }

    public static double round2(double n) { return Math.round(n * 100.0) / 100.0; }

    public static String num(double d) {
        return (d == Math.rint(d) && !Double.isInfinite(d))
                ? String.valueOf((long) d) : String.valueOf(round2(d));
    }
}
