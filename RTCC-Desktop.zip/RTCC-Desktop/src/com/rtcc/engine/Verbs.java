package com.rtcc.engine;

import java.util.HashMap;
import java.util.Map;

/** Normalises loose verb phrases into readable test-case wording. */
final class Verbs {
    private static final Map<String, String> MAP = new HashMap<>();
    static {
        MAP.put("login", "log in");      MAP.put("log in", "log in");
        MAP.put("logs in", "log in");    MAP.put("sign in", "sign in");
        MAP.put("logout", "log out");    MAP.put("log out", "log out");
        MAP.put("signup", "sign up");    MAP.put("register", "register");
        MAP.put("order", "place an order");
        MAP.put("place order", "place an order");
        MAP.put("place an order", "place an order");
        MAP.put("checkout", "check out"); MAP.put("pay", "complete payment");
        MAP.put("purchase", "complete a purchase");
        MAP.put("access", "access the feature");
        MAP.put("view", "view the page");  MAP.put("download", "download the file");
        MAP.put("upload", "upload a file"); MAP.put("submit", "submit the form");
        MAP.put("search", "run a search");  MAP.put("transfer", "transfer funds");
        MAP.put("withdraw", "withdraw funds");
    }
    private Verbs() {}
    static String normalize(String v) {
        String k = v.toLowerCase().trim();
        return MAP.getOrDefault(k, k);
    }
}
