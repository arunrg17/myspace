package com.rtcc.export;

import com.rtcc.model.TestCase;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Writes generated test cases to xlsx, csv, json, markdown and plain text. */
public final class Exporters {

    private static final String[] HEADERS = {
        "ID","Title","Type","Priority","Source Doc","Requirement",
        "Preconditions","Test Data","Steps","Expected Result","Tags"
    };

    private Exporters() {}

    private static String[] row(TestCase t) {
        return new String[]{ t.id, t.title, t.type, t.priority, t.sourceDoc, t.requirement,
                t.preconditions, t.testData, t.stepsJoined("\n"), t.expected, String.join(", ", t.tags) };
    }

    // ── real .xlsx (OOXML in a ZIP) ───────────────────────────────────
    public static void xlsx(List<TestCase> cases, File file) throws IOException {
        StringBuilder sheet = new StringBuilder();
        sheet.append("<row r=\"1\" ht=\"26\" customHeight=\"1\">");
        for (int i = 0; i < HEADERS.length; i++) sheet.append(cell(col(i + 1) + "1", HEADERS[i], 1));
        sheet.append("</row>");
        for (int r = 0; r < cases.size(); r++) {
            String[] vals = row(cases.get(r));
            int rn = r + 2;
            sheet.append("<row r=\"").append(rn).append("\">");
            for (int c = 0; c < vals.length; c++) sheet.append(cell(col(c + 1) + rn, vals[c], 2));
            sheet.append("</row>");
        }
        int[] widths = {10, 46, 13, 10, 16, 40, 40, 30, 64, 52, 26};
        StringBuilder cols = new StringBuilder("<cols>");
        for (int i = 0; i < widths.length; i++)
            cols.append("<col min=\"").append(i + 1).append("\" max=\"").append(i + 1)
                .append("\" width=\"").append(widths[i]).append("\" customWidth=\"1\"/>");
        cols.append("</cols>");

        String worksheet =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<sheetViews><sheetView workbookViewId=\"0\" showGridLines=\"0\">" +
            "<pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>" +
            "<sheetFormatPr defaultRowHeight=\"15\"/>" + cols +
            "<sheetData>" + sheet + "</sheetData>" +
            "<autoFilter ref=\"A1:" + col(HEADERS.length) + (cases.size() + 1) + "\"/></worksheet>";

        String styles =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"3\"><font><sz val=\"10\"/><name val=\"Calibri\"/></font>" +
            "<font><b/><sz val=\"10\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font>" +
            "<font><sz val=\"10\"/><color rgb=\"FF1B2733\"/><name val=\"Calibri\"/></font></fonts>" +
            "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill>" +
            "<fill><patternFill patternType=\"gray125\"/></fill>" +
            "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0B2545\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
            "<borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border>" +
            "<border><left style=\"thin\"><color rgb=\"FFD8DEE6\"/></left><right style=\"thin\"><color rgb=\"FFD8DEE6\"/></right>" +
            "<top style=\"thin\"><color rgb=\"FFD8DEE6\"/></top><bottom style=\"thin\"><color rgb=\"FFD8DEE6\"/></bottom><diagonal/></border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\">" +
            "<alignment horizontal=\"left\" vertical=\"center\" wrapText=\"1\"/></xf>" +
            "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\" applyAlignment=\"1\">" +
            "<alignment vertical=\"top\" wrapText=\"1\"/></xf></cellXfs>" +
            "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>";

        String workbook =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
            "<sheets><sheet name=\"Test Cases\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";

        String wbRels =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>";

        String rootRels =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>";

        String contentTypes =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
            "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
            "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>";

        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            put(z, "[Content_Types].xml", contentTypes);
            put(z, "_rels/.rels", rootRels);
            put(z, "xl/workbook.xml", workbook);
            put(z, "xl/_rels/workbook.xml.rels", wbRels);
            put(z, "xl/styles.xml", styles);
            put(z, "xl/worksheets/sheet1.xml", worksheet);
        }
    }

    private static void put(ZipOutputStream z, String name, String body) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(body.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    private static String cell(String ref, String text, int style) {
        return "<c r=\"" + ref + "\" t=\"inlineStr\" s=\"" + style + "\"><is><t xml:space=\"preserve\">"
                + xesc(text) + "</t></is></c>";
    }

    private static String col(int n) {
        StringBuilder s = new StringBuilder();
        while (n > 0) { int m = (n - 1) % 26; s.insert(0, (char) ('A' + m)); n = (n - m - 1) / 26; }
        return s.toString();
    }

    private static String xesc(String v) {
        if (v == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : v.toCharArray()) {
            if (c < 0x20 && c != '\n' && c != '\t') continue;
            switch (c) {
                case '&': sb.append("&amp;"); break;
                case '<': sb.append("&lt;"); break;
                case '>': sb.append("&gt;"); break;
                case '"': sb.append("&quot;"); break;
                default: sb.append(c);
            }
        }
        return sb.toString();
    }

    // ── CSV (Excel-friendly, BOM + CRLF) ──────────────────────────────
    public static void csv(List<TestCase> cases, File file) throws IOException {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
            w.write('\ufeff');
            w.write(String.join(",", quoteAll(HEADERS)) + "\r\n");
            for (TestCase t : cases) w.write(String.join(",", quoteAll(row(t))) + "\r\n");
        }
    }
    private static String[] quoteAll(String[] vals) {
        String[] q = new String[vals.length];
        for (int i = 0; i < vals.length; i++)
            q[i] = '"' + (vals[i] == null ? "" : vals[i]).replace("\"", "\"\"") + '"';
        return q;
    }

    // ── JSON ──────────────────────────────────────────────────────────
    public static void json(List<TestCase> cases, File file) throws IOException {
        StringBuilder sb = new StringBuilder("[\n");
        for (int i = 0; i < cases.size(); i++) {
            TestCase t = cases.get(i);
            sb.append("  {\n")
              .append(f("id", t.id)).append(f("title", t.title)).append(f("type", t.type))
              .append(f("priority", t.priority)).append(f("sourceDoc", t.sourceDoc))
              .append(f("requirement", t.requirement)).append(f("preconditions", t.preconditions))
              .append(f("testData", t.testData)).append("    \"steps\": [");
            for (int s = 0; s < t.steps.size(); s++) {
                if (s > 0) sb.append(", ");
                sb.append('"').append(jesc(t.steps.get(s))).append('"');
            }
            sb.append("],\n").append(f("expected", t.expected))
              .append("    \"tags\": [\"").append(String.join("\", \"", t.tags)).append("\"]\n")
              .append("  }").append(i < cases.size() - 1 ? ",\n" : "\n");
        }
        sb.append("]\n");
        write(file, sb.toString());
    }
    private static String f(String k, String v) { return "    \"" + k + "\": \"" + jesc(v) + "\",\n"; }
    private static String jesc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "").replace("\t", "\\t");
    }

    // ── Markdown ──────────────────────────────────────────────────────
    public static void markdown(List<TestCase> cases, File file) throws IOException {
        StringBuilder sb = new StringBuilder("# Test Cases\n\n");
        for (TestCase t : cases) {
            sb.append("## ").append(t.id).append(" \u2014 ").append(t.title).append("\n\n")
              .append("**Type:** ").append(t.type).append(" \u00b7 **Priority:** ").append(t.priority).append("\n\n")
              .append("**Requirement:** ").append(t.requirement).append("\n\n");
            if (!t.preconditions.isEmpty()) sb.append("**Preconditions:** ").append(t.preconditions).append("\n\n");
            if (!t.testData.isEmpty()) sb.append("**Test data:** ").append(t.testData).append("\n\n");
            sb.append("**Steps**\n\n");
            for (int i = 0; i < t.steps.size(); i++) sb.append(i + 1).append(". ").append(t.steps.get(i)).append('\n');
            sb.append("\n**Expected result:** ").append(t.expected).append("\n\n---\n\n");
        }
        write(file, sb.toString());
    }

    // ── plain text ────────────────────────────────────────────────────
    public static void text(List<TestCase> cases, File file) throws IOException {
        write(file, plain(cases));
    }
    public static String plain(List<TestCase> cases) {
        StringBuilder sb = new StringBuilder();
        for (TestCase t : cases) {
            sb.append(t.id).append(" \u2014 ").append(t.title).append('\n')
              .append("Type: ").append(t.type).append("   Priority: ").append(t.priority).append('\n')
              .append("Requirement: ").append(t.requirement).append('\n');
            if (!t.preconditions.isEmpty()) sb.append("Preconditions: ").append(t.preconditions).append('\n');
            if (!t.testData.isEmpty()) sb.append("Test data: ").append(t.testData).append('\n');
            sb.append("Steps:\n");
            for (int i = 0; i < t.steps.size(); i++) sb.append("  ").append(i + 1).append(". ").append(t.steps.get(i)).append('\n');
            sb.append("Expected: ").append(t.expected).append("\n\n");
        }
        return sb.toString();
    }

    private static void write(File f, String s) throws IOException {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) { w.write(s); }
    }
}
