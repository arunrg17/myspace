package com.rtcc.service;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/** Credential check for the API-key dialog. Generation itself stays offline. */
public final class AiService {

    private AiService() {}

    /** Copilot deployments are per-tenant, so the endpoint is configurable. */
    public static String endpoint(String provider, String custom) {
        if ("copilot".equals(provider)) {
            return (custom == null || custom.trim().isEmpty())
                    ? "https://api.githubcopilot.com/chat/completions" : custom.trim();
        }
        return endpoint(provider);
    }

    public static String endpoint(String provider) {
        switch (provider) {
            case "copilot": return "https://api.githubcopilot.com/chat/completions";
            case "openai": return "https://api.openai.com/v1/chat/completions";
            case "gemini": return "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";
            default:       return "https://api.anthropic.com/v1/messages";
        }
    }

    public static String testConnection(String provider, String key) {
        return testConnection(provider, key, null);
    }

    public static String testConnection(String provider, String key, String customEndpoint) {
        try {
            String url = endpoint(provider, customEndpoint);
            if ("gemini".equals(provider)) url += "?key=" + key;
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(12000);
            c.setReadTimeout(20000);
            c.setRequestProperty("Content-Type", "application/json");
            if ("anthropic".equals(provider)) {
                c.setRequestProperty("x-api-key", key);
                c.setRequestProperty("anthropic-version", "2023-06-01");
            } else if ("openai".equals(provider)) {
                c.setRequestProperty("Authorization", "Bearer " + key);
            } else if ("copilot".equals(provider)) {
                // GitHub Copilot uses a bearer token; Azure-hosted Copilot uses api-key.
                // Sending both keeps one dialog working for either deployment.
                c.setRequestProperty("Authorization", "Bearer " + key);
                c.setRequestProperty("api-key", key);
                c.setRequestProperty("Copilot-Integration-Id", "rtcc");
            }
            try (OutputStream os = c.getOutputStream()) {
                os.write(probe(provider).getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            if (code >= 200 && code < 300) return "OK";
            if (code == 401 || code == 403) return "Key rejected (HTTP " + code + ")";
            if (code == 429) return "Rate limited (HTTP 429) - the key itself looks valid";
            String err = read(c.getErrorStream());
            return "HTTP " + code + (err.isEmpty() ? "" : ": " + err.substring(0, Math.min(160, err.length())));
        } catch (Exception e) {
            return "No connection: " + e.getMessage();
        }
    }

    private static String probe(String provider) {
        switch (provider) {
            case "copilot": return "{\"model\":\"gpt-4o-mini\",\"max_tokens\":1,\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}";
            case "openai": return "{\"model\":\"gpt-4o-mini\",\"max_tokens\":1,\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}";
            case "gemini": return "{\"contents\":[{\"parts\":[{\"text\":\"hi\"}]}]}";
            default:       return "{\"model\":\"claude-3-5-haiku-20241022\",\"max_tokens\":1,\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}";
        }
    }

    private static String read(java.io.InputStream in) {
        if (in == null) return "";
        try (Scanner s = new Scanner(in, StandardCharsets.UTF_8.name()).useDelimiter("\\A")) {
            return s.hasNext() ? s.next() : "";
        }
    }
}
