package com.rtcc.util;

import java.util.prefs.Preferences;

/** Small wrapper over the Java Preferences store (API key, provider, theme). */
public final class Prefs {
    private static final Preferences P = Preferences.userRoot().node("com/rtcc");

    private Prefs() {}

    public static String apiKey()         { return P.get("api-key", ""); }
    public static void apiKey(String v)   { P.put("api-key", v == null ? "" : v); }
    public static String provider()       { return P.get("provider", "copilot"); }
    public static void provider(String v) { P.put("provider", v); }
    public static boolean dark()          { return P.getBoolean("dark", false); }
    public static void dark(boolean v)    { P.putBoolean("dark", v); }
    public static void clearKey()         { P.remove("api-key"); }
    public static String endpoint()       { return P.get("endpoint", ""); }
    public static void endpoint(String v) { P.put("endpoint", v == null ? "" : v.trim()); }
}
