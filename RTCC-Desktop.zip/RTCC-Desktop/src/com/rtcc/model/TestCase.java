package com.rtcc.model;

import java.util.ArrayList;
import java.util.List;

/** One generated test case, in IEEE-829 shape. */
public class TestCase {
    public String id = "";
    public String title = "";
    public String type = "Functional";
    public String priority = "MEDIUM";
    public String sourceDoc = "";
    public String requirement = "";
    public String preconditions = "";
    public String testData = "";
    public List<String> steps = new ArrayList<>();
    public String expected = "";
    public List<String> tags = new ArrayList<>();

    public String stepsJoined(String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < steps.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(i + 1).append(". ").append(steps.get(i));
        }
        return sb.toString();
    }
}
