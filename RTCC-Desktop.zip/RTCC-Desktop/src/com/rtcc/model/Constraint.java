package com.rtcc.model;

import java.util.ArrayList;
import java.util.List;

/**
 * A rule extracted from a requirement.
 * kind: time-window | money | count | threshold | length | lockout | sla | display | exclusive
 */
public class Constraint {
    public String kind;

    // time-window
    public List<int[]> allowed = new ArrayList<>();      // {loMinute, hiMinute}
    public List<String> allowedLabels = new ArrayList<>();
    public int[] forbidden;                              // {loMinute, hiMinute}
    public String forbiddenLabel;
    public List<int[]> bounds = new ArrayList<>();       // {insideMinute, outsideMinute}

    // numeric
    public String dir;               // "min" | "max"
    public double value;
    public String unit;
    public String subject;

    public int attempts;             // lockout
    public String slaValue, slaUnit; // sla
    public String what, trigger;     // display
    public String group;             // exclusive

    // performance shapes
    public int    people;            // concurrency: how many users/sessions
    public String people_unit;
    public String item, per;         // throughput: item + time unit
    public int    count;             // volume: how many records
    public String window, windowUnit;// batch window
    public String pct;               // availability

    public Constraint(String kind) { this.kind = kind; }
}
