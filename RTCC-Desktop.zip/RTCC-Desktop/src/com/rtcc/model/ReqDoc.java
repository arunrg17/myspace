package com.rtcc.model;

/** A requirement document: a name and its pasted or loaded text. */
public class ReqDoc {
    public String name;
    public String content;

    public ReqDoc(String name, String content) {
        this.name = name;
        this.content = content == null ? "" : content;
    }

    public boolean hasContent() { return content != null && !content.trim().isEmpty(); }

    @Override public String toString() { return name; }
}
