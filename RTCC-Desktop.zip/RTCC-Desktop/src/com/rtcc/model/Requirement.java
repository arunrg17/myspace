package com.rtcc.model;

import java.util.ArrayList;
import java.util.List;

/** A requirement statement after semantic analysis. */
public class Requirement {
    public String id;
    public String raw;
    public String actor;
    public String action;
    public boolean prohibit;
    public boolean integration;
    public boolean secTransport, secStorage, secSession, secAuthz, secInjection, secAudit, secAuth;
    public String sourceDoc = "";
    public List<Constraint> constraints = new ArrayList<>();

    public Constraint find(String kind) {
        for (Constraint c : constraints) if (c.kind.equals(kind)) return c;
        return null;
    }
    public boolean has(String kind) { return find(kind) != null; }
}
