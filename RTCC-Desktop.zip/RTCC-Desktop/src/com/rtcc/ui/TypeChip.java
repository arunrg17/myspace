package com.rtcc.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Selectable test-type chip, styled like the web app's toggle buttons. */
public class TypeChip extends JLabel {

    private boolean on;
    private final String value;

    public TypeChip(String value, boolean on) {
        super(value, SwingConstants.CENTER);
        this.value = value;
        this.on = on;
        setFont(Theme.SMALL);
        setOpaque(true);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        restyle();
        addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { setSelected(!TypeChip.this.on); }
        });
    }

    public String value() { return value; }
    public boolean isSelected() { return on; }
    public void setSelected(boolean b) { on = b; restyle(); }

    private void restyle() {
        setBackground(on ? Theme.ACCENT : Theme.surface());
        setForeground(on ? Color.WHITE : Theme.muted());
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(on ? Theme.ACCENT : Theme.border2()),
                Theme.pad(6, 10, 6, 10)));
    }
}
