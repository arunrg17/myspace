package com.rtcc.ui;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

/**
 * Palette and shared styling, mirroring the web app's corporate theme.
 * Colours are applied explicitly to every component: the Windows look-and-feel
 * ignores setBackground on several controls, which is what made text invisible.
 */
public final class Theme {

    public static boolean dark = false;

    // corporate light (default) — matches the HTML build
    private static final Color L_BG      = new Color(0xEEF1F5);
    private static final Color L_SURFACE = Color.WHITE;
    private static final Color L_SURF2   = new Color(0xF7F9FB);
    private static final Color L_BORDER  = new Color(0xDDE3EA);
    private static final Color L_BORDER2 = new Color(0xC8D2DD);
    private static final Color L_TEXT    = new Color(0x101828);
    private static final Color L_MUTED   = new Color(0x5B6B7F);

    private static final Color D_BG      = new Color(0x0C1420);
    private static final Color D_SURFACE = new Color(0x111C2B);
    private static final Color D_SURF2   = new Color(0x16232F);
    private static final Color D_BORDER  = new Color(0x22334A);
    private static final Color D_BORDER2 = new Color(0x2C405C);
    private static final Color D_TEXT    = new Color(0xE6ECF3);
    private static final Color D_MUTED   = new Color(0x93A3B8);

    public static final Color NAVY   = new Color(0x0B2545);
    public static final Color ACCENT = new Color(0x12437E);
    public static final Color ACCENT_HOV = new Color(0x0E365F);
    public static final Color OK     = new Color(0x0F7A52);
    public static final Color WARN   = new Color(0xB06A00);
    public static final Color DANGER = new Color(0xB42318);
    public static final Color PURPLE = new Color(0x6D28D9);

    public static Color bg()      { return dark ? D_BG : L_BG; }
    public static Color surface() { return dark ? D_SURFACE : L_SURFACE; }
    public static Color surface2(){ return dark ? D_SURF2 : L_SURF2; }
    public static Color border()  { return dark ? D_BORDER : L_BORDER; }
    public static Color border2() { return dark ? D_BORDER2 : L_BORDER2; }
    public static Color text()    { return dark ? D_TEXT : L_TEXT; }
    public static Color muted()   { return dark ? D_MUTED : L_MUTED; }
    public static Color navyBar() { return dark ? new Color(0x0A1725) : NAVY; }

    public static final Font H1     = ui(Font.BOLD, 17);
    public static final Font H2     = ui(Font.BOLD, 13);
    public static final Font LABEL  = ui(Font.BOLD, 11);
    public static final Font BODY   = ui(Font.PLAIN, 13);
    public static final Font SMALL  = ui(Font.PLAIN, 12);
    public static final Font TINY   = ui(Font.BOLD, 10);
    public static final Font MONO   = mono(Font.PLAIN, 12);
    public static final Font MONO_B = mono(Font.BOLD, 12);

    private Theme() {}

    private static Font ui(int style, int size) {
        return pick(new String[]{"Inter", "Segoe UI", "Helvetica Neue", "DejaVu Sans"}, Font.SANS_SERIF, style, size);
    }
    private static Font mono(int style, int size) {
        return pick(new String[]{"IBM Plex Mono", "Consolas", "Menlo", "DejaVu Sans Mono"}, Font.MONOSPACED, style, size);
    }
    /** Enumerating font families is expensive; do it once, not once per font. */
    private static String[] families;
    private static String[] families() {
        if (families == null) {
            try {
                families = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
            } catch (Throwable t) {
                families = new String[0];
            }
        }
        return families;
    }

    private static Font pick(String[] prefer, String fallback, int style, int size) {
        String[] avail = families();
        for (String p : prefer)
            for (String a : avail)
                if (a.equalsIgnoreCase(p)) return new Font(a, style, size);
        return new Font(fallback, style, size);
    }

    public static Border pad(int t, int l, int b, int r) { return BorderFactory.createEmptyBorder(t, l, b, r); }
    public static Border line() { return BorderFactory.createLineBorder(border()); }

    /** Text components need every colour set explicitly, or the OS L&F wins. */
    public static void styleText(JTextComponentHolder h) { /* marker */ }

    public static void applyTextColours(javax.swing.text.JTextComponent c, boolean monospace) {
        c.setBackground(surface());
        c.setForeground(text());
        c.setCaretColor(text());
        c.setSelectionColor(new Color(0xC7DAF3));
        c.setSelectedTextColor(new Color(0x101828));
        c.setFont(monospace ? MONO : BODY);
        c.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(border2()), pad(8, 10, 8, 10)));
        c.setOpaque(true);
    }

    public static JLabel label(String s, Font f, Color c) {
        JLabel l = new JLabel(s);
        l.setFont(f);
        l.setForeground(c);
        return l;
    }

    public static JLabel sectionLabel(String s) {
        return label(s.toUpperCase(), LABEL, muted());
    }

    public static JButton button(String text, boolean primary) {
        JButton b = new JButton(text);
        b.setFont(ui(Font.BOLD, 12));
        b.setFocusPainted(false);
        b.setBorderPainted(true);
        b.setContentAreaFilled(false);
        b.setOpaque(true);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        final Color base  = primary ? ACCENT : surface();
        final Color hov   = primary ? ACCENT_HOV : surface2();
        final Color fg    = primary ? Color.WHITE : text();
        b.setBackground(base);
        b.setForeground(fg);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(primary ? ACCENT : border2()), pad(8, 16, 8, 16)));
        b.addChangeListener(e -> b.setBackground(b.getModel().isRollover() ? hov : base));
        return b;
    }

    public interface JTextComponentHolder {}
}
