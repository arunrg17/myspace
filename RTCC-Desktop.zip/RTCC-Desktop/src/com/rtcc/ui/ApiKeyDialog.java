package com.rtcc.ui;

import com.rtcc.service.AiService;
import com.rtcc.util.Prefs;

import javax.swing.*;
import java.awt.*;

/** API key modal — the same fields and behaviour as the web app's key dialog. */
public class ApiKeyDialog extends JDialog {

    private final JComboBox<String> provider = new JComboBox<>(new String[]{
            "Copilot (GitHub / Azure)", "Anthropic (Claude)", "OpenAI (GPT)", "Google (Gemini)"});
    private final JTextField endpointField = new JTextField();
    private final JPasswordField keyField = new JPasswordField();
    private final JToggleButton reveal = new JToggleButton("Show");
    private final JLabel status = new JLabel(" ");
    private boolean changed = false;

    public ApiKeyDialog(Window owner) {
        super(owner, "API Key", ModalityType.APPLICATION_MODAL);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Theme.surface());

        JPanel head = new JPanel(new BorderLayout());
        head.setBackground(Theme.navyBar());
        head.setBorder(Theme.pad(14, 18, 14, 18));
        head.add(Theme.label("API Key", Theme.H1, Color.WHITE), BorderLayout.WEST);
        add(head, BorderLayout.NORTH);

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(Theme.surface());
        body.setBorder(Theme.pad(16, 18, 8, 18));

        body.add(left(Theme.sectionLabel("Provider")));
        provider.setFont(Theme.BODY);
        provider.setBackground(Theme.surface());
        provider.setForeground(Theme.text());
        provider.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        provider.setAlignmentX(Component.LEFT_ALIGNMENT);
        provider.setSelectedIndex(idxOf(Prefs.provider()));
        provider.addActionListener(e -> {
            boolean copilot = providerId().equals("copilot");
            endpointField.setEnabled(copilot);
            endpointField.setBackground(copilot ? Theme.surface() : Theme.surface2());
        });
        body.add(provider);
        body.add(Box.createVerticalStrut(12));

        body.add(left(Theme.sectionLabel("Endpoint  \u00b7  Copilot / Azure only")));
        endpointField.setText(Prefs.endpoint());
        Theme.applyTextColours(endpointField, true);
        endpointField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        endpointField.setAlignmentX(Component.LEFT_ALIGNMENT);
        endpointField.setToolTipText("Leave blank for the default GitHub Copilot endpoint, "
                + "or paste your organisation's Azure deployment URL.");
        body.add(endpointField);
        body.add(Box.createVerticalStrut(12));

        body.add(left(Theme.sectionLabel("API key")));
        Theme.applyTextColours(keyField, true);
        keyField.setEchoChar('\u2022');
        keyField.setText(Prefs.apiKey());
        keyField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        reveal.setFont(Theme.SMALL);
        reveal.setFocusPainted(false);
        reveal.addActionListener(e -> {
            keyField.setEchoChar(reveal.isSelected() ? (char) 0 : '\u2022');
            reveal.setText(reveal.isSelected() ? "Hide" : "Show");
        });

        JPanel keyRow = new JPanel(new BorderLayout(8, 0));
        keyRow.setBackground(Theme.surface());
        keyRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        keyRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        keyRow.add(keyField, BorderLayout.CENTER);
        keyRow.add(reveal, BorderLayout.EAST);
        body.add(keyRow);
        body.add(Box.createVerticalStrut(6));

        JLabel hint = Theme.label(
            "<html><body style='width:530px'>Stored locally on this machine only. "
          + "Leave it empty to stay in offline mode — the built-in engine needs no key.</body></html>",
            Theme.SMALL, Theme.muted());
        body.add(left(hint));
        body.add(Box.createVerticalStrut(10));

        status.setFont(Theme.SMALL);
        status.setForeground(Theme.muted());
        body.add(left(status));
        add(body, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 10));
        buttons.setBackground(Theme.surface2());
        JButton test = Theme.button("Test connection", false);
        JButton clear = Theme.button("Clear key", false);
        JButton save = Theme.button("Save", true);
        JButton cancel = Theme.button("Cancel", false);

        test.addActionListener(e -> {
            String k = new String(keyField.getPassword()).trim();
            if (k.isEmpty()) { status.setText("Enter a key first."); status.setForeground(Theme.WARN); return; }
            status.setText("Testing…"); status.setForeground(Theme.muted());
            test.setEnabled(false);
            new SwingWorker<String, Void>() {
                @Override protected String doInBackground() {
                    return AiService.testConnection(providerId(), k, endpointField.getText());
                }
                @Override protected void done() {
                    String r;
                    try { r = get(); } catch (Exception ex) { r = "Failed: " + ex.getMessage(); }
                    boolean ok = r.startsWith("OK") || r.contains("looks valid");
                    status.setText(ok ? "Connection OK — the key works." : r);
                    status.setForeground(ok ? Theme.OK : Theme.DANGER);
                    test.setEnabled(true);
                }
            }.execute();
        });

        clear.addActionListener(e -> {
            keyField.setText("");
            Prefs.clearKey();
            changed = true;
            status.setText("Key cleared — running in offline mode.");
            status.setForeground(Theme.OK);
        });

        save.addActionListener(e -> {
            Prefs.apiKey(new String(keyField.getPassword()).trim());
            Prefs.provider(providerId());
            Prefs.endpoint(endpointField.getText());
            changed = true;
            dispose();
        });
        cancel.addActionListener(e -> dispose());

        buttons.add(test); buttons.add(clear); buttons.add(cancel); buttons.add(save);
        add(buttons, BorderLayout.SOUTH);

        setSize(580, 470);
        setLocationRelativeTo(owner);
    }

    private static Component left(JComponent c) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Theme.surface());
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, c.getPreferredSize().height + 8));
        p.add(c, BorderLayout.WEST);
        return p;
    }

    private String providerId() {
        switch (provider.getSelectedIndex()) {
            case 1:  return "anthropic";
            case 2:  return "openai";
            case 3:  return "gemini";
            default: return "copilot";
        }
    }
    private static int idxOf(String id) {
        if ("anthropic".equals(id)) return 1;
        if ("openai".equals(id))    return 2;
        if ("gemini".equals(id))    return 3;
        return 0;                                    // Copilot is the default
    }
    public boolean wasChanged() { return changed; }
}
