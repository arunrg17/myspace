package com.rtcc.ui;

import com.rtcc.model.ReqDoc;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

/** One requirement document: name field, text area, remove button — as in the web app. */
public class DocEditor extends JPanel {

    private final JTextField nameField = new JTextField();
    private final JTextArea area = new JTextArea();
    public final ReqDoc doc;

    public DocEditor(ReqDoc doc, int index, Consumer<DocEditor> onRemove) {
        this.doc = doc;
        setLayout(new BorderLayout(0, 8));
        setBackground(Theme.surface());
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.border()), Theme.pad(10, 10, 10, 10)));
        setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel top = new JPanel(new BorderLayout(8, 0));
        top.setBackground(Theme.surface());

        JLabel num = Theme.label(String.format("%02d", index), Theme.MONO_B, Color.WHITE);
        num.setOpaque(true);
        num.setBackground(Theme.ACCENT);
        num.setHorizontalAlignment(SwingConstants.CENTER);
        num.setPreferredSize(new Dimension(28, 26));

        nameField.setText(doc.name);
        nameField.setFont(Theme.BODY);
        nameField.setBackground(Theme.surface());
        nameField.setForeground(Theme.text());
        nameField.setCaretColor(Theme.text());
        nameField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.border2()), Theme.pad(5, 8, 5, 8)));

        JButton remove = Theme.button("Remove", false);
        remove.addActionListener(e -> onRemove.accept(this));

        top.add(num, BorderLayout.WEST);
        top.add(nameField, BorderLayout.CENTER);
        top.add(remove, BorderLayout.EAST);

        Theme.applyTextColours(area, true);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setRows(9);
        area.setText(doc.content);

        JScrollPane sp = new JScrollPane(area);
        sp.setBorder(BorderFactory.createLineBorder(Theme.border2()));
        sp.getViewport().setBackground(Theme.surface());
        sp.setPreferredSize(new Dimension(300, 170));

        add(top, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);
    }

    /** Copies the on-screen values back into the model. */
    public ReqDoc sync() {
        doc.name = nameField.getText().trim().isEmpty() ? doc.name : nameField.getText().trim();
        doc.content = area.getText();
        return doc;
    }

    public void setContent(String s) { area.setText(s); }

    @Override public Dimension getMaximumSize() {
        return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
    }
}
