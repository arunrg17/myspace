package com.rtcc.ui;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;

/**
 * Application mark.
 *
 * Drop your organisation's approved logo file next to RTCC.jar as logo.png
 * (or logo.gif / logo.jpg) and it is picked up automatically at start-up —
 * no rebuild needed. Use the official asset from your brand portal rather than
 * a redrawn copy, so the mark stays within your organisation's brand rules.
 *
 * If no file is present a neutral placeholder is shown instead.
 */
public final class Brand {

    private static final String[] CANDIDATES = {"logo.png", "logo.gif", "logo.jpg", "logo.jpeg"};

    private Brand() {}

    /** Header mark, scaled to the given height, keeping aspect ratio. */
    public static JComponent mark(int size) {
        BufferedImage img = load();
        if (img != null) {
            int w = Math.max(1, img.getWidth() * size / Math.max(1, img.getHeight()));
            JLabel l = new JLabel(new ImageIcon(img.getScaledInstance(w, size, Image.SCALE_SMOOTH)));
            l.setOpaque(false);
            l.setToolTipText("Logo loaded from " + foundPath());
            return l;
        }
        return placeholder(size);
    }

    /** Neutral mark used until a logo file is supplied. */
    private static JComponent placeholder(int size) {
        JLabel l = new JLabel("RTCC", SwingConstants.CENTER);
        l.setFont(new Font(Font.SANS_SERIF, Font.BOLD, Math.max(11, size / 3)));
        l.setForeground(Theme.navyBar());
        l.setOpaque(true);
        l.setBackground(Color.WHITE);
        l.setPreferredSize(new Dimension(size + 26, size));
        l.setToolTipText("<html>Place your approved <b>logo.png</b> next to RTCC.jar "
                + "to show your organisation's logo here.</html>");
        return l;
    }

    private static BufferedImage load() {
        for (File f : searchPaths()) {
            if (f.isFile() && f.canRead()) {
                try {
                    BufferedImage img = ImageIO.read(f);
                    if (img != null) return img;
                } catch (Exception ignored) { }
            }
        }
        // also allow a logo bundled inside the jar
        for (String n : CANDIDATES) {
            URL u = Brand.class.getResource("/" + n);
            if (u != null) {
                try {
                    BufferedImage img = ImageIO.read(u);
                    if (img != null) return img;
                } catch (Exception ignored) { }
            }
        }
        return null;
    }

    private static String foundPath() {
        for (File f : searchPaths()) if (f.isFile()) return f.getAbsolutePath();
        return "the application jar";
    }

    /** Looks beside the jar first, then in the working directory. */
    private static java.util.List<File> searchPaths() {
        java.util.List<File> out = new java.util.ArrayList<>();
        File base = null;
        try {
            File jar = new File(Brand.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            base = jar.isFile() ? jar.getParentFile() : jar;
        } catch (Exception ignored) { }
        for (String n : CANDIDATES) {
            if (base != null) out.add(new File(base, n));
            out.add(new File(System.getProperty("user.dir"), n));
        }
        return out;
    }
}
