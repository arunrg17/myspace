package com.rtcc.ui;

import com.rtcc.engine.Engine;
import com.rtcc.export.Exporters;
import com.rtcc.model.ReqDoc;
import com.rtcc.model.TestCase;
import com.rtcc.util.Prefs;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** RTCC desktop — same panels, controls and result cards as the web application. */
public class MainWindow extends JFrame {

    private final List<DocEditor> editors = new ArrayList<>();
    private final JPanel docStack = new JPanel();
    private final JTextArea flowArea = new JTextArea();
    private final JPanel flowBody = new JPanel(new BorderLayout());
    private final JButton flowToggle = Theme.button("Show", false);

    private final List<TypeChip> chips = new ArrayList<>();
    private final JComboBox<String> detailBox = new JComboBox<>(new String[]{"Brief", "Standard", "Detailed"});
    private final JComboBox<String> maxBox = new JComboBox<>(new String[]{"10", "20", "30", "50"});

    private final JPanel cardStack = new JPanel();
    private final JPanel statsBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
    private final JPanel tabBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
    private final JLabel banner = new JLabel(" ");
    private final JLabel statusPill = new JLabel();
    private final JPanel resultsPanel = new JPanel(new BorderLayout(0, 10));

    private List<TestCase> results = new ArrayList<>();
    private String filter = "All";
    private int docCounter = 0;

    public MainWindow() {
        super("RTCC \u2014 Requirement-to-Test Case Compiler");
        Theme.dark = Prefs.dark();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1240, 780));
        buildUi();
        addDocument();
        setLocationRelativeTo(null);
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Theme.bg());
        root.add(header(), BorderLayout.NORTH);

        JScrollPane leftScroll = new JScrollPane(leftColumn());
        leftScroll.setBorder(null);
        leftScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        leftScroll.getVerticalScrollBar().setUnitIncrement(16);
        leftScroll.getViewport().setBackground(Theme.bg());
        leftScroll.setPreferredSize(new Dimension(600, 100));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftScroll, rightColumn());
        split.setDividerLocation(600);
        split.setBorder(Theme.pad(14, 14, 10, 14));
        split.setBackground(Theme.bg());
        root.add(split, BorderLayout.CENTER);
        root.add(statusBar(), BorderLayout.SOUTH);

        setContentPane(root);
    }

    // ── header, with a clickable status pill ──────────────────────────
    private JComponent header() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(Theme.navyBar());
        bar.setBorder(Theme.pad(12, 22, 12, 22));

        JComponent mark = Brand.mark(38);   // logo.png beside the jar, else a neutral mark

        JPanel titles = new JPanel();
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.setOpaque(false);
        titles.add(Theme.label("RTCC   |   Quality Engineering", Theme.H1, Color.WHITE));
        titles.add(Box.createVerticalStrut(2));
        titles.add(Theme.label("Requirement-to-Test Case Compiler \u00b7 End-to-end test design",
                Theme.SMALL, new Color(255, 255, 255, 170)));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        left.setOpaque(false);
        left.add(mark);
        left.add(titles);

        refreshStatusPill();
        statusPill.setCursor(new Cursor(Cursor.HAND_CURSOR));
        statusPill.setToolTipText("Click to add or change the API key");
        statusPill.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { openApiKeyDialog(); }
        });

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);
        right.add(statusPill);

        bar.add(left, BorderLayout.WEST);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    private void refreshStatusPill() {
        boolean offline = Prefs.apiKey().trim().isEmpty();
        statusPill.setText(offline ? "  \u25cf  OFFLINE MODE  " : "  \u25cf  AI POWERED  ");
        statusPill.setFont(Theme.LABEL);
        statusPill.setOpaque(false);
        statusPill.setForeground(offline ? new Color(0xF5C26B) : new Color(0x86E3B5));
        statusPill.setBorder(BorderFactory.createLineBorder(
                offline ? new Color(0xF5C26B) : new Color(0x86E3B5)));
    }

    private void openApiKeyDialog() {
        ApiKeyDialog d = new ApiKeyDialog(this);
        d.setVisible(true);
        if (d.wasChanged()) {
            refreshStatusPill();
            say(Prefs.apiKey().trim().isEmpty()
                    ? "Offline mode \u2014 test cases are generated by the built-in engine."
                    : "API key saved. The offline engine still runs if the service cannot be reached.", false);
        }
    }

    // ── left column ───────────────────────────────────────────────────
    private JComponent leftColumn() {
        JPanel col = new JPanel();
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        col.setBackground(Theme.bg());
        col.setBorder(Theme.pad(0, 0, 0, 8));

        // flow diagram, collapsed by default like the web app
        Theme.applyTextColours(flowArea, true);
        flowArea.setLineWrap(true);
        flowArea.setWrapStyleWord(true);
        flowArea.setRows(7);
        JScrollPane fs = new JScrollPane(flowArea);
        fs.setBorder(BorderFactory.createLineBorder(Theme.border2()));
        fs.getViewport().setBackground(Theme.surface());
        flowBody.setBackground(Theme.surface());
        flowBody.setBorder(Theme.pad(12, 12, 12, 12));
        flowBody.add(fs, BorderLayout.CENTER);
        flowBody.setVisible(false);

        flowToggle.addActionListener(e -> {
            flowBody.setVisible(!flowBody.isVisible());
            flowToggle.setText(flowBody.isVisible() ? "Hide" : "Show");
            revalidate(); repaint();
        });
        col.add(card("Flow diagram  \u00b7  optional, drives the E2E case", flowBody, flowToggle));
        col.add(Box.createVerticalStrut(12));

        // requirement documents
        docStack.setLayout(new BoxLayout(docStack, BoxLayout.Y_AXIS));
        docStack.setBackground(Theme.surface());

        JButton add = Theme.button("+ Add requirement document", false);
        add.addActionListener(e -> addDocument());
        JButton load = Theme.button("Load file", false);
        load.addActionListener(e -> loadFiles());
        JButton example = Theme.button("Example", false);
        example.addActionListener(e -> loadExample());

        JPanel docBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        docBtns.setBackground(Theme.surface());
        docBtns.add(add); docBtns.add(load); docBtns.add(example);

        JPanel docWrap = new JPanel(new BorderLayout(0, 10));
        docWrap.setBackground(Theme.surface());
        docWrap.setBorder(Theme.pad(12, 12, 12, 12));
        docWrap.add(docStack, BorderLayout.CENTER);
        docWrap.add(docBtns, BorderLayout.SOUTH);
        col.add(card("Requirement documents", docWrap, null));
        col.add(Box.createVerticalStrut(12));

        // settings
        JPanel chipGrid = new JPanel(new GridLayout(0, 2, 6, 6));
        chipGrid.setBackground(Theme.surface());
        String[] types = {"Functional", "Negative", "Boundary", "Security", "Performance", "Integration", "E2E", "Regression"};
        boolean[] on  = {true, true, true, true, true, false, true, false};
        for (int i = 0; i < types.length; i++) {
            TypeChip c = new TypeChip(types[i], on[i]);
            chips.add(c);
            chipGrid.add(c);
        }

        styleCombo(detailBox); styleCombo(maxBox);
        detailBox.setSelectedItem("Standard");
        maxBox.setSelectedItem("20");

        JPanel opts = new JPanel(new GridLayout(2, 2, 10, 4));
        opts.setBackground(Theme.surface());
        opts.add(Theme.sectionLabel("Detail level"));
        opts.add(Theme.sectionLabel("Max test cases"));
        opts.add(detailBox);
        opts.add(maxBox);

        JButton gen = Theme.button("Generate test cases", true);
        gen.setFont(new Font(gen.getFont().getName(), Font.BOLD, 14));
        gen.addActionListener(e -> generate());

        banner.setFont(Theme.SMALL);
        banner.setForeground(Theme.muted());
        banner.setBorder(Theme.pad(8, 0, 0, 0));

        JPanel setBody = new JPanel();
        setBody.setLayout(new BoxLayout(setBody, BoxLayout.Y_AXIS));
        setBody.setBackground(Theme.surface());
        setBody.setBorder(Theme.pad(12, 12, 12, 12));
        setBody.add(alignLeft(Theme.sectionLabel("Test types")));
        setBody.add(Box.createVerticalStrut(6));
        chipGrid.setAlignmentX(Component.LEFT_ALIGNMENT);
        setBody.add(chipGrid);
        setBody.add(Box.createVerticalStrut(12));
        opts.setAlignmentX(Component.LEFT_ALIGNMENT);
        opts.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        setBody.add(opts);
        setBody.add(Box.createVerticalStrut(12));
        gen.setAlignmentX(Component.LEFT_ALIGNMENT);
        gen.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        setBody.add(gen);
        banner.setAlignmentX(Component.LEFT_ALIGNMENT);
        setBody.add(banner);
        col.add(card("Generation settings", setBody, null));
        col.add(Box.createVerticalGlue());
        return col;
    }

    // ── right column: results ─────────────────────────────────────────
    private JComponent rightColumn() {
        cardStack.setLayout(new BoxLayout(cardStack, BoxLayout.Y_AXIS));
        cardStack.setBackground(Theme.surface());

        statsBar.setBackground(Theme.surface());
        tabBar.setBackground(Theme.surface());

        JScrollPane sp = new JScrollPane(cardStack);
        sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(BorderFactory.createLineBorder(Theme.border()));
        sp.getViewport().setBackground(Theme.surface());
        sp.getVerticalScrollBar().setUnitIncrement(16);

        JPanel head = new JPanel(new BorderLayout(0, 10));
        head.setBackground(Theme.surface());
        head.add(Theme.label("Generated test cases", Theme.H2, Theme.text()), BorderLayout.NORTH);
        JPanel meta = new JPanel(new BorderLayout(0, 8));
        meta.setBackground(Theme.surface());
        meta.add(statsBar, BorderLayout.NORTH);
        meta.add(tabBar, BorderLayout.SOUTH);
        head.add(meta, BorderLayout.CENTER);

        JPanel exportBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        exportBar.setBackground(Theme.surface());
        String[][] ex = {{"Export .xlsx", "xlsx"}, {"CSV", "csv"}, {"JSON", "json"},
                         {"Markdown", "md"}, {"Text", "txt"}, {"Copy all", "copy"}};
        for (String[] pair : ex) {
            JButton b = Theme.button(pair[0], "xlsx".equals(pair[1]));
            b.addActionListener(e -> export(pair[1]));
            exportBar.add(b);
        }

        resultsPanel.setBackground(Theme.surface());
        resultsPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.border()), Theme.pad(14, 14, 14, 14)));
        resultsPanel.add(head, BorderLayout.NORTH);
        resultsPanel.add(sp, BorderLayout.CENTER);
        resultsPanel.add(exportBar, BorderLayout.SOUTH);
        showEmptyState();
        return resultsPanel;
    }

    private JComponent statusBar() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Theme.surface2());
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Theme.border()), Theme.pad(6, 18, 6, 18)));
        p.add(Theme.label("Offline engine v3.2", Theme.SMALL, Theme.muted()), BorderLayout.WEST);
        p.add(Theme.label("Nothing leaves this machine unless an API key is set", Theme.SMALL, Theme.muted()),
              BorderLayout.EAST);
        return p;
    }

    private JComponent card(String title, JComponent body, JComponent headerControl) {
        JPanel head = new JPanel(new BorderLayout());
        head.setBackground(Theme.surface2());
        head.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.border()), Theme.pad(9, 12, 9, 12)));
        head.add(Theme.sectionLabel(title), BorderLayout.WEST);
        if (headerControl != null) head.add(headerControl, BorderLayout.EAST);

        JPanel c = new JPanel(new BorderLayout());
        c.setBackground(Theme.surface());
        c.setBorder(BorderFactory.createLineBorder(Theme.border()));
        c.add(head, BorderLayout.NORTH);
        c.add(body, BorderLayout.CENTER);
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        return c;
    }

    private static Component alignLeft(JComponent c) { c.setAlignmentX(Component.LEFT_ALIGNMENT); return c; }

    private void styleCombo(JComboBox<String> b) {
        b.setFont(Theme.BODY);
        b.setBackground(Theme.surface());
        b.setForeground(Theme.text());
        ((JComponent) b.getRenderer()).setOpaque(true);
    }

    // ── documents ─────────────────────────────────────────────────────
    private void addDocument() { addDocument("Requirements " + (++docCounter), ""); }

    private void addDocument(String name, String content) {
        ReqDoc d = new ReqDoc(name, content);
        DocEditor ed = new DocEditor(d, editors.size() + 1, this::removeDocument);
        editors.add(ed);
        docStack.add(ed);
        docStack.add(Box.createVerticalStrut(10));
        docStack.revalidate();
        docStack.repaint();
    }

    private void removeDocument(DocEditor ed) {
        if (editors.size() <= 1) { say("Keep at least one requirement document.", true); return; }
        editors.remove(ed);
        docStack.removeAll();
        for (DocEditor e : editors) { docStack.add(e); docStack.add(Box.createVerticalStrut(10)); }
        docStack.revalidate();
        docStack.repaint();
    }

    private void loadFiles() {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("Text files (*.txt, *.md, *.csv)", "txt", "md", "csv"));
        fc.setMultiSelectionEnabled(true);
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        for (File f : fc.getSelectedFiles()) {
            try {
                addDocument(f.getName(), new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            } catch (Exception ex) {
                say("Could not read " + f.getName() + ": " + ex.getMessage(), true);
            }
        }
    }

    private void loadExample() {
        flowArea.setText("1. Customer opens the app\n2. Adds items to the basket\n3. Goes to checkout\n4. Pays\n5. Order confirmed");
        if (!flowBody.isVisible()) { flowBody.setVisible(true); flowToggle.setText("Hide"); }
        editors.get(0).setContent(
            "Banking app the local German customers can login before 9 am and after 18 am and not others\n"
          + "FR-003: Account is locked after 3 failed login attempts\n"
          + "Minimum order is 10 euros and every time customer place order a thank you msg is displayed\n"
          + "The response should be in 10 sec\n"
          + "Customer passwords must be stored encrypted");
        revalidate(); repaint();
    }

    // ── generation ────────────────────────────────────────────────────
    private void generate() {
        List<ReqDoc> docs = new ArrayList<>();
        for (DocEditor e : editors) docs.add(e.sync());

        List<String> types = new ArrayList<>();
        for (TypeChip c : chips) if (c.isSelected()) types.add(c.value());
        if (types.isEmpty()) { say("Select at least one test type.", true); return; }

        boolean any = !flowArea.getText().trim().isEmpty();
        for (ReqDoc d : docs) any |= d.hasContent();
        if (!any) { say("Add at least one requirement, or a flow, before generating.", true); return; }

        final String flow = flowArea.getText();
        final String detail = (String) detailBox.getSelectedItem();
        final int max = Integer.parseInt((String) maxBox.getSelectedItem());
        say("Generating\u2026", false);
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

        new SwingWorker<List<TestCase>, Void>() {
            @Override protected List<TestCase> doInBackground() {
                return Engine.generate(flow, docs, types, detail, max);
            }
            @Override protected void done() {
                setCursor(Cursor.getDefaultCursor());
                try {
                    results = get();
                    filter = "All";
                    renderResults();
                    say("Generated " + results.size() + " test case" + (results.size() == 1 ? "" : "s") + ".", false);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    say("Generation failed: " + ex.getMessage(), true);
                }
            }
        }.execute();
    }

    private void renderResults() {
        Map<String, Integer> mix = new LinkedHashMap<>();
        for (TestCase t : results) mix.merge(t.type, 1, Integer::sum);

        statsBar.removeAll();
        statsBar.add(chip(results.size() + " total"));
        for (Map.Entry<String, Integer> e : mix.entrySet()) statsBar.add(chip(e.getKey() + " " + e.getValue()));

        tabBar.removeAll();
        tabBar.add(tab("All", results.size()));
        for (Map.Entry<String, Integer> e : mix.entrySet()) tabBar.add(tab(e.getKey(), e.getValue()));

        renderCards();
        statsBar.revalidate(); statsBar.repaint();
        tabBar.revalidate(); tabBar.repaint();
    }

    private void renderCards() {
        cardStack.setVisible(false);           // one layout pass, not one per card
        cardStack.removeAll();
        int shown = 0;
        for (TestCase t : results) {
            if (!"All".equals(filter) && !t.type.equals(filter)) continue;
            cardStack.add(new TestCaseCard(t));
            cardStack.add(Box.createVerticalStrut(7));
            shown++;
        }
        if (shown == 0) showEmptyState();
        cardStack.setVisible(true);
        cardStack.revalidate();
        cardStack.repaint();
    }

    private void showEmptyState() {
        cardStack.removeAll();
        JLabel l = Theme.label("No test cases yet \u2014 add requirements and press Generate.",
                               Theme.BODY, Theme.muted());
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        cardStack.add(Box.createVerticalStrut(40));
        cardStack.add(l);
    }

    private JLabel chip(String text) {
        JLabel l = Theme.label(text, Theme.SMALL, Theme.muted());
        l.setOpaque(true);
        l.setBackground(Theme.surface2());
        l.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Theme.border()), Theme.pad(5, 9, 5, 9)));
        return l;
    }

    /** Repaint tab highlighting in place instead of rebuilding the bar. */
    private void restyleTabs() {
        for (Component c : tabBar.getComponents()) {
            if (!(c instanceof JLabel)) continue;
            JLabel l = (JLabel) c;
            boolean active = String.valueOf(l.getClientProperty("tab")).equals(filter);
            l.setForeground(active ? Theme.ACCENT : Theme.muted());
            l.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 2, 0, active ? Theme.ACCENT : Theme.surface()),
                    Theme.pad(7, 11, 6, 11)));
        }
        tabBar.repaint();
    }

    private JLabel tab(String name, int count) {
        boolean active = filter.equals(name);
        JLabel l = Theme.label(name + " (" + count + ")", Theme.SMALL, active ? Theme.ACCENT : Theme.muted());
        l.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 2, 0, active ? Theme.ACCENT : Theme.surface()),
                Theme.pad(7, 11, 6, 11)));
        l.putClientProperty("tab", name);
        l.setCursor(new Cursor(Cursor.HAND_CURSOR));
        l.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                if (filter.equals(name)) return;
                filter = name;
                restyleTabs();
                renderCards();
            }
        });
        return l;
    }

    // ── exports ───────────────────────────────────────────────────────
    private void export(String kind) {
        if (results.isEmpty()) { say("Generate test cases first.", true); return; }
        if ("copy".equals(kind)) {
            Toolkit.getDefaultToolkit().getSystemClipboard()
                   .setContents(new java.awt.datatransfer.StringSelection(Exporters.plain(results)), null);
            say("Copied " + results.size() + " test cases to the clipboard.", false);
            return;
        }
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("RTCC-test-cases." + kind));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File f = fc.getSelectedFile();
        try {
            switch (kind) {
                case "xlsx": Exporters.xlsx(results, f); break;
                case "csv":  Exporters.csv(results, f); break;
                case "json": Exporters.json(results, f); break;
                case "md":   Exporters.markdown(results, f); break;
                default:     Exporters.text(results, f);
            }
            say("Saved " + f.getName(), false);
        } catch (Exception ex) {
            say("Export failed: " + ex.getMessage(), true);
        }
    }

    private void say(String msg, boolean bad) {
        banner.setText("<html><body style='width:400px'>" + msg + "</body></html>");
        banner.setForeground(bad ? Theme.DANGER : Theme.OK);
    }

    /** Rebuild the whole UI after a theme switch, keeping the current content. */
    private void rebuild() {
        List<ReqDoc> keep = new ArrayList<>();
        for (DocEditor e : editors) keep.add(e.sync());
        String flow = flowArea.getText();
        boolean flowOpen = flowBody.isVisible();
        List<String> selected = new ArrayList<>();
        for (TypeChip c : chips) if (c.isSelected()) selected.add(c.value());
        String detail = (String) detailBox.getSelectedItem();
        String max = (String) maxBox.getSelectedItem();

        editors.clear(); chips.clear(); docCounter = 0;
        docStack.removeAll();
        getContentPane().removeAll();
        buildUi();

        for (ReqDoc d : keep) addDocument(d.name, d.content);
        flowArea.setText(flow);
        if (flowOpen) { flowBody.setVisible(true); flowToggle.setText("Hide"); }
        for (TypeChip c : chips) c.setSelected(selected.contains(c.value()));
        detailBox.setSelectedItem(detail);
        maxBox.setSelectedItem(max);
        if (!results.isEmpty()) renderResults();
        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainWindow().setVisible(true));
    }
}
