package com.rtcc.ui;

import com.rtcc.model.TestCase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/** Collapsible test-case card, matching the web app's result cards. */
public class TestCaseCard extends JPanel {

    private final JPanel body = new JPanel();
    private boolean open = false;
    private final JLabel chevron = new JLabel("\u25be");
    private final TestCase tc;
    private boolean built = false;

    public TestCaseCard(TestCase t) {
        this.tc = t;
        setLayout(new BorderLayout());
        setBackground(Theme.surface());
        setBorder(BorderFactory.createLineBorder(Theme.border()));
        setAlignmentX(Component.LEFT_ALIGNMENT);

        // ── header row ──
        JPanel head = new JPanel(new BorderLayout(10, 0));
        head.setBackground(Theme.surface());
        head.setBorder(Theme.pad(10, 12, 10, 12));
        head.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JPanel badges = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        badges.setBackground(Theme.surface());
        badges.add(Theme.label(t.id, Theme.MONO_B, Theme.ACCENT));
        badges.add(badge(t.priority, "HIGH".equals(t.priority) ? Theme.DANGER : Theme.WARN));
        badges.add(badge(t.type, Theme.PURPLE));
        if (t.sourceDoc != null && !t.sourceDoc.isEmpty()) badges.add(badge(t.sourceDoc, Theme.muted()));

        JTextArea title = wrap(t.title, Theme.BODY, Theme.text());
        chevron.setForeground(Theme.muted());

        JPanel left = new JPanel(new BorderLayout(0, 4));
        left.setBackground(Theme.surface());
        left.add(badges, BorderLayout.NORTH);
        left.add(title, BorderLayout.CENTER);

        head.add(left, BorderLayout.CENTER);
        head.add(chevron, BorderLayout.EAST);
        head.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { toggle(); }
        });

        // ── expandable body: contents are built on first open, not up front.
        //    Building 50 card bodies eagerly is what made the UI feel sluggish. ──
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(Theme.surface());
        body.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Theme.border()), Theme.pad(12, 14, 14, 14)));
        body.setVisible(false);

        add(head, BorderLayout.NORTH);
        add(body, BorderLayout.CENTER);
    }

    private void buildBody() {
        if (built) return;
        built = true;
        TestCase t = tc;
        section("Requirement", t.requirement);
        if (t.preconditions != null && !t.preconditions.isEmpty()) section("Preconditions", t.preconditions);
        if (t.testData != null && !t.testData.isEmpty()) section("Test data", t.testData);

        body.add(Theme.sectionLabel("Steps"));
        body.add(Box.createVerticalStrut(6));
        for (int i = 0; i < t.steps.size(); i++) {
            JPanel row = new JPanel(new BorderLayout(9, 0));
            row.setBackground(Theme.surface());
            row.setAlignmentX(Component.LEFT_ALIGNMENT);
            JLabel n = Theme.label(String.valueOf(i + 1), Theme.MONO_B, Color.WHITE);
            n.setOpaque(true);
            n.setBackground(Theme.ACCENT);
            n.setHorizontalAlignment(SwingConstants.CENTER);
            n.setPreferredSize(new Dimension(22, 22));
            JPanel holder = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            holder.setBackground(Theme.surface());
            holder.add(n);
            row.add(holder, BorderLayout.WEST);
            row.add(wrap(t.steps.get(i), Theme.BODY, Theme.text()), BorderLayout.CENTER);
            body.add(row);
            body.add(Box.createVerticalStrut(4));
        }

        body.add(Box.createVerticalStrut(10));
        body.add(Theme.sectionLabel("Expected result"));
        body.add(Box.createVerticalStrut(5));
        JTextArea exp = wrap(t.expected, Theme.BODY, Theme.text());
        exp.setOpaque(true);
        exp.setBackground(Theme.surface2());
        exp.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 3, 0, 0, Theme.OK), Theme.pad(9, 10, 9, 10)));
        exp.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(exp);

        if (t.tags != null && !t.tags.isEmpty()) {
            body.add(Box.createVerticalStrut(10));
            JPanel tags = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
            tags.setBackground(Theme.surface());
            tags.setAlignmentX(Component.LEFT_ALIGNMENT);
            for (String tag : t.tags) tags.add(badge("#" + tag, Theme.muted()));
            tags.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
            body.add(tags);
        }

    }

    private void section(String label, String value) {
        body.add(Theme.sectionLabel(label));
        body.add(Box.createVerticalStrut(4));
        body.add(wrap(value, Theme.BODY, Theme.muted()));
        body.add(Box.createVerticalStrut(10));
    }

    private JLabel badge(String text, Color colour) {
        JLabel l = Theme.label(text, Theme.TINY, colour);
        l.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colour), Theme.pad(2, 6, 2, 6)));
        return l;
    }

    public void toggle() {
        open = !open;
        if (open) buildBody();
        body.setVisible(open);
        chevron.setText(open ? "\u25b4" : "\u25be");
        setBorder(BorderFactory.createLineBorder(open ? Theme.ACCENT : Theme.border()));
        revalidate();
        repaint();
    }

    /** Auto-wrapping read-only text that fits whatever width the card has. */
    private static JTextArea wrap(String text, Font font, Color fg) {
        JTextArea a = new JTextArea(text == null ? "" : text);
        a.setLineWrap(true);
        a.setWrapStyleWord(true);
        a.setEditable(false);
        a.setFocusable(false);
        a.setOpaque(false);
        a.setBorder(null);
        a.setFont(font);
        a.setForeground(fg);
        a.setAlignmentX(Component.LEFT_ALIGNMENT);
        return a;
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    @Override public Dimension getMaximumSize() {
        return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
    }
}
