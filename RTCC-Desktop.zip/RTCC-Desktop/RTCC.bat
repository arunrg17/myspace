@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RTCC - Requirement-to-Test Case Compiler
set "LOG=%~dp0RTCC-launch-log.txt"

echo RTCC launch log> "%LOG%"
echo Date: %date% %time%>> "%LOG%"
echo Folder: %~dp0>> "%LOG%"

echo.
echo   ============================================================
echo     RTCC - Requirement-to-Test Case Compiler
echo   ============================================================
echo.
echo   Folder: %~dp0
echo.

if not exist "%~dp0RTCC.jar" goto :nojar
echo   [ok] RTCC.jar found
echo RTCC.jar: found>> "%LOG%"

set "JAVA_EXE=%~dp0jre\bin\java.exe"
if exist "%JAVA_EXE%" goto :havejava
echo   [--] bundled jre\bin\java.exe NOT found, looking for system Java
echo bundled jre: missing>> "%LOG%"

set "JAVA_EXE=java"
where java.exe >nul 2>&1
if errorlevel 1 goto :nojava
echo   [ok] using Java from PATH
echo java: from PATH>> "%LOG%"
goto :run

:havejava
echo   [ok] using bundled Java runtime
echo java: bundled>> "%LOG%"

:run
echo.
echo   Starting RTCC. The application window will open shortly.
echo   Leave this window open while RTCC is running.
echo.
echo Launching: %JAVA_EXE%>> "%LOG%"
"%JAVA_EXE%" -jar "%~dp0RTCC.jar" 2>> "%LOG%"
if errorlevel 1 goto :failed
exit /b 0

:failed
echo.
echo   ------------------------------------------------------------
echo   RTCC could not start. The error is below and in
echo   RTCC-launch-log.txt next to this file.
echo   ------------------------------------------------------------
type "%LOG%"
echo.
pause
exit /b 1

:nojar
echo   [XX] RTCC.jar was NOT found in this folder.
echo.
echo   This almost always means the ZIP was not extracted.
echo   Do this:
echo     1. Right-click the downloaded .zip, choose Properties,
echo        tick Unblock if it is there, click OK.
echo     2. Right-click the .zip, choose "Extract All...", pick a folder.
echo     3. Open the extracted folder and double-click RTCC.bat there.
echo.
echo RTCC.jar: MISSING>> "%LOG%"
pause
exit /b 1

:nojava
echo   [XX] No Java runtime available.
echo.
echo   Fix it in one step: double-click  fetch-java.bat
echo   That downloads a private Java runtime into this folder
echo   ^(about 47 MB, nothing is installed into Windows^).
echo.
echo   Alternatives:
echo     - Install Temurin JRE 21 from https://adoptium.net
echo     - Or download the full RTCC release, runtime included.
echo.
echo java: NONE>> "%LOG%"
pause
exit /b 1
