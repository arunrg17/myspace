#!/usr/bin/env bash
# RTCC - Requirement-to-Test Case Compiler (macOS / Linux launcher)
cd "$(dirname "$0")" || exit 1

if command -v java >/dev/null 2>&1; then
  JAVA_EXE=java
elif [ -n "$JAVA_HOME" ] && [ -x "$JAVA_HOME/bin/java" ]; then
  JAVA_EXE="$JAVA_HOME/bin/java"
else
  echo "ERROR: Java was not found."
  echo "RTCC needs Java 11 or newer - install Temurin JRE 21 from https://adoptium.net"
  exit 1
fi

exec "$JAVA_EXE" -jar RTCC.jar "$@"
