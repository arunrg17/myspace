package com.apitest;

import com.apitest.dispatcher.SslConfig;
import org.junit.jupiter.api.Test;

import javax.net.ssl.SSLContext;

import static org.junit.jupiter.api.Assertions.*;

class SslConfigTest {

    @Test
    void emptyConfigReturnsNull() {
        assertNull(SslConfig.buildContext(""));
        assertNull(SslConfig.buildContext(null));
        assertNull(SslConfig.buildContext("   "));
    }

    @Test
    void verifyFalseEnablesTrustAll() {
        SSLContext ctx = SslConfig.buildContext("verify=false");
        assertNotNull(ctx);
        assertEquals("TLS", ctx.getProtocol());
        assertTrue(SslConfig.isVerifyDisabled("verify=false"));
        assertTrue(SslConfig.isVerifyDisabled("verify=no"));
        assertFalse(SslConfig.isVerifyDisabled("verify=true"));
        assertFalse(SslConfig.isVerifyDisabled(""));
    }

    @Test
    void missingFileThrowsClearError() {
        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> SslConfig.buildContext("trust_store=/no/such/file.jks; trust_password=x"));
        assertTrue(ex.getMessage().contains("SSL config failed"),
                "Error should be clearly attributed to SSL config: " + ex.getMessage());
    }

    @Test
    void caches() {
        SSLContext a = SslConfig.buildContext("verify=false");
        SSLContext b = SslConfig.buildContext("verify=false");
        assertSame(a, b, "Same config string should return cached context");
    }
}
