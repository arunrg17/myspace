package com.apitest.dispatcher;

import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.*;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Multi-protocol HTTP dispatcher.
 *
 * Handles auth header injection, content-type defaults, and response capture
 * for REST, SOAP, Fabric (Microsoft), and GCP endpoints.
 *
 * OAuth2 and service-account token acquisition are stubbed — wire in real
 * implementations (e.g. MSAL for Fabric, google-auth for GCP) in production.
 */
public class Dispatcher {

    private static final int DEFAULT_TIMEOUT_MS = 30_000;

    public static Response send(String protocol, String baseUrl, String endpoint,
                                String method, String body, Map<String, String> headers,
                                String authType, String authValue) {
        return send(protocol, baseUrl, endpoint, method, body, headers, authType, authValue, null);
    }

    public static Response send(String protocol, String baseUrl, String endpoint,
                                String method, String body, Map<String, String> headers,
                                String authType, String authValue, String sslConfig) {

        String url = composeUrl(baseUrl, endpoint);
        Map<String, String> finalHeaders = new LinkedHashMap<>(headers == null ? Map.of() : headers);
        finalHeaders.putAll(resolveAuth(authType, authValue));

        // Protocol-specific defaults
        if ("soap".equalsIgnoreCase(protocol)) {
            finalHeaders.putIfAbsent("Content-Type", "text/xml; charset=utf-8");
            finalHeaders.putIfAbsent("SOAPAction", "\"\"");
            method = "POST";
        } else if (body != null && !body.isEmpty()) {
            finalHeaders.putIfAbsent("Content-Type", "application/json");
        }

        long started = System.currentTimeMillis();
        Response resp = new Response();
        resp.url = url;

        RequestConfig config = RequestConfig.custom()
                .setConnectTimeout(DEFAULT_TIMEOUT_MS)
                .setSocketTimeout(DEFAULT_TIMEOUT_MS)
                .build();

        try (CloseableHttpClient client = buildClient(config, sslConfig)) {
            HttpRequestBase request = buildRequest(method, url);

            for (Map.Entry<String, String> e : finalHeaders.entrySet()) {
                request.addHeader(e.getKey(), e.getValue());
            }

            if (body != null && !body.isEmpty() && request instanceof HttpEntityEnclosingRequestBase entReq) {
                String ct = finalHeaders.getOrDefault("Content-Type", "application/json");
                entReq.setEntity(new ByteArrayEntity(body.getBytes(StandardCharsets.UTF_8),
                                                   ContentType.parse(ct)));
            }

            var response = client.execute(request);
            try {
                resp.status = response.getStatusLine().getStatusCode();
                resp.headers = new HashMap<>();
                for (var h : response.getAllHeaders()) {
                    resp.headers.put(h.getName(), h.getValue());
                }
                resp.body = response.getEntity() == null ? ""
                        : EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            } finally {
                response.close();
            }
        } catch (Exception ex) {
            resp.error = ex.getClass().getSimpleName() + ": " + ex.getMessage();
        }

        resp.elapsedMs = System.currentTimeMillis() - started;
        return resp;
    }

    // ------------------------------------------------------------------

    /**
     * Builds an HttpClient with SSL configured per the env's SslConfig.
     * If sslConfig is null/empty, uses the JVM default trust store.
     */
    private static CloseableHttpClient buildClient(RequestConfig config, String sslConfig) {
        var builder = HttpClients.custom().setDefaultRequestConfig(config);

        if (sslConfig != null && !sslConfig.isBlank()) {
            SSLContext ctx = SslConfig.buildContext(sslConfig);
            if (ctx != null) {
                // When verify=false, also skip hostname verification — otherwise
                // a CN/SAN mismatch will still fail even with TrustAllManager.
                var hostnameVerifier = SslConfig.isVerifyDisabled(sslConfig)
                        ? NoopHostnameVerifier.INSTANCE
                        : SSLConnectionSocketFactory.getDefaultHostnameVerifier();
                var sslFactory = new SSLConnectionSocketFactory(ctx, hostnameVerifier);
                builder.setSSLSocketFactory(sslFactory);

                Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                        .register("http", PlainConnectionSocketFactory.getSocketFactory())
                        .register("https", sslFactory)
                        .build();
                builder.setConnectionManager(new BasicHttpClientConnectionManager(registry));
            }
        }

        return builder.build();
    }

    private static String composeUrl(String baseUrl, String endpoint) {
        if (baseUrl == null) baseUrl = "";
        if (endpoint == null || endpoint.isEmpty()) return baseUrl;
        String b = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        String e = endpoint.startsWith("/") ? endpoint : "/" + endpoint;
        return b + e;
    }

    private static HttpRequestBase buildRequest(String method, String url) {
        return switch (method.toUpperCase()) {
            case "GET" -> new HttpGet(url);
            case "POST" -> new HttpPost(url);
            case "PUT" -> new HttpPut(url);
            case "DELETE" -> new HttpDelete(url);
            case "PATCH" -> new HttpPatch(url);
            case "HEAD" -> new HttpHead(url);
            case "OPTIONS" -> new HttpOptions(url);
            default -> throw new IllegalArgumentException("Unsupported method: " + method);
        };
    }

    private static Map<String, String> resolveAuth(String authType, String authValue) {
        Map<String, String> out = new HashMap<>();
        if (authType == null || authType.isEmpty() || "none".equalsIgnoreCase(authType)) return out;

        String value = authValue == null ? "" : authValue;
        if (value.startsWith("${env.") && value.endsWith("}")) {
            String envVar = value.substring(6, value.length() - 1);
            value = System.getenv(envVar);
            if (value == null) value = "";
        }

        switch (authType.toLowerCase()) {
            case "basic" -> {
                if (value.contains(":")) {
                    String enc = Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
                    out.put(HttpHeaders.AUTHORIZATION, "Basic " + enc);
                }
            }
            case "bearer" -> out.put(HttpHeaders.AUTHORIZATION, "Bearer " + value);
            case "oauth2" -> out.put(HttpHeaders.AUTHORIZATION, "Bearer " + getOauth2Token(value));
            case "service_account" -> out.put(HttpHeaders.AUTHORIZATION, "Bearer " + getGcpToken(value));
        }
        return out;
    }

    /** Stub — replace with real OAuth2 client credentials flow (e.g. MSAL). */
    private static String getOauth2Token(String clientSecret) {
        String env = System.getenv("OAUTH2_TOKEN");
        return env != null ? env : "stub-oauth2-token";
    }

    /** Stub — replace with Google ADC / service account flow. */
    private static String getGcpToken(String saPath) {
        String env = System.getenv("GCP_TOKEN");
        return env != null ? env : "stub-gcp-token";
    }
}
