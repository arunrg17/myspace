package com.apitest.dispatcher;

import javax.net.ssl.*;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * SSL/TLS configuration parser and SSLContext factory.
 *
 * Configured via the Environments sheet's SslConfig column. Format is a
 * semicolon-separated list of key=value pairs:
 *
 *   trust_store=/path/to/cacerts.jks; trust_password=${env.TRUST_PASS}
 *   key_store=/path/to/client.p12; key_password=${env.KEY_PASS}; key_type=PKCS12
 *   trust_store=...; key_store=...                  (mTLS — both sides)
 *   verify=false                                    (skip cert validation — DEV ONLY)
 *
 * Supported keys:
 *   trust_store     Path to truststore (server CA / self-signed)
 *   trust_password  Truststore password (supports ${env.VAR})
 *   trust_type      JKS (default) | PKCS12
 *   key_store       Path to keystore holding client cert + private key (mTLS)
 *   key_password    Keystore password (supports ${env.VAR})
 *   key_type        JKS (default) | PKCS12
 *   verify          true (default) | false  — DO NOT use false in production
 *
 * Built SSLContexts are cached per-config so we don't reload the keystores
 * on every request.
 */
public class SslConfig {

    private static final Map<String, SSLContext> CACHE = new ConcurrentHashMap<>();

    public static SSLContext buildContext(String configStr) {
        String key = configStr == null ? "" : configStr.trim();
        if (key.isEmpty()) return null;  // null = use JVM default

        return CACHE.computeIfAbsent(key, SslConfig::build);
    }

    /** True if config explicitly disables certificate verification. */
    public static boolean isVerifyDisabled(String configStr) {
        Map<String, String> opts = parse(configStr);
        String v = opts.get("verify");
        return v != null && ("false".equalsIgnoreCase(v) || "no".equalsIgnoreCase(v));
    }

    // ------------------------------------------------------------------

    private static SSLContext build(String configStr) {
        try {
            Map<String, String> opts = parse(configStr);

            TrustManager[] trustManagers;
            if ("false".equalsIgnoreCase(opts.get("verify"))) {
                // Skip verification — DEV only
                trustManagers = new TrustManager[]{ new TrustAllManager() };
            } else if (opts.containsKey("trust_store")) {
                KeyStore ts = loadKeyStore(
                        opts.get("trust_store"),
                        resolveSecret(opts.getOrDefault("trust_password", "")),
                        opts.getOrDefault("trust_type", inferType(opts.get("trust_store")))
                );
                TrustManagerFactory tmf = TrustManagerFactory.getInstance(
                        TrustManagerFactory.getDefaultAlgorithm());
                tmf.init(ts);
                trustManagers = tmf.getTrustManagers();
            } else {
                trustManagers = null;  // JVM default cacerts
            }

            KeyManager[] keyManagers = null;
            if (opts.containsKey("key_store")) {
                String pw = resolveSecret(opts.getOrDefault("key_password", ""));
                KeyStore ks = loadKeyStore(
                        opts.get("key_store"),
                        pw,
                        opts.getOrDefault("key_type", inferType(opts.get("key_store")))
                );
                KeyManagerFactory kmf = KeyManagerFactory.getInstance(
                        KeyManagerFactory.getDefaultAlgorithm());
                kmf.init(ks, pw.toCharArray());
                keyManagers = kmf.getKeyManagers();
            }

            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(keyManagers, trustManagers, new SecureRandom());
            return ctx;
        } catch (Exception ex) {
            throw new RuntimeException("SSL config failed: " + ex.getMessage()
                    + " (config: " + configStr + ")", ex);
        }
    }

    private static KeyStore loadKeyStore(String path, String password, String type) throws Exception {
        KeyStore ks = KeyStore.getInstance(type);
        try (InputStream in = Files.newInputStream(Path.of(path))) {
            ks.load(in, password == null ? new char[0] : password.toCharArray());
        }
        return ks;
    }

    private static String inferType(String path) {
        if (path == null) return "JKS";
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".p12") || lower.endsWith(".pfx")) return "PKCS12";
        return "JKS";
    }

    private static Map<String, String> parse(String configStr) {
        Map<String, String> out = new HashMap<>();
        if (configStr == null || configStr.isBlank()) return out;
        for (String part : configStr.split(";")) {
            int eq = part.indexOf('=');
            if (eq > 0) {
                String k = part.substring(0, eq).trim().toLowerCase(Locale.ROOT);
                String v = part.substring(eq + 1).trim();
                out.put(k, v);
            }
        }
        return out;
    }

    private static String resolveSecret(String value) {
        if (value == null) return "";
        if (value.startsWith("${env.") && value.endsWith("}")) {
            String envVar = value.substring(6, value.length() - 1);
            String v = System.getenv(envVar);
            return v == null ? "" : v;
        }
        return value;
    }

    // ------------------------------------------------------------------
    // Trust-all manager — used ONLY when verify=false (dev/test)
    // ------------------------------------------------------------------

    private static class TrustAllManager implements X509TrustManager {
        public void checkClientTrusted(X509Certificate[] c, String t) {}
        public void checkServerTrusted(X509Certificate[] c, String t) {}
        public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
    }
}
