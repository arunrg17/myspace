package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.comparator.Comparator;
import com.apitest.model.*;
import com.apitest.reporter.Reporter;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * End-to-end demo that uses mocked HTTP responses (no real network).
 * Produces a working sample HTML report covering all 5 comparison modes
 * and the new field-level assertions.
 */
public class Demo {

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void main(String[] args) throws Exception {
        List<TestResult> results = new ArrayList<>();

        // ------------------------------------------------------------------
        // T001 — vs_env: same response on DEV and UAT → PASS
        // ------------------------------------------------------------------
        {
            TestResult r = newResult("T001", "Get customer by ID — DEV vs UAT",
                    "Same REST GET on two envs, compare bodies", "vs_env", "DEV_REST", "UAT_REST");
            String body = "{\"id\":\"CUST-1001\",\"name\":\"Acme Industries\",\"region\":\"EMEA\",\"status\":\"active\"}";
            r.stepsA.add(stepOk(1, "Get customer", "GET",
                    "https://dev-api.example.com/customers/CUST-1001", body));
            r.stepsB.add(stepOk(1, "Get customer", "GET",
                    "https://uat-api.example.com/customers/CUST-1001", body));
            r.compareResult = Comparator.compare(body, body, List.of());
            r.status = r.compareResult.matched ? "PASS" : "FAIL";
            r.durationMs = 320;
            results.add(r);
        }

        // ------------------------------------------------------------------
        // T002 — vs_expected: difference detected → FAIL
        // ------------------------------------------------------------------
        {
            TestResult r = newResult("T002", "Create order — REST vs expected",
                    "Create order, compare to baseline response", "vs_expected", "DEV_REST", "");
            String actual = """
                <OrderResponse>
                  <Status>created</Status>
                  <Order>
                    <Id>ORD-9988</Id>
                    <Customer><Id>CUST-1001</Id></Customer>
                    <LineItems>
                      <Item>
                        <ProductId>PROD-501</ProductId>
                        <Quantity>5</Quantity>
                        <UnitPrice currency="USD">49.99</UnitPrice>
                      </Item>
                    </LineItems>
                    <Region>EMEA</Region>
                    <Priority>standard</Priority>
                    <Total>249.95</Total>
                  </Order>
                </OrderResponse>
                """;
            StepResult s = stepOk(1, "Create order", "POST",
                    "https://dev-api.example.com/orders", actual);
            s.status = 201;
            s.extracted.put("order_id", "ORD-9988");
            r.stepsA.add(s);

            String expected = Files.readString(Path.of("expected/T002_create_order.xml"));
            List<Assertion> ignores = List.of(
                    new Assertion("//*[local-name()='Id']", "xpath", "ignore", "", "Generated order id")
            );
            r.compareResult = Comparator.compare(expected, actual, ignores);
            r.status = r.compareResult.matched ? "PASS" : "FAIL";
            r.durationMs = 245;
            results.add(r);
        }

        // ------------------------------------------------------------------
        // T003 — vs_protocol: SOAP vs REST normalized, mismatch on currency
        // ------------------------------------------------------------------
        {
            TestResult r = newResult("T003", "Get account — SOAP vs REST parity",
                    "Same account fetched via SOAP and REST should match", "vs_protocol",
                    "DEV_SOAP", "DEV_REST");
            String soap = """
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
                  <soapenv:Body>
                    <AccountResponse>
                      <id>ACC-001</id>
                      <balance>1500.00</balance>
                      <currency>USD</currency>
                      <status>active</status>
                    </AccountResponse>
                  </soapenv:Body>
                </soapenv:Envelope>""";
            String rest = "{\"Envelope\":{\"Body\":{\"AccountResponse\":{\"id\":\"ACC-001\",\"balance\":\"1500.00\",\"currency\":\"EUR\",\"status\":\"active\"}}}}";
            r.stepsA.add(stepOk(1, "Get account (soap)", "POST",
                    "https://dev-soap.example.com/service", soap));
            r.stepsB.add(stepOk(1, "Get account (rest)", "GET",
                    "https://dev-api.example.com/accounts/ACC-001", rest));
            r.compareResult = Comparator.compare(soap, rest, List.of());
            r.status = r.compareResult.matched ? "PASS" : "FAIL";
            r.durationMs = 412;
            results.add(r);
        }

        // ------------------------------------------------------------------
        // T004 — chain: 3 steps, all succeed → PASS
        // ------------------------------------------------------------------
        {
            TestResult r = newResult("T004", "Order lifecycle (create→update→del)",
                    "Chain test — verify each step succeeds", "chain", "DEV_REST", "");
            StepResult s1 = stepOk(1, "Create order", "POST",
                    "https://dev-api.example.com/orders",
                    "{\"order\":{\"id\":\"ORD-X42\",\"status\":\"created\"}}");
            s1.status = 201;
            s1.extracted.put("order_id", "ORD-X42");
            r.stepsA.add(s1);

            StepResult s2 = stepOk(2, "Update order", "PUT",
                    "https://dev-api.example.com/orders/ORD-X42",
                    "{\"order\":{\"id\":\"ORD-X42\",\"status\":\"updated\"}}");
            r.stepsA.add(s2);

            StepResult s3 = stepOk(3, "Delete order", "DELETE",
                    "https://dev-api.example.com/orders/ORD-X42", "");
            s3.status = 204;
            s3.expectedStatus = List.of(204);
            r.stepsA.add(s3);

            r.status = "PASS";
            r.durationMs = 880;
            results.add(r);
        }

        // ------------------------------------------------------------------
        // T006 — assert_only: field-level assertions, mixed results
        // ------------------------------------------------------------------
        {
            TestResult r = newResult("T006", "Validate created order fields",
                    "Run create, assert specific response fields", "assert_only", "DEV_REST", "");
            String actual = """
                {"order":{"id":"ORD-7777","status":"created","region":"EMEA",
                "customer":{"id":"CUST-1001","name":"Acme"}},"total":249.95}""";
            StepResult s = stepOk(1, "Create order", "POST",
                    "https://dev-api.example.com/orders", actual);
            s.status = 201;
            s.extracted.put("order_id", "ORD-7777");
            r.stepsA.add(s);

            List<Assertion> assertions = List.of(
                new Assertion("$.order.status", "jsonpath", "equals", "created", "Order should be in created state"),
                new Assertion("$.order.id", "jsonpath", "exists", "", "Order ID must be present"),
                new Assertion("$.order.customer.id", "jsonpath", "equals", "CUST-1001", "Customer ID echo"),
                new Assertion("$.total", "jsonpath", "greater_than", "0", "Total must be positive"),
                new Assertion("$.order.region", "jsonpath", "regex_match", "^(EMEA|AMER|APAC)$", "Region must be a known code"),
                new Assertion("$.order.priority", "jsonpath", "equals", "high", "Priority should be high")
            );
            r.assertionResults = AssertionEngine.evaluate(actual, assertions);
            boolean allPass = r.assertionResults.stream().allMatch(a -> a.passed);
            r.status = allPass ? "PASS" : "FAIL";
            r.durationMs = 195;
            results.add(r);
        }

        // ------------------------------------------------------------------
        // T007 — vs_expected + assertions: combined mode
        // ------------------------------------------------------------------
        {
            TestResult r = newResult("T007", "Create order + validate fields",
                    "Compare to expected AND check key fields", "vs_expected", "DEV_REST", "");
            String body = "{\"order\":{\"id\":\"ORD-555\",\"status\":\"created\"},\"total\":99.50}";
            StepResult s = stepOk(1, "Create order", "POST",
                    "https://dev-api.example.com/orders", body);
            s.status = 201;
            r.stepsA.add(s);

            String expected = "{\"order\":{\"id\":\"__IGNORED__\",\"status\":\"created\"},\"total\":99.50}";
            List<Assertion> assertions = List.of(
                new Assertion("$.order.status", "jsonpath", "equals", "created", "Status check"),
                new Assertion("$.total", "jsonpath", "greater_than", "0", "Total positive")
            );
            r.compareResult = Comparator.compare(expected, body, assertions);
            r.assertionResults = AssertionEngine.evaluate(body, assertions);

            boolean allAssert = r.assertionResults.stream().allMatch(a -> a.passed);
            r.status = (r.compareResult.matched && allAssert) ? "PASS" : "FAIL";
            r.durationMs = 178;
            results.add(r);
        }

        // ------------------------------------------------------------------
        // Render
        // ------------------------------------------------------------------
        Path reportPath = Path.of("reports/demo_report.html");
        Files.createDirectories(reportPath.getParent());
        Reporter.renderReport(results, reportPath, "API Test Suite — Sample Run");

        long pass = results.stream().filter(r -> "PASS".equals(r.status)).count();
        long fail = results.stream().filter(r -> "FAIL".equals(r.status)).count();
        long err  = results.stream().filter(r -> "ERROR".equals(r.status)).count();
        System.out.println(pass + " passed · " + fail + " failed · " + err + " errored");
        System.out.println("Report: " + reportPath.toAbsolutePath());
    }

    // ------------------------------------------------------------------

    private static TestResult newResult(String id, String name, String desc,
                                        String mode, String a, String b) {
        TestResult r = new TestResult();
        r.testId = id;
        r.name = name;
        r.description = desc;
        r.comparisonMode = mode;
        r.sourceA = a;
        r.sourceB = b;
        r.started = LocalDateTime.now().format(TS);
        return r;
    }

    private static StepResult stepOk(int order, String name, String method, String url, String body) {
        StepResult s = new StepResult();
        s.name = name;
        s.order = order;
        s.method = method;
        s.url = url;
        s.status = 200;
        s.expectedStatus = List.of(200, 201, 204);
        s.elapsedMs = 90 + (long) (Math.random() * 110);
        s.responseBody = body;
        s.requestBody = method.equals("GET") || method.equals("DELETE") ? "" : "{\"sample\":\"request\"}";
        s.passed = true;
        return s;
    }
}
