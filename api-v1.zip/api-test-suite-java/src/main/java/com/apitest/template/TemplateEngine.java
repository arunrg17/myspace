package com.apitest.template;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Renders request bodies and endpoints with ${placeholder} substitution.
 *
 * Supported:
 *   ${col_name}        from TestCase.data
 *   ${stepN.varname}   from a previous step's extracted variables
 *   ${env.NAME}        from OS environment variable
 *   ${now}             current UTC ISO timestamp
 *   ${uuid}            random UUID
 */
public class TemplateEngine {

    private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{([^}]+)}");

    public static String render(String template, Map<String, String> data,
                                Map<Integer, Map<String, String>> stepVars) {
        if (template == null || template.isEmpty()) return template == null ? "" : template;

        Matcher m = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String token = m.group(1).trim();
            String replacement = resolve(token, data, stepVars);
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        return out.toString();
    }

    public static String renderFile(String templatePath, Map<String, String> data,
                                    Map<Integer, Map<String, String>> stepVars,
                                    Path baseDir) throws IOException {
        if (templatePath == null || templatePath.isEmpty()) return "";
        Path p = baseDir.resolve(templatePath);
        String text = Files.readString(p);
        return render(text, data, stepVars);
    }

    private static String resolve(String token, Map<String, String> data,
                                  Map<Integer, Map<String, String>> stepVars) {
        if ("now".equals(token)) {
            return Instant.now().toString();
        }
        if ("uuid".equals(token)) {
            return UUID.randomUUID().toString();
        }
        if (token.startsWith("env.")) {
            String v = System.getenv(token.substring(4));
            return v == null ? "" : v;
        }
        if (token.startsWith("step") && token.contains(".")) {
            int dot = token.indexOf('.');
            String head = token.substring(0, dot);
            String key = token.substring(dot + 1);
            try {
                int n = Integer.parseInt(head.substring(4));
                Map<String, String> vars = stepVars.get(n);
                if (vars != null) {
                    String v = vars.get(key);
                    return v == null ? "" : v;
                }
            } catch (NumberFormatException ignore) {}
            return "";
        }
        String v = data.get(token);
        return v == null ? "" : v;
    }
}
