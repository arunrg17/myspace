package com.apitest;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Extract the SKELETON of an XML response — element names and nesting structure
 * only. ALL text values, attribute values, namespace URIs, and comments are
 * stripped, so the output is safe to share for debugging XPath issues
 * even when the response itself contains proprietary data.
 *
 * Uses the same parser-free walker as the assertion engine, so what you see
 * here is what your assertions see — no strict XML parser anywhere.
 *
 * Usage:
 *   java -cp target/api-test-suite.jar com.apitest.ResponseSkeleton &lt;response_file&gt;
 */
public class ResponseSkeleton {

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("Usage: ResponseSkeleton <response_file>");
            System.exit(2);
        }

        Path file = Path.of(args[0]);
        String payload = Files.readString(file);

        // Strip HTTP-style header block if present (framework writes
        // "HTTP <status>\nelapsed: <ms>ms\n\n<body>")
        int doubleNl = payload.indexOf("\n\n");
        if (doubleNl > 0 && payload.regionMatches(true, 0, "HTTP", 0, 4)) {
            payload = payload.substring(doubleNl + 2);
        }

        // Strip leading junk / BOM
        payload = stripJunk(payload);
        // Decode escaped XML so we see the inner structure too (SOAP-in-SOAP)
        payload = decodeEscaped(payload);

        System.out.println("=== RESPONSE STRUCTURE ===");
        System.out.println("(values redacted - element names only)");
        System.out.println();

        StringBuilder skeleton = new StringBuilder();
        Set<String> allNames = new LinkedHashSet<>();
        Set<String> seenNames = new HashSet<>();
        Set<String> repeatedNames = new LinkedHashSet<>();

        walk(payload, 0, payload.length(), 0, skeleton, allNames, seenNames, repeatedNames);

        System.out.println(skeleton);
        System.out.println();
        System.out.println("=== UNIQUE ELEMENT NAMES (" + allNames.size() + ") ===");
        for (String n : allNames) System.out.println("  " + n);

        if (!repeatedNames.isEmpty()) {
            System.out.println();
            System.out.println("=== REPEATED ELEMENT NAMES (" + repeatedNames.size() + ") ===");
            System.out.println("These appear more than once. For these, use XPath predicates");
            System.out.println("like //Parent[ChildField='X'] to pick a specific one.");
            for (String n : repeatedNames) System.out.println("  " + n);
        }

        // Diagnostic: if there's a <Content> element, show a sanitized preview
        // of its raw text content so we can see what escape format the inner
        // payload uses (in case the decoder needs to handle a new variant).
        System.out.println();
        System.out.println("=== INNER CONTENT PREVIEW (for debugging escape patterns) ===");
        showInnerContentPreview(payload);
    }

    /** Find <Content>...</Content> and dump the first 200 chars of its inner text. */
    private static void showInnerContentPreview(String xml) {
        // Look for a <Content> tag — preserve the raw escape pattern we find inside
        int open = -1;
        int idx = 0;
        while (idx < xml.length()) {
            int lt = xml.indexOf("<Content", idx);
            if (lt < 0) break;
            // Make sure it's the actual tag (not a longer name like <ContentDescription>)
            if (lt + 8 < xml.length()) {
                char next = xml.charAt(lt + 8);
                if (next == '>' || next == ' ' || next == '/') {
                    open = lt;
                    break;
                }
            }
            idx = lt + 1;
        }
        if (open < 0) {
            System.out.println("(no <Content> tag found in payload — preview skipped)");
            return;
        }
        int gt = xml.indexOf('>', open);
        if (gt < 0) return;
        int close = xml.indexOf("</Content>", gt);
        if (close < 0) close = Math.min(gt + 250, xml.length());
        String inner = xml.substring(gt + 1, Math.min(close, gt + 251));
        // Redact common confidential patterns but keep the escape markers visible
        System.out.println("  Length: " + (close - gt - 1) + " chars");
        System.out.println("  First 250 chars of <Content> inner text:");
        // Show the actual bytes so we can see &lt;, &amp;lt;, &#60;, raw <, etc.
        System.out.println("  " + inner.replace("\n", "\n  "));
    }

    /**
     * Walk through tags by string scanning — no parser used at any point.
     */
    private static void walk(String xml, int start, int end, int depth,
                              StringBuilder out, Set<String> allNames,
                              Set<String> seenNames, Set<String> repeatedNames) {
        if (depth > 25) {  // safety cap on recursion
            out.append("  ".repeat(depth)).append("[... depth limit reached ...]\n");
            return;
        }

        int idx = start;
        Map<String, Integer> childCounts = new LinkedHashMap<>();
        // Pass 1: count children at this level
        int scan = idx;
        while (scan < end) {
            int lt = xml.indexOf('<', scan);
            if (lt < 0 || lt >= end) break;
            if (isMeta(xml, lt)) {
                scan = skipMeta(xml, lt, end);
                continue;
            }
            if (xml.startsWith("</", lt)) break;  // end of parent
            int gt = xml.indexOf('>', lt);
            if (gt < 0 || gt >= end) break;
            String fullName = readName(xml, lt + 1, end);
            childCounts.merge(localName(fullName), 1, Integer::sum);

            boolean selfClose = gt > 0 && xml.charAt(gt - 1) == '/';
            if (selfClose) {
                scan = gt + 1;
            } else {
                int close = findMatchingClose(xml, gt + 1, end, fullName);
                if (close < 0) { scan = end; break; }
                int afterClose = xml.indexOf('>', close);
                scan = afterClose < 0 ? end : afterClose + 1;
            }
        }

        // Pass 2: walk and emit
        Set<String> emitted = new HashSet<>();
        idx = start;
        while (idx < end) {
            int lt = xml.indexOf('<', idx);
            if (lt < 0 || lt >= end) break;
            if (isMeta(xml, lt)) {
                idx = skipMeta(xml, lt, end);
                continue;
            }
            if (xml.startsWith("</", lt)) break;
            int gt = xml.indexOf('>', lt);
            if (gt < 0 || gt >= end) break;

            String fullName = readName(xml, lt + 1, end);
            String local = localName(fullName);

            if (!seenNames.add(local)) repeatedNames.add(local);
            allNames.add(local);

            int count = childCounts.getOrDefault(local, 1);
            boolean selfClose = gt > 0 && xml.charAt(gt - 1) == '/';

            String indent = "  ".repeat(depth);

            if (count > 1) {
                // Only emit one example of repeated elements; print a count summary first
                if (!emitted.add(local)) {
                    // skip — already emitted one of these
                    if (selfClose) { idx = gt + 1; continue; }
                    int close = findMatchingClose(xml, gt + 1, end, fullName);
                    int afterClose = close < 0 ? end : xml.indexOf('>', close);
                    idx = afterClose < 0 ? end : afterClose + 1;
                    continue;
                }
                out.append(indent).append("[x ").append(count)
                   .append(" of <").append(fullName).append("> - showing first only]\n");
            }

            // Emit this tag
            String attrs = readAttrNames(xml, lt + 1 + fullName.length(), gt);
            if (selfClose) {
                out.append(indent).append("<").append(fullName).append(attrs).append("/>\n");
                idx = gt + 1;
                continue;
            }

            int contentStart = gt + 1;
            int contentEnd = findMatchingClose(xml, contentStart, end, fullName);
            if (contentEnd < 0) {
                out.append(indent).append("<").append(fullName).append(attrs).append("> [unclosed]\n");
                break;
            }
            int afterClose = xml.indexOf('>', contentEnd);

            // Check if the content has any nested tags or just text
            String content = xml.substring(contentStart, contentEnd);
            boolean hasChildTag = false;
            int s = 0;
            while (s < content.length()) {
                int t = content.indexOf('<', s);
                if (t < 0) break;
                if (isMeta(content, t)) { s = skipMeta(content, t, content.length()); continue; }
                if (content.startsWith("</", t)) { s = t + 2; continue; }
                hasChildTag = true;
                break;
            }
            boolean hasText = !content.replaceAll("<[^>]+>", "").trim().isEmpty();

            if (!hasChildTag && !hasText) {
                out.append(indent).append("<").append(fullName).append(attrs).append("></")
                   .append(fullName).append(">\n");
            } else if (!hasChildTag) {
                out.append(indent).append("<").append(fullName).append(attrs).append(">?text?</")
                   .append(fullName).append(">\n");
            } else {
                out.append(indent).append("<").append(fullName).append(attrs).append(">\n");
                walk(xml, contentStart, contentEnd, depth + 1, out, allNames, seenNames, repeatedNames);
                out.append(indent).append("</").append(fullName).append(">\n");
            }

            idx = afterClose < 0 ? end : afterClose + 1;
        }
    }

    private static int findMatchingClose(String xml, int start, int end, String fullName) {
        String local = localName(fullName);
        int depth = 1;
        int idx = start;
        while (idx < end) {
            int lt = xml.indexOf('<', idx);
            if (lt < 0 || lt >= end) return -1;
            if (isMeta(xml, lt)) { idx = skipMeta(xml, lt, end); continue; }

            boolean isClose = xml.startsWith("</", lt);
            String name = readName(xml, lt + (isClose ? 2 : 1), end);
            int gt = xml.indexOf('>', lt);
            if (gt < 0 || gt >= end) return -1;

            if (localName(name).equals(local)) {
                if (isClose) {
                    depth--;
                    if (depth == 0) return lt;
                } else {
                    boolean selfClose = gt > 0 && xml.charAt(gt - 1) == '/';
                    if (!selfClose) depth++;
                }
            }
            idx = gt + 1;
        }
        return -1;
    }

    private static String readName(String xml, int start, int end) {
        int i = start;
        while (i < end) {
            char c = xml.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '>' || c == '/') break;
            i++;
        }
        return xml.substring(start, i);
    }

    private static String readAttrNames(String xml, int start, int gt) {
        // Find attribute names (don't include values)
        List<String> names = new ArrayList<>();
        int i = start;
        while (i < gt) {
            char c = xml.charAt(i);
            if (Character.isLetter(c) || c == '_') {
                int j = i;
                while (j < gt && (Character.isLetterOrDigit(xml.charAt(j))
                        || xml.charAt(j) == '_' || xml.charAt(j) == ':'
                        || xml.charAt(j) == '-' || xml.charAt(j) == '.')) j++;
                names.add(xml.substring(i, j));
                i = j;
                // Skip past = "..." or = '...'
                while (i < gt && xml.charAt(i) != ' ' && xml.charAt(i) != '\t') {
                    if (xml.charAt(i) == '"' || xml.charAt(i) == '\'') {
                        char q = xml.charAt(i);
                        i++;
                        while (i < gt && xml.charAt(i) != q) i++;
                        if (i < gt) i++;
                        break;
                    }
                    i++;
                }
            } else {
                i++;
            }
        }
        if (names.isEmpty()) return "";
        StringBuilder sb = new StringBuilder(" [@");
        for (int k = 0; k < names.size(); k++) {
            if (k > 0) sb.append(",@");
            sb.append(names.get(k));
        }
        sb.append("]");
        return sb.toString();
    }

    private static String localName(String qname) {
        int c = qname.indexOf(':');
        return c >= 0 ? qname.substring(c + 1) : qname;
    }

    private static boolean isMeta(String xml, int lt) {
        return xml.startsWith("<!--", lt)
                || xml.startsWith("<?", lt)
                || xml.startsWith("<![CDATA[", lt)
                || (lt + 1 < xml.length() && xml.charAt(lt + 1) == '!');
    }

    private static int skipMeta(String xml, int lt, int end) {
        if (xml.startsWith("<!--", lt)) {
            int c = xml.indexOf("-->", lt + 4);
            return c < 0 ? end : c + 3;
        }
        if (xml.startsWith("<?", lt)) {
            int c = xml.indexOf("?>", lt + 2);
            return c < 0 ? end : c + 2;
        }
        if (xml.startsWith("<![CDATA[", lt)) {
            int c = xml.indexOf("]]>", lt + 9);
            return c < 0 ? end : c + 3;
        }
        if (xml.charAt(lt + 1) == '!') {
            int c = xml.indexOf('>', lt + 2);
            return c < 0 ? end : c + 1;
        }
        return lt + 1;
    }

    private static String stripJunk(String s) {
        if (s == null || s.isEmpty()) return s;
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '\uFEFF' || c == '\u00A0'
                    || Character.isWhitespace(c) || Character.isISOControl(c)) i++;
            else break;
        }
        String out = i == 0 ? s : s.substring(i);
        out = out.replace("\r\n", "\n").replace("\r", "");
        out = out.replaceAll("&#x[dD];", "").replaceAll("&#13;", "");
        return out;
    }

    private static String decodeEscaped(String s) {
        if (s == null) return s;
        for (int pass = 0; pass < 10; pass++) {
            int totalEscapes = countOccurrences(s, "&lt;")
                             + countOccurrences(s, "&#60;")
                             + countOccurrences(s, "&#x3c;")
                             + countOccurrences(s, "&#x3C;");
            if (totalEscapes < 3) return s;
            String next = s
                    .replace("&#60;", "<").replace("&#062;", "<")
                    .replace("&#62;", ">").replace("&#x3c;", "<")
                    .replace("&#x3C;", "<").replace("&#x3e;", ">")
                    .replace("&#x3E;", ">")
                    .replace("&#34;", "\"").replace("&#x22;", "\"")
                    .replace("&#39;", "'").replace("&#x27;", "'")
                    .replace("&lt;", "<")
                    .replace("&gt;", ">")
                    .replace("&quot;", "\"")
                    .replace("&apos;", "'")
                    .replace("&amp;", "&");
            if (next.equals(s)) return s;
            s = next;
        }
        return s;
    }

    private static int countOccurrences(String s, String sub) {
        if (s == null || sub == null || sub.isEmpty()) return 0;
        int count = 0, idx = 0;
        while ((idx = s.indexOf(sub, idx)) != -1) {
            count++;
            idx += sub.length();
            if (count >= 3) break;
        }
        return count;
    }
}
