package com.apitest.excel;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.nio.file.Path;

/**
 * Generates the starter Excel test suite workbook with all sheets,
 * sample rows, headers, and inline help comments.
 *
 * Run via:
 *   java -cp target/api-test-suite.jar com.apitest.excel.TemplateGenerator
 */
public class TemplateGenerator {

    public static void main(String[] args) throws Exception {
        Path out = Path.of(args.length > 0 ? args[0] : "config/test_suite.xlsx");
        generate(out);
        System.out.println("Excel template created: " + out.toAbsolutePath());
    }

    public static void generate(Path output) throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            CellStyle header = headerStyle(wb);
            CellStyle body = bodyStyle(wb);
            CellStyle title = titleStyle(wb);
            CellStyle wrap = wrapStyle(wb);

            readme(wb, title, body);
            environments(wb, header, body, wrap);
            testSuite(wb, header, body, wrap);
            steps(wb, header, body, wrap);
            testData(wb, header, body);
            assertions(wb, header, body, wrap);

            try (FileOutputStream fos = new FileOutputStream(output.toFile())) {
                wb.write(fos);
            }
        }
    }

    // ------------------------------------------------------------------

    private static void readme(Workbook wb, CellStyle title, CellStyle body) {
        Sheet s = wb.createSheet("README");
        Row r0 = s.createRow(0);
        Cell c = r0.createCell(0);
        c.setCellValue("API Test Suite — Quick Reference");
        c.setCellStyle(title);
        s.addMergedRegion(new CellRangeAddress(0, 0, 0, 1));

        String[][] rows = {
                {"", ""},
                {"Sheet", "Purpose"},
                {"Environments", "Define named environments (DEV/UAT/PROD) for any protocol: REST, SOAP, Fabric, GCP."},
                {"TestSuite", "One row per test case. Sets comparison mode and references which steps to run."},
                {"Steps", "One row per request. Multiple steps per TestID let you chain Create → Update → Delete."},
                {"TestData", "Variable values per test. Used to substitute placeholders like ${customer_id}."},
                {"Assertions", "Field-level checks on the response, plus 'ignore' directives for noisy fields."},
                {"", ""},
                {"Comparison Modes", ""},
                {"vs_expected", "Run on SourceA, compare last response to expected file in /expected folder."},
                {"vs_env", "Run on SourceA and SourceB (same protocol), compare the two responses."},
                {"vs_protocol", "Run on two different sources (e.g. SOAP vs REST). Responses normalized."},
                {"assert_only", "Run on SourceA, validate only field-level assertions. No file comparison."},
                {"chain", "Run all steps in order. No comparison — useful for setup or smoke tests."},
                {"", ""},
                {"Placeholders", "Usage in BodyTemplate files and Endpoint URLs"},
                {"${col_name}", "Pulled from TestData column matching the TestID."},
                {"${stepN.field}", "Variable extracted from a previous step's response (e.g. ${step1.order_id})."},
                {"${env.VAR}", "Pulled from OS environment variable (for secrets, tokens)."},
                {"${now}", "Current UTC timestamp in ISO format."},
                {"${uuid}", "Random UUID v4."},
                {"", ""},
                {"Run", "java -jar target/api-test-suite.jar"},
        };

        int ri = 1;
        for (String[] row : rows) {
            Row r = s.createRow(ri++);
            Cell a = r.createCell(0);
            a.setCellValue(row[0]);
            a.setCellStyle(body);
            Cell b = r.createCell(1);
            b.setCellValue(row[1]);
            b.setCellStyle(body);
        }
        s.setColumnWidth(0, 30 * 256);
        s.setColumnWidth(1, 90 * 256);
    }

    private static void environments(Workbook wb, CellStyle header, CellStyle body, CellStyle wrap) {
        Sheet s = wb.createSheet("Environments");
        String[] cols = {"EnvName", "Protocol", "BaseURL", "AuthType", "AuthValue", "ExtraHeaders", "SslConfig"};
        writeHeader(s, cols, header);

        Object[][] rows = {
                {"DEV_REST", "rest", "https://dev-api.example.com", "bearer", "${env.DEV_TOKEN}", "Content-Type: application/json", ""},
                {"UAT_REST", "rest", "https://uat-api.example.com", "bearer", "${env.UAT_TOKEN}", "Content-Type: application/json", ""},
                {"DEV_SOAP", "soap", "https://dev-soap.example.com/service", "basic", "soap_user:soap_pass", "Content-Type: text/xml; charset=utf-8\nSOAPAction: \"\"", "trust_store=certs/dev-truststore.jks; trust_password=${env.TRUST_PASS}"},
                {"UAT_SOAP", "soap", "https://uat-soap.example.com/service", "basic", "soap_user:soap_pass", "Content-Type: text/xml; charset=utf-8\nSOAPAction: \"\"", "trust_store=certs/uat-truststore.jks; trust_password=${env.TRUST_PASS}; key_store=certs/client.p12; key_password=${env.CLIENT_KEY_PASS}; key_type=PKCS12"},
                {"FABRIC_DEV", "fabric", "https://api.fabric.microsoft.com/v1", "oauth2", "${env.FABRIC_CLIENT_SECRET}", "Content-Type: application/json", ""},
                {"GCP_PROD", "gcp", "https://compute.googleapis.com/v1", "service_account", "/path/to/sa.json", "Content-Type: application/json", ""},
                {"LOCAL_DEV", "rest", "https://localhost:8443", "none", "", "Content-Type: application/json", "verify=false"},
        };
        writeData(s, rows, body);
        int[] widths = {16, 12, 50, 18, 35, 50, 60};
        for (int i = 0; i < widths.length; i++) s.setColumnWidth(i, widths[i] * 256);
        s.createFreezePane(0, 1);
    }

    private static void testSuite(Workbook wb, CellStyle header, CellStyle body, CellStyle wrap) {
        Sheet s = wb.createSheet("TestSuite");
        String[] cols = {"TestID", "TestName", "Description", "ComparisonMode", "SourceA", "SourceB", "ExpectedFile", "Enabled"};
        writeHeader(s, cols, header);

        Object[][] rows = {
                {"T001", "Get customer by ID — DEV vs UAT", "Same REST GET on two envs, compare bodies", "vs_env", "DEV_REST", "UAT_REST", "", "Y"},
                {"T002", "Create order — REST vs expected", "Create order, compare to baseline response", "vs_expected", "DEV_REST", "", "expected/T002_create_order.xml", "Y"},
                {"T003", "Get account — SOAP vs REST parity", "Same account fetched via SOAP and REST should match", "vs_protocol", "DEV_SOAP", "DEV_REST", "", "Y"},
                {"T004", "Order lifecycle (create→update→del)", "Chain test — verify each step succeeds", "chain", "DEV_REST", "", "", "Y"},
                {"T005", "Fabric vs GCP data parity", "Compare same dataset surface between Fabric and GCP", "vs_protocol", "FABRIC_DEV", "GCP_PROD", "", "N"},
                {"T006", "Validate created order fields", "Run create, assert specific response fields", "assert_only", "DEV_REST", "", "", "Y"},
        };
        writeData(s, rows, body);
        int[] widths = {10, 38, 50, 16, 14, 14, 38, 10};
        for (int i = 0; i < widths.length; i++) s.setColumnWidth(i, widths[i] * 256);
        s.createFreezePane(0, 1);
    }

    private static void steps(Workbook wb, CellStyle header, CellStyle body, CellStyle wrap) {
        Sheet s = wb.createSheet("Steps");
        String[] cols = {"TestID", "StepOrder", "StepName", "Method", "Endpoint", "BodyTemplate", "ExtractVars", "ExpectedStatus"};
        writeHeader(s, cols, header);

        Object[][] rows = {
                {"T001", 1, "Get customer", "GET", "/customers/${customer_id}", "", "", "200"},
                {"T002", 1, "Create order", "POST", "/orders", "templates/create_order.xml", "order_id=$.order.id", "201"},
                {"T003", 1, "Get account (soap)", "POST", "", "templates/get_account.xml", "", "200"},
                {"T004", 1, "Create order", "POST", "/orders", "templates/create_order.xml", "order_id=$.order.id", "201"},
                {"T004", 2, "Update order", "PUT", "/orders/${step1.order_id}", "templates/update_order.xml", "", "200"},
                {"T004", 3, "Delete order", "DELETE", "/orders/${step1.order_id}", "", "", "204"},
                {"T005", 1, "List datasets", "GET", "/workspaces/${workspace_id}/datasets", "", "", "200"},
                {"T006", 1, "Create order", "POST", "/orders", "templates/create_order.xml", "order_id=$.order.id", "201"},
        };
        writeData(s, rows, body);
        int[] widths = {10, 11, 28, 10, 48, 36, 30, 14};
        for (int i = 0; i < widths.length; i++) s.setColumnWidth(i, widths[i] * 256);
        s.createFreezePane(0, 1);
    }

    private static void testData(Workbook wb, CellStyle header, CellStyle body) {
        Sheet s = wb.createSheet("TestData");
        String[] cols = {"TestID", "customer_id", "workspace_id", "product_id", "quantity", "unit_price", "currency", "region", "priority", "notes"};
        writeHeader(s, cols, header);

        Object[][] rows = {
                {"T001", "CUST-1001", "", "", "", "", "", "", "", ""},
                {"T002", "CUST-1001", "", "PROD-501", "5", "49.99", "USD", "EMEA", "high", "rush order"},
                {"T003", "CUST-1001", "", "", "", "", "", "", "", ""},
                {"T004", "CUST-1002", "", "PROD-502", "2", "19.95", "USD", "AMER", "normal", "standard"},
                {"T005", "", "WS-prod-analytics", "", "", "", "", "", "", ""},
                {"T006", "CUST-1001", "", "PROD-501", "5", "49.99", "USD", "EMEA", "high", "validation"},
        };
        writeData(s, rows, body);
        int[] widths = {10, 14, 22, 14, 11, 12, 10, 10, 11, 28};
        for (int i = 0; i < widths.length; i++) s.setColumnWidth(i, widths[i] * 256);
        s.createFreezePane(0, 1);
    }

    private static void assertions(Workbook wb, CellStyle header, CellStyle body, CellStyle wrap) {
        Sheet s = wb.createSheet("Assertions");
        String[] cols = {"TestID", "Path", "PathType", "Operator", "ExpectedValue", "Description"};
        writeHeader(s, cols, header);

        Object[][] rows = {
                // Ignore directives (use TestID = * to apply to all tests)
                {"*", "//*[local-name()='traceId']", "xpath", "ignore", "", "Trace id always varies — ignore globally"},
                {"*", "$.metadata.requestTime", "jsonpath", "ignore", "", "Request time always varies — ignore globally"},
                {"T001", "//*[local-name()='lastModified']", "xpath", "ignore", "", "Timestamp changes per call"},
                {"T002", "$.order.created_at", "jsonpath", "ignore", "", "Generated timestamp"},
                {"T002", "$.order.id", "jsonpath", "ignore", "", "Generated UUID — validate via assertion instead"},
                {"T003", "//*[local-name()='Timestamp']", "xpath", "ignore", "", "SOAP envelope timestamp"},
                {"T003", "//*[local-name()='MessageID']", "xpath", "ignore", "", "WS-Addressing message id"},

                // Field-level assertions for T006 (assert_only mode)
                {"T006", "$.order.status", "jsonpath", "equals", "created", "Order should be in created state"},
                {"T006", "$.order.id", "jsonpath", "exists", "", "Order ID must be present"},
                {"T006", "$.order.customer.id", "jsonpath", "equals", "CUST-1001", "Customer ID echo"},
                {"T006", "$.total", "jsonpath", "greater_than", "0", "Total must be positive"},
                {"T006", "$.order.region", "jsonpath", "regex_match", "^(EMEA|AMER|APAC)$", "Region must be a known code"},
        };
        writeData(s, rows, body);
        int[] widths = {10, 40, 12, 14, 32, 45};
        for (int i = 0; i < widths.length; i++) s.setColumnWidth(i, widths[i] * 256);
        s.createFreezePane(0, 1);
    }

    // ------------------------------------------------------------------

    private static void writeHeader(Sheet s, String[] cols, CellStyle style) {
        Row r = s.createRow(0);
        for (int i = 0; i < cols.length; i++) {
            Cell c = r.createCell(i);
            c.setCellValue(cols[i]);
            c.setCellStyle(style);
        }
        r.setHeightInPoints(20f);
    }

    private static void writeData(Sheet s, Object[][] rows, CellStyle style) {
        int ri = 1;
        for (Object[] row : rows) {
            Row r = s.createRow(ri++);
            for (int i = 0; i < row.length; i++) {
                Cell c = r.createCell(i);
                if (row[i] instanceof Number n) c.setCellValue(n.doubleValue());
                else c.setCellValue(row[i] == null ? "" : row[i].toString());
                c.setCellStyle(style);
            }
        }
    }

    // ------------------------------------------------------------------

    private static CellStyle headerStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont();
        f.setBold(true);
        f.setColor(IndexedColors.WHITE.getIndex());
        f.setFontName("Arial");
        f.setFontHeightInPoints((short) 11);
        s.setFont(f);
        s.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        s.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        s.setAlignment(HorizontalAlignment.LEFT);
        s.setVerticalAlignment(VerticalAlignment.CENTER);
        s.setBorderLeft(BorderStyle.THIN);
        s.setBorderRight(BorderStyle.THIN);
        s.setBorderTop(BorderStyle.THIN);
        s.setBorderBottom(BorderStyle.THIN);
        return s;
    }

    private static CellStyle bodyStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont();
        f.setFontName("Arial");
        f.setFontHeightInPoints((short) 10);
        s.setFont(f);
        s.setAlignment(HorizontalAlignment.LEFT);
        s.setVerticalAlignment(VerticalAlignment.TOP);
        s.setWrapText(true);
        s.setBorderLeft(BorderStyle.THIN);
        s.setBorderRight(BorderStyle.THIN);
        s.setBorderTop(BorderStyle.THIN);
        s.setBorderBottom(BorderStyle.THIN);
        return s;
    }

    private static CellStyle titleStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont();
        f.setBold(true);
        f.setColor(IndexedColors.DARK_BLUE.getIndex());
        f.setFontName("Arial");
        f.setFontHeightInPoints((short) 16);
        s.setFont(f);
        return s;
    }

    private static CellStyle wrapStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        s.setWrapText(true);
        s.setVerticalAlignment(VerticalAlignment.TOP);
        return s;
    }
}
