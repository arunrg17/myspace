package com.apitest;

import com.apitest.comparator.Comparator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Standalone XPath tester. Reads a response file and evaluates one or more
 * XPaths against it using the same parser/recovery chain as the test runner,
 * so what passes here is what will pass in your tests.
 *
 * Usage:
 *   java -cp target/api-test-suite.jar com.apitest.XPathTester &lt;response_file&gt; &lt;xpath&gt; [xpath...]
 *
 * Examples:
 *   java -cp target/api-test-suite.jar com.apitest.XPathTester output/20260513_120000/T001/sourceA/step1_get/response.txt "//SecurityCostItem[Security/Id='AA0RED']/Cost"
 *   java -cp target/api-test-suite.jar com.apitest.XPathTester response.xml "//Version" "//Sender/ApplicationId"
 *
 * Returns exit code 0 if every XPath produced a non-empty value, 1 otherwise.
 */
public class XPathTester {

    public static void main(String[] args) {
        if (args.length < 2) {
            System.err.println("Usage: XPathTester <response_file> <xpath> [xpath...]");
            System.err.println();
            System.err.println("Reads the given file and evaluates each XPath against it.");
            System.err.println("Uses the same parser as the framework, so results match what your tests will see.");
            System.exit(2);
        }

        Path file = Path.of(args[0]);
        String payload;
        try {
            payload = Files.readString(file);
        } catch (IOException ex) {
            System.err.println("Failed to read file: " + ex.getMessage());
            System.exit(2);
            return;
        }

        // If the file is a saved response capture, the actual body starts after
        // a blank line (the framework writes "HTTP <status>\nelapsed: <ms>ms\n\n<body>").
        // Detect and strip the headers automatically.
        int doubleNl = payload.indexOf("\n\n");
        if (doubleNl > 0 && payload.regionMatches(true, 0, "HTTP", 0, 4)) {
            payload = payload.substring(doubleNl + 2);
        }

        String fmt = Comparator.detectFormat(payload);
        System.out.println("File:           " + file.toAbsolutePath());
        System.out.println("Size:           " + payload.length() + " chars");
        System.out.println("Detected:       " + fmt);
        System.out.println();

        // Show the first ~250 chars so you can sanity-check what was actually parsed
        String preview = payload.length() > 250 ? payload.substring(0, 250) + "…" : payload;
        System.out.println("Body preview:");
        System.out.println("  " + preview.replace("\n", "\n  "));
        System.out.println();

        List<String> xpaths = new ArrayList<>();
        for (int i = 1; i < args.length; i++) xpaths.add(args[i]);

        int failures = 0;
        for (String xpath : xpaths) {
            System.out.println("XPath: " + xpath);
            try {
                String value = Comparator.extractVariable(payload, xpath);
                if (value.isEmpty()) {
                    System.out.println("  → (empty)  ← no element matched, OR path resolved to an empty value");
                    failures++;
                } else {
                    String shown = value.length() > 200 ? value.substring(0, 200) + "…" : value;
                    System.out.println("  → '" + shown + "'");
                }
            } catch (Comparator.ExtractionException ex) {
                System.out.println("  → ERROR: " + ex.getMessage());
                failures++;
            }
            System.out.println();
        }

        System.out.println(failures == 0
                ? "All " + xpaths.size() + " path(s) returned a value."
                : failures + " of " + xpaths.size() + " path(s) returned empty or errored.");
        System.exit(failures == 0 ? 0 : 1);
    }
}
