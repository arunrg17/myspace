package com.apitest.model;

import java.util.ArrayList;
import java.util.List;

public class CompareResult {
    public boolean matched;
    public List<DiffEntry> diffs = new ArrayList<>();
    public String note = "";

    public String getSummary() {
        if (matched) return "MATCH";
        return diffs.size() + " difference(s)";
    }
}
