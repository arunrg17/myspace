package com.apitest.model;

import java.util.List;
import java.util.Map;

public record Step(
        String testId,
        int order,
        String name,
        String method,
        String endpoint,
        String bodyTemplate,
        Map<String, String> extractVars,
        List<Integer> expectedStatus
) {}
