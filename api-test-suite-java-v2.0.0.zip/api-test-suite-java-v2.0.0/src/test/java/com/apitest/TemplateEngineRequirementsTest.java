package com.apitest;

import com.apitest.template.TemplateEngine;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests that verify each functional requirement from the user's spec.
 * Each test maps directly to a numbered requirement.
 */
class TemplateEngineRequirementsTest {

    private static Map<String, String> data(String... kv) {
        Map<String, String> m = new HashMap<>();
        for (int i = 0; i < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return m;
    }
    private static String render(String t, Map<String, String> d) {
        return TemplateEngine.render(t, d, Map.of());
    }

    // ── REQ 1: XML Template Handling — ${} and ${} both supported ─────────

    @Test
    @DisplayName("REQ 1: ${name} placeholder syntax works in tag values")
    void dollarPlaceholderInTagValue1() {
        String out = render("<r><name>${customerName}</name></r>",
                data("customerName", "Alice"));
        assertTrue(out.contains("<name>Alice</name>"), out);
    }

    @Test
    @DisplayName("REQ 1: ${name} placeholder syntax still works")
    void dollarPlaceholderInTagValue() {
        String out = render("<r><name>${customerName}</name></r>",
                data("customerName", "Alice"));
        assertTrue(out.contains("<name>Alice</name>"), out);
    }

    @Test
    @DisplayName("REQ 1: placeholder in attribute")
    void placeholderInAttribute() {
        String out = render("<r><c type=\"${customerType}\"/></r>",
                data("customerType", "VIP"));
        assertTrue(out.contains("type=\"VIP\""), out);
    }

    @Test
    @DisplayName("REQ 1: placeholder in nested child element")
    void placeholderInNestedChild() {
        String t = "<Order><Customer><Address><City>${city}</City></Address></Customer></Order>";
        String out = render(t, data("city", "Berlin"));
        assertTrue(out.contains("<City>Berlin</City>"), out);
    }

    @Test
    @DisplayName("REQ 1: placeholder in repeating structures")
    void placeholderInRepeatingStructures() {
        String t = "<r><Item><Id>${id1}</Id></Item><Item><Id>${id2}</Id></Item></r>";
        String out = render(t, data("id1", "A", "id2", "B"));
        assertTrue(out.contains("<Id>A</Id>"), out);
        assertTrue(out.contains("<Id>B</Id>"), out);
    }

    // ── REQ 2: Excel-style mapping — column name = placeholder name ───────

    @Test
    @DisplayName("REQ 2: column name maps to placeholder name")
    void columnMapsToPlaceholder() {
        String t = "<r><a>${colA}</a><b>${colB}</b></r>";
        String out = render(t, data("colA", "valueA", "colB", "valueB"));
        assertTrue(out.contains("<a>valueA</a>"), out);
        assertTrue(out.contains("<b>valueB</b>"), out);
    }

    // ── REQ 3: Conditional Tag Removal ─────────────────────────────────────

    @Test
    @DisplayName("REQ 3: blank value removes the tag")
    void blankValueRemovesTag() {
        String t = "<r><a>${first}</a><b>${middle}</b><c>${last}</c></r>";
        String out = render(t, data("first", "Alice", "middle", "", "last", "Smith"));
        assertTrue(out.contains("<a>Alice</a>"), out);
        assertTrue(out.contains("<c>Smith</c>"), out);
        assertFalse(out.contains("<b>"), "Middle tag should be removed: " + out);
        assertFalse(out.contains("middle"), "Middle text should not appear: " + out);
    }

    @Test
    @DisplayName("REQ 3: missing column (not in Excel) removes the tag")
    void missingColumnRemovesTag() {
        String t = "<r><a>${x}</a><b>${not_in_map}</b></r>";
        String out = render(t, data("x", "value"));
        assertTrue(out.contains("<a>value</a>"), out);
        assertFalse(out.contains("<b>"), out);
    }

    @Test
    @DisplayName("REQ 3: null-equivalent (empty string) removes the tag")
    void nullValueRemovesTag() {
        String t = "<r><a>${a}</a></r>";
        String out = render(t, data("a", ""));
        assertFalse(out.contains("<a>"), "Empty value: tag removed: " + out);
    }

    // ── REQ 4: Conditional Attribute Removal ───────────────────────────────

    @Test
    @DisplayName("REQ 4: blank attribute is removed, element kept")
    void blankAttributeRemoved() {
        String t = "<Customer type=\"${customerType}\" tier=\"${tier}\">data</Customer>";
        String out = render(t, data("tier", "Gold"));
        assertTrue(out.contains("tier=\"Gold\""), out);
        assertFalse(out.contains("type="), "type attribute removed: " + out);
        assertTrue(out.contains(">data</Customer>"), out);
    }

    @Test
    @DisplayName("REQ 4: all attributes blank — element still kept (has text)")
    void allAttributesBlankElementKept() {
        String t = "<Customer type=\"${type}\" tier=\"${tier}\">data</Customer>";
        String out = render(t, data());
        assertTrue(out.contains(">data</Customer>"), out);
        assertFalse(out.contains("type"), out);
        assertFalse(out.contains("tier"), out);
    }

    // ── REQ 5: Parent Node Cleanup (cascading) ─────────────────────────────

    @Test
    @DisplayName("REQ 5: parent with all children blank is removed")
    void parentWithAllChildrenBlankIsRemoved() {
        String t = "<Order><Address><Street>${street}</Street><City>${city}</City></Address></Order>";
        String out = render(t, data());
        // Address has no surviving children, no attrs, no text → removed
        assertFalse(out.contains("<Address>"), "Address parent should cascade-remove: " + out);
        assertFalse(out.contains("<Street>"), out);
        assertFalse(out.contains("<City>"), out);
        // Order root preserved (even when empty)
        assertTrue(out.contains("<Order"), out);
    }

    @Test
    @DisplayName("REQ 5: parent kept when ANY child survives")
    void parentKeptWhenAnyChildSurvives() {
        String t = "<Order><Address><Street>${street}</Street><City>${city}</City></Address></Order>";
        String out = render(t, data("city", "Berlin"));
        assertTrue(out.contains("<Address>"), out);
        assertTrue(out.contains("<City>Berlin</City>"), out);
        assertFalse(out.contains("<Street>"), out);
    }

    @Test
    @DisplayName("REQ 5: cascading — grandparent dropped if all parents dropped")
    void grandparentCascade() {
        String t = "<Order>"
                + "<Container>"
                + "<Address><Street>${street}</Street><City>${city}</City></Address>"
                + "<Phone>${phone}</Phone>"
                + "</Container>"
                + "</Order>";
        String out = render(t, data());
        // All inner placeholders blank → Address removed → Phone removed
        // → Container empty → Container removed → Order remains as root
        assertFalse(out.contains("<Container>"), "Container should cascade: " + out);
        assertFalse(out.contains("<Address>"), out);
        assertFalse(out.contains("<Phone>"), out);
        assertTrue(out.contains("<Order"), out);
    }

    @Test
    @DisplayName("REQ 5: Parent kept if it has attributes even when children gone")
    void parentWithAttributesKept() {
        String t = "<Order><Address id=\"main\"><City>${city}</City></Address></Order>";
        String out = render(t, data());
        // City removed, but Address has 'id' attribute → keep
        assertTrue(out.contains("<Address"), out);
        assertTrue(out.contains("id=\"main\""), out);
    }

    @Test
    @DisplayName("REQ 5: Parent kept if it has text content even when child elements gone")
    void parentWithTextKept() {
        String t = "<Note>Header text<Detail>${detail}</Detail></Note>";
        String out = render(t, data());
        // Detail removed, but Note still has "Header text" → keep
        assertTrue(out.contains("<Note>"), out);
        assertTrue(out.contains("Header text"), out);
    }

    // ── REQ 6: Nested XML Structure Support ────────────────────────────────

    @Test
    @DisplayName("REQ 6: deeply nested XML with mix of filled and blank")
    void deeplyNestedMixed() {
        String t = "<Order>"
                + "  <Customer>"
                + "    <Name>${name}</Name>"
                + "    <Address>"
                + "      <Street>${street}</Street>"
                + "      <City>${city}</City>"
                + "      <PostalCode>${zip}</PostalCode>"
                + "    </Address>"
                + "    <Phone>${phone}</Phone>"
                + "  </Customer>"
                + "  <DeliveryDate>${deliveryDate}</DeliveryDate>"
                + "</Order>";

        String out = render(t, data(
                "name", "Alice",
                "city", "Berlin",
                "zip", "10115"
                // street, phone, deliveryDate intentionally absent
        ));

        assertTrue(out.contains("<Name>Alice</Name>"), out);
        assertTrue(out.contains("<City>Berlin</City>"), out);
        assertTrue(out.contains("<PostalCode>10115</PostalCode>"), out);
        assertTrue(out.contains("<Address>"), out);
        assertTrue(out.contains("<Customer>"), out);
        assertFalse(out.contains("<Street>"), "Street removed: " + out);
        assertFalse(out.contains("<Phone>"), "Phone removed: " + out);
        assertFalse(out.contains("<DeliveryDate>"), "DeliveryDate removed: " + out);
    }

    // ── REQ 7: Repeating Child Nodes ──────────────────────────────────────

    @Test
    @DisplayName("REQ 7: one repeating node with no values is removed; others kept")
    void oneRepeatingNodeRemovedOthersKept() {
        String t = "<Order><Products>"
                + "<Product><Id>${productId_1}</Id></Product>"
                + "<Product><Id>${productId_2}</Id></Product>"
                + "<Product><Id>${productId_3}</Id></Product>"
                + "</Products></Order>";

        String out = render(t, data("productId_1", "P1", "productId_3", "P3"));
        assertTrue(out.contains("<Id>P1</Id>"), out);
        assertTrue(out.contains("<Id>P3</Id>"), out);
        // Second product had no data → removed; first and third kept
        long productCount = out.split("<Product>").length - 1;
        assertEquals(2, productCount, "Only 2 Products should remain. Output:\n" + out);
    }

    @Test
    @DisplayName("REQ 7: all repeating children removed → parent container removed too")
    void allRepeatingRemovedParentRemoved() {
        String t = "<Order><Products>"
                + "<Product><Id>${productId_1}</Id></Product>"
                + "<Product><Id>${productId_2}</Id></Product>"
                + "</Products></Order>";

        String out = render(t, data());
        // All products removed → Products container also removed
        assertFalse(out.contains("<Product"), "No products should appear: " + out);
        assertFalse(out.contains("<Products>"), "Products container removed: " + out);
        // Order root remains
        assertTrue(out.contains("<Order"), out);
    }

    // ── REQ 8: Namespace Preservation ──────────────────────────────────────

    @Test
    @DisplayName("REQ 8: SOAP envelope namespaces preserved")
    void soapNamespacesPreserved() {
        String t = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                + "<soap:Body>"
                + "<ns:Order xmlns:ns=\"http://example.com/orders\">"
                + "<ns:Id>${order_id}</ns:Id>"
                + "</ns:Order>"
                + "</soap:Body>"
                + "</soap:Envelope>";

        String out = render(t, data("order_id", "X100"));
        assertTrue(out.contains("xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\""), out);
        // The ns prefix may be reorganized by the parser but must still bind correctly
        assertTrue(out.contains("xmlns:ns=\"http://example.com/orders\"")
                || out.contains("xmlns=\"http://example.com/orders\""), out);
        assertTrue(out.contains("X100"), out);
    }

    @Test
    @DisplayName("REQ 8: SOAP envelope structure kept (only the root) even when inner data blank")
    void soapStructureKeptWhenDataBlank() {
        String t = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">"
                + "<soap:Body>"
                + "<execute xmlns=\"http://example.com/svc\">"
                + "<request><type>${type}</type><id>${id}</id></request>"
                + "</execute>"
                + "</soap:Body>"
                + "</soap:Envelope>";

        String out = render(t, data());
        // Inner blanks: <type>, <id>, <request>, <execute>, <Body> all cascade
        // away per the spec (parents with no children + no real attrs + no
        // text are removed). Only the ROOT is preserved.
        assertFalse(out.contains("<type>"), out);
        assertFalse(out.contains("<id>"), out);
        assertFalse(out.contains("<request>"), out);
        assertFalse(out.contains("<execute"), out);
        assertFalse(out.contains("Body"), out);
        // Root Envelope is the only thing left
        assertTrue(out.contains("Envelope"), out);
        assertTrue(out.contains("xmlns:soap"), "Namespace decl preserved on root: " + out);
    }

    // ── REQ 10: Validation and Logging ─────────────────────────────────────

    @Test
    @DisplayName("REQ 10: render log captures missing placeholders and removed tags")
    void renderLogTracksChanges() {
        TemplateEngine.RenderLog log = new TemplateEngine.RenderLog();
        String t = "<r><a>${a}</a><b>${b}</b><c type=\"${c}\"/></r>";
        TemplateEngine.render(t, data("a", "filled"), Map.of(), log);

        // Missing: b, c
        assertTrue(log.missingPlaceholders.contains("b"),
                "b in missing: " + log.missingPlaceholders);
        assertTrue(log.missingPlaceholders.contains("c"),
                "c in missing: " + log.missingPlaceholders);
        // Tag dropped: b
        assertFalse(log.droppedTags.isEmpty(), "Should have logged dropped tags");
    }

    // ── REQ 11: Error Handling ─────────────────────────────────────────────

    @Test
    @DisplayName("REQ 11: optional placeholders do not fail the test")
    void optionalDoesNotFail() {
        String t = "<r><a>${a}</a></r>";
        assertDoesNotThrow(() -> render(t, data()));
    }

    @Test
    @DisplayName("REQ 11: mandatory placeholders fail with !prefix")
    void mandatoryThrows() {
        String t = "<r><id>${!order_id}</id></r>";
        assertThrows(IllegalStateException.class, () -> render(t, data()));
    }

    @Test
    @DisplayName("REQ 11: mandatory placeholders pass when filled")
    void mandatoryPassesWhenFilled() {
        String t = "<r><id>${!order_id}</id></r>";
        String out = render(t, data("order_id", "X100"));
        assertTrue(out.contains("<id>X100</id>"), out);
    }

    // ── REQ 12: Extensibility — non-XML bodies pass through ────────────────

    @Test
    @DisplayName("REQ 12: JSON bodies are substituted but not structurally pruned")
    void jsonBodySubstituted() {
        String t = "{\"name\":\"${name}\",\"phone\":\"${phone}\"}";
        String out = render(t, data("name", "Alice"));
        // JSON: name substituted, blank phone left empty (no structural pruning)
        assertTrue(out.contains("\"name\":\"Alice\""), out);
        // We don't attempt to remove the phone field — that's the user's tool job
    }

    // ── Root protection ────────────────────────────────────────────────────

    @Test
    @DisplayName("Root element preserved even when all content drops")
    void rootPreserved() {
        String t = "<Envelope><Body>${body}</Body></Envelope>";
        String out = render(t, data());
        // Envelope must remain as the root, even if empty
        assertTrue(out.contains("<Envelope"), "Root <Envelope> preserved: " + out);
    }
}
