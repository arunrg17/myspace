package com.apitest.template;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Renders request bodies with ${placeholder} substitution.
 *
 * Placeholder syntax: ${name}
 *
 * Special placeholders:
 *   ${now}, ${uuid}, ${env.NAME}, ${stepN.field}, ${!name} (mandatory)
 *
 * XML pruning rules:
 *   1. Blank/null/missing placeholder value -> containing tag removed
 *   2. Blank in an attribute -> that attribute removed (element survives)
 *   3. After child cleanup, if a parent has no children + no real attrs +
 *      no non-whitespace text -> parent removed (cascading)
 *   4. The root element is never auto-removed
 *   5. Repeating siblings are evaluated independently
 *   6. xmlns declarations are NOT counted as "real" attributes, so
 *      structural namespaced wrappers cascade away when truly empty
 *
 * Pass a RenderLog to capture every decision (which placeholder missed,
 * which tag was dropped, which parent cascaded).
 */
public class TemplateEngine {

    private static final Logger LOG = Logger.getLogger(TemplateEngine.class.getName());

    private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{([^}]+)}");

    private static final String DROP_MARKER = "__APITEST_DROP_MARKER_NULL__";

    public static class RenderLog {
        public final List<String> droppedTags = new ArrayList<>();
        public final List<String> droppedAttributes = new ArrayList<>();
        public final List<String> droppedParents = new ArrayList<>();
        public final List<String> missingPlaceholders = new ArrayList<>();
        public final List<String> trace = new ArrayList<>();

        public String summary() {
            StringBuilder sb = new StringBuilder();
            sb.append("Render log:\n");
            if (!missingPlaceholders.isEmpty()) {
                sb.append("  Missing placeholders (").append(missingPlaceholders.size())
                  .append("): ").append(missingPlaceholders).append("\n");
            }
            if (!droppedTags.isEmpty()) {
                sb.append("  Dropped tags - unresolved placeholder (").append(droppedTags.size())
                  .append("): ").append(droppedTags).append("\n");
            }
            if (!droppedAttributes.isEmpty()) {
                sb.append("  Dropped attributes (").append(droppedAttributes.size())
                  .append("): ").append(droppedAttributes).append("\n");
            }
            if (!droppedParents.isEmpty()) {
                sb.append("  Dropped parents - empty cascade (").append(droppedParents.size())
                  .append("): ").append(droppedParents).append("\n");
            }
            return sb.toString();
        }

        public String fullTrace() {
            StringBuilder sb = new StringBuilder(summary());
            if (!trace.isEmpty()) {
                sb.append("Detailed trace:\n");
                for (String t : trace) sb.append("  ").append(t).append("\n");
            }
            return sb.toString();
        }
    }

    public static String render(String template, Map<String, String> data,
                                Map<Integer, Map<String, String>> stepVars) {
        return render(template, data, stepVars, new RenderLog());
    }

    public static String render(String template, Map<String, String> data,
                                Map<Integer, Map<String, String>> stepVars,
                                RenderLog log) {
        if (template == null || template.isEmpty()) return "";
        String substituted = substitute(template, data, stepVars, log);
        if (!looksLikeXml(substituted)) return substituted.replace(DROP_MARKER, "");
        if (!substituted.contains(DROP_MARKER)) {
            log.trace.add("No unresolved placeholders - no pruning needed");
            return substituted;
        }
        return pruneAndSerialize(substituted, log);
    }

    public static String renderFile(String templatePath, Map<String, String> data,
                                    Map<Integer, Map<String, String>> stepVars,
                                    Path baseDir) throws IOException {
        return renderFile(templatePath, data, stepVars, baseDir, new RenderLog());
    }

    public static String renderFile(String templatePath, Map<String, String> data,
                                    Map<Integer, Map<String, String>> stepVars,
                                    Path baseDir, RenderLog log) throws IOException {
        if (templatePath == null || templatePath.isEmpty()) return "";
        Path p = baseDir.resolve(templatePath);
        if (!Files.exists(p)) throw new IOException("Template file not found: " + p.toAbsolutePath());
        return render(Files.readString(p), data, stepVars, log);
    }

    private static String substitute(String template, Map<String, String> data,
                                     Map<Integer, Map<String, String>> stepVars,
                                     RenderLog log) {
        Matcher m = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String token = m.group(1).trim();
            String replacement = resolve(token, data, stepVars, log);
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        return out.toString();
    }

    private static String resolve(String token, Map<String, String> data,
                                  Map<Integer, Map<String, String>> stepVars,
                                  RenderLog log) {
        if (token.startsWith("!")) {
            String key = token.substring(1).trim();
            String value = lookup(key, data, stepVars);
            if (value == null || value.isEmpty()) {
                throw new IllegalStateException("Required placeholder '" + key
                        + "' resolved to empty. Check TestData column or step output.");
            }
            return value;
        }
        String value = lookup(token, data, stepVars);
        if (value == null || value.isEmpty()) {
            log.missingPlaceholders.add(token);
            return DROP_MARKER;
        }
        return value;
    }

    private static String lookup(String token, Map<String, String> data,
                                 Map<Integer, Map<String, String>> stepVars) {
        if ("now".equals(token)) return Instant.now().toString();
        if ("uuid".equals(token)) return UUID.randomUUID().toString();
        if (token.startsWith("env.")) {
            String v = System.getenv(token.substring(4));
            return v == null ? "" : v;
        }
        if (token.startsWith("step") && token.contains(".")) {
            int dot = token.indexOf('.');
            try {
                int n = Integer.parseInt(token.substring(4, dot));
                String key = token.substring(dot + 1);
                Map<String, String> vars = stepVars == null ? null : stepVars.get(n);
                if (vars != null) {
                    String v = vars.get(key);
                    return v == null ? "" : v;
                }
            } catch (NumberFormatException ignore) {}
            return "";
        }
        if (data == null) return "";
        String v = data.get(token);
        return v == null ? "" : v;
    }

    private static boolean looksLikeXml(String s) {
        if (s == null) return false;
        String t = s.trim();
        int i = 0;
        while (i < t.length() && (t.charAt(i) == '\uFEFF' || Character.isWhitespace(t.charAt(i)))) i++;
        return i < t.length() && t.charAt(i) == '<';
    }

    private static String pruneAndSerialize(String xml, RenderLog log) {
        Document doc;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            try {
                dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
                dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            } catch (Exception ignore) {}
            DocumentBuilder builder = dbf.newDocumentBuilder();
            java.io.PrintStream original = System.err;
            try {
                System.setErr(new java.io.PrintStream(java.io.OutputStream.nullOutputStream()));
                doc = builder.parse(new InputSource(new StringReader(xml)));
            } finally {
                System.setErr(original);
            }
        } catch (Exception ex) {
            log.trace.add("XML parse failed; falling back to string cleanup: " + ex.getMessage());
            LOG.log(Level.WARNING, "XML parse failed during render: " + ex.getMessage());
            return fallbackStringClean(xml);
        }

        Element root = doc.getDocumentElement();
        if (root != null) {
            log.trace.add("Walking from root <" + qname(root) + ">");
            pruneElement(root, true, log);
        }
        boolean hadDecl = xml.trim().startsWith("<?xml");
        return serialize(doc, hadDecl);
    }

    private static void pruneElement(Element elem, boolean isRoot, RenderLog log) {
        List<Element> children = childElements(elem);
        for (Element child : children) pruneElement(child, false, log);

        String me = qname(elem);

        NamedNodeMap attrs = elem.getAttributes();
        List<String> attrsToRemove = new ArrayList<>();
        for (int i = 0; i < attrs.getLength(); i++) {
            Attr a = (Attr) attrs.item(i);
            if (a.getValue() != null && a.getValue().contains(DROP_MARKER)) {
                attrsToRemove.add(a.getName());
            }
        }
        for (String name : attrsToRemove) {
            log.droppedAttributes.add(name + " (on <" + me + ">)");
            log.trace.add("Removed attribute " + name + " from <" + me + ">");
            elem.removeAttribute(name);
        }

        if (isRoot) {
            log.trace.add("Keeping root <" + me + "> (root is never removed)");
            return;
        }

        List<Element> remainingChildren = childElements(elem);
        boolean hasChildElements = !remainingChildren.isEmpty();
        int realAttrCount = countNonNamespaceAttributes(elem);
        boolean hasRealAttrs = realAttrCount > 0;
        String textContent = directText(elem);
        boolean hasNonWhitespaceText = !textContent.replace(DROP_MARKER, "").trim().isEmpty();

        // Per the spec: "If a placeholder value is empty/null/missing, the
        // corresponding XML tag shall be completely removed". This applies
        // even when the element has attributes — having an `action="submit"`
        // attribute doesn't save the element when the element's content was
        // a single unresolved placeholder.
        if (!hasChildElements && textContent.contains(DROP_MARKER) && !hasNonWhitespaceText) {
            // Element has no child elements, no real text — only the marker.
            // (hasNonWhitespaceText was computed with marker removed; if it's
            // false, that means the marker was the ONLY content.)
            Node parent = elem.getParentNode();
            if (parent != null) {
                log.droppedTags.add(me);
                log.trace.add("Removed <" + me + "> (entire content was an unresolved placeholder; attributes "
                        + (hasRealAttrs ? "(present) ignored per spec" : "absent") + ")");
                removeWithPrecedingWhitespace(parent, elem);
            }
            return;
        }

        if (!hasChildElements && !hasRealAttrs && !hasNonWhitespaceText) {
            Node parent = elem.getParentNode();
            if (parent != null) {
                log.droppedParents.add(me);
                log.trace.add("Removed <" + me + "> (empty after cascade: no children, no real attrs, no text)");
                removeWithPrecedingWhitespace(parent, elem);
            }
            return;
        }

        // Element survives. If its text content still has the marker (mixed
        // content with some surviving real text), scrub the marker so it
        // doesn't leak.
        if (textContent.contains(DROP_MARKER)) {
            stripMarkerFromText(elem);
            log.trace.add("Stripped DROP marker from mixed-content text of <" + me + ">");
        }

        log.trace.add("Keeping <" + me + "> (children=" + remainingChildren.size()
                + ", realAttrs=" + realAttrCount + ", hasText=" + hasNonWhitespaceText + ")");
    }

    private static void stripMarkerFromText(Element elem) {
        NodeList kids = elem.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            if (k.getNodeType() == Node.TEXT_NODE && k.getNodeValue() != null
                    && k.getNodeValue().contains(DROP_MARKER)) {
                k.setNodeValue(k.getNodeValue().replace(DROP_MARKER, ""));
            }
        }
    }

    private static int countNonNamespaceAttributes(Element elem) {
        NamedNodeMap attrs = elem.getAttributes();
        int count = 0;
        for (int i = 0; i < attrs.getLength(); i++) {
            Attr a = (Attr) attrs.item(i);
            String name = a.getName();
            if (name == null) continue;
            if ("xmlns".equals(name) || name.startsWith("xmlns:")) continue;
            count++;
        }
        return count;
    }

    private static void removeWithPrecedingWhitespace(Node parent, Element elem) {
        Node prev = elem.getPreviousSibling();
        if (prev != null && prev.getNodeType() == Node.TEXT_NODE
                && prev.getNodeValue() != null
                && prev.getNodeValue().trim().isEmpty()) {
            parent.removeChild(prev);
        }
        parent.removeChild(elem);
    }

    private static String directText(Element elem) {
        StringBuilder sb = new StringBuilder();
        NodeList kids = elem.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            if (k.getNodeType() == Node.TEXT_NODE || k.getNodeType() == Node.CDATA_SECTION_NODE) {
                sb.append(k.getNodeValue());
            }
        }
        return sb.toString();
    }

    private static List<Element> childElements(Element elem) {
        List<Element> out = new ArrayList<>();
        NodeList kids = elem.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            if (k.getNodeType() == Node.ELEMENT_NODE) out.add((Element) k);
        }
        return out;
    }

    private static String qname(Element e) {
        String prefix = e.getPrefix();
        String local = e.getLocalName() != null ? e.getLocalName() : e.getNodeName();
        return prefix == null ? local : prefix + ":" + local;
    }

    private static String serialize(Document doc, boolean includeDecl) {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            try {
                tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
                tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
            } catch (IllegalArgumentException ignore) {}
            Transformer t = tf.newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, includeDecl ? "no" : "yes");
            t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            StringWriter sw = new StringWriter();
            t.transform(new DOMSource(doc), new StreamResult(sw));
            return sw.toString();
        } catch (Exception ex) {
            LOG.log(Level.WARNING, "XML serialization failed: " + ex.getMessage());
            return doc.toString();
        }
    }

    private static String fallbackStringClean(String xml) {
        String esc = Pattern.quote(DROP_MARKER);
        String result = xml.replaceAll(
                "<([A-Za-z_][\\w:.\\-]*)\\b[^>]*>\\s*" + esc + "\\s*</\\1>\\s*\\n?", "");
        result = result.replaceAll(
                "\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*\"[^\"]*" + esc + "[^\"]*\"", "");
        result = result.replaceAll(
                "\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*'[^']*" + esc + "[^']*'", "");
        result = result.replace(DROP_MARKER, "");
        return result;
    }
}
