package com.apitest.template;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Renders request bodies and endpoints with placeholder substitution.
 *
 * Placeholder forms (both equivalent):
 *   ${name}    legacy syntax
 *   &{name}    spec syntax (per requirements)
 *
 * Special placeholders:
 *   ${now}       current UTC ISO-8601 timestamp
 *   ${uuid}      random UUID v4
 *   ${env.NAME}  OS environment variable (for secrets)
 *   ${stepN.field}  variable from a previous step's response
 *
 * BEHAVIOR FOR XML TEMPLATES (auto-detected — output starts with '<')
 * ────────────────────────────────────────────────────────────────────────
 * After substitution the rendered text is parsed as XML and walked
 * recursively. The rules:
 *
 *   1. If a placeholder value is empty / null / blank / missing,
 *      the containing tag is REMOVED from the output.
 *      Example:  <Middle>&{middleName}</Middle>  with middleName=blank
 *                → tag does not appear
 *
 *   2. If a placeholder is in an attribute and the value is blank,
 *      the ATTRIBUTE is removed (the element is preserved).
 *      Example:  <Customer type="&{customerType}">
 *                with customerType=blank → <Customer>
 *
 *   3. After child removal, if a parent has no children, no attributes,
 *      and no non-whitespace text, the parent is removed too (CASCADING).
 *      Repeats recursively until no further parents can be dropped.
 *
 *   4. The ROOT element is never auto-removed. If everything inside it
 *      ends up pruned, the root remains as <RootTag></RootTag>.
 *
 *   5. Repeating children (e.g. multiple <Item> elements) work naturally:
 *      each one is evaluated independently; only the ones whose data is
 *      missing are pruned.
 *
 *   6. SOAP envelopes, namespaces, prefixes, and CDATA sections are
 *      preserved exactly as the template specifies — the parser handles
 *      them and the pretty-printer writes them back out.
 *
 *   7. To make a field MANDATORY (test fails fast if blank), prefix the
 *      placeholder name with '!' :  &{!order_id}
 *
 * NON-XML TEMPLATES (JSON, form, plain text)
 * ────────────────────────────────────────────────────────────────────────
 * Blank placeholders are replaced with empty strings; no structural
 * modification is performed. Use ${!name} for mandatory placeholders.
 */
public class TemplateEngine {

    private static final Logger LOG = Logger.getLogger(TemplateEngine.class.getName());

    // Match either ${name} or &{name}. Capture the inner token.
    private static final Pattern PLACEHOLDER = Pattern.compile("[\\$&]\\{([^}]+)}");

    /** Sentinel left behind when an unresolved placeholder is the entire content
     *  of an element or attribute. Phase 2 (DOM walk) removes any element or
     *  attribute that contains it. */
    private static final String DROP_MARKER = "__APITEST_DROP_MARKER_NULL__";

    /** Tracks what was removed in the last render — useful for diagnostics. */
    public static class RenderLog {
        public final List<String> droppedTags = new ArrayList<>();
        public final List<String> droppedAttributes = new ArrayList<>();
        public final List<String> droppedParents = new ArrayList<>();
        public final List<String> missingPlaceholders = new ArrayList<>();
        public void merge(RenderLog other) {
            droppedTags.addAll(other.droppedTags);
            droppedAttributes.addAll(other.droppedAttributes);
            droppedParents.addAll(other.droppedParents);
            missingPlaceholders.addAll(other.missingPlaceholders);
        }
    }

    /** Convenience overload that discards the render log. */
    public static String render(String template, Map<String, String> data,
                                Map<Integer, Map<String, String>> stepVars) {
        return render(template, data, stepVars, new RenderLog());
    }

    public static String render(String template, Map<String, String> data,
                                Map<Integer, Map<String, String>> stepVars,
                                RenderLog log) {
        if (template == null || template.isEmpty()) return "";

        // ── Phase 1: substitute placeholders into a working string ──────────
        String substituted = substitute(template, data, stepVars, log);

        // ── Phase 2 (XML only): parse and prune ─────────────────────────────
        if (!looksLikeXml(substituted)) {
            // Non-XML body: just strip the drop marker (no structural pruning)
            return substituted.replace(DROP_MARKER, "");
        }
        if (!substituted.contains(DROP_MARKER)) {
            // No pruning needed — return as-is
            return substituted;
        }
        return pruneAndSerialize(substituted, log);
    }

    public static String renderFile(String templatePath, Map<String, String> data,
                                    Map<Integer, Map<String, String>> stepVars,
                                    Path baseDir) throws IOException {
        if (templatePath == null || templatePath.isEmpty()) return "";
        Path p = baseDir.resolve(templatePath);
        return render(Files.readString(p), data, stepVars);
    }

    // ────────────────────────────────────────────────────────────────────────
    // Phase 1: substitution
    // ────────────────────────────────────────────────────────────────────────

    private static String substitute(String template, Map<String, String> data,
                                     Map<Integer, Map<String, String>> stepVars,
                                     RenderLog log) {
        Matcher m = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String token = m.group(1).trim();
            String replacement = resolve(token, data, stepVars, log);
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        return out.toString();
    }

    private static String resolve(String token, Map<String, String> data,
                                  Map<Integer, Map<String, String>> stepVars,
                                  RenderLog log) {
        // Required: &{!col} or ${!col}
        if (token.startsWith("!")) {
            String key = token.substring(1).trim();
            String value = lookup(key, data, stepVars);
            if (value == null || value.isEmpty()) {
                throw new IllegalStateException("Required placeholder '" + key
                        + "' resolved to empty. Check TestData column or step output.");
            }
            return value;
        }
        String value = lookup(token, data, stepVars);
        if (value == null || value.isEmpty()) {
            log.missingPlaceholders.add(token);
            return DROP_MARKER;
        }
        return value;
    }

    private static String lookup(String token, Map<String, String> data,
                                 Map<Integer, Map<String, String>> stepVars) {
        if ("now".equals(token)) return Instant.now().toString();
        if ("uuid".equals(token)) return UUID.randomUUID().toString();
        if (token.startsWith("env.")) {
            String v = System.getenv(token.substring(4));
            return v == null ? "" : v;
        }
        if (token.startsWith("step") && token.contains(".")) {
            int dot = token.indexOf('.');
            try {
                int n = Integer.parseInt(token.substring(4, dot));
                String key = token.substring(dot + 1);
                Map<String, String> vars = stepVars == null ? null : stepVars.get(n);
                if (vars != null) {
                    String v = vars.get(key);
                    return v == null ? "" : v;
                }
            } catch (NumberFormatException ignore) {}
            return "";
        }
        if (data == null) return "";
        String v = data.get(token);
        return v == null ? "" : v;
    }

    // ────────────────────────────────────────────────────────────────────────
    // Phase 2: parse → prune → serialize
    // ────────────────────────────────────────────────────────────────────────

    private static boolean looksLikeXml(String s) {
        if (s == null) return false;
        String t = s.trim();
        // skip BOM + leading whitespace
        int i = 0;
        while (i < t.length() && (t.charAt(i) == '\uFEFF' || Character.isWhitespace(t.charAt(i)))) i++;
        return i < t.length() && t.charAt(i) == '<';
    }

    private static String pruneAndSerialize(String xml, RenderLog log) {
        Document doc;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            // Defang external entity resolution
            try {
                dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
                dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            } catch (Exception ignore) {}
            DocumentBuilder builder = dbf.newDocumentBuilder();
            // Silence stderr from Xerces during parse
            java.io.PrintStream original = System.err;
            try {
                System.setErr(new java.io.PrintStream(java.io.OutputStream.nullOutputStream()));
                doc = builder.parse(new InputSource(new StringReader(xml)));
            } finally {
                System.setErr(original);
            }
        } catch (Exception ex) {
            // If parse fails, fall back to string-level cleanup so we still
            // produce something usable. Strip the marker and any obvious
            // empty <Tag></Tag> patterns. This is a best-effort fallback.
            LOG.log(Level.WARNING, "XML parse failed during render; falling back to string cleanup: "
                    + ex.getMessage());
            return fallbackStringClean(xml);
        }

        Element root = doc.getDocumentElement();
        if (root != null) {
            pruneElement(root, /*isRoot*/ true, log);
        }

        // Preserve the input's XML declaration policy: include only if
        // the template explicitly had one (or did not — same behavior).
        boolean hadDecl = xml.trim().startsWith("<?xml");
        return serialize(doc, hadDecl);
    }

    /**
     * Recursive post-order walk. For each element:
     *   1. Recurse into children first.
     *   2. Remove attributes whose value contains the drop marker.
     *   3. If this is a LEAF (after recursion) and its text content is the
     *      marker OR contains the marker, remove the whole element from
     *      its parent (unless it's the root).
     *   4. After 1-3, if this element has no children, no remaining
     *      attributes, and no non-whitespace text — and it's not the root —
     *      remove it too. This handles the cascading parent cleanup.
     */
    private static void pruneElement(Element elem, boolean isRoot, RenderLog log) {
        // 1. Recurse first (post-order)
        List<Element> children = childElements(elem);
        for (Element child : children) {
            pruneElement(child, false, log);
        }

        // 2. Remove attributes whose value contains the drop marker
        NamedNodeMap attrs = elem.getAttributes();
        List<String> attrsToRemove = new ArrayList<>();
        for (int i = 0; i < attrs.getLength(); i++) {
            Attr a = (Attr) attrs.item(i);
            if (a.getValue() != null && a.getValue().contains(DROP_MARKER)) {
                attrsToRemove.add(a.getName());
            }
        }
        for (String name : attrsToRemove) {
            log.droppedAttributes.add(name);
            elem.removeAttribute(name);
        }

        if (isRoot) return;

        // 3. Decide if THIS element should be removed:
        //    a) Its text content (collapsed) is exactly the marker, OR
        //       contains the marker in a leaf (no child elements remain)
        //    b) Or it's now empty: no children, no attrs, no text
        boolean removeThis = false;
        String removeReason = null;

        List<Element> remainingChildren = childElements(elem);
        boolean hasChildElements = !remainingChildren.isEmpty();
        boolean hasNonEmptyAttrs = elem.getAttributes().getLength() > 0;
        String textContent = directText(elem);

        if (!hasChildElements && textContent.contains(DROP_MARKER)) {
            removeThis = true;
            removeReason = "placeholder unresolved";
        } else if (!hasChildElements && !hasNonEmptyAttrs && textContent.trim().isEmpty()) {
            // Empty parent (after cascading): no children, no attrs, no text
            removeThis = true;
            removeReason = "empty after cascade";
        }

        if (removeThis) {
            Node parent = elem.getParentNode();
            if (parent != null) {
                if ("empty after cascade".equals(removeReason)) {
                    log.droppedParents.add(qname(elem));
                } else {
                    log.droppedTags.add(qname(elem));
                }
                // Also remove any adjacent whitespace text node to keep
                // pretty-printing clean
                Node prev = elem.getPreviousSibling();
                if (prev != null && prev.getNodeType() == Node.TEXT_NODE
                        && prev.getNodeValue() != null
                        && prev.getNodeValue().trim().isEmpty()) {
                    parent.removeChild(prev);
                }
                parent.removeChild(elem);
            }
        }
    }

    /** Direct text content (concatenation of immediate Text children, not descendants). */
    private static String directText(Element elem) {
        StringBuilder sb = new StringBuilder();
        NodeList kids = elem.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            if (k.getNodeType() == Node.TEXT_NODE || k.getNodeType() == Node.CDATA_SECTION_NODE) {
                sb.append(k.getNodeValue());
            }
        }
        return sb.toString();
    }

    private static List<Element> childElements(Element elem) {
        List<Element> out = new ArrayList<>();
        NodeList kids = elem.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            if (k.getNodeType() == Node.ELEMENT_NODE) out.add((Element) k);
        }
        return out;
    }

    private static String qname(Element e) {
        String prefix = e.getPrefix();
        return prefix == null ? e.getLocalName() != null ? e.getLocalName() : e.getNodeName()
                              : prefix + ":" + e.getLocalName();
    }

    private static String serialize(Document doc, boolean includeDecl) {
        try {
            TransformerFactory tf = TransformerFactory.newInstance();
            try {
                tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
                tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
            } catch (IllegalArgumentException ignore) {}
            Transformer t = tf.newTransformer();
            t.setOutputProperty(OutputKeys.INDENT, "yes");
            t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, includeDecl ? "no" : "yes");
            t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            StringWriter sw = new StringWriter();
            t.transform(new DOMSource(doc), new StreamResult(sw));
            return sw.toString();
        } catch (Exception ex) {
            LOG.log(Level.WARNING, "XML serialization failed: " + ex.getMessage());
            return doc.toString();
        }
    }

    /**
     * Best-effort cleanup if the XML can't be parsed (extremely malformed
     * input). Removes <Tag>MARKER</Tag> patterns and the marker itself. */
    private static String fallbackStringClean(String xml) {
        String esc = Pattern.quote(DROP_MARKER);
        // Drop self-contained <Tag ...>MARKER</Tag> (with optional whitespace)
        String result = xml.replaceAll(
                "<([A-Za-z_][\\w:.\\-]*)\\b[^>]*>\\s*" + esc + "\\s*</\\1>\\s*\\n?", "");
        // Drop attributes containing the marker
        result = result.replaceAll(
                "\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*\"[^\"]*" + esc + "[^\"]*\"", "");
        result = result.replaceAll(
                "\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*'[^']*" + esc + "[^']*'", "");
        // Strip any remaining marker fragments
        result = result.replace(DROP_MARKER, "");
        return result;
    }
}
