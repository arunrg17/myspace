# API Test Suite

Excel-driven API testing. Describe your tests in a workbook; the tool runs them
against real endpoints, compares the responses, and produces a self-contained
HTML report.

This repository is the test engine, built as one self-contained fat jar that
runs from the command line. It has no server, no web UI and no Spring: copy the
jar to any machine with a JRE and run it.

Version 2.15.9. Requires Java 21.


## Running

```bash
java -jar target/api-test-suite.jar --suite config/test_suite.xlsx
```

It runs the suite, writes the report and exits with `0` when everything passed
and `1` otherwise, so a pipeline can gate on it.

```bash
java -jar target/api-test-suite.jar --help
java -jar target/api-test-suite.jar --version
```


## Build

```bash
mvn clean package     # application jar at target/api-test-suite.jar
mvn test              # the full test suite
```

Dependencies resolve from your internal Maven repository, which on a corporate
network means VPN plus a `~/.m2/settings.xml` pointing at it. A missing
`settings.xml` shows up as Maven failing to resolve a dependency, which reads
like a project problem but is an environment one.

The Oracle JDBC driver is **commented out** in `pom.xml`. It is only needed for
`db_*` assertions and `${sql:...}` test data, and it is a licensed dependency
that is not on public Maven Central, so the build stays green without it.
Uncomment the block and set `oracle.version` to the build your repository
publishes, or put the driver jar on the classpath at run time.


## Layout

```
pom.xml
config/
  test_suite.xlsx                 starter workbook
  secrets.properties              sample, referenced from the workbook
src/main/java/com/apitest/
  Main, Version, XPathTester, ResponseSkeleton
  model/ excel/ template/         the engine
  dispatcher/ comparator/
  runner/ reporter/
src/main/resources/
  static/                         the built browser UI
  templates/                      workbook template served by the API
src/test/java/                    engine and server tests
docs/
```

The engine packages have no framework dependency. Keeping that boundary means the
engine stays usable from the command line and testable without a web context.


## Documentation

| Document | Covers |
|---|---|
| `docs/WORKBOOK_REFERENCE.md` | The workbook: every sheet, column, comparison mode, assertion operator and placeholder |
| `docs/DEVELOPER_GUIDE.md` | How the code is organised, how a run flows, where to extend it |
| `docs/DEPLOYMENT_GUIDE.md` | Running both modes, configuration, containers, Google Cloud Storage |
| `docs/EXCEL_TEMPLATE_GUIDE.md` | Keeping the workbook tidy, including a formatting macro |
| `docs/DECODE_ENCODE_DESIGN.md` | Design record for encoded-payload handling, not currently in the code |


## What it does not do

- It makes no network calls other than the requests a test asks for. There is
  no telemetry and no update check.
- The HTML report has no external references of any kind, so it opens correctly
  from an attachment or a bucket years later.
- The optional assistant feature is inert unless a base URL, key and model are
  all configured; there is no default endpoint.
