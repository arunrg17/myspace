package com.apitest.model;

/**
 * An ignore directive that actually matched something in a comparison, with
 * how many values it blanked out on each side. A directive that matched
 * nothing on either side is not recorded.
 */
public class IgnoredField {
    /** The XPath or JSONPath from the Assertions sheet. */
    public String path;
    /** {@code xpath} or {@code jsonpath}. */
    public String pathType;
    /** Values ignored in the expected payload / source A. */
    public int countA;
    /** Values ignored in the actual payload / source B. */
    public int countB;

    public IgnoredField() {}

    public IgnoredField(String path, String pathType, int countA, int countB) {
        this.path = path;
        this.pathType = pathType;
        this.countA = countA;
        this.countB = countB;
    }
}
