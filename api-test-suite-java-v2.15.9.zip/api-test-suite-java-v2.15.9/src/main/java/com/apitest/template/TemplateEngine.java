package com.apitest.template;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Renders request bodies with ${placeholder} substitution.
 *
 * Placeholder syntax: ${name}
 *
 * Special placeholders:
 *   ${now}, ${today}, ${uuid}, ${env.NAME}, ${stepN.field}, ${!name} (mandatory)
 *
 * Offsets (spaces around the operator are required):
 *   ${step1.contractId + 1}   whole number; leading zeros are kept
 *   ${startDate + 30 d}       date, by d(ays), w(eeks), m(onths) or y(ears);
 *                             the value keeps its own format
 *
 * XML pruning rules:
 *   1. Blank/null/missing placeholder value -> containing tag removed
 *   2. Blank in an attribute -> that attribute removed (element survives)
 *   3. After child cleanup, if a parent has no children + no real attrs +
 *      no non-whitespace text -> parent removed (cascading)
 *   4. The root element is never auto-removed
 *   5. Repeating siblings are evaluated independently
 *   6. xmlns declarations are NOT counted as "real" attributes, so
 *      structural namespaced wrappers cascade away when truly empty
 *
 * Pass a RenderLog to capture every decision (which placeholder missed,
 * which tag was dropped, which parent cascaded).
 */
public class TemplateEngine {

    private static final Logger LOG = Logger.getLogger(TemplateEngine.class.getName());

    private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{([^}]+)}");

    private static final String DROP_MARKER = "__APITEST_DROP_MARKER_NULL__";

    public static class RenderLog {
        public final List<String> droppedTags = new ArrayList<>();
        public final List<String> droppedAttributes = new ArrayList<>();
        public final List<String> droppedParents = new ArrayList<>();
        public final List<String> missingPlaceholders = new ArrayList<>();
        public final List<String> trace = new ArrayList<>();

        public String summary() {
            StringBuilder sb = new StringBuilder();
            sb.append("Render log:\n");
            if (!missingPlaceholders.isEmpty()) {
                sb.append("  Missing placeholders (").append(missingPlaceholders.size())
                  .append("): ").append(missingPlaceholders).append("\n");
            }
            if (!droppedTags.isEmpty()) {
                sb.append("  Dropped tags - unresolved placeholder (").append(droppedTags.size())
                  .append("): ").append(droppedTags).append("\n");
            }
            if (!droppedAttributes.isEmpty()) {
                sb.append("  Dropped attributes (").append(droppedAttributes.size())
                  .append("): ").append(droppedAttributes).append("\n");
            }
            if (!droppedParents.isEmpty()) {
                sb.append("  Dropped parents - empty cascade (").append(droppedParents.size())
                  .append("): ").append(droppedParents).append("\n");
            }
            return sb.toString();
        }

        public String fullTrace() {
            StringBuilder sb = new StringBuilder(summary());
            if (!trace.isEmpty()) {
                sb.append("Detailed trace:\n");
                for (String t : trace) sb.append("  ").append(t).append("\n");
            }
            return sb.toString();
        }
    }

    /**
     * Render a template string with placeholder substitution (no render log).
     *
     * @param template the raw template text (may contain ${...} tokens)
     * @param data     per-test variable values
     * @param stepVars variables extracted from earlier steps, keyed by step number
     * @return the rendered text
     */
    public static String render(String template, Map<String, String> data,
                                Map<Integer, Map<String, String>> stepVars) {
        return render(template, data, stepVars, new RenderLog());
    }

    /**
     * Render a template string with placeholder substitution.
     *
     * <p>After substitution, if the result is XML and any placeholder went
     * unresolved, the affected (now-empty) elements are pruned so optional
     * fields don't appear in the request. Non-XML output is returned as-is.
     *
     * @param template the raw template text
     * @param data     per-test variable values
     * @param stepVars variables extracted from earlier steps, keyed by step number
     * @param log      collects a trace of what was substituted/pruned, for diagnostics
     * @return the rendered text
     */
    public static String render(String template, Map<String, String> data,
                                Map<Integer, Map<String, String>> stepVars,
                                RenderLog log) {
        if (template == null || template.isEmpty()) return "";
        String substituted = substitute(template, data, stepVars, log);
        if (!looksLikeXml(substituted)) {
            // Not XML. If it looks like JSON and has unresolved placeholders,
            // drop the members that carry them so a blank TestData cell leaves
            // the field out of the request entirely, rather than sending an
            // empty value the server rejects. This mirrors, for JSON, the
            // empty-element pruning XML already gets.
            if (substituted.contains(DROP_MARKER) && looksLikeJson(substituted)) {
                return pruneJsonMarkers(substituted, log);
            }
            return substituted.replace(DROP_MARKER, "");
        }
        if (!substituted.contains(DROP_MARKER)) {
            log.trace.add("No unresolved placeholders - no pruning needed");
            return substituted;
        }
        return pruneAndSerialize(substituted, log);
    }

    /**
     * Load and render a template file (no expected-dir fallback, no log).
     * @see #renderFile(String, Map, Map, Path, Path, RenderLog)
     */
    public static String renderFile(String templatePath, Map<String, String> data,
                                    Map<Integer, Map<String, String>> stepVars,
                                    Path baseDir) throws IOException {
        return renderFile(templatePath, data, stepVars, baseDir, null, new RenderLog());
    }

    /**
     * Load and render a template file with a render log (no expected-dir fallback).
     * @see #renderFile(String, Map, Map, Path, Path, RenderLog)
     */
    public static String renderFile(String templatePath, Map<String, String> data,
                                    Map<Integer, Map<String, String>> stepVars,
                                    Path baseDir, RenderLog log) throws IOException {
        return renderFile(templatePath, data, stepVars, baseDir, null, log);
    }

    /**
     * Load a template file, substitute placeholders, and return the rendered output.
     *
     * <p>Path resolution (first match wins):
     * <ol>
     *   <li>If {@code templatePath} is absolute -> use it directly
     *   <li>{@code templatesDir / templatePath} (e.g. {@code templates/req.xml})
     *   <li>{@code projectRoot / templatePath} (e.g. user wrote {@code templates/req.xml}
     *       in Excel, and templatesDir is already {@code project/templates} - avoids the
     *       double-{@code templates/templates/} problem)
     *   <li>Fails with a clear error listing both attempted paths
     * </ol>
     */
    public static String renderFile(String templatePath, Map<String, String> data,
                                    Map<Integer, Map<String, String>> stepVars,
                                    Path templatesDir, Path projectRoot,
                                    RenderLog log) throws IOException {
        if (templatePath == null || templatePath.isEmpty()) return "";

        Path resolved = resolveTemplatePath(templatePath, templatesDir, projectRoot);
        return render(Files.readString(resolved), data, stepVars, log);
    }

    /**
     * Resolve a template path against the configured directories.
     *
     * <p>A relative path must stay inside the directory it resolves against, so
     * a workbook cannot reach outside the project with {@code ../} and pull an
     * unrelated file into a request body. Absolute paths are still honoured for
     * templates kept on a shared drive.
     */
    static Path resolveTemplatePath(String templatePath, Path templatesDir, Path projectRoot)
            throws IOException {
        Path p = Path.of(templatePath);

        // 1. Absolute path - honour as-is
        if (p.isAbsolute()) {
            if (Files.exists(p)) return p;
            throw new IOException("Template file not found: " + p);
        }

        // 2. Relative to templatesDir
        Path candidate = resolveContained(templatesDir, templatePath);
        if (candidate != null) return candidate;

        // 3. Relative to projectRoot (handles the case where user wrote
        // "templates/req.xml" in Excel and templatesDir is already
        // <project>/templates - avoids templates/templates/req.xml)
        candidate = resolveContained(projectRoot, templatePath);
        if (candidate != null) return candidate;

        // Build a helpful error
        StringBuilder msg = new StringBuilder("Template file not found: ").append(templatePath);
        msg.append("\n  Tried:");
        if (templatesDir != null) msg.append("\n    ").append(templatesDir.resolve(templatePath));
        if (projectRoot != null)  msg.append("\n    ").append(projectRoot.resolve(templatePath));
        throw new IOException(msg.toString());
    }

    /**
     * Resolve {@code relativePath} under {@code base}, returning it only if it
     * exists and has not escaped {@code base} via {@code ..} segments.
     */
    private static Path resolveContained(Path base, String relativePath) {
        if (base == null) return null;
        Path candidate = base.resolve(relativePath).normalize();
        if (!candidate.startsWith(base.normalize())) return null;
        return Files.exists(candidate) ? candidate : null;
    }

    /** Replace every ${...} token in the template with its resolved value. */
    private static String substitute(String template, Map<String, String> data,
                                     Map<Integer, Map<String, String>> stepVars,
                                     RenderLog log) {
        Matcher m = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String token = m.group(1).trim();
            String replacement = resolve(token, data, stepVars, log);
            m.appendReplacement(out, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(out);
        return out.toString();
    }

    /**
     * Resolve a single placeholder token to its value. Supports ${col_name},
     * ${stepN.field}, ${env.VAR}, ${now} and ${uuid}; unknown tokens are left
     * untouched so they are visible in the output.
     */
    private static String resolve(String token, Map<String, String> data,
                                  Map<Integer, Map<String, String>> stepVars,
                                  RenderLog log) {
        // A token may carry a trailing integer offset, e.g. ${step1.orderId + 1}
        // or ${seq - 2}. Peel it off first so the rest of the token resolves
        // exactly as it always has; the offset is applied to whatever comes back.
        Offset offset = Offset.parse(token);
        String key = offset == null ? token : offset.baseToken;

        if (key.startsWith("!")) {
            String name = key.substring(1).trim();
            String value = lookup(name, data, stepVars);
            if (value == null || value.isEmpty()) {
                throw new IllegalStateException("Required placeholder '" + name
                        + "' resolved to empty. Check TestData column or step output.");
            }
            return offset == null ? value : offset.applyTo(value, name);
        }

        String value = lookup(key, data, stepVars);
        if (value == null || value.isEmpty()) {
            log.missingPlaceholders.add(token);
            return DROP_MARKER;
        }
        return offset == null ? value : offset.applyTo(value, key);
    }

    /**
     * A trailing {@code + N} or {@code - N} on a placeholder token, optionally
     * followed by a date unit: {@code + 30 d}, {@code - 1 m}.
     *
     * <p>Kept deliberately narrow: one offset on a single variable. It exists
     * for taking a value out of one response and sending the next one on - the
     * next contract number, a start date a month later - without a separate
     * step to compute it. Anything more elaborate belongs in the service under
     * test, not in a spreadsheet cell.
     */
    private static final class Offset {
        // Whitespace around the operator is required, so "${a + 1}" is
        // arithmetic but a column literally named "order-2024" is not mistaken
        // for "order" minus 2024.
        private static final Pattern ARITHMETIC =
                Pattern.compile("^(.*\\S)\\s+([+-])\\s+(\\d+)\\s*([dDwWmMyY])?$");

        private static final Pattern WHOLE_NUMBER = Pattern.compile("^([+-]?)(\\d+)$");

        /** Date layouts an offset understands. Anything after the date (a time, a zone) is kept as it is. */
        private static final Pattern ISO_DATE = Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})([T ].*)?$");
        private static final Pattern DOTTED_DATE = Pattern.compile("^(\\d{2})\\.(\\d{2})\\.(\\d{4})( .*)?$");
        private static final Pattern SLASHED_DATE = Pattern.compile("^(\\d{2})/(\\d{2})/(\\d{4})( .*)?$");
        private static final Pattern COMPACT_DATE = Pattern.compile("^(\\d{4})(\\d{2})(\\d{2})$");

        final String baseToken;
        final java.math.BigInteger delta;
        /** d, w, m or y for a date offset; null for a whole-number offset. */
        final Character unit;

        private Offset(String baseToken, java.math.BigInteger delta, Character unit) {
            this.baseToken = baseToken;
            this.delta = delta;
            this.unit = unit;
        }

        /** Returns the parsed offset, or null when the token has none. */
        static Offset parse(String token) {
            Matcher m = ARITHMETIC.matcher(token);
            if (!m.matches()) return null;
            java.math.BigInteger n = new java.math.BigInteger(m.group(3));
            if (m.group(2).equals("-")) n = n.negate();
            Character unit = m.group(4) == null ? null : Character.toLowerCase(m.group(4).charAt(0));
            return new Offset(m.group(1).trim(), n, unit);
        }

        /** Apply the offset to a resolved value, failing clearly if it doesn't fit. */
        String applyTo(String value, String name) {
            String v = value.trim();
            if (unit != null) return shiftDate(v, name);

            Matcher m = WHOLE_NUMBER.matcher(v);
            if (!m.matches()) {
                String hint = isDate(v) ? " For a date, add a unit: + 1 d, + 1 w, + 1 m or + 1 y." : "";
                throw new IllegalStateException("Cannot apply offset to placeholder '" + name
                        + "': value '" + value + "' is not a whole number." + hint);
            }
            java.math.BigInteger result = new java.math.BigInteger(v).add(delta);
            // A zero-padded value (000123) stays the same width (000124), as an
            // id or contract number must; an unpadded one is left unpadded.
            String digits = m.group(2);
            if (digits.length() > 1 && digits.charAt(0) == '0' && result.signum() >= 0) {
                String r = result.toString();
                StringBuilder padded = new StringBuilder();
                for (int i = r.length(); i < digits.length(); i++) padded.append('0');
                return m.group(1).equals("+") ? "+" + padded + r : padded + r;
            }
            return result.toString();
        }

        private static boolean isDate(String v) {
            return ISO_DATE.matcher(v).matches() || DOTTED_DATE.matcher(v).matches()
                    || SLASHED_DATE.matcher(v).matches();
        }

        /** Move a date by the offset, keeping its layout and anything after it. */
        private String shiftDate(String v, String name) {
            try {
                Matcher m;
                if ((m = ISO_DATE.matcher(v)).matches()) {
                    java.time.LocalDate d = shift(date(m.group(1), m.group(2), m.group(3)));
                    return String.format("%04d-%02d-%02d", d.getYear(), d.getMonthValue(), d.getDayOfMonth())
                            + rest(m.group(4));
                }
                if ((m = DOTTED_DATE.matcher(v)).matches()) {
                    java.time.LocalDate d = shift(date(m.group(3), m.group(2), m.group(1)));
                    return String.format("%02d.%02d.%04d", d.getDayOfMonth(), d.getMonthValue(), d.getYear())
                            + rest(m.group(4));
                }
                if ((m = SLASHED_DATE.matcher(v)).matches()) {
                    java.time.LocalDate d = shift(date(m.group(3), m.group(2), m.group(1)));
                    return String.format("%02d/%02d/%04d", d.getDayOfMonth(), d.getMonthValue(), d.getYear())
                            + rest(m.group(4));
                }
                if ((m = COMPACT_DATE.matcher(v)).matches()) {
                    java.time.LocalDate d = shift(date(m.group(1), m.group(2), m.group(3)));
                    return String.format("%04d%02d%02d", d.getYear(), d.getMonthValue(), d.getDayOfMonth());
                }
            } catch (java.time.DateTimeException | ArithmeticException invalid) {
                throw new IllegalStateException("Cannot apply date offset to placeholder '" + name
                        + "': value '" + v + "' is not a valid date (" + invalid.getMessage() + ").");
            }
            throw new IllegalStateException("Cannot apply date offset to placeholder '" + name
                    + "': value '" + v + "' is not a date. Supported: yyyy-MM-dd (optionally"
                    + " followed by a time), dd.MM.yyyy, dd/MM/yyyy, yyyyMMdd.");
        }

        private static java.time.LocalDate date(String y, String m, String d) {
            return java.time.LocalDate.of(Integer.parseInt(y), Integer.parseInt(m), Integer.parseInt(d));
        }

        private static String rest(String tail) {
            return tail == null ? "" : tail;
        }

        private java.time.LocalDate shift(java.time.LocalDate d) {
            long n = delta.longValueExact();
            return switch (unit) {
                case 'd' -> d.plusDays(n);
                case 'w' -> d.plusWeeks(n);
                case 'm' -> d.plusMonths(n);
                default -> d.plusYears(n);
            };
        }
    }

    /** Look up a plain or dotted token across step variables and test data. */
    private static String lookup(String token, Map<String, String> data,
                                 Map<Integer, Map<String, String>> stepVars) {
        if ("now".equals(token)) return Instant.now().toString();
        if ("uuid".equals(token)) return UUID.randomUUID().toString();
        if (token.startsWith("env.")) {
            String v = System.getenv(token.substring(4));
            return v == null ? "" : v;
        }
        if (token.startsWith("step") && token.contains(".")) {
            // ${stepN.name} is a value captured by step N. Anything else that
            // merely starts with "step" (a TestData column such as step.status
            // or stepRef.id) is ordinary test data and is looked up below.
            int dot = token.indexOf('.');
            Integer n = null;
            try {
                n = Integer.parseInt(token.substring(4, dot));
            } catch (NumberFormatException notAStepReference) {
                // fall through to the TestData lookup
            }
            if (n != null) {
                String key = token.substring(dot + 1);
                Map<String, String> vars = stepVars == null ? null : stepVars.get(n);
                if (vars != null) {
                    String v = vars.get(key);
                    return v == null ? "" : v;
                }
                return "";
            }
        }
        String v = data == null ? null : data.get(token);
        if (v != null) return v;
        // ${today} is the current date as yyyy-MM-dd. A TestData column of the
        // same name wins, so existing workbooks keep their value.
        if ("today".equals(token)) return java.time.LocalDate.now().toString();
        return "";
    }

    /** Heuristic: does this string appear to be XML (starts with a tag)? */
    private static boolean looksLikeXml(String s) {
        if (s == null) return false;
        String t = s.trim();
        int i = 0;
        while (i < t.length() && (t.charAt(i) == '\uFEFF' || Character.isWhitespace(t.charAt(i)))) i++;
        return i < t.length() && t.charAt(i) == '<';
    }

    private static boolean looksLikeJson(String s) {
        if (s == null) return false;
        String t = s.trim();
        int i = 0;
        while (i < t.length() && (t.charAt(i) == '\uFEFF' || Character.isWhitespace(t.charAt(i)))) i++;
        if (i >= t.length()) return false;
        char c = t.charAt(i);
        return c == '{' || c == '[';
    }

    /**
     * Remove JSON members and array elements whose value did not resolve, so a
     * blank TestData cell drops the field instead of sending an empty one. A
     * marker can land in a value three ways: quoted ("k": "MARKER"), bare for a
     * number or boolean ("k": MARKER), or as an array element. Each is removed
     * whole, then any comma left dangling by the removal is cleaned up so the
     * result parses. What survives is validated as JSON; if for any reason it
     * does not, the original marker is stripped as a last resort so the request
     * still goes out.
     */
    private static String pruneJsonMarkers(String json, RenderLog log) {
        String m = java.util.regex.Pattern.quote(DROP_MARKER);
        String out = json;
        int dropped = 0;
        // An object member whose value is the marker, quoted or bare. The
        // trailing group swallows a following comma, or the pattern instead
        // consumes a preceding comma, so we never leave ",," or a comma against
        // a closing brace.
        java.util.regex.Pattern member = java.util.regex.Pattern.compile(
                "\\s*\"[^\"]*\"\\s*:\\s*(?:\"" + m + "\"|" + m + ")\\s*,"
                + "|,\\s*\"[^\"]*\"\\s*:\\s*(?:\"" + m + "\"|" + m + ")\\s*"
                + "|\\s*\"[^\"]*\"\\s*:\\s*(?:\"" + m + "\"|" + m + ")\\s*");
        java.util.regex.Matcher mm = member.matcher(out);
        StringBuffer sb = new StringBuffer();
        while (mm.find()) { mm.appendReplacement(sb, ""); dropped++; }
        mm.appendTail(sb);
        out = sb.toString();
        // Array elements that are just the marker, with their comma.
        out = out.replaceAll("\\s*(?:\"" + m + "\"|" + m + ")\\s*,", "");
        out = out.replaceAll(",\\s*(?:\"" + m + "\"|" + m + ")\\s*", "");
        out = out.replaceAll("\\s*(?:\"" + m + "\"|" + m + ")\\s*", "");
        // Tidy any comma now sitting against a closing brace or bracket.
        out = out.replaceAll(",\\s*([}\\]])", "$1");
        if (dropped > 0) {
            log.trace.add("Pruned " + dropped + " JSON member(s) with unresolved placeholders");
        }
        // Guard: only return the pruned form if it is still valid JSON.
        try {
            new com.fasterxml.jackson.databind.ObjectMapper().readTree(out);
            return out;
        } catch (Exception ex) {
            log.trace.add("JSON prune produced invalid JSON, stripping markers instead: " + ex.getMessage());
            return json.replace(DROP_MARKER, "");
        }
    }

    /**
     * Parse the template XML, drop any elements left empty after substitution
     * (cascading up so empty parents are removed too), and serialise the
     * result. This keeps optional fields out of the request when their value
     * wasn't supplied.
     */
    private static String pruneAndSerialize(String xml, RenderLog log) {
        Document doc;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            try {
                dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
                dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
                dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
                dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
                dbf.setXIncludeAware(false);
                dbf.setExpandEntityReferences(false);
            } catch (Exception ignore) {
                // Best-effort - feature support varies by parser
            }
            DocumentBuilder builder = dbf.newDocumentBuilder();
            java.io.PrintStream original = System.err;
            try {
                System.setErr(new java.io.PrintStream(java.io.OutputStream.nullOutputStream()));
                doc = builder.parse(new InputSource(new StringReader(xml)));
            } finally {
                System.setErr(original);
            }
        } catch (Exception ex) {
            log.trace.add("XML parse failed; falling back to string cleanup: " + ex.getMessage());
            LOG.log(Level.WARNING, "XML parse failed during render: " + ex.getMessage());
            return fallbackStringClean(xml);
        }

        Element root = doc.getDocumentElement();
        if (root != null) {
            log.trace.add("Walking from root <" + qname(root) + ">");
            pruneElement(root, true, log);
        }
        boolean hadDecl = xml.trim().startsWith("<?xml");
        return serialize(doc, hadDecl);
    }

    /** Recursively remove empty child elements, depth-first. */
    private static void pruneElement(Element elem, boolean isRoot, RenderLog log) {
        List<Element> children = childElements(elem);
        for (Element child : children) pruneElement(child, false, log);

        String me = qname(elem);

        NamedNodeMap attrs = elem.getAttributes();
        List<String> attrsToRemove = new ArrayList<>();
        for (int i = 0; i < attrs.getLength(); i++) {
            Attr a = (Attr) attrs.item(i);
            if (a.getValue() != null && a.getValue().contains(DROP_MARKER)) {
                attrsToRemove.add(a.getName());
            }
        }
        for (String name : attrsToRemove) {
            log.droppedAttributes.add(name + " (on <" + me + ">)");
            log.trace.add("Removed attribute " + name + " from <" + me + ">");
            elem.removeAttribute(name);
        }

        if (isRoot) {
            log.trace.add("Keeping root <" + me + "> (root is never removed)");
            return;
        }

        List<Element> remainingChildren = childElements(elem);
        boolean hasChildElements = !remainingChildren.isEmpty();
        int realAttrCount = countNonNamespaceAttributes(elem);
        boolean hasRealAttrs = realAttrCount > 0;
        String textContent = directText(elem);
        boolean hasNonWhitespaceText = !textContent.replace(DROP_MARKER, "").trim().isEmpty();

        // Per the spec: "If a placeholder value is empty/null/missing, the
        // corresponding XML tag shall be completely removed". This applies
        // even when the element has attributes - having an `action="submit"`
        // attribute doesn't save the element when the element's content was
        // a single unresolved placeholder.
        if (!hasChildElements && textContent.contains(DROP_MARKER) && !hasNonWhitespaceText) {
            // Element has no child elements, no real text - only the marker.
            // (hasNonWhitespaceText was computed with marker removed; if it's
            // false, that means the marker was the ONLY content.)
            Node parent = elem.getParentNode();
            if (parent != null) {
                log.droppedTags.add(me);
                log.trace.add("Removed <" + me + "> (entire content was an unresolved placeholder; attributes "
                        + (hasRealAttrs ? "(present) ignored per spec" : "absent") + ")");
                removeWithPrecedingWhitespace(parent, elem);
            }
            return;
        }

        if (!hasChildElements && !hasRealAttrs && !hasNonWhitespaceText) {
            Node parent = elem.getParentNode();
            if (parent != null) {
                log.droppedParents.add(me);
                log.trace.add("Removed <" + me + "> (empty after cascade: no children, no real attrs, no text)");
                removeWithPrecedingWhitespace(parent, elem);
            }
            return;
        }

        // Element survives. If its text content still has the marker (mixed
        // content with some surviving real text), scrub the marker so it
        // doesn't leak.
        if (textContent.contains(DROP_MARKER)) {
            stripMarkerFromText(elem);
            log.trace.add("Stripped DROP marker from mixed-content text of <" + me + ">");
        }

        log.trace.add("Keeping <" + me + "> (children=" + remainingChildren.size()
                + ", realAttrs=" + realAttrCount + ", hasText=" + hasNonWhitespaceText + ")");
    }

    /**
     * Clean DROP marker from element's text/CDATA content. If the text looks
     * like it contains XML structure (i.e. has `<...>` tag-like fragments -
     * which happens when the template uses CDATA to wrap inner XML), do a
     * deeper clean that removes &lt;Tag&gt;MARKER&lt;/Tag&gt; patterns AND
     * cascades to remove empty parents within the text. Otherwise, just
     * strip the marker.
     */
    private static void stripMarkerFromText(Element elem) {
        NodeList kids = elem.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            short type = k.getNodeType();
            if ((type != Node.TEXT_NODE && type != Node.CDATA_SECTION_NODE)
                    || k.getNodeValue() == null
                    || !k.getNodeValue().contains(DROP_MARKER)) {
                continue;
            }
            String cleaned = cleanEmbeddedXmlString(k.getNodeValue());
            k.setNodeValue(cleaned);
        }
    }

    /**
     * Clean a string that may contain a chunk of XML-like content with DROP
     * markers in it. This is the case for CDATA-wrapped inner business XML
     * inside a single placeholder slot like &lt;arg0&gt;...&lt;/arg0&gt;.
     *
     * The cleanup is iterative - each pass removes leaf tags whose content is
     * the marker, then removes orphan empty wrapper tags, until stable.
     */
    static String cleanEmbeddedXmlString(String s) {
        if (s == null || s.isEmpty()) return s;
        if (!s.contains(DROP_MARKER)) return s;

        String prev;
        String current = s;
        int passes = 0;
        // The marker may be embedded as raw text OR as escaped &lt;Tag&gt;MARKER&lt;/Tag&gt;
        // pattern. We handle both forms in each pass.
        do {
            prev = current;

            // 1. Remove leaf tags whose entire content is the marker.
            // Plain (raw) form:        <Tag ...>MARKER</Tag>
            // Whitespace tolerance:    <Tag ...>  MARKER  </Tag>
            String escMarker = java.util.regex.Pattern.quote(DROP_MARKER);
            current = current.replaceAll(
                    "<([A-Za-z_][\\w:.\\-]*)\\b[^>]*>\\s*" + escMarker + "\\s*</\\1>\\s*",
                    "");
            // Also escaped form: &lt;Tag&gt;MARKER&lt;/Tag&gt;
            current = current.replaceAll(
                    "&lt;([A-Za-z_][\\w:.\\-]*)\\b[^&]*&gt;\\s*" + escMarker + "\\s*&lt;/\\1&gt;\\s*",
                    "");

            // 2. Remove self-closing tags whose attribute value is the marker
            current = current.replaceAll(
                    "<[A-Za-z_][\\w:.\\-]*\\b[^>]*=\\s*[\"'][^\"']*"
                            + escMarker + "[^\"']*[\"'][^>]*/>\\s*",
                    "");

            // 3. Remove attributes whose value contains the marker
            // (preserves the element)
            current = current.replaceAll(
                    "\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*\"[^\"]*"
                            + escMarker + "[^\"]*\"", "");
            current = current.replaceAll(
                    "\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*'[^']*"
                            + escMarker + "[^']*'", "");

            // 4. Remove empty parent tags (no content between open/close).
            // Only do this when there ARE markers still present, or just
            // after a prior pass dropped something - otherwise we'd
            // delete legitimately empty tags the user wrote intentionally.
            // Heuristic: only run this when current != prev so far in this
            // pass, i.e. when we just deleted something.
            if (!current.equals(prev)) {
                current = current.replaceAll(
                        "<([A-Za-z_][\\w:.\\-]*)\\b[^>]*>\\s*</\\1>\\s*",
                        "");
                // Escaped form
                current = current.replaceAll(
                        "&lt;([A-Za-z_][\\w:.\\-]*)\\b[^&]*&gt;\\s*&lt;/\\1&gt;\\s*",
                        "");
            }

            passes++;
            if (passes > 20) break;
        } while (!current.equals(prev));

        // Strip any remaining marker fragments (shouldn't be any, but safety)
        current = current.replace(DROP_MARKER, "");
        return current;
    }

    /** Count attributes on an element, ignoring xmlns declarations. */
    private static int countNonNamespaceAttributes(Element elem) {
        NamedNodeMap attrs = elem.getAttributes();
        int count = 0;
        for (int i = 0; i < attrs.getLength(); i++) {
            Attr a = (Attr) attrs.item(i);
            String name = a.getName();
            if (name == null) continue;
            if ("xmlns".equals(name) || name.startsWith("xmlns:")) continue;
            count++;
        }
        return count;
    }

    /** Remove a child node along with the whitespace text node before it. */
    private static void removeWithPrecedingWhitespace(Node parent, Element elem) {
        Node prev = elem.getPreviousSibling();
        if (prev != null && prev.getNodeType() == Node.TEXT_NODE
                && prev.getNodeValue() != null
                && prev.getNodeValue().trim().isEmpty()) {
            parent.removeChild(prev);
        }
        parent.removeChild(elem);
    }

    /** Return the element's own direct text content, excluding child elements. */
    private static String directText(Element elem) {
        StringBuilder sb = new StringBuilder();
        NodeList kids = elem.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            if (k.getNodeType() == Node.TEXT_NODE || k.getNodeType() == Node.CDATA_SECTION_NODE) {
                sb.append(k.getNodeValue());
            }
        }
        return sb.toString();
    }

    /** List the direct child elements of an element (skipping text nodes). */
    private static List<Element> childElements(Element elem) {
        List<Element> out = new ArrayList<>();
        NodeList kids = elem.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            if (k.getNodeType() == Node.ELEMENT_NODE) out.add((Element) k);
        }
        return out;
    }

    /** Return the element's qualified name (prefix:local) as written. */
    private static String qname(Element e) {
        String prefix = e.getPrefix();
        String local = e.getLocalName() != null ? e.getLocalName() : e.getNodeName();
        return prefix == null ? local : prefix + ":" + local;
    }

    /** Serialise a DOM document back to a string, optionally keeping the XML declaration. */
    private static String serialize(Document doc, boolean includeDecl) {
        try {
            // Pre-process the DOM:
            // 1. Remove any redundant xmlns="" declarations the parser may
            // have added during DOM normalization
            // 2. Remove whitespace-only text nodes that were originally
            // indentation, because after pruning they leave visible blank
            // lines / gaps that may confuse strict server parsers
            cleanupRedundantNamespaces(doc.getDocumentElement(), null);
            removeWhitespaceOnlyTextNodes(doc.getDocumentElement());

            TransformerFactory tf = TransformerFactory.newInstance();
            try {
                tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
                tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
            } catch (IllegalArgumentException ignore) {}
            Transformer t = tf.newTransformer();
            // INDENT off - the Transformer's pretty-print is what wraps lines
            // after long attributes and inserts inconsistent whitespace.
            // Producing a single-line clean output is safer.
            t.setOutputProperty(OutputKeys.INDENT, "no");
            t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, includeDecl ? "no" : "yes");
            t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");

            // Preserve CDATA sections (don't escape them to entities)
            String cdataElements = findCdataElementNames(doc);
            if (!cdataElements.isEmpty()) {
                t.setOutputProperty(OutputKeys.CDATA_SECTION_ELEMENTS, cdataElements);
            }

            StringWriter sw = new StringWriter();
            t.transform(new DOMSource(doc), new StreamResult(sw));
            return sw.toString();
        } catch (Exception ex) {
            LOG.log(Level.WARNING, "XML serialization failed: " + ex.getMessage());
            return doc.toString();
        }
    }

    /**
     * Walk the tree removing redundant xmlns="" declarations the namespace-aware
     * parser may have added. An xmlns="" on a child is redundant when the
     * parent already has no default namespace.
     */
    private static void cleanupRedundantNamespaces(Element elem, String parentDefaultNs) {
        if (elem == null) return;
        String myDefaultNs = elem.getAttribute("xmlns");
        // If our default-ns is empty and the parent's was also empty,
        // remove the redundant attribute.
        if (elem.hasAttribute("xmlns") && myDefaultNs.isEmpty()
                && (parentDefaultNs == null || parentDefaultNs.isEmpty())) {
            elem.removeAttribute("xmlns");
        }
        String passDown = elem.hasAttribute("xmlns") ? elem.getAttribute("xmlns") : parentDefaultNs;
        NodeList kids = elem.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            if (k.getNodeType() == Node.ELEMENT_NODE) {
                cleanupRedundantNamespaces((Element) k, passDown);
            }
        }
    }

    /**
     * Remove text nodes that are pure whitespace (these were typically the
     * original template's indentation between elements). After pruning, these
     * leave visible blank lines and gaps. With INDENT off, the parser would
     * leave them in place; safer to strip them now.
     *
     * Important: only strip whitespace BETWEEN elements, not text that's the
     * actual content of a leaf element.
     */
    private static void removeWhitespaceOnlyTextNodes(Element elem) {
        if (elem == null) return;
        List<Element> childElems = childElements(elem);
        boolean hasChildElements = !childElems.isEmpty();
        if (hasChildElements) {
            // This is a structural element. Strip whitespace-only text nodes
            // among its children.
            List<Node> toRemove = new ArrayList<>();
            NodeList kids = elem.getChildNodes();
            for (int i = 0; i < kids.getLength(); i++) {
                Node k = kids.item(i);
                if (k.getNodeType() == Node.TEXT_NODE
                        && k.getNodeValue() != null
                        && k.getNodeValue().trim().isEmpty()) {
                    toRemove.add(k);
                }
            }
            for (Node n : toRemove) elem.removeChild(n);
        }
        // Recurse
        for (Element c : childElems) removeWhitespaceOnlyTextNodes(c);
    }

    /** Find names of elements that contain CDATA section children. */
    private static String findCdataElementNames(Document doc) {
        java.util.LinkedHashSet<String> names = new java.util.LinkedHashSet<>();
        collectCdataParentNames(doc.getDocumentElement(), names);
        return String.join(" ", names);
    }

    /** Record the names of elements that wrap their content in CDATA, for later handling. */
    private static void collectCdataParentNames(Node node, java.util.Set<String> out) {
        if (node == null) return;
        NodeList kids = node.getChildNodes();
        for (int i = 0; i < kids.getLength(); i++) {
            Node k = kids.item(i);
            if (k.getNodeType() == Node.CDATA_SECTION_NODE && node instanceof Element) {
                Element e = (Element) node;
                String name = e.getLocalName() != null ? e.getLocalName() : e.getNodeName();
                out.add(name);
            }
            if (k.getNodeType() == Node.ELEMENT_NODE) {
                collectCdataParentNames(k, out);
            }
        }
    }

    /**
     * Last-resort cleanup used when the XML can't be parsed as a DOM:
     * strips empty tags textually so a malformed-but-usable template still
     * renders sensibly.
     */
    private static String fallbackStringClean(String xml) {
        String esc = Pattern.quote(DROP_MARKER);
        String result = xml.replaceAll(
                "<([A-Za-z_][\\w:.\\-]*)\\b[^>]*>\\s*" + esc + "\\s*</\\1>\\s*\\n?", "");
        result = result.replaceAll(
                "\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*\"[^\"]*" + esc + "[^\"]*\"", "");
        result = result.replaceAll(
                "\\s+[A-Za-z_][\\w:.\\-]*\\s*=\\s*'[^']*" + esc + "[^']*'", "");
        result = result.replace(DROP_MARKER, "");
        return result;
    }
}
