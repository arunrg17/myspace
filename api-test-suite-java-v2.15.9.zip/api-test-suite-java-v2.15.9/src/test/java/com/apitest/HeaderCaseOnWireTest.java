package com.apitest;

import com.apitest.dispatcher.Dispatcher;
import com.apitest.dispatcher.Response;
import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Header names are case-insensitive. An environment header and a step header
 * that differ only in case must go on the wire once, with the step's value,
 * and a user-supplied content-type must not be joined by a default one.
 */
class HeaderCaseOnWireTest {

    /** Send one request to a raw socket and return the header lines received. */
    private List<String> headersOnWire(String protocol, String body, Map<String, String> headers)
            throws Exception {
        try (ServerSocket ss = new ServerSocket(0)) {
            int port = ss.getLocalPort();
            ExecutorService ex = Executors.newSingleThreadExecutor();
            Future<List<String>> cap = ex.submit(() -> {
                try (Socket s = ss.accept()) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    in.readLine();
                    List<String> lines = new ArrayList<>();
                    String line;
                    int contentLength = 0;
                    while ((line = in.readLine()) != null && !line.isEmpty()) {
                        lines.add(line);
                        if (line.toLowerCase().startsWith("content-length:")) {
                            contentLength = Integer.parseInt(line.split(":")[1].trim());
                        }
                    }
                    char[] buf = new char[contentLength];
                    if (contentLength > 0) in.read(buf, 0, contentLength);
                    OutputStream out = s.getOutputStream();
                    out.write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\n{}".getBytes());
                    out.flush();
                    return lines;
                }
            });
            Response r = Dispatcher.send(protocol, "", "http://localhost:" + port + "/svc",
                    body == null ? "GET" : "POST", body, headers, "none", "", null);
            List<String> lines = cap.get(5, TimeUnit.SECONDS);
            ex.shutdown();
            assertEquals(200, r.status, "endpoint should have responded 200");
            return lines;
        }
    }

    private static List<String> named(List<String> lines, String name) {
        List<String> out = new ArrayList<>();
        for (String l : lines) {
            if (l.toLowerCase().startsWith(name.toLowerCase() + ":")) out.add(l);
        }
        return out;
    }

    @Test
    void stepHeaderReplacesEnvironmentHeaderOfDifferentCase() throws Exception {
        Map<String, String> h = new LinkedHashMap<>();
        h.put("Authorization", "Bearer from-environment");
        h.put("authorization", "Bearer from-step");
        List<String> auth = named(headersOnWire("rest", null, h), "Authorization");
        assertEquals(1, auth.size(), auth::toString);
        assertTrue(auth.get(0).endsWith("Bearer from-step"), auth::toString);
    }

    @Test
    void lowercaseContentTypeIsNotJoinedByTheDefault() throws Exception {
        Map<String, String> h = new LinkedHashMap<>();
        h.put("content-type", "application/xml");
        List<String> ct = named(headersOnWire("rest", "<a>1</a>", h), "Content-Type");
        assertEquals(1, ct.size(), ct::toString);
        assertTrue(ct.get(0).contains("application/xml"), ct::toString);
    }

    @Test
    void defaultContentTypeStillAppliesWhenNoneIsGiven() throws Exception {
        List<String> ct = named(headersOnWire("rest", "{\"a\":1}", new LinkedHashMap<>()), "Content-Type");
        assertEquals(1, ct.size(), ct::toString);
        assertTrue(ct.get(0).contains("application/json"), ct::toString);
    }
}
