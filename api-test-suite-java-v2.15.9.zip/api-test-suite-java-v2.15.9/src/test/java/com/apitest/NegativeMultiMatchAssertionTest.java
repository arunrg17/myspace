package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * When a path matches several values, a positive operator passes if any value
 * satisfies it, but a negative operator is a claim about every value:
 * "no status equals FAILED" is false as soon as one does.
 */
class NegativeMultiMatchAssertionTest {

    private static final String BODY =
            "{\"items\":[{\"status\":\"SUCCESS\"},{\"status\":\"FAILED\"},{\"status\":\"SUCCESS\"}]}";

    private static AssertionResult eval(String body, String op, String expected) {
        List<AssertionResult> rs = AssertionEngine.evaluate(body,
                List.of(new Assertion("$.items[*].status", "jsonpath", op, expected, "")));
        return rs.get(0);
    }

    @Test
    void notEqualsFailsWhenAnyMatchEqualsTheValue() {
        AssertionResult r = eval(BODY, "not_equals", "FAILED");
        assertFalse(r.passed, "FAILED is present in one of the matches");
        assertTrue(r.message.contains("FAILED"), r.message);
    }

    @Test
    void notEqualsPassesWhenNoMatchEqualsTheValue() {
        assertTrue(eval(BODY, "not_equals", "PENDING").passed);
    }

    @Test
    void notContainsFailsWhenAnyMatchContainsTheText() {
        assertFalse(eval(BODY, "not_contains", "FAIL").passed);
        assertTrue(eval(BODY, "not_contains", "PEND").passed);
    }

    @Test
    void positiveOperatorsStillPassOnAnyMatch() {
        assertTrue(eval(BODY, "equals", "FAILED").passed);
        assertTrue(eval(BODY, "contains", "SUCC").passed);
        assertFalse(eval(BODY, "equals", "PENDING").passed);
    }

    @Test
    void singleMatchBehaviourIsUnchanged() {
        String one = "{\"items\":[{\"status\":\"SUCCESS\"}]}";
        assertTrue(eval(one, "not_equals", "FAILED").passed);
        assertFalse(eval(one, "not_equals", "SUCCESS").passed);
    }
}
