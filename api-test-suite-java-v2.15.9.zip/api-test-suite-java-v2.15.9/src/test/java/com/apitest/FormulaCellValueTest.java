package com.apitest;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A formula cell is read from its cached result. A boolean result used to come
 * back blank; string and number results read as before.
 */
class FormulaCellValueTest {

    private static String read(String formula) throws Exception {
        try (Workbook wb = new HSSFWorkbook()) {
            Sheet sh = wb.createSheet("s");
            Row row = sh.createRow(0);
            Cell c = row.createCell(0);
            c.setCellFormula(formula);
            wb.getCreationHelper().createFormulaEvaluator().evaluateFormulaCell(c);
            Method m = Class.forName("com.apitest.excel.ExcelLoader")
                    .getDeclaredMethod("cellStringValue", Cell.class);
            m.setAccessible(true);
            return (String) m.invoke(null, c);
        }
    }

    @Test
    void booleanResultIsRead() throws Exception {
        assertEquals("true", read("1=1"));
        assertEquals("false", read("1=2"));
    }

    @Test
    void stringResultIsUnchanged() throws Exception {
        assertEquals("ab", read("\"a\"&\"b\""));
    }

    @Test
    void numberResultIsUnchanged() throws Exception {
        assertEquals("3.0", read("1+2"));
    }

    @Test
    void errorResultIsBlank() throws Exception {
        assertEquals("", read("1/0"));
    }
}
