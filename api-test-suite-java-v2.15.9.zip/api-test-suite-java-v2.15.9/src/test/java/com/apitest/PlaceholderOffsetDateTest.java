package com.apitest;

import com.apitest.template.TemplateEngine;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Offsets on placeholders: the next contract number from the last one, a date
 * moved on by days, weeks, months or years, and ${today}.
 */
class PlaceholderOffsetDateTest {

    private static String render(String template, String name, String value) {
        Map<String, String> data = new HashMap<>();
        data.put(name, value);
        return TemplateEngine.render(template, data, Map.of());
    }

    private static Map<Integer, Map<String, String>> step1(String name, String value) {
        Map<Integer, Map<String, String>> steps = new HashMap<>();
        steps.put(1, Map.of(name, value));
        return steps;
    }

    // ---- whole numbers ------------------------------------------------

    @Test
    void nextContractNumberFromPreviousStep() {
        assertEquals("100045",
                TemplateEngine.render("${step1.lastContractId + 1}", Map.of(), step1("lastContractId", "100044")));
    }

    @Test
    void longAndShortNumbers() {
        assertEquals("8", render("${n + 1}", "n", "7"));
        assertEquals("9223372036854775808", render("${n + 1}", "n", "9223372036854775807"));
        assertEquals("123456789012345678901234567891", render("${n + 1}", "n", "123456789012345678901234567890"));
    }

    @Test
    void leadingZerosAreKept() {
        assertEquals("000124", render("${n + 1}", "n", "000123"));
        assertEquals("0100", render("${n + 1}", "n", "0099"));
        assertEquals("1000", render("${n + 1}", "n", "0999"));
        assertEquals("10000", render("${n + 1}", "n", "9999"));
        assertEquals("000122", render("${n - 1}", "n", "000123"));
    }

    // ---- dates --------------------------------------------------------

    @Test
    void isoDateByDaysWeeksMonthsYears() {
        assertEquals("2026-11-19", render("${d + 1 d}", "d", "2026-11-18"));
        assertEquals("2026-12-02", render("${d + 2 w}", "d", "2026-11-18"));
        assertEquals("2026-02-28", render("${d + 1 m}", "d", "2026-01-31"));
        assertEquals("2025-02-28", render("${d + 1 y}", "d", "2024-02-29"));
        assertEquals("2026-12-31", render("${d - 1 d}", "d", "2027-01-01"));
        assertEquals("2026-11-19", render("${d + 1d}", "d", "2026-11-18"));
    }

    @Test
    void timeAndZoneAfterTheDateAreKeptAsTheyAre() {
        assertEquals("2026-11-19T10:15:30.000+01:00",
                render("${d + 1 d}", "d", "2026-11-18T10:15:30.000+01:00"));
        assertEquals("2026-11-17 08:00:00", render("${d - 1 d}", "d", "2026-11-18 08:00:00"));
        assertEquals("2026-12-18T00:00:00Z", render("${d + 1 m}", "d", "2026-11-18T00:00:00Z"));
    }

    @Test
    void otherDateLayoutsKeepTheirLayout() {
        assertEquals("02.12.2026", render("${d + 2 w}", "d", "18.11.2026"));
        assertEquals("28/02/2025", render("${d + 1 y}", "d", "29/02/2024"));
        assertEquals("20270101", render("${d + 1 d}", "d", "20261231"));
    }

    @Test
    void dateFromPreviousStep() {
        assertEquals("2027-01-18",
                TemplateEngine.render("${step1.startDate + 2 m}", Map.of(), step1("startDate", "2026-11-18")));
    }

    @Test
    void today() {
        assertEquals(LocalDate.now().toString(), TemplateEngine.render("${today}", Map.of(), Map.of()));
        assertEquals(LocalDate.now().plusDays(1).toString(),
                TemplateEngine.render("${today + 1 d}", Map.of(), Map.of()));
        assertEquals(LocalDate.now().minusMonths(1).toString(),
                TemplateEngine.render("${today - 1 m}", Map.of(), Map.of()));
    }

    @Test
    void testDataColumnNamedTodayWins() {
        assertEquals("2020-01-01", render("${today}", "today", "2020-01-01"));
    }

    // ---- clear errors ---------------------------------------------------

    @Test
    void dateWithoutUnitSaysToAddOne() {
        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> render("${d + 1}", "d", "2026-11-18"));
        assertTrue(ex.getMessage().contains("add a unit"), ex.getMessage());
    }

    @Test
    void unitOnSomethingThatIsNotADate() {
        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> render("${n + 1 d}", "n", "12345"));
        assertTrue(ex.getMessage().contains("is not a date"), ex.getMessage());
    }

    @Test
    void impossibleDate() {
        IllegalStateException ex = assertThrows(IllegalStateException.class,
                () -> render("${d + 1 d}", "d", "2026-02-30"));
        assertTrue(ex.getMessage().contains("not a valid date"), ex.getMessage());
    }
}
