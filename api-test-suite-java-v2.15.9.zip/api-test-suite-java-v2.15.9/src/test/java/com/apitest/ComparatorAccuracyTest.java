package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.CompareResult;
import com.apitest.model.DiffEntry;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comparison accuracy: exact numeric equality, consistent added/removed
 * labels, ampersands around an escaped XML payload, and pairing of reordered
 * list elements that also carry a difference.
 */
class ComparatorAccuracyTest {

    private static CompareResult cmp(String a, String b) {
        return Comparator.compare(a, b, List.of());
    }

    // ---- numbers -------------------------------------------------------

    @Test
    void largeIdsDifferingInLastDigitAreDifferent() {
        // Both are beyond 2^53, where double cannot tell them apart.
        CompareResult r = cmp("{\"id\":9007199254740993}", "{\"id\":9007199254740992}");
        assertFalse(r.matched);
        assertEquals(1, r.diffs.size());
    }

    @Test
    void wholeNumberEqualsSameNumberWithDecimalPoint() {
        assertTrue(cmp("{\"amount\":12}", "{\"amount\":12.0}").matched);
        assertTrue(cmp("{\"amount\":0.1}", "{\"amount\":0.10}").matched);
    }

    @Test
    void decimalsThatDifferAreReported() {
        assertFalse(cmp("{\"amount\":100.01}", "{\"amount\":100.02}").matched);
    }

    // ---- added / removed ----------------------------------------------

    @Test
    void valueOnlyInSourceBIsAdded() {
        CompareResult r = cmp("{\"a\":null}", "{\"a\":1}");
        assertEquals(1, r.diffs.size());
        assertEquals("added", r.diffs.get(0).kind);
        assertEquals("<missing>", r.diffs.get(0).expected);
    }

    @Test
    void valueOnlyInSourceAIsRemoved() {
        CompareResult r = cmp("{\"a\":1}", "{\"a\":null}");
        assertEquals(1, r.diffs.size());
        assertEquals("removed", r.diffs.get(0).kind);
        assertEquals("<missing>", r.diffs.get(0).actual);
    }

    // ---- ampersands around an escaped payload --------------------------

    @Test
    void ampersandInRealMarkupSurvivesDecodingOfEscapedPayload() throws Exception {
        String payload = "<Envelope><Name>A&amp;B</Name><Content>"
                + "&lt;Inner&gt;&lt;V&gt;x&amp;amp;y&lt;/V&gt;&lt;/Inner&gt;"
                + "</Content></Envelope>";
        String decoded = Comparator.extractInnerPayload(payload);
        Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .parse(new InputSource(new StringReader(decoded)));
        assertEquals("A&B", doc.getElementsByTagName("Name").item(0).getTextContent());
        assertEquals("x&y", doc.getElementsByTagName("V").item(0).getTextContent());
    }

    @Test
    void escapedEntitiesInsideThePayloadAreStillDecoded() {
        String payload = "<C>&lt;R&gt;&lt;T&gt;a &amp;lt; b&lt;/T&gt;&lt;/R&gt;</C>";
        assertEquals("<C><R><T>a &lt; b</T></R></C>", Comparator.extractInnerPayload(payload));
    }

    // ---- list pairing ---------------------------------------------------

    @Test
    void reorderedListWithOneChangedFieldReportsOnlyThatField() {
        String a = "{\"rows\":[{\"id\":1,\"name\":\"a\",\"flag\":\"x\"},"
                + "{\"id\":2,\"name\":\"b\",\"flag\":\"x\"},{\"id\":3,\"name\":\"c\",\"flag\":\"x\"}]}";
        String b = "{\"rows\":[{\"id\":3,\"name\":\"c\",\"flag\":\"y\"},"
                + "{\"id\":1,\"name\":\"a\",\"flag\":\"y\"},{\"id\":2,\"name\":\"b\",\"flag\":\"y\"}]}";
        CompareResult r = cmp(a, b);
        assertFalse(r.matched);
        assertEquals(3, r.diffs.size(), () -> "diffs: " + r.diffs);
        for (DiffEntry d : r.diffs) {
            assertTrue(d.path.endsWith(".flag"), d.path);
            assertEquals("x", d.expected);
            assertEquals("y", d.actual);
        }
    }

    @Test
    void alignedListWithChangesStillPairsByPosition() {
        CompareResult r = cmp("{\"v\":[{\"x\":1},{\"x\":2}]}", "{\"v\":[{\"x\":9},{\"x\":8}]}");
        assertEquals(2, r.diffs.size(), () -> "diffs: " + r.diffs);
        assertEquals("1", r.diffs.get(0).expected);
        assertEquals("9", r.diffs.get(0).actual);
        assertEquals("2", r.diffs.get(1).expected);
        assertEquals("8", r.diffs.get(1).actual);
    }

    @Test
    void surplusElementIsStillReportedAsAdded() {
        CompareResult r = cmp("{\"v\":[{\"x\":1}]}", "{\"v\":[{\"x\":1},{\"x\":2}]}");
        assertEquals(1, r.diffs.size(), () -> "diffs: " + r.diffs);
        assertEquals("added", r.diffs.get(0).kind);
    }
}
