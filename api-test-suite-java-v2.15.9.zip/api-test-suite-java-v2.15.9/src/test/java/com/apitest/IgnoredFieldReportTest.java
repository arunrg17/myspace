package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import com.apitest.model.DiffEntry;
import com.apitest.model.IgnoredField;
import com.apitest.model.TestResult;
import com.apitest.reporter.JsonReport;
import com.apitest.reporter.Reporter;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A comparison records which ignore directives actually matched, and the
 * report lists them. A clean comparison is reported without its payloads.
 */
class IgnoredFieldReportTest {

    private static final String A =
            "{\"rows\":[{\"no\":\"A1\",\"deletedflag\":false},{\"no\":\"A2\",\"deletedflag\":true}],\"ts\":\"t1\"}";
    private static final String B =
            "{\"rows\":[{\"no\":\"A1\"},{\"no\":\"A2\"}],\"ts\":\"t2\"}";

    private static Assertion ignore(String path, String type) {
        return new Assertion(path, type, "ignore", "", "");
    }

    // ---- what the comparator records -------------------------------------

    @Test
    void ignoredFieldsAreRecordedWithCountsPerSide() {
        CompareResult r = Comparator.compare(A, B,
                List.of(ignore("$..deletedflag", "jsonpath"), ignore("$.ts", "jsonpath")));
        assertTrue(r.matched, () -> "diffs: " + r.diffs.size());
        assertEquals(2, r.ignored.size());
        IgnoredField flag = r.ignored.get(0);
        assertEquals("$..deletedflag", flag.path);
        assertEquals("jsonpath", flag.pathType);
        assertEquals(2, flag.countA);
        assertEquals(0, flag.countB);
        assertEquals(1, r.ignored.get(1).countA);
        assertEquals(1, r.ignored.get(1).countB);
    }

    @Test
    void ignoreThatMatchedNothingIsNotListed() {
        CompareResult r = Comparator.compare("{\"a\":1}", "{\"a\":1}",
                List.of(ignore("$..notThere", "jsonpath")));
        assertTrue(r.matched);
        assertTrue(r.ignored.isEmpty());
    }

    @Test
    void xpathIgnoresAreCounted() {
        CompareResult r = Comparator.compare(
                "<r><a>1</a><stamp>x</stamp><stamp>y</stamp></r>",
                "<r><a>1</a><stamp>z</stamp><stamp>w</stamp></r>",
                List.of(ignore("//stamp", "xpath")));
        assertTrue(r.matched, () -> "diffs: " + r.diffs.size());
        assertEquals(1, r.ignored.size());
        assertEquals(2, r.ignored.get(0).countA);
        assertEquals(2, r.ignored.get(0).countB);
    }

    @Test
    void noIgnoreDirectivesMeansNothingRecorded() {
        assertTrue(Comparator.compare("{\"a\":1}", "{\"a\":2}", List.of()).ignored.isEmpty());
    }

    // ---- what the report shows -------------------------------------------

    private static TestResult result(String id, CompareResult cr) {
        TestResult t = new TestResult();
        t.testId = id;
        t.name = id;
        t.comparisonMode = "vs_env";
        t.sourceA = "ENV_A";
        t.sourceB = "ENV_B";
        t.compareResult = cr;
        t.status = cr.matched ? "PASS" : "FAIL";
        return t;
    }

    private static String section(String html, String id) {
        int start = html.indexOf("data-tab=\"compare\"", html.indexOf(">" + id + "<"));
        int end = html.indexOf("data-tab=\"asserts\"", start);
        int next = html.indexOf("</section>", start);
        return html.substring(start, end < 0 || end > next ? next : end);
    }

    @Test
    void cleanComparisonOmitsPayloadsAndListsIgnores() {
        CompareResult clean = Comparator.compare(A, B,
                List.of(ignore("$..deletedflag", "jsonpath"), ignore("$.ts", "jsonpath")));
        String html = Reporter.renderHtml(List.of(result("T_CLEAN", clean)), "suite");
        String cmp = section(html, "T_CLEAN");
        assertTrue(cmp.contains("No differences found."), cmp);
        assertFalse(cmp.contains("compare-payload"), "payloads must not be embedded for a clean comparison");
        assertTrue(cmp.contains("Ignored in this comparison (2)"), cmp);
        assertTrue(cmp.contains("$..deletedflag"), cmp);
    }

    @Test
    void comparisonWithDifferencesKeepsPayloadsAndShowsIgnores() {
        CompareResult bad = Comparator.compare(A, B.replace("\"A2\"", "\"A9\""),
                List.of(ignore("$..deletedflag", "jsonpath"), ignore("$.ts", "jsonpath")));
        assertFalse(bad.matched);
        String html = Reporter.renderHtml(List.of(result("T_DIFF", bad)), "suite");
        String cmp = section(html, "T_DIFF");
        assertFalse(cmp.contains("No differences found."));
        assertTrue(cmp.contains("compare-payload"), "payloads stay when there are differences");
        assertTrue(cmp.contains("Ignored in this comparison (2)"), cmp);
    }

    @Test
    void cleanComparisonWithoutIgnoresShowsOnlyTheMessage() {
        CompareResult clean = Comparator.compare("{\"a\":1}", "{\"a\":1}", List.of());
        String cmp = section(Reporter.renderHtml(List.of(result("T_PLAIN", clean)), "suite"), "T_PLAIN");
        assertTrue(cmp.contains("No differences found."));
        assertFalse(cmp.contains("Ignored in this comparison"));
        assertFalse(cmp.contains("compare-payload"));
    }

    @Test
    void parseErrorIsNotTreatedAsClean() {
        CompareResult broken = new CompareResult();
        broken.matched = false;
        broken.note = "Parse error: bad input";
        broken.preparedExpected = "{";
        broken.preparedActual = "{";
        String cmp = section(Reporter.renderHtml(List.of(result("T_BROKEN", broken)), "suite"), "T_BROKEN");
        assertFalse(cmp.contains("No differences found."));
        assertTrue(cmp.contains("compare-payload"));
    }

    @Test
    void ignoredFieldsRoundTripThroughJsonReport() throws Exception {
        CompareResult clean = Comparator.compare(A, B, List.of(ignore("$..deletedflag", "jsonpath"),
                ignore("$.ts", "jsonpath")));
        List<TestResult> in = new ArrayList<>(List.of(result("T_JSON", clean)));
        JsonReport.Envelope back = JsonReport.fromJson(JsonReport.toJson(in, "suite"));
        CompareResult cr = back.results.get(0).compareResult;
        assertEquals(2, cr.ignored.size());
        assertEquals("$..deletedflag", cr.ignored.get(0).path);
        assertEquals(2, cr.ignored.get(0).countA);
        List<DiffEntry> none = cr.diffs;
        assertTrue(none.isEmpty());
    }
}
