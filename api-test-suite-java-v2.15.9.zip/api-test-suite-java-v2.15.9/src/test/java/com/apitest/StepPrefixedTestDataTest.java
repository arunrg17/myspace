package com.apitest;

import com.apitest.template.TemplateEngine;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A TestData column whose name starts with "step" and contains a dot
 * (step.status, stepRef.id) is ordinary test data. Only ${stepN.name}, with a
 * step number, refers to a value captured by an earlier step.
 */
class StepPrefixedTestDataTest {

    private static Map<Integer, Map<String, String>> captured() {
        Map<Integer, Map<String, String>> steps = new HashMap<>();
        steps.put(1, Map.of("orderId", "ORD-1"));
        return steps;
    }

    @Test
    void testDataColumnStartingWithStepResolves() {
        Map<String, String> data = Map.of("step.status", "ACTIVE", "stepRef.id", "R-9");
        assertEquals("ACTIVE R-9",
                TemplateEngine.render("${step.status} ${stepRef.id}", data, captured()));
    }

    @Test
    void numberedStepReferenceStillReadsCapturedValue() {
        Map<String, String> data = Map.of("orderId", "from-test-data");
        assertEquals("ORD-1", TemplateEngine.render("${step1.orderId}", data, captured()));
    }

    @Test
    void numberedStepReferenceThatWasNotCapturedIsBlank() {
        assertEquals("[]", TemplateEngine.render("[${step1.missing}]", Map.of(), captured()));
        assertEquals("[]", TemplateEngine.render("[${step7.orderId}]", Map.of(), captured()));
    }
}
