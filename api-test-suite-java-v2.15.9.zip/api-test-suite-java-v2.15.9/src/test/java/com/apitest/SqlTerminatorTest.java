package com.apitest;

import com.apitest.comparator.DbQuery;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A query copied from a SQL client usually ends with ';'. The terminator is a
 * client convention, not SQL, and the Oracle driver rejects it (ORA-00911), so
 * the guard drops it. A second statement after it is still refused.
 */
class SqlTerminatorTest {

    @Test
    void trailingSemicolonIsDropped() {
        assertEquals("SELECT status FROM orders WHERE id = 1",
                DbQuery.guard("SELECT status FROM orders WHERE id = 1;"));
        assertEquals("SELECT 1 FROM dual", DbQuery.guard("  SELECT 1 FROM dual ;  "));
    }

    @Test
    void queryWithoutSemicolonIsUnchanged() {
        assertEquals("SELECT 1 FROM dual", DbQuery.guard("SELECT 1 FROM dual"));
    }

    @Test
    void secondStatementIsStillRefused() {
        assertThrows(DbQuery.DbQueryException.class,
                () -> DbQuery.guard("SELECT 1 FROM dual; DELETE FROM orders"));
    }
}
