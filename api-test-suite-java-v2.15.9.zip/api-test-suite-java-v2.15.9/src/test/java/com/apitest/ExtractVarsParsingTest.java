package com.apitest;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ExtractVars pairs may be separated by commas, new lines or semicolons, as the
 * column has always been documented. Only commas used to work, so a cell with
 * one pair per line captured a single variable holding everything after the
 * first '='.
 */
class ExtractVarsParsingTest {

    @SuppressWarnings("unchecked")
    private Map<String, String> parse(String raw) throws Exception {
        Method m = Class.forName("com.apitest.excel.ExcelLoader")
                .getDeclaredMethod("parseExtractVars", String.class);
        m.setAccessible(true);
        return (Map<String, String>) m.invoke(null, raw);
    }

    @Test
    void commaSeparatedIsUnchanged() throws Exception {
        Map<String, String> v = parse("orderId=$.order.id,status=$.order.status");
        assertEquals(2, v.size(), v::toString);
        assertEquals("$.order.id", v.get("orderId"));
        assertEquals("$.order.status", v.get("status"));
    }

    @Test
    void onePairPerLine() throws Exception {
        Map<String, String> v = parse("orderId=$.order.id\nstatus=$.order.status\r\ntotal=//Total");
        assertEquals(3, v.size(), v::toString);
        assertEquals("$.order.id", v.get("orderId"));
        assertEquals("$.order.status", v.get("status"));
        assertEquals("//Total", v.get("total"));
    }

    @Test
    void semicolonSeparated() throws Exception {
        Map<String, String> v = parse("orderId=$.order.id; status=$.order.status");
        assertEquals(2, v.size(), v::toString);
        assertEquals("$.order.id", v.get("orderId"));
        assertEquals("$.order.status", v.get("status"));
    }

    @Test
    void semicolonInsideAFilterIsNotASeparator() throws Exception {
        Map<String, String> v = parse("ref=$.items[?(@.code=='A;B')].ref");
        assertEquals(1, v.size(), v::toString);
        assertEquals("$.items[?(@.code=='A;B')].ref", v.get("ref"));
    }

    @Test
    void blankAndEmpty() throws Exception {
        assertTrue(parse("").isEmpty());
        assertTrue(parse(null).isEmpty());
        assertTrue(parse("\n\n").isEmpty());
    }
}
