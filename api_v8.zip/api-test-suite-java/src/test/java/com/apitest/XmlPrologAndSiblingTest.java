package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class XmlPrologAndSiblingTest {

    // ──────────────────────────────────────────────────────────────────────
    // Issue: parser fails with "processing instruction target matching xml is not allowed"
    // Cause: BOM, leading whitespace, or other junk before <?xml ... ?>
    // ──────────────────────────────────────────────────────────────────────

    @Test
    void bomPrefixedXmlIsParseable() {
        String xml = "\uFEFF<?xml version=\"1.0\"?><r><a>hello</a></r>";
        assertEquals("hello", Comparator.extractVariable(xml, "//a"));
    }

    @Test
    void leadingWhitespaceBeforeProlog() {
        String xml = "   \n\n<?xml version=\"1.0\"?><r><a>x</a></r>";
        assertEquals("x", Comparator.extractVariable(xml, "//a"));
    }

    @Test
    void leadingControlCharactersBeforeProlog() {
        String xml = "\u0000\u0001<?xml version=\"1.0\"?><r><a>y</a></r>";
        assertEquals("y", Comparator.extractVariable(xml, "//a"));
    }

    @Test
    void xmlWithoutDeclarationStillWorks() {
        // No <?xml ... ?> at all — should still extract
        String xml = "<r><a>z</a></r>";
        assertEquals("z", Comparator.extractVariable(xml, "//a"));
    }

    @Test
    void parseErrorSurfacesAsExtractionException() {
        // Genuinely malformed XML — should throw, not silently return ""
        String xml = "<r><unclosed>";
        Comparator.ExtractionException ex = assertThrows(
                Comparator.ExtractionException.class,
                () -> Comparator.extractVariable(xml, "//unclosed"));
        assertTrue(ex.getMessage().contains("XML parse failed"), ex.getMessage());
    }

    @Test
    void assertionEngineCatchesExtractionException() {
        // The AssertionEngine should not crash on parse failures — it should
        // record the failure as the assertion message.
        String xml = "<r><broken>";
        List<Assertion> assertions = List.of(
                new Assertion("//anything", "xpath", "equals", "x", "test")
        );
        List<AssertionResult> results = AssertionEngine.evaluate(xml, assertions);
        assertEquals(1, results.size());
        assertFalse(results.get(0).passed);
        assertTrue(results.get(0).message.contains("XML parse failed"),
                "Should show real error in message: " + results.get(0).message);
    }

    // ──────────────────────────────────────────────────────────────────────
    // The user's specific pattern: find a SecurityItem by unique ID, then
    // read sibling fields from THAT SAME SecurityItem.
    // ──────────────────────────────────────────────────────────────────────

    private static final String SECURITIES = """
            <?xml version="1.0"?>
            <Portfolio>
              <securityItem>
                <Security>
                  <id>abc111</id>
                  <name>Stock A</name>
                  <cost>100.50</cost>
                  <currency>USD</currency>
                  <quantity>10</quantity>
                </Security>
              </securityItem>
              <securityItem>
                <Security>
                  <id>abc123</id>
                  <name>Bond X</name>
                  <cost>249.95</cost>
                  <currency>EUR</currency>
                  <quantity>5</quantity>
                </Security>
              </securityItem>
              <securityItem>
                <Security>
                  <id>abc456</id>
                  <name>Stock C</name>
                  <cost>50.00</cost>
                  <currency>GBP</currency>
                  <quantity>20</quantity>
                </Security>
              </securityItem>
            </Portfolio>
            """;

    @Test
    void findByIdReturnsCorrectId() {
        // exists check via predicate
        String id = Comparator.extractVariable(SECURITIES,
                "//securityItem/Security[id='abc123']/id");
        assertEquals("abc123", id);
    }

    @Test
    void findSiblingsOfUniqueId_TheUsersExactQuestion() {
        // Lookup the cost of the security with id='abc123' — exactly what
        // the user asked. Plain //cost would return 100.50 (first one); this
        // predicate path picks the right sibling.
        String cost = Comparator.extractVariable(SECURITIES,
                "//securityItem/Security[id='abc123']/cost");
        assertEquals("249.95", cost);

        String name = Comparator.extractVariable(SECURITIES,
                "//securityItem/Security[id='abc123']/name");
        assertEquals("Bond X", name);

        String currency = Comparator.extractVariable(SECURITIES,
                "//securityItem/Security[id='abc123']/currency");
        assertEquals("EUR", currency);

        String quantity = Comparator.extractVariable(SECURITIES,
                "//securityItem/Security[id='abc123']/quantity");
        assertEquals("5", quantity);
    }

    @Test
    void plainPathReturnsFirstNotMatching() {
        // Demonstrates WHY the predicate is needed: //cost returns first match
        assertEquals("100.50", Comparator.extractVariable(SECURITIES, "//cost"));
    }

    @Test
    void assertSiblingOfUniqueIdViaAssertionEngine() {
        // End-to-end through the assertion engine: equals with the right path
        Assertion a = new Assertion(
                "//securityItem/Security[id='abc123']/cost",
                "xpath", "equals", "249.95", "Bond X cost");
        List<AssertionResult> results = AssertionEngine.evaluate(SECURITIES, List.of(a));
        assertTrue(results.get(0).passed,
                "Should pass — actual was: " + results.get(0).actualValue);
        assertEquals("249.95", results.get(0).actualValue);
    }

    @Test
    void notExistsCorrectlyReturnsEmptyWithNoError() {
        // Genuinely missing element should return empty, not throw
        String v = Comparator.extractVariable(SECURITIES, "//securityItem/Security[id='nope']/cost");
        assertEquals("", v);
    }

    // ──────────────────────────────────────────────────────────────────────
    // detectFormat should still recognize BOM-prefixed XML as XML
    // ──────────────────────────────────────────────────────────────────────

    @Test
    void detectFormatHandlesBom() {
        assertEquals("xml", Comparator.detectFormat("\uFEFF<?xml version=\"1.0\"?><r/>"));
        assertEquals("xml", Comparator.detectFormat("   <r/>"));
    }
}
