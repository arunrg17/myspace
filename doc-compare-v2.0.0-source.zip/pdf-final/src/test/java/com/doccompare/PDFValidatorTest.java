package com.doccompare;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.List;

/**
 * Unit tests for the validation API surface.
 *
 * <p>These tests exercise builder semantics, rule construction, and result
 * aggregation. End-to-end PDF validation tests require a real PDF and
 * PDFBox runtime — they are covered by integration tests run via
 * {@code mvn verify} after the main build.
 */
public class PDFValidatorTest {

    // ════════════════════════════════════════════════════════════════════════
    //  BUILDER
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testBuilderRequiresPdfPath() {
        try {
            new ValidationConfig.Builder().build();
            fail("Expected IllegalStateException");
        } catch (IllegalStateException expected) {
            assertTrue(expected.getMessage().contains("pdf"));
        }
    }

    @Test
    public void testBuilderAllRuleTypes() {
        ValidationConfig cfg = new ValidationConfig.Builder()
            .pdf("test.pdf")
            .report("out.html")
            .mustContain("body text")
            .mustNotContain("FEHLER")
            .mustContainInLeftMargin("COSREP0001")
            .mustContainInRightMargin("PAGE 1")
            .mustContainOnAllPages("nur zur internen Verwendung")
            .mustContainOnAnyPage("Anhang")
            .mustContainOnPage(3, "Spezifischer Text")
            .mustContainBetween("target", "before", "after")
            .mustHaveImage()
            .mustHaveImageOnAllPages()
            .minPages(2)
            .maxPages(50)
            .build();

        assertEquals("test.pdf", cfg.getPdfPath());
        assertEquals("out.html", cfg.getReportPath());

        List<ValidationConfig.Rule> rules = cfg.getRules();
        assertEquals(12, rules.size());

        assertEquals(ValidationConfig.Rule.Type.MUST_CONTAIN,            rules.get(0).type);
        assertEquals(ValidationConfig.Rule.Type.MUST_NOT_CONTAIN,        rules.get(1).type);
        assertEquals(ValidationConfig.Rule.Type.MUST_CONTAIN_LEFT_MARGIN, rules.get(2).type);
        assertEquals(ValidationConfig.Rule.Type.MUST_CONTAIN_RIGHT_MARGIN,rules.get(3).type);
        assertEquals(ValidationConfig.Rule.Type.MUST_CONTAIN_ALL_PAGES,  rules.get(4).type);
        assertEquals(ValidationConfig.Rule.Type.MUST_CONTAIN_ANY_PAGE,   rules.get(5).type);
        assertEquals(ValidationConfig.Rule.Type.MUST_CONTAIN_ON_PAGE,    rules.get(6).type);
        assertEquals(3, rules.get(6).pageNumber);
        assertEquals(ValidationConfig.Rule.Type.MUST_CONTAIN_BETWEEN,    rules.get(7).type);
        assertEquals("before", rules.get(7).before);
        assertEquals("after",  rules.get(7).after);
        assertEquals(ValidationConfig.Rule.Type.MUST_HAVE_IMAGE,         rules.get(8).type);
        assertEquals(ValidationConfig.Rule.Type.MUST_HAVE_IMAGE_ALL_PAGES,rules.get(9).type);
        assertEquals(ValidationConfig.Rule.Type.MIN_PAGES,               rules.get(10).type);
        assertEquals(2, rules.get(10).number);
        assertEquals(ValidationConfig.Rule.Type.MAX_PAGES,               rules.get(11).type);
        assertEquals(50, rules.get(11).number);
    }

    @Test
    public void testRulesListIsImmutable() {
        ValidationConfig cfg = new ValidationConfig.Builder()
            .pdf("test.pdf").mustContain("x").build();
        try {
            cfg.getRules().add(null);
            fail("Expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) {
            // good
        }
    }

    @Test
    public void testCaseSensitivityDefault() {
        ValidationConfig cfg = new ValidationConfig.Builder()
            .pdf("test.pdf")
            .mustContain("text")
            .build();
        // Default is case-insensitive
        assertFalse(cfg.getRules().get(0).caseSensitive);
    }

    @Test
    public void testCaseSensitivityOverride() {
        ValidationConfig cfg = new ValidationConfig.Builder()
            .pdf("test.pdf")
            .caseSensitive(true)
            .mustContain("Text")
            .build();
        assertTrue(cfg.getRules().get(0).caseSensitive);
    }

    @Test
    public void testMarginPctDefault() {
        ValidationConfig cfg = new ValidationConfig.Builder().pdf("a.pdf").build();
        assertEquals(8.0, cfg.getMarginPct(), 0.001);
    }

    @Test
    public void testMarginPctOverride() {
        ValidationConfig cfg = new ValidationConfig.Builder().pdf("a.pdf")
            .marginPct(12.0).build();
        assertEquals(12.0, cfg.getMarginPct(), 0.001);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  RULE DESCRIPTIONS
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testRuleDescriptions() {
        ValidationConfig cfg = new ValidationConfig.Builder()
            .pdf("a.pdf")
            .mustContain("Foo")
            .mustNotContain("Bar")
            .mustContainInLeftMargin("Cosrep")
            .mustContainOnAllPages("nur zur")
            .mustContainOnPage(5, "Total")
            .mustContainBetween("Q3", "Period:", "End:")
            .mustHaveImage()
            .minPages(3)
            .maxPages(50)
            .build();

        List<ValidationConfig.Rule> r = cfg.getRules();
        assertTrue(r.get(0).description().contains("Must contain"));
        assertTrue(r.get(0).description().contains("Foo"));
        assertTrue(r.get(1).description().contains("Must NOT contain"));
        assertTrue(r.get(2).description().contains("left margin"));
        assertTrue(r.get(3).description().contains("every page"));
        assertTrue(r.get(4).description().contains("page 5"));
        assertTrue(r.get(5).description().contains("between"));
        assertTrue(r.get(5).description().contains("Period:"));
        assertTrue(r.get(5).description().contains("End:"));
        assertTrue(r.get(6).description().contains("image"));
        assertTrue(r.get(7).description().contains("at least 3"));
        assertTrue(r.get(8).description().contains("at most 50"));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  RESULT AGGREGATION
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testResultStatusError() {
        ValidationResult r = ValidationResult.error("a.pdf", "out.html", "File not found");
        assertEquals(ValidationResult.Status.ERROR, r.getStatus());
        assertFalse(r.isPassed());
        assertTrue(r.getSummary().contains("ERROR"));
        assertTrue(r.getSummary().contains("File not found"));
    }

    @Test
    public void testResultSummaryFormat() {
        ValidationConfig cfg = new ValidationConfig.Builder().pdf("a.pdf")
            .mustContain("a").mustContain("b").mustContain("c").build();

        java.util.List<ValidationResult.RuleResult> rrs = new java.util.ArrayList<>();
        rrs.add(new ValidationResult.RuleResult(cfg.getRules().get(0), true,  "found"));
        rrs.add(new ValidationResult.RuleResult(cfg.getRules().get(1), true,  "found"));
        rrs.add(new ValidationResult.RuleResult(cfg.getRules().get(2), false, "missing"));

        ValidationResult fail = ValidationResult.failure(5, "a.pdf", "out.html", rrs);
        assertEquals(2, fail.getPassedCount());
        assertEquals(1, fail.getFailedCount());
        assertTrue(fail.getSummary().contains("FAIL"));
        assertTrue(fail.getSummary().contains("2/3"));
        assertTrue(fail.getFailureDetails().contains("missing"));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PROPERTIES FILE LOADING
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testRulesFromProperties() {
        java.util.Properties p = new java.util.Properties();
        p.setProperty("must.contain.1",                  "Foo");
        p.setProperty("must.contain.2",                  "Bar");
        p.setProperty("must.not.contain.1",              "FEHLER");
        p.setProperty("must.contain.left-margin.1",      "COSREP");
        p.setProperty("must.contain.all-pages.1",        "nur zur internen Verwendung");
        p.setProperty("must.contain.between.1",          "Q3|Period:|End:");
        p.setProperty("must.contain.page.1",             "1=Bericht");
        p.setProperty("must.have.image",                 "true");
        p.setProperty("min.pages",                       "5");
        p.setProperty("max.pages",                       "50");
        p.setProperty("margin.pct",                      "10.0");

        ValidationConfig cfg = new ValidationConfig.Builder()
            .pdf("test.pdf")
            .rulesFromProperties(p)
            .build();

        List<ValidationConfig.Rule> rules = cfg.getRules();
        assertEquals(9, rules.size());
        assertEquals(10.0, cfg.getMarginPct(), 0.001);

        // Verify the BETWEEN rule split correctly
        ValidationConfig.Rule between = null;
        for (ValidationConfig.Rule r : rules) {
            if (r.type == ValidationConfig.Rule.Type.MUST_CONTAIN_BETWEEN) {
                between = r;
                break;
            }
        }
        assertNotNull(between);
        assertEquals("Q3",      between.primary);
        assertEquals("Period:", between.before);
        assertEquals("End:",    between.after);

        // Verify the page-specific rule
        ValidationConfig.Rule page1 = null;
        for (ValidationConfig.Rule r : rules) {
            if (r.type == ValidationConfig.Rule.Type.MUST_CONTAIN_ON_PAGE) {
                page1 = r;
                break;
            }
        }
        assertNotNull(page1);
        assertEquals(1, page1.pageNumber);
        assertEquals("Bericht", page1.primary);
    }

    @Test
    public void testNumberedRulesStopAtGap() {
        // The loader should stop at .3 because .4 is missing
        java.util.Properties p = new java.util.Properties();
        p.setProperty("must.contain.1", "A");
        p.setProperty("must.contain.2", "B");
        p.setProperty("must.contain.3", "C");
        p.setProperty("must.contain.5", "E"); // gap — should NOT be loaded

        ValidationConfig cfg = new ValidationConfig.Builder()
            .pdf("test.pdf")
            .rulesFromProperties(p)
            .build();
        assertEquals(3, cfg.getRules().size());
    }
}
