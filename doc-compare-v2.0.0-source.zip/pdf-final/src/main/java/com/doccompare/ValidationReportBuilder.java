package com.doccompare;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** Builds a self-contained HTML report for validation results. */
final class ValidationReportBuilder {

    private ValidationReportBuilder() {}

    static String build(String pdfPath, int totalPages,
                         List<ValidationResult.RuleResult> results,
                         boolean allPassed) {

        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        int passed = 0;
        for (ValidationResult.RuleResult r : results) if (r.passed) passed++;
        int failed = results.size() - passed;
        String fileName = new java.io.File(pdfPath).getName();

        StringBuilder sb = new StringBuilder(8192);
        sb.append("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n")
          .append("<meta charset=\"UTF-8\">\n")
          .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n")
          .append("<meta http-equiv=\"Content-Security-Policy\" content=\"")
          .append("default-src 'none'; style-src 'unsafe-inline';\">\n")
          .append("<title>PDF Validator — [").append(allPassed ? "PASS" : "FAIL")
          .append("] ").append(PDFComparator.escHtml(fileName)).append("</title>\n")
          .append("<style>\n").append(CSS).append("</style>\n")
          .append("</head>\n<body>\n");

        // ── Toolbar ──
        sb.append("<div class=\"toolbar\">\n")
          .append("  <div class=\"tb-row\">\n")
          .append("    <span class=\"verdict ").append(allPassed ? "v-pass" : "v-fail").append("\">")
          .append(allPassed ? "&#10003; PASS" : "&#10007; FAIL").append("</span>\n")
          .append("    <span class=\"tb-app\">&#128196; PDF Validator</span>\n")
          .append("    <span class=\"tb-file\">").append(PDFComparator.escHtml(fileName)).append("</span>\n")
          .append("    <span class=\"tb-ts\">&#128336; ").append(ts).append("</span>\n")
          .append("  </div>\n")
          .append("  <div class=\"stats\">\n")
          .append("    <div class=\"stat\"><span class=\"s-l\">Pages</span><span class=\"s-v\">")
          .append(totalPages).append("</span></div>\n")
          .append("    <div class=\"stat s-good\"><span class=\"s-l\">Passed</span><span class=\"s-v\">")
          .append(passed).append("</span></div>\n")
          .append("    <div class=\"stat ").append(failed > 0 ? "s-bad" : "s-good")
          .append("\"><span class=\"s-l\">Failed</span><span class=\"s-v\">")
          .append(failed).append("</span></div>\n")
          .append("    <div class=\"stat\"><span class=\"s-l\">Total Rules</span><span class=\"s-v\">")
          .append(results.size()).append("</span></div>\n")
          .append("  </div>\n")
          .append("</div>\n");

        // ── Rule results table ──
        sb.append("<div class=\"content\">\n")
          .append("  <h2 class=\"section-title\">Validation Rules</h2>\n")
          .append("  <table class=\"tbl\">\n")
          .append("    <thead><tr>\n")
          .append("      <th class=\"th-num\">#</th>\n")
          .append("      <th class=\"th-status\">Status</th>\n")
          .append("      <th class=\"th-rule\">Rule</th>\n")
          .append("      <th class=\"th-detail\">Detail</th>\n")
          .append("    </tr></thead>\n")
          .append("    <tbody>\n");

        for (int i = 0; i < results.size(); i++) {
            ValidationResult.RuleResult r = results.get(i);
            String rowCls = r.passed ? "row-pass" : "row-fail";
            sb.append("      <tr class=\"").append(rowCls).append("\">\n")
              .append("        <td class=\"num\">").append(i + 1).append("</td>\n")
              .append("        <td class=\"status\">")
              .append(r.passed ? "<span class=\"badge-pass\">&#10003; PASS</span>"
                                : "<span class=\"badge-fail\">&#10007; FAIL</span>")
              .append("</td>\n")
              .append("        <td class=\"rule\">").append(PDFComparator.escHtml(r.rule.description()))
              .append("</td>\n")
              .append("        <td class=\"detail\">")
              .append(r.detail != null ? PDFComparator.escHtml(r.detail) : "")
              .append("</td>\n")
              .append("      </tr>\n");
        }

        sb.append("    </tbody>\n  </table>\n");

        if (results.isEmpty()) {
            sb.append("  <div class=\"empty\">No validation rules were configured.</div>\n");
        }

        sb.append("</div>\n");

        // ── Footer ──
        sb.append("<div class=\"footer\">\n")
          .append("  <span class=\"f-l\">PDF:</span>\n")
          .append("  <code>").append(PDFComparator.escHtml(pdfPath)).append("</code>\n")
          .append("</div>\n")
          .append("</body>\n</html>\n");

        return sb.toString();
    }

    private static final String CSS =
        "*{box-sizing:border-box;margin:0;padding:0;}\n" +
        "html,body{height:100%;}\n" +
        "body{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;background:#eceff1;color:#212121;display:flex;flex-direction:column;}\n" +

        // Toolbar
        ".toolbar{position:sticky;top:0;z-index:100;background:linear-gradient(135deg,#1a237e 0%,#283593 60%,#1565c0 100%);" +
        "color:#fff;padding:10px 20px 7px;box-shadow:0 3px 12px rgba(0,0,0,.5);}\n" +
        ".tb-row{display:flex;align-items:center;gap:12px;margin-bottom:8px;flex-wrap:wrap;}\n" +
        ".verdict{font-size:15px;font-weight:800;padding:3px 16px;border-radius:5px;letter-spacing:.5px;flex-shrink:0;}\n" +
        ".v-pass{background:#1b5e20;color:#a5d6a7;border:1px solid #2e7d32;}\n" +
        ".v-fail{background:#b71c1c;color:#ffcdd2;border:1px solid #c62828;}\n" +
        ".tb-app{font-size:14px;font-weight:700;color:#fff;letter-spacing:.3px;}\n" +
        ".tb-file{font-size:12px;font-weight:600;color:#80deea;background:rgba(255,255,255,.12);padding:2px 10px;border-radius:12px;max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}\n" +
        ".tb-ts{font-size:11px;color:#90caf9;margin-left:auto;white-space:nowrap;}\n" +

        ".stats{display:flex;gap:6px;flex-wrap:wrap;}\n" +
        ".stat{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.15);border-radius:6px;padding:3px 14px;display:flex;flex-direction:column;align-items:center;min-width:70px;}\n" +
        ".s-l{font-size:9px;color:#90a4ae;text-transform:uppercase;letter-spacing:.6px;}\n" +
        ".s-v{font-size:18px;font-weight:700;color:#fff;line-height:1.2;}\n" +
        ".s-good .s-v{color:#a5d6a7;}\n" +
        ".s-bad  .s-v{color:#ef9a9a;}\n" +

        // Content
        ".content{flex:1;padding:20px;overflow-y:auto;}\n" +
        ".section-title{font-size:15px;font-weight:700;color:#37474f;margin-bottom:12px;letter-spacing:.3px;}\n" +
        ".tbl{width:100%;border-collapse:collapse;background:#fff;border-radius:6px;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.08);}\n" +
        ".tbl th{background:#37474f;color:#fff;padding:10px 14px;font-size:12px;font-weight:700;text-align:left;text-transform:uppercase;letter-spacing:.4px;}\n" +
        ".th-num{width:50px;text-align:center !important;}\n" +
        ".th-status{width:110px;}\n" +
        ".th-rule{width:auto;}\n" +
        ".th-detail{width:35%;}\n" +
        ".tbl td{padding:10px 14px;border-bottom:1px solid #e8ecf0;vertical-align:top;font-size:12.5px;}\n" +
        ".num{text-align:center;color:#90a4ae;font-family:monospace;font-weight:600;}\n" +
        ".badge-pass{display:inline-block;background:#c8e6c9;color:#1b5e20;padding:3px 10px;border-radius:4px;font-weight:700;font-size:11px;}\n" +
        ".badge-fail{display:inline-block;background:#ffcdd2;color:#b71c1c;padding:3px 10px;border-radius:4px;font-weight:700;font-size:11px;}\n" +
        ".rule{color:#263238;font-weight:500;}\n" +
        ".detail{color:#546e7a;font-style:italic;}\n" +
        ".row-pass{background:#fafbfc;}\n" +
        ".row-fail{background:#fff5f5;}\n" +
        ".row-fail .rule{color:#b71c1c;font-weight:600;}\n" +
        ".empty{padding:40px;text-align:center;color:#9e9e9e;font-style:italic;}\n" +

        // Footer
        ".footer{background:#263238;color:#90a4ae;padding:8px 20px;display:flex;align-items:center;gap:10px;font-size:11px;flex-shrink:0;}\n" +
        ".f-l{color:#546e7a;}\n" +
        ".footer code{font-family:monospace;color:#80cbc4;background:rgba(255,255,255,.05);padding:3px 8px;border-radius:4px;border:1px solid rgba(255,255,255,.1);word-break:break-all;flex:1;}\n";
}
