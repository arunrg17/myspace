package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * PDF Text Comparator — core engine.
 *
 * <h2>Programmatic usage (Selenium / JUnit)</h2>
 * <pre>{@code
 *   FilterConfig config = new FilterConfig.Builder()
 *       .pdf1("baseline.pdf")
 *       .pdf2("actual.pdf")
 *       .output("report.html")
 *       .ignoreHeader(true)
 *       .ignoreFooter(true)
 *       .ignoreMargins(true)
 *       .ignoreTimestamps(true)
 *       .build();
 *
 *   CompareResult result = PDFComparator.compare(config);
 *   Assert.assertTrue("Diffs: " + result.getReportPath(), result.isPassed());
 * }</pre>
 *
 * <h2>CLI usage (UFT / CI)</h2>
 * <pre>
 *   java -jar doc-compare.jar baseline.pdf actual.pdf report.html [options]
 *   Exit codes:  0=PASS  1=FAIL  2=ERROR
 * </pre>
 *
 * <h2>Security</h2>
 * No network calls. No external resources in HTML output. All PDF-derived
 * content is HTML-escaped. No reflection or dynamic class loading.
 */
public final class PDFComparator {

    public static final int EXIT_PASS  = 0;
    public static final int EXIT_FAIL  = 1;
    public static final int EXIT_ERROR = 2;

    private static final Logger LOG = Logger.getLogger(PDFComparator.class.getName());

    static {
        // Suppress PDFBox verbose logging — not needed in automation environments
        // These cover the "CMap format 4 subtable is empty" warning from font parsing
        Logger.getLogger("org.apache.pdfbox").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.pdfbox.pdmodel.font").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.pdfbox.rendering").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.fontbox").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.fontbox.cmap").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.fontbox.ttf").setLevel(Level.SEVERE);
        Logger.getLogger("com.github.jai_imageio").setLevel(Level.SEVERE);
    }

    private PDFComparator() {}

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC API
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Run a full PDF comparison and write the HTML report.
     * Never throws — errors are returned as CompareResult.Status.ERROR.
     */
    public static CompareResult compare(FilterConfig config) {
        try {
            return doCompare(config);
        } catch (Exception ex) {
            LOG.severe("Comparison error: " + ex.getMessage());
            return new CompareResult(CompareResult.Status.ERROR,
                0, 0, 0, 0, 0, 0, null, ex.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CLI ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    public static void main(String[] args) {
        System.exit(runCli(args));
    }

    static int runCli(String[] args) {
        if (args.length < 3) {
            printUsage();
            return EXIT_ERROR;
        }

        FilterConfig.Builder builder;
        try {
            builder = new FilterConfig.Builder()
                .pdf1(args[0])
                .pdf2(args[1])
                .output(args[2]);
        } catch (IllegalArgumentException ex) {
            System.err.println("[ERROR] " + ex.getMessage());
            return EXIT_ERROR;
        }

        for (int i = 3; i < args.length; i++) {
            String flag = args[i].trim();
            try {
                switch (flag) {
                    case "--ignore-header":       builder.ignoreHeader(true);      break;
                    case "--ignore-footer":       builder.ignoreFooter(true);      break;
                    case "--ignore-left-margin":  builder.ignoreLeftMargin(true);  break;
                    case "--ignore-right-margin": builder.ignoreRightMargin(true); break;
                    case "--ignore-margins":      builder.ignoreMargins(true);     break;
                    case "--ignore-timestamps":   builder.ignoreTimestamps(true);  break;
                    case "--ignore-page-numbers": builder.ignorePageNumbers(true); break;
                    default:
                        if (flag.startsWith("--header-pct="))
                            builder.headerPct(parseDouble(flag));
                        else if (flag.startsWith("--footer-pct="))
                            builder.footerPct(parseDouble(flag));
                        else if (flag.startsWith("--margin-pct="))
                            builder.marginPct(parseDouble(flag));
                        else if (flag.startsWith("--ignore-pattern="))
                            builder.ignorePattern(flag.substring("--ignore-pattern=".length()));
                        else if (flag.startsWith("--ignore-text="))
                            builder.ignoreText(flag.substring("--ignore-text=".length()));
                        else if (flag.startsWith("--ignore-config=")) {
                            try { builder.ignoreConfig(flag.substring("--ignore-config=".length())); }
                            catch (IOException ex) {
                                System.err.println("[ERROR] Cannot read config file: " + ex.getMessage());
                                return EXIT_ERROR;
                            }
                        } else
                            System.err.println("[WARN] Unknown flag ignored: " + flag);
                }
            } catch (IllegalArgumentException ex) {
                System.err.println("[ERROR] Bad option '" + flag + "': " + ex.getMessage());
                return EXIT_ERROR;
            }
        }

        FilterConfig config;
        try { config = builder.build(); }
        catch (IllegalArgumentException ex) {
            System.err.println("[ERROR] " + ex.getMessage());
            return EXIT_ERROR;
        }

        System.out.println("  PDF Text Comparator v2.0.0");
        System.out.println("  PDF 1  : " + config.getPdf1Path());
        System.out.println("  PDF 2  : " + config.getPdf2Path());
        System.out.println("  Output : " + config.getOutputPath());
        System.out.println("  Filters: " + config.summary());
        System.out.println();

        CompareResult r = compare(config);

        System.out.println("  Result  : " + r.getStatus());
        System.out.println("  Same    : " + r.getSameLines());
        System.out.println("  Added   : " + r.getAddedLines());
        System.out.println("  Removed : " + r.getRemovedLines());
        System.out.println("  Changed : " + r.getChangedLines());
        if (r.getReportPath()   != null) System.out.println("  Report  : " + r.getReportPath());
        if (r.getErrorMessage() != null) System.err.println("  Error   : " + r.getErrorMessage());

        switch (r.getStatus()) {
            case PASS:  return EXIT_PASS;
            case FAIL:  return EXIT_FAIL;
            default:    return EXIT_ERROR;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CORE LOGIC
    // ════════════════════════════════════════════════════════════════════════

    private static CompareResult doCompare(FilterConfig config) throws Exception {

        File f1 = validateFile(config.getPdf1Path());
        File f2 = validateFile(config.getPdf2Path());
        File out = prepareOutputFile(config.getOutputPath());

        String[] lines1 = extractLines(f1, config);
        String[] lines2 = extractLines(f2, config);

        List<DiffRow> diff = computeDiff(lines1, lines2);

        int added = 0, removed = 0, changed = 0, same = 0;
        for (DiffRow r : diff) {
            switch (r.type) {
                case ADDED:   added++;   break;
                case REMOVED: removed++; break;
                case CHANGED: changed++; break;
                default:      same++;    break;
            }
        }

        boolean passed = (added + removed + changed) == 0;

        String html = HtmlReportBuilder.build(
            diff, f1, f2, config,
            lines1.length, lines2.length,
            added, removed, changed, passed);

        Files.write(out.toPath(), html.getBytes(StandardCharsets.UTF_8));

        return new CompareResult(
            passed ? CompareResult.Status.PASS : CompareResult.Status.FAIL,
            added, removed, changed, same,
            lines1.length, lines2.length,
            out.getAbsolutePath(), null);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  VALIDATION
    // ════════════════════════════════════════════════════════════════════════

    static File validateFile(String path) throws IOException {
        if (path == null || path.trim().isEmpty())
            throw new IOException("File path must not be blank");
        File f = new File(path);
        if (!f.exists())  throw new IOException("File not found: " + f.getAbsolutePath());
        if (!f.isFile())  throw new IOException("Not a file: " + f.getAbsolutePath());
        if (!f.canRead()) throw new IOException("Cannot read: " + f.getAbsolutePath());
        if (!f.getName().toLowerCase().endsWith(".pdf"))
            throw new IOException("Only PDF files supported: " + f.getName());
        return f;
    }

    private static File prepareOutputFile(String path) throws IOException {
        String resolved = (path.endsWith(".html") || path.endsWith(".htm")) ? path : path + ".html";
        File f = new File(resolved);
        File parent = f.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs())
            throw new IOException("Cannot create output directory: " + parent.getAbsolutePath());
        return f;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TEXT EXTRACTION
    // ════════════════════════════════════════════════════════════════════════

    static String[] extractLines(File file, FilterConfig config) throws Exception {
        String raw;
        try (PDDocument doc = PDDocument.load(file)) {
            raw = new ZoneAwareStripper(config).getText(doc);
        }
        List<String> lines = new ArrayList<>();
        for (String line : raw.split("\n", -1)) {
            String processed = config.processLine(line);
            if (processed != null && !processed.isEmpty()) {
                lines.add(processed);
            }
        }
        return mergeTableRows(lines);
    }

    /**
     * Merges table rows that PDFBox splits into many short lines.
     *
     * <p>When PDFBox extracts a financial table, each cell becomes a separate
     * line: "A40HAR" / "ANR.A.S2MEDICAL AB" / "0,00" / "0,00" / "0,00" ...
     * This causes serious LCS diff problems because identical "0,00" values
     * appear hundreds of times and cannot be uniquely matched.
     *
     * <p>This method detects short lines that are part of a table row and
     * merges them with adjacent short lines into a single logical line.
     * A "table context" is a sequence of lines where most are short (< 30 chars).
     * Within such a context, consecutive short lines are joined with a space.
     *
     * <p>Long lines (>= 30 chars) are kept as-is — they are headings or
     * descriptive text that does not need merging.
     */
    private static String[] mergeTableRows(List<String> lines) {
        if (lines.isEmpty()) return new String[0];

        // Detect if the document has a significant table section
        // (many short lines in sequence)
        int shortLineCount = 0;
        for (String l : lines) {
            if (l.trim().length() < 30) shortLineCount++;
        }
        // If less than 30% short lines, no merging needed
        if (shortLineCount < lines.size() * 0.30) {
            return lines.toArray(new String[0]);
        }

        List<String> result = new ArrayList<>();
        List<String> pendingShort = new ArrayList<>();

        for (String line : lines) {
            String t = line.trim();
            boolean isShort = t.length() < 30;

            if (isShort) {
                pendingShort.add(t);
            } else {
                // Flush pending short lines first
                if (!pendingShort.isEmpty()) {
                    flushShortLines(pendingShort, result);
                    pendingShort.clear();
                }
                result.add(line);
            }
        }
        // Flush any remaining short lines
        if (!pendingShort.isEmpty()) {
            flushShortLines(pendingShort, result);
        }
        return result.toArray(new String[0]);
    }

    /**
     * Groups a list of short lines into logical table rows.
     * Lines that look like a new WKN/entry start a new group.
     * All other short lines are appended to the current group.
     */
    private static void flushShortLines(List<String> shortLines, List<String> result) {
        if (shortLines.isEmpty()) return;

        // Try to group by "anchor" lines — lines that start a table row
        // An anchor is typically a WKN code (all caps+digits, 5-8 chars)
        // or a line that begins a logical entry
        List<List<String>> groups = new ArrayList<>();
        List<String> currentGroup = new ArrayList<>();

        for (String line : shortLines) {
            // New group if line looks like a table row anchor
            boolean isAnchor = line.matches("[A-Z0-9]{3,8}") ||  // WKN code
                               line.matches("[A-Z0-9]{3,8}\\s+.*") || // WKN + name
                               (currentGroup.isEmpty());
            if (isAnchor && !currentGroup.isEmpty()) {
                groups.add(new ArrayList<>(currentGroup));
                currentGroup.clear();
            }
            currentGroup.add(line);
        }
        if (!currentGroup.isEmpty()) groups.add(currentGroup);

        // Emit each group as a single joined line
        for (List<String> group : groups) {
            if (group.size() == 1) {
                result.add(group.get(0));
            } else {
                result.add(String.join(" ", group));
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  ZONE-AWARE TEXT STRIPPER
    //  Drops text runs that fall inside ignored page zones at extraction time.
    // ════════════════════════════════════════════════════════════════════════

    static final class ZoneAwareStripper extends PDFTextStripper {

        private final FilterConfig config;
        private float pageH = 792f;
        private float pageW = 595f;

        ZoneAwareStripper(FilterConfig config) throws IOException {
            super();
            this.config = config;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle box = page.getMediaBox();
            pageH = box.getHeight();
            pageW = box.getWidth();
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions) throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }
            float sumX = 0f, sumY = 0f;
            for (TextPosition tp : positions) { sumX += tp.getX(); sumY += tp.getY(); }
            float avgX = sumX / positions.size();
            float avgY = sumY / positions.size();
            float yTop = pageH - avgY;  // Y from top of page

            if (config.isIgnoreHeader()      && yTop  < pageH * (config.getHeaderPct()  / 100.0)) return;
            if (config.isIgnoreFooter()      && yTop  > pageH * ((100.0 - config.getFooterPct())  / 100.0)) return;
            if (config.isIgnoreLeftMargin()  && avgX  < pageW * (config.getMarginPct()  / 100.0)) return;
            if (config.isIgnoreRightMargin() && avgX  > pageW * ((100.0 - config.getMarginPct())  / 100.0)) return;

            super.writeString(text, positions);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DIFF TYPES
    // ════════════════════════════════════════════════════════════════════════

    enum DiffType { SAME, ADDED, REMOVED, CHANGED }

    static final class DiffRow {
        final DiffType type;
        final String   left;
        final String   right;
        final int      leftLineNo;
        final int      rightLineNo;

        DiffRow(DiffType type, String left, String right, int leftLineNo, int rightLineNo) {
            this.type        = type;
            this.left        = left  != null ? left  : "";
            this.right       = right != null ? right : "";
            this.leftLineNo  = leftLineNo;
            this.rightLineNo = rightLineNo;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  LCS DIFF ALGORITHM
    // ════════════════════════════════════════════════════════════════════════

    static List<DiffRow> computeDiff(String[] a, String[] b) {
        int n = a.length, m = b.length;
        if ((long) n * m > 4_000_000L) return chunkedDiff(a, b, 1500);
        return lcsBacktrack(a, b, buildLcsTable(a, b));
    }

    private static int[][] buildLcsTable(String[] a, String[] b) {
        int n = a.length, m = b.length;
        int[][] dp = new int[n + 1][m + 1];
        for (int i = n - 1; i >= 0; i--)
            for (int j = m - 1; j >= 0; j--)
                dp[i][j] = norm(a[i]).equals(norm(b[j]))
                    ? dp[i+1][j+1] + 1
                    : Math.max(dp[i+1][j], dp[i][j+1]);
        return dp;
    }

    private static List<DiffRow> lcsBacktrack(String[] a, String[] b, int[][] dp) {
        List<DiffRow> result = new ArrayList<>();
        int i = 0, j = 0, la = 1, lb = 1;
        int n = a.length, m = b.length;

        while (i < n && j < m) {
            if (norm(a[i]).equals(norm(b[j]))) {
                result.add(new DiffRow(DiffType.SAME, a[i], b[j], la++, lb++));
                i++; j++;
            } else {
                // Substitution: both sides cost equally to skip → pair as CHANGED
                boolean isSubstitution = !norm(a[i]).isEmpty()
                    && !norm(b[j]).isEmpty()
                    && dp[i+1][j] == dp[i][j+1];

                if (isSubstitution) {
                    result.add(new DiffRow(DiffType.CHANGED, a[i], b[j], la++, lb++));
                    i++; j++;
                } else if (dp[i+1][j] >= dp[i][j+1]) {
                    result.add(new DiffRow(DiffType.REMOVED, a[i], "", la++, -1));
                    i++;
                } else {
                    result.add(new DiffRow(DiffType.ADDED, "", b[j], -1, lb++));
                    j++;
                }
            }
        }
        while (i < n) { result.add(new DiffRow(DiffType.REMOVED, a[i], "", la++, -1)); i++; }
        while (j < m) { result.add(new DiffRow(DiffType.ADDED,   "", b[j], -1, lb++)); j++; }
        return result;
    }

    private static List<DiffRow> chunkedDiff(String[] a, String[] b, int chunk) {
        List<DiffRow> result = new ArrayList<>();
        int la = 1, lb = 1;
        for (int ai = 0; ai < a.length || ai < b.length; ai += chunk) {
            String[] ca = Arrays.copyOfRange(a, ai, Math.min(ai + chunk, a.length));
            String[] cb = Arrays.copyOfRange(b, ai, Math.min(ai + chunk, b.length));
            for (DiffRow r : computeDiff(ca, cb)) {
                int ln = r.leftLineNo  > 0 ? r.leftLineNo  + la - 1 : -1;
                int rn = r.rightLineNo > 0 ? r.rightLineNo + lb - 1 : -1;
                result.add(new DiffRow(r.type, r.left, r.right, ln, rn));
                if (r.leftLineNo  > 0) la++;
                if (r.rightLineNo > 0) lb++;
            }
        }
        return result;
    }

    private static String norm(String s) { return s == null ? "" : s.trim(); }

    // ════════════════════════════════════════════════════════════════════════
    //  WORD-LEVEL DIFF  (for CHANGED rows — highlights exactly which words differ)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Returns [leftHtml, rightHtml] with &lt;mark&gt; around differing words only.
     * Words that are the same are NOT marked.
     */
    static String[] wordDiff(String left, String right) {
        // Split on word boundaries to get individual tokens
        String[] wa = left.split("(?<=\\W)|(?=\\W)");
        String[] wb = right.split("(?<=\\W)|(?=\\W)");
        int n = wa.length, m = wb.length;

        int[][] dp = new int[n + 1][m + 1];
        for (int i = n - 1; i >= 0; i--)
            for (int j = m - 1; j >= 0; j--)
                dp[i][j] = wa[i].equals(wb[j])
                    ? dp[i+1][j+1] + 1
                    : Math.max(dp[i+1][j], dp[i][j+1]);

        StringBuilder sl = new StringBuilder(), sr = new StringBuilder();
        int i = 0, j = 0;
        while (i < n && j < m) {
            if (wa[i].equals(wb[j])) {
                sl.append(escHtml(wa[i]));
                sr.append(escHtml(wb[j]));
                i++; j++;
            } else if (dp[i+1][j] >= dp[i][j+1]) {
                sl.append("<mark>").append(escHtml(wa[i])).append("</mark>"); i++;
            } else {
                sr.append("<mark>").append(escHtml(wb[j])).append("</mark>"); j++;
            }
        }
        while (i < n) sl.append("<mark>").append(escHtml(wa[i++])).append("</mark>");
        while (j < m) sr.append("<mark>").append(escHtml(wb[j++])).append("</mark>");
        return new String[]{ sl.toString(), sr.toString() };
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HTML ESCAPING
    // ════════════════════════════════════════════════════════════════════════

    static String escHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CLI HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private static double parseDouble(String flag) {
        String[] p = flag.split("=", 2);
        if (p.length < 2) throw new IllegalArgumentException("Missing value: " + flag);
        return Double.parseDouble(p[1]);
    }

    private static void printUsage() {
        System.err.println("Usage: java -jar doc-compare.jar <pdf1> <pdf2> <output.html> [options]");
        System.err.println();
        System.err.println("Zone options (exclude by position on page):");
        System.err.println("  --ignore-header              Top 10% of each page");
        System.err.println("  --ignore-footer              Bottom 10% of each page");
        System.err.println("  --ignore-left-margin         Left 8% (vertical timestamps)");
        System.err.println("  --ignore-right-margin        Right 8% (watermarks)");
        System.err.println("  --ignore-margins             Both margins");
        System.err.println("  --header-pct=<n>             Override header %  (1-49)");
        System.err.println("  --footer-pct=<n>             Override footer %  (1-49)");
        System.err.println("  --margin-pct=<n>             Override margin %  (1-30)");
        System.err.println();
        System.err.println("Content options:");
        System.err.println("  --ignore-timestamps          Strip date/time patterns");
        System.err.println("  --ignore-page-numbers        Drop page-number lines");
        System.err.println("  --ignore-pattern=<regex>     Strip lines matching regex");
        System.err.println("  --ignore-text=<literal>      Strip exact literal text");
        System.err.println("  --ignore-config=<file>       Load settings from .properties file");
        System.err.println();
        System.err.println("Exit codes: 0=PASS  1=FAIL  2=ERROR");
    }
}
