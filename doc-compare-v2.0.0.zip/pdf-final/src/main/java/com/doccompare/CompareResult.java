package com.doccompare;

/**
 * Immutable result of a PDF comparison run.
 *
 * <p>Usage in Selenium/JUnit:
 * <pre>
 *   CompareResult result = PDFComparator.compare(config);
 *   Assert.assertTrue("Diffs found — see: " + result.getReportPath(), result.isPassed());
 * </pre>
 *
 * <p>Usage in UFT (via exit code from CLI):
 * <pre>
 *   exitCode = oShell.Run("java -jar doc-compare.jar ...", 0, True)
 *   If exitCode = 0 Then ... ' PASS
 * </pre>
 */
public final class CompareResult {

    public enum Status { PASS, FAIL, ERROR }

    private final Status status;
    private final int    addedLines;
    private final int    removedLines;
    private final int    changedLines;
    private final int    sameLines;
    private final int    totalLinesPdf1;
    private final int    totalLinesPdf2;
    private final String reportPath;
    private final String errorMessage;

    CompareResult(Status status,
                  int addedLines, int removedLines, int changedLines, int sameLines,
                  int totalLinesPdf1, int totalLinesPdf2,
                  String reportPath, String errorMessage) {
        this.status         = status;
        this.addedLines     = addedLines;
        this.removedLines   = removedLines;
        this.changedLines   = changedLines;
        this.sameLines      = sameLines;
        this.totalLinesPdf1 = totalLinesPdf1;
        this.totalLinesPdf2 = totalLinesPdf2;
        this.reportPath     = reportPath;
        this.errorMessage   = errorMessage;
    }

    /** @return true when PDFs are identical after applying all filters. */
    public boolean isPassed()            { return status == Status.PASS; }
    public Status  getStatus()           { return status; }
    public int     getAddedLines()       { return addedLines; }
    public int     getRemovedLines()     { return removedLines; }
    public int     getChangedLines()     { return changedLines; }
    public int     getSameLines()        { return sameLines; }
    public int     getTotalDiffs()       { return addedLines + removedLines + changedLines; }
    public int     getTotalLinesPdf1()   { return totalLinesPdf1; }
    public int     getTotalLinesPdf2()   { return totalLinesPdf2; }
    /** Absolute path to the written HTML report, or null on ERROR. */
    public String  getReportPath()       { return reportPath; }
    public String  getErrorMessage()     { return errorMessage; }

    @Override
    public String toString() {
        return "CompareResult{status=" + status
            + ", added=" + addedLines + ", removed=" + removedLines
            + ", changed=" + changedLines + ", same=" + sameLines
            + ", report='" + reportPath + "'"
            + (errorMessage != null ? ", error='" + errorMessage + "'" : "")
            + "}";
    }
}
