package com.doccompare;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Builds the self-contained HTML comparison report.
 *
 * The report has two views, toggled by buttons at the top:
 *
 * 1. VISUAL VIEW (default) — both PDFs rendered as page images side-by-side,
 *    with coloured highlight boxes drawn on text regions that differ.
 *    Highlights are precise: only differing text is highlighted, same text
 *    and ignored zones are never highlighted.
 *
 * 2. TEXT DIFF VIEW — line-by-line side-by-side text comparison with
 *    word-level inline highlighting for detailed inspection.
 *
 * Security: no external URLs anywhere. All CSS/JS/images are inline.
 * Content Security Policy blocks external resource loads.
 * All PDF-derived content is HTML-escaped.
 */
final class HtmlReportBuilder {

    private HtmlReportBuilder() {}

    // ════════════════════════════════════════════════════════════════════════
    //  BUILD
    // ════════════════════════════════════════════════════════════════════════

    static String build(
            List<PDFComparator.DiffRow> diff,
            File file1, File file2,
            FilterConfig config,
            int linesLeft, int linesRight,
            int added, int removed, int changed,
            boolean passed) throws IOException {

        String ts     = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        int    same   = (int) diff.stream().filter(r -> r.type == PDFComparator.DiffType.SAME).count();
        int    total  = added + removed + changed;
        int    pct    = linesLeft > 0 ? (int) Math.round(total * 100.0 / linesLeft) : 0;

        // Render page images with precise highlights (only differing lines)
        List<PageRenderer.RenderedPage> pages1 = PageRenderer.render(file1, "left",  diff, config);
        List<PageRenderer.RenderedPage> pages2 = PageRenderer.render(file2, "right", diff, config);

        StringBuilder sb = new StringBuilder(1 << 20);

        // ── Head ──────────────────────────────────────────────────────────
        sb.append("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n")
          .append("<meta charset=\"UTF-8\">\n")
          .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n")
          .append("<meta http-equiv=\"Content-Security-Policy\" content=\"")
          .append("default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:;\">\n")
          .append("<title>[").append(passed ? "PASS" : "FAIL").append("] ")
          .append(PDFComparator.escHtml(file1.getName())).append(" vs ")
          .append(PDFComparator.escHtml(file2.getName())).append("</title>\n")
          .append("<style>").append(CSS).append("</style>\n")
          .append("</head>\n<body>\n");

        // ── Sticky header ─────────────────────────────────────────────────
        header(sb, file1.getName(), file2.getName(), ts, passed,
               linesLeft, linesRight, added, removed, changed, same, pct, config);

        // ── View toggle ───────────────────────────────────────────────────
        sb.append("<div class=\"vtbar\">\n")
          .append("<button id=\"btn-vis\" class=\"vtbtn active\" onclick=\"showView('vis')\">")
          .append("&#128444;&#xFE0E; Visual — page structure</button>\n")
          .append("<button id=\"btn-txt\" class=\"vtbtn\" onclick=\"showView('txt')\">")
          .append("&#9776; Text diff — line detail</button>\n")
          .append("<span class=\"vtinfo\">Visual view preserves PDF layout with highlights on changed text only. ")
          .append("Text view shows exact word-level differences.</span>\n")
          .append("</div>\n");

        // ── Visual view ───────────────────────────────────────────────────
        sb.append("<div id=\"v-vis\">\n");
        buildVisual(sb, pages1, pages2, file1.getName(), file2.getName());
        sb.append("</div>\n");

        // ── Text diff view ────────────────────────────────────────────────
        sb.append("<div id=\"v-txt\" style=\"display:none\">\n");
        buildTextDiff(sb, diff, file1.getName(), file2.getName());
        sb.append("</div>\n");

        // ── Footer ────────────────────────────────────────────────────────
        sb.append("<div class=\"footer\">\n")
          .append("<span class=\"footer-lbl\">Command:</span>\n")
          .append("<code>").append(PDFComparator.escHtml(
              buildCmdHint(config, file1.getAbsolutePath(), file2.getAbsolutePath())))
          .append("</code>\n</div>\n");

        sb.append("<script>").append(JS).append("</script>\n");
        sb.append("</body>\n</html>\n");
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STICKY HEADER
    // ════════════════════════════════════════════════════════════════════════

    private static void header(StringBuilder sb, String f1, String f2, String ts,
            boolean passed, int tL, int tR,
            int added, int removed, int changed, int same, int pct, FilterConfig config) {

        sb.append("<div class=\"topbar\">\n")
          .append("<div class=\"tb1\">\n")
          .append("<span class=\"verdict ").append(passed ? "vpass" : "vfail").append("\">")
          .append(passed ? "&#10003; PASS" : "&#10007; FAIL").append("</span>\n")
          .append("<span class=\"tbf tbfl\">").append(PDFComparator.escHtml(f1)).append("</span>\n")
          .append("<span class=\"tbvs\">vs</span>\n")
          .append("<span class=\"tbf tbfr\">").append(PDFComparator.escHtml(f2)).append("</span>\n")
          .append("<span class=\"tbts\">").append(ts).append("</span>\n")
          .append("</div>\n")
          .append("<div class=\"stats\">\n");

        sc(sb, "PDF\u00a01",  String.valueOf(tL), "");
        sc(sb, "PDF\u00a02",  String.valueOf(tR), "");
        sc(sb, "Added",   String.valueOf(added),   added   > 0 ? "sf" : "so");
        sc(sb, "Removed", String.valueOf(removed), removed > 0 ? "sf" : "so");
        sc(sb, "Changed", String.valueOf(changed), changed > 0 ? "sw" : "so");
        sc(sb, "Same",    String.valueOf(same),    "sm");
        sc(sb, "Diff\u00a0%", pct + "%",          (added + removed + changed) > 0 ? "sf" : "so");

        sb.append("</div>\n")
          .append("<div class=\"filters\">\n")
          .append("<span class=\"flbl\">Filters:</span>\n");
        filterChips(sb, config);
        sb.append("</div>\n")
          // Nav row — shown only in text view
          .append("<div class=\"navrow\" id=\"navrow\" style=\"display:none\">\n")
          .append("<button class=\"btn\" onclick=\"navDiff(-1)\">&#9650; Prev</button>\n")
          .append("<span class=\"navpos\" id=\"navpos\"></span>\n")
          .append("<button class=\"btn\" onclick=\"navDiff(1)\">Next &#9660;</button>\n")
          .append("<button class=\"btn\" id=\"btnhide\" onclick=\"toggleSame()\">Hide unchanged</button>\n")
          .append("<span class=\"kbhint\">Alt+&#8593;&#8595; to navigate</span>\n")
          .append("</div>\n")
          .append("</div>\n");
    }

    private static void sc(StringBuilder sb, String label, String val, String cls) {
        sb.append("<div class=\"sc ").append(cls).append("\">")
          .append("<span class=\"scl\">").append(label).append("</span>")
          .append("<span class=\"scv\">").append(val).append("</span>")
          .append("</div>\n");
    }

    private static void filterChips(StringBuilder sb, FilterConfig config) {
        List<String[]> chips = new ArrayList<>();
        if (config.isIgnoreHeader())
            chips.add(new String[]{"&#8679; header " + (int)config.getHeaderPct() + "%", "czn"});
        if (config.isIgnoreFooter())
            chips.add(new String[]{"&#8681; footer " + (int)config.getFooterPct() + "%", "czn"});
        if (config.isIgnoreLeftMargin())
            chips.add(new String[]{"&#8678; left " + (int)config.getMarginPct() + "%", "czn"});
        if (config.isIgnoreRightMargin())
            chips.add(new String[]{"&#8680; right " + (int)config.getMarginPct() + "%", "czn"});
        if (config.isIgnoreTimestamps())
            chips.add(new String[]{"timestamps", "cco"});
        if (config.isIgnorePageNumbers())
            chips.add(new String[]{"page-numbers", "cco"});
        for (java.util.regex.Pattern p : config.getCustomPatterns())
            chips.add(new String[]{"/ " + PDFComparator.escHtml(p.pattern()), "ccu"});
        if (chips.isEmpty()) {
            sb.append("<span class=\"chip cnone\">none</span>\n");
        } else {
            for (String[] c : chips)
                sb.append("<span class=\"chip ").append(c[1]).append("\">").append(c[0]).append("</span>\n");
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  VISUAL VIEW — rendered page images with highlight overlays
    // ════════════════════════════════════════════════════════════════════════

    private static void buildVisual(StringBuilder sb,
            List<PageRenderer.RenderedPage> pages1, List<PageRenderer.RenderedPage> pages2,
            String f1, String f2) {

        // Legend
        sb.append("<div class=\"vis-legend\">\n")
          .append("<span class=\"vleg\">Highlight key:</span>\n")
          .append("<span class=\"vkey vk-rem\">&#9646; Removed (only in PDF\u00a01)</span>\n")
          .append("<span class=\"vkey vk-add\">&#9646; Added (only in PDF\u00a02)</span>\n")
          .append("<span class=\"vkey vk-chg\">&#9646; Changed (differs in both)</span>\n")
          .append("<span class=\"vkey vk-sme\">No highlight = identical text</span>\n")
          .append("</div>\n");

        // Column headers
        sb.append("<div class=\"vcols\">\n")
          .append("<div class=\"vhdr vhdr-l\">&#9664;\u00a0").append(PDFComparator.escHtml(f1)).append("</div>\n")
          .append("<div class=\"vhdr vhdr-r\">&#9654;\u00a0").append(PDFComparator.escHtml(f2)).append("</div>\n")
          .append("</div>\n");

        int numPages = Math.max(pages1.size(), pages2.size());
        for (int p = 0; p < numPages; p++) {
            sb.append("<div class=\"vpage\">\n")
              .append("<div class=\"vpn\">Page ").append(p + 1).append("</div>\n")
              .append("<div class=\"vcols\">\n");

            // Left
            sb.append("<div class=\"vcol\">\n");
            if (p < pages1.size()) {
                PageRenderer.RenderedPage rp = pages1.get(p);
                sb.append("<img class=\"vimg\" src=\"data:image/png;base64,")
                  .append(rp.base64Png).append("\" ")
                  .append("width=\"").append(rp.widthPx).append("\" ")
                  .append("height=\"").append(rp.heightPx).append("\" ")
                  .append("alt=\"PDF 1 page ").append(p + 1).append("\">\n");
            } else {
                sb.append("<div class=\"vempty\">No page ").append(p + 1).append("</div>\n");
            }
            sb.append("</div>\n");

            // Right
            sb.append("<div class=\"vcol\">\n");
            if (p < pages2.size()) {
                PageRenderer.RenderedPage rp = pages2.get(p);
                sb.append("<img class=\"vimg\" src=\"data:image/png;base64,")
                  .append(rp.base64Png).append("\" ")
                  .append("width=\"").append(rp.widthPx).append("\" ")
                  .append("height=\"").append(rp.heightPx).append("\" ")
                  .append("alt=\"PDF 2 page ").append(p + 1).append("\">\n");
            } else {
                sb.append("<div class=\"vempty\">No page ").append(p + 1).append("</div>\n");
            }
            sb.append("</div>\n");

            sb.append("</div>\n</div>\n");
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TEXT DIFF VIEW
    // ════════════════════════════════════════════════════════════════════════

    private static void buildTextDiff(StringBuilder sb,
            List<PDFComparator.DiffRow> diff, String f1, String f2) {

        sb.append("<div class=\"twrap\">\n")
          .append("<table class=\"tbl\">\n")
          .append("<colgroup>")
          .append("<col class=\"clno\"><col class=\"cico\"><col class=\"ctxt\">")
          .append("<col class=\"clno\"><col class=\"cico\"><col class=\"ctxt\">")
          .append("</colgroup>\n")
          .append("<thead><tr>")
          .append("<th colspan=\"3\" class=\"th thl\">&#9664;\u00a0")
          .append(PDFComparator.escHtml(f1)).append("</th>")
          .append("<th colspan=\"3\" class=\"th thr\">&#9654;\u00a0")
          .append(PDFComparator.escHtml(f2)).append("</th>")
          .append("</tr></thead>\n")
          .append("<tbody id=\"tbody\">\n");

        int di = 0;
        for (PDFComparator.DiffRow row : diff) {
            String cls, icon, icls;
            switch (row.type) {
                case ADDED:   cls = "radd"; icon = "+";      icls = "iadd"; break;
                case REMOVED: cls = "rrem"; icon = "\u2212"; icls = "irem"; break;
                case CHANGED: cls = "rchg"; icon = "~";      icls = "ichg"; break;
                default:      cls = "rsme"; icon = "";       icls = "";     break;
            }
            boolean isDiff = row.type != PDFComparator.DiffType.SAME;
            sb.append("<tr class=\"").append(cls).append("\"");
            if (isDiff) sb.append(" id=\"d").append(di++).append("\"");
            sb.append(">");

            String lh, rh;
            if (row.type == PDFComparator.DiffType.CHANGED) {
                String[] wd = PDFComparator.wordDiff(row.left, row.right);
                lh = wd[0]; rh = wd[1];
            } else {
                lh = PDFComparator.escHtml(row.left);
                rh = PDFComparator.escHtml(row.right);
            }

            tdCell(sb, row.leftLineNo,  icon, icls, lh, row.type == PDFComparator.DiffType.ADDED);
            tdCell(sb, row.rightLineNo, icon, icls, rh, row.type == PDFComparator.DiffType.REMOVED);
            sb.append("</tr>\n");
        }
        sb.append("</tbody>\n</table>\n</div>\n");
    }

    private static void tdCell(StringBuilder sb, int no, String icon, String icls,
                                 String html, boolean empty) {
        sb.append("<td class=\"lno\">").append(no > 0 ? no : "").append("</td>")
          .append("<td class=\"ico ").append(icls).append("\">").append(icon).append("</td>")
          .append("<td class=\"code\">")
          .append(empty ? "<span class=\"ec\">(empty)</span>" : html)
          .append("</td>");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  COMMAND HINT
    // ════════════════════════════════════════════════════════════════════════

    private static String buildCmdHint(FilterConfig c, String p1, String p2) {
        StringBuilder sb = new StringBuilder("java -jar doc-compare.jar ")
            .append(p1).append(" ").append(p2).append(" ").append(c.getOutputPath());
        if (c.isIgnoreHeader())       sb.append(" --ignore-header");
        if (c.getHeaderPct() != 10.0) sb.append(" --header-pct=").append((int)c.getHeaderPct());
        if (c.isIgnoreFooter())       sb.append(" --ignore-footer");
        if (c.getFooterPct() != 10.0) sb.append(" --footer-pct=").append((int)c.getFooterPct());
        if (c.isIgnoreLeftMargin() && c.isIgnoreRightMargin()) sb.append(" --ignore-margins");
        else {
            if (c.isIgnoreLeftMargin())  sb.append(" --ignore-left-margin");
            if (c.isIgnoreRightMargin()) sb.append(" --ignore-right-margin");
        }
        if (c.getMarginPct() != 8.0)  sb.append(" --margin-pct=").append((int)c.getMarginPct());
        if (c.isIgnoreTimestamps())   sb.append(" --ignore-timestamps");
        if (c.isIgnorePageNumbers())  sb.append(" --ignore-page-numbers");
        for (java.util.regex.Pattern p : c.getCustomPatterns())
            sb.append(" --ignore-pattern=").append(p.pattern());
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CSS
    // ════════════════════════════════════════════════════════════════════════

    private static final String CSS =
        ":root{--add:#c8e6c9;--rem:#ffcdd2;--chl:#fff3e0;--chr:#f1f8e9;" +
        "--sme:#fafafa;--bdr:#e0e0e0;--ba:#43a047;--br:#e53935;--bc:#fb8c00;--lno:#b0bec5;}\n" +
        "*{box-sizing:border-box;margin:0;padding:0;}\n" +
        "body{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;background:#f4f4f4;color:#212121;}\n" +

        // ── Topbar ──
        ".topbar{position:sticky;top:0;z-index:100;background:#263238;color:#fff;" +
        "padding:8px 16px 5px;box-shadow:0 2px 8px rgba(0,0,0,.45);}\n" +
        ".tb1{display:flex;align-items:center;gap:10px;margin-bottom:5px;flex-wrap:wrap;}\n" +
        ".verdict{font-size:14px;font-weight:700;padding:2px 12px;border-radius:4px;" +
        "flex-shrink:0;white-space:nowrap;}\n" +
        ".vpass{background:#1b5e20;color:#c8e6c9;}\n" +
        ".vfail{background:#b71c1c;color:#ffcdd2;}\n" +
        ".tbf{font-size:12px;font-weight:500;max-width:300px;overflow:hidden;" +
        "text-overflow:ellipsis;white-space:nowrap;}\n" +
        ".tbfl{color:#80cbc4;}.tbfr{color:#a5d6a7;}\n" +
        ".tbvs{font-size:11px;color:#546e7a;}\n" +
        ".tbts{font-size:11px;color:#546e7a;margin-left:auto;white-space:nowrap;}\n" +

        // ── Stats ──
        ".stats{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:5px;}\n" +
        ".sc{background:rgba(255,255,255,.1);border-radius:4px;padding:2px 9px;" +
        "display:flex;flex-direction:column;align-items:center;min-width:54px;}\n" +
        ".scl{font-size:9px;color:#90a4ae;text-transform:uppercase;letter-spacing:.4px;}\n" +
        ".scv{font-size:15px;font-weight:600;color:#fff;line-height:1.2;}\n" +
        ".sf .scv{color:#ef9a9a;}.sw .scv{color:#ffcc80;}.so .scv{color:#a5d6a7;}.sm .scv{color:#78909c;}\n" +

        // ── Filter chips ──
        ".filters{display:flex;align-items:center;gap:4px;flex-wrap:wrap;margin-bottom:5px;}\n" +
        ".flbl{font-size:10px;color:#78909c;}\n" +
        ".chip{display:inline-block;border-radius:9px;padding:1px 8px;font-size:10px;font-weight:500;}\n" +
        ".czn{background:#1a237e;color:#c5cae9;}.cco{background:#e65100;color:#ffe0b2;}\n" +
        ".ccu{background:#4a148c;color:#e1bee7;}.cnone{background:#37474f;color:#90a4ae;}\n" +

        // ── Nav row ──
        ".navrow{display:flex;align-items:center;gap:6px;flex-wrap:wrap;}\n" +
        ".btn{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);" +
        "color:#fff;padding:3px 11px;border-radius:4px;cursor:pointer;font-size:12px;}\n" +
        ".btn:hover{background:rgba(255,255,255,.22);}\n" +
        ".btn.on{background:#e65100;border-color:#bf360c;}\n" +
        ".navpos{font-size:12px;color:#90a4ae;min-width:52px;text-align:center;}\n" +
        ".kbhint{font-size:10px;color:#546e7a;margin-left:4px;}\n" +

        // ── View toggle bar ──
        ".vtbar{background:#fff;border-bottom:1px solid var(--bdr);" +
        "padding:8px 16px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;}\n" +
        ".vtbtn{background:#f5f5f5;border:1px solid #bdbdbd;color:#424242;" +
        "padding:5px 16px;border-radius:4px;cursor:pointer;font-size:12px;font-weight:500;}\n" +
        ".vtbtn:hover{background:#e0e0e0;}\n" +
        ".vtbtn.active{background:#1565c0;color:#fff;border-color:#1565c0;}\n" +
        ".vtbtn.active:hover{background:#0d47a1;}\n" +
        ".vtinfo{font-size:11px;color:#9e9e9e;margin-left:6px;}\n" +

        // ── Visual view ──
        ".vis-legend{padding:8px 16px;background:#fff;border-bottom:1px solid var(--bdr);" +
        "display:flex;align-items:center;gap:12px;flex-wrap:wrap;}\n" +
        ".vleg{font-size:11px;color:#757575;font-weight:500;}\n" +
        ".vkey{font-size:11px;padding:2px 8px;border-radius:3px;font-weight:500;}\n" +
        ".vk-rem{background:#ffcdd2;color:#b71c1c;}\n" +
        ".vk-add{background:#c8e6c9;color:#1b5e20;}\n" +
        ".vk-chg{background:#ffe0b2;color:#e65c00;}\n" +
        ".vk-sme{font-size:11px;color:#9e9e9e;}\n" +
        ".vcols{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:0 16px;}\n" +
        ".vhdr{padding:5px 10px;font-size:12px;font-weight:600;color:#fff;" +
        "overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}\n" +
        ".vhdr-l{background:#37474f;}.vhdr-r{background:#263238;border-left:2px solid #546e7a;}\n" +
        ".vpage{padding:8px 0 0;}\n" +
        ".vpn{font-size:10px;color:#9e9e9e;padding:4px 16px;}\n" +
        ".vcol{background:#fff;border:1px solid var(--bdr);overflow:hidden;}\n" +
        ".vimg{width:100%;height:auto;display:block;}\n" +
        ".vempty{padding:40px;text-align:center;color:#bdbdbd;font-style:italic;font-size:12px;}\n" +

        // ── Text diff ──
        ".twrap{overflow-x:auto;}\n" +
        ".tbl{width:100%;border-collapse:collapse;table-layout:fixed;min-width:700px;}\n" +
        ".clno{width:40px;}.cico{width:18px;}.ctxt{width:calc(50% - 58px - 9px);}\n" +
        ".th{padding:7px 12px;font-size:12px;font-weight:600;color:#fff;" +
        "position:sticky;top:0;z-index:5;border-bottom:2px solid rgba(255,255,255,.15);}\n" +
        ".thl{background:#37474f;}.thr{background:#263238;border-left:3px solid #455a64;}\n" +
        "tbody tr td{border-bottom:1px solid var(--bdr);vertical-align:top;padding:1px 0;}\n" +
        ".lno{font-family:monospace;font-size:10px;color:var(--lno);text-align:right;" +
        "padding:2px 4px 2px 2px;user-select:none;white-space:nowrap;}\n" +
        ".ico{font-family:monospace;font-size:11px;font-weight:700;text-align:center;" +
        "padding:0 1px;user-select:none;width:18px;}\n" +
        ".iadd{color:#2e7d32;}.irem{color:#c62828;}.ichg{color:#e65c00;}\n" +
        ".code{font-family:Consolas,'Courier New',monospace;font-size:11.5px;" +
        "padding:2px 7px;word-break:break-all;white-space:pre-wrap;}\n" +
        ".ec{color:#bdbdbd;font-style:italic;font-size:10px;}\n" +
        ".rsme td{background:var(--sme);}.rsme.hide{display:none;}\n" +
        ".radd td:nth-child(-n+3){background:#fafafa;}\n" +
        ".radd td:nth-child(n+4){background:var(--add);}\n" +
        ".radd td:nth-child(4){border-left:3px solid var(--ba);}\n" +
        ".rrem td:nth-child(-n+3){background:var(--rem);}\n" +
        ".rrem td:nth-child(1){border-left:3px solid var(--br);}\n" +
        ".rrem td:nth-child(n+4){background:#fafafa;}\n" +
        ".rchg td:nth-child(-n+3){background:var(--chl);}\n" +
        ".rchg td:nth-child(1){border-left:3px solid var(--bc);}\n" +
        ".rchg td:nth-child(n+4){background:var(--chr);}\n" +
        ".rchg td:nth-child(4){border-left:3px solid var(--bc);}\n" +
        "mark{background:#ffe082;color:#5d4037;border-radius:2px;padding:0 1px;}\n" +
        ".radd mark{background:#a5d6a7;color:#1b5e20;}\n" +
        ".rrem mark{background:#ef9a9a;color:#7f0000;}\n" +
        ".diffhl{outline:2px solid #ff6f00;outline-offset:-1px;}\n" +

        // ── Footer ──
        ".footer{background:#fff;border-top:1px solid var(--bdr);padding:8px 14px;" +
        "display:flex;align-items:flex-start;gap:8px;font-size:11px;}\n" +
        ".footer-lbl{color:#9e9e9e;white-space:nowrap;padding-top:2px;}\n" +
        ".footer code{font-family:monospace;color:#424242;background:#f5f5f5;" +
        "padding:3px 7px;border-radius:3px;border:1px solid var(--bdr);word-break:break-all;flex:1;}\n";

    // ════════════════════════════════════════════════════════════════════════
    //  JAVASCRIPT — view toggle + text diff navigation; no network calls
    // ════════════════════════════════════════════════════════════════════════

    private static final String JS =
        "(function(){'use strict';\n" +
        "var diffs=[],cur=-1,sameOn=true;\n" +
        "function loadDiffs(){diffs=Array.from(document.querySelectorAll('#tbody tr[id]'));}\n" +
        "function upd(){var el=document.getElementById('navpos');" +
        "if(el)el.textContent=diffs.length===0?'no diffs':(cur+1)+' / '+diffs.length;}\n" +

        // View toggle
        "window.showView=function(v){\n" +
        "  document.getElementById('v-vis').style.display=v==='vis'?'':'none';\n" +
        "  document.getElementById('v-txt').style.display=v==='txt'?'':'none';\n" +
        "  document.getElementById('btn-vis').className='vtbtn'+(v==='vis'?' active':'');\n" +
        "  document.getElementById('btn-txt').className='vtbtn'+(v==='txt'?' active':'');\n" +
        "  var nr=document.getElementById('navrow');\n" +
        "  if(nr)nr.style.display=v==='txt'?'':'none';\n" +
        "  if(v==='txt'&&diffs.length===0){loadDiffs();upd();}\n" +
        "};\n" +

        // Navigation
        "window.navDiff=function(d){\n" +
        "  if(!diffs.length)return;\n" +
        "  if(cur>=0)diffs[cur].classList.remove('diffhl');\n" +
        "  cur=(cur+d+diffs.length)%diffs.length;\n" +
        "  diffs[cur].classList.add('diffhl');\n" +
        "  diffs[cur].scrollIntoView({behavior:'smooth',block:'center'});\n" +
        "  upd();\n" +
        "};\n" +

        // Toggle unchanged lines
        "window.toggleSame=function(){\n" +
        "  sameOn=!sameOn;\n" +
        "  document.querySelectorAll('.rsme').forEach(function(r){r.classList.toggle('hide',!sameOn);});\n" +
        "  var b=document.getElementById('btnhide');\n" +
        "  if(b){b.textContent=sameOn?'Hide unchanged':'Show unchanged';b.classList.toggle('on',!sameOn);}\n" +
        "};\n" +

        // Keyboard shortcuts
        "document.addEventListener('keydown',function(e){\n" +
        "  if(e.altKey&&e.key==='ArrowDown'){e.preventDefault();showView('txt');navDiff(1);}\n" +
        "  if(e.altKey&&e.key==='ArrowUp'){e.preventDefault();showView('txt');navDiff(-1);}\n" +
        "});\n" +
        "}());\n";
}
