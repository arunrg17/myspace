package com.doccompare;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Builds the self-contained HTML comparison report.
 *
 * <h2>Security</h2>
 * <ul>
 *   <li>All PDF-derived content passes through {@link PDFComparator#escHtml} before output.</li>
 *   <li>No external URLs anywhere — all CSS and JS are inline.</li>
 *   <li>Content Security Policy blocks any external resource load.</li>
 *   <li>No {@code eval()}, no {@code innerHTML} on user data.</li>
 * </ul>
 */
final class HtmlReportBuilder {

    private HtmlReportBuilder() {}

    // ════════════════════════════════════════════════════════════════════════
    //  BUILD
    // ════════════════════════════════════════════════════════════════════════

    static String build(
            List<PDFComparator.DiffRow> diff,
            File file1, File file2,
            FilterConfig config,
            int linesLeft, int linesRight,
            int added, int removed, int changed,
            boolean passed) throws IOException {

        String ts    = LocalDateTime.now()
                         .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        int    same  = (int) diff.stream()
                         .filter(r -> r.type == PDFComparator.DiffType.SAME).count();
        int    total = added + removed + changed;
        int    pct   = linesLeft > 0
                         ? (int) Math.round(total * 100.0 / linesLeft) : 0;

        // Render pages with pixel-level diff (like Adobe Compare)
        List<PageRenderer.RenderedPage>[] rendered =
            PageRenderer.renderBoth(file1, file2);
        List<PageRenderer.RenderedPage> pages1 = rendered[0];
        List<PageRenderer.RenderedPage> pages2 = rendered[1];

        StringBuilder sb = new StringBuilder(1 << 20);

        // ── Head ──────────────────────────────────────────────────────────
        sb.append("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n")
          .append("<meta charset=\"UTF-8\">\n")
          .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n")
          .append("<meta http-equiv=\"Content-Security-Policy\" content=\"")
          .append("default-src 'none'; style-src 'unsafe-inline'; ")
          .append("script-src 'unsafe-inline'; img-src data:;\">\n")
          .append("<title>PDF Comparator — [")
          .append(passed ? "PASS" : "FAIL").append("] ")
          .append(PDFComparator.escHtml(file1.getName())).append(" vs ")
          .append(PDFComparator.escHtml(file2.getName())).append("</title>\n")
          .append("<style>\n").append(CSS).append("</style>\n")
          .append("</head>\n<body>\n");

        // ── Sticky toolbar (frozen, does not scroll) ──────────────────────
        sb.append("<div class=\"toolbar\" id=\"toolbar\">\n");
        buildToolbar(sb, file1.getName(), file2.getName(), ts, passed,
            linesLeft, linesRight, added, removed, changed, same, pct, config);
        sb.append("</div>\n");

        // ── View toggle (also sticky, below toolbar) ──────────────────────
        sb.append("<div class=\"vtbar\" id=\"vtbar\">\n")
          .append("  <div class=\"app-name\">&#128196; PDF Comparator</div>\n")
          .append("  <div class=\"view-btns\">\n")
          .append("    <button id=\"btn-vis\" class=\"vtbtn active\" onclick=\"showView('vis')\">")
          .append("&#128444;&#xFE0E; Visual View</button>\n")
          .append("    <button id=\"btn-txt\" class=\"vtbtn\" onclick=\"showView('txt')\">")
          .append("&#9776; Text Diff</button>\n")
          .append("  </div>\n")
          .append("  <div class=\"vtinfo\">")
          .append("Visual: pixel-level comparison highlights only visually different areas")
          .append(" &nbsp;|&nbsp; ")
          .append("Text: word-level line diff with navigation")
          .append("</div>\n")
          .append("</div>\n");

        // ── Highlight legend (also sticky) ────────────────────────────────
        sb.append("<div class=\"legend\" id=\"legend\">\n")
          .append("  <span class=\"legend-lbl\">Highlight key:</span>\n")
          .append("  <span class=\"lk lk-diff\">&#9646; Visual difference detected</span>\n")
          .append("  <span class=\"lk lk-same\">No highlight &mdash; pixel-identical</span>\n")
          .append("  <span class=\"legend-sep\"></span>\n")
          .append("  <span class=\"lk lk-add\">&#9646; Added (text view)</span>\n")
          .append("  <span class=\"lk lk-rem\">&#9646; Removed (text view)</span>\n")
          .append("  <span class=\"lk lk-chg\">&#9646; Changed (text view)</span>\n")
          .append("</div>\n");

        // ── Scrollable content area ────────────────────────────────────────
        sb.append("<div class=\"scroll-body\">\n");

        // Visual view
        sb.append("<div id=\"v-vis\">\n");
        buildVisual(sb, pages1, pages2, file1.getName(), file2.getName());
        sb.append("</div>\n");

        // Text diff view
        sb.append("<div id=\"v-txt\" style=\"display:none\">\n");
        buildTextDiff(sb, diff, file1.getName(), file2.getName());
        sb.append("</div>\n");

        sb.append("</div>\n"); // end scroll-body

        // ── Command footer ─────────────────────────────────────────────────
        sb.append("<div class=\"cmd-footer\">\n")
          .append("  <span class=\"cmd-lbl\">&#9881; Command used:</span>\n")
          .append("  <code>java -jar doc-compare.jar ")
          .append(PDFComparator.escHtml(file1.getAbsolutePath())).append(" ")
          .append(PDFComparator.escHtml(file2.getAbsolutePath())).append(" ")
          .append(PDFComparator.escHtml(config.getOutputPath()))
          .append(buildFlags(config))
          .append("</code>\n</div>\n");

        sb.append("<script>\n").append(JS).append("</script>\n");
        sb.append("</body>\n</html>\n");
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TOOLBAR
    // ════════════════════════════════════════════════════════════════════════

    private static void buildToolbar(StringBuilder sb,
            String f1, String f2, String ts, boolean passed,
            int tL, int tR, int added, int removed, int changed, int same,
            int pct, FilterConfig config) {

        // Row 1: verdict + file names + timestamp
        sb.append("  <div class=\"tb-row1\">\n")
          .append("    <span class=\"verdict ").append(passed ? "v-pass" : "v-fail").append("\">")
          .append(passed ? "&#10003; PASS" : "&#10007; FAIL").append("</span>\n")
          .append("    <span class=\"tb-file tb-f1\">")
          .append(PDFComparator.escHtml(f1)).append("</span>\n")
          .append("    <span class=\"tb-arrow\">&#8644;</span>\n")
          .append("    <span class=\"tb-file tb-f2\">")
          .append(PDFComparator.escHtml(f2)).append("</span>\n")
          .append("    <span class=\"tb-ts\">&#128336; ").append(ts).append("</span>\n")
          .append("  </div>\n");

        // Row 2: stats chips
        sb.append("  <div class=\"stats\">\n");
        stat(sb, "PDF 1",    String.valueOf(tL),      "");
        stat(sb, "PDF 2",    String.valueOf(tR),      "");
        stat(sb, "Added",    String.valueOf(added),   added   > 0 ? "s-bad"  : "s-good");
        stat(sb, "Removed",  String.valueOf(removed), removed > 0 ? "s-bad"  : "s-good");
        stat(sb, "Changed",  String.valueOf(changed), changed > 0 ? "s-warn" : "s-good");
        stat(sb, "Same",     String.valueOf(same),    "s-muted");
        stat(sb, "Diff %",   pct + "%",               pct     > 0 ? "s-bad"  : "s-good");
        sb.append("  </div>\n");

        // Row 3: active filters
        sb.append("  <div class=\"filters\">\n")
          .append("    <span class=\"f-lbl\">&#9881; Active filters:</span>\n");
        buildFilterChips(sb, config);
        sb.append("  </div>\n");

        // Row 4: text-view navigation (hidden in visual view)
        sb.append("  <div class=\"nav\" id=\"nav\" style=\"display:none\">\n")
          .append("    <button class=\"nav-btn\" onclick=\"navDiff(-1)\">&#9650; Prev</button>\n")
          .append("    <span class=\"nav-pos\" id=\"navpos\"></span>\n")
          .append("    <button class=\"nav-btn\" onclick=\"navDiff(1)\">Next &#9660;</button>\n")
          .append("    <button class=\"nav-btn\" id=\"btnhide\" onclick=\"toggleSame()\">")
          .append("Hide unchanged</button>\n")
          .append("    <span class=\"kb-hint\">Alt + &#8593;&#8595; to navigate</span>\n")
          .append("  </div>\n");
    }

    private static void stat(StringBuilder sb, String label, String val, String cls) {
        sb.append("<div class=\"stat ").append(cls).append("\">")
          .append("<span class=\"stat-l\">").append(label).append("</span>")
          .append("<span class=\"stat-v\">").append(val).append("</span>")
          .append("</div>\n");
    }

    private static void buildFilterChips(StringBuilder sb, FilterConfig config) {
        List<String[]> chips = new ArrayList<>();
        if (config.isIgnoreHeader())
            chips.add(new String[]{"&#8679; header " + (int)config.getHeaderPct() + "%", "fz"});
        if (config.isIgnoreFooter())
            chips.add(new String[]{"&#8681; footer " + (int)config.getFooterPct() + "%", "fz"});
        if (config.isIgnoreLeftMargin())
            chips.add(new String[]{"&#8678; left " + (int)config.getMarginPct() + "%", "fz"});
        if (config.isIgnoreRightMargin())
            chips.add(new String[]{"&#8680; right " + (int)config.getMarginPct() + "%", "fz"});
        if (config.isIgnoreTimestamps())
            chips.add(new String[]{"timestamps", "fc"});
        if (config.isIgnorePageNumbers())
            chips.add(new String[]{"page-numbers", "fc"});
        for (java.util.regex.Pattern p : config.getCustomPatterns())
            chips.add(new String[]{"/ " + PDFComparator.escHtml(p.pattern()), "fp"});

        if (chips.isEmpty()) {
            sb.append("<span class=\"chip fn\">none — comparing full content</span>\n");
        } else {
            for (String[] c : chips)
                sb.append("<span class=\"chip ").append(c[1]).append("\">")
                  .append(c[0]).append("</span>\n");
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  VISUAL VIEW
    // ════════════════════════════════════════════════════════════════════════

    private static void buildVisual(StringBuilder sb,
            List<PageRenderer.RenderedPage> pages1,
            List<PageRenderer.RenderedPage> pages2,
            String f1, String f2) {

        sb.append("<div class=\"vis-hdr\">\n")
          .append("  <div class=\"vis-col-hdr\">&#9664;&nbsp;")
          .append(PDFComparator.escHtml(f1)).append("</div>\n")
          .append("  <div class=\"vis-col-hdr vis-col-hdr-r\">&#9654;&nbsp;")
          .append(PDFComparator.escHtml(f2)).append("</div>\n")
          .append("</div>\n");

        int numPages = Math.max(pages1.size(), pages2.size());
        for (int p = 0; p < numPages; p++) {
            sb.append("<div class=\"vis-page\">\n")
              .append("  <div class=\"vis-pn\">Page ").append(p + 1).append("</div>\n")
              .append("  <div class=\"vis-cols\">\n");

            appendPageImg(sb, pages1, p, "PDF 1", p + 1);
            appendPageImg(sb, pages2, p, "PDF 2", p + 1);

            sb.append("  </div>\n</div>\n");
        }
    }

    private static void appendPageImg(StringBuilder sb,
            List<PageRenderer.RenderedPage> pages, int idx,
            String side, int pageNum) {
        sb.append("    <div class=\"vis-col\">\n");
        if (idx < pages.size()) {
            PageRenderer.RenderedPage rp = pages.get(idx);
            sb.append("      <img class=\"vis-img\" ")
              .append("src=\"data:image/png;base64,").append(rp.base64Png).append("\" ")
              .append("width=\"").append(rp.widthPx).append("\" ")
              .append("height=\"").append(rp.heightPx).append("\" ")
              .append("alt=\"").append(side).append(" page ").append(pageNum).append("\">\n");
        } else {
            sb.append("      <div class=\"vis-empty\">Page ").append(pageNum)
              .append(" not present</div>\n");
        }
        sb.append("    </div>\n");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TEXT DIFF VIEW
    // ════════════════════════════════════════════════════════════════════════

    private static void buildTextDiff(StringBuilder sb,
            List<PDFComparator.DiffRow> diff, String f1, String f2) {

        sb.append("<div class=\"tbl-wrap\">\n")
          .append("<table class=\"tbl\">\n")
          .append("<colgroup>")
          .append("<col class=\"c-lno\"><col class=\"c-ico\"><col class=\"c-txt\">")
          .append("<col class=\"c-lno\"><col class=\"c-ico\"><col class=\"c-txt\">")
          .append("</colgroup>\n")
          .append("<thead><tr>")
          .append("<th colspan=\"3\" class=\"th th-l\">&#9664;&nbsp;")
          .append(PDFComparator.escHtml(f1)).append(" (baseline)")
          .append("</th>")
          .append("<th colspan=\"3\" class=\"th th-r\">&#9654;&nbsp;")
          .append(PDFComparator.escHtml(f2)).append(" (actual)")
          .append("</th>")
          .append("</tr></thead>\n")
          .append("<tbody id=\"tbody\">\n");

        int di = 0;
        for (PDFComparator.DiffRow row : diff) {
            String rowCls, icon, iconCls;
            switch (row.type) {
                case ADDED:   rowCls = "r-add"; icon = "+";       iconCls = "i-add"; break;
                case REMOVED: rowCls = "r-rem"; icon = "\u2212";  iconCls = "i-rem"; break;
                case CHANGED: rowCls = "r-chg"; icon = "~";       iconCls = "i-chg"; break;
                default:      rowCls = "r-sme"; icon = "";        iconCls = "";      break;
            }
            boolean isDiff = row.type != PDFComparator.DiffType.SAME;
            sb.append("<tr class=\"").append(rowCls).append("\"");
            if (isDiff) sb.append(" id=\"d").append(di++).append("\"");
            sb.append(">");

            String lHtml, rHtml;
            if (row.type == PDFComparator.DiffType.CHANGED) {
                String[] wd = PDFComparator.wordDiff(row.left, row.right);
                lHtml = wd[0]; rHtml = wd[1];
            } else {
                lHtml = PDFComparator.escHtml(row.left);
                rHtml = PDFComparator.escHtml(row.right);
            }

            appendCell(sb, row.leftLineNo,  icon, iconCls, lHtml,
                row.type == PDFComparator.DiffType.ADDED);
            appendCell(sb, row.rightLineNo, icon, iconCls, rHtml,
                row.type == PDFComparator.DiffType.REMOVED);
            sb.append("</tr>\n");
        }
        sb.append("</tbody>\n</table>\n</div>\n");
    }

    private static void appendCell(StringBuilder sb, int lineNo, String icon,
                                    String iconCls, String html, boolean empty) {
        sb.append("<td class=\"lno\">").append(lineNo > 0 ? lineNo : "").append("</td>")
          .append("<td class=\"ico ").append(iconCls).append("\">").append(icon).append("</td>")
          .append("<td class=\"code\">")
          .append(empty ? "<span class=\"ec\">(empty)</span>" : html)
          .append("</td>");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  FLAG BUILDER
    // ════════════════════════════════════════════════════════════════════════

    private static String buildFlags(FilterConfig c) {
        StringBuilder sb = new StringBuilder();
        if (c.isIgnoreHeader())       sb.append(" --ignore-header");
        if (c.getHeaderPct() != 10.0) sb.append(" --header-pct=").append((int)c.getHeaderPct());
        if (c.isIgnoreFooter())       sb.append(" --ignore-footer");
        if (c.getFooterPct() != 10.0) sb.append(" --footer-pct=").append((int)c.getFooterPct());
        if (c.isIgnoreLeftMargin() && c.isIgnoreRightMargin()) sb.append(" --ignore-margins");
        else {
            if (c.isIgnoreLeftMargin())  sb.append(" --ignore-left-margin");
            if (c.isIgnoreRightMargin()) sb.append(" --ignore-right-margin");
        }
        if (c.getMarginPct() != 8.0)  sb.append(" --margin-pct=").append((int)c.getMarginPct());
        if (c.isIgnoreTimestamps())   sb.append(" --ignore-timestamps");
        if (c.isIgnorePageNumbers())  sb.append(" --ignore-page-numbers");
        for (java.util.regex.Pattern p : c.getCustomPatterns())
            sb.append(" --ignore-pattern=").append(PDFComparator.escHtml(p.pattern()));
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CSS  — professional dark topbar, clean content area, sticky headers
    // ════════════════════════════════════════════════════════════════════════

    private static final String CSS =

        // ── Reset & base ──
        "*{box-sizing:border-box;margin:0;padding:0;}\n" +
        "html,body{height:100%;}\n" +
        "body{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;" +
        "background:#eceff1;color:#212121;display:flex;flex-direction:column;}\n" +

        // ── Sticky wrapper (toolbar + vtbar + legend all freeze together) ──
        ".toolbar,.vtbar,.legend{position:sticky;z-index:100;}\n" +

        // ── Toolbar ──
        ".toolbar{top:0;background:linear-gradient(135deg,#1a237e 0%,#283593 60%,#1565c0 100%);" +
        "color:#fff;padding:10px 20px 7px;box-shadow:0 3px 12px rgba(0,0,0,.5);}\n" +

        ".tb-row1{display:flex;align-items:center;gap:10px;margin-bottom:7px;flex-wrap:wrap;}\n" +

        ".verdict{font-size:15px;font-weight:800;padding:3px 16px;border-radius:5px;" +
        "letter-spacing:.5px;flex-shrink:0;white-space:nowrap;}\n" +
        ".v-pass{background:#1b5e20;color:#a5d6a7;border:1px solid #2e7d32;}\n" +
        ".v-fail{background:#b71c1c;color:#ffcdd2;border:1px solid #c62828;}\n" +

        ".tb-file{font-size:12px;font-weight:600;max-width:300px;" +
        "overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" +
        "background:rgba(255,255,255,.12);padding:2px 10px;border-radius:12px;}\n" +
        ".tb-f1{color:#80deea;}.tb-f2{color:#a5d6a7;}\n" +
        ".tb-arrow{color:#90a4ae;font-size:16px;}\n" +
        ".tb-ts{font-size:11px;color:#90caf9;margin-left:auto;white-space:nowrap;}\n" +

        // ── Stats ──
        ".stats{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:7px;}\n" +
        ".stat{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.15);" +
        "border-radius:6px;padding:3px 12px;display:flex;flex-direction:column;" +
        "align-items:center;min-width:58px;}\n" +
        ".stat-l{font-size:8px;color:#90a4ae;text-transform:uppercase;letter-spacing:.6px;}\n" +
        ".stat-v{font-size:18px;font-weight:700;color:#fff;line-height:1.2;}\n" +
        ".s-bad  .stat-v{color:#ef9a9a;}\n" +
        ".s-warn .stat-v{color:#ffcc80;}\n" +
        ".s-good .stat-v{color:#a5d6a7;}\n" +
        ".s-muted .stat-v{color:#78909c;}\n" +

        // ── Filter chips ──
        ".filters{display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin-bottom:7px;}\n" +
        ".f-lbl{font-size:10px;color:#90a4ae;}\n" +
        ".chip{display:inline-block;border-radius:10px;padding:2px 9px;" +
        "font-size:10px;font-weight:600;}\n" +
        ".fz{background:#311b92;color:#ce93d8;border:1px solid #4a148c;}\n" +
        ".fc{background:#bf360c;color:#ffccbc;border:1px solid #d84315;}\n" +
        ".fp{background:#1a237e;color:#90caf9;border:1px solid #283593;}\n" +
        ".fn{background:rgba(255,255,255,.08);color:#78909c;}\n" +

        // ── Navigation row ──
        ".nav{display:flex;align-items:center;gap:7px;flex-wrap:wrap;}\n" +
        ".nav-btn{background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.25);" +
        "color:#fff;padding:3px 13px;border-radius:5px;cursor:pointer;font-size:12px;" +
        "font-weight:500;transition:background .15s;}\n" +
        ".nav-btn:hover{background:rgba(255,255,255,.28);}\n" +
        ".nav-btn.on{background:#e65100;border-color:#bf360c;}\n" +
        ".nav-pos{font-size:12px;color:#90caf9;min-width:60px;text-align:center;}\n" +
        ".kb-hint{font-size:10px;color:#546e7a;margin-left:4px;}\n" +

        // ── View toggle bar ──
        ".vtbar{top:0;background:#fff;border-bottom:2px solid #e3e8f0;" +
        "padding:9px 20px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;" +
        "box-shadow:0 2px 6px rgba(0,0,0,.08);}\n" +

        ".app-name{font-size:14px;font-weight:700;color:#1565c0;letter-spacing:.3px;" +
        "white-space:nowrap;}\n" +

        ".view-btns{display:flex;gap:6px;}\n" +
        ".vtbtn{background:#f5f7fa;border:1px solid #d0d7e2;color:#37474f;" +
        "padding:6px 18px;border-radius:6px;cursor:pointer;font-size:12px;" +
        "font-weight:600;transition:all .15s;}\n" +
        ".vtbtn:hover{background:#e8edf5;border-color:#b0bec5;}\n" +
        ".vtbtn.active{background:#1565c0;color:#fff;border-color:#1565c0;" +
        "box-shadow:0 2px 6px rgba(21,101,192,.4);}\n" +
        ".vtinfo{font-size:11px;color:#78909c;margin-left:6px;flex:1;}\n" +

        // ── Highlight legend (sticky below vtbar) ──
        ".legend{top:0;background:#fffde7;border-bottom:2px solid #fff176;" +
        "padding:6px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;}\n" +
        ".legend-lbl{font-size:11px;font-weight:700;color:#f57f17;}\n" +
        ".lk{font-size:11px;padding:2px 10px;border-radius:4px;font-weight:600;}\n" +
        ".lk-diff{background:#ffe0b2;color:#e65c00;border:1px solid #ffcc80;}\n" +
        ".lk-same{font-size:11px;color:#9e9e9e;padding:2px 6px;}\n" +
        ".lk-add{background:#c8e6c9;color:#1b5e20;border:1px solid #a5d6a7;}\n" +
        ".lk-rem{background:#ffcdd2;color:#b71c1c;border:1px solid #ef9a9a;}\n" +
        ".lk-chg{background:#fff3e0;color:#e65c00;border:1px solid #ffe0b2;}\n" +
        ".legend-sep{flex:1;}\n" +

        // ── Scrollable body ──
        ".scroll-body{flex:1;overflow-y:auto;}\n" +

        // ── Visual view ──
        ".vis-hdr{display:grid;grid-template-columns:1fr 1fr;gap:8px;" +
        "padding:8px 16px;background:#37474f;position:sticky;top:0;z-index:5;}\n" +
        ".vis-col-hdr{font-size:12px;font-weight:700;color:#fff;" +
        "padding:4px 8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}\n" +
        ".vis-col-hdr-r{border-left:2px solid #546e7a;}\n" +
        ".vis-page{padding:10px 16px 0;}\n" +
        ".vis-pn{font-size:10px;color:#9e9e9e;padding:2px 4px 4px;" +
        "font-weight:500;letter-spacing:.3px;}\n" +
        ".vis-cols{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;}\n" +
        ".vis-col{background:#fff;border:1px solid #e0e0e0;border-radius:4px;" +
        "overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.08);}\n" +
        ".vis-img{width:100%;height:auto;display:block;}\n" +
        ".vis-empty{padding:40px;text-align:center;color:#bdbdbd;" +
        "font-style:italic;font-size:12px;}\n" +

        // ── Text diff table ──
        ".tbl-wrap{overflow-x:auto;}\n" +
        ".tbl{width:100%;border-collapse:collapse;table-layout:fixed;min-width:720px;}\n" +
        ".c-lno{width:42px;}.c-ico{width:20px;}.c-txt{width:calc(50% - 62px - 10px);}\n" +
        ".th{padding:8px 14px;font-size:12px;font-weight:700;color:#fff;" +
        "position:sticky;top:0;z-index:4;border-bottom:3px solid rgba(255,255,255,.2);}\n" +
        ".th-l{background:#37474f;}.th-r{background:#263238;border-left:3px solid #455a64;}\n" +
        "tbody tr td{border-bottom:1px solid #e8ecf0;vertical-align:top;padding:1px 0;}\n" +
        ".lno{font-family:'Consolas','Courier New',monospace;font-size:10px;" +
        "color:#b0bec5;text-align:right;padding:3px 5px;user-select:none;white-space:nowrap;}\n" +
        ".ico{font-family:monospace;font-size:12px;font-weight:800;" +
        "text-align:center;padding:0 2px;user-select:none;width:20px;}\n" +
        ".i-add{color:#2e7d32;}.i-rem{color:#c62828;}.i-chg{color:#e65c00;}\n" +
        ".code{font-family:'Consolas','Courier New',monospace;font-size:11.5px;" +
        "padding:3px 8px;word-break:break-all;white-space:pre-wrap;line-height:1.5;}\n" +
        ".ec{color:#bdbdbd;font-style:italic;font-size:10px;}\n" +

        // ── Row colours ──
        ".r-sme td{background:#fafbfc;}\n" +
        ".r-sme.hide{display:none;}\n" +
        ".r-add td:nth-child(-n+3){background:#f8fafb;}\n" +
        ".r-add td:nth-child(n+4){background:#e8f5e9;}\n" +
        ".r-add td:nth-child(4){border-left:4px solid #43a047;}\n" +
        ".r-rem td:nth-child(-n+3){background:#ffebee;}\n" +
        ".r-rem td:nth-child(1){border-left:4px solid #e53935;}\n" +
        ".r-rem td:nth-child(n+4){background:#f8fafb;}\n" +
        ".r-chg td:nth-child(-n+3){background:#fff8e1;}\n" +
        ".r-chg td:nth-child(1){border-left:4px solid #fb8c00;}\n" +
        ".r-chg td:nth-child(n+4){background:#f1f8e9;}\n" +
        ".r-chg td:nth-child(4){border-left:4px solid #fb8c00;}\n" +
        "mark{background:#ffe082;color:#5d4037;border-radius:3px;padding:0 2px;}\n" +
        ".r-add mark{background:#a5d6a7;color:#1b5e20;}\n" +
        ".r-rem mark{background:#ef9a9a;color:#7f0000;}\n" +
        ".diffhl{outline:2px solid #ff6f00;outline-offset:-1px;}\n" +

        // ── Command footer ──
        ".cmd-footer{background:#263238;color:#90a4ae;padding:8px 20px;" +
        "display:flex;align-items:flex-start;gap:10px;font-size:11px;flex-shrink:0;}\n" +
        ".cmd-lbl{color:#546e7a;white-space:nowrap;padding-top:2px;}\n" +
        ".cmd-footer code{font-family:'Consolas','Courier New',monospace;" +
        "color:#80cbc4;background:rgba(255,255,255,.05);padding:3px 8px;" +
        "border-radius:4px;border:1px solid rgba(255,255,255,.1);" +
        "word-break:break-all;flex:1;}\n";

    // ════════════════════════════════════════════════════════════════════════
    //  JAVASCRIPT — view toggle + text diff navigation; no network calls
    // ════════════════════════════════════════════════════════════════════════

    private static final String JS =
        "(function(){'use strict';\n" +
        "var diffs=[],cur=-1,sameOn=true;\n" +

        "function loadDiffs(){\n" +
        "  diffs=Array.from(document.querySelectorAll('#tbody tr[id]'));\n" +
        "}\n" +
        "function updateNav(){\n" +
        "  var el=document.getElementById('navpos');\n" +
        "  if(el) el.textContent=diffs.length===0\n" +
        "    ?'no diffs':(cur+1)+' / '+diffs.length;\n" +
        "}\n" +

        // Sticky offset calculation — accounts for stacked sticky elements
        "function getStickyOffset(){\n" +
        "  var h=0;\n" +
        "  ['toolbar','vtbar','legend'].forEach(function(id){\n" +
        "    var el=document.getElementById(id);\n" +
        "    if(el) h+=el.offsetHeight;\n" +
        "  });\n" +
        "  return h;\n" +
        "}\n" +

        "window.showView=function(v){\n" +
        "  document.getElementById('v-vis').style.display=v==='vis'?'':'none';\n" +
        "  document.getElementById('v-txt').style.display=v==='txt'?'':'none';\n" +
        "  document.getElementById('btn-vis').className='vtbtn'+(v==='vis'?' active':'');\n" +
        "  document.getElementById('btn-txt').className='vtbtn'+(v==='txt'?' active':'');\n" +
        "  var nav=document.getElementById('nav');\n" +
        "  if(nav) nav.style.display=v==='txt'?'':'none';\n" +
        "  if(v==='txt' && diffs.length===0){loadDiffs();updateNav();}\n" +
        "};\n" +

        "window.navDiff=function(d){\n" +
        "  if(!diffs.length) return;\n" +
        "  if(cur>=0) diffs[cur].classList.remove('diffhl');\n" +
        "  cur=(cur+d+diffs.length)%diffs.length;\n" +
        "  diffs[cur].classList.add('diffhl');\n" +
        "  var offset=getStickyOffset()+10;\n" +
        "  var rect=diffs[cur].getBoundingClientRect();\n" +
        "  var scrollBody=document.querySelector('.scroll-body');\n" +
        "  if(scrollBody){\n" +
        "    scrollBody.scrollBy({top:rect.top-offset,behavior:'smooth'});\n" +
        "  }\n" +
        "  updateNav();\n" +
        "};\n" +

        "window.toggleSame=function(){\n" +
        "  sameOn=!sameOn;\n" +
        "  document.querySelectorAll('.r-sme').forEach(function(r){\n" +
        "    r.classList.toggle('hide',!sameOn);\n" +
        "  });\n" +
        "  var btn=document.getElementById('btnhide');\n" +
        "  if(btn){\n" +
        "    btn.textContent=sameOn?'Hide unchanged':'Show unchanged';\n" +
        "    btn.classList.toggle('on',!sameOn);\n" +
        "  }\n" +
        "};\n" +

        "document.addEventListener('keydown',function(e){\n" +
        "  if(e.altKey && e.key==='ArrowDown'){\n" +
        "    e.preventDefault(); showView('txt'); navDiff(1);\n" +
        "  }\n" +
        "  if(e.altKey && e.key==='ArrowUp'){\n" +
        "    e.preventDefault(); showView('txt'); navDiff(-1);\n" +
        "  }\n" +
        "});\n" +

        // Set sticky top dynamically so elements stack correctly
        "(function stickyStack(){\n" +
        "  var ids=['toolbar','vtbar','legend'];\n" +
        "  var offset=0;\n" +
        "  ids.forEach(function(id){\n" +
        "    var el=document.getElementById(id);\n" +
        "    if(!el) return;\n" +
        "    el.style.top=offset+'px';\n" +
        "    offset+=el.offsetHeight;\n" +
        "  });\n" +
        "  var vis=document.querySelector('.vis-hdr');\n" +
        "  if(vis) vis.style.top=offset+'px';\n" +
        "}());\n" +

        "}());\n";
}
