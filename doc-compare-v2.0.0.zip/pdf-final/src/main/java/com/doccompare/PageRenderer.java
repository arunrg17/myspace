package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Renders PDF pages as images with precise highlight boxes on differing lines only.
 *
 * <h2>Design — single-pass, line-number exact</h2>
 *
 * <p>All previous versions tried to locate lines by text matching or by a
 * separate position-collection pass. Both fail because:
 * <ul>
 *   <li>Token matching gives false positives when German legal text repeats the
 *       same phrases across many lines (e.g. "Der Produzent hat für den
 *       Schlusstag mindestens eine Transaktion im Berichtszeitraum").</li>
 *   <li>A separate RunCollector pass cannot guarantee its line counter matches
 *       the one in {@code PDFComparator.extractLines()}, because PDFBox fires
 *       {@code writeLineSeparator()} for more events than just visual line breaks
 *       (columns, text-run boundaries, etc.).</li>
 * </ul>
 *
 * <p>This version uses a <b>single subclass of PDFTextStripper</b> that mirrors
 * {@link PDFComparator.ZoneAwareStripper} <em>exactly</em> — same zone filters,
 * same {@link FilterConfig#processLine} call, same line counter — but also records
 * the Y-coordinate of each accepted line. Because the counter increments under
 * identical conditions to {@code extractLines()}, the line numbers here are
 * guaranteed to match the diff result.
 *
 * <p>Highlights are drawn as full-width bars at the recorded Y position of each
 * differing line. No text matching. No token overlap. No ghost highlights.
 */
final class PageRenderer {

    private static final float DPI = 150f;

    private static final Color FILL_REM   = new Color(220,  50,  50,  55);
    private static final Color FILL_ADD   = new Color( 40, 160,  40,  55);
    private static final Color FILL_CHG   = new Color(240, 130,   0,  55);
    private static final Color BORDER_REM = new Color(180,  20,  20, 210);
    private static final Color BORDER_ADD = new Color( 20, 130,  20, 210);
    private static final Color BORDER_CHG = new Color(200,  90,   0, 210);

    private PageRenderer() {}

    // ── Public output type ───────────────────────────────────────────────────

    static final class RenderedPage {
        final int    pageIndex;
        final String base64Png;
        final int    widthPx;
        final int    heightPx;

        RenderedPage(int i, String b64, int w, int h) {
            pageIndex = i; base64Png = b64; widthPx = w; heightPx = h;
        }
    }

    // ── Line position record ─────────────────────────────────────────────────

    /** The Y-extent and X-extent of one accepted line, in PDF points (top-origin). */
    private static final class LinePos {
        final int   page;
        final float yTop;
        final float yBottom;
        final float xLeft;
        final float xRight;

        LinePos(int pg, float yt, float yb, float xl, float xr) {
            page = pg; yTop = yt; yBottom = yb; xLeft = xl; xRight = xr;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    static List<RenderedPage> render(File pdfFile,
                                      String side,
                                      List<PDFComparator.DiffRow> diff,
                                      FilterConfig config) throws IOException {
        // Step 1: build highlight set — which line numbers need a highlight?
        Map<Integer, PDFComparator.DiffType> hlMap = buildHighlightMap(diff, side);
        if (hlMap.isEmpty()) {
            return renderPlain(pdfFile);
        }

        // Step 2: single-pass extraction — record Y position of every accepted line
        // using IDENTICAL logic to PDFComparator.extractLines()
        Map<Integer, LinePos> linePositions = recordLinePositions(pdfFile, config);

        // Step 3: render pages with highlight bars
        return renderWithHighlights(pdfFile, hlMap, linePositions);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HIGHLIGHT MAP  — only ADDED / REMOVED / CHANGED line numbers
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, PDFComparator.DiffType> buildHighlightMap(
            List<PDFComparator.DiffRow> diff, String side) {

        Map<Integer, PDFComparator.DiffType> map = new LinkedHashMap<>();
        boolean isLeft = "left".equals(side);

        for (PDFComparator.DiffRow row : diff) {
            if (row.type == PDFComparator.DiffType.SAME) continue;

            boolean relevant = isLeft
                ? (row.type == PDFComparator.DiffType.REMOVED
                   || row.type == PDFComparator.DiffType.CHANGED)
                : (row.type == PDFComparator.DiffType.ADDED
                   || row.type == PDFComparator.DiffType.CHANGED);
            if (!relevant) continue;

            int lineNo = isLeft ? row.leftLineNo : row.rightLineNo;
            if (lineNo > 0) map.put(lineNo, row.type);
        }
        return map;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  SINGLE-PASS LINE POSITION RECORDER
    //
    //  This is a subclass of PDFTextStripper that runs EXACTLY the same logic
    //  as PDFComparator.ZoneAwareStripper + extractLines(), but also records
    //  the bounding box of each line that passes all filters.
    //
    //  Because it uses the same callbacks in the same order, the line counter
    //  here ALWAYS matches the one in extractLines(). No token matching needed.
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, LinePos> recordLinePositions(File pdfFile,
                                                              FilterConfig config)
            throws IOException {
        LineRecorder recorder = new LineRecorder(config);
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            recorder.getText(doc);
        }
        return recorder.linePositions;
    }

    private static final class LineRecorder extends PDFTextStripper {

        private final FilterConfig config;

        /** Map from 1-based line number to its page position. */
        final Map<Integer, LinePos> linePositions = new HashMap<>();

        // Per-line state (reset on each writeLineSeparator / endPage)
        private final StringBuilder lineText  = new StringBuilder();
        private final List<float[]>  lineCoords = new ArrayList<>(); // [yTop, yBottom, xLeft, xRight] per run

        // Page state
        private int   lineCounter  = 1;   // 1-based, matches extractLines()
        private int   currentPage  = 0;   // 0-based
        private float pageH        = 842f;
        private float pageW        = 595f;

        LineRecorder(FilterConfig config) throws IOException {
            super();
            this.config = config;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle box = page.getMediaBox();
            pageH = box.getHeight();
            pageW = box.getWidth();
            currentPage = getCurrentPageNo() - 1;
            flushLine();   // flush any leftover from previous page
            super.startPage(page);
        }

        @Override
        protected void writeString(String text,
                                    List<TextPosition> positions) throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }

            // ── Zone filters (identical to ZoneAwareStripper) ──
            float sumX = 0f, sumY = 0f;
            for (TextPosition tp : positions) {
                sumX += tp.getX();
                sumY += tp.getY();
            }
            float avgX    = sumX / positions.size();
            float avgY    = sumY / positions.size();
            float yFromTop = pageH - avgY;  // convert PDF Y-up to Y-from-top

            if (config.isIgnoreHeader()
                    && yFromTop < pageH * (config.getHeaderPct() / 100.0)) {
                // Zone-excluded: do NOT call super, do NOT accumulate
                return;
            }
            if (config.isIgnoreFooter()
                    && yFromTop > pageH * ((100.0 - config.getFooterPct()) / 100.0)) {
                return;
            }
            if (config.isIgnoreLeftMargin()
                    && avgX < pageW * (config.getMarginPct() / 100.0)) {
                return;
            }
            if (config.isIgnoreRightMargin()
                    && avgX > pageW * ((100.0 - config.getMarginPct()) / 100.0)) {
                return;
            }

            // Accumulate text and bounding box for this run
            lineText.append(text);

            // Compute glyph bounding box in top-origin coordinates
            float minX    = Float.MAX_VALUE;
            float maxX    = -Float.MAX_VALUE;
            float minYbase = Float.MAX_VALUE;   // lowest baseline in this run
            float maxYtop  = -Float.MAX_VALUE;  // highest top in this run

            for (TextPosition tp : positions) {
                float x  = tp.getX();
                float xr = x + tp.getWidth();
                float yb = tp.getY();             // PDF Y-up baseline
                float yt = yb + tp.getHeight();   // PDF Y-up top of glyph

                if (x  < minX)    minX    = x;
                if (xr > maxX)    maxX    = xr;
                if (yb < minYbase) minYbase = yb;
                if (yt > maxYtop)  maxYtop  = yt;
            }

            // Convert to top-origin (Y-down from top of page)
            float topOriginTop    = pageH - maxYtop;   // top of glyph from page top
            float topOriginBottom = pageH - minYbase;  // bottom of glyph from page top

            lineCoords.add(new float[]{topOriginTop, topOriginBottom, minX, maxX});
            super.writeString(text, positions);
        }

        @Override
        protected void writeLineSeparator() throws IOException {
            flushLine();
            super.writeLineSeparator();
        }

        @Override
        protected void endPage(PDPage page) throws IOException {
            flushLine();
            super.endPage(page);
        }

        /**
         * Process the accumulated line buffer — same logic as
         * {@code PDFComparator.extractLines()}.
         */
        private void flushLine() {
            String raw = lineText.toString();
            lineText.setLength(0);

            if (raw.trim().isEmpty() || lineCoords.isEmpty()) {
                lineCoords.clear();
                return;
            }

            // Apply the SAME content filter as extractLines()
            String processed = config.processLine(raw);
            if (processed == null || processed.trim().isEmpty()) {
                lineCoords.clear();
                return;
            }

            // Compute bounding box over all runs in this line
            float yTop    = lineCoords.get(0)[0];
            float yBottom = lineCoords.get(0)[1];
            float xLeft   = lineCoords.get(0)[2];
            float xRight  = lineCoords.get(0)[3];

            for (float[] c : lineCoords) {
                if (c[0] < yTop)    yTop    = c[0];
                if (c[1] > yBottom) yBottom = c[1];
                if (c[2] < xLeft)   xLeft   = c[2];
                if (c[3] > xRight)  xRight  = c[3];
            }

            linePositions.put(lineCounter, new LinePos(currentPage,
                yTop, yBottom, xLeft, xRight));
            lineCounter++;
            lineCoords.clear();
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  RENDER WITH HIGHLIGHTS
    // ════════════════════════════════════════════════════════════════════════

    private static List<RenderedPage> renderWithHighlights(
            File pdfFile,
            Map<Integer, PDFComparator.DiffType> hlMap,
            Map<Integer, LinePos> linePositions) throws IOException {

        // Group highlights by page
        Map<Integer, List<int[]>> highlightsByPage = new HashMap<>();
        // int[] = {yTopPx, yBottomPx, xLeftPx, xRightPx, diffTypeOrdinal}

        for (Map.Entry<Integer, PDFComparator.DiffType> entry : hlMap.entrySet()) {
            int lineNo = entry.getKey();
            LinePos pos = linePositions.get(lineNo);
            if (pos == null) continue;  // line not found on any page

            // We store PDF-point coords here; convert to pixels during rendering
            int typeOrd = entry.getValue().ordinal();
            List<int[]> list = highlightsByPage.computeIfAbsent(
                pos.page, k -> new ArrayList<>());
            // Store as float bits packed in int for simplicity; use a small holder
            list.add(new int[]{
                Float.floatToIntBits(pos.yTop),
                Float.floatToIntBits(pos.yBottom),
                Float.floatToIntBits(pos.xLeft),
                Float.floatToIntBits(pos.xRight),
                typeOrd
            });
        }

        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                List<int[]> pageHL = highlightsByPage.getOrDefault(
                    p, Collections.<int[]>emptyList());
                if (!pageHL.isEmpty()) {
                    PDPage page = doc.getPage(p);
                    drawHighlights(img, page, pageHL);
                }
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    private static void drawHighlights(BufferedImage img, PDPage page,
                                        List<int[]> highlights) {
        PDRectangle media = page.getMediaBox();
        float pdfW  = media.getWidth();
        float pdfH  = media.getHeight();
        float scaleX = (float) img.getWidth()  / pdfW;
        float scaleY = (float) img.getHeight() / pdfH;

        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                           RenderingHints.VALUE_ANTIALIAS_ON);

        for (int[] h : highlights) {
            float yTop    = Float.intBitsToFloat(h[0]);
            float yBottom = Float.intBitsToFloat(h[1]);
            float xLeft   = Float.intBitsToFloat(h[2]);
            float xRight  = Float.intBitsToFloat(h[3]);
            int   typeOrd = h[4];

            // yTop / yBottom are already top-origin (from LineRecorder)
            int px = Math.max(0,               (int)(xLeft  * scaleX) - 2);
            int py = Math.max(0,               (int)(yTop   * scaleY) - 1);
            int pr = Math.min(img.getWidth(),  (int)(xRight * scaleX) + 2);
            int pb = Math.min(img.getHeight(), (int)(yBottom * scaleY) + 2);
            int pw = Math.max(4, pr - px);
            int ph = Math.max(3, pb - py);

            Color fill, border;
            PDFComparator.DiffType type = PDFComparator.DiffType.values()[typeOrd];
            switch (type) {
                case REMOVED: fill = FILL_REM; border = BORDER_REM; break;
                case ADDED:   fill = FILL_ADD; border = BORDER_ADD; break;
                case CHANGED: fill = FILL_CHG; border = BORDER_CHG; break;
                default: continue;
            }

            g.setColor(fill);
            g.fillRect(px, py, pw, ph);
            g.setColor(border);
            g.setStroke(new BasicStroke(1.0f));
            g.drawRect(px, py, pw, ph);
        }
        g.dispose();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PLAIN RENDER (no diffs on this side)
    // ════════════════════════════════════════════════════════════════════════

    private static List<RenderedPage> renderPlain(File pdfFile) throws IOException {
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PNG ENCODER
    // ════════════════════════════════════════════════════════════════════════

    private static String toPng(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }
}
