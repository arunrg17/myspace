package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Renders PDF pages as images with highlight boxes on differing lines.
 *
 * <h2>How highlighting works — definitive approach</h2>
 *
 * <p>Previous versions failed because they tried to track a line counter
 * across the entire document using {@code writeLineSeparator()} callbacks.
 * This breaks on multi-column PDFs because {@code writeParagraphSeparator()}
 * fires at column boundaries and caused phantom counter increments.
 *
 * <p>This version processes <b>one page at a time</b>:
 * <ol>
 *   <li>For each page, call {@code getText()} with {@code setStartPage/setEndPage}
 *       restricted to that single page.</li>
 *   <li>Within that single-page call, {@code writeString()} and
 *       {@code writeLineSeparator()} fire only for text on that page.
 *       {@code writeParagraphSeparator()} is overridden to do nothing —
 *       paragraph breaks within a page do not represent new output lines.</li>
 *   <li>A local line counter increments only when {@code processLine()} accepts
 *       a line — identical to how {@code extractLines()} counts lines.</li>
 *   <li>The global line number = page_start_offset + local_line_number.</li>
 * </ol>
 *
 * <p>Since both {@code extractLines()} and this class process pages in order
 * and apply identical filters, global line numbers are guaranteed to match.
 */
final class PageRenderer {

    private static final float DPI = 150f;

    private static final Color FILL_REM   = new Color(220,  50,  50,  60);
    private static final Color FILL_ADD   = new Color( 40, 160,  40,  60);
    private static final Color FILL_CHG   = new Color(240, 130,   0,  60);
    private static final Color BORDER_REM = new Color(180,  20,  20, 220);
    private static final Color BORDER_ADD = new Color( 20, 130,  20, 220);
    private static final Color BORDER_CHG = new Color(200,  90,   0, 220);

    private PageRenderer() {}

    // ── Public output ─────────────────────────────────────────────────────────

    static final class RenderedPage {
        final int    pageIndex;
        final String base64Png;
        final int    widthPx;
        final int    heightPx;

        RenderedPage(int i, String b64, int w, int h) {
            pageIndex = i; base64Png = b64; widthPx = w; heightPx = h;
        }
    }

    // ── Line bounding box ─────────────────────────────────────────────────────

    private static final class LineBox {
        final float yTop;
        final float yBottom;
        final float xLeft;
        final float xRight;

        LineBox(float yt, float yb, float xl, float xr) {
            yTop = yt; yBottom = yb; xLeft = xl; xRight = xr;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    static List<RenderedPage> render(File pdfFile,
                                      String side,
                                      List<PDFComparator.DiffRow> diff,
                                      FilterConfig config) throws IOException {

        // Build set of global line numbers that need highlighting
        Map<Integer, PDFComparator.DiffType> hlMap = buildHighlightMap(diff, side);
        if (hlMap.isEmpty()) {
            return renderPlain(pdfFile);
        }

        // Process each page independently to get line positions
        // Key: global line number → LineBox on that page
        Map<Integer, LineBox>  lineBoxes   = new LinkedHashMap<>();
        Map<Integer, Integer>  lineToPage  = new HashMap<>();

        try (PDDocument doc = PDDocument.load(pdfFile)) {
            int globalOffset = 0; // lines accepted on pages 0..p-1

            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                SinglePageRecorder rec = new SinglePageRecorder(config, p + 1);
                rec.setStartPage(p + 1);
                rec.setEndPage(p + 1);
                rec.getText(doc);

                // rec.lineBoxes has local line numbers 1..N for this page
                for (Map.Entry<Integer, LineBox> e : rec.lineBoxes.entrySet()) {
                    int globalLineNo = globalOffset + e.getKey();
                    lineBoxes.put(globalLineNo, e.getValue());
                    lineToPage.put(globalLineNo, p);
                }
                globalOffset += rec.acceptedLineCount;
            }
        }

        // Group highlights by page
        Map<Integer, List<int[]>> byPage = new HashMap<>();
        for (Map.Entry<Integer, PDFComparator.DiffType> e : hlMap.entrySet()) {
            int lineNo = e.getKey();
            LineBox box = lineBoxes.get(lineNo);
            Integer page = lineToPage.get(lineNo);
            if (box == null || page == null) continue;

            byPage.computeIfAbsent(page, k -> new ArrayList<>())
                .add(pack(box, e.getValue()));
        }

        // Render pages
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                List<int[]> hl = byPage.getOrDefault(p, Collections.<int[]>emptyList());
                if (!hl.isEmpty()) {
                    drawHighlights(img, doc.getPage(p), hl);
                }
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  SINGLE PAGE RECORDER
    //
    //  Processes exactly one page. writeParagraphSeparator() is a no-op so
    //  column boundaries within the page do not affect the line counter.
    //  Only writeLineSeparator() advances the line — same as getText() output.
    // ════════════════════════════════════════════════════════════════════════

    private static final class SinglePageRecorder extends PDFTextStripper {

        private final FilterConfig config;
        final Map<Integer, LineBox> lineBoxes = new LinkedHashMap<>();

        // Local state (resets per page — this is the key advantage)
        private final StringBuilder  lineBuf    = new StringBuilder();
        private final List<float[]>  lineCoords = new ArrayList<>(); // [yTop,yBottom,xLeft,xRight]
        private int   localLineNo       = 0; // counts accepted lines on this page (1-based after flush)
        int           acceptedLineCount = 0; // total accepted lines on this page

        private float pageH = 842f;
        private float pageW = 595f;

        SinglePageRecorder(FilterConfig config, int pageNum) throws IOException {
            super();
            this.config = config;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle box = page.getMediaBox();
            pageH = box.getHeight();
            pageW = box.getWidth();
            // Reset all per-page state
            lineBuf.setLength(0);
            lineCoords.clear();
            localLineNo = 0;
            acceptedLineCount = 0;
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions)
                throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }

            // Zone filters — identical to ZoneAwareStripper
            float sumX = 0f, sumY = 0f;
            for (TextPosition tp : positions) { sumX += tp.getX(); sumY += tp.getY(); }
            float avgX    = sumX / positions.size();
            float avgY    = sumY / positions.size();
            float yFromTop = pageH - avgY;

            if (config.isIgnoreHeader()
                    && yFromTop < pageH * (config.getHeaderPct() / 100.0)) return;
            if (config.isIgnoreFooter()
                    && yFromTop > pageH * ((100.0 - config.getFooterPct()) / 100.0)) return;
            if (config.isIgnoreLeftMargin()
                    && avgX < pageW * (config.getMarginPct() / 100.0)) return;
            if (config.isIgnoreRightMargin()
                    && avgX > pageW * ((100.0 - config.getMarginPct()) / 100.0)) return;

            // Accumulate text
            lineBuf.append(text);

            // Accumulate bounding box (top-origin coords)
            float minX = Float.MAX_VALUE, maxX = -Float.MAX_VALUE;
            float minYb = Float.MAX_VALUE, maxYt = -Float.MAX_VALUE;
            for (TextPosition tp : positions) {
                if (tp.getX()                  < minX) minX = tp.getX();
                if (tp.getX() + tp.getWidth()  > maxX) maxX = tp.getX() + tp.getWidth();
                if (tp.getY()                  < minYb) minYb = tp.getY();
                if (tp.getY() + tp.getHeight() > maxYt) maxYt = tp.getY() + tp.getHeight();
            }
            lineCoords.add(new float[]{
                pageH - maxYt,   // yTop    (top-origin)
                pageH - minYb,   // yBottom (top-origin)
                minX,            // xLeft
                maxX             // xRight
            });

            super.writeString(text, positions);
        }

        @Override
        protected void writeLineSeparator() throws IOException {
            flushLine();
            super.writeLineSeparator();
        }

        /**
         * Paragraph separators appear at column/article boundaries.
         * They do NOT add a line to getText() output on their own,
         * so we must NOT flush here — overriding as no-op prevents
         * phantom line counter increments.
         */
        @Override
        protected void writeParagraphSeparator() throws IOException {
            // Intentionally empty — do NOT flush, do NOT increment counter
            // The next writeLineSeparator() or endPage() will flush correctly
            super.writeParagraphSeparator();
        }

        @Override
        protected void endPage(PDPage page) throws IOException {
            flushLine();
            super.endPage(page);
        }

        private void flushLine() {
            String raw = lineBuf.toString();
            lineBuf.setLength(0);

            if (raw.trim().isEmpty() || lineCoords.isEmpty()) {
                lineCoords.clear();
                return;
            }

            // Apply SAME content filter as extractLines()
            String processed = config.processLine(raw);
            if (processed == null || processed.trim().isEmpty()) {
                lineCoords.clear();
                return;
            }

            // Compute bounding box
            float yTop    =  Float.MAX_VALUE;
            float yBottom = -Float.MAX_VALUE;
            float xLeft   =  Float.MAX_VALUE;
            float xRight  = -Float.MAX_VALUE;
            for (float[] c : lineCoords) {
                if (c[0] < yTop)    yTop    = c[0];
                if (c[1] > yBottom) yBottom = c[1];
                if (c[2] < xLeft)   xLeft   = c[2];
                if (c[3] > xRight)  xRight  = c[3];
            }

            localLineNo++;
            acceptedLineCount++;
            lineBoxes.put(localLineNo, new LineBox(yTop, yBottom, xLeft, xRight));
            lineCoords.clear();
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HIGHLIGHT MAP — ADDED/REMOVED/CHANGED only
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, PDFComparator.DiffType> buildHighlightMap(
            List<PDFComparator.DiffRow> diff, String side) {
        Map<Integer, PDFComparator.DiffType> map = new LinkedHashMap<>();
        boolean isLeft = "left".equals(side);
        for (PDFComparator.DiffRow row : diff) {
            if (row.type == PDFComparator.DiffType.SAME) continue;
            boolean relevant = isLeft
                ? (row.type == PDFComparator.DiffType.REMOVED
                   || row.type == PDFComparator.DiffType.CHANGED)
                : (row.type == PDFComparator.DiffType.ADDED
                   || row.type == PDFComparator.DiffType.CHANGED);
            if (!relevant) continue;
            int lineNo = isLeft ? row.leftLineNo : row.rightLineNo;
            if (lineNo > 0) map.put(lineNo, row.type);
        }
        return map;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DRAW HIGHLIGHTS
    // ════════════════════════════════════════════════════════════════════════

    private static void drawHighlights(BufferedImage img, PDPage page,
                                        List<int[]> highlights) {
        float pdfW  = page.getMediaBox().getWidth();
        float pdfH  = page.getMediaBox().getHeight();
        float scaleX = (float) img.getWidth()  / pdfW;
        float scaleY = (float) img.getHeight() / pdfH;

        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                           RenderingHints.VALUE_ANTIALIAS_ON);

        for (int[] h : highlights) {
            float yTop    = Float.intBitsToFloat(h[0]);
            float yBottom = Float.intBitsToFloat(h[1]);
            float xLeft   = Float.intBitsToFloat(h[2]);
            float xRight  = Float.intBitsToFloat(h[3]);

            int px = Math.max(0,               (int)(xLeft   * scaleX) - 2);
            int py = Math.max(0,               (int)(yTop    * scaleY) - 1);
            int pr = Math.min(img.getWidth(),  (int)(xRight  * scaleX) + 2);
            int pb = Math.min(img.getHeight(), (int)(yBottom * scaleY) + 2);
            int pw = Math.max(4, pr - px);
            int ph = Math.max(3, pb - py);

            PDFComparator.DiffType type =
                PDFComparator.DiffType.values()[h[4]];
            Color fill, border;
            switch (type) {
                case REMOVED: fill = FILL_REM; border = BORDER_REM; break;
                case ADDED:   fill = FILL_ADD; border = BORDER_ADD; break;
                case CHANGED: fill = FILL_CHG; border = BORDER_CHG; break;
                default: continue;
            }

            g.setColor(fill);
            g.fillRect(px, py, pw, ph);
            g.setColor(border);
            g.setStroke(new BasicStroke(1.0f));
            g.drawRect(px, py, pw, ph);
        }
        g.dispose();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private static int[] pack(LineBox box, PDFComparator.DiffType type) {
        return new int[]{
            Float.floatToIntBits(box.yTop),
            Float.floatToIntBits(box.yBottom),
            Float.floatToIntBits(box.xLeft),
            Float.floatToIntBits(box.xRight),
            type.ordinal()
        };
    }

    private static List<RenderedPage> renderPlain(File pdfFile) throws IOException {
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    private static String toPng(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }
}
