package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Renders PDF pages as images with highlight boxes on differing lines.
 *
 * <h2>Why every previous approach was wrong</h2>
 *
 * <p>The problem: a two-column PDF (like COSREP bank reports) has text articles.
 * PDFBox calls {@code writeParagraphSeparator()} between articles (columns).
 * Every previous {@code LineRecorder} overrode {@code writeLineSeparator()} to
 * flush and count lines — but {@code writeParagraphSeparator()} also triggers a
 * flush, adding phantom line increments that don't exist in {@code getText()} output.
 * After page 1 column 1, every line number was off by +1, then +2, etc.
 * The highlights therefore landed on completely wrong lines.
 *
 * <h2>The correct approach</h2>
 *
 * <p>Run one single {@code PDFTextStripper} subclass ({@link PositionCapture}) that:
 * <ol>
 *   <li>Calls {@code super.getText(doc)} normally — this is the authoritative source
 *       of line order and line content, identical to {@link PDFComparator#extractLines}.</li>
 *   <li>During that same call, records every text run's page, Y-coordinate, and
 *       X-extent in a list ordered exactly as {@code getText()} processes them.</li>
 *   <li>After {@code getText()} returns, re-applies the same {@link FilterConfig}
 *       filters line-by-line on the output text, and for each accepted line looks up
 *       the corresponding runs from the position list to get a bounding box.</li>
 * </ol>
 *
 * <p>Because we parse the {@code getText()} output directly — the same string that
 * {@link PDFComparator#extractLines} splits on {@code \n} — the line numbers are
 * guaranteed identical. No separate counter. No callback ordering issues.
 */
final class PageRenderer {

    private static final float DPI = 150f;

    private static final Color FILL_REM   = new Color(220,  50,  50,  55);
    private static final Color FILL_ADD   = new Color( 40, 160,  40,  55);
    private static final Color FILL_CHG   = new Color(240, 130,   0,  55);
    private static final Color BORDER_REM = new Color(180,  20,  20, 210);
    private static final Color BORDER_ADD = new Color( 20, 130,  20, 210);
    private static final Color BORDER_CHG = new Color(200,  90,   0, 210);

    private PageRenderer() {}

    // ── Public output ─────────────────────────────────────────────────────────

    static final class RenderedPage {
        final int    pageIndex;
        final String base64Png;
        final int    widthPx;
        final int    heightPx;

        RenderedPage(int i, String b64, int w, int h) {
            pageIndex = i; base64Png = b64; widthPx = w; heightPx = h;
        }
    }

    // ── Internal position record ──────────────────────────────────────────────

    /** Position of a text run in the PDF, top-origin coordinates (points). */
    private static final class RunPos {
        final int   page;
        final float yTop;     // top of glyph from top of page
        final float yBottom;  // bottom of glyph from top of page
        final float xLeft;
        final float xRight;
        final String text;    // the raw text of this run (before any filtering)

        RunPos(int pg, float yt, float yb, float xl, float xr, String t) {
            page = pg; yTop = yt; yBottom = yb; xLeft = xl; xRight = xr; text = t;
        }
    }

    /** Bounding box of one accepted (filtered) line. */
    private static final class LineBox {
        final int   page;
        final float yTop;
        final float yBottom;
        final float xLeft;
        final float xRight;

        LineBox(int pg, float yt, float yb, float xl, float xr) {
            page = pg; yTop = yt; yBottom = yb; xLeft = xl; xRight = xr;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    static List<RenderedPage> render(File pdfFile,
                                      String side,
                                      List<PDFComparator.DiffRow> diff,
                                      FilterConfig config) throws IOException {

        Map<Integer, PDFComparator.DiffType> hlMap = buildHighlightMap(diff, side);
        if (hlMap.isEmpty()) {
            return renderPlain(pdfFile);
        }

        // Single pass: run getText() and capture positions simultaneously
        PositionCapture capture = new PositionCapture(config);
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            capture.getText(doc);
        }

        // Map from line number (1-based) to its bounding box on the page
        Map<Integer, LineBox> lineBoxes = capture.lineBoxes;

        // Group highlighted lines by page
        Map<Integer, List<int[]>> byPage = new HashMap<>();
        for (Map.Entry<Integer, PDFComparator.DiffType> entry : hlMap.entrySet()) {
            int lineNo = entry.getKey();
            LineBox box = lineBoxes.get(lineNo);
            if (box == null) continue;
            int typeOrd = entry.getValue().ordinal();
            byPage.computeIfAbsent(box.page, k -> new ArrayList<>())
                .add(new int[]{
                    Float.floatToIntBits(box.yTop),
                    Float.floatToIntBits(box.yBottom),
                    Float.floatToIntBits(box.xLeft),
                    Float.floatToIntBits(box.xRight),
                    typeOrd
                });
        }

        // Render pages
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                List<int[]> hl = byPage.getOrDefault(p, Collections.<int[]>emptyList());
                if (!hl.isEmpty()) {
                    drawHighlights(img, doc.getPage(p), hl);
                }
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  POSITION CAPTURE
    //
    //  Runs getText() once — same call that ZoneAwareStripper.extractLines()
    //  makes — and records the bounding box of each accepted line.
    //
    //  The line counter is derived from splitting getText() output on "\n"
    //  and applying filterConfig.processLine(), EXACTLY as extractLines() does.
    //  So line numbers here are guaranteed identical to the diff result.
    // ════════════════════════════════════════════════════════════════════════

    private static final class PositionCapture extends PDFTextStripper {

        private final FilterConfig config;

        // Runs collected during getText() — in output order
        private final List<RunPos> allRuns = new ArrayList<>();

        // Final result: line number → bounding box
        final Map<Integer, LineBox> lineBoxes = new LinkedHashMap<>();

        // Per-page state
        private int   currentPage = 0;
        private float pageH = 842f;
        private float pageW = 595f;

        // Tracks which character position in getText() output each run maps to
        private int outputCharPos = 0;   // incremented as we write chars to output

        // Zone-excluded runs accumulator (per output character position)
        // We record ALL non-zone-excluded runs with their output position
        private final List<long[]> runIndex = new ArrayList<>();
        // long[] = {outputStartChar, outputEndChar, runIndex_in_allRuns}

        PositionCapture(FilterConfig config) throws IOException {
            super();
            this.config = config;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle box = page.getMediaBox();
            pageH = box.getHeight();
            pageW = box.getWidth();
            currentPage = getCurrentPageNo() - 1;
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions)
                throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }

            // Zone filters — identical to ZoneAwareStripper
            float sumX = 0f, sumY = 0f;
            for (TextPosition tp : positions) { sumX += tp.getX(); sumY += tp.getY(); }
            float avgX    = sumX / positions.size();
            float avgY    = sumY / positions.size();
            float yFromTop = pageH - avgY;

            boolean zoneExcluded =
                (config.isIgnoreHeader()
                    && yFromTop < pageH * (config.getHeaderPct() / 100.0))
                || (config.isIgnoreFooter()
                    && yFromTop > pageH * ((100.0 - config.getFooterPct()) / 100.0))
                || (config.isIgnoreLeftMargin()
                    && avgX < pageW * (config.getMarginPct() / 100.0))
                || (config.isIgnoreRightMargin()
                    && avgX > pageW * ((100.0 - config.getMarginPct()) / 100.0));

            if (zoneExcluded) {
                // Do NOT call super — same as ZoneAwareStripper
                // Do NOT record position — this text won't appear in getText() output
                return;
            }

            // Compute bounding box (top-origin)
            float minX = Float.MAX_VALUE, maxX = -Float.MAX_VALUE;
            float minYb = Float.MAX_VALUE, maxYt = -Float.MAX_VALUE;
            for (TextPosition tp : positions) {
                if (tp.getX() < minX)              minX = tp.getX();
                if (tp.getX() + tp.getWidth() > maxX) maxX = tp.getX() + tp.getWidth();
                if (tp.getY() < minYb)             minYb = tp.getY();
                if (tp.getY() + tp.getHeight() > maxYt) maxYt = tp.getY() + tp.getHeight();
            }
            float yTop    = pageH - maxYt;
            float yBottom = pageH - minYb;

            int idx = allRuns.size();
            allRuns.add(new RunPos(currentPage, yTop, yBottom, minX, maxX, text));

            // Record output range this run occupies
            int startPos = outputCharPos;
            outputCharPos += text.length();
            runIndex.add(new long[]{startPos, outputCharPos, idx});

            super.writeString(text, positions);
        }

        /**
         * Called by PDFTextStripper after getText() has finished writing all pages.
         * At this point, getTextStripper output is complete. We parse it into lines
         * using the SAME logic as PDFComparator.extractLines(), and for each accepted
         * line, look up the runs that contributed to it to compute a bounding box.
         */
        @Override
        public String getText(PDDocument doc) throws IOException {
            String fullText = super.getText(doc);
            buildLineBoxes(fullText);
            return fullText;
        }

        private void buildLineBoxes(String fullText) {
            // Split on the same separator that getText() uses
            String[] rawLines = fullText.split("\n", -1);

            int lineNo    = 1;   // 1-based, matches extractLines()
            int charPos   = 0;   // tracks position within fullText

            for (String rawLine : rawLines) {
                int lineStart = charPos;
                int lineEnd   = charPos + rawLine.length();
                charPos = lineEnd + 1;  // +1 for the '\n'

                // Apply SAME filters as extractLines()
                String processed = config.processLine(rawLine);
                if (processed == null || processed.trim().isEmpty()) {
                    continue;
                }

                // Find all runs whose output range overlaps this line's char range
                float yTop    =  Float.MAX_VALUE;
                float yBottom = -Float.MAX_VALUE;
                float xLeft   =  Float.MAX_VALUE;
                float xRight  = -Float.MAX_VALUE;
                int   page    = -1;

                for (long[] ri : runIndex) {
                    long rStart = ri[0];
                    long rEnd   = ri[1];
                    int  rIdx   = (int) ri[2];

                    // Check overlap with this line's char range
                    if (rEnd <= lineStart || rStart >= lineEnd) continue;

                    RunPos rp = allRuns.get(rIdx);
                    if (page == -1) page = rp.page;

                    if (rp.yTop    < yTop)    yTop    = rp.yTop;
                    if (rp.yBottom > yBottom) yBottom = rp.yBottom;
                    if (rp.xLeft   < xLeft)   xLeft   = rp.xLeft;
                    if (rp.xRight  > xRight)  xRight  = rp.xRight;
                }

                if (page >= 0 && yTop < Float.MAX_VALUE) {
                    lineBoxes.put(lineNo, new LineBox(page, yTop, yBottom, xLeft, xRight));
                }
                lineNo++;
            }
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HIGHLIGHT MAP
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, PDFComparator.DiffType> buildHighlightMap(
            List<PDFComparator.DiffRow> diff, String side) {

        Map<Integer, PDFComparator.DiffType> map = new LinkedHashMap<>();
        boolean isLeft = "left".equals(side);

        for (PDFComparator.DiffRow row : diff) {
            if (row.type == PDFComparator.DiffType.SAME) continue;
            boolean relevant = isLeft
                ? (row.type == PDFComparator.DiffType.REMOVED
                   || row.type == PDFComparator.DiffType.CHANGED)
                : (row.type == PDFComparator.DiffType.ADDED
                   || row.type == PDFComparator.DiffType.CHANGED);
            if (!relevant) continue;
            int lineNo = isLeft ? row.leftLineNo : row.rightLineNo;
            if (lineNo > 0) map.put(lineNo, row.type);
        }
        return map;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DRAW HIGHLIGHTS
    // ════════════════════════════════════════════════════════════════════════

    private static void drawHighlights(BufferedImage img, PDPage page,
                                        List<int[]> highlights) {
        PDRectangle media = page.getMediaBox();
        float scaleX = (float) img.getWidth()  / media.getWidth();
        float scaleY = (float) img.getHeight() / media.getHeight();

        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                           RenderingHints.VALUE_ANTIALIAS_ON);

        for (int[] h : highlights) {
            float yTop    = Float.intBitsToFloat(h[0]);
            float yBottom = Float.intBitsToFloat(h[1]);
            float xLeft   = Float.intBitsToFloat(h[2]);
            float xRight  = Float.intBitsToFloat(h[3]);

            int px = Math.max(0,               (int)(xLeft  * scaleX) - 2);
            int py = Math.max(0,               (int)(yTop   * scaleY) - 1);
            int pr = Math.min(img.getWidth(),  (int)(xRight * scaleX) + 2);
            int pb = Math.min(img.getHeight(), (int)(yBottom * scaleY) + 2);
            int pw = Math.max(4, pr - px);
            int ph = Math.max(3, pb - py);

            PDFComparator.DiffType type =
                PDFComparator.DiffType.values()[h[4]];
            Color fill, border;
            switch (type) {
                case REMOVED: fill = FILL_REM; border = BORDER_REM; break;
                case ADDED:   fill = FILL_ADD; border = BORDER_ADD; break;
                case CHANGED: fill = FILL_CHG; border = BORDER_CHG; break;
                default: continue;
            }

            g.setColor(fill);
            g.fillRect(px, py, pw, ph);
            g.setColor(border);
            g.setStroke(new BasicStroke(1.0f));
            g.drawRect(px, py, pw, ph);
        }
        g.dispose();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PLAIN RENDER
    // ════════════════════════════════════════════════════════════════════════

    private static List<RenderedPage> renderPlain(File pdfFile) throws IOException {
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PNG ENCODER
    // ════════════════════════════════════════════════════════════════════════

    private static String toPng(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }
}
