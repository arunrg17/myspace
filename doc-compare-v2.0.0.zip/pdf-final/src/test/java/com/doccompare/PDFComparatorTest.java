package com.doccompare;

import org.junit.Test;
import java.io.File;
import java.util.List;
import static org.junit.Assert.*;

/**
 * Unit tests for PDFComparator logic.
 * No PDF files required — tests the algorithm and helpers in isolation.
 */
public class PDFComparatorTest {

    // ════════════════════════════════════════════════════════════════════════
    //  DIFF ALGORITHM
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testIdenticalInputProducesNoDiffs() {
        String[] a = {"line one", "line two", "line three"};
        String[] b = {"line one", "line two", "line three"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long diffs = diff.stream().filter(r -> r.type != PDFComparator.DiffType.SAME).count();
        assertEquals("Identical input should produce zero diffs", 0, diffs);
    }

    @Test
    public void testAllSameRowsForIdenticalInput() {
        String[] a = {"alpha", "beta"};
        String[] b = {"alpha", "beta"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        assertTrue("All rows should be SAME", diff.stream().allMatch(r -> r.type == PDFComparator.DiffType.SAME));
    }

    @Test
    public void testAddedLineDetected() {
        String[] a = {"alpha", "gamma"};
        String[] b = {"alpha", "beta", "gamma"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long added = diff.stream().filter(r -> r.type == PDFComparator.DiffType.ADDED).count();
        assertEquals("One line should be ADDED", 1, added);
    }

    @Test
    public void testRemovedLineDetected() {
        String[] a = {"alpha", "beta", "gamma"};
        String[] b = {"alpha", "gamma"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long removed = diff.stream().filter(r -> r.type == PDFComparator.DiffType.REMOVED).count();
        assertEquals("One line should be REMOVED", 1, removed);
    }

    @Test
    public void testChangedLineProducesDiff() {
        String[] a = {"Rate: $100 per hour"};
        String[] b = {"Rate: $150 per hour"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long diffCount = diff.stream().filter(r -> r.type != PDFComparator.DiffType.SAME).count();
        assertTrue("Differing single lines should produce at least one diff row", diffCount >= 1);
    }

    @Test
    public void testEmptyArraysProduceEmptyDiff() {
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(new String[0], new String[0]);
        assertTrue("Empty inputs should produce empty diff", diff.isEmpty());
    }

    @Test
    public void testEmptyVsNonEmptyAllAdded() {
        String[] a = {};
        String[] b = {"x", "y", "z"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long added = diff.stream().filter(r -> r.type == PDFComparator.DiffType.ADDED).count();
        assertEquals("All lines in b should be ADDED", 3, added);
    }

    @Test
    public void testNonEmptyVsEmptyAllRemoved() {
        String[] a = {"x", "y", "z"};
        String[] b = {};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long removed = diff.stream().filter(r -> r.type == PDFComparator.DiffType.REMOVED).count();
        assertEquals("All lines in a should be REMOVED", 3, removed);
    }

    @Test
    public void testDiffRowHasCorrectText() {
        String[] a = {"hello world"};
        String[] b = {"hello java"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        // At least one row should reference the original texts
        boolean leftFound  = diff.stream().anyMatch(r -> "hello world".equals(r.left));
        boolean rightFound = diff.stream().anyMatch(r -> "hello java".equals(r.right));
        assertTrue("Diff should contain left text",  leftFound);
        assertTrue("Diff should contain right text", rightFound);
    }

    @Test
    public void testLineNumbersStartAtOne() {
        String[] a = {"first", "second"};
        String[] b = {"first", "second"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        assertEquals("First row left line number should be 1",  1, diff.get(0).leftLineNo);
        assertEquals("First row right line number should be 1", 1, diff.get(0).rightLineNo);
    }

    @Test
    public void testLineNumbersIncrementCorrectly() {
        String[] a = {"a", "b", "c"};
        String[] b = {"a", "b", "c"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        assertEquals(1, diff.get(0).leftLineNo);
        assertEquals(2, diff.get(1).leftLineNo);
        assertEquals(3, diff.get(2).leftLineNo);
    }

    @Test
    public void testMultipleChangesDetected() {
        String[] a = {"unchanged", "old value 1", "unchanged", "old value 2"};
        String[] b = {"unchanged", "new value 1", "unchanged", "new value 2"};
        List<PDFComparator.DiffRow> diff = PDFComparator.computeDiff(a, b);
        long diffs = diff.stream().filter(r -> r.type != PDFComparator.DiffType.SAME).count();
        assertTrue("Should detect 2 diffs", diffs >= 2);
        long same = diff.stream().filter(r -> r.type == PDFComparator.DiffType.SAME).count();
        assertEquals("Should have 2 unchanged lines", 2, same);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  WORD DIFF
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testWordDiffIdenticalNoMarks() {
        String[] r = PDFComparator.wordDiff("hello world", "hello world");
        assertFalse("Left:  no marks expected for identical input", r[0].contains("<mark>"));
        assertFalse("Right: no marks expected for identical input", r[1].contains("<mark>"));
    }

    @Test
    public void testWordDiffMarksOnlyChangedWord() {
        String[] r = PDFComparator.wordDiff("Rate $100 per hour", "Rate $150 per hour");
        assertTrue("Left should mark 100",  r[0].contains("<mark>100</mark>") || r[0].contains("<mark>$100</mark>"));
        assertTrue("Right should mark 150", r[1].contains("<mark>150</mark>") || r[1].contains("<mark>$150</mark>"));
        assertFalse("Left should NOT mark 'Rate'",  r[0].contains("<mark>Rate</mark>"));
        assertFalse("Right should NOT mark 'Rate'", r[1].contains("<mark>Rate</mark>"));
    }

    @Test
    public void testWordDiffCompletelyDifferent() {
        String[] r = PDFComparator.wordDiff("foo bar", "baz qux");
        assertTrue("Left should have marks",  r[0].contains("<mark>"));
        assertTrue("Right should have marks", r[1].contains("<mark>"));
    }

    @Test
    public void testWordDiffEmptyStrings() {
        String[] r = PDFComparator.wordDiff("", "");
        assertEquals("Empty left", "", r[0]);
        assertEquals("Empty right", "", r[1]);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HTML ESCAPING
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testEscapeAmpersand() {
        assertEquals("&amp;", PDFComparator.escHtml("&"));
    }

    @Test
    public void testEscapeLtGt() {
        assertEquals("&lt;script&gt;", PDFComparator.escHtml("<script>"));
    }

    @Test
    public void testEscapeDoubleQuote() {
        assertEquals("&quot;", PDFComparator.escHtml("\""));
    }

    @Test
    public void testEscapeNull() {
        assertEquals("", PDFComparator.escHtml(null));
    }

    @Test
    public void testXssAttemptEscaped() {
        String xss    = "<script>alert('xss')</script>";
        String result = PDFComparator.escHtml(xss);
        assertFalse("Must not contain literal <script>", result.contains("<script>"));
        assertFalse("Must not contain literal </script>", result.contains("</script>"));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  FILTER CONFIG
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testBuilderCreatesConfig() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .ignoreHeader(true).headerPct(15)
            .ignoreFooter(true).footerPct(12)
            .ignoreMargins(true).marginPct(10)
            .ignoreTimestamps(true)
            .ignorePageNumbers(true)
            .build();
        assertTrue(cfg.isIgnoreHeader());
        assertTrue(cfg.isIgnoreFooter());
        assertTrue(cfg.isIgnoreLeftMargin());
        assertTrue(cfg.isIgnoreRightMargin());
        assertTrue(cfg.isIgnoreTimestamps());
        assertTrue(cfg.isIgnorePageNumbers());
        assertEquals(15.0, cfg.getHeaderPct(), 0.001);
        assertEquals(12.0, cfg.getFooterPct(), 0.001);
        assertEquals(10.0, cfg.getMarginPct(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testBuilderRequiresPdf1() {
        new FilterConfig.Builder().pdf2("b.pdf").output("o.html").build();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testBuilderRequiresPdf2() {
        new FilterConfig.Builder().pdf1("a.pdf").output("o.html").build();
    }

    @Test(expected = IllegalArgumentException.class)
    public void testBuilderRequiresOutput() {
        new FilterConfig.Builder().pdf1("a.pdf").pdf2("b.pdf").build();
    }

    @Test
    public void testHeaderPctClamped() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .headerPct(99).build();
        assertTrue("headerPct should be clamped to <=49", cfg.getHeaderPct() <= 49.0);
    }

    @Test
    public void testFooterPctClamped() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .footerPct(0).build();
        assertTrue("footerPct should be clamped to >=1", cfg.getFooterPct() >= 1.0);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PROCESS LINE
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testProcessLineDropsBarePageNumber() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .ignorePageNumbers(true).build();

        // These unambiguous page-number formats ARE dropped
        assertNull("'Page 3' should be dropped",          cfg.processLine("Page 3"));
        assertNull("'Page 3 of 10' should be dropped",    cfg.processLine("Page 3 of 10"));
        assertNull("'Seite 2 von 5' should be dropped",   cfg.processLine("Seite 2 von 5"));
        assertNull("'39/40' format should be dropped",    cfg.processLine("39/40"));
        assertNull("'- 5 -' format should be dropped",    cfg.processLine("- 5 -"));

        // Bare single digit is intentionally NOT dropped — it could be a
        // section number, ID, or financial total.  Use a page-number pattern
        // like "Page N" or "N/M" instead of bare digits.
        assertNotNull("Bare digit '5' is kept (may be ID/total, not a page number)",
            cfg.processLine("5"));

        // Normal content always kept
        assertNotNull("Normal content should be kept",
            cfg.processLine("Account balance: 1,234.56"));
    }

    @Test
    public void testProcessLineStripsTimestamps() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .ignoreTimestamps(true).build();

        // Pure timestamp / metadata lines MUST be dropped
        assertNull("'Erstellt am' footer should be dropped",
            cfg.processLine("Erstellt am 08.12.2025 um 11:34"));
        assertNull("Bare date line should be dropped",
            cfg.processLine("08.12.2025 um 11:34"));
        assertNull("Stand: date line should be dropped",
            cfg.processLine("Stand: 01.01.2024"));

        // CRITICAL: content lines containing a date must be KEPT intact
        // so that date differences in document content are detected by the diff
        String contentLine = "(1) Der Depotpreis wurde im Rahmen einer Transaktion am 01.07.2024 berechnet.";
        String result = cfg.processLine(contentLine);
        assertNotNull("Content line with date must NOT be dropped", result);
        assertTrue("Content line must retain the date", result.contains("01.07.2024"));

        // Another content line with embedded date
        String amountLine = "Gesamtkosten: 965,46 EUR (Stand: Q3 2024)";
        assertNotNull("Amount line must NOT be dropped", cfg.processLine(amountLine));
    }

    @Test
    public void testProcessLineStripsCustomPattern() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .ignorePattern("DRAFT").build();
        String result = cfg.processLine("DRAFT - Internal Use Only");
        assertNotNull("Line should not be dropped", result);
        assertFalse("DRAFT should be stripped", result.contains("DRAFT"));
    }

    @Test
    public void testProcessLineStripsCustomText() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .ignoreText("Erstellt am").build();
        String result = cfg.processLine("Erstellt am 08.12.2025 um 11:34");
        assertNotNull("Line should not be dropped (some content remains)", result);
        assertFalse("Literal text should be stripped", result.contains("Erstellt am"));
    }

    @Test
    public void testProcessLineReturnsNullForBlankAfterFilter() {
        FilterConfig cfg = new FilterConfig.Builder()
            .pdf1("a.pdf").pdf2("b.pdf").output("o.html")
            .ignorePattern(".*").build();
        assertNull("Line that becomes empty after filter should be null", cfg.processLine("anything"));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  VALIDATION
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testValidateFileThrowsForMissing() {
        try {
            PDFComparator.validateFile("does_not_exist.pdf");
            fail("Expected IOException for non-existent file");
        } catch (Exception ex) {
            assertTrue("Exception should be IOException or subclass",
                ex instanceof java.io.IOException);
        }
    }

    @Test
    public void testValidateFileThrowsForNonPdf() throws Exception {
        File tmp = File.createTempFile("test", ".txt");
        tmp.deleteOnExit();
        try {
            PDFComparator.validateFile(tmp.getAbsolutePath());
            fail("Expected IOException for non-PDF file");
        } catch (Exception ex) {
            assertTrue("Exception should mention PDF", ex.getMessage().contains("PDF") || ex.getMessage().contains("pdf"));
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CLI
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testCliTooFewArgsReturnsError() {
        assertEquals(PDFComparator.EXIT_ERROR, PDFComparator.runCli(new String[]{"only.pdf"}));
    }

    @Test
    public void testCliNoArgsReturnsError() {
        assertEquals(PDFComparator.EXIT_ERROR, PDFComparator.runCli(new String[]{}));
    }

    @Test
    public void testCliNonExistentFilesReturnError() {
        int code = PDFComparator.runCli(new String[]{"nope1.pdf", "nope2.pdf", "out.html"});
        assertEquals("Non-existent files should return EXIT_ERROR (2)",
            PDFComparator.EXIT_ERROR, code);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  COMPARE RESULT
    // ════════════════════════════════════════════════════════════════════════

    @Test
    public void testCompareResultPass() {
        CompareResult r = new CompareResult(CompareResult.Status.PASS, 0, 0, 0, 10, 10, 10, "/out.html", null);
        assertTrue(r.isPassed());
        assertEquals(CompareResult.Status.PASS, r.getStatus());
        assertEquals(0, r.getTotalDiffs());
    }

    @Test
    public void testCompareResultFail() {
        CompareResult r = new CompareResult(CompareResult.Status.FAIL, 2, 1, 3, 10, 10, 10, "/out.html", null);
        assertFalse(r.isPassed());
        assertEquals(6, r.getTotalDiffs());
    }

    @Test
    public void testCompareResultError() {
        CompareResult r = new CompareResult(CompareResult.Status.ERROR, 0, 0, 0, 0, 0, 0, null, "File not found");
        assertFalse(r.isPassed());
        assertEquals(CompareResult.Status.ERROR, r.getStatus());
        assertEquals("File not found", r.getErrorMessage());
        assertNull(r.getReportPath());
    }
}
