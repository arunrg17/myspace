package com.doccompare;

/**
 * Immutable result object returned by {@link PDFComparator#compare}.
 *
 * <p>Use this in Selenium or UFT to determine pass/fail and locate the report:
 * <pre>
 *   CompareResult result = PDFComparator.compare(config);
 *   if (!result.isPassed()) {
 *       // fail the test, attach result.getReportPath()
 *   }
 * </pre>
 */
public final class CompareResult {

    /** Comparison outcome */
    public enum Status { PASS, FAIL, ERROR }

    private final Status  status;
    private final int     addedLines;
    private final int     removedLines;
    private final int     changedLines;
    private final int     sameLines;
    private final int     totalLinesPdf1;
    private final int     totalLinesPdf2;
    private final String  reportPath;     // absolute path to the written HTML file
    private final String  errorMessage;  // non-null only when status == ERROR

    /** Package-private constructor — built by PDFComparator only. */
    CompareResult(Status status,
                  int addedLines, int removedLines, int changedLines, int sameLines,
                  int totalLinesPdf1, int totalLinesPdf2,
                  String reportPath, String errorMessage) {
        this.status         = status;
        this.addedLines     = addedLines;
        this.removedLines   = removedLines;
        this.changedLines   = changedLines;
        this.sameLines      = sameLines;
        this.totalLinesPdf1 = totalLinesPdf1;
        this.totalLinesPdf2 = totalLinesPdf2;
        this.reportPath     = reportPath;
        this.errorMessage   = errorMessage;
    }

    // ── Accessors ───────────────────────────────────────────────────────────

    /** @return true only when the two PDFs are identical after applying all filters. */
    public boolean isPassed() { return status == Status.PASS; }

    /** @return the outcome: PASS, FAIL, or ERROR. */
    public Status getStatus() { return status; }

    /** @return number of lines present in PDF 2 but not PDF 1. */
    public int getAddedLines() { return addedLines; }

    /** @return number of lines present in PDF 1 but not PDF 2. */
    public int getRemovedLines() { return removedLines; }

    /** @return number of lines that exist in both PDFs but differ in content. */
    public int getChangedLines() { return changedLines; }

    /** @return number of identical lines. */
    public int getSameLines() { return sameLines; }

    /** @return total lines extracted from PDF 1 after filtering. */
    public int getTotalLinesPdf1() { return totalLinesPdf1; }

    /** @return total lines extracted from PDF 2 after filtering. */
    public int getTotalLinesPdf2() { return totalLinesPdf2; }

    /** @return total number of differing lines (added + removed + changed). */
    public int getTotalDiffs() { return addedLines + removedLines + changedLines; }

    /**
     * @return absolute path to the HTML comparison report that was written to disk,
     *         or null if status is ERROR and the report could not be written.
     */
    public String getReportPath() { return reportPath; }

    /**
     * @return error description when status is ERROR, null otherwise.
     */
    public String getErrorMessage() { return errorMessage; }

    @Override
    public String toString() {
        return "CompareResult{"
            + "status=" + status
            + ", added=" + addedLines
            + ", removed=" + removedLines
            + ", changed=" + changedLines
            + ", same=" + sameLines
            + ", report='" + reportPath + "'"
            + (errorMessage != null ? ", error='" + errorMessage + "'" : "")
            + "}";
    }
}
