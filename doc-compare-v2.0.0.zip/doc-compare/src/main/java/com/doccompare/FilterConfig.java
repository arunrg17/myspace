package com.doccompare;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Immutable configuration for a PDF comparison run.
 *
 * <p>Create instances via {@link Builder}:
 * <pre>
 *   FilterConfig config = new FilterConfig.Builder()
 *       .pdf1("C:/reports/env1.pdf")
 *       .pdf2("C:/reports/env2.pdf")
 *       .output("C:/reports/comparison.html")
 *       .ignoreHeader(true)
 *       .ignoreFooter(true)
 *       .ignoreMargins(true)
 *       .ignoreTimestamps(true)
 *       .build();
 * </pre>
 *
 * <p>Or load from a properties file:
 * <pre>
 *   FilterConfig config = new FilterConfig.Builder()
 *       .pdf1(pdf1).pdf2(pdf2).output(out)
 *       .ignoreConfig("C:/tools/ignore.properties")
 *       .build();
 * </pre>
 */
public final class FilterConfig {

    // ── File paths ──────────────────────────────────────────────────────────
    private final String pdf1Path;
    private final String pdf2Path;
    private final String outputPath;

    // ── Spatial zone flags ──────────────────────────────────────────────────
    private final boolean ignoreHeader;
    private final boolean ignoreFooter;
    private final boolean ignoreLeftMargin;
    private final boolean ignoreRightMargin;
    private final double  headerPct;
    private final double  footerPct;
    private final double  marginPct;

    // ── Content filter flags ────────────────────────────────────────────────
    private final boolean        ignoreTimestamps;
    private final boolean        ignorePageNumbers;
    private final List<Pattern>  customPatterns;

    // ── Built-in patterns (compiled once at class-load time) ─────────────────

    static final Pattern[] TIMESTAMP_PATTERNS = {
        Pattern.compile("\\b\\d{4}-\\d{2}-\\d{2}[T ]\\d{2}:\\d{2}(:\\d{2})?\\b"),
        Pattern.compile("\\b\\d{1,2}[/\\-.]\\d{1,2}[/\\-.]\\d{2,4}\\b"),
        Pattern.compile("\\b(\\d{1,2}\\s+[A-Za-z]{3,9}\\s+\\d{4}|[A-Za-z]{3,9}\\s+\\d{1,2},?\\s+\\d{4})\\b"),
        Pattern.compile("\\b\\d{1,2}:\\d{2}(:\\d{2})?\\s*(AM|PM|Uhr)?\\b", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?i)(printed|generated|created|issued|erstellt|datum|date|timestamp)[:\\s]+[\\d\\w./ \\-:,]{4,40}"),
    };

    static final Pattern[] PAGE_NUMBER_PATTERNS = {
        Pattern.compile("(?i)^\\s*page\\s+\\d+(\\s+of\\s+\\d+)?\\s*$"),
        Pattern.compile("(?i)^\\s*seite\\s+\\d+(\\s+von\\s+\\d+)?\\s*$"),
        Pattern.compile("^\\s*\\d+\\s*/\\s*\\d+\\s*$"),
        Pattern.compile("^\\s*[-\u2013]\\s*\\d+\\s*[-\u2013]\\s*$"),
        Pattern.compile("^\\s*\\d+\\s*$"),
    };

    // ── Private constructor ─────────────────────────────────────────────────

    private FilterConfig(Builder b) {
        this.pdf1Path          = b.pdf1Path;
        this.pdf2Path          = b.pdf2Path;
        this.outputPath        = b.outputPath;
        this.ignoreHeader      = b.ignoreHeader;
        this.ignoreFooter      = b.ignoreFooter;
        this.ignoreLeftMargin  = b.ignoreLeftMargin;
        this.ignoreRightMargin = b.ignoreRightMargin;
        this.headerPct         = clamp(b.headerPct,  1.0, 49.0);
        this.footerPct         = clamp(b.footerPct,  1.0, 49.0);
        this.marginPct         = clamp(b.marginPct,  1.0, 30.0);
        this.ignoreTimestamps  = b.ignoreTimestamps;
        this.ignorePageNumbers = b.ignorePageNumbers;
        this.customPatterns    = Collections.unmodifiableList(new ArrayList<>(b.customPatterns));
    }

    // ── Accessors ────────────────────────────────────────────────────────────

    public String  getPdf1Path()             { return pdf1Path; }
    public String  getPdf2Path()             { return pdf2Path; }
    public String  getOutputPath()           { return outputPath; }
    public boolean isIgnoreHeader()          { return ignoreHeader; }
    public boolean isIgnoreFooter()          { return ignoreFooter; }
    public boolean isIgnoreLeftMargin()      { return ignoreLeftMargin; }
    public boolean isIgnoreRightMargin()     { return ignoreRightMargin; }
    public double  getHeaderPct()            { return headerPct; }
    public double  getFooterPct()            { return footerPct; }
    public double  getMarginPct()            { return marginPct; }
    public boolean isIgnoreTimestamps()      { return ignoreTimestamps; }
    public boolean isIgnorePageNumbers()     { return ignorePageNumbers; }
    public List<Pattern> getCustomPatterns() { return customPatterns; }

    /**
     * Apply all content-level filters to one extracted text line.
     *
     * @param line raw text line from the PDF
     * @return filtered line, or {@code null} if the line should be dropped entirely
     */
    public String processLine(String line) {
        if (line == null) return null;
        String trimmed = line.trim();

        if (ignorePageNumbers) {
            for (Pattern p : PAGE_NUMBER_PATTERNS) {
                if (p.matcher(trimmed).matches()) return null;
            }
        }

        String result = line;
        if (ignoreTimestamps) {
            for (Pattern p : TIMESTAMP_PATTERNS) {
                result = p.matcher(result).replaceAll("");
            }
        }
        for (Pattern p : customPatterns) {
            result = p.matcher(result).replaceAll("");
        }

        return result.trim().isEmpty() ? null : result;
    }

    /** Human-readable summary of active filters — used in the HTML report header. */
    public String summary() {
        List<String> parts = new ArrayList<>();
        if (ignoreHeader)      parts.add("header " + (int) headerPct + "%");
        if (ignoreFooter)      parts.add("footer " + (int) footerPct + "%");
        if (ignoreLeftMargin)  parts.add("left-margin " + (int) marginPct + "%");
        if (ignoreRightMargin) parts.add("right-margin " + (int) marginPct + "%");
        if (ignoreTimestamps)  parts.add("timestamps");
        if (ignorePageNumbers) parts.add("page-numbers");
        for (Pattern p : customPatterns) parts.add("text:" + p.pattern());
        return parts.isEmpty() ? "none" : String.join("  |  ", parts);
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BUILDER
    // ════════════════════════════════════════════════════════════════════════

    public static final class Builder {

        private String  pdf1Path;
        private String  pdf2Path;
        private String  outputPath;

        private boolean ignoreHeader      = false;
        private boolean ignoreFooter      = false;
        private boolean ignoreLeftMargin  = false;
        private boolean ignoreRightMargin = false;
        private double  headerPct         = 10.0;
        private double  footerPct         = 10.0;
        private double  marginPct         = 8.0;

        private boolean       ignoreTimestamps  = false;
        private boolean       ignorePageNumbers = false;
        private List<Pattern> customPatterns    = new ArrayList<>();

        // ── Required paths ──────────────────────────────────────────────────

        /** Path to the first (baseline) PDF. */
        public Builder pdf1(String path)   { this.pdf1Path   = path; return this; }

        /** Path to the second (comparison) PDF. */
        public Builder pdf2(String path)   { this.pdf2Path   = path; return this; }

        /** Path where the HTML report will be written. Parent directory is created if absent. */
        public Builder output(String path) { this.outputPath = path; return this; }

        // ── Zone flags ──────────────────────────────────────────────────────

        /** Ignore the top N% of each page (headers, logos, letterhead). Default N=10. */
        public Builder ignoreHeader(boolean v)      { this.ignoreHeader      = v; return this; }

        /** Ignore the bottom N% of each page (footers, page numbers). Default N=10. */
        public Builder ignoreFooter(boolean v)      { this.ignoreFooter      = v; return this; }

        /** Ignore the left N% of each page (vertical timestamps, binding marks). Default N=8. */
        public Builder ignoreLeftMargin(boolean v)  { this.ignoreLeftMargin  = v; return this; }

        /** Ignore the right N% of each page (vertical watermarks, border text). Default N=8. */
        public Builder ignoreRightMargin(boolean v) { this.ignoreRightMargin = v; return this; }

        /** Convenience: ignore both left and right margins. */
        public Builder ignoreMargins(boolean v) {
            this.ignoreLeftMargin = v;
            this.ignoreRightMargin = v;
            return this;
        }

        /** Override the header zone height (1–49 %). */
        public Builder headerPct(double pct) { this.headerPct = pct; return this; }

        /** Override the footer zone height (1–49 %). */
        public Builder footerPct(double pct) { this.footerPct = pct; return this; }

        /** Override the margin zone width (1–30 %). */
        public Builder marginPct(double pct) { this.marginPct = pct; return this; }

        // ── Content filters ─────────────────────────────────────────────────

        /** Strip date/time patterns from line content before comparing. */
        public Builder ignoreTimestamps(boolean v)  { this.ignoreTimestamps  = v; return this; }

        /** Drop lines whose entire content is a page number. */
        public Builder ignorePageNumbers(boolean v) { this.ignorePageNumbers = v; return this; }

        /**
         * Add a custom Java regex. Matches are removed from the line before comparing.
         * If the whole line becomes empty after removal, it is dropped.
         *
         * @throws PatternSyntaxException if the regex is invalid
         */
        public Builder ignorePattern(String regex) {
            this.customPatterns.add(Pattern.compile(regex));
            return this;
        }

        /**
         * Ignore a plain literal text string — no regex knowledge needed.
         * The string is automatically escaped for safe regex matching.
         *
         * <p>Example: {@code .ignoreText("Erstellt am")} removes every occurrence
         * of the literal text "Erstellt am" from lines before comparing.
         */
        public Builder ignoreText(String literal) {
            this.customPatterns.add(Pattern.compile(Pattern.quote(literal)));
            return this;
        }

        /**
         * Load ignore settings from a Java {@code .properties} file.
         *
         * <p>Settings are <b>additive</b> — combined with flags already set on this builder.
         * This is the recommended way to configure ignores for a specific document type
         * without changing your test code.
         *
         * <p>Supported keys:
         * <pre>
         * # Zone filters
         * ignore.header=true
         * ignore.footer=true
         * ignore.left.margin=true
         * ignore.right.margin=true
         * ignore.margins=true
         * header.pct=15
         * footer.pct=12
         * margin.pct=10
         *
         * # Content filters
         * ignore.timestamps=true
         * ignore.page.numbers=true
         *
         * # Plain text to strip (no regex needed)
         * ignore.text.1=Erstellt am
         * ignore.text.2=Ursprung, Eva und Adam
         * ignore.text.3=COSREP
         *
         * # Regex patterns to strip (Java regex syntax)
         * ignore.pattern.1=DRAFT
         * ignore.pattern.2=Printed on.*
         * ignore.pattern.3=Generated by.*
         * </pre>
         *
         * @param propertiesFilePath path to the .properties file
         * @throws IOException if the file cannot be read
         */
        public Builder ignoreConfig(String propertiesFilePath) throws IOException {
            Properties props = new Properties();
            try (FileInputStream fis = new FileInputStream(propertiesFilePath)) {
                props.load(fis);
            }

            if ("true".equalsIgnoreCase(props.getProperty("ignore.header")))
                this.ignoreHeader = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.footer")))
                this.ignoreFooter = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.left.margin")))
                this.ignoreLeftMargin = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.right.margin")))
                this.ignoreRightMargin = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.margins"))) {
                this.ignoreLeftMargin = true;
                this.ignoreRightMargin = true;
            }
            if ("true".equalsIgnoreCase(props.getProperty("ignore.timestamps")))
                this.ignoreTimestamps = true;
            if ("true".equalsIgnoreCase(props.getProperty("ignore.page.numbers")))
                this.ignorePageNumbers = true;

            String hp = props.getProperty("header.pct");
            String fp = props.getProperty("footer.pct");
            String mp = props.getProperty("margin.pct");
            if (hp != null) this.headerPct = Double.parseDouble(hp.trim());
            if (fp != null) this.footerPct = Double.parseDouble(fp.trim());
            if (mp != null) this.marginPct = Double.parseDouble(mp.trim());

            // Plain literal text entries — ignore.text.1, ignore.text.2, ...
            for (int n = 1; n <= 100; n++) {
                String val = props.getProperty("ignore.text." + n);
                if (val == null) break;
                this.customPatterns.add(Pattern.compile(Pattern.quote(val.trim())));
            }

            // Regex pattern entries — ignore.pattern.1, ignore.pattern.2, ...
            for (int n = 1; n <= 100; n++) {
                String val = props.getProperty("ignore.pattern." + n);
                if (val == null) break;
                this.customPatterns.add(Pattern.compile(val.trim()));
            }

            return this;
        }

        // ── Build ────────────────────────────────────────────────────────────

        /**
         * Build an immutable {@link FilterConfig}.
         *
         * @throws IllegalArgumentException if any required path is missing or blank
         */
        public FilterConfig build() {
            requireNonBlank(pdf1Path,   "pdf1 path must be provided");
            requireNonBlank(pdf2Path,   "pdf2 path must be provided");
            requireNonBlank(outputPath, "output path must be provided");
            return new FilterConfig(this);
        }

        private static void requireNonBlank(String value, String message) {
            if (value == null || value.trim().isEmpty()) {
                throw new IllegalArgumentException(message);
            }
        }
    }
}
