package com.doccompare;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Builds a self-contained HTML comparison report with two view modes:
 *
 * <ol>
 *   <li><b>Visual view</b> — both PDF pages rendered side-by-side as images,
 *       with coloured highlight boxes overlaid on differing text regions.
 *       This preserves the original PDF structure (tables, columns, formatting).</li>
 *   <li><b>Text diff view</b> — line-by-line text comparison with word-level
 *       highlighting, for detailed inspection of what exactly changed.</li>
 * </ol>
 *
 * <h2>Security guarantees</h2>
 * <ul>
 *   <li>No external URLs anywhere — all CSS, JS, and images are inline.</li>
 *   <li>Content Security Policy blocks any accidental external loads.</li>
 *   <li>All PDF-derived text is HTML-escaped before insertion.</li>
 * </ul>
 */
final class HtmlReportBuilder {

    private HtmlReportBuilder() {}

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Build the full HTML report.
     *
     * @param diff            computed diff rows
     * @param file1           actual PDF 1 file (used for page rendering)
     * @param file2           actual PDF 2 file (used for page rendering)
     * @param config          filter configuration
     * @param totalLinesLeft  line count after filtering, PDF 1
     * @param totalLinesRight line count after filtering, PDF 2
     * @param added           count of added lines
     * @param removed         count of removed lines
     * @param changed         count of changed lines
     * @param passed          true if no differences found
     * @return complete HTML string, self-contained
     */
    static String build(
            List<PDFComparator.DiffRow> diff,
            File file1, File file2,
            FilterConfig config,
            int totalLinesLeft, int totalLinesRight,
            int added, int removed, int changed,
            boolean passed) throws IOException {

        String ts      = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        int    same    = (int) diff.stream().filter(r -> r.type == PDFComparator.DiffType.SAME).count();
        int    total   = added + removed + changed;
        int    diffPct = totalLinesLeft > 0 ? (int) Math.round(total * 100.0 / totalLinesLeft) : 0;
        String verdict = passed ? "PASS" : "FAIL";

        // ── Render pages with highlights ───────────────────────────────────
        Map<Integer, List<PageRenderer.Highlight>> hi1 =
            PageRenderer.collectHighlights(file1, diff, config);
        Map<Integer, List<PageRenderer.Highlight>> hi2 =
            PageRenderer.collectHighlights(file2, diff, config);

        List<PageRenderer.RenderedPage> pages1 = PageRenderer.renderPages(file1, hi1, config);
        List<PageRenderer.RenderedPage> pages2 = PageRenderer.renderPages(file2, hi2, config);

        StringBuilder sb = new StringBuilder(1 << 20); // 1 MB initial capacity

        // ── HTML head ──────────────────────────────────────────────────────
        sb.append("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n")
          .append("<meta charset=\"UTF-8\">\n")
          .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n")
          .append("<meta http-equiv=\"Content-Security-Policy\" ")
          .append("content=\"default-src 'none'; style-src 'unsafe-inline'; ")
          .append("script-src 'unsafe-inline'; img-src 'self' data:;\">\n")
          .append("<title>[").append(verdict).append("] ")
          .append(PDFComparator.escHtml(file1.getName())).append(" vs ")
          .append(PDFComparator.escHtml(file2.getName())).append("</title>\n")
          .append("<style>\n").append(CSS).append("</style>\n")
          .append("</head>\n<body>\n");

        // ── Sticky header ──────────────────────────────────────────────────
        buildHeader(sb, file1.getName(), file2.getName(), ts, verdict, passed,
            totalLinesLeft, totalLinesRight, added, removed, changed, same, diffPct, config);

        // ── View toggle bar ────────────────────────────────────────────────
        sb.append("<div class=\"view-toggle\">\n")
          .append("  <button id=\"btn-visual\" class=\"vt-btn vt-active\" onclick=\"showView('visual')\">")
          .append("&#128444; Visual (page structure)</button>\n")
          .append("  <button id=\"btn-text\"   class=\"vt-btn\"           onclick=\"showView('text')\">")
          .append("&#9776; Text diff (line detail)</button>\n")
          .append("  <span class=\"vt-hint\">Visual view shows the PDF as-is with highlights. ")
          .append("Text view shows what changed word-by-word.</span>\n")
          .append("</div>\n");

        // ── Visual page view ───────────────────────────────────────────────
        sb.append("<div id=\"view-visual\" class=\"view-section\">\n");
        buildVisualView(sb, pages1, pages2, file1.getName(), file2.getName(), passed);
        sb.append("</div>\n");

        // ── Text diff view ─────────────────────────────────────────────────
        sb.append("<div id=\"view-text\" class=\"view-section\" style=\"display:none\">\n");
        buildTextDiffView(sb, diff, file1.getName(), file2.getName());
        sb.append("</div>\n");

        // ── Command footer ─────────────────────────────────────────────────
        sb.append("<div class=\"cmd-bar\">\n")
          .append("  <span class=\"cmd-lbl\">Command:</span>\n")
          .append("  <code class=\"cmd\">")
          .append(PDFComparator.escHtml(buildCommandHint(
              config, file1.getAbsolutePath(), file2.getAbsolutePath())))
          .append("</code>\n</div>\n");

        sb.append("<script>\n").append(JS).append("\n</script>\n");
        sb.append("</body>\n</html>\n");
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STICKY HEADER
    // ════════════════════════════════════════════════════════════════════════

    private static void buildHeader(StringBuilder sb,
            String f1, String f2, String ts, String verdict, boolean passed,
            int tL, int tR, int added, int removed, int changed, int same, int pct,
            FilterConfig config) {

        sb.append("<div class=\"topbar\">\n")
          .append("  <div class=\"tb-row1\">\n")
          .append("    <span class=\"verdict ").append(passed ? "v-pass" : "v-fail").append("\">")
          .append(passed ? "&#10003;&nbsp;PASS" : "&#10007;&nbsp;FAIL").append("</span>\n")
          .append("    <span class=\"tb-file tb-file-l\">")
          .append(PDFComparator.escHtml(f1)).append("</span>\n")
          .append("    <span class=\"tb-vs\">vs</span>\n")
          .append("    <span class=\"tb-file tb-file-r\">")
          .append(PDFComparator.escHtml(f2)).append("</span>\n")
          .append("    <span class=\"tb-ts\">").append(ts).append("</span>\n")
          .append("  </div>\n")
          .append("  <div class=\"stats-row\">\n");

        statChip(sb, "PDF\u00a01",  tL  + " lines", "");
        statChip(sb, "PDF\u00a02",  tR  + " lines", "");
        statChip(sb, "Added",   String.valueOf(added),   added   > 0 ? "s-fail" : "s-ok");
        statChip(sb, "Removed", String.valueOf(removed), removed > 0 ? "s-fail" : "s-ok");
        statChip(sb, "Changed", String.valueOf(changed), changed > 0 ? "s-warn" : "s-ok");
        statChip(sb, "Same",    String.valueOf(same),    "s-muted");
        statChip(sb, "Diff\u00a0%", pct + "%", total(added, removed, changed) > 0 ? "s-fail" : "s-ok");

        sb.append("  </div>\n")
          .append("  <div class=\"filter-row\">\n")
          .append("    <span class=\"fc-lbl\">Filters:</span>\n");
        buildFilterChips(sb, config);
        sb.append("  </div>\n")
          .append("  <div class=\"nav-row\" id=\"navRow\">\n")
          .append("    <button class=\"btn\" onclick=\"navDiff(-1)\">&#9650; Prev</button>\n")
          .append("    <span class=\"nav-pos\" id=\"navPos\"></span>\n")
          .append("    <button class=\"btn\" onclick=\"navDiff(1)\">Next &#9660;</button>\n")
          .append("    <button class=\"btn\" id=\"btnHide\" onclick=\"toggleSame()\">")
          .append("Hide unchanged</button>\n")
          .append("    <span class=\"kb\">Alt+&#8593;&#8595; to navigate</span>\n")
          .append("  </div>\n")
          .append("</div>\n");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  VISUAL PAGE VIEW
    // ════════════════════════════════════════════════════════════════════════

    private static void buildVisualView(StringBuilder sb,
            List<PageRenderer.RenderedPage> pages1,
            List<PageRenderer.RenderedPage> pages2,
            String f1, String f2) {

        int numPages = Math.max(pages1.size(), pages2.size());

        // Legend
        sb.append("<div class=\"vis-legend\">\n")
          .append("  <span class=\"vis-lbl\">Highlight key:</span>\n")
          .append("  <span class=\"vis-key vis-key-rem\">&#9646; Removed / only in PDF 1</span>\n")
          .append("  <span class=\"vis-key vis-key-add\">&#9646; Added / only in PDF 2</span>\n")
          .append("  <span class=\"vis-key vis-key-chg\">&#9646; Changed in both</span>\n")
          .append("</div>\n");

        // Column headers
        sb.append("<div class=\"vis-col-hdr\">\n")
          .append("  <div class=\"vis-hdr-l\">&#9664;&nbsp;").append(PDFComparator.escHtml(f1)).append("</div>\n")
          .append("  <div class=\"vis-hdr-r\">&#9654;&nbsp;").append(PDFComparator.escHtml(f2)).append("</div>\n")
          .append("</div>\n");

        for (int p = 0; p < numPages; p++) {
            sb.append("<div class=\"vis-page-row\" data-page=\"").append(p + 1).append("\">\n");
            sb.append("  <div class=\"vis-page-num\">Page ").append(p + 1).append("</div>\n");
            sb.append("  <div class=\"vis-cols\">\n");

            // Left page
            sb.append("    <div class=\"vis-col\">\n");
            if (p < pages1.size()) {
                PageRenderer.RenderedPage rp = pages1.get(p);
                sb.append("      <img class=\"vis-img\" ")
                  .append("src=\"data:image/png;base64,").append(rp.base64Png).append("\" ")
                  .append("width=\"").append(rp.widthPx).append("\" ")
                  .append("height=\"").append(rp.heightPx).append("\" ")
                  .append("alt=\"PDF 1 page ").append(p + 1).append("\">\n");
            } else {
                sb.append("      <div class=\"vis-no-page\">No page ").append(p + 1).append("</div>\n");
            }
            sb.append("    </div>\n");

            // Right page
            sb.append("    <div class=\"vis-col\">\n");
            if (p < pages2.size()) {
                PageRenderer.RenderedPage rp = pages2.get(p);
                sb.append("      <img class=\"vis-img\" ")
                  .append("src=\"data:image/png;base64,").append(rp.base64Png).append("\" ")
                  .append("width=\"").append(rp.widthPx).append("\" ")
                  .append("height=\"").append(rp.heightPx).append("\" ")
                  .append("alt=\"PDF 2 page ").append(p + 1).append("\">\n");
            } else {
                sb.append("      <div class=\"vis-no-page\">No page ").append(p + 1).append("</div>\n");
            }
            sb.append("    </div>\n");

            sb.append("  </div>\n</div>\n");
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TEXT DIFF VIEW
    // ════════════════════════════════════════════════════════════════════════

    private static void buildTextDiffView(StringBuilder sb,
            List<PDFComparator.DiffRow> diff, String f1, String f2) {

        sb.append("<div class=\"wrap\">\n")
          .append("<table class=\"tbl\">\n")
          .append("<colgroup>")
          .append("<col class=\"c-lno\"><col class=\"c-icon\"><col class=\"c-txt\">")
          .append("<col class=\"c-lno\"><col class=\"c-icon\"><col class=\"c-txt\">")
          .append("</colgroup>\n")
          .append("<thead><tr>")
          .append("<th colspan=\"3\" class=\"th th-l\">&#9664;&nbsp;")
          .append(PDFComparator.escHtml(f1)).append("</th>")
          .append("<th colspan=\"3\" class=\"th th-r\">&#9654;&nbsp;")
          .append(PDFComparator.escHtml(f2)).append("</th>")
          .append("</tr></thead>\n")
          .append("<tbody id=\"body\">\n");

        int di = 0;
        for (PDFComparator.DiffRow row : diff) {
            String cls, icon, iconCls;
            switch (row.type) {
                case ADDED:   cls = "r-add"; icon = "+";      iconCls = "i-add"; break;
                case REMOVED: cls = "r-rem"; icon = "\u2212"; iconCls = "i-rem"; break;
                case CHANGED: cls = "r-chg"; icon = "~";      iconCls = "i-chg"; break;
                default:      cls = "r-sme"; icon = "";       iconCls = "";       break;
            }
            boolean isDiff = row.type != PDFComparator.DiffType.SAME;
            sb.append("<tr class=\"").append(cls).append("\"");
            if (isDiff) sb.append(" id=\"d").append(di++).append("\"");
            sb.append(">");

            String leftHtml, rightHtml;
            if (row.type == PDFComparator.DiffType.CHANGED) {
                String[] wd = PDFComparator.wordDiff(row.left, row.right);
                leftHtml  = wd[0]; rightHtml = wd[1];
            } else {
                leftHtml  = PDFComparator.escHtml(row.left);
                rightHtml = PDFComparator.escHtml(row.right);
            }

            appendCell(sb, row.leftLineNo,  icon, iconCls, leftHtml,  row.type == PDFComparator.DiffType.ADDED);
            appendCell(sb, row.rightLineNo, icon, iconCls, rightHtml, row.type == PDFComparator.DiffType.REMOVED);
            sb.append("</tr>\n");
        }
        sb.append("</tbody>\n</table>\n</div>\n");
    }

    private static void appendCell(StringBuilder sb, int lineNo, String icon,
                                    String iconCls, String html, boolean empty) {
        sb.append("<td class=\"lno\">").append(lineNo > 0 ? lineNo : "").append("</td>")
          .append("<td class=\"icon ").append(iconCls).append("\">").append(icon).append("</td>")
          .append("<td class=\"code\">")
          .append(empty ? "<span class=\"empty\">(empty)</span>" : html)
          .append("</td>");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private static int total(int a, int b, int c) { return a + b + c; }

    private static void statChip(StringBuilder sb, String label, String value, String cls) {
        sb.append("    <div class=\"sc ").append(cls).append("\">")
          .append("<span class=\"sc-l\">").append(label).append("</span>")
          .append("<span class=\"sc-v\">").append(value).append("</span>")
          .append("</div>\n");
    }

    private static void buildFilterChips(StringBuilder sb, FilterConfig config) {
        List<String[]> chips = new ArrayList<>();
        if (config.isIgnoreHeader())
            chips.add(new String[]{"&#8679; header " + (int)config.getHeaderPct() + "%", "fc-zone"});
        if (config.isIgnoreFooter())
            chips.add(new String[]{"&#8681; footer " + (int)config.getFooterPct() + "%", "fc-zone"});
        if (config.isIgnoreLeftMargin())
            chips.add(new String[]{"&#8678; left " + (int)config.getMarginPct() + "%", "fc-zone"});
        if (config.isIgnoreRightMargin())
            chips.add(new String[]{"&#8680; right " + (int)config.getMarginPct() + "%", "fc-zone"});
        if (config.isIgnoreTimestamps())
            chips.add(new String[]{"timestamps", "fc-content"});
        if (config.isIgnorePageNumbers())
            chips.add(new String[]{"page-numbers", "fc-content"});
        for (java.util.regex.Pattern p : config.getCustomPatterns())
            chips.add(new String[]{"/ " + PDFComparator.escHtml(p.pattern()), "fc-custom"});

        if (chips.isEmpty()) {
            sb.append("    <span class=\"fc fc-none\">none &mdash; full content compared</span>\n");
        } else {
            for (String[] chip : chips)
                sb.append("    <span class=\"fc ").append(chip[1]).append("\">")
                  .append(chip[0]).append("</span>\n");
        }
    }

    private static String buildCommandHint(FilterConfig config, String p1, String p2) {
        StringBuilder sb = new StringBuilder("java -jar doc-compare.jar ")
            .append(p1).append(" ").append(p2).append(" ").append(config.getOutputPath());
        if (config.isIgnoreHeader())       sb.append(" --ignore-header");
        if (config.getHeaderPct() != 10.0) sb.append(" --header-pct=").append((int)config.getHeaderPct());
        if (config.isIgnoreFooter())       sb.append(" --ignore-footer");
        if (config.getFooterPct() != 10.0) sb.append(" --footer-pct=").append((int)config.getFooterPct());
        if (config.isIgnoreLeftMargin() && config.isIgnoreRightMargin()) sb.append(" --ignore-margins");
        else {
            if (config.isIgnoreLeftMargin())  sb.append(" --ignore-left-margin");
            if (config.isIgnoreRightMargin()) sb.append(" --ignore-right-margin");
        }
        if (config.getMarginPct() != 8.0)  sb.append(" --margin-pct=").append((int)config.getMarginPct());
        if (config.isIgnoreTimestamps())   sb.append(" --ignore-timestamps");
        if (config.isIgnorePageNumbers())  sb.append(" --ignore-page-numbers");
        for (java.util.regex.Pattern p : config.getCustomPatterns())
            sb.append(" --ignore-pattern=").append(p.pattern());
        return sb.toString();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CSS — zero external references
    // ════════════════════════════════════════════════════════════════════════

    private static final String CSS =
        ":root{--add:#c8e6c9;--rem:#ffcdd2;--chl:#fff3e0;--chr:#f1f8e9;--sme:#fafafa;" +
        "--bdr:#e0e0e0;--ba:#43a047;--br:#e53935;--bc:#fb8c00;--lno:#b0bec5;}\n" +
        "*{box-sizing:border-box;margin:0;padding:0;}\n" +
        "body{font-family:'Segoe UI',Arial,sans-serif;font-size:13px;background:#f4f4f4;color:#212121;}\n" +
        /* topbar */
        ".topbar{position:sticky;top:0;z-index:100;background:#263238;color:#fff;" +
        "padding:8px 16px 5px;box-shadow:0 2px 8px rgba(0,0,0,.45);}\n" +
        ".tb-row1{display:flex;align-items:center;gap:10px;margin-bottom:5px;flex-wrap:wrap;}\n" +
        ".verdict{font-size:14px;font-weight:700;padding:2px 12px;border-radius:4px;white-space:nowrap;flex-shrink:0;}\n" +
        ".v-pass{background:#1b5e20;color:#c8e6c9;}.v-fail{background:#b71c1c;color:#ffcdd2;}\n" +
        ".tb-file{font-size:12px;font-weight:500;max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}\n" +
        ".tb-file-l{color:#80cbc4;}.tb-file-r{color:#a5d6a7;}\n" +
        ".tb-vs{font-size:11px;color:#546e7a;}\n" +
        ".tb-ts{font-size:11px;color:#546e7a;margin-left:auto;white-space:nowrap;}\n" +
        /* stats */
        ".stats-row{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:5px;}\n" +
        ".sc{background:rgba(255,255,255,.1);border-radius:4px;padding:2px 9px;" +
        "display:flex;flex-direction:column;align-items:center;min-width:55px;}\n" +
        ".sc-l{font-size:9px;color:#90a4ae;text-transform:uppercase;letter-spacing:.4px;}\n" +
        ".sc-v{font-size:15px;font-weight:600;color:#fff;line-height:1.2;}\n" +
        ".s-fail .sc-v{color:#ef9a9a;}.s-warn .sc-v{color:#ffcc80;}"+
        ".s-ok .sc-v{color:#a5d6a7;}.s-muted .sc-v{color:#78909c;}\n" +
        /* filter chips */
        ".filter-row{display:flex;align-items:center;gap:4px;flex-wrap:wrap;margin-bottom:5px;}\n" +
        ".fc-lbl{font-size:10px;color:#78909c;}\n" +
        ".fc{display:inline-block;border-radius:9px;padding:1px 8px;font-size:10px;font-weight:500;}\n" +
        ".fc-zone{background:#1a237e;color:#c5cae9;}.fc-content{background:#e65100;color:#ffe0b2;}\n" +
        ".fc-custom{background:#4a148c;color:#e1bee7;}.fc-none{background:#37474f;color:#90a4ae;}\n" +
        /* nav */
        ".nav-row{display:flex;align-items:center;gap:6px;flex-wrap:wrap;}\n" +
        ".btn{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);" +
        "color:#fff;padding:3px 11px;border-radius:4px;cursor:pointer;font-size:12px;}\n" +
        ".btn:hover{background:rgba(255,255,255,.22);}.btn.on{background:#e65100;border-color:#bf360c;}\n" +
        ".nav-pos{font-size:12px;color:#90a4ae;min-width:52px;text-align:center;}\n" +
        ".kb{font-size:10px;color:#546e7a;margin-left:4px;}\n" +
        /* view toggle */
        ".view-toggle{background:#fff;border-bottom:1px solid var(--bdr);" +
        "padding:8px 16px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;}\n" +
        ".vt-btn{background:#f5f5f5;border:1px solid #bdbdbd;color:#424242;" +
        "padding:5px 16px;border-radius:4px;cursor:pointer;font-size:12px;font-weight:500;}\n" +
        ".vt-btn:hover{background:#e0e0e0;}\n" +
        ".vt-active{background:#1565c0;color:#fff;border-color:#1565c0;}\n" +
        ".vt-active:hover{background:#0d47a1;}\n" +
        ".vt-hint{font-size:11px;color:#9e9e9e;margin-left:8px;}\n" +
        /* visual view */
        ".vis-legend{padding:8px 16px;background:#fff;border-bottom:1px solid var(--bdr);" +
        "display:flex;align-items:center;gap:12px;flex-wrap:wrap;}\n" +
        ".vis-lbl{font-size:11px;color:#757575;font-weight:500;}\n" +
        ".vis-key{font-size:11px;padding:2px 8px;border-radius:3px;}\n" +
        ".vis-key-rem{background:#ffcdd2;color:#b71c1c;}\n" +
        ".vis-key-add{background:#c8e6c9;color:#1b5e20;}\n" +
        ".vis-key-chg{background:#ffe0b2;color:#e65c00;}\n" +
        ".vis-col-hdr{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:6px 16px;" +
        "background:#37474f;}\n" +
        ".vis-hdr-l,.vis-hdr-r{font-size:12px;font-weight:600;color:#fff;" +
        "padding:4px 8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}\n" +
        ".vis-hdr-r{border-left:2px solid #546e7a;}\n" +
        ".vis-page-row{padding:8px 16px 0;}\n" +
        ".vis-page-num{font-size:11px;color:#9e9e9e;margin-bottom:4px;padding-left:4px;}\n" +
        ".vis-cols{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;}\n" +
        ".vis-col{background:#fff;border:1px solid var(--bdr);border-radius:4px;" +
        "overflow:hidden;min-height:100px;}\n" +
        ".vis-img{width:100%;height:auto;display:block;}\n" +
        ".vis-no-page{padding:40px;text-align:center;color:#bdbdbd;font-style:italic;}\n" +
        /* text diff */
        ".wrap{overflow-x:auto;}\n" +
        ".tbl{width:100%;border-collapse:collapse;table-layout:fixed;min-width:680px;}\n" +
        ".c-lno{width:40px;}.c-icon{width:18px;}.c-txt{width:calc(50% - 58px - 9px);}\n" +
        ".th{padding:7px 12px;font-size:12px;font-weight:600;color:#fff;" +
        "position:sticky;top:0;z-index:5;border-bottom:2px solid rgba(255,255,255,.15);}\n" +
        ".th-l{background:#37474f;}.th-r{background:#263238;border-left:3px solid #455a64;}\n" +
        "tbody tr td{border-bottom:1px solid var(--bdr);vertical-align:top;padding:1px 0;}\n" +
        ".lno{font-family:monospace;font-size:10px;color:var(--lno);text-align:right;" +
        "padding:2px 4px 2px 2px;user-select:none;white-space:nowrap;}\n" +
        ".icon{font-family:monospace;font-size:11px;font-weight:700;text-align:center;" +
        "padding:0 1px;user-select:none;width:18px;}\n" +
        ".i-add{color:#2e7d32;}.i-rem{color:#c62828;}.i-chg{color:#e65c00;}\n" +
        ".code{font-family:Consolas,'Courier New',monospace;font-size:11.5px;" +
        "padding:2px 7px;word-break:break-all;white-space:pre-wrap;}\n" +
        ".empty{color:#bdbdbd;font-style:italic;font-size:10px;}\n" +
        ".r-sme td{background:var(--sme);}.r-sme.h{display:none;}\n" +
        ".r-add td:nth-child(-n+3){background:#fafafa;}\n" +
        ".r-add td:nth-child(n+4){background:var(--add);}\n" +
        ".r-add td:nth-child(4){border-left:3px solid var(--ba);}\n" +
        ".r-rem td:nth-child(-n+3){background:var(--rem);}\n" +
        ".r-rem td:nth-child(1){border-left:3px solid var(--br);}\n" +
        ".r-rem td:nth-child(n+4){background:#fafafa;}\n" +
        ".r-chg td:nth-child(-n+3){background:var(--chl);}\n" +
        ".r-chg td:nth-child(1){border-left:3px solid var(--bc);}\n" +
        ".r-chg td:nth-child(n+4){background:var(--chr);}\n" +
        ".r-chg td:nth-child(4){border-left:3px solid var(--bc);}\n" +
        "mark{background:#ffe082;color:#5d4037;border-radius:2px;padding:0 1px;}\n" +
        ".r-add mark{background:#a5d6a7;color:#1b5e20;}\n" +
        ".r-rem mark{background:#ef9a9a;color:#7f0000;}\n" +
        ".hl{outline:2px solid #ff6f00;outline-offset:-1px;}\n" +
        /* command footer */
        ".cmd-bar{background:#fff;border-top:1px solid var(--bdr);padding:8px 14px;" +
        "display:flex;align-items:flex-start;gap:8px;}\n" +
        ".cmd-lbl{font-size:11px;color:#9e9e9e;white-space:nowrap;padding-top:2px;}\n" +
        ".cmd{font-family:monospace;font-size:11px;color:#424242;background:#f5f5f5;" +
        "padding:3px 7px;border-radius:3px;border:1px solid #e0e0e0;word-break:break-all;flex:1;}\n";

    // ════════════════════════════════════════════════════════════════════════
    //  JAVASCRIPT — view toggle + navigation, no network calls
    // ════════════════════════════════════════════════════════════════════════

    private static final String JS =
        "(function(){\n" +
        "  'use strict';\n" +
        // View toggle
        "  window.showView = function(v) {\n" +
        "    document.getElementById('view-visual').style.display = v==='visual' ? '' : 'none';\n" +
        "    document.getElementById('view-text').style.display   = v==='text'   ? '' : 'none';\n" +
        "    document.getElementById('btn-visual').className = 'vt-btn' + (v==='visual' ? ' vt-active' : '');\n" +
        "    document.getElementById('btn-text').className   = 'vt-btn' + (v==='text'   ? ' vt-active' : '');\n" +
        // Nav row only relevant in text view
        "    document.getElementById('navRow').style.display = v==='text' ? '' : 'none';\n" +
        "  };\n" +
        // Text diff navigation
        "  var diffs = Array.from(document.querySelectorAll('#body tr[id]'));\n" +
        "  var cur = -1;\n" +
        "  var sameVisible = true;\n" +
        "  var navPos = document.getElementById('navPos');\n" +
        "  function updateNav() {\n" +
        "    if (navPos) navPos.textContent = diffs.length === 0\n" +
        "      ? 'no diffs' : (cur + 1) + ' / ' + diffs.length;\n" +
        "  }\n" +
        "  updateNav();\n" +
        "  window.navDiff = function(dir) {\n" +
        "    if (!diffs.length) return;\n" +
        "    showView('text');\n" +
        "    if (cur >= 0) diffs[cur].classList.remove('hl');\n" +
        "    cur = (cur + dir + diffs.length) % diffs.length;\n" +
        "    diffs[cur].classList.add('hl');\n" +
        "    diffs[cur].scrollIntoView({ behavior: 'smooth', block: 'center' });\n" +
        "    updateNav();\n" +
        "  };\n" +
        "  window.toggleSame = function() {\n" +
        "    sameVisible = !sameVisible;\n" +
        "    document.querySelectorAll('.r-sme').forEach(function(r) {\n" +
        "      r.classList.toggle('h', !sameVisible);\n" +
        "    });\n" +
        "    var btn = document.getElementById('btnHide');\n" +
        "    if (btn) { btn.textContent = sameVisible ? 'Hide unchanged' : 'Show unchanged';\n" +
        "    btn.classList.toggle('on', !sameVisible); }\n" +
        "  };\n" +
        "  document.addEventListener('keydown', function(e) {\n" +
        "    if (e.altKey && e.key === 'ArrowDown') { e.preventDefault(); navDiff(1);  }\n" +
        "    if (e.altKey && e.key === 'ArrowUp')   { e.preventDefault(); navDiff(-1); }\n" +
        "  });\n" +
        // Hide nav row initially (visual view is default)
        "  document.getElementById('navRow').style.display = 'none';\n" +
        "}());\n";
}
