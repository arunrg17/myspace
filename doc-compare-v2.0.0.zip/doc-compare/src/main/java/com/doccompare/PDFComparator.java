package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

/**
 * PDF Text Comparator — core engine.
 *
 * <h2>Programmatic usage (Selenium / JUnit)</h2>
 * <pre>
 *   FilterConfig config = new FilterConfig.Builder()
 *       .pdf1("path/to/baseline.pdf")
 *       .pdf2("path/to/actual.pdf")
 *       .output("path/to/report.html")
 *       .ignoreHeader(true)
 *       .ignoreFooter(true)
 *       .ignoreMargins(true)
 *       .ignoreTimestamps(true)
 *       .build();
 *
 *   CompareResult result = PDFComparator.compare(config);
 *
 *   Assert.assertTrue("PDF differences found: " + result.getReportPath(),
 *       result.isPassed());
 * </pre>
 *
 * <h2>Command-line usage (UFT / CI)</h2>
 * <pre>
 *   java -jar doc-compare.jar baseline.pdf actual.pdf report.html [options]
 *
 *   Exit codes:  0 = PASS,  1 = FAIL,  2 = ERROR
 * </pre>
 *
 * <h2>Security notes</h2>
 * <ul>
 *   <li>No network connections are made at any point.</li>
 *   <li>No external resources are referenced in the HTML output.</li>
 *   <li>Input paths are validated before any file is opened.</li>
 *   <li>HTML output is fully escaped — no user content is rendered unescaped.</li>
 *   <li>No reflection, no dynamic class loading, no shell execution.</li>
 *   <li>All regex patterns are compiled with standard java.util.regex — no script engines.</li>
 * </ul>
 */
public final class PDFComparator {

    // ── Exit codes (CLI mode) ────────────────────────────────────────────────
    public static final int EXIT_PASS  = 0;
    public static final int EXIT_FAIL  = 1;
    public static final int EXIT_ERROR = 2;

    private static final Logger LOG = Logger.getLogger(PDFComparator.class.getName());

    // Suppress PDFBox's verbose logging — not needed in automation environments
    static {
        Logger.getLogger("org.apache.pdfbox").setLevel(Level.SEVERE);
        Logger.getLogger("org.apache.fontbox").setLevel(Level.SEVERE);
    }

    /** Utility class — no instantiation. */
    private PDFComparator() {}

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC API  — used by Selenium / JUnit callers
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Run a full PDF comparison and write the HTML report.
     *
     * @param config fully built {@link FilterConfig}
     * @return {@link CompareResult} — never null; check {@link CompareResult#isPassed()}
     */
    public static CompareResult compare(FilterConfig config) {
        try {
            return doCompare(config);
        } catch (Exception ex) {
            LOG.severe("Comparison failed: " + ex.getMessage());
            return errorResult(ex.getMessage());
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CLI ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Main entry point for command-line / UFT usage.
     *
     * <p>Usage: {@code java -jar doc-compare.jar <pdf1> <pdf2> <output.html> [options]}
     */
    public static void main(String[] args) {
        System.exit(runCli(args));
    }

    /** Separated from main() so it can be unit-tested without calling System.exit. */
    static int runCli(String[] args) {
        if (args.length < 3) {
            printUsage();
            return EXIT_ERROR;
        }

        FilterConfig.Builder builder = new FilterConfig.Builder()
            .pdf1(args[0])
            .pdf2(args[1])
            .output(args[2]);

        for (int i = 3; i < args.length; i++) {
            String flag = args[i].trim();
            try {
                switch (flag) {
                    case "--ignore-header":        builder.ignoreHeader(true);       break;
                    case "--ignore-footer":        builder.ignoreFooter(true);       break;
                    case "--ignore-left-margin":   builder.ignoreLeftMargin(true);   break;
                    case "--ignore-right-margin":  builder.ignoreRightMargin(true);  break;
                    case "--ignore-margins":       builder.ignoreMargins(true);      break;
                    case "--ignore-timestamps":    builder.ignoreTimestamps(true);   break;
                    case "--ignore-page-numbers":  builder.ignorePageNumbers(true);  break;
                    default:
                        if (flag.startsWith("--header-pct="))
                            builder.headerPct(parsePercent(flag));
                        else if (flag.startsWith("--footer-pct="))
                            builder.footerPct(parsePercent(flag));
                        else if (flag.startsWith("--margin-pct="))
                            builder.marginPct(parsePercent(flag));
                        else if (flag.startsWith("--ignore-pattern="))
                            builder.ignorePattern(flag.substring("--ignore-pattern=".length()));
                        else if (flag.startsWith("--ignore-text="))
                            builder.ignoreText(flag.substring("--ignore-text=".length()));
                        else if (flag.startsWith("--ignore-config=")) {
                            try {
                                builder.ignoreConfig(flag.substring("--ignore-config=".length()));
                            } catch (java.io.IOException ex) {
                                System.err.println("[ERROR] Cannot read ignore config: " + ex.getMessage());
                                return EXIT_ERROR;
                            }
                        } else
                            System.err.println("[WARN] Unknown option ignored: " + flag);
                }
            } catch (IllegalArgumentException ex) {
                System.err.println("[ERROR] Invalid option '" + flag + "': " + ex.getMessage());
                return EXIT_ERROR;
            }
        }

        FilterConfig config;
        try {
            config = builder.build();
        } catch (IllegalArgumentException ex) {
            System.err.println("[ERROR] " + ex.getMessage());
            return EXIT_ERROR;
        }

        log("PDF Text Comparator v1.0.0");
        log("PDF 1  : " + config.getPdf1Path());
        log("PDF 2  : " + config.getPdf2Path());
        log("Output : " + config.getOutputPath());
        log("Filters: " + config.summary());
        log("");

        CompareResult result = compare(config);

        log("");
        log("Result  : " + result.getStatus());
        log("Same    : " + result.getSameLines());
        log("Added   : " + result.getAddedLines());
        log("Removed : " + result.getRemovedLines());
        log("Changed : " + result.getChangedLines());
        if (result.getReportPath() != null) log("Report  : " + result.getReportPath());
        if (result.getErrorMessage() != null) System.err.println("[ERROR] " + result.getErrorMessage());
        log("");

        switch (result.getStatus()) {
            case PASS:  return EXIT_PASS;
            case FAIL:  return EXIT_FAIL;
            default:    return EXIT_ERROR;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CORE COMPARISON LOGIC
    // ════════════════════════════════════════════════════════════════════════

    private static CompareResult doCompare(FilterConfig config) throws Exception {

        // Validate input files before opening anything.
        // IllegalArgumentException is intentionally re-thrown so runCli returns EXIT_ERROR.
        File file1, file2;
        try {
            file1 = validateInputFile(config.getPdf1Path());
            file2 = validateInputFile(config.getPdf2Path());
        } catch (IllegalArgumentException ex) {
            throw new IOException(ex.getMessage());
        }

        // Validate / prepare output path
        File outputFile = prepareOutputFile(config.getOutputPath());

        // Extract text with zone filtering applied at extraction time
        String[] lines1 = extractLines(file1, config);
        String[] lines2 = extractLines(file2, config);

        // Compute line-level diff
        List<DiffRow> diff = computeDiff(lines1, lines2);

        // Tally results
        int added   = 0, removed = 0, changed = 0, same = 0;
        for (DiffRow row : diff) {
            switch (row.type) {
                case ADDED:   added++;   break;
                case REMOVED: removed++; break;
                case CHANGED: changed++; break;
                default:      same++;    break;
            }
        }

        boolean passed = (added + removed + changed) == 0;

        // Write HTML report — includes rendered page images with highlights
        String html = HtmlReportBuilder.build(
            diff, file1, file2, config,
            lines1.length, lines2.length,
            added, removed, changed, passed);

        Files.write(outputFile.toPath(), html.getBytes(StandardCharsets.UTF_8));

        return new CompareResult(
            passed ? CompareResult.Status.PASS : CompareResult.Status.FAIL,
            added, removed, changed, same,
            lines1.length, lines2.length,
            outputFile.getAbsolutePath(), null);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  VALIDATION
    // ════════════════════════════════════════════════════════════════════════

    private static File validateInputFile(String path) throws IllegalArgumentException {
        if (path == null || path.trim().isEmpty())
            throw new IllegalArgumentException("File path must not be blank");

        File file = new File(path);
        if (!file.exists())
            throw new IllegalArgumentException("File not found: " + file.getAbsolutePath());
        if (!file.isFile())
            throw new IllegalArgumentException("Path is not a file: " + file.getAbsolutePath());
        if (!file.canRead())
            throw new IllegalArgumentException("File is not readable: " + file.getAbsolutePath());
        if (!file.getName().toLowerCase().endsWith(".pdf"))
            throw new IllegalArgumentException("Only PDF files are supported: " + file.getName());

        return file;
    }

    private static File prepareOutputFile(String path) throws IOException {
        String resolved = path.endsWith(".html") || path.endsWith(".htm")
            ? path : path + ".html";
        File file = new File(resolved);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            if (!parent.mkdirs())
                throw new IOException("Could not create output directory: " + parent.getAbsolutePath());
        }
        return file;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TEXT EXTRACTION  — zone-aware PDFBox stripper
    // ════════════════════════════════════════════════════════════════════════

    private static String[] extractLines(File file, FilterConfig config) throws Exception {
        String rawText;
        try (PDDocument doc = PDDocument.load(file)) {
            ZoneAwareStripper stripper = new ZoneAwareStripper(config);
            rawText = stripper.getText(doc);
        }

        List<String> lines = new ArrayList<>();
        for (String line : rawText.split("\n", -1)) {
            String processed = config.processLine(line);
            if (processed != null && !processed.isEmpty()) {
                lines.add(processed);
            }
        }
        return lines.toArray(new String[0]);
    }

    /**
     * Extends PDFTextStripper to skip text runs that fall within ignored page zones.
     * Zone checks use the raw PDF coordinate system (origin bottom-left).
     */
    private static final class ZoneAwareStripper extends PDFTextStripper {

        private final FilterConfig config;
        private float pageHeight;
        private float pageWidth;

        ZoneAwareStripper(FilterConfig config) throws IOException {
            super();
            this.config = config;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle box = page.getMediaBox();
            pageHeight = box.getHeight();
            pageWidth  = box.getWidth();
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions) throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }

            // Compute the average X/Y of this text run
            float sumX = 0f, sumY = 0f;
            for (TextPosition tp : positions) {
                sumX += tp.getX();
                sumY += tp.getY();
            }
            float avgX    = sumX / positions.size();
            float avgY    = sumY / positions.size();
            float yFromTop = pageHeight - avgY;  // convert to top-origin

            // Drop the run if it falls inside an ignored zone
            if (config.isIgnoreHeader() &&
                    yFromTop < pageHeight * (config.getHeaderPct() / 100.0)) return;

            if (config.isIgnoreFooter() &&
                    yFromTop > pageHeight * ((100.0 - config.getFooterPct()) / 100.0)) return;

            if (config.isIgnoreLeftMargin() &&
                    avgX < pageWidth * (config.getMarginPct() / 100.0)) return;

            if (config.isIgnoreRightMargin() &&
                    avgX > pageWidth * ((100.0 - config.getMarginPct()) / 100.0)) return;

            super.writeString(text, positions);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DIFF ALGORITHM — LCS (Longest Common Subsequence)
    // ════════════════════════════════════════════════════════════════════════

    enum DiffType { SAME, ADDED, REMOVED, CHANGED }

    static final class DiffRow {
        final DiffType type;
        final String   left;
        final String   right;
        final int      leftLineNo;
        final int      rightLineNo;

        DiffRow(DiffType type, String left, String right, int leftLineNo, int rightLineNo) {
            this.type        = type;
            this.left        = left;
            this.right       = right;
            this.leftLineNo  = leftLineNo;
            this.rightLineNo = rightLineNo;
        }
    }

    /**
     * Compute a line-level diff using the LCS algorithm.
     * Falls back to chunked processing for very large documents to avoid OOM.
     */
    static List<DiffRow> computeDiff(String[] a, String[] b) {
        int n = a.length, m = b.length;
        // Safety threshold: avoid O(n*m) table for very large inputs
        if ((long) n * m > 4_000_000L) {
            return chunkedDiff(a, b, 1500);
        }
        return lcsBacktrack(a, b, buildLcsTable(a, b));
    }

    private static int[][] buildLcsTable(String[] a, String[] b) {
        int n = a.length, m = b.length;
        int[][] dp = new int[n + 1][m + 1];
        for (int i = n - 1; i >= 0; i--) {
            for (int j = m - 1; j >= 0; j--) {
                dp[i][j] = normalise(a[i]).equals(normalise(b[j]))
                    ? dp[i + 1][j + 1] + 1
                    : Math.max(dp[i + 1][j], dp[i][j + 1]);
            }
        }
        return dp;
    }

    private static List<DiffRow> lcsBacktrack(String[] a, String[] b, int[][] dp) {
        List<DiffRow> result = new ArrayList<>();
        int i = 0, j = 0, la = 1, lb = 1;
        int n = a.length, m = b.length;

        while (i < n && j < m) {
            if (normalise(a[i]).equals(normalise(b[j]))) {
                result.add(new DiffRow(DiffType.SAME, a[i], b[j], la++, lb++));
                i++; j++;
            } else {
                // CHANGED: both sides diverge equally (substitution).
                // Detected when skipping either side costs the same LCS score,
                // and both lines have actual content.
                boolean isSubstitution = !normalise(a[i]).isEmpty()
                        && !normalise(b[j]).isEmpty()
                        && dp[i + 1][j] == dp[i][j + 1];

                if (isSubstitution) {
                    result.add(new DiffRow(DiffType.CHANGED, a[i], b[j], la++, lb++));
                    i++; j++;
                } else if (dp[i + 1][j] >= dp[i][j + 1]) {
                    result.add(new DiffRow(DiffType.REMOVED, a[i], "", la++, -1));
                    i++;
                } else {
                    result.add(new DiffRow(DiffType.ADDED, "", b[j], -1, lb++));
                    j++;
                }
            }
        }
        while (i < n) { result.add(new DiffRow(DiffType.REMOVED, a[i], "", la++, -1)); i++; }
        while (j < m) { result.add(new DiffRow(DiffType.ADDED,   "", b[j], -1, lb++)); j++; }
        return result;
    }

    /** Chunked diff for large documents: processes in overlapping windows. */
    private static List<DiffRow> chunkedDiff(String[] a, String[] b, int chunkSize) {
        List<DiffRow> result = new ArrayList<>();
        int la = 1, lb = 1;
        for (int ai = 0; ai < a.length || ai < b.length; ai += chunkSize) {
            String[] ca = Arrays.copyOfRange(a, ai, Math.min(ai + chunkSize, a.length));
            String[] cb = Arrays.copyOfRange(b, ai, Math.min(ai + chunkSize, b.length));
            List<DiffRow> chunk = computeDiff(ca, cb);
            for (DiffRow row : chunk) {
                int ln = row.leftLineNo  > 0 ? row.leftLineNo  + la - 1 : -1;
                int rn = row.rightLineNo > 0 ? row.rightLineNo + lb - 1 : -1;
                result.add(new DiffRow(row.type, row.left, row.right, ln, rn));
                if (row.leftLineNo  > 0) la++;
                if (row.rightLineNo > 0) lb++;
            }
        }
        return result;
    }

    private static String normalise(String s) {
        return s == null ? "" : s.trim();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  WORD-LEVEL DIFF  (used inside CHANGED rows for inline highlighting)
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Returns [markedLeft, markedRight] with HTML {@code <mark>} tags wrapping
     * words that differ between the two strings.
     */
    static String[] wordDiff(String left, String right) {
        String[] wa = left.split("\\b");
        String[] wb = right.split("\\b");
        int n = wa.length, m = wb.length;

        int[][] dp = new int[n + 1][m + 1];
        for (int i = n - 1; i >= 0; i--)
            for (int j = m - 1; j >= 0; j--)
                dp[i][j] = wa[i].equals(wb[j])
                    ? dp[i+1][j+1] + 1
                    : Math.max(dp[i+1][j], dp[i][j+1]);

        StringBuilder sl = new StringBuilder(), sr = new StringBuilder();
        int i = 0, j = 0;
        while (i < n && j < m) {
            if (wa[i].equals(wb[j])) {
                sl.append(escHtml(wa[i])); sr.append(escHtml(wb[j])); i++; j++;
            } else if (dp[i+1][j] >= dp[i][j+1]) {
                sl.append("<mark>").append(escHtml(wa[i])).append("</mark>"); i++;
            } else {
                sr.append("<mark>").append(escHtml(wb[j])).append("</mark>"); j++;
            }
        }
        while (i < n) sl.append("<mark>").append(escHtml(wa[i++])).append("</mark>");
        while (j < m) sr.append("<mark>").append(escHtml(wb[j++])).append("</mark>");
        return new String[]{ sl.toString(), sr.toString() };
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HTML ESCAPING  — all user content must pass through this
    // ════════════════════════════════════════════════════════════════════════

    static String escHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  ERROR RESULT FACTORY
    // ════════════════════════════════════════════════════════════════════════

    private static CompareResult errorResult(String message) {
        return new CompareResult(
            CompareResult.Status.ERROR,
            0, 0, 0, 0, 0, 0, null, message);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CLI HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private static double parsePercent(String flag) {
        String[] parts = flag.split("=", 2);
        if (parts.length < 2) throw new IllegalArgumentException("Missing value in: " + flag);
        double v = Double.parseDouble(parts[1]);
        if (v < 1 || v > 49) throw new IllegalArgumentException("Percentage must be 1–49: " + v);
        return v;
    }

    private static void log(String message) {
        System.out.println("  " + message);
    }

    private static void printUsage() {
        System.err.println("Usage: java -jar doc-compare.jar <pdf1> <pdf2> <output.html> [options]");
        System.err.println();
        System.err.println("Zone filters (exclude by position on page):");
        System.err.println("  --ignore-header              Top 10% of each page");
        System.err.println("  --ignore-footer              Bottom 10% of each page");
        System.err.println("  --ignore-left-margin         Left 8% (vertical timestamps, stamps)");
        System.err.println("  --ignore-right-margin        Right 8% (vertical watermarks)");
        System.err.println("  --ignore-margins             Both left and right margins");
        System.err.println("  --header-pct=<n>             Override header zone % (1-49)");
        System.err.println("  --footer-pct=<n>             Override footer zone % (1-49)");
        System.err.println("  --margin-pct=<n>             Override margin zone % (1-30)");
        System.err.println();
        System.err.println("Content filters:");
        System.err.println("  --ignore-timestamps          Strip date/time values from lines");
        System.err.println("  --ignore-page-numbers        Drop page-number-only lines");
        System.err.println("  --ignore-pattern=<regex>     Drop lines matching Java regex");
        System.err.println("  --ignore-text=<literal>      Drop lines containing exact text");
        System.err.println("  --ignore-config=<file>       Load all ignore settings from a .properties file");
        System.err.println();
        System.err.println("Properties file format (ignore.properties):");
        System.err.println("  ignore.header=true");
        System.err.println("  ignore.footer=true");
        System.err.println("  ignore.margins=true");
        System.err.println("  ignore.timestamps=true");
        System.err.println("  ignore.page.numbers=true");
        System.err.println("  ignore.text.1=Erstellt am");
        System.err.println("  ignore.text.2=COSREP");
        System.err.println("  ignore.pattern.1=Generated by.*");
        System.err.println();
        System.err.println("Exit codes:  0 = PASS   1 = FAIL   2 = ERROR");
    }
}
