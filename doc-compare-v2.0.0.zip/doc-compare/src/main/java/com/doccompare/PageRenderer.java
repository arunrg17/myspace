package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Renders PDF pages to base64-encoded PNG images and overlays
 * coloured highlight boxes over text regions that differ.
 *
 * <p>Used by {@link HtmlReportBuilder} when building the visual page view.
 * All rendering is done in-process using PDFBox — no external tools, no
 * network access, no temporary files written to disk.
 */
final class PageRenderer {

    /** DPI used for page rendering. 150 dpi gives crisp readable output at reasonable file size. */
    private static final float RENDER_DPI = 150f;

    /** Highlight colours — semi-transparent ARGB */
    private static final Color COLOR_ADDED   = new Color(0x60, 0xC8, 0x60, 90);   // green
    private static final Color COLOR_REMOVED = new Color(0xE5, 0x50, 0x50, 90);   // red
    private static final Color COLOR_CHANGED = new Color(0xFF, 0xA0, 0x00, 80);   // amber
    private static final Color BORDER_ADDED   = new Color(0x2E, 0x7D, 0x32, 200);
    private static final Color BORDER_REMOVED = new Color(0xC6, 0x28, 0x28, 200);
    private static final Color BORDER_CHANGED = new Color(0xE6, 0x5C, 0x00, 200);

    private PageRenderer() {}

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC DATA TYPES
    // ════════════════════════════════════════════════════════════════════════

    /** One rendered page — base64 PNG image plus its natural dimensions. */
    static final class RenderedPage {
        final int    pageIndex;       // 0-based
        final String base64Png;       // data URI payload (without the "data:image/png;base64," prefix)
        final int    widthPx;
        final int    heightPx;

        RenderedPage(int pageIndex, String base64Png, int widthPx, int heightPx) {
            this.pageIndex  = pageIndex;
            this.base64Png  = base64Png;
            this.widthPx    = widthPx;
            this.heightPx   = heightPx;
        }
    }

    /**
     * A highlight region to draw on a rendered page.
     * Coordinates are in PDF user-space units (points, Y-up from bottom-left).
     */
    static final class Highlight {
        final PDFComparator.DiffType type;
        final float x, y, width, height;   // PDF coordinates

        Highlight(PDFComparator.DiffType type, float x, float y, float width, float height) {
            this.type   = type;
            this.x      = x;
            this.y      = y;
            this.width  = width;
            this.height = height;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  MAIN RENDER METHOD
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Render all pages of a PDF to base64 PNG images, with diff highlights overlaid.
     *
     * @param pdfFile      the PDF to render
     * @param highlights   per-page highlight regions (keyed by 0-based page index)
     * @param filterConfig used to re-apply zone exclusions when collecting positions
     * @return list of rendered pages in page order
     */
    static List<RenderedPage> renderPages(File pdfFile,
                                          java.util.Map<Integer, List<Highlight>> highlights,
                                          FilterConfig filterConfig) throws IOException {
        List<RenderedPage> result = new ArrayList<>();

        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            int numPages = doc.getNumberOfPages();

            for (int p = 0; p < numPages; p++) {
                // Render page to buffered image at RENDER_DPI
                BufferedImage img = renderer.renderImageWithDPI(p, RENDER_DPI, ImageType.RGB);

                // Overlay highlights if any exist for this page
                List<Highlight> pageHighlights = highlights.getOrDefault(p, new ArrayList<>());
                if (!pageHighlights.isEmpty()) {
                    PDPage page = doc.getPage(p);
                    overlayHighlights(img, page, pageHighlights);
                }

                // Encode to base64 PNG
                String b64 = toBase64Png(img);
                result.add(new RenderedPage(p, b64, img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HIGHLIGHT COLLECTION
    //  Extracts the bounding box of each differing text run on each page.
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Collect highlight regions for all diff rows that have positional data.
     *
     * <p>We extract text positions again (same as during comparison) and match
     * the text content of each ADDED / REMOVED / CHANGED row to its bounding box
     * on the page.
     *
     * @return map from 0-based page index → list of highlights for that page
     */
    static java.util.Map<Integer, List<Highlight>> collectHighlights(
            File pdfFile,
            List<PDFComparator.DiffRow> diff,
            FilterConfig config) throws IOException {

        java.util.Map<Integer, List<Highlight>> result = new java.util.HashMap<>();

        // Build a set of line texts that changed, for quick lookup
        java.util.Set<String> diffTexts = new java.util.HashSet<>();
        java.util.Map<String, PDFComparator.DiffType> typeByText = new java.util.HashMap<>();
        for (PDFComparator.DiffRow row : diff) {
            if (row.type == PDFComparator.DiffType.SAME) continue;
            if (!row.left.trim().isEmpty()) {
                diffTexts.add(row.left.trim());
                typeByText.put(row.left.trim(), row.type);
            }
            if (!row.right.trim().isEmpty()) {
                // Right-side lines exist in the "actual" PDF — we highlight them there
                diffTexts.add(row.right.trim());
                typeByText.put(row.right.trim(), row.type);
            }
        }

        if (diffTexts.isEmpty()) return result;

        // Run position-collecting stripper
        PositionCollector collector = new PositionCollector(config, diffTexts, typeByText);
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            collector.getText(doc);
        }

        return collector.highlights;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  POSITION-COLLECTING STRIPPER
    // ════════════════════════════════════════════════════════════════════════

    /**
     * PDFTextStripper subclass that records the bounding box of each text run
     * whose content matches a known diff line.
     */
    private static final class PositionCollector extends PDFTextStripper {

        private final FilterConfig                                     config;
        private final java.util.Set<String>                            diffTexts;
        private final java.util.Map<String, PDFComparator.DiffType>    typeByText;
        final java.util.Map<Integer, List<Highlight>>                  highlights = new java.util.HashMap<>();

        private int   currentPage = 0;
        private float pageH       = 792f;  // default A4
        private float pageW       = 595f;

        PositionCollector(FilterConfig config,
                          java.util.Set<String> diffTexts,
                          java.util.Map<String, PDFComparator.DiffType> typeByText) throws IOException {
            super();
            this.config     = config;
            this.diffTexts  = diffTexts;
            this.typeByText = typeByText;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle box = page.getMediaBox();
            pageH = box.getHeight();
            pageW = box.getWidth();
            currentPage = getCurrentPageNo() - 1;  // 0-based
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions) throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }

            // Check zone exclusions — same logic as extraction
            float sumX = 0f, sumY = 0f;
            for (TextPosition tp : positions) { sumX += tp.getX(); sumY += tp.getY(); }
            float avgX    = sumX / positions.size();
            float avgY    = sumY / positions.size();
            float yFromTop = pageH - avgY;

            if (config.isIgnoreHeader()      && yFromTop < pageH * (config.getHeaderPct() / 100.0)) return;
            if (config.isIgnoreFooter()      && yFromTop > pageH * ((100.0 - config.getFooterPct()) / 100.0)) return;
            if (config.isIgnoreLeftMargin()  && avgX     < pageW * (config.getMarginPct() / 100.0)) return;
            if (config.isIgnoreRightMargin() && avgX     > pageW * ((100.0 - config.getMarginPct()) / 100.0)) return;

            // Check if this run (or a fragment of it) matches a known diff line
            String trimmed = text.trim();
            PDFComparator.DiffType matchType = findMatch(trimmed);
            if (matchType != null) {
                // Compute bounding box over all character positions in this run
                float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
                float maxX = Float.MIN_VALUE, maxY = Float.MIN_VALUE;
                for (TextPosition tp : positions) {
                    minX = Math.min(minX, tp.getX());
                    minY = Math.min(minY, tp.getY() - tp.getHeight());
                    maxX = Math.max(maxX, tp.getX() + tp.getWidth());
                    maxY = Math.max(maxY, tp.getY());
                }
                highlights.computeIfAbsent(currentPage, k -> new ArrayList<>())
                    .add(new Highlight(matchType, minX, minY, maxX - minX, maxY - minY));
            }

            super.writeString(text, positions);
        }

        private PDFComparator.DiffType findMatch(String text) {
            // Exact match first
            if (diffTexts.contains(text)) return typeByText.get(text);
            // Substring match — the run might be a word fragment of a diff line
            for (String diffText : diffTexts) {
                if (diffText.length() > 3 && text.length() > 3 && diffText.contains(text)) {
                    return typeByText.get(diffText);
                }
            }
            return null;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  HIGHLIGHT OVERLAY
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Draw semi-transparent highlight rectangles over the rendered page image.
     * PDF coordinates (points, Y-up) are converted to pixel coordinates (Y-down).
     */
    private static void overlayHighlights(BufferedImage img, PDPage page,
                                           List<Highlight> pageHighlights) {
        PDRectangle mediaBox = page.getMediaBox();
        float pdfW = mediaBox.getWidth();
        float pdfH = mediaBox.getHeight();
        float scaleX = (float) img.getWidth()  / pdfW;
        float scaleY = (float) img.getHeight() / pdfH;

        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        for (Highlight h : pageHighlights) {
            // Convert PDF Y-up to image Y-down
            float imgX = h.x * scaleX;
            float imgY = (pdfH - h.y - h.height) * scaleY;
            float imgW = Math.max(h.width  * scaleX, 20);
            float imgH = Math.max(h.height * scaleY, 10);

            Color fill, border;
            switch (h.type) {
                case ADDED:   fill = COLOR_ADDED;   border = BORDER_ADDED;   break;
                case REMOVED: fill = COLOR_REMOVED; border = BORDER_REMOVED; break;
                case CHANGED: fill = COLOR_CHANGED; border = BORDER_CHANGED; break;
                default:      continue;
            }

            // Fill
            g.setColor(fill);
            g.fillRect(Math.round(imgX), Math.round(imgY),
                       Math.round(imgW), Math.round(imgH));
            // Border
            g.setColor(border);
            g.setStroke(new BasicStroke(1.5f));
            g.drawRect(Math.round(imgX), Math.round(imgY),
                       Math.round(imgW), Math.round(imgH));
        }
        g.dispose();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BASE64 ENCODE
    // ════════════════════════════════════════════════════════════════════════

    private static String toBase64Png(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }
}
