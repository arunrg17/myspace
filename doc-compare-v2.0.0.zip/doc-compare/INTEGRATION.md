# Integration Guide

---

## 1. UFT (VBScript)

### One-time setup

1. Copy `doc-compare.jar` to a shared path, e.g. `C:\Tools\doc-compare.jar`
2. Ensure Java 11+ is on the machine's PATH:
   ```
   java -version
   ```

### VBScript helper function

Add this to your UFT shared function library or directly in your action:

```vbscript
' ──────────────────────────────────────────────────────────────────────────
' ComparePDFs
'   pdf1    : full path to baseline PDF
'   pdf2    : full path to actual/generated PDF
'   report  : full path where the HTML report will be saved
'   flags   : optional extra CLI flags (e.g. "--ignore-header --ignore-footer")
'
' Returns : 0 = PASS, 1 = FAIL, 2 = ERROR
' ──────────────────────────────────────────────────────────────────────────
Function ComparePDFs(pdf1, pdf2, report, flags)
    Dim jarPath, cmd, oShell, exitCode

    jarPath = "C:\Tools\doc-compare.jar"

    cmd = "java -jar """ & jarPath & """ " & _
          """" & pdf1   & """ " & _
          """" & pdf2   & """ " & _
          """" & report & """"

    If Len(Trim(flags)) > 0 Then
        cmd = cmd & " " & Trim(flags)
    End If

    Set oShell = CreateObject("WScript.Shell")
    ' 0  = hidden window
    ' True = wait for process to finish before continuing
    exitCode = oShell.Run(cmd, 0, True)
    Set oShell = Nothing

    ComparePDFs = exitCode
End Function
```

### Usage in a UFT test action

```vbscript
Dim pdf1, pdf2, report, flags, result

' Paths — adjust to match your environment
pdf1   = "C:\Results\env1_statement.pdf"
pdf2   = "C:\Results\env2_statement.pdf"
report = "C:\Results\comparison_" & Now() & ".html"
flags  = "--ignore-header --ignore-footer --ignore-margins --ignore-timestamps"

result = ComparePDFs(pdf1, pdf2, report, flags)

Select Case result
    Case 0
        Reporter.ReportEvent micPass, "PDF Comparison", _
            "PDFs match. Report: " & report

    Case 1
        Reporter.ReportEvent micFail, "PDF Comparison", _
            "Differences found. Report: " & report

    Case Else
        Reporter.ReportEvent micFail, "PDF Comparison", _
            "Comparison error (exit " & result & "). Check console output."
End Select
```

---

## 2. Selenium — Java

### Option A: Call JAR programmatically (no shell, recommended)

Add the JAR to your project's classpath (Maven or Gradle), then call the API directly from your test:

**Maven — add to your test project's pom.xml:**
```xml
<dependency>
    <groupId>com.doccompare</groupId>
    <artifactId>doc-compare</artifactId>
    <version>1.0.0</version>
    <scope>system</scope>
    <systemPath>${project.basedir}/lib/doc-compare.jar</systemPath>
</dependency>
```

**JUnit 4 test example:**
```java
import com.doccompare.CompareResult;
import com.doccompare.FilterConfig;
import com.doccompare.PDFComparator;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class StatementCompareTest {

    @Test
    public void monthlyStatementShouldMatchBaseline() {

        FilterConfig config = new FilterConfig.Builder()
            .pdf1("src/test/resources/baseline/statement_jan.pdf")
            .pdf2("target/test-output/actual/statement_jan.pdf")
            .output("target/test-output/reports/statement_jan_diff.html")
            .ignoreHeader(true)        // skip letterhead
            .ignoreFooter(true)        // skip page numbers / print dates
            .ignoreMargins(true)       // skip vertical border timestamps
            .ignoreTimestamps(true)    // strip inline date/time values
            .ignorePageNumbers(true)   // drop bare page number lines
            .build();

        CompareResult result = PDFComparator.compare(config);

        assertTrue(
            "PDF differences found (" + result.getTotalDiffs() + " diffs). "
                + "Report: " + result.getReportPath(),
            result.isPassed()
        );
    }
}
```

**TestNG example:**
```java
import com.doccompare.CompareResult;
import com.doccompare.FilterConfig;
import com.doccompare.PDFComparator;
import org.testng.Assert;
import org.testng.annotations.Test;

public class StatementCompareTestNG {

    @Test(description = "Compare generated PDF against baseline")
    public void compareStatement() {

        FilterConfig config = new FilterConfig.Builder()
            .pdf1("src/test/resources/baseline/report.pdf")
            .pdf2("target/output/actual/report.pdf")
            .output("target/output/reports/report_diff.html")
            .ignoreHeader(true)
            .ignoreFooter(true)
            .ignoreMargins(true)
            .ignoreTimestamps(true)
            .build();

        CompareResult result = PDFComparator.compare(config);

        Assert.assertTrue(
            result.isPassed(),
            "PDF diff found. Added=" + result.getAddedLines()
                + " Removed=" + result.getRemovedLines()
                + " Changed=" + result.getChangedLines()
                + ". Report: " + result.getReportPath()
        );
    }
}
```

---

### Option B: Shell out to JAR (if you cannot add it to classpath)

```java
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import java.io.IOException;

public class PDFShellCompareTest {

    @Test
    public void compareViaCLI() throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder(
            "java", "-jar", "lib/doc-compare.jar",
            "baseline.pdf",
            "actual.pdf",
            "report.html",
            "--ignore-header",
            "--ignore-footer",
            "--ignore-margins",
            "--ignore-timestamps"
        );
        pb.inheritIO();  // pipe stdout/stderr to test console
        Process proc = pb.start();
        int exitCode = proc.waitFor();

        assertEquals("PDF comparison failed — see report.html", 0, exitCode);
    }
}
```

---

## 3. Selenium — Python

```python
import subprocess
import os
import pytest

JAR = r"C:\Tools\doc-compare.jar"


def compare_pdfs(pdf1: str, pdf2: str, report: str, flags: list[str] = None) -> int:
    """
    Run PDF comparison. Returns 0=PASS, 1=FAIL, 2=ERROR.
    """
    cmd = ["java", "-jar", JAR, pdf1, pdf2, report]
    if flags:
        cmd.extend(flags)
    result = subprocess.run(cmd, capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print(result.stderr)
    return result.returncode


class TestStatementPDF:

    def test_monthly_statement_matches_baseline(self):
        pdf1   = r"C:\Results\baseline\statement_jan.pdf"
        pdf2   = r"C:\Results\actual\statement_jan.pdf"
        report = r"C:\Results\reports\statement_jan_diff.html"
        flags  = [
            "--ignore-header",
            "--ignore-footer",
            "--ignore-margins",
            "--ignore-timestamps",
            "--ignore-page-numbers",
        ]

        exit_code = compare_pdfs(pdf1, pdf2, report, flags)

        assert exit_code == 0, (
            f"PDF differences found. Open report: {report}"
        )
```

---

## 4. Typical filter settings for bank documents

| Document type | Recommended flags |
|---------------|-------------------|
| Account statement | `--ignore-header --ignore-footer --ignore-margins --ignore-timestamps --ignore-page-numbers` |
| Trade confirmation | `--ignore-header --ignore-footer --ignore-margins --ignore-timestamps` |
| Contract / agreement | `--ignore-header --ignore-footer --ignore-timestamps` |
| Report with vertical watermark | `--ignore-margins --margin-pct=12` |
| Document with wide header band | `--ignore-header --header-pct=15` |

---

## 5. Output report — what the end user sees

The HTML report is self-contained (open in any browser, no internet required):

- **PASS / FAIL** verdict in the top-left corner
- Side-by-side diff table — left = PDF 1, right = PDF 2
- Colour coding: 🟩 Added (green) | 🟥 Removed (red) | 🟨 Changed (amber)
- Word-level highlighting on changed lines
- Prev / Next diff navigation buttons
- "Hide unchanged" toggle to focus only on differences
- Active filter chips showing exactly what was excluded
- Command used — for traceability in audit trails

---

## 6. Directory structure recommendation

```
project/
├── lib/
│   └── doc-compare.jar
├── src/test/
│   ├── resources/baseline/     ← checked-in baseline PDFs
│   └── java/.../PDFCompareTest.java
└── target/
    ├── test-output/actual/     ← PDFs generated during the test run
    └── test-output/reports/    ← HTML diff reports (attach to test results)
```
