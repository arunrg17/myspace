package com.doccompare;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.List;

/**
 * Renders PDF pages as images and overlays precise highlight boxes
 * on lines that the diff identified as different.
 *
 * <h2>Core approach — position-based, not text-matching</h2>
 *
 * Previous versions tried to highlight by matching text strings from the diff
 * against text runs in the PDF. This caused false positives because common
 * phrases appear in many lines and a substring of a diff line would match
 * identical (SAME) lines too.
 *
 * This version works differently:
 * <ol>
 *   <li>Re-extract lines from the PDF using the same ZoneAwareStripper used
 *       during comparison, collecting the Y-coordinate of each line.</li>
 *   <li>Cross-reference the diff result by LINE NUMBER to find which
 *       extracted lines need highlighting.</li>
 *   <li>Use the stored Y-coordinate of each matching line to draw a highlight
 *       bar at the correct position on the rendered page image.</li>
 * </ol>
 *
 * <p>Because matching is done by line number (not text content), a line is
 * highlighted if and only if it was classified as ADDED/REMOVED/CHANGED in
 * the diff. SAME lines — no matter how similar their text is to a diff line
 * — are never highlighted.
 *
 * <p>Text in ignored zones (header, footer, margins) is excluded at step 1
 * using the same FilterConfig, so it never appears in the extracted line list
 * and therefore never gets a highlight.
 */
final class PageRenderer {

    /** Render resolution. 150 DPI gives clear readable output at reasonable file size. */
    private static final float DPI = 150f;

    /** Points-per-inch constant (PDF user space). */
    private static final float PT_PER_INCH = 72f;

    /** Scale factor from PDF points to pixels at our DPI. */
    private static final float SCALE = DPI / PT_PER_INCH;

    // Highlight colours — semi-transparent fills, solid borders
    private static final Color FILL_REMOVED = new Color(220,  50,  50,  60);
    private static final Color FILL_ADDED   = new Color( 50, 160,  50,  60);
    private static final Color FILL_CHANGED = new Color(240, 130,   0,  60);
    private static final Color LINE_REMOVED = new Color(180,  20,  20, 200);
    private static final Color LINE_ADDED   = new Color( 20, 140,  20, 200);
    private static final Color LINE_CHANGED = new Color(200,  90,   0, 200);

    private PageRenderer() {}

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC DATA TYPES
    // ════════════════════════════════════════════════════════════════════════

    /** A rendered PDF page encoded as a base64 PNG string. */
    static final class RenderedPage {
        final int    pageIndex;
        final String base64Png;
        final int    widthPx;
        final int    heightPx;

        RenderedPage(int idx, String b64, int w, int h) {
            pageIndex = idx; base64Png = b64; widthPx = w; heightPx = h;
        }
    }

    /**
     * One extracted line with its page position.
     * Y is in PDF user-space (points, origin bottom-left, increases upward).
     */
    private static final class ExtractedLine {
        final int   lineNumber;   // 1-based, matches DiffRow.leftLineNo / rightLineNo
        final int   pageIndex;    // 0-based
        final float yBaseline;    // PDF Y coordinate of the text baseline
        final float yTop;         // PDF Y of the top of the line (baseline + ascent)
        final float xLeft;        // PDF X of leftmost character
        final float xRight;       // PDF X of rightmost character edge
        final float pageH;        // total page height (needed for coordinate conversion)
        final float pageW;        // total page width

        ExtractedLine(int ln, int pg, float yBase, float yTop,
                      float xL, float xR, float pH, float pW) {
            lineNumber = ln; pageIndex = pg;
            yBaseline  = yBase; this.yTop = yTop;
            xLeft      = xL;    xRight    = xR;
            pageH = pH; pageW = pW;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PUBLIC ENTRY POINT
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Render all pages of a PDF with highlights on differing lines.
     *
     * @param pdfFile  the PDF file to render
     * @param side     "left" (PDF 1) or "right" (PDF 2)
     * @param diff     full diff result from PDFComparator.computeDiff
     * @param config   filter config — zone exclusions are re-applied here
     */
    static List<RenderedPage> render(File pdfFile,
                                      String side,
                                      List<PDFComparator.DiffRow> diff,
                                      FilterConfig config) throws IOException {

        // Step 1: extract lines WITH their page positions, applying zone filters
        List<ExtractedLine> extractedLines = extractLinesWithPositions(pdfFile, config);

        // Step 2: build a map of {lineNumber → DiffType} for the relevant side
        Map<Integer, PDFComparator.DiffType> highlightByLineNo = buildLineHighlightMap(diff, side);

        // Step 3: for each extracted line whose number is in the highlight map,
        //         record a highlight region keyed by page index
        Map<Integer, List<ExtractedLine>> toHighlight = new HashMap<>();
        for (ExtractedLine el : extractedLines) {
            PDFComparator.DiffType type = highlightByLineNo.get(el.lineNumber);
            if (type != null) {
                toHighlight.computeIfAbsent(el.pageIndex, k -> new ArrayList<>())
                    .add(el);
            }
        }

        // Step 4: render pages and overlay highlights
        List<RenderedPage> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PDFRenderer renderer = new PDFRenderer(doc);
            for (int p = 0; p < doc.getNumberOfPages(); p++) {
                BufferedImage img = renderer.renderImageWithDPI(p, DPI, ImageType.RGB);
                List<ExtractedLine> pageLines = toHighlight.getOrDefault(p, Collections.emptyList());
                if (!pageLines.isEmpty()) {
                    PDFComparator.DiffType[] types = new PDFComparator.DiffType[pageLines.size()];
                    for (int k = 0; k < pageLines.size(); k++) {
                        types[k] = highlightByLineNo.get(pageLines.get(k).lineNumber);
                    }
                    drawHighlights(img, pageLines, types);
                }
                result.add(new RenderedPage(p, toPng(img), img.getWidth(), img.getHeight()));
            }
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BUILD HIGHLIGHT MAP  (line number → diff type)
    //  Only lines actually classified as ADDED/REMOVED/CHANGED are included.
    //  SAME lines are not in the map, so they can never be highlighted.
    // ════════════════════════════════════════════════════════════════════════

    private static Map<Integer, PDFComparator.DiffType> buildLineHighlightMap(
            List<PDFComparator.DiffRow> diff, String side) {

        Map<Integer, PDFComparator.DiffType> map = new HashMap<>();
        boolean isLeft = "left".equals(side);

        for (PDFComparator.DiffRow row : diff) {
            // SAME lines: never highlight
            if (row.type == PDFComparator.DiffType.SAME) continue;

            // Left side:  highlight REMOVED lines (present in left, gone in right)
            //             highlight CHANGED lines  (present in both, but different)
            // Right side: highlight ADDED lines    (new in right, not in left)
            //             highlight CHANGED lines  (present in both, but different)
            boolean shouldHighlight = isLeft
                ? (row.type == PDFComparator.DiffType.REMOVED || row.type == PDFComparator.DiffType.CHANGED)
                : (row.type == PDFComparator.DiffType.ADDED   || row.type == PDFComparator.DiffType.CHANGED);

            if (!shouldHighlight) continue;

            // Get the line number for this side
            int lineNo = isLeft ? row.leftLineNo : row.rightLineNo;
            if (lineNo > 0) {
                map.put(lineNo, row.type);
            }
        }
        return map;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  EXTRACT LINES WITH POSITIONS
    //
    //  Uses a custom PDFTextStripper to collect, for each filtered line:
    //    - its 1-based line number (matching DiffRow line numbers exactly)
    //    - its Y coordinate on the page
    //    - its X extent
    //    - which page it is on
    //
    //  The SAME zone filtering as PDFComparator.extractLines() is applied,
    //  so line numbers here correspond 1:1 with the diff result.
    // ════════════════════════════════════════════════════════════════════════

    private static List<ExtractedLine> extractLinesWithPositions(
            File pdfFile, FilterConfig config) throws IOException {

        List<ExtractedLine> result = new ArrayList<>();
        try (PDDocument doc = PDDocument.load(pdfFile)) {
            PositionStripper stripper = new PositionStripper(config);
            stripper.getText(doc);
            result.addAll(stripper.extractedLines);
        }
        return result;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  POSITION STRIPPER
    //
    //  Mirrors the logic of PDFComparator.ZoneAwareStripper + extractLines()
    //  exactly, but also records the Y/X position of each accepted line.
    //  The line counter increments only when a line passes all filters —
    //  matching the counter in PDFComparator.extractLines().
    // ════════════════════════════════════════════════════════════════════════

    private static final class PositionStripper extends PDFTextStripper {

        private final FilterConfig config;
        final List<ExtractedLine> extractedLines = new ArrayList<>();

        // Per-line accumulators
        private final List<TextPosition> linePositions = new ArrayList<>();
        private int   lineCounter = 1;   // 1-based, matches diff row line numbers
        private int   currentPage = 0;
        private float pageH = 792f;
        private float pageW = 595f;

        PositionStripper(FilterConfig config) throws IOException {
            super();
            this.config = config;
            setSortByPosition(true);
        }

        @Override
        protected void startPage(PDPage page) throws IOException {
            PDRectangle box = page.getMediaBox();
            pageH = box.getHeight();
            pageW = box.getWidth();
            currentPage = getCurrentPageNo() - 1;
            flushLine();
            super.startPage(page);
        }

        @Override
        protected void writeString(String text, List<TextPosition> positions) throws IOException {
            if (positions == null || positions.isEmpty()) {
                super.writeString(text, positions);
                return;
            }

            // Compute average position for zone checks (same logic as ZoneAwareStripper)
            float sumX = 0, sumY = 0;
            for (TextPosition tp : positions) { sumX += tp.getX(); sumY += tp.getY(); }
            float avgX = sumX / positions.size();
            float avgY = sumY / positions.size();
            float yTop = pageH - avgY;

            // Apply identical zone filters
            if (config.isIgnoreHeader()      && yTop < pageH * (config.getHeaderPct()  / 100.0)) return;
            if (config.isIgnoreFooter()      && yTop > pageH * ((100.0 - config.getFooterPct())  / 100.0)) return;
            if (config.isIgnoreLeftMargin()  && avgX < pageW * (config.getMarginPct()  / 100.0)) return;
            if (config.isIgnoreRightMargin() && avgX > pageW * ((100.0 - config.getMarginPct())  / 100.0)) return;

            linePositions.addAll(positions);
            super.writeString(text, positions);
        }

        @Override
        protected void writeLineSeparator() throws IOException {
            flushLine();
            super.writeLineSeparator();
        }

        @Override
        protected void endPage(PDPage page) throws IOException {
            flushLine();
            super.endPage(page);
        }

        private void flushLine() {
            if (linePositions.isEmpty()) return;

            // Reconstruct the line text to apply content filters (same as extractLines)
            StringBuilder sb = new StringBuilder();
            for (TextPosition tp : linePositions) sb.append(tp.getUnicode());
            String lineText = sb.toString();

            // Apply content filters — if the line would be dropped by processLine, skip it
            String processed = config.processLine(lineText);
            if (processed == null || processed.trim().isEmpty()) {
                linePositions.clear();
                return;
            }

            // Compute bounding box from character positions
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            for (TextPosition tp : linePositions) {
                minX = Math.min(minX, tp.getX());
                maxX = Math.max(maxX, tp.getX() + tp.getWidth());
                // PDF Y-up: baseline at tp.getY(), top at tp.getY() + tp.getHeight()
                minY = Math.min(minY, tp.getY());                       // lowest baseline
                maxY = Math.max(maxY, tp.getY() + tp.getHeight());     // highest top
            }

            extractedLines.add(new ExtractedLine(
                lineCounter, currentPage,
                minY, maxY,    // yBaseline=minY, yTop=maxY (PDF Y-up coords)
                minX, maxX,
                pageH, pageW
            ));

            lineCounter++;
            linePositions.clear();
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DRAW HIGHLIGHTS
    //
    //  Converts PDF coordinates (points, Y-up, bottom-left origin) to pixel
    //  coordinates (Y-down, top-left origin) and draws highlight rectangles.
    //
    //  The highlight spans the full width of the text on that line, tight to
    //  the actual character bounding boxes — not the full page width.
    // ════════════════════════════════════════════════════════════════════════

    private static void drawHighlights(BufferedImage img,
                                        List<ExtractedLine> lines,
                                        PDFComparator.DiffType[] types) {
        if (lines.isEmpty()) return;

        // All lines on this page share the same page dimensions
        float pdfH = lines.get(0).pageH;
        float pdfW = lines.get(0).pageW;
        float scaleX = (float) img.getWidth()  / pdfW;
        float scaleY = (float) img.getHeight() / pdfH;

        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,   RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

        for (int k = 0; k < lines.size(); k++) {
            ExtractedLine el   = lines.get(k);
            PDFComparator.DiffType type = types[k];

            // Convert PDF Y-up to image Y-down
            // In PDF: yBaseline is the bottom of text, yTop is the top of text
            // In image: origin is top-left, Y increases downward
            // So: imgY = pdfH - yTop   (the "top" in PDF becomes the "top" in image)
            //     imgBottom = pdfH - yBaseline
            float imgY      = (pdfH - el.yTop)      * scaleY;
            float imgBottom = (pdfH - el.yBaseline)  * scaleY;
            float imgX      = el.xLeft  * scaleX;
            float imgRight  = el.xRight * scaleX;

            int px = Math.max(0, (int) Math.floor(imgX)  - 2);
            int py = Math.max(0, (int) Math.floor(imgY)  - 1);
            int pr = Math.min(img.getWidth()  - 1, (int) Math.ceil(imgRight) + 2);
            int pb = Math.min(img.getHeight() - 1, (int) Math.ceil(imgBottom) + 1);
            int pw = Math.max(4, pr - px);
            int ph = Math.max(3, pb - py);

            Color fill, border;
            switch (type) {
                case REMOVED: fill = FILL_REMOVED; border = LINE_REMOVED; break;
                case ADDED:   fill = FILL_ADDED;   border = LINE_ADDED;   break;
                case CHANGED: fill = FILL_CHANGED; border = LINE_CHANGED; break;
                default: continue;
            }

            g.setColor(fill);
            g.fillRect(px, py, pw, ph);
            g.setColor(border);
            g.setStroke(new BasicStroke(1.0f));
            g.drawRect(px, py, pw, ph);
        }
        g.dispose();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BASE64 PNG ENCODER
    // ════════════════════════════════════════════════════════════════════════

    private static String toPng(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "PNG", baos);
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }
}
