package com.apitest;

import com.apitest.comparator.Comparator;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Extract the SKELETON of an XML response — element names and nesting structure
 * only. ALL text values, attribute values, namespace URIs, and comments are
 * stripped, so the output is safe to share for debugging XPath issues
 * even when the response itself contains proprietary data.
 *
 * Usage:
 *   java -cp target/api-test-suite.jar com.apitest.ResponseSkeleton &lt;response_file&gt;
 *
 * Output:
 *   - element tree with names only (text and attribute values replaced with placeholders)
 *   - list of unique element names found
 *   - list of repeated element names (often the ones you want to query via predicate)
 */
public class ResponseSkeleton {

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("Usage: ResponseSkeleton <response_file>");
            System.exit(2);
        }

        Path file = Path.of(args[0]);
        String payload = Files.readString(file);

        // Strip HTTP-style headers if present (the framework writes
        // "HTTP <status>\nelapsed: <ms>ms\n\n<body>")
        int doubleNl = payload.indexOf("\n\n");
        if (doubleNl > 0 && payload.regionMatches(true, 0, "HTTP", 0, 4)) {
            payload = payload.substring(doubleNl + 2);
        }

        // Apply the framework's sanitizer so this matches what the parser sees
        String sanitized = Comparator.sanitizeXmlProlog(payload).strip()
                .replace("\r\n", "\n").replace("\r", "")
                .replaceAll("&#x[dD];", "")
                .replaceAll("&#13;", "");

        Document doc;
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(false);
            doc = dbf.newDocumentBuilder().parse(new InputSource(new StringReader(sanitized)));
        } catch (Exception ex) {
            System.err.println("XML parse failed: " + ex.getMessage());
            System.err.println("If you see this, the framework will also fail to parse this response.");
            System.exit(1);
            return;
        }

        System.out.println("=== RESPONSE STRUCTURE ===");
        System.out.println("(values redacted — element names only, depths shown)");
        System.out.println();

        StringBuilder skeleton = new StringBuilder();
        Set<String> allNames = new LinkedHashSet<>();
        Set<String> seenNames = new HashSet<>();
        Set<String> repeatedNames = new LinkedHashSet<>();

        walk(doc.getDocumentElement(), 0, skeleton, allNames, seenNames, repeatedNames, 10);

        System.out.println(skeleton);
        System.out.println();
        System.out.println("=== UNIQUE ELEMENT NAMES (" + allNames.size() + ") ===");
        for (String n : allNames) System.out.println("  " + n);

        if (!repeatedNames.isEmpty()) {
            System.out.println();
            System.out.println("=== REPEATED ELEMENT NAMES (" + repeatedNames.size() + ") ===");
            System.out.println("These appear more than once. For these, use XPath predicates");
            System.out.println("like //Parent[ChildField='X'] to pick a specific one.");
            for (String n : repeatedNames) System.out.println("  " + n);
        }
    }

    /**
     * Walk the element tree, writing names + nesting only.
     * Depth-limited to avoid huge output on deeply nested or repeated structures.
     */
    private static void walk(Node node, int depth, StringBuilder out,
                              Set<String> allNames, Set<String> seenNames,
                              Set<String> repeatedNames, int maxDepth) {
        if (node == null) return;
        if (node.getNodeType() != Node.ELEMENT_NODE) return;

        String name = node.getNodeName();
        // Strip namespace prefix for the "names" output, but show in tree
        String localName = name.contains(":") ? name.substring(name.indexOf(':') + 1) : name;
        if (!seenNames.add(localName)) {
            repeatedNames.add(localName);
        }
        allNames.add(localName);

        String indent = "  ".repeat(depth);

        // Show attribute NAMES (not values)
        StringBuilder attrs = new StringBuilder();
        NamedNodeMap attrMap = node.getAttributes();
        if (attrMap != null && attrMap.getLength() > 0) {
            attrs.append(" [@");
            for (int i = 0; i < attrMap.getLength(); i++) {
                if (i > 0) attrs.append(",@");
                attrs.append(attrMap.item(i).getNodeName());
            }
            attrs.append("]");
        }

        if (depth >= maxDepth) {
            out.append(indent).append("<").append(name).append(attrs).append(">…\n");
            return;
        }

        // Count children of each name for compact summary
        java.util.Map<String, Integer> childCounts = new java.util.LinkedHashMap<>();
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node c = children.item(i);
            if (c.getNodeType() == Node.ELEMENT_NODE) {
                childCounts.merge(c.getNodeName(), 1, Integer::sum);
            }
        }

        // Has text content? (non-whitespace)
        boolean hasText = false;
        for (int i = 0; i < children.getLength(); i++) {
            Node c = children.item(i);
            if (c.getNodeType() == Node.TEXT_NODE
                    && c.getNodeValue() != null
                    && !c.getNodeValue().trim().isEmpty()) {
                hasText = true;
                break;
            }
        }

        if (childCounts.isEmpty() && !hasText) {
            out.append(indent).append("<").append(name).append(attrs).append("/>\n");
            return;
        }
        if (childCounts.isEmpty() && hasText) {
            out.append(indent).append("<").append(name).append(attrs).append(">…text…</").append(name).append(">\n");
            return;
        }

        out.append(indent).append("<").append(name).append(attrs).append(">\n");

        // Walk children — for repeated children, only walk the FIRST occurrence
        // and note the count, to keep the output small
        Set<String> walkedNames = new HashSet<>();
        for (int i = 0; i < children.getLength(); i++) {
            Node c = children.item(i);
            if (c.getNodeType() != Node.ELEMENT_NODE) continue;
            String cName = c.getNodeName();
            int count = childCounts.get(cName);
            if (count > 1) {
                if (walkedNames.add(cName)) {
                    out.append("  ".repeat(depth + 1))
                       .append("[× ").append(count).append(" of <").append(cName).append("> — showing first only]\n");
                    walk(c, depth + 1, out, allNames, seenNames, repeatedNames, maxDepth);
                }
                // skip subsequent occurrences
            } else {
                walk(c, depth + 1, out, allNames, seenNames, repeatedNames, maxDepth);
            }
        }
        out.append(indent).append("</").append(name).append(">\n");
    }
}
