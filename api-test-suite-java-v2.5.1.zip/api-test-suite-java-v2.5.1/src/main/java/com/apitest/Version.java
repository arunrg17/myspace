package com.apitest;

/**
 * Build version constant. Kept in sync with pom.xml {@code <version>} and
 * the {@code VERSION} file at the project root.
 *
 * Version history:
 *   2.5.0  - Automatic token fetch from Environment sheet. New TokenURL
 *            and TokenBody columns — the runner POSTs the form-urlencoded
 *            body to the token URL before any test step, extracts the
 *            access_token from the JSON response, and injects it as a
 *            Bearer header automatically. No template file needed.
 *   2.4.1  - Endpoint URLs starting with http:// or https:// are now
 *            used as-is without prepending the environment's BaseURL.
 *            Fixes the broken URL when a token endpoint on a different
 *            host is used in a step (e.g. https://auth.example.com/token
 *            was becoming https://dev-api/https://auth.example.com/token).
 *   2.4.0  - Apigee protocol support. Form-urlencoded body support for
 *            OAuth token endpoints. New "apikey" auth type. Certificate
 *            passwords can now be read from a properties file via the
 *            ${file./path:key} syntax. Auth values also support ${file.}.
 *   2.3.1  - Template and expected-file path resolution now uses a
 *            fallback chain: try templatesDir first, then projectRoot.
 *            Fixes the double-directory bug where BodyTemplate =
 *            "templates/req.xml" resolved to templates/templates/req.xml.
 *   2.3.0  - Per-step ExtraHeaders. Steps sheet now has an ExtraHeaders
 *            column supporting the same formats as Environments. Step
 *            headers override env headers for that step. Both env and step
 *            headers support placeholders (e.g., Authorization: Bearer
 *            ${step1.token}), enabling dynamic token flows where step 1
 *            fetches a token and step 2+ use it.
 *   2.2.1  - ExtraHeaders now supports semicolon-delimited format on a
 *            single line: "Authorization: Bearer xyz; X-Custom: value".
 *            Previous newline-delimited format still works. Both can mix.
 *   2.2.0  - Path configuration via CLI flags: --templates-dir,
 *            --expected-dir, --output-dir, --project-root. Lets users ship
 *            just the jar and point it at any directory layout. Comparison
 *            tab no longer truncates large payloads — pre-rendered area is
 *            fully accessible via scroll, with a header showing char counts.
 *   2.1.1  - Bug fix: in vs_env / vs_protocol mode, when source B's
 *            step failed (e.g. socket exception), the final status-resolve
 *            block was overwriting the FAIL set earlier with PASS. Final
 *            block now preserves any explicit FAIL/ERROR set by the
 *            comparison-mode switch. Overview tab now also shows a small
 *            ok/failed pill on each Source cell.
 *   2.1.0  - Comparison view enhancements. CompareResult now carries the
 *            CDATA-unwrapped, pretty-printed payloads; the HTML report
 *            shows them side-by-side in the Comparison tab so users can
 *            see exactly what was compared. Diff cell rendering fixed
 *            to suppress the internal {@code <missing>} sentinel string.
 *            Cleanup of code/docs, version metadata, and security review.
 *   2.0.2  - Serialization clean-up: no more {@code xmlns=""} artifacts,
 *            no line-wraps inside opening tags, no leftover blank lines
 *            from original-template indentation.
 *   2.0.1  - CDATA-aware cleanup of the rendered output: inner XML inside
 *            a CDATA wrapper now has unfilled placeholder tags removed
 *            cleanly via string-level passes (DOM walker cannot enter
 *            CDATA). CDATA sections preserved through serialization.
 *   2.0.0  - Template engine rewritten using a DOM walk with cascade
 *            pruning. Per-test error isolation: template / dispatch /
 *            extract errors become reported step failures, never killing
 *            the suite. RenderLog persisted to disk for diagnostics.
 *            Placeholder syntax is {@code ${name}} only.
 *   1.0.0  - Initial Java port from UFT/VBScript suite.
 */
public final class Version {
    public static final String VERSION = "2.5.1";
    private Version() {}
}
