package com.apitest.excel;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileOutputStream;
import java.nio.file.Path;

public class TemplateGenerator {
    public static void main(String[] args) throws Exception {
        Path out = Path.of(args.length > 0 ? args[0] : "config/test_suite.xlsx");
        generate(out);
        System.out.println("Excel template created: " + out.toAbsolutePath());
    }
    public static void generate(Path output) throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            CellStyle hdr = headerStyle(wb), bdy = bodyStyle(wb), ttl = titleStyle(wb);
            readme(wb, ttl, bdy);
            environments(wb, hdr, bdy);
            testSuite(wb, hdr, bdy);
            steps(wb, hdr, bdy);
            testData(wb, hdr, bdy);
            assertions(wb, hdr, bdy);
            try (FileOutputStream fos = new FileOutputStream(output.toFile())) { wb.write(fos); }
        }
    }
    private static void readme(Workbook wb, CellStyle title, CellStyle body) {
        Sheet s = wb.createSheet("README");
        Row r0 = s.createRow(0); Cell c = r0.createCell(0);
        c.setCellValue("API Test Suite \u2014 Quick Reference"); c.setCellStyle(title);
        s.addMergedRegion(new CellRangeAddress(0, 0, 0, 1));
        String[][] rows = {
            {"",""},
            {"Sheet","Purpose"},
            {"Environments","Define named environments: REST, SOAP, Apigee, Fabric, GCP."},
            {"TestSuite","One row per test case. Sets comparison mode and step references."},
            {"Steps","One row per HTTP request. Chain steps via StepOrder 1, 2, 3\u2026"},
            {"TestData","Variable values per test: ${col_name} in templates/endpoints."},
            {"Assertions","Field checks and 'ignore' directives for noisy fields."},
            {"",""},
            {"=== Protocols ===",""},
            {"rest","Generic REST. Content-Type defaults to application/json."},
            {"soap","SOAP. Forces POST. Content-Type defaults to text/xml."},
            {"apigee","Apigee proxy. Content-Type defaults to application/json."},
            {"fabric","Microsoft Fabric. Same as REST."},
            {"gcp","Google Cloud. Same as REST."},
            {"",""},
            {"=== Auth Types ===",""},
            {"none","No auth header."},
            {"basic","HTTP Basic. AuthValue = user:pass"},
            {"bearer","Bearer token. AuthValue = token or ${env.VAR} or ${file.path:key}"},
            {"apikey","API key. Injected as x-api-key header."},
            {"oauth2","OAuth2 bearer. AuthValue resolved via ${env.} or ${file.}."},
            {"service_account","GCP service account bearer."},
            {"",""},
            {"=== Secret Resolution ===","Works in AuthValue, SslConfig passwords, ExtraHeaders via ${} placeholders"},
            {"${env.MY_VAR}","OS environment variable."},
            {"${file./path/config.properties:key}","Java properties file."},
            {"literal_value","Plain text (not recommended for secrets)."},
            {"",""},
            {"=== Placeholders ===","In templates, endpoints, step ExtraHeaders"},
            {"${col_name}","From TestData column."},
            {"${stepN.field}","Extracted from previous step response."},
            {"${env.VAR}","OS environment variable."},
            {"${now}","Current UTC timestamp (ISO)."},
            {"${uuid}","Random UUID v4."},
            {"",""},
            {"=== Comparison Modes ===",""},
            {"vs_expected","Compare last response to a baseline file."},
            {"vs_env","Run on SourceA and SourceB, compare responses."},
            {"vs_protocol","Compare across protocols (e.g. SOAP vs REST)."},
            {"assert_only","Field-level assertions only."},
            {"chain","Run all steps; no comparison. For setup/smoke."},
            {"",""},
            {"Run","java -jar api-test-suite.jar --help"},
        };
        int ri = 1;
        for (String[] row : rows) {
            Row r = s.createRow(ri++);
            r.createCell(0).setCellValue(row[0]); r.getCell(0).setCellStyle(body);
            r.createCell(1).setCellValue(row[1]); r.getCell(1).setCellStyle(body);
        }
        s.setColumnWidth(0, 30 * 256); s.setColumnWidth(1, 90 * 256);
    }
    private static void environments(Workbook wb, CellStyle hdr, CellStyle bdy) {
        Sheet s = wb.createSheet("Environments");
        String[] cols = {"EnvName","Protocol","BaseURL","AuthType","AuthValue","ExtraHeaders","SslConfig","TokenURL","TokenBody","TokenHeaders"};
        writeHeader(s, cols, hdr);
        Object[][] rows = {
            {"DEV_REST","rest","https://dev-api.example.com","bearer","${env.DEV_TOKEN}","Content-Type: application/json; Accept: application/json",""},
            {"UAT_REST","rest","https://uat-api.example.com","bearer","${env.UAT_TOKEN}","Content-Type: application/json; Accept: application/json",""},
            {"PROD_REST","rest","https://api.example.com","bearer","${file./config/secrets.properties:prod_token}","Content-Type: application/json","trust_store=certs/prod-ca.jks; trust_password=${file./config/secrets.properties:trust_pass}"},
            {"DEV_SOAP","soap","https://dev-soap.example.com/ws","basic","${env.SOAP_USER}:${env.SOAP_PASS}","SOAPAction: \"\"",""},
            {"UAT_SOAP","soap","https://uat-soap.example.com/ws","basic","soap_user:soap_pass","SOAPAction: \"\"","trust_store=certs/uat-ca.jks; trust_password=${env.TRUST_PASS}"},
            {"PROD_SOAP","soap","https://soap.example.com/ws","basic","${file./config/secrets.properties:soap_creds}","SOAPAction: \"\"","trust_store=certs/prod-ca.jks; trust_password=${file./config/secrets.properties:trust_pass}; key_store=certs/client.p12; key_password=${file./config/secrets.properties:key_pass}; key_type=PKCS12"},
            {"APIGEE_DEV","apigee","https://dev-apigee.example.com/v1","apikey","${env.APIGEE_DEV_KEY}","Accept: application/json",""},
            {"APIGEE_PROD","apigee","https://apigee.example.com/v1","apikey","${file./config/secrets.properties:apigee_key}","Accept: application/json","trust_store=certs/apigee-ca.jks; trust_password=${file./config/secrets.properties:trust_pass}"},
            {"FABRIC_DEV","fabric","https://api.fabric.microsoft.com/v1","oauth2","${env.FABRIC_TOKEN}","Content-Type: application/json",""},
            {"GCP_PROD","gcp","https://compute.googleapis.com/v1","service_account","${env.GCP_TOKEN}","Content-Type: application/json",""},
            {"AUTH_SERVER","rest","https://auth.example.com","none","","Content-Type: application/x-www-form-urlencoded",""},
            {"LOCAL_DEV","rest","https://localhost:8443","none","","Content-Type: application/json","verify=false"},
        };
        writeData(s, rows, bdy);
        int[] w = {16,10,45,14,50,55,90};
        for (int i = 0; i < w.length; i++) s.setColumnWidth(i, w[i] * 256);
        s.createFreezePane(0, 1);
    }
    private static void testSuite(Workbook wb, CellStyle hdr, CellStyle bdy) {
        Sheet s = wb.createSheet("TestSuite");
        String[] cols = {"TestID","TestName","Description","ComparisonMode","SourceA","SourceB","ExpectedFile","Enabled"};
        writeHeader(s, cols, hdr);
        Object[][] rows = {
            {"T001","REST: DEV vs UAT","Same REST GET on two envs","vs_env","DEV_REST","UAT_REST","","Y"},
            {"T002","SOAP: DEV vs UAT","Same SOAP on two envs","vs_env","DEV_SOAP","UAT_SOAP","","Y"},
            {"T003","REST: vs expected JSON","Create order, compare to baseline JSON","vs_expected","DEV_REST","","expected/T003_order_response.json","Y"},
            {"T004","SOAP: vs expected XML","SOAP call, compare to expected XML","vs_expected","DEV_SOAP","","expected/T004_soap_response.xml","Y"},
            {"T005","SOAP vs REST parity","Same data via SOAP and REST","vs_protocol","DEV_SOAP","DEV_REST","","Y"},
            {"T006","Validate order fields","Create order, assert specific fields","assert_only","DEV_REST","","","Y"},
            {"T007","Order lifecycle chain","Create->Update->Verify->Delete","chain","DEV_REST","","","Y"},
            {"T008","REST with dynamic token","Step 1=fetch token, Step 2=use it","assert_only","DEV_REST","","","Y"},
            {"T009","Apigee: DEV vs PROD","Apigee-proxied endpoint","vs_env","APIGEE_DEV","APIGEE_PROD","","Y"},
            {"T010","SOAP with fresh token","Fetch token (form-urlencoded), then SOAP","assert_only","DEV_SOAP","","","Y"},
            {"T011","Fabric workspace","List Fabric datasets","assert_only","FABRIC_DEV","","","N"},
            {"T012","GCP instances","List GCP compute instances","assert_only","GCP_PROD","","","N"},
        };
        writeData(s, rows, bdy);
        int[] w = {10,35,45,16,14,14,42,10};
        for (int i = 0; i < w.length; i++) s.setColumnWidth(i, w[i] * 256);
        s.createFreezePane(0, 1);
    }
    private static void steps(Workbook wb, CellStyle hdr, CellStyle bdy) {
        Sheet s = wb.createSheet("Steps");
        String[] cols = {"TestID","StepOrder","StepName","Method","Endpoint","BodyTemplate","ExtractVars","ExpectedStatus","ExtraHeaders"};
        writeHeader(s, cols, hdr);
        Object[][] rows = {
            {"T001",1,"Get customer","GET","/customers/${customer_id}","","","200",""},
            {"T002",1,"Get account","POST","/ws/AccountService","soap_get_account.xml","","200",""},
            {"T003",1,"Create order","POST","/orders","create_order.json","order_id=$.order.id","201",""},
            {"T004",1,"Get cost report","POST","/ws/CostService","soap_cost_request.xml","","200",""},
            {"T005",1,"Get account","POST","/ws/AccountService","soap_get_account.xml","","200",""},
            {"T006",1,"Create order","POST","/orders","create_order.json","order_id=$.order.id","201",""},
            {"T007",1,"Create order","POST","/orders","create_order.json","order_id=$.order.id","201",""},
            {"T007",2,"Update order","PUT","/orders/${step1.order_id}","update_order.json","","200",""},
            {"T007",3,"Verify order","GET","/orders/${step1.order_id}","","status=$.order.status","200",""},
            {"T007",4,"Delete order","DELETE","/orders/${step1.order_id}","","","204",""},
            {"T008",1,"Fetch OAuth token","POST","https://auth.example.com/oauth/token","auth_form_body.txt","access_token=$.access_token; token_type=$.token_type","200","Content-Type: application/x-www-form-urlencoded"},
            {"T008",2,"Call protected API","GET","/protected/resource/${resource_id}","","","200","Authorization: Bearer ${step1.access_token}"},
            {"T009",1,"Get products","GET","/products?category=${category}","","","200",""},
            {"T010",1,"Fetch token","POST","https://auth.example.com/oauth/token","auth_form_body.txt","access_token=$.access_token","200","Content-Type: application/x-www-form-urlencoded"},
            {"T010",2,"SOAP with token","POST","/ws/SecureService","soap_secure_request.xml","","200","Authorization: Bearer ${step1.access_token}; SOAPAction: \"getSecureData\""},
            {"T011",1,"List datasets","GET","/workspaces/${workspace_id}/datasets","","","200",""},
            {"T012",1,"List instances","GET","/projects/${gcp_project}/zones/${gcp_zone}/instances","","","200",""},
        };
        writeData(s, rows, bdy);
        int[] w = {10,11,26,8,55,28,50,14,65};
        for (int i = 0; i < w.length; i++) s.setColumnWidth(i, w[i] * 256);
        s.createFreezePane(0, 1);
    }
    private static void testData(Workbook wb, CellStyle hdr, CellStyle bdy) {
        Sheet s = wb.createSheet("TestData");
        String[] cols = {"TestID","customer_id","product_id","quantity","unit_price","currency","region","category","resource_id","workspace_id","gcp_project","gcp_zone","client_id","client_secret","notes"};
        writeHeader(s, cols, hdr);
        Object[][] rows = {
            {"T001","CUST-1001","","","","","","","","","","","","","Simple GET"},
            {"T002","CUST-1001","","","","","","","","","","","","","SOAP call"},
            {"T003","CUST-1001","PROD-501","5","49.99","USD","EMEA","","","","","","","","REST POST"},
            {"T004","CUST-1001","","","","","","","","","","","","","SOAP cost"},
            {"T005","CUST-1001","","","","","","","","","","","","","Cross-protocol"},
            {"T006","CUST-1001","PROD-501","5","49.99","USD","EMEA","","","","","","","","Assert fields"},
            {"T007","CUST-1002","PROD-502","2","19.95","EUR","AMER","","","","","","","","Lifecycle"},
            {"T008","","","","","","","","RES-2001","","","","${env.CLIENT_ID}","${env.CLIENT_SECRET}","Dynamic token"},
            {"T009","","","","","","","electronics","","","","","","","Apigee"},
            {"T010","","","","","","","","","","","","${env.CLIENT_ID}","${env.CLIENT_SECRET}","Token+SOAP"},
            {"T011","","","","","","","","","WS-prod-analytics","","","","","Fabric"},
            {"T012","","","","","","","","","","my-gcp-project","us-central1-a","","","GCP"},
        };
        writeData(s, rows, bdy);
        int[] w = {10,14,14,11,12,10,10,14,14,22,18,16,22,22,20};
        for (int i = 0; i < w.length; i++) s.setColumnWidth(i, w[i] * 256);
        s.createFreezePane(0, 1);
    }
    private static void assertions(Workbook wb, CellStyle hdr, CellStyle bdy) {
        Sheet s = wb.createSheet("Assertions");
        String[] cols = {"TestID","Path","PathType","Operator","ExpectedValue","Description"};
        writeHeader(s, cols, hdr);
        Object[][] rows = {
            {"*","//*[local-name()='traceId']","xpath","ignore","","Trace ID always varies"},
            {"*","$.metadata.requestTime","jsonpath","ignore","","Request timestamp varies"},
            {"*","$.metadata.correlationId","jsonpath","ignore","","Correlation ID varies"},
            {"*","//*[local-name()='Timestamp']","xpath","ignore","","SOAP timestamp"},
            {"*","//*[local-name()='MessageID']","xpath","ignore","","WS-Addressing ID"},
            {"T001","//*[local-name()='lastModified']","xpath","ignore","","Varies per env"},
            {"T002","//*[local-name()='serverNode']","xpath","ignore","","Server name varies"},
            {"T003","$.order.created_at","jsonpath","ignore","","Generated timestamp"},
            {"T003","$.order.id","jsonpath","ignore","","Generated UUID"},
            {"T006","$.order.status","jsonpath","equals","created","Status = created"},
            {"T006","$.order.id","jsonpath","exists","","ID must exist"},
            {"T006","$.order.customer.id","jsonpath","equals","CUST-1001","Customer echo"},
            {"T006","$.total","jsonpath","greater_than","0","Positive total"},
            {"T006","$.order.items[0].quantity","jsonpath","equals","5","Quantity match"},
            {"T006","$.order.region","jsonpath","regex_match","^(EMEA|AMER|APAC)$","Valid region code"},
            {"T006","$.order.currency","jsonpath","not_null","","Currency present"},
            {"T006","$.order.notes","jsonpath","contains","order","Notes content"},
            {"T008","$.access_token","jsonpath","exists","","Token present"},
            {"T008","$.token_type","jsonpath","equals","Bearer","Token type"},
            {"T010","//*[local-name()='Status']","xpath","equals","SUCCESS","Service OK"},
        };
        writeData(s, rows, bdy);
        int[] w = {10,45,12,14,32,40};
        for (int i = 0; i < w.length; i++) s.setColumnWidth(i, w[i] * 256);
        s.createFreezePane(0, 1);
    }
    private static void writeHeader(Sheet s, String[] cols, CellStyle style) {
        Row r = s.createRow(0);
        for (int i = 0; i < cols.length; i++) { Cell c = r.createCell(i); c.setCellValue(cols[i]); c.setCellStyle(style); }
        r.setHeightInPoints(20f);
    }
    private static void writeData(Sheet s, Object[][] rows, CellStyle style) {
        int ri = 1;
        for (Object[] row : rows) {
            Row r = s.createRow(ri++);
            for (int i = 0; i < row.length; i++) {
                Cell c = r.createCell(i);
                if (row[i] instanceof Number n) c.setCellValue(n.doubleValue());
                else c.setCellValue(row[i] == null ? "" : row[i].toString());
                c.setCellStyle(style);
            }
        }
    }
    private static CellStyle headerStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle(); Font f = wb.createFont();
        f.setBold(true); f.setColor(IndexedColors.WHITE.getIndex()); f.setFontName("Arial"); f.setFontHeightInPoints((short)11);
        s.setFont(f); s.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex()); s.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        s.setAlignment(HorizontalAlignment.LEFT); s.setVerticalAlignment(VerticalAlignment.CENTER);
        s.setBorderLeft(BorderStyle.THIN); s.setBorderRight(BorderStyle.THIN); s.setBorderTop(BorderStyle.THIN); s.setBorderBottom(BorderStyle.THIN);
        return s;
    }
    private static CellStyle bodyStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle(); Font f = wb.createFont();
        f.setFontName("Arial"); f.setFontHeightInPoints((short)10);
        s.setFont(f); s.setAlignment(HorizontalAlignment.LEFT); s.setVerticalAlignment(VerticalAlignment.TOP); s.setWrapText(true);
        s.setBorderLeft(BorderStyle.THIN); s.setBorderRight(BorderStyle.THIN); s.setBorderTop(BorderStyle.THIN); s.setBorderBottom(BorderStyle.THIN);
        return s;
    }
    private static CellStyle titleStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle(); Font f = wb.createFont();
        f.setBold(true); f.setColor(IndexedColors.DARK_BLUE.getIndex()); f.setFontName("Arial"); f.setFontHeightInPoints((short)16);
        s.setFont(f); return s;
    }
}
