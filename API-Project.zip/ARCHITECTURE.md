# Architecture

This document is for developers who will maintain, extend, or deploy the API
test suite. It explains how the three parts fit together, why the main design
choices were made, and where to make changes for the most common kinds of work.

The system compares API responses. A tester describes their tests in an Excel
workbook; the engine runs each test against real endpoints and compares the
response to a baseline, to another environment, or to field-level assertions;
and it produces a self-contained HTML report. There is a command-line build for
scripted/CI use and a web application for interactive use.


## The three parts

```
api-test-suite-java     The engine. Reads the workbook, runs tests, compares,
                        writes the report. Has a CLI entry point (Main). Ships
                        as a library (a jar other code depends on) and as a
                        runnable fat jar.

api-test-suite-server   A Spring Boot application. Bundles the engine as a
                        dependency and runs it in-process, adds a REST API,
                        per-project workspaces, run history, settings, and
                        serves the web UI as static files.

api-test-suite-web      The browser UI (React + Vite + TypeScript). Built to
                        static files that the server serves. Talks to the
                        server's REST API.
```

The dependency direction is one-way: the server depends on the engine, the web
UI depends on the server's API. The engine knows nothing about the server; you
can use it entirely on its own from the command line.


## The engine (api-test-suite-java)

### Package layout

```
com.apitest
  Main                     CLI entry point: parses flags, runs, writes report
  Version                  Single source of the engine version string
  XPathTester              Small standalone helper for trying XPath expressions
  model/                   Plain data carriers (records and simple classes)
    Environment            One environment row (URL, protocol, auth, DB details)
    Step                   One request within a test
    Assertion              One field-level check, optionally scoped to a step
    TestCase               One test: its steps, data, and assertions
    TestSuite              Everything loaded from the workbook
    StepResult             Result of running one step
    DiffEntry              One structural difference
    CompareResult          Result of one comparison
    AssertionResult        Result of one assertion
    TestResult             Everything about one finished test
  excel/
    ExcelLoader            Reads the workbook into a TestSuite (Apache POI)
  template/
    TemplateEngine         Resolves ${placeholders} in bodies and endpoints
  dispatcher/
    Dispatcher             Sends the HTTP request, handles auth per protocol
    Response               The response the dispatcher returns
    SslConfig              Trust store / client cert handling for TLS
  comparator/
    Comparator             Structural diff of XML and JSON, with ignore rules
    AssertionEngine        Field-level assertions, including DB assertions
    CrossFormatCanonicalizer, SimpleXmlWalker   Helpers for normalising payloads
  runner/
    RunConfig              The inputs one run needs (paths, names)
    Runner                 Orchestrates load -> execute -> compare -> record
  reporter/
    Reporter               Builds the self-contained HTML report
    JsonReport             Serialises results to and from JSON
```

### How a run flows

```
workbook.xlsx
     |
     v
ExcelLoader  ->  TestSuite (environments + list of test cases)
     |
     v
Runner.runAll()
     |
     |-- for each test case:
     |     |-- for each step in order:
     |     |     |-- TemplateEngine renders the endpoint and body
     |     |     |-- Dispatcher sends the request, returns the response
     |     |     |-- extract variables from the response for later steps
     |     |
     |     |-- Comparator compares (when the mode calls for it)
     |     |-- AssertionEngine checks field-level and DB assertions
     |
     v
List<TestResult>
     |
     v
Reporter  ->  report.html   (self-contained: all CSS and JS inlined)
```

Every request and response is also written to disk under the run's output
folder, so a failure can be inspected byte for byte.

### Comparison modes

Set per test in the workbook. The mode decides what the engine compares:

- `vs_expected` runs on one source and compares the response to a saved file.
- `vs_env` runs the same request on two environments and compares the two.
- `vs_protocol` runs on two different sources (for example SOAP against REST);
  both are normalised to a common shape before comparing.
- `assert_only` runs on one source and checks field-level assertions, no file
  comparison.
- `chain` runs every step in order with no comparison, and honours any
  assertions attached to the steps. Useful for setup, teardown, and smoke tests.

### Assertions

Field-level checks live on the Assertions sheet. Each has a path (XPath or
JSONPath), an operator, and an expected value. Operators include equality,
containment, existence, numeric comparison, membership, regex, and count
checks. An assertion can be scoped to a specific step with a StepOrder value,
or left blank to check the final response.

Database assertions (`db_equals`, `db_contains`, `db_exists`, `db_rows`) run a
SQL query against the environment's configured database and compare the result.
These are guarded: only read-only `SELECT`/`WITH` queries are allowed, multiple
statements are rejected, and the connection is set read-only with a timeout.
The SQL comes from the tester's own workbook, so this is defence in depth
against a malformed or pasted statement rather than against an outside attacker.
The connection handling and these guards live in one place, `DbQuery`, which
both the assertion engine and the TestData SQL feature call, so the safety rules
cannot drift apart.

### Variable extraction

A step can capture values from its response into named variables that later
steps and assertions reference as `${stepN.field}`. Extraction returns every
value a path resolves to, not only the first: a path matching one value yields
that value, and a path matching several (for example every id in a list) yields
them joined with commas. That comma-separated form is exactly what a `db_rows`
assertion consumes, so a step can pull a list of ids from a response and hand
the whole set to a database check. `Comparator.extractAllVariables` does the
work; the single-value `extractVariable` remains for callers that want only the
first match.

### Test data from a database

A TestData cell may hold `${sql:ENV:QUERY}` instead of a literal value. Before a
test runs, `Runner.resolveSqlData` replaces each such cell with the result of
running QUERY against environment ENV's database (or the test's own Source A
database when ENV is omitted). One returned value substitutes as-is; several are
joined with commas. The query goes through `DbQuery`, so it obeys the same
read-only guards as a database assertion. To use more than one database, add an
Environments row per database that fills only the `Db*` columns and leaves
`BaseURL` blank; a reference then names whichever one it needs. This keeps the
one-database-per-environment model intact without widening the sheet.

### Optional JSON request fields

When a TestData value is blank, the placeholder in a request template does not
resolve. For XML templates the containing element is pruned; for JSON templates
the containing member (or array element) is dropped and the surrounding commas
are tidied, so an optional field is left out of the request entirely rather than
sent as an empty value the server would reject. The pruned JSON is validated
before it is sent, and if pruning ever produced invalid JSON the engine falls
back to simply clearing the markers. This lives in `TemplateEngine`, alongside
the existing XML pruning.

### The report

The HTML report inlines every byte of CSS and JavaScript. There are no external
links or CDN dependencies, so it opens correctly years later from an email
attachment, a ticket, or a bucket. That property is deliberate and worth
preserving in any report change.


## The server (api-test-suite-server)

The server wraps the engine so several people can use it from a browser without
each installing Java and a build. It is a standard Spring Boot application.

### Services

```
web/ApiController        The REST API. Every browser action lands here.
service/
  ProjectManager         Isolates each project under its own folder so several
                         projects share one server without colliding.
  WorkspaceService       Confines all file access to the project's workspace,
                         provides the run/template/expected/output areas, and
                         records an audit line for each change.
  RunService             Launches runs on worker threads, tracks in-flight and
                         queued runs, writes a finished marker so history is
                         correct even after a restart, and enforces the
                         concurrency limit (see below).
  EngineService          The thin bridge that calls the bundled engine in-process.
  SettingsService        Reads and writes the settings the UI exposes.
  StoragePolicy          How a finished run's results are stored (trim, truncate,
                         gzip) to keep large suites from filling the disk.
  AiService              Optional assistant features; off unless configured.
```

### How the server runs the engine

The engine is a Maven dependency of the server and runs **in the same process**
on a worker thread, not as a separate command. A run's progress lines are
streamed to the browser as each test starts and finishes. When a run ends, a
marker is written to disk with the exit code, so the run's status is correct
even if the browser closes, the worker dies, or the server restarts. This is
why status is never read from an in-memory map alone.

### Per-project isolation

Each project has its own folder under the workspace. A request names its project
with a header; the server resolves that to the project's own workspace, run
history, and settings. Nothing leaks between projects.

### The concurrency limit

Runs execute on worker threads, so without a limit a busy server could launch
many at once and overwhelm both itself and the systems under test. A permit
gate caps how many runs execute at the same time:

- The ceiling is the `max.concurrent.runs` setting (default 4), set from the UI
  under Settings > Execution, or by seeding the setting at deploy time.
- A run acquires a permit before it does any work. When every permit is taken,
  further runs wait on the gate: they are accepted, have a run id, and show a
  "queued" state, but consume no engine resources until a permit frees up.
- The limit is read per run, so a change takes effect on the next run without a
  restart. Lowering it never interrupts a run already under way; the reclaimed
  permits are only taken as running runs finish.
- The `/active` endpoint reports each run's state (running or queued) and, for a
  queued run, how many are ahead of it. There is deliberately no time estimate:
  run durations vary too much to predict, and a wrong estimate is worse than a
  simple position.

The relevant code is in `RunService`: the `ResizableGate` inner class, the
`syncGateLimit` method, and the `isQueued` / `queuePosition` / `executingCount`
/ `maxConcurrentRuns` helpers.

### Identity of the user who ran something

The server has no built-in login. It is intended to sit behind an identity
provider (the deployment integrates EIDP login) that authenticates the user and
passes the identity to the server. Where the server needs to record who did
something, it reads that identity from the request rather than trying to read an
OS username or hostname from the browser, which a browser does not expose.


## The web UI (api-test-suite-web)

React with Vite and TypeScript. It is built to static files and served by the
server, so in production there is no separate web server. It calls the server's
REST API for everything: listing projects, uploading workbooks, starting runs,
streaming progress, reading history, and reading and writing settings.

Settings fields follow one pattern: the settings screen loads all settings from
the API, each field is bound to a key, and saving posts the changed keys back.
Adding a setting is therefore a UI-only change plus, if the engine or a service
needs to read it, a call to `SettingsService`. The maximum-concurrent-runs field
under Settings > Execution is an example: it binds to `max.concurrent.runs` and
needs no new endpoint, because the settings API is generic.


## Building and running

Build order matters because the server depends on the engine, and the server
bundles the built UI.

1. Build and install the engine so the server can depend on it:
   `cd api-test-suite-java && mvn install`
2. Build the UI to static files and place them where the server serves them
   (see the server's static resources folder).
3. Build the server: `cd api-test-suite-server && mvn package`. This produces a
   runnable jar.

Run the server jar. It reads its workspace location from an environment variable
(default is a local `workspace` folder) and listens on a configurable port
(default 8080).

The engine alone, for CLI or CI use, runs from its own fat jar:
`java -jar api-test-suite.jar --suite <workbook> --output-dir <dir>` and the
other flags shown by `--help`.

Deployment recipes (systemd, Docker, and a single-replica Kubernetes setup) and
the full list of environment variables are in the deployment guide that ships
alongside this document.


## Extending the framework

### Add a comparison mode

1. Add a case for the new mode in `Runner` where the mode is dispatched.
2. Implement it by calling into `Comparator` and/or `AssertionEngine` and
   populating the result.
3. The report handles arbitrary modes already; a new mode appears in its filters
   automatically.
4. Update the workbook template and the docs.

### Add an assertion operator

1. Add a case in `AssertionEngine` where operators are handled.
2. Set the pass/fail outcome and a clear message.
3. Update the workbook template's dropdowns and the docs.

### Add a protocol or auth type

`Dispatcher` is the only place that knows about protocols and auth. Add a branch
for the new auth flow, or for any special header handling the new protocol
needs. Keep token providers quiet on success and let failures surface as the
response error, so they show up in the report like any other failure.

### Add a setting

Add the field to the settings screen bound to a new key. If a service or the
engine needs the value, read it through `SettingsService`. No new endpoint is
needed; the settings API stores and returns whatever keys the UI sends.


## Testing

The engine and the server each have their own test suite (JUnit 5). Run them
with `mvn test` in each project. Between them they cover the comparator, the
assertion engine (including database assertions against an in-memory fake
driver), the template engine, the Excel round-trip, run-status derivation, the
storage policy, workspace confinement, project isolation, and the concurrency
limit. Add a test alongside any behaviour change; the existing tests are the
model for style and setup.
