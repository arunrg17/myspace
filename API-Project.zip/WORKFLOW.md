# How the API test suite works

This is a plain-language walkthrough of what the tool does and how it works,
end to end. It is written to be read aloud or handed to a team that has not seen
the tool before. There is no code here.


## What problem it solves

Teams need to know that an API returns the right response: the same as a known
good baseline, the same across two environments, or the same after a change.
Doing that by hand is slow and easy to get wrong, especially when a response has
hundreds of fields and a few of them (timestamps, generated ids) are expected to
differ every time.

This tool automates that. You describe your tests once in a spreadsheet, run
them, and get a report that says, test by test, what matched and what did not,
with the exact differences highlighted.


## The idea in one picture

```
   Excel workbook                 The tool                    HTML report
   (you write the       ->    (runs each test and    ->    (pass/fail per test,
    tests here)                compares responses)          with the differences)
```

You work in the spreadsheet. The tool does the running and comparing. The report
is what you review and share.


## The spreadsheet: where you describe your tests

Everything a test needs is in one workbook, split across a few sheets. You do not
need to be a developer to fill it in.

- **Environments** is your list of targets: what to call, over which protocol
  (REST, SOAP, and others), and how to authenticate. You define each environment
  once (for example DEV and UAT) and refer to it by name everywhere else.

- **Tests** is one row per test. Each row says what the test is called and what
  kind of comparison it should do (more on the comparison types below).

- **Steps** is the actual requests. A simple test has one step. A more involved
  test can have several in order, for example create something, then update it,
  then delete it, each step able to use a value the previous step returned.

- **Test data** holds the values that fill in the requests, so the same request
  shape can be reused with different inputs. A value can also be pulled straight
  from a database: instead of typing it in, you write a short query and the tool
  looks the value up before the test runs. That is useful when the input has to
  be real and current - an account that actually exists today, the list of
  portfolios that are active right now - rather than a fixed value that goes
  stale. If the query returns several values, they are all used together, which
  pairs naturally with the database checks below.

- **Assertions** is where you check individual fields: this field must equal
  that, this one must exist, this number must be greater than zero, and so on.
  You can also check values in a database here, not just in the response - for
  example, that every item a response listed is backed by exactly those rows in
  the database.

Because it is a spreadsheet, anyone on the team can read it, review it, and add
tests, and it can be kept in version control like any other file.


## The kinds of comparison

Each test picks one way of deciding whether it passed:

- **Against a saved baseline** run the request and compare the response to a
  known good copy you saved earlier.

- **Across two environments** run the same request on, say, DEV and UAT, and
  check that both return the same thing. This is how you confirm two
  environments genuinely agree.

- **Across two protocols** run the same logical request two different ways (for
  example SOAP and REST) and confirm they agree, even though the raw formats
  differ. The tool normalises both before comparing.

- **Field checks only** run the request and check specific fields, without
  comparing the whole response to anything.

- **A sequence with no comparison** run several steps in order just to confirm
  each one succeeds. Useful for setup and quick smoke tests.


## Ignoring the fields that are meant to differ

Real responses contain fields that change every single time: a timestamp, a
generated id, a trace number. If the tool flagged those as differences, every
test would fail for the wrong reason. So you can tell it which fields to ignore,
either for one test or across all of them. The comparison then comes down to
what actually matters.


## What happens when you run

You can run the tests two ways.

**From the command line** for scheduled or automated runs, for example as part
of a nightly job. You point the tool at the workbook and it produces the report.

**From the web application** for day-to-day interactive use. You open it in a
browser, pick your project, upload or select the workbook, and start the run.
You watch progress as each test finishes, and the report appears at the end.

Either way, the steps are the same underneath: the tool reads the workbook,
sends each request to the real API, compares the response the way each test
asked for, and records the result.


## The report

The report is a single web page. At the top it shows the totals: how many tests
ran, how many passed, how many failed. Below that is every test, and clicking
one opens its details: the request that was sent, the response that came back,
and the exact differences if it did not match.

The report is entirely self-contained. It is one file with nothing linked from
outside, so you can email it, attach it to a ticket, or open it a year later and
it still works exactly the same. That matters when a report is evidence in an
audit trail.


## Using it as a team

The web application is built for several people to use at once, each in their own
project space so nobody's work collides with anyone else's.

**Signing in.** Access goes through the organisation's normal login, so people
sign in with their own credentials and the tool knows who is who.

**Running at the same time.** If many people start runs at once, the tool does
not try to run them all simultaneously and overload the servers being tested.
There is a limit on how many run at the same time. When the limit is reached,
further runs wait in a short queue and start automatically as slots free up.
Someone whose run is waiting sees that it is queued and how many are ahead of
it, so nothing looks stuck. An administrator sets the limit to suit the size of
the machine the tool runs on, and can change it without downtime.


## The short version

You describe your API tests in a spreadsheet. The tool runs them against the
real systems, compares the responses the way each test asks for, ignores the
fields that are meant to change, and gives you one self-contained report of
what passed and what did not. It works from the command line for automation and
from a browser for interactive use, supports several people working at once
behind the normal company login, and keeps everyone's runs orderly under load.
