package com.apitest;

/**
 * Build version constant. Kept in sync with pom.xml version and VERSION file.
 *
 * Version history:
 *   2.0.0  - Rewritten template engine using DOM walk with cascade pruning.
 *            Per-test error isolation: template / dispatch / extract errors
 *            become reported step failures, never killing the suite.
 *            RenderLog persisted to disk for diagnostics. ${} placeholder
 *            syntax only.
 *   1.0.0  - Initial Java port from UFT/VBScript.
 */
public final class Version {
    public static final String VERSION = "2.0.2";
    private Version() {}
}
