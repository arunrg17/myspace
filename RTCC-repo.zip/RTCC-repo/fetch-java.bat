@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RTCC - download the Java runtime

REM ====================================================================
REM  Downloads a private Java runtime into .\jre so RTCC can run
REM  without installing Java. Needs an internet connection, once.
REM ====================================================================

if exist "%~dp0jre\bin\java.exe" goto :already

echo.
echo   RTCC needs a Java runtime. This downloads one (about 47 MB)
echo   into a jre folder here. Nothing is installed into Windows.
echo.
set /p GO="   Continue? [Y/N] "
if /i not "%GO%"=="Y" goto :cancelled

set "URL=https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.5%%2B11/OpenJDK21U-jre_x64_windows_hotspot_21.0.5_11.zip"

echo.
echo   Downloading...
powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -Uri '%URL%' -OutFile 'jre.zip' -UseBasicParsing } catch { exit 1 }"
if errorlevel 1 goto :failed
if not exist "jre.zip" goto :failed

echo   Extracting...
powershell -NoProfile -Command "try { Expand-Archive -Path 'jre.zip' -DestinationPath 'jre-tmp' -Force } catch { exit 1 }"
if errorlevel 1 goto :failed

for /d %%D in ("jre-tmp\*") do move "%%~fD" "jre" >nul
rmdir /s /q jre-tmp 2>nul
del /q jre.zip 2>nul

if not exist "%~dp0jre\bin\java.exe" goto :failed
echo.
echo   Done. Double-click RTCC.bat to start the application.
echo.
pause
exit /b 0

:already
echo.
echo   A Java runtime is already present in this folder.
echo   Just double-click RTCC.bat.
echo.
pause
exit /b 0

:cancelled
echo.
echo   Cancelled. You can also install Java yourself from https://adoptium.net
echo.
pause
exit /b 1

:failed
echo.
echo   [ERROR] The download or extraction failed.
echo.
echo   Alternatives:
echo     - Install Temurin JRE 21 from https://adoptium.net
echo     - Or download the full RTCC release, which already contains
echo       the runtime.
echo.
pause
exit /b 1
