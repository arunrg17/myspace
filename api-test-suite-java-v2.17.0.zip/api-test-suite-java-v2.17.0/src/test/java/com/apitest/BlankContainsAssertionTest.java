package com.apitest;

import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import com.apitest.comparator.AssertionEngine;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A blank ExpectedValue on a contains-style check is a workbook mistake, not a
 * pass. Java's String.contains("") is always true, which used to make these
 * assertions pass regardless of the actual value; they must fail with a clear
 * message instead.
 */
class BlankContainsAssertionTest {

    private AssertionResult run(String path, String op, String expected, String body) {
        Assertion a = new Assertion(path, "jsonpath", op, expected, "");
        List<AssertionResult> results = AssertionEngine.evaluate(body, List.of(a));
        return results.get(0);
    }

    @Test
    void blankContainsFailsInsteadOfPassing() {
        AssertionResult r = run("$.name", "contains", "", "{\"name\":\"anything\"}");
        assertFalse(r.passed, "blank contains must not pass");
        assertTrue(r.message.toLowerCase().contains("non-blank"));
    }

    @Test
    void blankNotContainsFailsInsteadOfPassing() {
        AssertionResult r = run("$.name", "not_contains", "", "{\"name\":\"anything\"}");
        assertFalse(r.passed, "blank not_contains must not pass silently");
        assertTrue(r.message.toLowerCase().contains("non-blank"));
    }

    @Test
    void normalContainsStillWorks() {
        AssertionResult r = run("$.name", "contains", "thing", "{\"name\":\"anything\"}");
        assertTrue(r.passed);
    }

    @Test
    void normalContainsStillFailsWhenAbsent() {
        AssertionResult r = run("$.name", "contains", "zzz", "{\"name\":\"anything\"}");
        assertFalse(r.passed);
    }
}
