package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.Test;

import java.util.Base64;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Decoding base64 fields before a vs_expected / vs_env comparison. The point is
 * that base64 is not canonical: the same content can encode differently, so
 * comparing the encoded strings reports differences that are not real and hides
 * where a real difference actually is. Decoding first makes the structural
 * comparison work on the content.
 *
 * The existing three-argument compare must behave exactly as it always has.
 */
class DecodeComparisonTest {

    private static String b64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes());
    }

    private static String envelope(String encodedSection) {
        return "{\"id\":\"SEC\",\"payload\":\"" + encodedSection + "\"}";
    }

    // ---- the feature ----

    @Test
    void identicalInnerContentMatchesEvenWhenEncodingDiffers() {
        // Same inner JSON, but the two sides differ in inner whitespace, so the
        // base64 strings are not equal. Decoded and compared structurally they
        // are the same document.
        String a = envelope(b64("{\"status\":\"OK\",\"n\":1}"));
        String b = envelope(b64("{\"status\": \"OK\", \"n\": 1}"));

        CompareResult raw = Comparator.compare(a, b, List.of());
        assertFalse(raw.matched, "without decoding the encoded strings differ");

        CompareResult decoded = Comparator.compare(a, b, List.of(), List.of("$.payload"));
        assertTrue(decoded.matched, "decoded content is the same document: " + decoded.note);
    }

    @Test
    void genuineInnerDifferenceIsStillReported() {
        String a = envelope(b64("{\"status\":\"OK\"}"));
        String b = envelope(b64("{\"status\":\"FAILED\"}"));
        CompareResult r = Comparator.compare(a, b, List.of(), List.of("$.payload"));
        assertFalse(r.matched, "a real difference inside the encoded field must be reported");
    }

    @Test
    void noteRecordsHowManyFieldsWereDecoded() {
        String a = envelope(b64("{\"x\":1}"));
        String b = envelope(b64("{\"x\":1}"));
        CompareResult r = Comparator.compare(a, b, List.of(), List.of("$.payload"));
        assertTrue(r.note != null && r.note.contains("decoded"), "note was: " + r.note);
    }

    // ---- backwards compatibility ----

    @Test
    void threeArgCompareIsUnchanged() {
        String a = "{\"x\":1}";
        String b = "{\"x\":1}";
        assertTrue(Comparator.compare(a, b, List.of()).matched);
        assertFalse(Comparator.compare(a, "{\"x\":2}", List.of()).matched);
    }

    @Test
    void nullDecodePathsBehavesLikeThreeArg() {
        String a = envelope(b64("{\"x\":1}"));
        String b = envelope(b64("{\"x\":1}"));
        CompareResult with = Comparator.compare(a, b, List.of(), null);
        CompareResult without = Comparator.compare(a, b, List.of());
        assertEquals(without.matched, with.matched);
    }

    @Test
    void emptyDecodePathsBehavesLikeThreeArg() {
        String a = envelope(b64("{\"x\":1}"));
        String b = envelope(b64("{\"y\":2}"));
        assertEquals(Comparator.compare(a, b, List.of()).matched,
                Comparator.compare(a, b, List.of(), List.of()).matched);
    }

    // ---- corner cases: nothing should throw, nothing should silently corrupt ----

    @Test
    void pathThatMatchesNothingLeavesPayloadsAlone() {
        String a = "{\"x\":1}";
        String b = "{\"x\":1}";
        CompareResult r = Comparator.compare(a, b, List.of(), List.of("$.nosuchfield"));
        assertTrue(r.matched, "an unmatched decode path must not change the outcome");
    }

    @Test
    void fieldThatIsNotBase64IsLeftAsIsAndStillCompares() {
        // Both sides hold the same non-base64 text at the named path. Decoding
        // cannot work, so the values stay as they are and still match.
        String a = "{\"payload\":\"@@@not base64@@@\"}";
        String b = "{\"payload\":\"@@@not base64@@@\"}";
        CompareResult r = Comparator.compare(a, b, List.of(), List.of("$.payload"));
        assertTrue(r.matched, "note: " + r.note);
    }

    @Test
    void xmlPayloadWithDecodePathsDoesNotThrow() {
        String a = "<root><x>1</x></root>";
        String b = "<root><x>1</x></root>";
        assertDoesNotThrow(() -> Comparator.compare(a, b, List.of(), List.of("$.payload")));
        assertTrue(Comparator.compare(a, b, List.of(), List.of("$.payload")).matched);
    }

    @Test
    void nullAndMalformedInputsDoNotThrow() {
        assertDoesNotThrow(() -> Comparator.compare(null, null, List.of(), List.of("$.p")));
        assertDoesNotThrow(() -> Comparator.compare("!@#$", "{]}[", List.of(), List.of("$.p")));
        assertDoesNotThrow(() -> Comparator.compare("{\"p\":\"x\"}", null, List.of(), List.of("$.p")));
    }

    @Test
    void emptyStringValueAtPathIsSkipped() {
        String a = "{\"payload\":\"\"}";
        String b = "{\"payload\":\"\"}";
        CompareResult r = Comparator.compare(a, b, List.of(), List.of("$.payload"));
        assertTrue(r.matched);
    }

    @Test
    void wildcardPathDecodesEverySection() {
        // Several sections, each with an encoded payload; one differs inside.
        String a = "{\"sections\":[{\"p\":\"" + b64("{\"v\":1}") + "\"},"
                 + "{\"p\":\"" + b64("{\"v\":2}") + "\"}]}";
        String same = "{\"sections\":[{\"p\":\"" + b64("{\"v\": 1}") + "\"},"
                 + "{\"p\":\"" + b64("{\"v\": 2}") + "\"}]}";
        String diff = "{\"sections\":[{\"p\":\"" + b64("{\"v\":1}") + "\"},"
                 + "{\"p\":\"" + b64("{\"v\":99}") + "\"}]}";

        assertTrue(Comparator.compare(a, same, List.of(), List.of("$.sections[*].p")).matched,
                "same content, different encoding, must match");
        assertFalse(Comparator.compare(a, diff, List.of(), List.of("$.sections[*].p")).matched,
                "a difference in the second section must be reported");
    }

    @Test
    void blankAndNullEntriesInDecodePathsAreIgnored() {
        String a = envelope(b64("{\"x\":1}"));
        String b = envelope(b64("{\"x\":1}"));
        List<String> paths = java.util.Arrays.asList("", "  ", "$.payload");
        assertTrue(Comparator.compare(a, b, List.of(), paths).matched);
    }

    @Test
    void ignoreAssertionsStillApplyAfterDecoding() {
        // The decoded content differs only at a field the user ignores.
        String a = envelope(b64("{\"status\":\"OK\",\"ts\":\"2026-01-01\"}"));
        String b = envelope(b64("{\"status\":\"OK\",\"ts\":\"2026-09-09\"}"));
        Assertion ignoreTs = new Assertion("$.payload.ts", "jsonpath", "ignore", "", "");
        CompareResult r = Comparator.compare(a, b, List.of(ignoreTs), List.of("$.payload"));
        assertTrue(r.matched, "ignore should still apply to the decoded content: " + r.note);
    }
}
