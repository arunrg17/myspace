package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A blank ExpectedValue on an operator whose check would be trivially satisfied
 * by emptiness must fail with a clear message rather than silently pass. Every
 * value contains the empty string and matches the empty pattern, so a blank
 * check there is always a workbook mistake, not a real assertion.
 */
class BlankExpectedGuardTest {

    private AssertionResult run(String path, String op, String expected, String payload) {
        Assertion a = new Assertion(path, "jsonpath", op, expected, "", 0);
        List<AssertionResult> results = AssertionEngine.evaluate(payload, List.of(a));
        return results.get(0);
    }

    private static final String JSON = "{\"name\":\"anything\"}";

    @Test
    void containsWithBlankExpectedFails() {
        AssertionResult r = run("$.name", "contains", "", JSON);
        assertFalse(r.passed);
        assertTrue(r.message.toLowerCase().contains("blank"));
    }

    @Test
    void notContainsWithBlankExpectedFails() {
        AssertionResult r = run("$.name", "not_contains", "", JSON);
        assertFalse(r.passed);
    }

    @Test
    void regexMatchWithBlankPatternFails() {
        AssertionResult r = run("$.name", "regex_match", "", JSON);
        assertFalse(r.passed);
        assertTrue(r.message.toLowerCase().contains("pattern"));
    }

    @Test
    void oneOfWithBlankExpectedFails() {
        AssertionResult r = run("$.name", "one_of", "", JSON);
        assertFalse(r.passed);
    }

    @Test
    void containsWithRealExpectedStillWorks() {
        assertTrue(run("$.name", "contains", "any", JSON).passed);
        assertFalse(run("$.name", "contains", "zzz", JSON).passed);
    }

    @Test
    void regexMatchWithRealPatternStillWorks() {
        assertTrue(run("$.name", "regex_match", "^any", JSON).passed);
    }
}
