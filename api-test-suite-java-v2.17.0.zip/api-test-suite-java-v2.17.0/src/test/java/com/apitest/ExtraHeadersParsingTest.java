package com.apitest;

import org.junit.jupiter.api.Test;
import java.lang.reflect.Method;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test the ExtraHeaders parsing logic. Each header is on its own line, only the
 * first colon separates name from value, and a semicolon in a value is kept.
 */
class ExtraHeadersParsingTest {

    /**
     * Invoke the private parseHeaders method via reflection.
     */
    @SuppressWarnings("unchecked")
    private Map<String, String> parseHeaders(String raw) throws Exception {
        Class<?> cls = Class.forName("com.apitest.excel.ExcelLoader");
        Method m = cls.getDeclaredMethod("parseHeaders", String.class);
        m.setAccessible(true);
        return (Map<String, String>) m.invoke(null, raw);
    }

    @Test
    void newlineDelimited() throws Exception {
        String input = "Authorization: Bearer xyz\nX-Custom-Header: value123";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(2, headers.size());
        assertEquals("Bearer xyz", headers.get("Authorization"));
        assertEquals("value123", headers.get("X-Custom-Header"));
    }

    @Test
    void semicolonInValueIsKept() throws Exception {
        // A semicolon is part of the value now, not a delimiter. A Content-Type
        // with a charset parameter is the common case that used to be cut short.
        String input = "Content-Type: text/html; charset=utf-8";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(1, headers.size());
        assertEquals("text/html; charset=utf-8", headers.get("Content-Type"));
    }

    @Test
    void cookieWithSeveralPairsIsKept() throws Exception {
        // A cookie with several pairs kept every pair, where the old semicolon
        // split dropped all but the first.
        String input = "Cookie: session=abc; theme=dark; lang=en";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(1, headers.size());
        assertEquals("session=abc; theme=dark; lang=en", headers.get("Cookie"));
    }

    @Test
    void multipleHeadersOnePerLine() throws Exception {
        String input = "Authorization: Bearer xyz\nContent-Type: text/html; charset=utf-8\nX-Custom: val1";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(3, headers.size());
        assertEquals("Bearer xyz", headers.get("Authorization"));
        assertEquals("text/html; charset=utf-8", headers.get("Content-Type"));
        assertEquals("val1", headers.get("X-Custom"));
    }

    @Test
    void blankLinesBetweenHeadersAreIgnored() throws Exception {
        String input = "Authorization: Bearer xyz\n\nX-Custom: val1\n";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(2, headers.size());
        assertEquals("val1", headers.get("X-Custom"));
    }

    @Test
    void trailingSpaces() throws Exception {
        String input = "Authorization:  Bearer xyz  \n  X-Custom:  value123  ";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(2, headers.size());
        assertEquals("Bearer xyz", headers.get("Authorization"));
        assertEquals("value123", headers.get("X-Custom"));
    }

    @Test
    void emptyInput() throws Exception {
        Map<String, String> headers = parseHeaders("");
        assertTrue(headers.isEmpty());
        headers = parseHeaders(null);
        assertTrue(headers.isEmpty());
    }

    @Test
    void headerValueWithColon() throws Exception {
        // Bearer token might have colons in the value
        String input = "Authorization: Bearer eyJhbGc:iOiJIUzI1:NiIsInR5cCI6Ikp";
        Map<String, String> headers = parseHeaders(input);
        assertEquals(1, headers.size());
        // Only the FIRST colon is the delimiter
        assertEquals("Bearer eyJhbGc:iOiJIUzI1:NiIsInR5cCI6Ikp", headers.get("Authorization"));
    }
}
