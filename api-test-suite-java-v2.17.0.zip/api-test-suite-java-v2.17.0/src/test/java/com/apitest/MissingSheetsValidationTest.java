package com.apitest;

import com.apitest.excel.ExcelLoader;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Workbook structure validation should report every missing required sheet at
 * once, not fail on the first one and make the user fix them one re-run at a
 * time.
 */
class MissingSheetsValidationTest {

    @Test
    void reportsAllMissingSheetsTogether() throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            // Only one of the three required sheets is present.
            wb.createSheet("TestSuite");
            List<String> missing = ExcelLoader.missingSheets(wb);
            assertTrue(missing.contains("Environments"));
            assertTrue(missing.contains("Steps"));
            assertFalse(missing.contains("TestSuite"));
            assertEquals(2, missing.size());
        }
    }

    @Test
    void noneMissingWhenAllPresent() throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            wb.createSheet("Environments");
            wb.createSheet("TestSuite");
            wb.createSheet("Steps");
            assertTrue(ExcelLoader.missingSheets(wb).isEmpty());
        }
    }

    @Test
    void optionalSheetsAreNotRequired() throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            wb.createSheet("Environments");
            wb.createSheet("TestSuite");
            wb.createSheet("Steps");
            // TestData and Assertions absent, but they are optional.
            assertTrue(ExcelLoader.missingSheets(wb).isEmpty());
        }
    }
}
