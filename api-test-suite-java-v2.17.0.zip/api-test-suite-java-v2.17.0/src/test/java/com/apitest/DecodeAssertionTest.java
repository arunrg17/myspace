package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import org.junit.jupiter.api.Test;

import java.util.Base64;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * The Decode transform on an assertion: a field holding base64 is decoded
 * before the operator runs, so an assertion can reach inside an encoded request
 * or response section. A blank decode leaves the value untouched (every
 * existing workbook), and a value that will not decode fails loudly rather than
 * passing silently.
 */
class DecodeAssertionTest {

    private AssertionResult run(String path, String op, String expected, String decode, String payload) {
        Assertion a = new Assertion(path, "jsonpath", op, expected, "", 0, decode);
        return AssertionEngine.evaluate(payload, List.of(a)).get(0);
    }

    private static String b64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes());
    }

    @Test
    void decodesBase64ThenChecksInnerValue() {
        // The encoded field holds {"status":"OK"}; the assertion checks inside it.
        String inner = "{\"status\":\"OK\",\"id\":42}";
        String payload = "{\"section\":\"" + b64(inner) + "\"}";
        AssertionResult r = run("$.section", "contains", "\"status\":\"OK\"", "base64", payload);
        assertTrue(r.passed, r.message);
    }

    @Test
    void decodedEqualsMatchesExactInnerContent() {
        String inner = "hello world";
        String payload = "{\"section\":\"" + b64(inner) + "\"}";
        AssertionResult r = run("$.section", "equals", "hello world", "base64", payload);
        assertTrue(r.passed, r.message);
    }

    @Test
    void blankDecodeLeavesValueUntouched() {
        // No decode: the raw base64 string is what the operator sees. This is
        // the existing behaviour every current workbook relies on.
        String raw = b64("anything");
        String payload = "{\"section\":\"" + raw + "\"}";
        AssertionResult r = run("$.section", "equals", raw, "", payload);
        assertTrue(r.passed, r.message);
    }

    @Test
    void invalidBase64FailsLoudlyNotSilently() {
        // '@@@@' is not valid base64. The assertion must fail with a decode
        // error, never pass and never fall back to the raw value.
        String payload = "{\"section\":\"@@@@not-base64@@@@\"}";
        AssertionResult r = run("$.section", "contains", "anything", "base64", payload);
        assertFalse(r.passed);
        assertTrue(r.message.toLowerCase().contains("decode failed"), r.message);
    }

    @Test
    void unknownDecodeModeReported() {
        String payload = "{\"section\":\"" + b64("x") + "\"}";
        AssertionResult r = run("$.section", "equals", "x", "rot13", payload);
        assertFalse(r.passed);
        assertTrue(r.message.toLowerCase().contains("unknown decode"), r.message);
    }

    @Test
    void base64TextAliasWorks() {
        String payload = "{\"section\":\"" + b64("value") + "\"}";
        AssertionResult r = run("$.section", "equals", "value", "base64:text", payload);
        assertTrue(r.passed, r.message);
    }

    @Test
    void decodeModeIsCaseInsensitive() {
        String payload = "{\"section\":\"" + b64("value") + "\"}";
        AssertionResult r = run("$.section", "equals", "value", "BASE64", payload);
        assertTrue(r.passed, r.message);
    }

    @Test
    void base64WithSurroundingWhitespaceStillDecodes() {
        String padded = "  " + b64("trimmed") + "  ";
        String payload = "{\"section\":\"" + padded + "\"}";
        AssertionResult r = run("$.section", "equals", "trimmed", "base64", payload);
        assertTrue(r.passed, r.message);
    }

    @Test
    void missingPathWithDecodeDoesNotThrow() {
        // Path resolves to nothing; decode has nothing to do; the assertion
        // fails cleanly rather than erroring.
        String payload = "{\"other\":\"x\"}";
        AssertionResult r = run("$.section", "equals", "x", "base64", payload);
        assertFalse(r.passed);
    }

    @Test
    void decodedContentDrivesExistsCheck() {
        String inner = "{\"token\":\"abc\"}";
        String payload = "{\"s\":\"" + b64(inner) + "\"}";
        // exists checks the decoded value is present and non-empty
        AssertionResult r = run("$.s", "exists", "", "base64", payload);
        assertTrue(r.passed, r.message);
    }
}
