package com.apitest.runner;

import com.apitest.comparator.AssertionEngine;
import com.apitest.comparator.Comparator;
import com.apitest.comparator.DbQuery;
import com.apitest.dispatcher.Dispatcher;
import com.apitest.dispatcher.Response;
import com.apitest.excel.ExcelLoader;

import java.io.IOException;
import com.apitest.model.*;
import com.apitest.template.TemplateEngine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Orchestrates: load suite -> execute steps -> compare/assert -> record results.
 *
 * Comparison modes:
 *   vs_expected      Run on source A, compare to expected file
 *   vs_env           Run on source A and source B, compare responses
 *   vs_protocol      Run on two different protocols, compare normalized
 *   assert_only      Run on source A, validate field-level assertions
 *   chain            Run all steps in order, no comparison
 */
public class Runner {

    private static final DateTimeFormatter TS_FOLDER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    private static final DateTimeFormatter TS_DISPLAY = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Run the suite using default conventions (templates/, expected/, output/
     * relative to projectRoot). Kept for backward compatibility and tests.
     */
    public static List<TestResult> runAll(Path suitePath, Path projectRoot) throws Exception {
        RunConfig cfg = new RunConfig(
                suitePath,
                projectRoot.resolve("reports/report.html"),
                projectRoot,
                projectRoot.resolve("templates"),
                projectRoot.resolve("expected"),
                projectRoot.resolve("output"),
                "API Test Suite"
        );
        return runAll(cfg);
    }

    /**
     * Run the suite using the given configuration. Paths in RunConfig take
     * precedence over the conventional defaults.
     */
    public static List<TestResult> runAll(RunConfig cfg) throws Exception {
        return runAll(cfg, null, null);
    }

    /**
     * Run every test, reporting progress and honouring cancellation.
     *
     * <p>Added so the tool can run in-process inside a long-lived service and
     * stream progress to a browser, instead of only as a one-shot command-line
     * process. Both parameters are optional:
     *
     * <ul>
     *   <li>{@code onEvent} - called before and after each test with a short
     *       progress line, for a live console. Null to ignore.
     *   <li>{@code cancelled} - checked before each test; when it returns true
     *       the run stops early and returns the results gathered so far. Null
     *       means never cancelled.
     * </ul>
     */
    public static List<TestResult> runAll(RunConfig cfg,
                                          java.util.function.Consumer<String> onEvent,
                                          java.util.function.BooleanSupplier cancelled) throws Exception {
        TestSuite suite = ExcelLoader.load(cfg.suitePath);
        Path outputRoot = cfg.outputDir.resolve(LocalDateTime.now().format(TS_FOLDER));
        Files.createDirectories(outputRoot);

        List<TestResult> results = new ArrayList<>();
        for (TestCase tc : suite.tests()) {
            if (cancelled != null && cancelled.getAsBoolean()) {
                emit(onEvent, "  Cancelled before " + tc.testId);
                break;
            }
            emit(onEvent, "  Running " + tc.testId + ": " + tc.name);
            try {
                TestResult r = runTest(tc, suite, cfg, outputRoot);
                results.add(r);
                emit(onEvent, "    " + r.status + " (" + tc.testId + ")");
            } catch (Throwable ex) {
                // A test threw outside the per-step safety nets - record it
                // as a failed test result and keep going. The suite never
                // aborts because of one bad test.
                TestResult r = new TestResult();
                r.testId = tc.testId;
                r.name = tc.name;
                r.description = tc.description;
                r.status = "ERROR";
                r.error = "Test execution error: " + ex.getClass().getSimpleName()
                        + ": " + ex.getMessage();
                r.errorDetail = formatException(ex);
                r.started = LocalDateTime.now().format(TS_DISPLAY);
                results.add(r);
                emit(onEvent, "    ERROR (" + tc.testId + "): " + r.error);
            }
        }
        return results;
    }

    private static void emit(java.util.function.Consumer<String> onEvent, String line) {
        if (onEvent != null) onEvent.accept(line);
        else System.out.println(line);
    }

    /** Backward-compatible single-test entry point (kept for tests). */
    /**
     * Run a single test case end to end and produce its result.
     *
     * <p>Dispatches by comparison mode: vs_expected compares the last response
     * against a baseline file; vs_env / vs_protocol run two sources and compare
     * them; assert_only runs assertions with no comparison; chain just runs the
     * steps in order. Any error is captured into the result rather than thrown,
     * so one bad test never aborts the suite.
     *
     * @param tc    the test case to run
     * @param suite the full suite (for environment lookups)
     * @return the populated result, including status, steps, diffs and assertions
     */
    public static TestResult runTest(TestCase tc, TestSuite suite, Path projectRoot, Path outputRoot)
            throws Exception {
        RunConfig cfg = new RunConfig(
                null, null, projectRoot,
                projectRoot.resolve("templates"),
                projectRoot.resolve("expected"),
                projectRoot.resolve("output"),
                ""
        );
        return runTest(tc, suite, cfg, outputRoot);
    }

    public static TestResult runTest(TestCase tc, TestSuite suite, RunConfig cfg, Path outputRoot)
            throws Exception {

        long started = System.currentTimeMillis();
        Path testOut = outputRoot.resolve(tc.testId);
        Files.createDirectories(testOut);

        TestResult result = new TestResult();
        result.testId = tc.testId;
        result.name = tc.name;
        result.description = tc.description;
        result.comparisonMode = tc.comparisonMode;
        result.sourceA = tc.sourceA;
        result.sourceB = tc.sourceB;
        result.started = LocalDateTime.now().format(TS_DISPLAY);

        Environment envA = suite.environments().get(tc.sourceA);
        if (envA == null) {
            result.status = "ERROR";
            result.error = "Unknown environment: " + tc.sourceA;
            result.durationMs = System.currentTimeMillis() - started;
            return result;
        }

        // Resolve any ${sql:...} references in the TestData values into concrete
        // values before the steps run, so a data value can come straight from a
        // database. A reference names the environment whose database to query,
        // or defaults to this test's own source A database.
        resolveSqlData(tc, suite, envA);

        // Variables captured from each step's response, shared so both the
        // step requests and the assertions can resolve ${stepN.field}.
        Map<Integer, Map<String, String>> stepVars = new java.util.LinkedHashMap<>();
        // Step-scoped assertion results are collected as the steps run.
        List<AssertionResult> stepScoped = new ArrayList<>();

        String mode = tc.comparisonMode == null ? "" : tc.comparisonMode;

        result.stepsA = executeSteps(tc.steps, envA, tc.data, cfg,
                testOut.resolve("sourceA"), "A", stepVars,
                tc.assertions, stepScoped, envA);
        boolean stepFailed = result.stepsA.stream().anyMatch(s -> !s.passed);

        // Final-scoped assertions (no StepOrder, or StepOrder 0) run once
        // against the last response, in every mode including chain. Rendering
        // resolves any ${stepN.field} they reference. Historically these ran in
        // every mode except chain; chain now honours them too, so a chained
        // create/update/delete can validate along the way.
        List<AssertionResult> finalScoped = new ArrayList<>();
        if (!result.stepsA.isEmpty()) {
            List<Assertion> finalAssertions = new ArrayList<>();
            for (Assertion a : tc.assertions) {
                if (!a.isStepScoped()) finalAssertions.add(a);
            }
            if (!finalAssertions.isEmpty()) {
                String lastA = result.stepsA.get(result.stepsA.size() - 1).responseBody;
                List<Assertion> rendered = renderAssertions(finalAssertions, tc.data, stepVars);
                finalScoped = AssertionEngine.evaluate(lastA, rendered, envA);
            }
        }
        // Present all assertion results together, step-scoped first (in step
        // order) then final-scoped, so the report reads top to bottom.
        result.assertionResults = new ArrayList<>();
        result.assertionResults.addAll(stepScoped);
        result.assertionResults.addAll(finalScoped);

        if (stepFailed) {
            result.status = "FAIL";
            result.error = "One or more steps in source A failed";
            result.durationMs = System.currentTimeMillis() - started;
            return result;
        }

        switch (mode) {
            case "chain" -> { /* steps already ran; assertions handled above */ }

            case "assert_only" -> {
                if (result.assertionResults.isEmpty()) {
                    result.status = "ERROR";
                    result.error = "assert_only mode requires at least one assertion";
                }
            }

            case "vs_expected" -> {
                String lastA = result.stepsA.get(result.stepsA.size() - 1).responseBody;
                Path expectedPath = resolveFile(tc.expectedFile, cfg.expectedDir, cfg.projectRoot);
                if (expectedPath == null) {
                    result.status = "ERROR";
                    StringBuilder msg = new StringBuilder("Expected file not found: ").append(tc.expectedFile);
                    msg.append("\n  Tried:");
                    if (cfg.expectedDir != null) msg.append("\n    ").append(cfg.expectedDir.resolve(tc.expectedFile));
                    if (cfg.projectRoot != null) msg.append("\n    ").append(cfg.projectRoot.resolve(tc.expectedFile));
                    result.error = msg.toString();
                } else {
                    String expected = Files.readString(expectedPath);
                    result.compareResult = Comparator.compare(expected, lastA, tc.assertions, tc.decodePaths);
                }
            }

            case "vs_env", "vs_protocol" -> {
                Environment envB = suite.environments().get(tc.sourceB);
                if (envB == null) {
                    result.status = "ERROR";
                    result.error = "Unknown environment: " + tc.sourceB;
                } else {
                    result.stepsB = executeSteps(tc.steps, envB, tc.data, cfg,
                            testOut.resolve("sourceB"), "B",
                            new java.util.LinkedHashMap<>(), null, null, null);
                    if (result.stepsB.stream().anyMatch(s -> !s.passed)) {
                        result.status = "FAIL";
                        result.error = "One or more steps in source B failed";
                    } else {
                        String lastA = result.stepsA.get(result.stepsA.size() - 1).responseBody;
                        String lastB = result.stepsB.get(result.stepsB.size() - 1).responseBody;
                        result.compareResult = Comparator.compare(lastA, lastB, tc.assertions, tc.decodePaths);
                    }
                }
            }

            default -> {
                result.status = "ERROR";
                result.error = "Unknown comparison mode: " + mode;
            }
        }

        // Final pass/fail determination.
        //
        // The switch above may already have settled the outcome - FAIL when
        // source B's steps failed in vs_env mode, ERROR when the expected
        // file was missing. Only fall back to the comparison result when it
        // hasn't.
        if (!"ERROR".equals(result.status) && !"FAIL".equals(result.status)) {
            boolean assertionsPassed = result.assertionResults.stream().allMatch(a -> a.passed);
            boolean compareMatched = result.compareResult == null || result.compareResult.matched;
            result.status = (assertionsPassed && compareMatched) ? "PASS" : "FAIL";
        }

        result.durationMs = System.currentTimeMillis() - started;
        return result;
    }

    // ------------------------------------------------------------------

    /**
     * Execute every step for one source against one environment, in order.
     *
     * <p>If the environment defines an auto-token endpoint, a token is fetched
     * first and applied as a Bearer header. For each step it renders the body
     * template and endpoint, sends the request, checks the status, and extracts
     * any variables for later steps to use. The {@code source} marker ("A"/"B")
     * selects which endpoint to use when a step has two pipe-separated ones.
     */
    private static List<StepResult> executeSteps(List<Step> steps, Environment env,
                                                 Map<String, String> data, RunConfig cfg,
                                                 Path outputDir, String source,
                                                 Map<Integer, Map<String, String>> stepVars,
                                                 List<Assertion> assertions,
                                                 List<AssertionResult> assertionSink,
                                                 Environment assertEnv) throws Exception {
        List<StepResult> results = new ArrayList<>();
        Files.createDirectories(outputDir);

        // --- Auto token fetch -------------------------------------------
        // If the environment has a TokenURL configured, hit it BEFORE any
        // test step to obtain a Bearer token. The token is injected into
        // the environment's headers automatically.
        //
        // TokenBody supports ${env.VAR} and ${file.path:key} placeholders
        // for client_id / client_secret.
        // -----------------------------------------------------------------
        Map<String, String> envHeaders = new LinkedHashMap<>(env.extraHeaders());
        if (env.tokenUrl() != null && !env.tokenUrl().isEmpty()) {
            try {
                String tokenBody = env.tokenBody() == null ? "" : env.tokenBody();
                // Resolve ${env.} and ${file.} placeholders in token body
                tokenBody = TemplateEngine.render(tokenBody, data, stepVars);
                String tokenUrl = TemplateEngine.render(env.tokenUrl(), data, stepVars);

                System.out.println("    Fetching token from " + tokenUrl);
                Response tokenResp = Dispatcher.send(
                        "rest", "", tokenUrl, "POST",
                        tokenBody,
                        env.tokenHeaders(),
                        "none", "",
                        env.sslConfig()
                );

                if (tokenResp.error != null && !tokenResp.error.isEmpty()) {
                    // Token fetch failed - record as step 0 failure
                    StepResult sr = new StepResult();
                    sr.order = 0;
                    sr.name = "Auto token fetch";
                    sr.url = tokenUrl;
                    sr.method = "POST";
                    sr.requestBody = tokenBody;
                    sr.responseBody = tokenResp.body;
                    sr.status = tokenResp.status;
                    sr.expectedStatus = List.of(200);
                    sr.passed = false;
                    sr.error = "Token fetch failed: " + tokenResp.error;
                    results.add(sr);
                    return results;
                }

                // Extract access_token from JSON response
                String token = extractJsonField(tokenResp.body, "access_token");
                if (token == null || token.isEmpty()) {
                    StepResult sr = new StepResult();
                    sr.order = 0;
                    sr.name = "Auto token fetch";
                    sr.url = tokenUrl;
                    sr.method = "POST";
                    sr.requestBody = tokenBody;
                    sr.responseBody = tokenResp.body;
                    sr.status = tokenResp.status;
                    sr.expectedStatus = List.of(200);
                    sr.passed = false;
                    sr.error = "No access_token found in token response";
                    results.add(sr);
                    return results;
                }

                // Inject Bearer token into headers for all subsequent steps
                envHeaders.put("Authorization", "Bearer " + token);
                System.out.println("    Token acquired (" + token.length() + " chars)");

                // Record as a passed step 0 so it shows in the report
                StepResult sr = new StepResult();
                sr.order = 0;
                sr.name = "Auto token fetch";
                sr.url = tokenUrl;
                sr.method = "POST";
                sr.requestBody = "(form-urlencoded credentials)";
                sr.responseBody = tokenResp.body;
                sr.status = tokenResp.status;
                sr.expectedStatus = List.of(200);
                sr.elapsedMs = tokenResp.elapsedMs;
                sr.passed = true;
                results.add(sr);

            } catch (Exception ex) {
                StepResult sr = new StepResult();
                sr.order = 0;
                sr.name = "Auto token fetch";
                sr.url = env.tokenUrl();
                sr.method = "POST";
                sr.passed = false;
                sr.error = "Token fetch error: " + ex.getClass().getSimpleName()
                        + ": " + ex.getMessage();
                sr.errorDetail = formatException(ex);
                results.add(sr);
                return results;
            }
        }

        for (Step step : steps) {
            String endpoint = "";
            String body = "";
            Response resp;
            TemplateEngine.RenderLog renderLog = new TemplateEngine.RenderLog();
            // Resolve the per-source method, endpoint and body template up
            // front. For vs_protocol, source A and source B may differ in all
            // three (e.g. A = REST GET no body, B = SOAP POST with a template).
            String stepMethod = step.methodFor(source);
            String rawEndpoint = step.endpointFor(source);
            String bodyTemplate = step.bodyTemplateFor(source);
            try {
                endpoint = TemplateEngine.render(rawEndpoint, data, stepVars, renderLog);
                // The request body is driven by whether a BodyTemplate is
                // configured for THIS source - not by the HTTP method and not
                // by the other source. So source A (no template) sends nothing
                // while source B (SOAP template) sends its rendered XML, even
                // within the same logical step.
                if (bodyTemplate != null && !bodyTemplate.isEmpty()) {
                    // Resolve BodyTemplate against configured templates dir,
                    // with project root as fallback (handles the case where
                    // user wrote "templates/req.xml" in Excel).
                    body = TemplateEngine.renderFile(bodyTemplate, data, stepVars,
                            cfg.templatesDir, cfg.projectRoot, renderLog);
                }
            } catch (Throwable ex) {
                // ANY error during template processing (missing file, required
                // placeholder unresolved, IO error, etc.) becomes a failed step
                // in the report - never an uncaught exception that kills the
                // whole suite.
                StepResult sr = new StepResult();
                sr.order = step.order();
                sr.name = step.name();
                sr.url = rawEndpoint;
                sr.method = stepMethod;
                sr.requestBody = body;
                sr.responseBody = "";
                sr.status = 0;
                sr.expectedStatus = step.expectedStatus();
                sr.passed = false;
                sr.error = "Template error: " + ex.getClass().getSimpleName()
                        + ": " + ex.getMessage();
                sr.errorDetail = formatException(ex)
                        + (renderLog.summary().equals("Render log:\n") ? ""
                            : "\n\n" + renderLog.fullTrace());
                results.add(sr);
                continue;
            }

            // Merge environment-level headers (including auto-fetched token)
            // with step-level headers. Step headers override if same key.
            Map<String, String> finalHeaders = new LinkedHashMap<>();
            for (Map.Entry<String, String> e : envHeaders.entrySet()) {
                finalHeaders.put(e.getKey(),
                        TemplateEngine.render(e.getValue(), data, stepVars));
            }
            for (Map.Entry<String, String> e : step.extraHeaders().entrySet()) {
                finalHeaders.put(e.getKey(),
                        TemplateEngine.render(e.getValue(), data, stepVars));
            }

            try {
                resp = Dispatcher.send(
                        env.protocol(), env.baseUrl(), endpoint, stepMethod,
                        body, finalHeaders, env.authType(), env.authValue(),
                        env.sslConfig()
                );
            } catch (Throwable ex) {
                // Network / SSL / dispatch errors. Same pattern: record as a
                // failed step with diagnostic info, don't kill the suite.
                StepResult sr = new StepResult();
                sr.order = step.order();
                sr.name = step.name();
                sr.url = endpoint;
                sr.method = stepMethod;
                sr.requestBody = body;
                sr.responseBody = "";
                sr.status = 0;
                sr.expectedStatus = step.expectedStatus();
                sr.passed = false;
                sr.error = "Dispatch error: " + ex.getClass().getSimpleName()
                        + ": " + ex.getMessage();
                sr.errorDetail = formatException(ex);
                results.add(sr);
                continue;
            }

            Map<String, String> extracted = new LinkedHashMap<>();
            try {
                for (Map.Entry<String, String> ev : step.extractVars().entrySet()) {
                    // Pull every match the path resolves to, not just the first.
                    // A path that hits one value yields that value unchanged; a
                    // path that hits many (for example every id in a list) is
                    // joined with commas, which is exactly the form a db_rows
                    // assertion consumes as its expected set.
                    List<String> matches = Comparator.extractAllVariables(resp.body, ev.getValue());
                    String value = matches.isEmpty() ? ""
                            : matches.size() == 1 ? matches.get(0)
                            : String.join(",", matches);
                    extracted.put(ev.getKey(), value);
                }
            } catch (Throwable ex) {
                // Variable extraction errors shouldn't break the run - record
                // but continue. The step still completes.
                extracted.put("__extract_error__", ex.getMessage());
            }
            stepVars.put(step.order(), extracted);

            boolean passed = step.expectedStatus().contains(resp.status) && resp.error == null;

            Path stepDir = outputDir.resolve("step" + step.order() + "_"
                    + step.name().replaceAll("[^a-zA-Z0-9._-]", "_"));
            try {
                Files.createDirectories(stepDir);
                Files.writeString(stepDir.resolve("request.txt"),
                        stepMethod + " " + resp.url + "\n\n" + body);
                Files.writeString(stepDir.resolve("response.txt"),
                        "HTTP " + resp.status + "\nelapsed: " + resp.elapsedMs + "ms\n\n" + resp.body);
                // Persist the render log so the user has it on disk even when
                // the step otherwise passed. Useful when debugging "why did
                // some fields not appear in my request".
                if (!renderLog.summary().equals("Render log:\n")) {
                    Files.writeString(stepDir.resolve("render-log.txt"),
                            renderLog.fullTrace());
                }
            } catch (IOException ioEx) {
                // Disk error during artifact write. Note it but don't fail
                // the step on this alone.
                resp.error = (resp.error == null ? "" : resp.error + "; ")
                        + "Disk write failed: " + ioEx.getMessage();
            }

            StepResult sr = new StepResult();
            sr.name = step.name();
            sr.order = step.order();
            sr.method = stepMethod;
            sr.url = resp.url;
            sr.status = resp.status;
            sr.expectedStatus = step.expectedStatus();
            sr.elapsedMs = resp.elapsedMs;
            sr.requestBody = body;
            sr.responseBody = resp.body;
            sr.extracted = extracted;
            sr.error = resp.error;
            sr.passed = passed;
            results.add(sr);

            // Step-scoped assertions: any assertion bound to this step's order
            // runs now, against this step's response, with every variable
            // captured so far available to placeholders in its path and
            // expected value. Only source A carries assertions; source B exists
            // purely to produce a response to compare against.
            if (assertions != null && assertionSink != null && "A".equals(source)) {
                List<Assertion> forThisStep = new ArrayList<>();
                for (Assertion a : assertions) {
                    if (a.stepOrder() == step.order()) forThisStep.add(a);
                }
                if (!forThisStep.isEmpty()) {
                    List<Assertion> rendered = renderAssertions(forThisStep, data, stepVars);
                    assertionSink.addAll(
                            AssertionEngine.evaluate(resp.body, rendered, assertEnv));
                }
            }

            if (!passed) break;
        }
        return results;
    }

    /**
     * Replace any TestData value of the form {@code ${sql:ENV:QUERY}} or
     * {@code ${sql:QUERY}} with the result of running QUERY against a database.
     * ENV names the environment whose database to use; when omitted the query
     * runs against the test's own source A database. A query returning one value
     * yields that value; several values are joined with commas, which is the
     * form a db_rows assertion consumes. A failed or rejected query leaves a
     * readable error marker in the value so the failure surfaces in the report
     * rather than silently blanking the field.
     */
    private static void resolveSqlData(TestCase tc, TestSuite suite, Environment defaultEnv) {
        if (tc.data == null || tc.data.isEmpty()) return;
        for (Map.Entry<String, String> e : tc.data.entrySet()) {
            String raw = e.getValue();
            if (raw == null) continue;
            String trimmed = raw.trim();
            if (!trimmed.startsWith("${sql:") || !trimmed.endsWith("}")) continue;

            String inner = trimmed.substring(6, trimmed.length() - 1);
            // An optional environment name precedes the query, separated by the
            // first colon. The query may itself contain colons, so only the
            // first is treated as the separator, and only when what precedes it
            // is a known environment name.
            Environment target = defaultEnv;
            String query = inner;
            int colon = inner.indexOf(':');
            if (colon > 0) {
                String maybeEnv = inner.substring(0, colon).trim();
                if (suite.environments().containsKey(maybeEnv)) {
                    target = suite.environments().get(maybeEnv);
                    query = inner.substring(colon + 1);
                }
            }

            try {
                List<String> rows = DbQuery.firstColumn(target, query.trim());
                String value = rows.isEmpty() ? ""
                        : rows.size() == 1 ? rows.get(0)
                        : String.join(",", rows);
                e.setValue(value);
            } catch (Exception ex) {
                e.setValue("__SQL_ERROR__: " + ex.getMessage());
            }
        }
    }

    /**
     * Resolve {@code ${...}} placeholders in each assertion's path and expected
     * value using the data and step variables captured so far. This is what
     * lets a step-scoped assertion refer to a value produced by an earlier
     * step - for example a SQL query that filters on a server-generated id
     * carried in {@code ${step1.portfolioId}}. Assertions are otherwise left
     * exactly as written; only the two placeholder-bearing fields are rendered.
     */
    private static List<Assertion> renderAssertions(List<Assertion> assertions,
                                                    Map<String, String> data,
                                                    Map<Integer, Map<String, String>> stepVars) {
        List<Assertion> out = new ArrayList<>(assertions.size());
        for (Assertion a : assertions) {
            String path = TemplateEngine.render(a.path(), data, stepVars);
            String expected = a.expectedValue() == null ? null
                    : TemplateEngine.render(a.expectedValue(), data, stepVars);
            out.add(new Assertion(path, a.pathType(), a.operator(), expected,
                    a.description(), a.stepOrder(), a.decode()));
        }
        return out;
    }

    /**
     * Resolve a user-provided file path against a primary directory (e.g.
     * expectedDir / templatesDir), falling back to projectRoot.
     *
     * <p>A relative path must stay inside the directory it is resolved against.
     * Workbooks get shared between teams, so a path like {@code ../../etc/passwd}
     * silently reading a file outside the project - and pasting it into the HTML
     * report - is not something we want to allow. Absolute paths are still
     * honoured, since shared baselines legitimately live on network drives.
     *
     * @return the resolved file, or null if nothing matched or the path escaped
     */
    private static Path resolveFile(String userPath, Path primaryDir, Path projectRoot) {
        if (userPath == null || userPath.isEmpty()) return null;
        Path p = Path.of(userPath);
        if (p.isAbsolute()) return Files.exists(p) ? p : null;
        Path candidate = resolveContained(primaryDir, userPath);
        if (candidate != null) return candidate;
        return resolveContained(projectRoot, userPath);
    }

    /**
     * Resolve {@code userPath} under {@code base} and return it only if it
     * exists and has not escaped {@code base} via {@code ..} segments.
     */
    private static Path resolveContained(Path base, String userPath) {
        if (base == null) return null;
        Path candidate = base.resolve(userPath).normalize();
        if (!candidate.startsWith(base.normalize())) return null;
        return Files.exists(candidate) ? candidate : null;
    }

    /**
     * Extract a top-level string field from a JSON response.
     * Simple extraction without pulling in a full JSON library dependency
     * into the runner's hot path. Handles quoted string values.
     */
    private static String extractJsonField(String json, String field) {
        if (json == null || json.isEmpty()) return null;
        try {
            com.fasterxml.jackson.databind.JsonNode root =
                    new com.fasterxml.jackson.databind.ObjectMapper().readTree(json);
            com.fasterxml.jackson.databind.JsonNode node = root.get(field);
            if (node != null && !node.isNull()) {
                return node.asText();
            }
        } catch (Exception ignored) {}
        return null;
    }

    /**
     * Format an exception with full cause chain and stack trace for the
     * Diagnostics tab in the HTML report. The top-level message goes into
     * the short {@code error} field; this returns the long-form detail.
     */
    static String formatException(Throwable ex) {
        if (ex == null) return "";
        StringBuilder sb = new StringBuilder();
        Throwable cur = ex;
        int depth = 0;
        while (cur != null && depth < 10) {
            if (depth == 0) sb.append("Exception: ");
            else sb.append("\nCaused by: ");
            sb.append(cur.getClass().getName());
            String msg = cur.getMessage();
            if (msg != null && !msg.isEmpty()) sb.append(": ").append(msg);
            sb.append("\n");
            StackTraceElement[] trace = cur.getStackTrace();
            int shown = Math.min(trace.length, 15);
            for (int i = 0; i < shown; i++) {
                sb.append("    at ").append(trace[i]).append("\n");
            }
            if (trace.length > shown) {
                sb.append("    ... ").append(trace.length - shown).append(" more\n");
            }
            cur = cur.getCause();
            depth++;
        }
        return sb.toString();
    }
}
