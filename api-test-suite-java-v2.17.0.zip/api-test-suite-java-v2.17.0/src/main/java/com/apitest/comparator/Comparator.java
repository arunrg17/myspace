package com.apitest.comparator;

import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import com.apitest.model.DiffEntry;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.ReadContext;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import java.io.StringReader;
import java.util.*;

/**
 * Compare two payloads structurally with ignore-field support.
 *
 * Handles XML vs XML, JSON vs JSON, and cross-format (XML vs JSON) by
 * normalising XML into a JSON-like tree.
 */
public class Comparator {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Configuration JSONPATH_CFG = Configuration.builder()
            .options(Option.SUPPRESS_EXCEPTIONS)
            .build();

    /**
     * Detect whether a payload is XML, JSON, or plain text.
     * @return "xml", "json", "text", or "empty"
     */
    public static String detectFormat(String payload) {
        if (payload == null) return "empty";
        // Strip BOM + leading junk so a BOM-prefixed XML response is still
        // classified as XML rather than as "text".
        String s = sanitizeXmlProlog(payload).strip();
        if (s.isEmpty()) return "empty";
        if (s.startsWith("<")) return "xml";
        if (s.startsWith("{") || s.startsWith("[")) return "json";
        // Last-ditch: if the body contains an XML-looking start somewhere in
        // the first 500 chars (e.g. "garbage prefix <?xml ...?>"), treat as XML.
        int scan = Math.min(s.length(), 500);
        int xmlStart = s.indexOf("<?xml");
        if (xmlStart < 0) xmlStart = s.indexOf("<");
        if (xmlStart >= 0 && xmlStart < scan) return "xml";
        return "text";
    }

    /**
     * Unwrap CDATA-wrapped business XML and escaped XML content so that
     * comparison sees the real structure rather than treating it as text.
     *
     * Servers often return responses like:
     *     <ns:executeResponse>
     *       <return>
     *         <Envelope>
     *           <Content><![CDATA[<RealPayload>...</RealPayload>]]></Content>
     *         </Envelope>
     *       </return>
     *     </ns:executeResponse>
     *
     * For comparison against an expected file containing just `<RealPayload>...`,
     * we need to surface the inner payload. The strategy:
     *   1. If the input has &lt;...&gt; escaped XML, decode it
     *   2. If the input has <![CDATA[...]]> sections, unwrap them
     *   3. Repeat until stable (handles multi-layer wrapping)
     *
     * This is a no-op for payloads that don't have either pattern.
     */
    public static String extractInnerPayload(String payload) {
        if (payload == null || payload.isEmpty()) return payload;
        String prev;
        String current = payload;
        int passes = 0;
        do {
            prev = current;
            // Step 1: decode escaped XML chunks. Conservative - only triggers
            // if there are at least 3 escaped tag pairs.
            current = decodeEscapedXmlChunks(current);
            // Step 2: unwrap CDATA sections, but ONLY when they contain XML
            // (looks like <tag...>). CDATA wrapping non-XML text is left alone.
            current = unwrapXmlBearingCdata(current);
            passes++;
            if (passes > 6) break;
        } while (!current.equals(prev));
        return current;
    }

    /**
     * Decode runs of escaped XML (&lt;tag&gt;...) back into real markup.
     * Only triggers when several escaped tag pairs are present, so ordinary
     * text containing a stray &lt; is left untouched.
     */
    private static String decodeEscapedXmlChunks(String s) {
        if (s == null || !s.contains("&lt;")) return s;
        int hits = 0, idx = 0;
        while ((idx = s.indexOf("&lt;", idx)) != -1) {
            hits++;
            idx += 4;
            if (hits >= 3) break;
        }
        if (hits < 3) return s;
        return s.replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'")
                .replace("&amp;", "&");
    }

    /**
     * Unwrap CDATA sections that contain XML so the inner markup can be
     * compared. CDATA wrapping non-XML text is left as-is.
     */
    private static String unwrapXmlBearingCdata(String s) {
        if (s == null || !s.contains("<![CDATA[")) return s;
        StringBuilder out = new StringBuilder(s.length());
        int idx = 0;
        while (idx < s.length()) {
            int start = s.indexOf("<![CDATA[", idx);
            if (start < 0) {
                out.append(s, idx, s.length());
                break;
            }
            int end = s.indexOf("]]>", start + 9);
            if (end < 0) {
                out.append(s, idx, s.length());
                break;
            }
            String inner = s.substring(start + 9, end);
            // Only unwrap if the inner content looks like XML.
            // Plain-text CDATA (e.g. <Description><![CDATA[Hello, world!]]>)
            // should stay wrapped.
            boolean looksXml = inner.trim().startsWith("<");
            out.append(s, idx, start);
            if (looksXml) {
                out.append(inner);
            } else {
                out.append(s, start, end + 3);
            }
            idx = end + 3;
        }
        return out.toString();
    }

    /**
     * Get the local name (without prefix) of the first real element in a
     * payload. Skips XML declarations, comments, and processing instructions.
     * Returns null if no element is found.
     */
    private static String topLevelElementName(String xml) {
        if (xml == null) return null;
        int idx = 0;
        while (idx < xml.length()) {
            int lt = xml.indexOf('<', idx);
            if (lt < 0) return null;
            if (xml.startsWith("<?", lt)) {
                int e = xml.indexOf("?>", lt + 2);
                idx = e < 0 ? xml.length() : e + 2;
                continue;
            }
            if (xml.startsWith("<!--", lt)) {
                int e = xml.indexOf("-->", lt + 4);
                idx = e < 0 ? xml.length() : e + 3;
                continue;
            }
            if (xml.startsWith("<!", lt)) {
                int e = xml.indexOf('>', lt);
                idx = e < 0 ? xml.length() : e + 1;
                continue;
            }
            int nameStart = lt + 1;
            int nameEnd = nameStart;
            while (nameEnd < xml.length()) {
                char c = xml.charAt(nameEnd);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '>' || c == '/') break;
                nameEnd++;
            }
            String name = xml.substring(nameStart, nameEnd);
            // Strip namespace prefix
            int colon = name.indexOf(':');
            return colon < 0 ? name : name.substring(colon + 1);
        }
        return null;
    }

    /**
     * Find the first element with the given local name in the payload and
     * return its outer XML (open tag through matching close tag).
     * Returns null if not found. Used to anchor comparison on the expected's
     * top-level element when the actual is wrapped in SOAP envelopes.
     */
    private static String findElementBlock(String xml, String localName) {
        if (xml == null || localName == null) return null;
        int idx = 0;
        while (idx < xml.length()) {
            int lt = xml.indexOf('<', idx);
            if (lt < 0) return null;
            if (xml.startsWith("<?", lt) || xml.startsWith("<!--", lt) || xml.startsWith("<!", lt)) {
                int e = xml.indexOf('>', lt);
                idx = e < 0 ? xml.length() : e + 1;
                continue;
            }
            if (xml.startsWith("</", lt)) {
                int e = xml.indexOf('>', lt);
                idx = e < 0 ? xml.length() : e + 1;
                continue;
            }
            int nameStart = lt + 1;
            int nameEnd = nameStart;
            while (nameEnd < xml.length()) {
                char c = xml.charAt(nameEnd);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '>' || c == '/') break;
                nameEnd++;
            }
            String name = xml.substring(nameStart, nameEnd);
            int colon = name.indexOf(':');
            String local = colon < 0 ? name : name.substring(colon + 1);
            if (local.equals(localName)) {
                // Find the close of this element
                int gt = xml.indexOf('>', nameEnd);
                if (gt < 0) return null;
                if (gt > 0 && xml.charAt(gt - 1) == '/') {
                    return xml.substring(lt, gt + 1);
                }
                // Find matching close, respecting nesting
                int depth = 1;
                int scan = gt + 1;
                while (scan < xml.length() && depth > 0) {
                    int next = xml.indexOf('<', scan);
                    if (next < 0) return null;
                    if (xml.startsWith("<!--", next)) {
                        int e = xml.indexOf("-->", next + 4);
                        scan = e < 0 ? xml.length() : e + 3;
                        continue;
                    }
                    if (xml.startsWith("<![CDATA[", next)) {
                        int e = xml.indexOf("]]>", next + 9);
                        scan = e < 0 ? xml.length() : e + 3;
                        continue;
                    }
                    if (xml.startsWith("<?", next)) {
                        int e = xml.indexOf("?>", next + 2);
                        scan = e < 0 ? xml.length() : e + 2;
                        continue;
                    }
                    boolean isClose = xml.startsWith("</", next);
                    int ns = next + (isClose ? 2 : 1);
                    int ne = ns;
                    while (ne < xml.length()) {
                        char c = xml.charAt(ne);
                        if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '>' || c == '/') break;
                        ne++;
                    }
                    String n2 = xml.substring(ns, ne);
                    int c2 = n2.indexOf(':');
                    String l2 = c2 < 0 ? n2 : n2.substring(c2 + 1);
                    int gt2 = xml.indexOf('>', ne);
                    if (gt2 < 0) return null;
                    if (l2.equals(localName)) {
                        if (isClose) {
                            depth--;
                            if (depth == 0) return xml.substring(lt, gt2 + 1);
                        } else {
                            boolean selfClose = gt2 > 0 && xml.charAt(gt2 - 1) == '/';
                            if (!selfClose) depth++;
                        }
                    }
                    scan = gt2 + 1;
                }
                return null;
            }
            idx = nameEnd;
        }
        return null;
    }

    /**
     * Compare two payloads structurally and report the differences.
     *
     * <p>Both sides are first unwrapped (SOAP envelopes, CDATA, escaped XML)
     * and normalised to a common map/list structure, so an XML response and a
     * JSON response with the same data compare as equal. Ignore directives
     * (by XPath or JSONPath) blank out fields that are expected to vary, such
     * as timestamps and trace IDs. Repeated child elements are matched
     * order-insensitively. The prepared (cleaned) payloads are stored on the
     * result so the report can show what was actually compared.
     *
     * @param expected   the baseline / source-A payload
     * @param actual     the candidate / source-B payload
     * @param assertions assertions whose {@code ignore} entries are applied here
     * @return the comparison result, with {@code matched} and a list of diffs
     */
    public static CompareResult compare(String expected, String actual, List<Assertion> assertions) {
        return compare(expected, actual, assertions, null);
    }

    /**
     * Compare two payloads, first decoding any fields named by
     * {@code decodePaths}.
     *
     * <p>Each entry is a JSONPath naming a field whose content is base64. Both
     * sides are decoded at those paths before anything else happens, so the
     * structural comparison that follows sees the real inner content rather
     * than two opaque strings. That matters because base64 is not canonical:
     * the same content can encode differently, which would otherwise show up
     * as a difference that is not real, and a genuine difference would only be
     * reported as "these two long strings differ" with no indication where.
     *
     * <p>Passing null or an empty list is exactly the historical behaviour -
     * no decoding is attempted and the payloads are compared as they arrive.
     * A field that is named but cannot be decoded is left untouched rather
     * than failing the whole comparison, and the result note records it, so a
     * mis-typed path degrades to the old behaviour visibly instead of throwing.
     *
     * @param expected    the baseline / source-A payload
     * @param actual      the candidate / source-B payload
     * @param assertions  assertions whose {@code ignore} entries are applied here
     * @param decodePaths JSONPaths of base64 fields to decode on both sides
     */
    public static CompareResult compare(String expected, String actual,
                                        List<Assertion> assertions,
                                        List<String> decodePaths) {
        String decodeNote = "";
        if (decodePaths != null && !decodePaths.isEmpty()) {
            DecodeOutcome de = decodeAtPaths(expected, decodePaths);
            DecodeOutcome da = decodeAtPaths(actual, decodePaths);
            expected = de.payload;
            actual = da.payload;
            int done = de.decoded + da.decoded;
            int failed = de.failed + da.failed;
            decodeNote = "decoded " + done + " field(s)"
                    + (failed > 0 ? ", " + failed + " left as-is (not valid base64)" : "");
        }

        CompareResult result = compareInternal(expected, actual, assertions);
        if (!decodeNote.isEmpty()) {
            result.note = result.note == null || result.note.isEmpty()
                    ? decodeNote : result.note + "; " + decodeNote;
        }
        return result;
    }

    /** Counts from one side's decode pass. */
    private static final class DecodeOutcome {
        final String payload;
        final int decoded;
        final int failed;
        DecodeOutcome(String payload, int decoded, int failed) {
            this.payload = payload;
            this.decoded = decoded;
            this.failed = failed;
        }
    }

    /**
     * Replace the value at each JSONPath with its base64-decoded text. Works on
     * the parsed tree and writes the document back out, so a path that matches
     * several nodes (a wildcard over repeated sections) decodes every match. A
     * payload that is not JSON, or a path that matches nothing, is returned
     * unchanged - decoding is only ever additive to what the comparison can
     * see, never destructive.
     */
    private static DecodeOutcome decodeAtPaths(String payload, List<String> paths) {
        if (payload == null || payload.isEmpty()) return new DecodeOutcome(payload, 0, 0);
        if (!"json".equals(detectFormat(payload))) return new DecodeOutcome(payload, 0, 0);

        int decoded = 0;
        int failed = 0;
        try {
            com.jayway.jsonpath.DocumentContext ctx =
                    com.jayway.jsonpath.JsonPath.using(JSONPATH_CFG).parse(payload);
            java.util.Base64.Decoder decoder = java.util.Base64.getDecoder();

            for (String path : paths) {
                String p = path == null ? "" : path.trim();
                if (p.isEmpty()) continue;
                List<String> found;
                try {
                    found = extractAllVariables(payload, p);
                } catch (Exception ex) {
                    continue;
                }
                if (found.isEmpty()) continue;

                for (String raw : found) {
                    if (raw == null || raw.isEmpty()) continue;
                    String text;
                    try {
                        text = new String(decoder.decode(raw.trim()),
                                java.nio.charset.StandardCharsets.UTF_8);
                    } catch (IllegalArgumentException ex) {
                        failed++;
                        continue;
                    }
                    // When the decoded text is itself JSON, put it back as a
                    // parsed structure rather than a string. That is the whole
                    // point: the comparison then walks the inner document field
                    // by field, so formatting differences in the encoded form
                    // do not register as differences and a real difference is
                    // reported at the field where it actually is. Anything that
                    // is not JSON goes back as plain text.
                    Object replacement = text;
                    String trimmedText = text.trim();
                    if (trimmedText.startsWith("{") || trimmedText.startsWith("[")) {
                        try {
                            replacement = com.jayway.jsonpath.JsonPath.using(JSONPATH_CFG)
                                    .parse(trimmedText).json();
                        } catch (Exception ex) {
                            replacement = text;
                        }
                    }
                    final Object rep = replacement;
                    try {
                        // Replace every node matching the path whose current
                        // value is this exact encoded string.
                        ctx.map(p, (current, cfg) ->
                                raw.equals(String.valueOf(current)) ? rep : current);
                        decoded++;
                    } catch (Exception ex) {
                        failed++;
                    }
                }
            }
            return new DecodeOutcome(ctx.jsonString(), decoded, failed);
        } catch (Exception ex) {
            // Anything unexpected leaves the payload exactly as it arrived.
            return new DecodeOutcome(payload, 0, 0);
        }
    }

    private static CompareResult compareInternal(String expected, String actual, List<Assertion> assertions) {
        CompareResult result = new CompareResult();
        if (assertions == null) assertions = List.of();

        // Pre-process: if either side wraps the meaningful business payload
        // inside CDATA (a common SOAP pattern: <arg0><![CDATA[<actual/>]]></arg0>),
        // unwrap it so the comparison sees the real elements rather than the
        // CDATA-as-text. This matches how a human reads the response.
        String expectedPrepared = extractInnerPayload(expected);
        String actualPrepared   = extractInnerPayload(actual);

        // If the expected file is a clean business payload (single root) and
        // the actual is wrapped in SOAP envelopes / arg containers, anchor
        // the comparison on the expected's root element name found anywhere
        // in the unwrapped actual. This makes "expected vs response" useful
        // out of the box without forcing the user to also write the wrapper
        // structure in their expected file.
        String expectedRoot = topLevelElementName(expectedPrepared);
        if (expectedRoot != null) {
            String anchored = findElementBlock(actualPrepared, expectedRoot);
            if (anchored != null) {
                actualPrepared = anchored;
            }
        }

        String fmtA = detectFormat(expectedPrepared);
        String fmtB = detectFormat(actualPrepared);

        if ("empty".equals(fmtA) || "empty".equals(fmtB)) {
            result.matched = false;
            result.note = "One side is empty";
            return result;
        }

        List<String> xpathIgnores = new ArrayList<>();
        List<String> jsonpathIgnores = new ArrayList<>();
        for (Assertion a : assertions) {
            if (!"ignore".equalsIgnoreCase(a.operator())) continue;
            if ("xpath".equalsIgnoreCase(a.pathType())) xpathIgnores.add(a.path());
            else if ("jsonpath".equalsIgnoreCase(a.pathType())) jsonpathIgnores.add(a.path());
        }

        try {
            Object objA, objB;
            if ("xml".equals(fmtA) && "xml".equals(fmtB)) {
                objA = xmlToMap(applyXpathIgnores(expectedPrepared, xpathIgnores));
                objB = xmlToMap(applyXpathIgnores(actualPrepared, xpathIgnores));
                applyJsonpathIgnores(objA, jsonpathIgnores);
                applyJsonpathIgnores(objB, jsonpathIgnores);
                result.note = "xml vs xml";
            } else if ("json".equals(fmtA) && "json".equals(fmtB)) {
                objA = jsonToMap(expectedPrepared);
                objB = jsonToMap(actualPrepared);
                applyJsonpathIgnores(objA, jsonpathIgnores);
                applyJsonpathIgnores(objB, jsonpathIgnores);
                result.note = "json vs json";
            } else {
                objA = "xml".equals(fmtA) ? xmlToMap(applyXpathIgnores(expectedPrepared, xpathIgnores)) : jsonToMap(expectedPrepared);
                objB = "xml".equals(fmtB) ? xmlToMap(applyXpathIgnores(actualPrepared, xpathIgnores)) : jsonToMap(actualPrepared);
                applyJsonpathIgnores(objA, jsonpathIgnores);
                applyJsonpathIgnores(objB, jsonpathIgnores);
                // Cross-format (JSON vs XML/SOAP): the two trees have different
                // key casing, wrappers, attribute-vs-field placement, nesting
                // depth and number formats even when the data is identical.
                // Canonicalize both sides, reduce each to a list of flat
                // business records, and diff those records matched by business
                // key. This collapses all representation differences so only
                // real data differences remain. Same-format paths above are
                // untouched.
                Object canonA = CrossFormatCanonicalizer.canonicalize(objA);
                Object canonB = CrossFormatCanonicalizer.canonicalize(objB);
                // Pick a strategy from the payload shape. A collection payload
                // (a repeated list of business records) is flattened and matched
                // by business key. A single rich document must NOT be reduced to
                // its largest inner list - that would silently discard the rest
                // of the tree - so it gets a recursive structural diff that
                // bridges the representation gaps instead.
                if (CrossFormatCanonicalizer.isCollectionPayload(canonA)
                        || CrossFormatCanonicalizer.isCollectionPayload(canonB)) {
                    List<java.util.Map<String, Object>> recA = CrossFormatCanonicalizer.toRecords(canonA);
                    List<java.util.Map<String, Object>> recB = CrossFormatCanonicalizer.toRecords(canonB);
                    diffRecords(recA, recB, result.diffs);
                    result.note = fmtA + " vs " + fmtB + " (cross-format, records)";
                } else {
                    structuralDiff(CrossFormatCanonicalizer.dropHeaderBlocks(canonA),
                                   CrossFormatCanonicalizer.dropHeaderBlocks(canonB),
                                   "$", result.diffs);
                    result.note = fmtA + " vs " + fmtB + " (cross-format, document)";
                }
                result.matched = result.diffs.isEmpty();
                // Skip the generic diff below - already compared above.
                objA = null;
                objB = null;
            }

            if (objA != null || objB != null) {
                diff(objA, objB, "$", result.diffs);
                result.matched = result.diffs.isEmpty();
            }
        } catch (Exception ex) {
            result.matched = false;
            result.note = "Parse error: " + ex.getMessage();
        }

        // Expose the prepared (unwrapped, pretty-printed when XML) payloads
        // so the HTML report can show users what was actually compared.
        // This is essential when the actual response was deeply wrapped
        // (SOAP envelope + CDATA + escaped XML) and the user needs to see
        // the cleaned form to make sense of the diff.
        result.preparedExpected = prettyPrintIfXml(expectedPrepared);
        result.preparedActual   = prettyPrintIfXml(actualPrepared);
        return result;
    }

    /** If the input looks like XML, return an indented version; otherwise return as-is. */
    private static String prettyPrintIfXml(String s) {
        if (s == null || s.isEmpty()) return s;
        String trimmed = s.trim();
        if (!trimmed.startsWith("<")) return s;
        try {
            javax.xml.parsers.DocumentBuilderFactory dbf =
                    javax.xml.parsers.DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            hardenXxe(dbf);
            javax.xml.parsers.DocumentBuilder b = dbf.newDocumentBuilder();
            java.io.PrintStream origErr = System.err;
            org.w3c.dom.Document doc;
            try {
                System.setErr(new java.io.PrintStream(java.io.OutputStream.nullOutputStream()));
                doc = b.parse(new org.xml.sax.InputSource(new java.io.StringReader(trimmed)));
            } finally {
                System.setErr(origErr);
            }
            // Strip whitespace-only text nodes so indent looks clean
            stripWhitespaceTextNodes(doc.getDocumentElement());
            javax.xml.transform.TransformerFactory tf = javax.xml.transform.TransformerFactory.newInstance();
            try {
                tf.setAttribute(javax.xml.XMLConstants.ACCESS_EXTERNAL_DTD, "");
                tf.setAttribute(javax.xml.XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
            } catch (Exception ignore) { /* best-effort */ }
            javax.xml.transform.Transformer t = tf.newTransformer();
            t.setOutputProperty(javax.xml.transform.OutputKeys.INDENT, "yes");
            t.setOutputProperty(javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION, "yes");
            t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            java.io.StringWriter sw = new java.io.StringWriter();
            t.transform(new javax.xml.transform.dom.DOMSource(doc),
                    new javax.xml.transform.stream.StreamResult(sw));
            return sw.toString();
        } catch (Exception ex) {
            return s;
        }
    }

    /** Remove whitespace-only text nodes so pretty-printed XML indents cleanly. */
    private static void stripWhitespaceTextNodes(org.w3c.dom.Node node) {
        if (node == null) return;
        org.w3c.dom.NodeList kids = node.getChildNodes();
        java.util.List<org.w3c.dom.Node> toRemove = new java.util.ArrayList<>();
        boolean hasElementChild = false;
        for (int i = 0; i < kids.getLength(); i++) {
            if (kids.item(i).getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
                hasElementChild = true;
                break;
            }
        }
        if (hasElementChild) {
            for (int i = 0; i < kids.getLength(); i++) {
                org.w3c.dom.Node k = kids.item(i);
                if (k.getNodeType() == org.w3c.dom.Node.TEXT_NODE
                        && k.getNodeValue() != null
                        && k.getNodeValue().trim().isEmpty()) {
                    toRemove.add(k);
                }
            }
            for (org.w3c.dom.Node n : toRemove) node.removeChild(n);
        }
        for (int i = 0; i < kids.getLength(); i++) {
            if (kids.item(i).getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
                stripWhitespaceTextNodes(kids.item(i));
            }
        }
    }

    // ------------------------------------------------------------------
    // Format conversion
    // ------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    /** Parse a JSON string into nested Map/List/scalar objects. */
    public static Object jsonToMap(String json) throws Exception {
        JsonNode node = MAPPER.readTree(json);
        return jsonNodeToObject(node);
    }

    /** Recursively convert a Jackson JsonNode into plain Map/List/scalar objects. */
    private static Object jsonNodeToObject(JsonNode node) {
        if (node.isObject()) {
            Map<String, Object> map = new LinkedHashMap<>();
            node.fields().forEachRemaining(e -> map.put(e.getKey(), jsonNodeToObject(e.getValue())));
            return map;
        }
        if (node.isArray()) {
            List<Object> list = new ArrayList<>();
            node.forEach(c -> list.add(jsonNodeToObject(c)));
            return list;
        }
        if (node.isNumber()) return node.numberValue();
        if (node.isBoolean()) return node.booleanValue();
        if (node.isNull()) return null;
        return node.asText();
    }

    /** Parse an XML string into the same nested Map/List structure used for JSON. */
    public static Object xmlToMap(String xml) throws Exception {
        // Apply the same defensive sanitization + recovery as extractVariable
        // so malformed responses can still be compared.
        String sanitized = sanitizeXmlProlog(xml).replace("\r\n", "\n").replace("\r", "");
        Document doc = parseWithRecovery(sanitized);
        if (doc == null) {
            throw new IllegalStateException(
                    "XML is malformed and unrecoverable. First 200 chars: "
                            + safePreview(sanitized, 200));
        }
        Node root = doc.getDocumentElement();
        Map<String, Object> wrapper = new LinkedHashMap<>();
        wrapper.put(localName(root.getNodeName()), elementToObject(root));
        return wrapper;
    }

    @SuppressWarnings("unchecked")
    /**
     * Recursively convert a DOM element into Map/List/scalar form. Repeated
     * child element names become lists; leaf elements become their text value.
     */
    private static Object elementToObject(Node elem) {
        List<Node> children = new ArrayList<>();
        NodeList nl = elem.getChildNodes();
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < nl.getLength(); i++) {
            Node c = nl.item(i);
            if (c.getNodeType() == Node.ELEMENT_NODE) children.add(c);
            else if (c.getNodeType() == Node.TEXT_NODE || c.getNodeType() == Node.CDATA_SECTION_NODE) {
                text.append(c.getNodeValue());
            }
        }

        NamedNodeMap attrs = elem.getAttributes();
        if (children.isEmpty()) {
            String t = text.toString().trim();
            if (attrs == null || attrs.getLength() == 0) return t;
            Map<String, Object> map = new LinkedHashMap<>();
            for (int i = 0; i < attrs.getLength(); i++) {
                Node a = attrs.item(i);
                if (isNamespaceAttr(a)) continue;
                map.put("@" + localName(a.getNodeName()), a.getNodeValue());
            }
            if (map.isEmpty()) return t;
            if (!t.isEmpty()) map.put("#text", t);
            return map;
        }

        Map<String, Object> map = new LinkedHashMap<>();
        for (Node child : children) {
            String key = localName(child.getNodeName());
            Object value = elementToObject(child);
            if (map.containsKey(key)) {
                Object existing = map.get(key);
                if (existing instanceof List) {
                    ((List<Object>) existing).add(value);
                } else {
                    List<Object> list = new ArrayList<>();
                    list.add(existing);
                    list.add(value);
                    map.put(key, list);
                }
            } else {
                map.put(key, value);
            }
        }
        if (attrs != null) {
            for (int i = 0; i < attrs.getLength(); i++) {
                Node a = attrs.item(i);
                if (isNamespaceAttr(a)) continue;
                map.put("@" + localName(a.getNodeName()), a.getNodeValue());
            }
        }
        return map;
    }

    /** @return true if the attribute is an xmlns namespace declaration. */
    private static boolean isNamespaceAttr(Node a) {
        String n = a.getNodeName();
        return "xmlns".equals(n) || n.startsWith("xmlns:");
    }

    private static String localName(String qname) {
        int idx = qname.indexOf(':');
        return idx >= 0 ? qname.substring(idx + 1) : qname;
    }

    // ------------------------------------------------------------------
    // Ignore application
    // ------------------------------------------------------------------

    /** Blank out every XML node matching an ignore XPath before comparison. */
    private static String applyXpathIgnores(String xml, List<String> patterns) {
        if (patterns.isEmpty()) return xml;
        try {
            String sanitized = sanitizeXmlProlog(xml).replace("\r\n", "\n").replace("\r", "");
            Document doc = parseWithRecovery(sanitized);
            if (doc == null) return xml;  // fall through; downstream will report it
            XPath xp = XPathFactory.newInstance().newXPath();
            for (String pat : patterns) {
                try {
                    NodeList nodes = (NodeList) xp.evaluate(pat, doc, XPathConstants.NODESET);
                    for (int i = 0; i < nodes.getLength(); i++) {
                        nodes.item(i).setTextContent("__IGNORED__");
                    }
                } catch (Exception ignore) {}
            }
            javax.xml.transform.TransformerFactory tf2 = javax.xml.transform.TransformerFactory.newInstance();
            try {
                tf2.setAttribute(javax.xml.XMLConstants.ACCESS_EXTERNAL_DTD, "");
                tf2.setAttribute(javax.xml.XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
            } catch (Exception ignore) { /* best-effort */ }
            javax.xml.transform.Transformer t = tf2.newTransformer();
            java.io.StringWriter sw = new java.io.StringWriter();
            t.transform(new javax.xml.transform.dom.DOMSource(doc), new javax.xml.transform.stream.StreamResult(sw));
            return sw.toString();
        } catch (Exception ex) {
            return xml;
        }
    }

    @SuppressWarnings("unchecked")
    /** Blank out every JSON value matching an ignore JSONPath before comparison. */
    private static void applyJsonpathIgnores(Object obj, List<String> patterns) {
        if (patterns.isEmpty()) return;
        try {
            String json = MAPPER.writeValueAsString(obj);
            ReadContext ctx = JsonPath.using(JSONPATH_CFG).parse(json);
            Object doc = ctx.json();
            for (String pat : patterns) {
                try {
                    JsonPath.using(JSONPATH_CFG).parse(doc).set(pat, "__IGNORED__");
                } catch (Exception ignore) {}
            }
            // Copy patched back into obj
            if (obj instanceof Map && doc instanceof Map) {
                ((Map<String, Object>) obj).clear();
                ((Map<String, Object>) obj).putAll((Map<String, Object>) doc);
            }
        } catch (Exception ignore) {}
    }

    // ------------------------------------------------------------------
    // Recursive diff
    // ------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    /**
     * Recursively compare two normalised values and record any differences.
     * Handles maps (compared by key), lists (compared order-insensitively via
     * {@link #diffLists}), numbers (compared numerically), and scalars.
     *
     * @param a     expected value
     * @param b     actual value
     * @param path  JSON-path-style location, used in diff messages
     * @param diffs accumulator for differences found
     */
    public static void diff(Object a, Object b, String path, List<DiffEntry> diffs) {
        if ("__IGNORED__".equals(a) || "__IGNORED__".equals(b)) return;
        if (a == null && b == null) return;
        if (a == null) {
            diffs.add(new DiffEntry(path, "<missing>", String.valueOf(b), "removed"));
            return;
        }
        if (b == null) {
            diffs.add(new DiffEntry(path, String.valueOf(a), "<missing>", "added"));
            return;
        }

        // Numeric tolerance: treat numbers as numbers regardless of int/double
        if (a instanceof Number && b instanceof Number) {
            if (((Number) a).doubleValue() != ((Number) b).doubleValue()) {
                diffs.add(new DiffEntry(path, a.toString(), b.toString(), "value"));
            }
            return;
        }

        if (a.getClass() != b.getClass() && !(a instanceof Map && b instanceof Map)
                && !(a instanceof List && b instanceof List)) {
            // Treat numeric strings vs numbers as a value mismatch
            diffs.add(new DiffEntry(path, a.toString(), b.toString(), "type"));
            return;
        }

        if (a instanceof Map && b instanceof Map) {
            Map<String, Object> ma = (Map<String, Object>) a;
            Map<String, Object> mb = (Map<String, Object>) b;
            Set<String> keys = new TreeSet<>();
            keys.addAll(ma.keySet());
            keys.addAll(mb.keySet());
            for (String k : keys) {
                String childPath = path + "." + k;
                if (!ma.containsKey(k)) diffs.add(new DiffEntry(childPath, "<missing>", String.valueOf(mb.get(k)), "added"));
                else if (!mb.containsKey(k)) diffs.add(new DiffEntry(childPath, String.valueOf(ma.get(k)), "<missing>", "removed"));
                else diff(ma.get(k), mb.get(k), childPath, diffs);
            }
            return;
        }

        if (a instanceof List && b instanceof List) {
            List<Object> la = (List<Object>) a;
            List<Object> lb = (List<Object>) b;
            diffLists(la, lb, path, diffs);
            return;
        }

        if (!Objects.equals(a, b)) {
            diffs.add(new DiffEntry(path, a.toString(), b.toString(), "value"));
        }
    }

    /**
     * Compare two lists without assuming the elements are in the same order.
     *
     * <p>Many APIs return repeated child elements (line items, accounts, etc.)
     * in an order that isn't guaranteed and can differ between two systems
     * even though the data is identical. A naive index-by-index comparison
     * reports every shifted element as a difference, which floods the report
     * with false positives.
     *
     * <p>This method instead matches greedily: for each element in the
     * expected list it looks for an element in the actual list that compares
     * with zero differences, and pairs them up. Elements that find an exact
     * partner are removed from both sides. Whatever is left over is then
     * compared positionally so genuine value differences are still reported,
     * and any true surplus/shortfall is flagged as added/removed.
     *
     * <p>Consequences:
     * <ul>
     *   <li>Lists that already line up in order still match (the first probe
     *       finds the same-index element), so existing behaviour is preserved.
     *   <li>Lists with the same content in a different order now match.
     *   <li>Lists with genuine differences still report those differences.
     * </ul>
     *
     * @param la    expected list
     * @param lb    actual list
     * @param path  JSON-path-style location of this list, for diff messages
     * @param diffs accumulator for any differences found
     */
    private static void diffLists(List<Object> la, List<Object> lb, String path, List<DiffEntry> diffs) {
        // Track which actual-side elements are still available to match.
        boolean[] usedB = new boolean[lb.size()];
        // Expected-side indices that didn't find an exact partner.
        List<Integer> unmatchedA = new ArrayList<>();

        // Pass 1: pair each expected element with an exact (zero-diff) actual
        // element that hasn't been claimed yet.
        for (int i = 0; i < la.size(); i++) {
            int matchIdx = -1;
            for (int j = 0; j < lb.size(); j++) {
                if (usedB[j]) continue;
                List<DiffEntry> probe = new ArrayList<>();
                diff(la.get(i), lb.get(j), path, probe);
                if (probe.isEmpty()) {   // exact structural match
                    matchIdx = j;
                    break;
                }
            }
            if (matchIdx >= 0) {
                usedB[matchIdx] = true;
            } else {
                unmatchedA.add(i);
            }
        }

        // Collect the actual-side elements that were never matched.
        List<Integer> unmatchedB = new ArrayList<>();
        for (int j = 0; j < lb.size(); j++) {
            if (!usedB[j]) unmatchedB.add(j);
        }

        // Pass 2: pair leftover elements positionally and report their
        // differences, so a changed value inside an element is still shown.
        int pairs = Math.min(unmatchedA.size(), unmatchedB.size());
        for (int k = 0; k < pairs; k++) {
            int ai = unmatchedA.get(k);
            int bj = unmatchedB.get(k);
            diff(la.get(ai), lb.get(bj), path + "[" + ai + "]", diffs);
        }

        // Pass 3: report any true surplus/shortfall.
        for (int k = pairs; k < unmatchedA.size(); k++) {
            int ai = unmatchedA.get(k);
            diffs.add(new DiffEntry(path + "[" + ai + "]",
                    String.valueOf(la.get(ai)), "<missing>", "removed"));
        }
        for (int k = pairs; k < unmatchedB.size(); k++) {
            int bj = unmatchedB.get(k);
            diffs.add(new DiffEntry(path + "[" + bj + "]",
                    "<missing>", String.valueOf(lb.get(bj)), "added"));
        }
    }

    /**
     * Recursive structural comparison of two canonical trees, used for
     * cross-format <em>single documents</em> (as opposed to a repeated list of
     * records, which goes through {@link #diffRecords}).
     *
     * <p>Both sides have already been canonicalized (keys folded, attributes
     * folded into fields, scalars normalized), so this walks the two trees in
     * parallel and reports only genuine differences. It bridges two remaining
     * representation gaps:
     * <ul>
     *   <li>a single XML element vs a one-element JSON array - a lone
     *       {@code <PhoneNumber>} lines up with {@code "phoneNumber": [{...}]}</li>
     *   <li>list ordering - elements are matched by content, not position</li>
     * </ul>
     *
     * @param a     canonical value from side A
     * @param b     canonical value from side B
     * @param path  current path, for reporting
     * @param diffs accumulator
     */
    private static void structuralDiff(Object a, Object b, String path, List<DiffEntry> diffs) {
        // Bridge "one element" vs "one-element array" before anything else.
        Object left = unwrapSingleton(a, b);
        Object right = unwrapSingleton(b, a);

        if (left == null && right == null) return;
        if (left == null) {
            diffs.add(new DiffEntry(path, "<missing>", String.valueOf(right), "added"));
            return;
        }
        if (right == null) {
            diffs.add(new DiffEntry(path, String.valueOf(left), "<missing>", "removed"));
            return;
        }

        if (left instanceof Map && right instanceof Map) {
            @SuppressWarnings("unchecked") Map<String, Object> ma = (Map<String, Object>) left;
            @SuppressWarnings("unchecked") Map<String, Object> mb = (Map<String, Object>) right;
            Set<String> keys = new TreeSet<>();
            keys.addAll(ma.keySet());
            keys.addAll(mb.keySet());
            for (String k : keys) {
                String childPath = path + "." + k;
                boolean inA = ma.containsKey(k), inB = mb.containsKey(k);
                if (inA && inB) {
                    structuralDiff(ma.get(k), mb.get(k), childPath, diffs);
                } else if (inA) {
                    diffs.add(new DiffEntry(childPath, String.valueOf(ma.get(k)), "<missing>", "removed"));
                } else {
                    diffs.add(new DiffEntry(childPath, "<missing>", String.valueOf(mb.get(k)), "added"));
                }
            }
            return;
        }

        if (left instanceof List && right instanceof List) {
            @SuppressWarnings("unchecked") List<Object> la = (List<Object>) left;
            @SuppressWarnings("unchecked") List<Object> lb = (List<Object>) right;
            structuralDiffLists(la, lb, path, diffs);
            return;
        }

        // Scalars (or a type mismatch) - compare by normalized value.
        if (!valuesEqual(left, right)) {
            diffs.add(new DiffEntry(path, String.valueOf(left), String.valueOf(right), "value"));
        }
    }

    /**
     * Order-insensitive list comparison for the document path. Exact matches
     * are paired first (so identical elements never produce spurious diffs when
     * reordered), then the remaining elements are paired by best match, and any
     * surplus or shortfall is reported.
     */
    private static void structuralDiffLists(List<Object> la, List<Object> lb,
                                            String path, List<DiffEntry> diffs) {
        boolean[] usedB = new boolean[lb.size()];
        List<Integer> unmatchedA = new ArrayList<>();

        // Pass 1: exact (zero-difference) matches.
        for (int i = 0; i < la.size(); i++) {
            int match = -1;
            for (int j = 0; j < lb.size(); j++) {
                if (usedB[j]) continue;
                List<DiffEntry> probe = new ArrayList<>();
                structuralDiff(la.get(i), lb.get(j), "", probe);
                if (probe.isEmpty()) { match = j; break; }
            }
            if (match >= 0) usedB[match] = true;
            else unmatchedA.add(i);
        }

        // Pass 2: pair leftovers by best match, then report their differences.
        for (int i : unmatchedA) {
            int best = pickPartner(la.get(i), lb, usedB);
            String childPath = path + "[" + i + "]";
            if (best >= 0) {
                usedB[best] = true;
                structuralDiff(la.get(i), lb.get(best), childPath, diffs);
            } else {
                diffs.add(new DiffEntry(childPath, String.valueOf(la.get(i)), "<missing>", "removed"));
            }
        }

        // Anything left on B is surplus.
        for (int j = 0; j < lb.size(); j++) {
            if (usedB[j]) continue;
            diffs.add(new DiffEntry(path + "[" + j + "]", "<missing>",
                    String.valueOf(lb.get(j)), "added"));
        }
    }

    /**
     * Choose the best partner for {@code item} among the unused elements of
     * {@code candidates}: an element sharing the same business key wins,
     * otherwise the one with the highest field overlap. Returns -1 if none are
     * available.
     */
    private static int pickPartner(Object item, List<Object> candidates, boolean[] used) {
        Object key = (item instanceof Map)
                ? CrossFormatCanonicalizer.businessKey(asStringMap(item))
                : null;
        int best = -1, bestScore = -1;
        for (int j = 0; j < candidates.size(); j++) {
            if (used[j]) continue;
            Object cand = candidates.get(j);
            if (key != null && cand instanceof Map
                    && key.equals(CrossFormatCanonicalizer.businessKey(asStringMap(cand)))) {
                return j;                                    // business key wins outright
            }
            int score = (item instanceof Map && cand instanceof Map)
                    ? overlapScore(asStringMap(item), asStringMap(cand))
                    : 0;
            if (score > bestScore) { bestScore = score; best = j; }
        }
        return best;
    }

    /** Narrow an Object known to be a Map into a Map&lt;String,Object&gt;. */
    @SuppressWarnings("unchecked")
    private static Map<String, Object> asStringMap(Object o) {
        return (Map<String, Object>) o;
    }

    /**
     * Treat a one-element list as the bare element when the other side is a
     * plain object, so a single XML element lines up with a one-element JSON
     * array. Returns the value unchanged in every other case.
     */
    private static Object unwrapSingleton(Object value, Object other) {
        if (value instanceof List && !(other instanceof List)) {
            List<?> list = (List<?>) value;
            if (list.size() == 1) return list.get(0);
        }
        return value;
    }

    /**
     * Compare two lists of flat business records (produced by the
     * cross-format canonicalizer). Records are paired by business key when
     * available, otherwise by best field overlap, so ordering between the
     * two systems never matters. Each matched pair is compared field by
     * field; unmatched records on either side are reported as added/removed.
     *
     * @param recA  records from side A (expected)
     * @param recB  records from side B (actual)
     * @param diffs accumulator for differences
     */
    private static void diffRecords(List<Map<String, Object>> recA,
                                    List<Map<String, Object>> recB,
                                    List<DiffEntry> diffs) {
        boolean[] usedB = new boolean[recB.size()];

        for (int i = 0; i < recA.size(); i++) {
            Map<String, Object> a = recA.get(i);
            Object keyA = CrossFormatCanonicalizer.businessKey(a);
            int match = -1;

            // Prefer matching by business key.
            if (keyA != null) {
                for (int j = 0; j < recB.size(); j++) {
                    if (usedB[j]) continue;
                    if (keyA.equals(CrossFormatCanonicalizer.businessKey(recB.get(j)))) {
                        match = j;
                        break;
                    }
                }
            }
            // Fall back to best field-overlap match (most equal leaf values).
            if (match < 0) {
                int bestScore = -1;
                for (int j = 0; j < recB.size(); j++) {
                    if (usedB[j]) continue;
                    int score = overlapScore(a, recB.get(j));
                    if (score > bestScore) { bestScore = score; match = j; }
                }
            }

            String path = "$[" + (keyA != null ? keyA : i) + "]";
            if (match >= 0) {
                usedB[match] = true;
                diffRecordPair(a, recB.get(match), path, diffs);
            } else {
                diffs.add(new DiffEntry(path, String.valueOf(a), "<missing>", "removed"));
            }
        }

        // Any B records never matched are extra.
        for (int j = 0; j < recB.size(); j++) {
            if (usedB[j]) continue;
            Object keyB = CrossFormatCanonicalizer.businessKey(recB.get(j));
            String path = "$[" + (keyB != null ? keyB : j) + "]";
            diffs.add(new DiffEntry(path, "<missing>", String.valueOf(recB.get(j)), "added"));
        }
    }

    /**
     * Compare two matched flat records field by field. Only leaf keys present
     * on both sides are compared for value equality; a key present on just
     * one side is reported as added/removed so genuine missing data surfaces,
     * while representation-only wrapper noise has already been canonicalized
     * away.
     */
    private static void diffRecordPair(Map<String, Object> a, Map<String, Object> b,
                                       String path, List<DiffEntry> diffs) {
        Set<String> keys = new TreeSet<>();
        keys.addAll(a.keySet());
        keys.addAll(b.keySet());
        for (String k : keys) {
            boolean inA = a.containsKey(k), inB = b.containsKey(k);
            String childPath = path + "." + k;
            if (inA && inB) {
                diff(a.get(k), b.get(k), childPath, diffs);
            } else if (inA) {
                // A leaf present only on side A. If the same value already
                // appears in a matched leaf of side B, this is representation-
                // only redundancy (e.g. currency carried twice in JSON but
                // once in XML) - not a real data difference, so don't report it.
                if (!valueAppearsIn(a.get(k), b)) {
                    diffs.add(new DiffEntry(childPath, String.valueOf(a.get(k)), "<missing>", "removed"));
                }
            } else {
                if (!valueAppearsIn(b.get(k), a)) {
                    diffs.add(new DiffEntry(childPath, "<missing>", String.valueOf(b.get(k)), "added"));
                }
            }
        }
    }

    /** @return true if the given value equals any value in the record. */
    private static boolean valueAppearsIn(Object value, Map<String, Object> record) {
        if (value == null) return false;
        for (Object v : record.values()) {
            if (valuesEqual(value, v)) return true;
        }
        return false;
    }

    /** Count leaf keys whose normalized values are equal on both records. */
    private static int overlapScore(Map<String, Object> a, Map<String, Object> b) {
        int score = 0;
        for (Map.Entry<String, Object> e : a.entrySet()) {
            Object bv = b.get(e.getKey());
            if (bv != null && valuesEqual(e.getValue(), bv)) score++;
        }
        return score;
    }

    /** Value equality that treats numbers by value and everything else by equals. */
    private static boolean valuesEqual(Object a, Object b) {
        if (a instanceof Number && b instanceof Number) {
            return ((Number) a).doubleValue() == ((Number) b).doubleValue();
        }
        if (a instanceof java.math.BigDecimal && b instanceof java.math.BigDecimal) {
            return ((java.math.BigDecimal) a).compareTo((java.math.BigDecimal) b) == 0;
        }
        return Objects.equals(a, b);
    }

    // ------------------------------------------------------------------
    // Variable extraction
    // ------------------------------------------------------------------

    /** Thrown when extractVariable fails for a reportable reason. */
    public static class ExtractionException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        public ExtractionException(String msg) { super(msg); }
    }

    public static String extractVariable(String payload, String path) {
        // Defensive: null or empty inputs yield empty result rather than
        // propagating a NullPointerException from the underlying parsers.
        if (payload == null || payload.isEmpty()) return "";
        if (path == null || path.isEmpty()) return "";
        String fmt = detectFormat(payload);
        if ("json".equals(fmt)) {
            try {
                Object value = JsonPath.using(JSONPATH_CFG).parse(payload).read(path);
                if (value == null) return "";
                if (value instanceof List) {
                    List<?> list = (List<?>) value;
                    return list.isEmpty() ? "" : String.valueOf(list.get(0));
                }
                return String.valueOf(value);
            } catch (Exception ex) {
                throw new ExtractionException("JSONPath failed: " + ex.getMessage());
            }
        }
        if ("xml".equals(fmt)) {
            // STRATEGY 1: Parser-free tag walker. Handles the XPath idioms we
            // care about (//Tag, //Tag[N], //Tag[last()], //Parent[Child='V'],
            // chained navigation) WITHOUT requiring strict-XML compliance.
            // Works against real-world SOAP responses that confound parsers.
            //
            // The walker tells us whether it could handle the path syntax.
            // If yes, we trust its result (even when empty - that means
            // legitimately no match). If no, we fall through to the parser.
            if (SimpleXmlWalker.canHandle(path)) {
                return SimpleXmlWalker.findFirst(payload, path);
            }

            // STRATEGY 2: Strict XML parser for advanced XPath only
            // (count(), starts-with(), attribute paths, etc.).
            // Servers sometimes return XML containing HTML-escaped XML as text
            // content (common SOAP pattern). Decode so XPath can address the
            // inner elements directly without the user knowing about the wrap.
            String decoded = decodeEmbeddedEscapedXml(payload);
            // Normalize CRLF/CR - servers sometimes send Windows line endings
            // which end up as &#xd; in extracted values.
            decoded = decoded.replace("\r\n", "\n").replace("\r", "");
            // Strip literal &#xd; / &#xD; / &#13; entity references that appear
            // in element content when servers double-encode carriage returns.
            // These are legal XML character refs but appear as visible junk in
            // extracted values; remove them everywhere.
            decoded = decoded.replaceAll("&#x[dD];", "").replaceAll("&#13;", "");
            // Strip BOM + leading whitespace BEFORE <?xml ... ?>
            String sanitized = sanitizeXmlProlog(decoded);

            // Try progressively more aggressive recovery strategies before
            // giving up. This keeps the framework usable against real-world
            // SOAP servers that emit malformed XML.
            Document doc = parseWithRecovery(sanitized);
            if (doc == null) {
                // Final fallback: simple regex-based extraction.
                // Only works for plain //TagName or //Parent[Child='X']/TagName,
                // but covers the vast majority of real-world assertions.
                String fallback = regexExtract(sanitized, path);
                if (fallback != null) return fallback;

                // Diagnostic: show position of the offending <?xml so the user
                // can find the malformation in the raw response file.
                int innerXml = findInnerXmlPosition(sanitized);
                String hint = innerXml > 0
                        ? " (stray <?xml found at column " + (innerXml + 1) + ")"
                        : "";
                throw new ExtractionException(
                        "XML response is severely malformed and could not be recovered" + hint +
                        ". Inspect output/<timestamp>/<TestID>/sourceA/step*/response.txt. " +
                        "First 200 chars: " + safePreview(sanitized, 200));
            }

            try {
                XPath xp = XPathFactory.newInstance().newXPath();
                // Evaluate to a NodeSet first so we can detect "no match" cleanly.
                org.w3c.dom.NodeList nodes = (org.w3c.dom.NodeList) xp.evaluate(path, doc, XPathConstants.NODESET);
                if (nodes != null && nodes.getLength() > 0) {
                    String v = nodes.item(0).getTextContent();
                    return v == null ? "" : v.trim();
                }
                // Fall back to a string evaluation for paths that return scalars
                // (e.g. count(...), string-length(...), or attribute selections).
                Object str = xp.evaluate(path, doc, XPathConstants.STRING);
                String s = str == null ? "" : str.toString().trim();
                return s;
            } catch (javax.xml.xpath.XPathExpressionException ex) {
                throw new ExtractionException("XPath syntax error: " + ex.getMessage());
            } catch (Exception ex) {
                throw new ExtractionException("XPath evaluation failed: " + ex.getMessage());
            }
        }
        return "";
    }

    /**
     * Extract <b>all</b> values that match the given path, not just the first.
     *
     * <p>This is used by the assertion engine so that when multiple sibling
     * elements share the same tag name (e.g. several CostComponent nodes
     * under one parent), an assertion like {@code equals "360.30"} can check
     * every match and pass if <em>any</em> of them satisfies the operator,
     * rather than failing because the first one happened to hold a different
     * value.
     *
     * <p>For paths that resolve to a single value the returned list has one
     * element, so callers that need first-match semantics can use
     * {@link #extractVariable} instead.
     *
     * @param payload the response body (XML or JSON)
     * @param path    the XPath or JSONPath expression
     * @return all matching values (never null; empty list on no match)
     */
    public static List<String> extractAllVariables(String payload, String path) {
        if (payload == null || payload.isEmpty()) return List.of();
        if (path == null || path.isEmpty()) return List.of();
        String fmt = detectFormat(payload);

        if ("json".equals(fmt)) {
            try {
                Object value = JsonPath.using(JSONPATH_CFG).parse(payload).read(path);
                if (value == null) return List.of();
                if (value instanceof List) {
                    List<?> list = (List<?>) value;
                    return list.stream()
                            .filter(java.util.Objects::nonNull)
                            .map(String::valueOf)
                            .collect(java.util.stream.Collectors.toList());
                }
                return List.of(String.valueOf(value));
            } catch (Exception ex) {
                throw new ExtractionException("JSONPath failed: " + ex.getMessage());
            }
        }

        if ("xml".equals(fmt)) {
            // Strategy 1: parser-free walker (handles the common idioms).
            if (SimpleXmlWalker.canHandle(path)) {
                List<String> all = SimpleXmlWalker.findAll(payload, path);
                return all == null ? List.of() : all;
            }

            // Strategy 2: strict XPath via DOM.
            String decoded = decodeEmbeddedEscapedXml(payload);
            decoded = decoded.replace("\r\n", "\n").replace("\r", "");
            decoded = decoded.replaceAll("&#x[dD];", "").replaceAll("&#13;", "");
            String sanitized = sanitizeXmlProlog(decoded);
            Document doc = parseWithRecovery(sanitized);
            if (doc == null) {
                // regex fallback only returns one match - wrap it
                String fallback = regexExtract(sanitized, path);
                return fallback != null ? List.of(fallback) : List.of();
            }
            try {
                XPath xp = XPathFactory.newInstance().newXPath();
                org.w3c.dom.NodeList nodes = (org.w3c.dom.NodeList)
                        xp.evaluate(path, doc, XPathConstants.NODESET);
                if (nodes == null || nodes.getLength() == 0) return List.of();
                List<String> results = new ArrayList<>();
                for (int i = 0; i < nodes.getLength(); i++) {
                    String v = nodes.item(i).getTextContent();
                    results.add(v == null ? "" : v.trim());
                }
                return results;
            } catch (Exception ex) {
                throw new ExtractionException("XPath failed: " + ex.getMessage());
            }
        }
        return List.of();
    }

    /**
     * Try parsing with three escalating strategies. Returns null if all fail.
     */
    private static Document parseWithRecovery(String xml) {
        // Attempt 1: parse as-is (already sanitized for BOM and inner <?xml).
        try {
            return buildAndParse(xml);
        } catch (Exception ignore) {}

        // Attempt 2: aggressively strip EVERY <?xml ... ?> processing
        // instruction except the very first one (if any). Some servers
        // emit them in extremely creative places that the targeted sanitizer
        // doesn't catch.
        String stripped = stripAllInnerXmlPis(xml);
        if (!stripped.equals(xml)) {
            try {
                return buildAndParse(stripped);
            } catch (Exception ignore) {}
        }

        // Attempt 3: strip invalid XML 1.0 characters (NUL bytes, raw control
        // chars, lone surrogates) which some legacy mainframe backends emit.
        String cleaned = stripInvalidXmlChars(stripped);
        if (!cleaned.equals(stripped)) {
            try {
                return buildAndParse(cleaned);
            } catch (Exception ignore) {}
        }

        // Attempt 4: wrap content in a fake root so multiple top-level
        // siblings (the second-document case) parse as one tree. We then
        // re-extract against the inner content.
        String wrapped = "<__root__>" + cleaned.replaceFirst("(?i)^\\s*<\\?xml[^?]*\\?>", "") + "</__root__>";
        try {
            return buildAndParse(wrapped);
        } catch (Exception ignore) {}

        return null;
    }

    /** Parse XML into a DOM document with XXE protections enabled. */
    private static Document buildAndParse(String xml) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(false);
        hardenXxe(dbf);
        DocumentBuilder b = dbf.newDocumentBuilder();
        // Custom error handler: swallow EVERYTHING quietly. Fatal errors throw
        // SAXParseException up to us, which the recovery chain catches.
        b.setErrorHandler(new org.xml.sax.ErrorHandler() {
            public void warning(org.xml.sax.SAXParseException e) {}
            public void error(org.xml.sax.SAXParseException e) {}
            public void fatalError(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException {
                throw e;
            }
        });

        // Xerces writes "[Fatal Error] :1:N: ..." DIRECTLY to System.err
        // before invoking our error handler. Suppress that channel during
        // the parse attempt so the user doesn't see a misleading error in
        // their console when the recovery chain is doing its job.
        java.io.PrintStream originalErr = System.err;
        try {
            System.setErr(new java.io.PrintStream(java.io.OutputStream.nullOutputStream()));
            return b.parse(new InputSource(new StringReader(xml)));
        } finally {
            System.setErr(originalErr);
        }
    }

    /**
     * Apply the full set of XXE / external-entity protections to a
     * DocumentBuilderFactory. Centralized so every XML parse path in this
     * class is hardened identically. Best-effort: features not supported on
     * a given JDK are skipped without failing.
     */
    static void hardenXxe(DocumentBuilderFactory dbf) {
        try {
            dbf.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
            dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            dbf.setXIncludeAware(false);
            dbf.setExpandEntityReferences(false);
        } catch (Exception ignore) {
            // Features may not all be supported on every JDK - best-effort.
            // disallow-doctype-decl alone blocks the DTD-based XXE vectors.
        }
    }

    /**
     * Strip every &lt;?xml ... ?&gt; processing instruction. Aggressive - used
     * as a last-ditch recovery before declaring the response unparseable.
     */
    private static String stripAllInnerXmlPis(String xml) {
        if (xml == null || xml.isEmpty()) return xml;
        // Match <?xml...?> case-insensitively. Non-greedy body.
        return xml.replaceAll("(?i)<\\?xml[^?]*\\?>", "");
    }

    /**
     * Remove characters that are illegal in XML 1.0 - NUL bytes, raw control
     * chars (0x01-0x08, 0x0B, 0x0C, 0x0E-0x1F), and lone surrogates. Some
     * legacy backends (mainframes, COBOL services) emit these and crash any
     * conformant XML parser.
     */
    private static String stripInvalidXmlChars(String xml) {
        if (xml == null || xml.isEmpty()) return xml;
        StringBuilder out = new StringBuilder(xml.length());
        for (int i = 0; i < xml.length(); i++) {
            char c = xml.charAt(i);
            // Allowed XML 1.0 chars: 0x9, 0xA, 0xD, 0x20-0xD7FF, 0xE000-0xFFFD
            if (c == 0x9 || c == 0xA || c == 0xD
                    || (c >= 0x20 && c <= 0xD7FF)
                    || (c >= 0xE000 && c <= 0xFFFD)) {
                out.append(c);
            }
            // else: skip silently
        }
        return out.toString();
    }

    /**
     * Best-effort regex extraction when the XML can't be parsed at all.
     * Supports two path shapes:
     *   //TagName                            - first occurrence's inner text
     *   //Parent[Child='value']/Sibling      - find first Parent with a
     *                                          Child equal to 'value', then
     *                                          return the inner text of its
     *                                          Sibling child.
     * Returns null if the path shape isn't supported.
     */
    private static String regexExtract(String xml, String path) {
        if (xml == null || path == null) return null;
        // Shape A: //Tag (no predicates, no slashes after the tag name)
        java.util.regex.Matcher mA = java.util.regex.Pattern
                .compile("^//([A-Za-z_][\\w-]*)$")
                .matcher(path.trim());
        if (mA.matches()) {
            return regexFindFirstTag(xml, mA.group(1));
        }
        // Shape B: //Parent[Child='value']/Sibling   (or .../Sibling/SubSibling)
        java.util.regex.Matcher mB = java.util.regex.Pattern
                .compile("^//([A-Za-z_][\\w-]*)\\[([A-Za-z_][\\w-]*)\\s*=\\s*['\"]([^'\"]+)['\"]\\]/(.+)$")
                .matcher(path.trim());
        if (mB.matches()) {
            String parent = mB.group(1);
            String pred   = mB.group(2);
            String value  = mB.group(3);
            String tail   = mB.group(4);
            return regexFindParentWithChild(xml, parent, pred, value, tail);
        }
        return null;
    }

    /** Fallback: find the first occurrence of a tag's text content by regex. */
    private static String regexFindFirstTag(String xml, String tag) {
        // Match <tag ...>content</tag> (allow attributes; non-greedy content)
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "<(?:\\w+:)?" + java.util.regex.Pattern.quote(tag) + "(?:\\s[^>]*)?>(.*?)</(?:\\w+:)?"
                        + java.util.regex.Pattern.quote(tag) + ">",
                java.util.regex.Pattern.DOTALL);
        java.util.regex.Matcher m = p.matcher(xml);
        if (m.find()) {
            return stripTags(m.group(1)).trim();
        }
        return "";
    }

    /** Fallback: find a parent element that contains a given child=value, by regex. */
    private static String regexFindParentWithChild(String xml, String parent,
                                                   String childTag, String childValue,
                                                   String tail) {
        // Find every <parent>...</parent> block, then check if it contains
        // <childTag>childValue</childTag>. On match, look up the tail tag.
        java.util.regex.Pattern parentP = java.util.regex.Pattern.compile(
                "<(?:\\w+:)?" + java.util.regex.Pattern.quote(parent) + "(?:\\s[^>]*)?>"
                        + "(.*?)</(?:\\w+:)?" + java.util.regex.Pattern.quote(parent) + ">",
                java.util.regex.Pattern.DOTALL);
        java.util.regex.Matcher pm = parentP.matcher(xml);
        java.util.regex.Pattern childP = java.util.regex.Pattern.compile(
                "<(?:\\w+:)?" + java.util.regex.Pattern.quote(childTag) + "(?:\\s[^>]*)?>"
                        + "\\s*" + java.util.regex.Pattern.quote(childValue) + "\\s*"
                        + "</(?:\\w+:)?" + java.util.regex.Pattern.quote(childTag) + ">",
                java.util.regex.Pattern.DOTALL);

        while (pm.find()) {
            String body = pm.group(1);
            if (childP.matcher(body).find()) {
                // Found the right parent. Walk the tail path (split on /)
                // and return the first match in the parent body.
                String[] parts = tail.split("/");
                String lastTag = parts[parts.length - 1];
                return regexFindFirstTag(body, lastTag);
            }
        }
        return "";
    }

    /** Remove all XML tags, leaving only the text content. */
    private static String stripTags(String s) {
        return s.replaceAll("<[^>]+>", "");
    }

    /** Return a length-limited, single-line preview of a string for messages. */
    private static String safePreview(String s, int max) {
        if (s == null) return "(null)";
        String t = s.replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
        return t.length() > max ? t.substring(0, max) + "..." : t;
    }

    /** Return the position of the first non-leading &lt;?xml, or -1. */
    private static int findInnerXmlPosition(String s) {
        if (s == null || s.isEmpty()) return -1;
        // Skip a legitimate leading <?xml ...?>
        int start = 0;
        if (s.startsWith("<?xml")) {
            int end = s.indexOf("?>", 5);
            if (end > 0) start = end + 2;
        }
        int p = s.indexOf("<?", start);
        while (p >= 0) {
            if (p + 5 <= s.length() && s.substring(p + 2, p + 5).equalsIgnoreCase("xml")) {
                return p;
            }
            p = s.indexOf("<?", p + 2);
        }
        return -1;
    }

    /**
     * Sanitize XML for parsing. Handles three real-world malformations seen
     * in enterprise SOAP responses:
     *
     *   1. BOM + leading whitespace/control chars before &lt;?xml - easy.
     *   2. Inner &lt;?xml declarations anywhere except position 0 - illegal
     *      per the spec, but real servers (especially chained proxies, MTOM
     *      strippers, and over-eager logging filters) emit them. We strip
     *      every non-leading &lt;?xml ... ?&gt; instruction.
     *   3. Two XML documents concatenated. We keep the first complete
     *      document by truncating at the first standalone &lt;?xml that
     *      appears after the leading prolog. Specifically: if a &lt;?xml
     *      declaration appears AFTER any element has already opened, we
     *      treat that as the start of a second document and discard from
     *      that point on.
     *
     * The fix is conservative - well-formed XML is unchanged.
     */
    public static String sanitizeXmlProlog(String xml) {
        if (xml == null || xml.isEmpty()) return xml;

        // Step 1: strip BOM + leading whitespace/control chars
        int start = 0;
        while (start < xml.length()) {
            char c = xml.charAt(start);
            if (c == '\uFEFF'
                    || c == '\u00A0'
                    || Character.isWhitespace(c)
                    || Character.isISOControl(c)) {
                start++;
            } else {
                break;
            }
        }
        String s = (start == 0) ? xml : xml.substring(start);
        if (s.isEmpty()) return s;

        // Step 2: locate the leading <?xml ... ?> prolog (if present) so we
        // know what's "the legitimate one" and can strip any subsequent ones.
        int searchFrom = 0;
        if (s.startsWith("<?xml")) {
            int prologEnd = s.indexOf("?>", 5);
            if (prologEnd > 0) {
                searchFrom = prologEnd + 2;
            }
        }

        // Step 3: scan for additional <?xml declarations or processing
        // instructions that target xml - both are the trigger of the
        // "[xX][mM][lL] is not allowed" error.
        int badIdx = findIllegalXmlPi(s, searchFrom);
        if (badIdx < 0) {
            return s;
        }

        // STRIP every non-leading <?xml ... ?> instruction.  This is the
        // safe, conservative recovery - it keeps all element content and
        // only removes the offending processing instructions.  Truncation
        // (used in earlier versions) would drop legitimate sibling elements
        // when the response had multiple top-level siblings with a stray
        // <?xml between them.
        StringBuilder out = new StringBuilder(s.length());
        out.append(s, 0, searchFrom);
        int cursor = searchFrom;
        while (cursor < s.length()) {
            int piStart = s.indexOf("<?", cursor);
            if (piStart < 0) {
                out.append(s, cursor, s.length());
                break;
            }
            // Append everything up to this PI start
            out.append(s, cursor, piStart);
            int piEnd = s.indexOf("?>", piStart + 2);
            if (piEnd < 0) {
                // Unterminated PI - best we can do is drop the rest
                break;
            }
            String target = s.substring(piStart + 2, Math.min(piStart + 6, s.length())).toLowerCase();
            if (target.startsWith("xml")) {
                // Skip this PI entirely
                cursor = piEnd + 2;
            } else {
                // Legitimate non-xml PI - keep it
                out.append(s, piStart, piEnd + 2);
                cursor = piEnd + 2;
            }
        }
        return out.toString();
    }

    /**
     * Find the next <?xml ... ?> processing instruction starting from `from`.
     * Returns the start index, or -1 if none.
     */
    private static int findIllegalXmlPi(String s, int from) {
        int idx = from;
        while (idx < s.length()) {
            int p = s.indexOf("<?", idx);
            if (p < 0) return -1;
            // Check the PI target - case-insensitive "xml"
            if (p + 5 <= s.length()) {
                String target = s.substring(p + 2, p + 5).toLowerCase();
                if (target.equals("xml")) {
                    return p;
                }
            }
            idx = p + 2;
        }
        return -1;
    }

    /**
     * If a payload contains 3+ HTML-escaped XML tags, decode them into real XML
     * so XPath can address the inner elements. Idempotent.
     */
    private static String decodeEmbeddedEscapedXml(String s) {
        if (s == null || !s.contains("&lt;")) return s;
        int hits = 0;
        int idx = 0;
        while ((idx = s.indexOf("&lt;", idx)) != -1) { hits++; idx += 4; if (hits >= 3) break; }
        if (hits < 3) return s;
        return s.replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'")
                .replace("&amp;", "&");
    }

    /**
     * Count how many nodes match the given XPath or JSONPath expression.
     * Used by the count_equals assertion operator.
     */
    public static int countMatches(String payload, String path) {
        if (payload == null || payload.isEmpty() || path == null || path.isEmpty()) return 0;
        String clean = extractInnerPayload(payload).trim();

        if (path.startsWith("$")) {
            // JSONPath - count array elements or matched nodes
            try {
                Object result = com.jayway.jsonpath.JsonPath.read(clean, path);
                if (result instanceof java.util.List<?> list) return list.size();
                return result != null ? 1 : 0;
            } catch (Exception e) {
                try {
                    JsonNode node = MAPPER.readTree(clean);
                    JsonNode found = node.at(path.substring(1).replace(".", "/"));
                    if (found.isMissingNode()) return 0;
                    if (found.isArray()) return found.size();
                    return 1;
                } catch (Exception e2) { return 0; }
            }
        } else {
            // XPath
            try {
                Document doc = buildAndParse(clean);
                javax.xml.xpath.XPath xpath = javax.xml.xpath.XPathFactory.newInstance().newXPath();
                org.w3c.dom.NodeList nodes = (org.w3c.dom.NodeList) xpath.evaluate(
                        path, doc, javax.xml.xpath.XPathConstants.NODESET);
                return nodes.getLength();
            } catch (Exception e) { return 0; }
        }
    }

    /**
     * Check whether the node at the given path has child elements.
     * Used by the has_children assertion operator.
     */
    public static boolean hasChildren(String payload, String path) {
        if (payload == null || payload.isEmpty() || path == null || path.isEmpty()) return false;
        String clean = extractInnerPayload(payload).trim();

        if (path.startsWith("$")) {
            // JSONPath - check if the result is a non-empty object or array
            try {
                JsonNode root = MAPPER.readTree(clean);
                JsonNode node = root.at(path.substring(1).replace(".", "/"));
                if (node.isMissingNode() || node.isNull()) return false;
                return node.isObject() ? node.size() > 0 : node.isArray() && node.size() > 0;
            } catch (Exception e) { return false; }
        } else {
            // XPath - check if the matched node has child Element nodes
            try {
                Document doc = buildAndParse(clean);
                javax.xml.xpath.XPath xpath = javax.xml.xpath.XPathFactory.newInstance().newXPath();
                org.w3c.dom.NodeList nodes = (org.w3c.dom.NodeList) xpath.evaluate(
                        path, doc, javax.xml.xpath.XPathConstants.NODESET);
                if (nodes.getLength() == 0) return false;
                org.w3c.dom.Node target = nodes.item(0);
                org.w3c.dom.NodeList kids = target.getChildNodes();
                for (int i = 0; i < kids.getLength(); i++) {
                    if (kids.item(i).getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) return true;
                }
                return false;
            } catch (Exception e) { return false; }
        }
    }
}
