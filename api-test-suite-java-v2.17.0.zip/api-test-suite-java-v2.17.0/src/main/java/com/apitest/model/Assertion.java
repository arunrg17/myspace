package com.apitest.model;

/**
 * Field-level assertion or ignore directive.
 *
 * Operators:
 *   equals, not_equals, contains, not_contains, exists, not_exists,
 *   greater_than, less_than, one_of, regex_match, ignore,
 *   db_equals, db_contains, db_exists, db_rows
 *
 * PathType:
 *   jsonpath  - e.g. $.order.id
 *   xpath     - e.g. //*[local-name()='Status']
 *   (db_* operators put a SQL SELECT in the path instead)
 *
 * <p>{@code stepOrder} optionally binds an assertion to one step of a
 * multi-step test. When zero (the default, meaning the StepOrder cell was
 * blank), the assertion runs once against the final response - the historical
 * behaviour. When set to a step's order, the assertion runs right after that
 * step, against that step's response, with the variables captured up to and
 * including that step available to placeholders in the path and expected value.
 * This is what lets a value produced by an earlier step - a server-generated
 * id, say - be referenced as {@code ${step1.portfolioId}} inside a later
 * assertion or its SQL query.
 *
 * <p>{@code decode} names an optional transform applied to the value the path
 * resolves to, before the operator runs. Blank (the default, meaning the Decode
 * cell was empty) leaves the value exactly as extracted - the historical
 * behaviour every existing workbook relies on. {@code base64} decodes the value
 * as base64 text first, so an assertion can reach into a field whose content is
 * base64-encoded (an encoded request or response section) and check what is
 * inside it.
 */
public record Assertion(
        String path,
        String pathType,
        String operator,
        String expectedValue,
        String description,
        int stepOrder,
        String decode
) {
    /** Backwards-compatible constructor for assertions with no step binding and no decode. */
    public Assertion(String path, String pathType, String operator,
                     String expectedValue, String description) {
        this(path, pathType, operator, expectedValue, description, 0, "");
    }

    /** Backwards-compatible constructor for assertions with a step binding but no decode. */
    public Assertion(String path, String pathType, String operator,
                     String expectedValue, String description, int stepOrder) {
        this(path, pathType, operator, expectedValue, description, stepOrder, "");
    }

    /** True when this assertion is bound to a specific step. */
    public boolean isStepScoped() {
        return stepOrder > 0;
    }

    /** The decode transform, normalised to lower case; empty when none. */
    public String decodeMode() {
        return decode == null ? "" : decode.trim().toLowerCase(java.util.Locale.ROOT);
    }
}
