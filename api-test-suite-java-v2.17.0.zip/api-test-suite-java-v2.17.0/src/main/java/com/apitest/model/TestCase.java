package com.apitest.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Mutable test case (built up while parsing the Excel workbook).
 */
public class TestCase {
    public String testId;
    public String name;
    public String description;
    public String comparisonMode;
    public String sourceA;
    public String sourceB;
    public String expectedFile;

    /**
     * JSONPaths of base64-encoded fields to decode on both sides before a
     * vs_expected / vs_env comparison. Empty for every test that does not
     * declare any, which is the historical behaviour.
     */
    public List<String> decodePaths = new ArrayList<>();
    public boolean enabled;
    public List<Step> steps = new ArrayList<>();
    public Map<String, String> data = new HashMap<>();
    public List<Assertion> assertions = new ArrayList<>();

    /** Create an empty test case; fields are populated by the loader. */
    public TestCase() {}
}
