# Changelog

## 2.1.0 — 2026-05-15

### Features

- **CDATA-aware comparison.** When the actual response wraps the business
  payload inside CDATA (a common SOAP pattern such as
  `<arg0><![CDATA[<RealPayload>...</RealPayload>]]></arg0>`), the
  comparator now unwraps it before structural diff so you can compare
  against a clean expected XML file. Also handles escaped XML
  (`&lt;...&gt;`) and SOAP-in-SOAP nested wrappers.
- **Smart comparison anchor.** When the expected file's top-level element
  exists somewhere inside the unwrapped actual response, comparison
  automatically anchors on that element. Lets users write expected files
  that contain only the business payload without having to mirror the
  full SOAP envelope structure.

### Improvements

- **Differences tab readability:**
  - `added` / `removed` rows now show `(missing)` on the absent side
    instead of repeating the value in both columns
  - Empty values render as `(empty)` instead of an indistinguishable blank
  - Long values truncate at 300 chars with a footer indicating how many
    more chars were elided
  - Table layout uses fixed widths for Kind/Path so the value columns get
    consistent space; word-break prevents overflow

### Security

- **XXE hardening across all XML parsers.** Every `DocumentBuilderFactory`
  now disables doctype declarations, external general/parameter entities,
  external DTD loading, XInclude, and entity expansion. Defense-in-depth
  against the small but real risk of a malicious response triggering an
  XXE-style attack on the test harness.

### Cleanup

- Removed unused `Demo.java` scaffolding.
- All snippets/identifiers from real-world test runs replaced with
  neutral example domain names. No proprietary references remain in the
  codebase.
- `serialVersionUID` added to `ExtractionException`.

## 2.0.2 — 2026-05-15

### Bug fixes

- **No more `xmlns=""` artifacts.** The namespace-aware DOM parser sometimes
  inserted redundant `xmlns=""` declarations on child elements during
  round-trip. A new cleanup pass walks the tree and removes empty default
  namespace declarations when the parent already had no default namespace.
- **No more line-wrapping inside element open tags.** The Transformer's
  pretty-print was wrapping long opening tags across multiple lines (e.g.
  `<arg0\n   xmlns="">`), which some strict server parsers reject. Indent
  is now disabled in the serializer; output is single-line clean XML.
- **No more visible blank lines inside the request.** After pruning, the
  original template's indentation whitespace was left as text nodes between
  elements, producing visible gaps in the output. A cleanup pass removes
  whitespace-only text nodes between structural elements.

## 2.0.1 — 2026-05-15

### Bug fixes

- **CDATA-wrapped inner XML now cleaned correctly.** When a template uses
  `<arg0><![CDATA[<inner>...${field}...</inner>]]></arg0>` to wrap a
  business payload, unresolved placeholders inside the CDATA now have their
  surrounding tags removed via string-level cleanup (the parser can't walk
  into CDATA as elements). Surviving filled tags are preserved; empty
  wrappers cascade away within the CDATA.
- **CDATA sections preserved through the output.** Previously the
  Transformer was converting CDATA back to escaped entities. Now the
  serializer explicitly lists CDATA-containing element names so they
  round-trip as `<![CDATA[...]]>`.
- **DROP marker no longer leaks to output** even when an element has
  attributes and the placeholder was its only content. The element is
  dropped per the spec, regardless of attributes.

## 2.0.0 — 2026-05-15

### Behavior changes (breaking)

- **Template engine rewritten using DOM-walk + cascade pruning.** Old
  regex-based heuristics replaced with a real XML parser. Handles namespaces,
  nested structures, attributes, repeating siblings correctly.
- **Placeholder syntax is `${name}` only.** The `&{name}` form is no longer
  recognized (was briefly experimental in pre-release builds).
- **Blank/missing placeholder values now drop the surrounding tag.** This
  matches the requirements spec. A leaf with `<Phone>${phone}</Phone>` and
  blank `phone` cell renders with no `<Phone>` element at all.
- **Parent cascade cleanup.** When all children of a parent are pruned and
  the parent has no other content (no real attrs, no text), the parent
  itself is removed. Cascades up.
- **Namespace declarations don't block cascade.** `xmlns` and `xmlns:*` are
  not counted as "real" attributes — so `<execute xmlns="..."/>` cascades
  away properly when its content was just a placeholder.
- **Root element is never auto-removed.** If pruning empties everything,
  the body is `<Root></Root>` rather than nothing — better diagnostics.

### Reliability improvements

- **Per-test error isolation.** Template-not-found, dispatch errors, SSL
  failures, variable-extraction errors — all now produce a failed step in
  the report instead of an uncaught exception that killed the suite. The
  next test always runs.
- **RenderLog persisted to disk.** Each step's render log is saved next
  to its `request.txt`/`response.txt` under `output/.../step.../render-log.txt`.
  Shows which placeholders were missing, which tags were dropped, which
  parents cascaded.
- **Step errors shown in HTML report.** When a step fails for any reason
  (template error, dispatch error, etc.), the report shows the full
  rendered log inline with the failed step.

### Other

- Version badge added to HTML report header.
- `Required` placeholder syntax `${!name}` documented — raises a clear
  error if the column is blank/missing.

## 1.0.0 — earlier

- Initial Java port from the original UFT/VBScript suite.
- Excel-driven test definition (5 sheets: Environments, TestSuite, Steps,
  TestData, Assertions).
- Four protocols: REST, SOAP, Fabric, GCP.
- Five comparison modes; nine assertion operators.
- Self-contained HTML report.
- Parser-free `SimpleXmlWalker` for assertion extraction (handles
  SOAP-in-SOAP, CDATA-wrapped inner XML).
