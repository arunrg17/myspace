package com.apitest;

import com.apitest.model.TestResult;
import com.apitest.reporter.Reporter;
import com.apitest.runner.Runner;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * Entry point for the API test suite.
 *
 * Usage:
 *   java -jar target/api-test-suite.jar
 *   java -jar target/api-test-suite.jar --suite config/test_suite.xlsx --report reports/report.html
 */
public class Main {

    public static void main(String[] args) throws Exception {
        String suitePath = "config/test_suite.xlsx";
        String reportPath = "reports/report.html";
        String name = "API Test Suite";

        try {
            for (int i = 0; i < args.length; i++) {
                switch (args[i]) {
                    case "--suite"  -> suitePath  = requireValue(args, ++i, "--suite");
                    case "--report" -> reportPath = requireValue(args, ++i, "--report");
                    case "--name"   -> name       = requireValue(args, ++i, "--name");
                    case "--help", "-h" -> {
                        printHelp();
                        return;
                    }
                    case "--version", "-v" -> {
                        System.out.println("api-test-suite " + Version.VERSION);
                        return;
                    }
                    default -> {
                        System.err.println("Unknown argument: " + args[i]);
                        printHelp();
                        System.exit(2);
                    }
                }
            }
        } catch (IllegalArgumentException ex) {
            System.err.println("Error: " + ex.getMessage());
            printHelp();
            System.exit(2);
        }

        Path projectRoot = Paths.get("").toAbsolutePath();
        Path suite = projectRoot.resolve(suitePath);
        Path report = projectRoot.resolve(reportPath);

        if (!Files.exists(suite)) {
            System.err.println("Suite not found: " + suite);
            System.exit(1);
        }

        System.out.println("Running suite: " + suite);
        List<TestResult> results = Runner.runAll(suite, projectRoot);

        Files.createDirectories(report.getParent());
        Reporter.renderReport(results, report, name);

        long passed  = results.stream().filter(r -> "PASS".equals(r.status)).count();
        long failed  = results.stream().filter(r -> "FAIL".equals(r.status)).count();
        long errored = results.stream().filter(r -> "ERROR".equals(r.status)).count();

        System.out.println();
        System.out.println("  " + passed + " passed · " + failed + " failed · " + errored + " errored");
        System.out.println("  Report: " + report);

        System.exit((failed == 0 && errored == 0) ? 0 : 1);
    }

    private static String requireValue(String[] args, int idx, String flag) {
        if (idx >= args.length || args[idx].startsWith("--")) {
            throw new IllegalArgumentException(flag + " requires a value");
        }
        return args[idx];
    }

    private static void printHelp() {
        System.out.println("API Test Suite v" + Version.VERSION);
        System.out.println("Usage: java -jar api-test-suite.jar [options]");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  --suite <path>    Excel suite file (default: config/test_suite.xlsx)");
        System.out.println("  --report <path>   HTML report output (default: reports/report.html)");
        System.out.println("  --name <name>     Suite name shown in the report header");
        System.out.println("  --version, -v     Print version and exit");
        System.out.println("  --help, -h        Show this help message");
    }
}
