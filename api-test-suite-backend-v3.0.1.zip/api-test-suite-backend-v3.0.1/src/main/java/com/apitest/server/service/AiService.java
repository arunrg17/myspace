package com.apitest.server.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * Talks to an OpenAI-compatible chat endpoint - the shape most internal company
 * LLM gateways expose. It is configured with three things, all held in the
 * project's settings: a base URL, an API key, and a model name. A question is
 * sent as a standard {@code /chat/completions} request with the key in an
 * {@code Authorization: Bearer} header, and the reply is read from
 * {@code choices[0].message.content}.
 *
 * <p>This replaces the earlier approach of replaying a captured browser request
 * with cookies, which was brittle and expired quickly. An API key is stable and
 * is the way these gateways are meant to be called from a server.
 */
public class AiService {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final int TIMEOUT_MS = 60_000;

    private final SettingsService settings;

    public AiService(SettingsService settings) {
        this.settings = settings;
    }

    /** Whether a base URL, key and model are all set. */
    public boolean isConfigured() {
        return !base().isBlank() && !key().isBlank() && !model().isBlank();
    }

    private String base()  { return safe("ai.baseUrl"); }
    private String key()   { return safe("ai.apiKey"); }
    private String model() { return safe("ai.model"); }

    private String safe(String k) {
        try {
            return settings.raw(k) == null ? "" : settings.raw(k).trim();
        } catch (IOException e) {
            return "";
        }
    }

    /** A short, non-secret description of the connection for the settings screen. */
    public Map<String, Object> status() {
        boolean configured = isConfigured();
        String b = base();
        return Map.of(
                "configured", configured,
                "baseUrlSet", !b.isBlank(),
                "model", model(),
                // Never echo the key; just say whether one is stored.
                "keyStored", !key().isBlank(),
                "summary", configured
                        ? "Connected to " + host(b) + " (" + model() + ")"
                        : "Not configured");
    }

    /**
     * Ask the model a question and return its reply text.
     *
     * @throws IllegalStateException if the assistant is not configured
     * @throws IOException on a transport error or a non-success response
     */
    public String ask(String prompt) throws IOException {
        if (!isConfigured()) {
            throw new IllegalStateException("The assistant is not configured.");
        }
        String url = join(base(), "/chat/completions");

        ObjectNode body = MAPPER.createObjectNode();
        body.put("model", model());
        ArrayNode messages = body.putArray("messages");
        ObjectNode system = messages.addObject();
        system.put("role", "system");
        system.put("content",
                "You are a concise assistant helping an engineer build and debug API test suites.");
        ObjectNode user = messages.addObject();
        user.put("role", "user");
        user.put("content", prompt);

        RequestConfig cfg = RequestConfig.custom()
                .setConnectTimeout(TIMEOUT_MS)
                .setSocketTimeout(TIMEOUT_MS)
                .build();

        try (CloseableHttpClient client = HttpClients.custom()
                .setDefaultRequestConfig(cfg).build()) {
            HttpPost post = new HttpPost(url);
            post.setHeader("Authorization", "Bearer " + key());
            post.setHeader("Content-Type", "application/json");
            post.setEntity(new StringEntity(MAPPER.writeValueAsString(body),
                    ContentType.APPLICATION_JSON));

            var response = client.execute(post);
            try {
                int status = response.getStatusLine().getStatusCode();
                String text = response.getEntity() == null ? ""
                        : EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                if (status < 200 || status >= 300) {
                    throw new IOException("The assistant endpoint returned HTTP " + status
                            + (text.isBlank() ? "" : ": " + trim(text)));
                }
                JsonNode root = MAPPER.readTree(text);
                JsonNode content = root.path("choices").path(0).path("message").path("content");
                if (content.isMissingNode() || content.isNull()) {
                    throw new IOException("The assistant reply had no message content.");
                }
                return content.asText();
            } finally {
                response.close();
            }
        }
    }

    private static String join(String base, String path) {
        if (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        return base + path;
    }

    private static String host(String url) {
        try {
            return java.net.URI.create(url).getHost();
        } catch (Exception e) {
            return url;
        }
    }

    private static String trim(String s) {
        s = s.strip();
        return s.length() > 300 ? s.substring(0, 300) + "..." : s;
    }
}
