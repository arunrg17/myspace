package com.apitest.server.web;

import com.apitest.server.service.EngineService;
import com.apitest.server.service.ProjectManager;
import com.apitest.server.service.RunService;
import com.apitest.server.service.SettingsService;
import com.apitest.server.service.WorkspaceService;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The HTTP contract the GUI talks to. Kept as thin adapters over the service
 * layer - every rule (containment, hygiene, storage) lives in the services,
 * which carry their own tests.
 */
@RestController
@RequestMapping("/api")
public class ApiController {

    private final ProjectManager projects;

    /** Live SSE subscribers per run. */
    private final Map<String, SseEmitter> streams = new ConcurrentHashMap<>();
    /** Console lines buffered until (and after) the subscriber attaches. */
    private final Map<String, List<String>> consoles = new ConcurrentHashMap<>();
    private final Map<String, Map<String, Object>> summaries = new ConcurrentHashMap<>();

    public ApiController(ProjectManager projects) {
        this.projects = projects;
    }

    // The project a request targets is taken from the X-Project header (the GUI
    // sends the selected project). Missing/unknown falls back to the default,
    // so nothing errors on a stale selection. Each accessor resolves the current
    // request's project, so every handler works only within that project's
    // isolated workspace.
    private ProjectManager.Project current() {
        var attrs = org.springframework.web.context.request.RequestContextHolder
                .getRequestAttributes();
        String projectId = null;
        if (attrs instanceof org.springframework.web.context.request.ServletRequestAttributes sra) {
            var request = sra.getRequest();
            projectId = request.getHeader("X-Project");
            // Report links open in a new tab via window.open, which can't set a
            // header - those requests carry the project as a ?project= query
            // parameter instead. The header wins when both are present.
            if (projectId == null || projectId.isBlank()) {
                projectId = request.getParameter("project");
            }
        }
        return projects.get(projectId);
    }

    private WorkspaceService workspace() { return current().workspace(); }
    private RunService runs()            { return current().runs(); }
    private EngineService engine()       { return current().engine(); }
    private SettingsService settings()   { return current().settings(); }

    // context

    /** All projects the app knows about, for the selector. */
    @GetMapping("/projects")
    public Map<String, Object> listProjects() {
        return Map.of("projects", projects.list(),
                "active", current().id());
    }

    /** Create a new project with its own isolated workspace. */
    @PostMapping(value = "/projects", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, String> createProject(@RequestParam String name,
                                             @RequestParam(required = false) String id) {
        try {
            return projects.create(id, name);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }


    @GetMapping("/context")
    public Map<String, Object> context() throws IOException {
        Map<String, Object> out = new LinkedHashMap<>();
        var proj = current();
        out.put("project", Map.of("id", proj.id(), "name", proj.name()));
        out.put("root", workspace().root().toString());
        out.put("engine", "in-process");
        out.put("version", com.apitest.Version.VERSION);
        out.put("templates", workspace().area("templates").toString());
        out.put("templatesOk", Files.isDirectory(workspace().area("templates")));
        out.put("expected", workspace().area("expected").toString());
        out.put("expectedOk", Files.isDirectory(workspace().area("expected")));
        out.put("output", workspace().area("runs").toString());
        out.put("workbooks", workspace().workbooks().stream()
                .map(WorkspaceService.Entry::name).toList());
        return out;
    }

    // workspace file management

    @GetMapping("/files")
    public Map<String, Object> listFiles(@RequestParam String area,
                                         @RequestParam(defaultValue = "") String path) {
        try {
            return Map.of("entries", workspace().list(area, path));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @PostMapping("/files")
    public Map<String, Object> upload(@RequestParam String area,
                                      @RequestHeader("X-Filename") String filename,
                                      InputStream body,
                                      @RequestHeader(value = "X-User", required = false) String user) {
        try {
            var saved = workspace().save(area, filename, body);
            workspace().audit(user, "upload", area + "/" + saved.path());
            return Map.of("saved", saved.path(), "bytes", saved.size());
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @GetMapping("/files/download")
    public ResponseEntity<FileSystemResource> download(@RequestParam String area,
                                                       @RequestParam String path) {
        try {
            Path file = workspace().fileForDownload(area, path);
            return ResponseEntity.ok()
                    .header("Content-Disposition",
                            "attachment; filename=\"" + file.getFileName() + "\"")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new FileSystemResource(file));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
        }
    }

    @DeleteMapping("/files")
    public Map<String, Object> delete(@RequestParam String area, @RequestParam String path,
                                      @RequestHeader(value = "X-User", required = false) String user) {
        try {
            workspace().delete(area, path);
            workspace().audit(user, "delete", area + "/" + path);
            return Map.of("deleted", path);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    /** Workbook upload endpoint the existing GUI already calls. */
    @PostMapping("/upload")
    public Map<String, Object> uploadWorkbook(@RequestHeader("X-Filename") String filename,
                                              InputStream body) {
        return upload("workbooks", filename, body, null);
    }

    // runs

    @PostMapping(value = "/run", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> run(@RequestParam String workbook,
                                   @RequestParam(defaultValue = "API test run") String name,
                                   @RequestParam(defaultValue = "true") boolean save) {
        try {
            // Resolve the project now, on the request thread where the project
            // header is available. The run's completion callback fires on a
            // worker thread that has no HTTP request context, so it cannot
            // resolve the project itself - it must use the service captured here.
            // Reading results through the wrong (default) project's workspace is
            // what left completed runs showing "error" with a blank summary.
            RunService runService = runs();
            List<String> console = new java.util.concurrent.CopyOnWriteArrayList<>();
            // The pump thread can emit before start() returns the runId, so the
            // callbacks wait on this latch until registration has happened.
            var registered = new java.util.concurrent.CountDownLatch(1);
            var runIdHolder = new java.util.concurrent.atomic.AtomicReference<String>("");

            var handle = runService.start(workbook, name, save,
                    line -> {
                        await(registered);
                        console.add(line);
                        SseEmitter emitter = streams.get(runIdHolder.get());
                        if (emitter != null) {
                            try {
                                emitter.send(SseEmitter.event().name("line").data(line));
                            } catch (IOException ignored) { }
                        }
                    },
                    exit -> {
                        await(registered);
                        // A dry run's folder is about to be deleted, so capture
                        // its report now while it still exists on disk.
                        if (!save) captureDryRun(runService, runIdHolder.get());
                        finish(runService, runIdHolder.get(), exit);
                    });

            runIdHolder.set(handle.runId());
            consoles.put(handle.runId(), console);
            registered.countDown();
            return Map.of("runId", handle.runId());
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    /** Rendered reports for dry runs, held in memory only (never on the volume). */
    private final Map<String, String> dryRunReports = new ConcurrentHashMap<>();

    private void captureDryRun(RunService runService, String runId) {
        try {
            var env = runService.results(runId);
            if (env != null) {
                dryRunReports.put(runId,
                        com.apitest.reporter.Reporter.renderHtml(env.results, env.suiteName));
            }
        } catch (IOException ignored) {
            // No results to capture (e.g. the workbook failed to load).
        }
    }

    private static void await(java.util.concurrent.CountDownLatch latch) {
        try {
            latch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void finish(RunService runService, String runId, int exit) {
        Map<String, Object> summary = new LinkedHashMap<>();
        boolean hasReport = false;
        try {
            var env = runService.results(runId);
            if (env != null) {
                summary.put("passed", env.summary.passed);
                summary.put("failed", env.summary.failed);
                summary.put("errored", env.summary.errored);
                summary.put("durationMs", env.summary.durationMs);
                // exit 130 is a cancellation from the engine; it wins over the
                // pass/fail counts, which are only partial for a stopped run.
                // Otherwise a run is "error" only when it is entirely errors -
                // any real failures make it a "fail", which is what the user
                // cares about; a mix of failures and errors should not hide the
                // failures behind an "error" label.
                summary.put("status", exit == 130 ? "cancelled"
                        : env.summary.errored > 0 && env.summary.failed == 0 && env.summary.passed == 0 ? "error"
                        : env.summary.failed > 0 || env.summary.errored > 0 ? "fail" : "pass");
                hasReport = true;
            } else {
                summary.put("passed", 0);
                summary.put("failed", 0);
                summary.put("errored", 0);
                summary.put("durationMs", 0);
                summary.put("status", exit == 130 ? "cancelled" : "error");
            }
        } catch (IOException e) {
            summary.put("status", "error");
        }
        summary.put("exit", exit);
        // A dry run keeps its report only in memory; a saved run has it on disk.
        // Either way, only advertise a report link when one can actually be
        // opened - otherwise the button leads to an error page.
        if (dryRunReports.containsKey(runId)) hasReport = true;
        if (hasReport) {
            summary.put("report", "/api/reports/" + runId + "/html");
        }
        summaries.put(runId, summary);

        SseEmitter emitter = streams.remove(runId);
        if (emitter != null) {
            try {
                emitter.send(SseEmitter.event().name("done")
                        .data(summary, MediaType.APPLICATION_JSON));
                emitter.complete();
            } catch (IOException ignored) { }
        }
    }

    @GetMapping("/stream")
    public SseEmitter stream(@RequestParam String runId) {
        SseEmitter emitter = new SseEmitter(0L);
        // Replay whatever printed before the subscriber attached.
        List<String> console = consoles.get(runId);
        try {
            if (console != null) {
                for (String line : console) {
                    emitter.send(SseEmitter.event().name("line").data(line));
                }
            }
            Map<String, Object> done = summaries.get(runId);
            if (done != null) {
                emitter.send(SseEmitter.event().name("done")
                        .data(done, MediaType.APPLICATION_JSON));
                emitter.complete();
                return emitter;
            }
        } catch (IOException e) {
            emitter.completeWithError(e);
            return emitter;
        }
        streams.put(runId, emitter);
        emitter.onCompletion(() -> streams.remove(runId, emitter));
        emitter.onTimeout(() -> streams.remove(runId, emitter));
        return emitter;
    }

    @PostMapping(value = "/cancel", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> cancel(@RequestParam String runId) {
        return Map.of("cancelled", runs().cancel(runId));
    }

    // history, results, reports, trends

    /**
     * Runs still executing right now, so a browser returning to the run screen
     * can re-attach to one it started earlier instead of showing Idle. Each id
     * can be streamed again at /stream, which replays the console from the top.
     */
    @GetMapping("/active")
    public Map<String, Object> active() {
        RunService rs = runs();
        java.util.List<Map<String, Object>> items = new java.util.ArrayList<>();
        for (String id : rs.activeRuns()) {
            Map<String, Object> m = new java.util.HashMap<>();
            m.put("runId", id);
            boolean queued = rs.isQueued(id);
            m.put("state", queued ? "queued" : "running");
            if (queued) m.put("ahead", rs.queuePosition(id));
            items.add(m);
        }
        return Map.of(
                "runIds", new java.util.ArrayList<>(rs.activeRuns()),
                "runs", items,
                "executing", rs.executingCount(),
                "maxConcurrent", rs.maxConcurrentRuns());
    }

    /** Health of one workbook across its recent runs (pass/fail trend, flaky tests). */
    @GetMapping("/workbook-health")
    public Map<String, Object> workbookHealth(@RequestParam String workbook) throws IOException {
        return runs().workbookHealth(workbook, 30);
    }

    @GetMapping("/history")
    public Map<String, Object> history() throws IOException {
        return Map.of("entries", runs().history().stream().map(r -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("runId", r.runId());
            m.put("name", r.name());
            m.put("workbook", r.workbook());
            m.put("status", r.status());
            m.put("passed", r.passed());
            m.put("failed", r.failed());
            m.put("errored", r.errored());
            m.put("startedAt", r.startedAt());
            // Only offer a report link when there is actually a report to open -
            // a cancelled or errored run with no stored results has none, and a
            // link to it would just show an error page.
            if (r.hasReport()) {
                m.put("report", "/api/reports/" + r.runId() + "/html");
            }
            return m;
        }).toList());
    }

    /** The GUI historically passed a report path; accept a bare runId too. */
    /** The stored JSON itself, for tooling and export (always plain JSON). */
    @GetMapping(value = "/reports/{runId}/json", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> reportJson(@PathVariable String runId) {
        try {
            var env = runs().results(runId);
            if (env == null) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No results for " + runId);
            }
            // Re-serialize so the caller always gets plain JSON even when the
            // run is stored gzipped on the volume.
            return ResponseEntity.ok()
                    .header("Content-Disposition", "attachment; filename=\"report.json\"")
                    .body(com.apitest.reporter.JsonReport.toJson(env.results, env.suiteName));
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    /** The report, regenerated from stored JSON at request time. */
    @GetMapping(value = "/reports/{runId}/html", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> reportHtml(@PathVariable String runId,
                                             @RequestParam(defaultValue = "false") boolean download) {
        String html;
        String dry = dryRunReports.get(runId);
        if (dry != null) {
            html = dry;
        } else {
            try {
                html = runs().reportHtml(runId);
            } catch (IOException e) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage());
            }
        }
        // The report is one self-contained HTML file - all CSS and JS inlined -
        // so a downloaded copy works fully offline, every tab and link intact.
        // download=true makes the browser save it; otherwise it opens inline.
        ResponseEntity.BodyBuilder b = ResponseEntity.ok().contentType(MediaType.TEXT_HTML);
        if (download) {
            b.header("Content-Disposition", "attachment; filename=\"report-" + runId + ".html\"");
        }
        return b.body(html);
    }

    // engine capabilities (in-process)

    /** Structural check of a workbook: does it parse, what is in it, problems. */
    @GetMapping("/validate")
    public Map<String, Object> validate(@RequestParam String workbook) {
        try {
            return engine().validate(workbook);
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    /** Preview a test's resolved endpoint and body without sending anything. */
    /** Run exactly one test and return its result envelope. */
    /** Render a report from a results JSON posted in the body (results.json). */
    // settings and sources

    @GetMapping("/settings")
    public Map<String, String> getSettings() throws IOException {
        return settings().forDisplay();
    }

    @PostMapping(value = "/settings", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> saveSettings(@RequestParam Map<String, String> form)
            throws IOException {
        settings().save(form);
        return Map.of("saved", true);
    }

    /**
     * Download a starter workbook. First-time users get a correctly-structured
     * template - the six sheets with headers and a couple of example rows - so
     * they are not building the workbook from a blank page.
     *
     * <p>The file served is config/test_suite_template.xlsx in the workspace,
     * so a team can drop in its own house template and everyone downloads that.
     */
    @GetMapping("/template")
    public ResponseEntity<?> template() throws IOException {
        // A team can drop its own house template into the workspace config/
        // folder and everyone downloads that. When none is installed - which is
        // the case on a fresh workspace - fall back to the copy bundled inside
        // the application, so a first-time user always has a current template.
        Path installed = workspace().area("config").resolve("test_suite_template.xlsx");
        if (Files.isRegularFile(installed)) {
            return ResponseEntity.ok()
                    .header("Content-Disposition",
                            "attachment; filename=\"test_suite_template.xlsx\"")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(new FileSystemResource(installed));
        }
        var bundled = new ClassPathResource("templates/test_suite_template.xlsx");
        if (bundled.exists()) {
            byte[] bytes;
            try (var in = bundled.getInputStream()) {
                bytes = in.readAllBytes();
            }
            return ResponseEntity.ok()
                    .header("Content-Disposition",
                            "attachment; filename=\"test_suite_template.xlsx\"")
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .body(bytes);
        }
        throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No template is available.");
    }

    /** Whether a template is available to download (drives the GUI button). */
    @GetMapping("/template/available")
    public Map<String, Object> templateAvailable() {
        // Always true now: the app ships a template as a fallback, so the
        // download is offered even before anyone installs a house template.
        boolean installed = Files.isRegularFile(
                workspace().area("config").resolve("test_suite_template.xlsx"));
        boolean bundled = new ClassPathResource("templates/test_suite_template.xlsx").exists();
        return Map.of("available", installed || bundled);
    }

    /**
     * Workbooks visible in the configured shared folder (src.folder.path), so
     * teams can keep suites outside the workspace and pull them in on demand.
     */
    @GetMapping("/sources/list")
    public Map<String, Object> sourcesList(@RequestParam String type) throws IOException {
        if (!"folder".equals(type)) {
            return Map.of("items", List.of(),
                    "error", "Source type '" + type + "' is not configured on this server");
        }
        String configured = settings().raw("src.folder.path");
        if (configured.isBlank()) {
            return Map.of("items", List.of(), "error",
                    "No shared folder configured. Set it under Settings > Workbook sources.");
        }
        Path dir = Path.of(configured);
        if (!Files.isDirectory(dir)) {
            return Map.of("items", List.of(), "error", "Not a directory: " + configured);
        }
        try (var children = Files.list(dir)) {
            return Map.of("items", children
                    .filter(p -> WorkspaceService.extension(p.getFileName().toString())
                            .matches("xlsx|xlsm"))
                    .map(p -> {
                        try {
                            return Map.of("name", p.getFileName().toString(),
                                    "path", p.toString(), "size", Files.size(p));
                        } catch (IOException e) {
                            return Map.of("name", p.getFileName().toString(),
                                    "path", p.toString(), "size", 0L);
                        }
                    }).toList());
        }
    }

    /** Copy a workbook from the shared folder into the workspace(). */
    @PostMapping(value = "/sources/fetch", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> sourcesFetch(@RequestParam String type, @RequestParam String path)
            throws IOException {
        if (!"folder".equals(type)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Source type '" + type + "' is not configured on this server");
        }
        String configured = settings().raw("src.folder.path");
        Path source = Path.of(path).toAbsolutePath().normalize();
        if (configured.isBlank()
                || !source.startsWith(Path.of(configured).toAbsolutePath().normalize())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Path is outside the configured shared folder");
        }
        try (InputStream in = Files.newInputStream(source)) {
            var saved = workspace().save("workbooks", source.getFileName().toString(), in);
            workspace().audit(null, "fetch", saved.path() + " <- " + source);
            return Map.of("saved", saved.path(), "bytes", saved.size());
        }
    }

    /**
     * Look for OneDrive / SharePoint folders that have been synced to this
     * machine, so the user can pick one instead of typing a path. Synced
     * libraries appear as ordinary folders under the user's home - commonly
     * "OneDrive", "OneDrive - <Company>", or a company-named folder holding
     * synced document libraries. This lists those top-level candidates; the
     * user picks one and can then drill in by editing the path.
     */
    @GetMapping("/sources/discover")
    public Map<String, Object> discover() {
        List<Map<String, String>> found = new java.util.ArrayList<>();
        String home = System.getProperty("user.home", "");
        if (!home.isBlank()) {
            Path homePath = Path.of(home);
            try (var top = Files.list(homePath)) {
                top.filter(Files::isDirectory)
                   .filter(p -> {
                       String n = p.getFileName().toString();
                       return n.startsWith("OneDrive")           // personal + business
                               || n.contains("SharePoint")
                               || n.toLowerCase().contains("- ");  // "Company - Documents" style
                   })
                   .forEach(p -> found.add(Map.of(
                           "name", p.getFileName().toString(),
                           "path", p.toString())));
            } catch (IOException ignored) {
                // Home not listable - just return nothing found.
            }
        }
        return Map.of("items", found);
    }

    // assistant: an OpenAI-compatible internal LLM endpoint

    /** Connection status for the settings screen (never returns the key). */
    @GetMapping("/ai/config")
    public Map<String, Object> aiConfig() {
        return current().ai().status();
    }

    /** Ask the configured assistant a question. */
    @PostMapping(value = "/ai/ask", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, Object> aiAsk(@RequestParam String prompt) {
        if (prompt == null || prompt.isBlank()) {
            return Map.of("error", "Ask a question first.");
        }
        try {
            return Map.of("answer", current().ai().ask(prompt));
        } catch (IllegalStateException e) {
            return Map.of("error", "The assistant is not configured. Set the base URL, "
                    + "API key and model under Settings > Assistant.");
        } catch (IOException e) {
            return Map.of("error", e.getMessage());
        }
    }
}
