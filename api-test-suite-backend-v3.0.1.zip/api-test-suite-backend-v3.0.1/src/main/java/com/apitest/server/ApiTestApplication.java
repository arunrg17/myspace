package com.apitest.server;

import com.apitest.Main;
import com.apitest.server.service.ProjectManager;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Set;

/**
 * The API test suite: the test engine and the web service that drives it, in
 * one application.
 *
 * <p>The jar runs either way. Given one of the engine's own flags it behaves as
 * a command line tool, runs the suite and exits with a status a CI job can gate
 * on. Given anything else - or nothing - it starts the web service, and runs
 * then execute in-process on worker threads.
 *
 * <p>All state lives under one configured workspace root, so the application
 * itself holds nothing and can be restarted or rescheduled freely. Set the root
 * with {@code apitest.workspace}, the {@code APITEST_WORKSPACE} environment
 * variable, or {@code --apitest.workspace=...}.
 */
@SpringBootApplication
@EnableConfigurationProperties(ApiTestApplication.WorkspaceProperties.class)
public class ApiTestApplication {

    /**
     * Flags that mean the caller wants the command line tool rather than the
     * service. Everything else, including Spring's own --server.port style
     * arguments, falls through to the web application.
     */
    private static final Set<String> CLI_FLAGS =
            Set.of("--suite", "--help", "-h", "--version", "-v");

    @ConfigurationProperties(prefix = "apitest")
    public record WorkspaceProperties(String workspace) {
        public WorkspaceProperties {
            if (workspace == null || workspace.isBlank()) workspace = "./workspace";
        }
    }

    public static void main(String[] args) throws Exception {
        if (isCommandLineRun(args)) {
            // Main parses the remaining flags, runs the suite and sets the
            // exit status itself.
            Main.main(args);
            return;
        }
        SpringApplication.run(ApiTestApplication.class, args);
    }

    static boolean isCommandLineRun(String[] args) {
        if (args == null) return false;
        for (String arg : args) {
            if (arg != null && CLI_FLAGS.contains(arg)) return true;
        }
        return false;
    }

    @Bean
    public ProjectManager projectManager(WorkspaceProperties props) throws IOException {
        return new ProjectManager(Path.of(props.workspace()));
    }
}
