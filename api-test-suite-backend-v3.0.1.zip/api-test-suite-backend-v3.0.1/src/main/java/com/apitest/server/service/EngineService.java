package com.apitest.server.service;

import com.apitest.excel.ExcelLoader;
import com.apitest.model.TestCase;
import com.apitest.model.TestSuite;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Engine capabilities exposed for the GUI to call directly, in-process.
 *
 * <p>These are the read-only and single-shot operations that used to require
 * running the whole jar: checking a workbook parses without sending any
 * traffic.
 */
public class EngineService {

    private final WorkspaceService workspace;

    public EngineService(WorkspaceService workspace) {
        this.workspace = workspace;
    }

    // validate / parse

    /** A structural check of a workbook: does it parse, and what is in it. */
    public Map<String, Object> validate(String workbookRel) throws IOException {
        Path workbook = workspace.fileForDownload("workbooks", workbookRel);
        Map<String, Object> out = new LinkedHashMap<>();
        try {
            TestSuite suite = ExcelLoader.load(workbook);
            out.put("ok", true);
            out.put("environments", new ArrayList<>(suite.environments().keySet()));

            List<Map<String, Object>> tests = new ArrayList<>();
            List<String> problems = new ArrayList<>();
            for (TestCase tc : suite.tests()) {
                Map<String, Object> t = new LinkedHashMap<>();
                t.put("testId", tc.testId);
                t.put("name", tc.name);
                t.put("mode", tc.comparisonMode);
                t.put("enabled", tc.enabled);
                t.put("steps", tc.steps.size());
                t.put("assertions", tc.assertions == null ? 0 : tc.assertions.size());
                tests.add(t);

                // Surface the mistakes that only show up at run time otherwise.
                if (tc.sourceA != null && !tc.sourceA.isBlank()
                        && !suite.environments().containsKey(tc.sourceA)) {
                    problems.add(tc.testId + ": SourceA '" + tc.sourceA + "' is not defined");
                }
                boolean needsB = "vs_env".equals(tc.comparisonMode)
                        || "vs_protocol".equals(tc.comparisonMode);
                if (needsB) {
                    if (tc.sourceB == null || tc.sourceB.isBlank()) {
                        problems.add(tc.testId + ": " + tc.comparisonMode + " needs a SourceB");
                    } else if (!suite.environments().containsKey(tc.sourceB)) {
                        problems.add(tc.testId + ": SourceB '" + tc.sourceB + "' is not defined");
                    }
                }
                if ("vs_expected".equals(tc.comparisonMode)
                        && (tc.expectedFile == null || tc.expectedFile.isBlank())) {
                    problems.add(tc.testId + ": vs_expected needs an ExpectedFile");
                }
                if (tc.steps.isEmpty()) {
                    problems.add(tc.testId + ": has no steps");
                }
            }
            out.put("tests", tests);
            out.put("problems", problems);
        } catch (Exception e) {
            out.put("ok", false);
            out.put("error", e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
        }
        return out;
    }
}
