package com.apitest.server.service;

import com.apitest.model.TestResult;
import com.apitest.reporter.JsonReport;
import com.apitest.reporter.Reporter;
import com.apitest.runner.RunConfig;
import com.apitest.runner.Runner;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.stream.Stream;

/**
 * Runs suites in-process and owns everything under {@code runs/}.
 *
 * <p>The engine is part of this application, not a separate jar. A run executes
 * on a worker thread by calling {@link Runner#runAll} directly - no subprocess,
 * nothing to place on the volume. Each run still gets its own folder holding a
 * frozen copy of the workbook, a console log of the progress lines, and the
 * results as {@code report.json}. Only the JSON is stored; the HTML report is
 * regenerated from it on demand, so a long-lived archive stays small.
 *
 * <p>Runs are isolated from each other: one thread per run, its own output
 * folder, and its own cancellation flag. One wedged or failing suite cannot
 * affect another, and the engine already captures per-test errors so a single
 * bad test never aborts the run.
 */
public class RunService {

    /** A handle to a started run. */
    public record RunHandle(String runId) {}

    /** What the GUI needs to list a past run. */
    public record RunRecord(String runId, String name, String workbook, String status,
                            int passed, int failed, int errored, String startedAt,
                            long durationMs, boolean hasReport) {}

    private final WorkspaceService workspace;
    private final SettingsService settings;
    private final ExecutorService pool = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "apitest-run");
        t.setDaemon(true);
        return t;
    });
    /** Cancellation flags for in-flight runs. */
    private final Map<String, AtomicBoolean> active = new ConcurrentHashMap<>();
    /** Where each run's files live (runs/<id>, or a temp dir for a dry run). */
    private final Map<String, Path> runDirs = new ConcurrentHashMap<>();

    // Concurrency gate. Runs acquire a permit before they execute; when every
    // permit is taken, further runs block on the semaphore and so wait their
    // turn instead of all hammering the server and the systems under test at
    // once. The limit comes from the max.concurrent.runs setting and is applied
    // per run so a settings change takes effect on the next run without a
    // restart. runsExecuting holds the ids that hold a permit right now, which
    // lets the status logic tell a queued run apart from a running one.
    private static final String MAX_RUNS_KEY = "max.concurrent.runs";
    private static final int MAX_RUNS_DEFAULT = 4;

    /** Semaphore that also lets us shrink the permit count when the limit drops. */
    private static final class ResizableGate extends java.util.concurrent.Semaphore {
        ResizableGate(int permits) { super(permits, true); }
        void shrink(int n) { reducePermits(n); }
    }

    private final ResizableGate gate = new ResizableGate(MAX_RUNS_DEFAULT);
    private volatile int gatePermits = MAX_RUNS_DEFAULT;
    private final java.util.Set<String> runsExecuting = ConcurrentHashMap.newKeySet();

    /**
     * Resize the gate to the current max.concurrent.runs setting. The semaphore
     * is created with a fixed count, so a change is applied by handing back or
     * reclaiming the difference. Reclaimed permits are only taken as running
     * runs release them, so lowering the limit never interrupts a run already
     * under way - it just holds the next ones back until the count settles.
     */
    private synchronized void syncGateLimit() {
        int want = settings.getInt(MAX_RUNS_KEY, MAX_RUNS_DEFAULT);
        if (want < 1) want = 1;
        if (want > gatePermits) {
            gate.release(want - gatePermits);
        } else if (want < gatePermits) {
            gate.shrink(gatePermits - want);
        }
        gatePermits = want;
    }

    public RunService(WorkspaceService workspace, SettingsService settings) {
        this.workspace = workspace;
        this.settings = settings;
    }

    /**
     * Start a run on a worker thread. Progress lines go to {@code onLine} as
     * each test starts and finishes; {@code onDone} fires once with an exit-like
     * code (0 all passed, 1 failures/errors, 130 cancelled, -1 internal error).
     */
    public RunHandle start(String workbookRel, String runName,
                           Consumer<String> onLine, Consumer<Integer> onDone) throws IOException {
        return start(workbookRel, runName, true, onLine, onDone);
    }

    /**
     * Start a run.
     *
     * <p>When {@code persist} is false the run executes in a temporary folder
     * deleted on completion: the report and console still stream to the browser,
     * but nothing is written under {@code runs/}. That is for the dry runs done
     * while automating a new service, which would otherwise fill the volume with
     * results nobody keeps.
     */
    public RunHandle start(String workbookRel, String runName, boolean persist,
                           Consumer<String> onLine, Consumer<Integer> onDone) throws IOException {
        Path workbook = workspace.fileForDownload("workbooks", workbookRel);

        String runId = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")
                .format(java.time.LocalDateTime.now()) + "_" + Integer.toHexString(
                        (workbookRel + System.nanoTime()).hashCode()).substring(0, 4);
        Path runDir = persist
                ? workspace.area("runs").resolve(runId)
                : Files.createTempDirectory("apitest-dryrun-");
        Files.createDirectories(runDir);
        runDirs.put(runId, runDir);

        // Freeze the workbook so the record of what ran survives later edits to
        // the shared copy.
        Path frozen = runDir.resolve(workbook.getFileName().toString());
        Files.copy(workbook, frozen, StandardCopyOption.REPLACE_EXISTING);
        String name = runName == null || runName.isBlank() ? "API test run" : runName;
        Files.writeString(runDir.resolve("meta.properties"),
                "name=" + escape(name) + "\n"
                + "workbook=" + escape(workbookRel) + "\n"
                + "startedAt=" + Instant.now() + "\n");

        AtomicBoolean cancelled = new AtomicBoolean(false);
        active.put(runId, cancelled);

        RunConfig cfg = new RunConfig(
                frozen,
                runDir.resolve("report.html"),
                workspace.root(),
                workspace.area("templates"),
                workspace.area("expected"),
                runDir,
                name);

        pool.submit(() -> {
            int code = -1;
            // Wait for a concurrency permit before doing any work. Until this
            // returns, the run sits in the queue: it has a run id and a "queued"
            // status on disk, but consumes no engine resources. syncGateLimit
            // first so a change to the limit is picked up for this run.
            syncGateLimit();
            boolean acquired = false;
            try {
                gate.acquire();
                acquired = true;
                runsExecuting.add(runId);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                active.remove(runId);
                onDone.accept(130);
                return;
            }
            try (var console = Files.newBufferedWriter(runDir.resolve("console.log"))) {
                Consumer<String> sink = line -> {
                    try {
                        console.write(line);
                        console.newLine();
                        console.flush();
                    } catch (IOException ignored) { }
                    onLine.accept(line);
                };
                try {
                    StoragePolicy policy = StoragePolicy.from(settings);
                    List<TestResult> results = Runner.runAll(cfg, sink, cancelled::get);
                    policy.write(results, runDir, name);
                    boolean anyBad = results.stream()
                            .anyMatch(r -> !"PASS".equals(r.status));
                    code = cancelled.get() ? 130 : (anyBad ? 1 : 0);
                    // cancel() already recorded the cancelled flag on disk the
                    // moment it was requested, so history is correct no matter
                    // how we exit here.
                    sink.accept(cancelled.get() ? "  Run cancelled" : summaryLine(results));
                } catch (Exception e) {
                    // If the run was cancelled, an interrupted in-flight call can
                    // surface as an exception - that is still a cancellation, not
                    // an error. cancel() has already flagged it on disk.
                    code = cancelled.get() ? 130 : -1;
                    sink.accept(cancelled.get() ? "  Run cancelled"
                            : "[error] " + e.getClass().getSimpleName() + ": " + e.getMessage());
                }
            } catch (IOException e) {
                onLine.accept("[error] could not open console log: " + e.getMessage());
                code = -1;
            } finally {
                active.remove(runId);
                // Hand the concurrency permit back so a queued run can start,
                // and drop this run from the executing set. Guarded by the
                // acquired flag so an interrupted acquire never over-releases.
                if (acquired) {
                    runsExecuting.remove(runId);
                    gate.release();
                }
                // Record on disk that this run has ended, with its exit code.
                // Status must not depend on the in-memory active map alone: if
                // the browser closes, the server restarts, or the worker dies,
                // that map is gone, but this marker persists - so a finished run
                // never shows "running" forever, and a run with no results is
                // told apart from one still genuinely in progress.
                try {
                    Files.writeString(runDir.resolve("meta.properties"),
                            "finished=" + code + "\n",
                            java.nio.file.StandardOpenOption.APPEND,
                            java.nio.file.StandardOpenOption.CREATE);
                } catch (IOException ignored) { }
                if (persist) {
                    // The frozen workbook and console log are kept only as a
                    // record - nothing reads them back at request time - and the
                    // workbook especially can be large. Gzip both now that the
                    // run is done, so a kept run's folder stays small.
                    gzipInPlace(runDir.resolve(frozen.getFileName().toString()));
                    gzipInPlace(runDir.resolve("console.log"));
                    // The engine also drops per-test request.txt / response.txt
                    // debug files under a timestamped subfolder. Everything in
                    // them is already in report.json (which the HTML report is
                    // rebuilt from), so for large suites they are pure
                    // duplication - the real space hog. Compact that tree:
                    // gzip each text file in place, keeping the folder browsable
                    // but small.
                    StoragePolicy policy = StoragePolicy.from(settings);
                    compactArtifacts(runDir, policy);
                }
            }
            // onDone runs while a dry run's results are still on disk, so the
            // caller can capture the report before we delete the temp folder.
            onDone.accept(code);
            if (!persist) {
                deleteQuietly(runDir);
                runDirs.remove(runId);
            }
        });

        workspace.audit(null, persist ? "run.start" : "run.start.dry",
                runId + " " + workbookRel);
        return new RunHandle(runId);
    }

    private static String summaryLine(List<TestResult> results) {
        long passed = results.stream().filter(r -> "PASS".equals(r.status)).count();
        long failed = results.stream().filter(r -> "FAIL".equals(r.status)).count();
        long errored = results.stream().filter(r -> !"PASS".equals(r.status) && !"FAIL".equals(r.status)).count();
        return "  " + passed + " passed \u00b7 " + failed + " failed \u00b7 " + errored + " errored";
    }

    /** Ask an in-flight run to stop; it ends after the current test. */
    public boolean cancel(String runId) {
        AtomicBoolean flag = active.get(runId);
        if (flag == null) return false;
        flag.set(true);
        // Mark the run cancelled on disk immediately, the moment the request
        // arrives - not when the run finishes. However the run then ends (clean
        // break between tests, or an exception from an interrupted in-flight
        // call), history will read this and show "cancelled" rather than
        // treating the unfinished run as an error.
        Path dir = runDirs.get(runId);
        if (dir != null) {
            try {
                Files.writeString(dir.resolve("meta.properties"),
                        "cancelled=true\n", java.nio.file.StandardOpenOption.APPEND,
                        java.nio.file.StandardOpenOption.CREATE);
            } catch (IOException ignored) { }
        }
        workspace.audit(null, "run.cancel", runId);
        return true;
    }

    /** Run ids currently executing, so a returning browser can re-attach. */
    public java.util.Set<String> activeRuns() {
        return new java.util.HashSet<>(active.keySet());
    }

    /** Whether a specific run is still executing. */
    public boolean isActive(String runId) {
        return active.containsKey(runId);
    }

    /**
     * Whether a run is accepted but still waiting for a concurrency permit -
     * that is, sitting in the queue rather than executing. A run is queued when
     * it is active (has been started and not finished) but has not yet entered
     * the executing set.
     */
    public boolean isQueued(String runId) {
        return active.containsKey(runId) && !runsExecuting.contains(runId);
    }

    /**
     * How many runs are ahead of this one in the queue - the count of other
     * runs that are also waiting for a permit. Returns 0 when the run is not
     * queued (already executing, finished, or unknown). This is a position, not
     * a time: the wait depends on how long the running suites take, which the
     * server cannot predict, so no ETA is offered.
     */
    public int queuePosition(String runId) {
        if (!isQueued(runId)) return 0;
        int ahead = 0;
        for (String id : active.keySet()) {
            if (!id.equals(runId) && !runsExecuting.contains(id)) ahead++;
        }
        return ahead;
    }

    /** How many runs are executing right now (holding a permit). */
    public int executingCount() {
        return runsExecuting.size();
    }

    /** The configured ceiling on concurrent runs. */
    public int maxConcurrentRuns() {
        return settings.getInt(MAX_RUNS_KEY, MAX_RUNS_DEFAULT);
    }

    /** The stored results of a finished run, or null when it has none. */
    public JsonReport.Envelope results(String runId) throws IOException {
        Path dir = runDirs.getOrDefault(runId, workspace.resolve("runs", runId));
        return StoragePolicy.read(dir);
    }

    /**
     * The HTML report for a stored run, regenerated from its JSON. Identical to
     * what the engine would have written - same renderer, same data.
     */
    public String reportHtml(String runId) throws IOException {
        JsonReport.Envelope env = results(runId);
        if (env == null) throw new IOException("Run " + runId + " has no stored results");
        return Reporter.renderHtml(env.results, env.suiteName);
    }

    /** All stored runs, newest first. */
    public List<RunRecord> history() throws IOException {
        Path runs = workspace.area("runs");
        List<RunRecord> out = new ArrayList<>();
        try (Stream<Path> dirs = Files.list(runs)) {
            for (Path dir : dirs.filter(Files::isDirectory).toList()) {
                out.add(record(dir));
            }
        }
        out.sort(Comparator.comparing(RunRecord::startedAt).reversed());
        return out;
    }

    private RunRecord record(Path runDir) {
        String runId = runDir.getFileName().toString();
        String name = "", workbook = "", startedAt = "";
        boolean wasCancelled = false;
        String finishedCode = null;
        Path meta = runDir.resolve("meta.properties");
        if (Files.isRegularFile(meta)) {
            try {
                var props = new java.util.Properties();
                try (var in = Files.newInputStream(meta)) { props.load(in); }
                name = props.getProperty("name", "");
                workbook = props.getProperty("workbook", "");
                startedAt = formatStarted(props.getProperty("startedAt", ""));
                wasCancelled = "true".equals(props.getProperty("cancelled", ""));
                finishedCode = props.getProperty("finished");   // null until the run ends
            } catch (IOException ignored) { }
        }
        int passed = 0, failed = 0, errored = 0;
        long durationMs = 0;
        boolean hasReport = StoragePolicy.hasResults(runDir);
        // A finished=<code> line in meta means the run's worker thread ended,
        // whatever happened to the browser or server since. Its presence is the
        // authoritative "no longer running" signal.
        boolean finished = finishedCode != null;

        String status;
        if (hasReport) {
            try {
                JsonReport.Summary s = StoragePolicy.read(runDir).summary;
                passed = s.passed; failed = s.failed; errored = s.errored;
                durationMs = s.durationMs;
                status = wasCancelled ? "cancelled"
                        : s.errored > 0 && s.failed == 0 && s.passed == 0 ? "error"
                        : s.failed > 0 || s.errored > 0 ? "fail" : "pass";
            } catch (IOException e) {
                status = "error";
            }
        } else if (wasCancelled) {
            status = "cancelled";
        } else if (finished || !active.containsKey(runId)) {
            // Ended (marker present) or no longer tracked, but wrote no results:
            // that's a genuine error, not a run still in progress.
            status = "error";
        } else {
            status = "running";
        }
        return new RunRecord(runId, name, workbook, status, passed, failed, errored,
                startedAt, durationMs, hasReport);
    }

    /**
     * Compact the per-test debug artifacts (request.txt / response.txt /
     * render-log.txt) the engine writes under a timestamped subfolder of the
     * run. Everything in them is already in report.json, from which the HTML
     * report is rebuilt, so they are redundant on the server.
     *
     * <p>When the user has turned on any result-storage saving (trim, truncate
     * or gzip), the whole artifact tree is removed - report.json is the source
     * of truth and these files were the largest duplicated cost. When no saving
     * is selected, the files are gzipped in place instead, so nothing is lost
     * but the folder still shrinks.
     */
    private static void compactArtifacts(Path runDir, StoragePolicy policy) {
        boolean anySaving = policy.trimPrepared || policy.truncateBodies || policy.gzip;
        try (Stream<Path> entries = Files.list(runDir)) {
            for (Path entry : entries.filter(Files::isDirectory).toList()) {
                // The engine's artifact root is a timestamped folder; the run's
                // own known subfolders are never directories here.
                if (anySaving) {
                    deleteQuietly(entry);
                } else {
                    gzipTree(entry);
                }
            }
        } catch (IOException ignored) { }
    }

    /** Gzip every regular file under a directory tree, in place. */
    private static void gzipTree(Path dir) {
        try (Stream<Path> walk = Files.walk(dir)) {
            for (Path p : walk.filter(Files::isRegularFile).toList()) {
                gzipInPlace(p);
            }
        } catch (IOException ignored) { }
    }

    /**
     * Replace a file with its gzipped form ({@code name.gz}), deleting the
     * original. Best-effort: on any error the original is left untouched.
     */
    private static void gzipInPlace(Path file) {
        if (!Files.isRegularFile(file)) return;
        Path gz = file.resolveSibling(file.getFileName().toString() + ".gz");
        try {
            try (var in = Files.newInputStream(file);
                 var out = new java.util.zip.GZIPOutputStream(Files.newOutputStream(gz))) {
                in.transferTo(out);
            }
            Files.deleteIfExists(file);
        } catch (IOException e) {
            try { Files.deleteIfExists(gz); } catch (IOException ignored) { }
        }
    }

    /**
     * Health of a single workbook across its recent runs: the pass/fail of each
     * run, and which tests are "flaky" - seen both passing and failing, the ones
     * worth investigating. Only runs of this workbook are considered, so the
     * view is about one suite rather than everything.
     */
    public Map<String, Object> workbookHealth(String workbookRel, int maxRuns) throws IOException {
        List<Map<String, Object>> runs = new ArrayList<>();
        // Per test, across the runs considered.
        Map<String, int[]> perTest = new java.util.LinkedHashMap<>();   // [pass, fail, total]
        Map<String, String> testName = new java.util.HashMap<>();
        Map<String, List<Long>> perTestDurations = new java.util.LinkedHashMap<>();
        // The most recent failure reason seen for a test (newest run wins).
        Map<String, String> lastFailReason = new java.util.HashMap<>();
        Map<String, Boolean> lastFailReasonSet = new java.util.HashMap<>();

        long totalPassed = 0, totalFailed = 0, totalErrored = 0, totalDuration = 0;
        // Pass rate of the newest and oldest run in view, for a trend arrow.
        Integer newestRate = null, oldestRate = null;

        int seen = 0;
        for (RunRecord r : history()) {           // history() is newest-first
            if (!workbookRel.equals(r.workbook())) continue;
            if (seen++ >= maxRuns) break;
            int tests = r.passed() + r.failed() + r.errored();
            runs.add(Map.of("runId", r.runId(), "name", r.name(),
                    "startedAt", r.startedAt(), "status", r.status(),
                    "passed", r.passed(), "failed", r.failed(),
                    "errored", r.errored(), "tests", tests,
                    "durationMs", r.durationMs()));

            totalPassed += r.passed();
            totalFailed += r.failed();
            totalErrored += r.errored();
            totalDuration += r.durationMs();
            int rate = tests == 0 ? 0 : (int) Math.round(100.0 * r.passed() / tests);
            if (newestRate == null) newestRate = rate;   // first seen = newest
            oldestRate = rate;                            // last seen = oldest

            JsonReport.Envelope env = results(r.runId());
            if (env == null) continue;
            for (var tr : env.results) {
                int[] c = perTest.computeIfAbsent(tr.testId, k -> new int[3]);
                boolean passed = "PASS".equals(tr.status);
                if (passed) c[0]++; else c[1]++;
                c[2]++;
                testName.putIfAbsent(tr.testId, tr.name);
                perTestDurations.computeIfAbsent(tr.testId, k -> new ArrayList<>())
                        .add(tr.durationMs);
                // Capture the reason from the newest run in which this test failed.
                if (!passed && !lastFailReasonSet.containsKey(tr.testId)) {
                    lastFailReason.put(tr.testId, failureReason(tr));
                    lastFailReasonSet.put(tr.testId, true);
                }
            }
        }

        // Flaky = a test that has both passed and failed across these runs.
        List<Map<String, Object>> flaky = new ArrayList<>();
        for (var e : perTest.entrySet()) {
            int[] c = e.getValue();
            if (c[0] > 0 && c[1] > 0) {
                Map<String, Object> row = new java.util.LinkedHashMap<>();
                row.put("testId", e.getKey());
                row.put("name", testName.getOrDefault(e.getKey(), e.getKey()));
                row.put("passed", c[0]);
                row.put("failed", c[1]);
                row.put("runs", c[2]);
                row.put("failRate", (int) Math.round(100.0 * c[1] / c[2]));
                row.put("lastFailure", lastFailReason.getOrDefault(e.getKey(), ""));
                flaky.add(row);
            }
        }
        flaky.sort((a, b) -> (int) b.get("failRate") - (int) a.get("failRate"));

        // Slowest tests by average duration across the runs in view.
        List<Map<String, Object>> slowest = new ArrayList<>();
        for (var e : perTestDurations.entrySet()) {
            List<Long> ds = e.getValue();
            if (ds.isEmpty()) continue;
            long avg = Math.round(ds.stream().mapToLong(Long::longValue).average().orElse(0));
            slowest.add(Map.of("testId", e.getKey(),
                    "name", testName.getOrDefault(e.getKey(), e.getKey()),
                    "avgMs", avg, "samples", ds.size()));
        }
        slowest.sort((a, b) -> Long.compare((long) b.get("avgMs"), (long) a.get("avgMs")));
        List<Map<String, Object>> topSlow = slowest.stream().limit(5).toList();

        // runs came newest-first; reverse for a left-to-right trend.
        List<Map<String, Object>> trend = new ArrayList<>(runs);
        java.util.Collections.reverse(trend);

        long totalTests = totalPassed + totalFailed + totalErrored;
        int overallPassRate = totalTests == 0 ? 0
                : (int) Math.round(100.0 * totalPassed / totalTests);
        long avgRunMs = runs.isEmpty() ? 0 : totalDuration / runs.size();
        // Positive = improving (newest better than oldest), negative = worse.
        int direction = (newestRate == null || oldestRate == null) ? 0
                : newestRate - oldestRate;

        Map<String, Object> summary = new java.util.LinkedHashMap<>();
        summary.put("passRate", overallPassRate);
        summary.put("totalTests", totalTests);
        summary.put("passed", totalPassed);
        summary.put("failed", totalFailed);
        summary.put("errored", totalErrored);
        summary.put("avgRunMs", avgRunMs);
        summary.put("trendDirection", direction);
        summary.put("flakyCount", flaky.size());

        Map<String, Object> out = new java.util.LinkedHashMap<>();
        out.put("workbook", workbookRel);
        out.put("runCount", runs.size());
        out.put("summary", summary);
        out.put("runs", runs);
        out.put("trend", trend);
        out.put("flaky", flaky);
        out.put("slowest", topSlow);
        return out;
    }

    /** A short human reason a test failed, drawn from its results. */
    private static String failureReason(com.apitest.model.TestResult tr) {
        if (tr.error != null && !tr.error.isBlank()) return tr.error;
        // First failed assertion, if any.
        if (tr.assertionResults != null) {
            for (var a : tr.assertionResults) {
                if (!a.passed) {
                    String at = a.path == null ? "" : a.path;
                    return "assertion failed: " + at
                            + (a.operator == null ? "" : " " + a.operator)
                            + (a.expectedValue == null ? "" : " " + a.expectedValue);
                }
            }
        }
        // Otherwise a count of differences.
        if (tr.compareResult != null && tr.compareResult.diffs != null
                && !tr.compareResult.diffs.isEmpty()) {
            return tr.compareResult.diffs.size() + " difference(s) from expected";
        }
        return "failed";
    }


    private static void deleteQuietly(Path dir) {
        try (Stream<Path> walk = Files.walk(dir)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (IOException ignored) { }
            });
        } catch (IOException ignored) { }
    }

    /**
     * Turn the stored ISO instant (e.g. 2026-08-12T13:55:18.123456Z) into a
     * plain second-precision local timestamp for display, matching the report.
     */
    private static String formatStarted(String iso) {
        if (iso == null || iso.isBlank()) return "";
        try {
            return java.time.LocalDateTime.ofInstant(
                            java.time.Instant.parse(iso), java.time.ZoneId.systemDefault())
                    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        } catch (Exception e) {
            // Unknown format: strip any fractional seconds rather than fail.
            int dot = iso.indexOf('.');
            return dot > 0 ? iso.substring(0, dot) : iso;
        }
    }

    private static String escape(String v) {
        return v == null ? "" : v.replace("\\", "\\\\").replace("\n", " ");
    }
}
