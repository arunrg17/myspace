package com.apitest.server.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Isolates each project's data under its own workspace.
 *
 * <p>The application is meant to be shared across a domain by several teams, and
 * one team's run history, workbooks, templates and baselines are of no use to
 * another. So every project gets its own fully separate workspace under
 * {@code <root>/projects/<projectId>/}, and a project's services only ever see
 * that folder. Switching project in the UI switches which project's services a
 * request is dispatched to; there is no path by which one project reads
 * another's files.
 *
 * <p>A small registry file at {@code <root>/config/projects.properties} records
 * the known projects (id -> display name). The services for a project are built
 * on first use and cached, so this stays cheap.
 */
public class ProjectManager {

    /** The bundle of services scoped to a single project's workspace. */
    public record Project(String id, String name, WorkspaceService workspace,
                          RunService runs, EngineService engine, SettingsService settings,
                          AiService ai) {}

    private final Path root;
    private final Path projectsDir;
    private final Path registryFile;
    private final Map<String, Project> cache = new ConcurrentHashMap<>();

    /** The id used when no project has been created yet, so the app works out of the box. */
    public static final String DEFAULT_ID = "default";

    public ProjectManager(Path root) throws IOException {
        this.root = root.toAbsolutePath().normalize();
        this.projectsDir = this.root.resolve("projects");
        Files.createDirectories(projectsDir);
        Files.createDirectories(this.root.resolve("config"));
        this.registryFile = this.root.resolve("config").resolve("projects.properties");
        // Ensure a default project always exists, so a fresh install is usable
        // immediately and older single-workspace deployments keep working.
        if (list().isEmpty()) {
            create(DEFAULT_ID, "Default project");
        }
    }

    /** All known projects, id and display name, sorted by name. */
    public synchronized List<Map<String, String>> list() {
        Properties reg = loadRegistry();
        List<Map<String, String>> out = new ArrayList<>();
        for (String id : reg.stringPropertyNames()) {
            out.add(Map.of("id", id, "name", reg.getProperty(id)));
        }
        out.sort((a, b) -> a.get("name").compareToIgnoreCase(b.get("name")));
        return out;
    }

    /** Whether a project id is registered. */
    public synchronized boolean exists(String id) {
        return loadRegistry().containsKey(normalizeId(id));
    }

    /**
     * Create a new project with its own empty workspace. The id is derived from
     * the name (lowercased, spaces to hyphens) unless one is given.
     */
    public synchronized Map<String, String> create(String idOrNull, String name)
            throws IOException {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("A project needs a name");
        }
        String id = normalizeId(idOrNull == null || idOrNull.isBlank() ? name : idOrNull);
        if (id.isBlank()) throw new IllegalArgumentException("Invalid project id");
        Properties reg = loadRegistry();
        if (reg.containsKey(id)) {
            throw new IllegalArgumentException("A project with id '" + id + "' already exists");
        }
        // Build its workspace (creates the area folders) and register it.
        projectServices(id);
        reg.setProperty(id, name.trim());
        saveRegistry(reg);
        return Map.of("id", id, "name", name.trim());
    }

    /**
     * The services for a project. Falls back to the default project when the id
     * is unknown or blank, so a missing/stale selection never errors - it just
     * lands on the default.
     */
    public Project get(String id) {
        String wanted = (id == null || id.isBlank()) ? DEFAULT_ID : normalizeId(id);
        if (!exists(wanted)) wanted = DEFAULT_ID;
        return projectServices(wanted);
    }

    private Project projectServices(String id) {
        return cache.computeIfAbsent(id, pid -> {
            try {
                Path ws = projectsDir.resolve(pid);
                WorkspaceService workspace = new WorkspaceService(ws);
                SettingsService settings = new SettingsService(workspace);
                RunService runs = new RunService(workspace, settings);
                EngineService engine = new EngineService(workspace);
                AiService ai = new AiService(settings);
                String name = loadRegistry().getProperty(pid, pid);
                return new Project(pid, name, workspace, runs, engine, settings, ai);
            } catch (IOException e) {
                throw new IllegalStateException("Could not open project '" + pid + "': "
                        + e.getMessage(), e);
            }
        });
    }

    // registry file

    private Properties loadRegistry() {
        Properties p = new Properties();
        if (Files.isRegularFile(registryFile)) {
            try (var in = Files.newInputStream(registryFile)) {
                p.load(in);
            } catch (IOException ignored) { }
        }
        return p;
    }

    private void saveRegistry(Properties p) throws IOException {
        try (var out = Files.newOutputStream(registryFile)) {
            p.store(out, "API test suite - project registry (id=display name)");
        }
    }

    /** A safe, stable id: lowercase, alnum and hyphens only. */
    private static String normalizeId(String raw) {
        String s = raw.trim().toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "-")
                .replaceAll("(^-+)|(-+$)", "");
        return s.length() > 60 ? s.substring(0, 60) : s;
    }
}
