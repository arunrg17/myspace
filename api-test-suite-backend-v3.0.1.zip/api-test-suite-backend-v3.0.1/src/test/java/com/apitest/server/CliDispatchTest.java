package com.apitest.server;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * One jar serves both the command line tool and the web service, so the choice
 * between them has to be unambiguous. Only the engine's own flags select the
 * command line; Spring's arguments must fall through to the web application.
 */
class CliDispatchTest {

    @Test
    void engineFlagsSelectTheCommandLine() {
        assertTrue(ApiTestApplication.isCommandLineRun(new String[]{"--suite", "tests.xlsx"}));
        assertTrue(ApiTestApplication.isCommandLineRun(new String[]{"--help"}));
        assertTrue(ApiTestApplication.isCommandLineRun(new String[]{"-h"}));
        assertTrue(ApiTestApplication.isCommandLineRun(new String[]{"--version"}));
        assertTrue(ApiTestApplication.isCommandLineRun(new String[]{"-v"}));
    }

    @Test
    void springArgumentsStartTheWebApplication() {
        assertFalse(ApiTestApplication.isCommandLineRun(new String[]{}));
        assertFalse(ApiTestApplication.isCommandLineRun(new String[]{"--server.port=9090"}));
        assertFalse(ApiTestApplication.isCommandLineRun(new String[]{"--apitest.workspace=/data"}));
        assertFalse(ApiTestApplication.isCommandLineRun(new String[]{"--spring.profiles.active=prod"}));
    }

    @Test
    void anEngineFlagAnywhereInTheArgumentsSelectsTheCommandLine() {
        assertTrue(ApiTestApplication.isCommandLineRun(
                new String[]{"--server.port=9090", "--suite", "tests.xlsx"}));
    }

    @Test
    void noArgumentsAndNullAreBothTheWebApplication() {
        assertFalse(ApiTestApplication.isCommandLineRun(null));
        assertFalse(ApiTestApplication.isCommandLineRun(new String[0]));
    }
}
