package com.apitest.server.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

/**
 * The concurrency limit that queues runs once the ceiling is reached. These
 * cover the reading of the setting and the queue-position reporting; the actual
 * blocking is exercised end to end by the run flow, but the numbers a queued
 * run reports back to the screen are what matter here.
 */
class ConcurrencyLimitTest {

    private RunService runs(Path root, Integer limit) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        SettingsService settings = new SettingsService(ws);
        if (limit != null) {
            settings.save(Map.of("max.concurrent.runs", String.valueOf(limit)));
        }
        return new RunService(ws, settings);
    }

    @Test
    void defaultLimitAppliesWhenUnset(@TempDir Path root) throws Exception {
        RunService rs = runs(root, null);
        assertEquals(4, rs.maxConcurrentRuns());
    }

    @Test
    void limitReflectsTheSetting(@TempDir Path root) throws Exception {
        RunService rs = runs(root, 2);
        assertEquals(2, rs.maxConcurrentRuns());
    }

    @Test
    void unknownRunIsNeitherQueuedNorAhead(@TempDir Path root) throws Exception {
        RunService rs = runs(root, 3);
        assertFalse(rs.isQueued("no-such-run"));
        assertEquals(0, rs.queuePosition("no-such-run"));
    }

    @Test
    void nothingExecutesBeforeAnyRunStarts(@TempDir Path root) throws Exception {
        RunService rs = runs(root, 3);
        assertEquals(0, rs.executingCount());
    }
}
