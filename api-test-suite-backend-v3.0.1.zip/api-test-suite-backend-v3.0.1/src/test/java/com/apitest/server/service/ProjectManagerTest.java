package com.apitest.server.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/** Each project's workspace is fully isolated from every other. */
class ProjectManagerTest {

    @Test
    void aDefaultProjectAlwaysExists(@TempDir Path root) throws Exception {
        ProjectManager pm = new ProjectManager(root);
        assertTrue(pm.exists("default"));
        assertEquals(1, pm.list().size());
    }

    @Test
    void projectsHaveSeparateWorkspaces(@TempDir Path root) throws Exception {
        ProjectManager pm = new ProjectManager(root);
        pm.create(null, "Payments Team");
        pm.create(null, "Cards Team");

        var pay = pm.get("payments-team");
        var cards = pm.get("cards-team");
        assertNotEquals(pay.workspace().root(), cards.workspace().root());

        // A workbook in one project is invisible to the other.
        Files.writeString(pay.workspace().area("workbooks").resolve("s.xlsx"), "x");
        try (var a = Files.list(pay.workspace().area("workbooks"));
             var b = Files.list(cards.workspace().area("workbooks"))) {
            assertEquals(1, a.count());
            assertEquals(0, b.count());
        }
    }

    @Test
    void unknownProjectFallsBackToDefault(@TempDir Path root) throws Exception {
        ProjectManager pm = new ProjectManager(root);
        assertEquals("default", pm.get("no-such-project").id());
        assertEquals("default", pm.get(null).id());
        assertEquals("default", pm.get("").id());
    }

    @Test
    void duplicateProjectIsRejected(@TempDir Path root) throws Exception {
        ProjectManager pm = new ProjectManager(root);
        pm.create(null, "Team A");
        assertThrows(IllegalArgumentException.class, () -> pm.create(null, "Team A"));
    }
}
