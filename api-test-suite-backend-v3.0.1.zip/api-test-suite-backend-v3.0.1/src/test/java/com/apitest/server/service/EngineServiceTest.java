package com.apitest.server.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/** Workbook validation, which needs no Excel or network. */
class EngineServiceTest {

    @Test
    void validateReportsMissingWorkbook(@TempDir Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        EngineService engine = new EngineService(ws);
        // A workbook that isn't there surfaces as ok=false, not an exception.
        assertThrows(Exception.class, () -> engine.validate("nope.xlsx"));
    }
}
