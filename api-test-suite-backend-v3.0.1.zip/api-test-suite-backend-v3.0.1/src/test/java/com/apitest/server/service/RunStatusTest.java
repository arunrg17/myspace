package com.apitest.server.service;

import com.apitest.model.TestResult;
import com.apitest.reporter.JsonReport;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * How a run's history status is derived from what's on disk. Covers the cases
 * that used to be wrong: a run with both failures and errors was labelled
 * "error" (hiding the failures), and a run whose browser closed mid-flight
 * could stay "running" forever.
 */
class RunStatusTest {

    private RunService runs(Path root) throws Exception {
        WorkspaceService ws = new WorkspaceService(root);
        return new RunService(ws, new SettingsService(ws));
    }

    private WorkspaceService ws(Path root) throws Exception {
        return new WorkspaceService(root);
    }

    private TestResult r(String id, String status) {
        TestResult t = new TestResult();
        t.testId = id; t.name = id; t.status = status;
        return t;
    }

    private void writeRun(WorkspaceService ws, String id, boolean finished,
                          List<TestResult> results) throws Exception {
        Path d = ws.area("runs").resolve(id);
        Files.createDirectories(d);
        String meta = "name=Run\nworkbook=w.xlsx\nstartedAt=2026-08-12T10:00:00Z\n"
                + (finished ? "finished=0\n" : "");
        Files.writeString(d.resolve("meta.properties"), meta);
        if (results != null) {
            Files.writeString(d.resolve("report.json"), JsonReport.toJson(results, "S"));
        }
    }

    private String statusOf(RunService svc, String id) throws Exception {
        return svc.history().stream()
                .filter(rec -> rec.runId().equals(id))
                .findFirst().orElseThrow().status();
    }

    @Test
    void failuresMixedWithErrorsReadAsFail(@TempDir Path root) throws Exception {
        WorkspaceService ws = ws(root);
        writeRun(ws, "mixed", true, List.of(r("T1", "PASS"), r("T2", "FAIL"), r("T3", "ERROR")));
        // A run with real failures is a "fail", even when some tests also errored.
        assertEquals("fail", statusOf(runs(root), "mixed"));
    }

    @Test
    void onlyErrorsReadsAsError(@TempDir Path root) throws Exception {
        WorkspaceService ws = ws(root);
        writeRun(ws, "allerr", true, List.of(r("T1", "ERROR"), r("T2", "ERROR")));
        assertEquals("error", statusOf(runs(root), "allerr"));
    }

    @Test
    void finishedWithoutResultsIsErrorNotRunning(@TempDir Path root) throws Exception {
        WorkspaceService ws = ws(root);
        // Browser closed / thread ended, no report written: the finished marker
        // means this is a failed run, not one still in progress.
        writeRun(ws, "stuck", true, null);
        assertEquals("error", statusOf(runs(root), "stuck"));
    }

    @Test
    void allPassReadsAsPass(@TempDir Path root) throws Exception {
        WorkspaceService ws = ws(root);
        writeRun(ws, "green", true, List.of(r("T1", "PASS"), r("T2", "PASS")));
        assertEquals("pass", statusOf(runs(root), "green"));
    }
}
