package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class DeepScanIgnoreTest {

    private static final String WITH_FLAG =
            "{\"masterPartner\":{\"customer\":["
          + "{\"id\":1,\"accounts\":{\"cashaccount\":[{\"no\":\"A1\",\"deletedflag\":false},{\"no\":\"A2\",\"deletedflag\":false}]}},"
          + "{\"id\":2,\"accounts\":{\"cashaccount\":[{\"no\":\"B1\",\"deletedflag\":false},{\"no\":\"B2\",\"deletedflag\":true}]}}]}}";

    private static final String WITHOUT_FLAG = WITH_FLAG
            .replace(",\"deletedflag\":false", "")
            .replace(",\"deletedflag\":true", "");

    private static final List<Assertion> IGNORE_FLAG =
            List.of(new Assertion("$..deletedflag", "jsonpath", "ignore", "", "deep scan"));

    @Test
    void deepScanIgnoreWhenValuesDiffer() {
        CompareResult r = Comparator.compare(WITH_FLAG, WITH_FLAG.replace("true", "false"), IGNORE_FLAG);
        assertTrue(r.matched, () -> "diffs: " + r.diffs.size());
    }

    @Test
    void deepScanIgnoreWhenFieldOnlyOnSourceA() {
        CompareResult r = Comparator.compare(WITH_FLAG, WITHOUT_FLAG, IGNORE_FLAG);
        assertTrue(r.matched, () -> "diffs: " + r.diffs.size());
    }

    @Test
    void deepScanIgnoreWhenFieldOnlyOnSourceB() {
        CompareResult r = Comparator.compare(WITHOUT_FLAG, WITH_FLAG, IGNORE_FLAG);
        assertTrue(r.matched, () -> "diffs: " + r.diffs.size());
    }

    @Test
    void wildcardPathIgnoreWhenFieldOnlyOnOneSide() {
        List<Assertion> ignore = List.of(new Assertion(
                "$.masterPartner.customer[*].accounts.cashaccount[*].deletedflag", "jsonpath", "ignore", "", ""));
        CompareResult r = Comparator.compare(WITH_FLAG, WITHOUT_FLAG, ignore);
        assertTrue(r.matched, () -> "diffs: " + r.diffs.size());
    }

    @Test
    void realChangeNextToIgnoredFieldIsStillReported() {
        CompareResult r = Comparator.compare(WITH_FLAG, WITHOUT_FLAG.replace("\"B2\"", "\"B9\""), IGNORE_FLAG);
        assertFalse(r.matched);
        assertEquals(1, r.diffs.size());
        assertTrue(r.diffs.get(0).path.endsWith(".no"));
    }

    @Test
    void withoutIgnoreMissingFlagIsStillReported() {
        CompareResult r = Comparator.compare(WITH_FLAG, WITHOUT_FLAG, List.of());
        assertFalse(r.matched);
    }
}
