package com.apitest.dispatcher;

import java.util.Map;

public class Response {
    public int status;
    public Map<String, String> headers;
    public String body = "";
    public long elapsedMs;
    public String url = "";
    public String error;

    public Response() {}
}
