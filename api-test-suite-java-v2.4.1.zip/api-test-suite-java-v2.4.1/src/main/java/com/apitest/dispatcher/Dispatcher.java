package com.apitest.dispatcher;

import org.apache.http.HttpHeaders;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.*;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Multi-protocol HTTP dispatcher.
 *
 * <p>Handles auth header injection, content-type defaults, and response capture
 * for REST, SOAP, Apigee, Fabric (Microsoft), and GCP endpoints.
 *
 * <p>Supported protocols (set in the Environments sheet's Protocol column):
 * <ul>
 *   <li>{@code rest}    — generic REST; Content-Type defaults to application/json
 *   <li>{@code soap}    — SOAP; forces POST, defaults Content-Type to text/xml
 *   <li>{@code apigee}  — Apigee proxy; Content-Type defaults to application/json
 *   <li>{@code fabric}  — Microsoft Fabric; same as REST
 *   <li>{@code gcp}     — Google Cloud; same as REST
 * </ul>
 *
 * <p>For form-urlencoded auth requests, set Content-Type in ExtraHeaders:
 * {@code Content-Type: application/x-www-form-urlencoded} and write the body
 * template as {@code grant_type=client_credentials&client_id=${id}&client_secret=${secret}}.
 */
public class Dispatcher {

    private static final int DEFAULT_TIMEOUT_MS = 30_000;

    public static Response send(String protocol, String baseUrl, String endpoint,
                                String method, String body, Map<String, String> headers,
                                String authType, String authValue) {
        return send(protocol, baseUrl, endpoint, method, body, headers, authType, authValue, null);
    }

    public static Response send(String protocol, String baseUrl, String endpoint,
                                String method, String body, Map<String, String> headers,
                                String authType, String authValue, String sslConfig) {

        String url = composeUrl(baseUrl, endpoint);
        Map<String, String> finalHeaders = new LinkedHashMap<>(headers == null ? Map.of() : headers);
        finalHeaders.putAll(resolveAuth(authType, authValue));

        // Protocol-specific defaults
        String proto = protocol == null ? "" : protocol.toLowerCase(Locale.ROOT);
        switch (proto) {
            case "soap" -> {
                finalHeaders.putIfAbsent("Content-Type", "text/xml; charset=utf-8");
                finalHeaders.putIfAbsent("SOAPAction", "\"\"");
                method = "POST";
            }
            case "apigee" -> {
                // Apigee proxies use REST over HTTPS with an API key.
                // The user can provide the key in AuthValue; we inject it
                // as the standard Apigee header if not already set.
                finalHeaders.putIfAbsent("Content-Type", "application/json");
            }
            default -> {
                // REST / GCP / Fabric / anything else
                if (body != null && !body.isEmpty()) {
                    finalHeaders.putIfAbsent("Content-Type", "application/json");
                }
            }
        }

        long started = System.currentTimeMillis();
        Response resp = new Response();
        resp.url = url;

        RequestConfig config = RequestConfig.custom()
                .setConnectTimeout(DEFAULT_TIMEOUT_MS)
                .setSocketTimeout(DEFAULT_TIMEOUT_MS)
                .build();

        try (CloseableHttpClient client = buildClient(config, sslConfig)) {
            HttpRequestBase request = buildRequest(method, url);

            for (Map.Entry<String, String> e : finalHeaders.entrySet()) {
                request.addHeader(e.getKey(), e.getValue());
            }

            if (body != null && !body.isEmpty() && request instanceof HttpEntityEnclosingRequestBase entReq) {
                String ct = finalHeaders.getOrDefault("Content-Type", "application/json");
                entReq.setEntity(new ByteArrayEntity(body.getBytes(StandardCharsets.UTF_8),
                                                   ContentType.parse(ct)));
            }

            var response = client.execute(request);
            try {
                resp.status = response.getStatusLine().getStatusCode();
                resp.headers = new HashMap<>();
                for (var h : response.getAllHeaders()) {
                    resp.headers.put(h.getName(), h.getValue());
                }
                resp.body = response.getEntity() == null ? ""
                        : EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
            } finally {
                response.close();
            }
        } catch (Exception ex) {
            resp.error = ex.getClass().getSimpleName() + ": " + ex.getMessage();
        }

        resp.elapsedMs = System.currentTimeMillis() - started;
        return resp;
    }

    // ------------------------------------------------------------------

    /**
     * Builds an HttpClient with SSL configured per the env's SslConfig.
     * If sslConfig is null/empty, uses the JVM default trust store.
     */
    private static CloseableHttpClient buildClient(RequestConfig config, String sslConfig) {
        var builder = HttpClients.custom().setDefaultRequestConfig(config);

        if (sslConfig != null && !sslConfig.isBlank()) {
            SSLContext ctx = SslConfig.buildContext(sslConfig);
            if (ctx != null) {
                // When verify=false, also skip hostname verification — otherwise
                // a CN/SAN mismatch will still fail even with TrustAllManager.
                var hostnameVerifier = SslConfig.isVerifyDisabled(sslConfig)
                        ? NoopHostnameVerifier.INSTANCE
                        : SSLConnectionSocketFactory.getDefaultHostnameVerifier();
                var sslFactory = new SSLConnectionSocketFactory(ctx, hostnameVerifier);
                builder.setSSLSocketFactory(sslFactory);

                Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                        .register("http", PlainConnectionSocketFactory.getSocketFactory())
                        .register("https", sslFactory)
                        .build();
                builder.setConnectionManager(new BasicHttpClientConnectionManager(registry));
            }
        }

        return builder.build();
    }

    private static String composeUrl(String baseUrl, String endpoint) {
        if (baseUrl == null) baseUrl = "";
        if (endpoint == null || endpoint.isEmpty()) return baseUrl;

        // If the endpoint is already a full URL (e.g. a token endpoint on a
        // different host), use it as-is — don't prepend the env's BaseURL.
        if (endpoint.startsWith("http://") || endpoint.startsWith("https://")) {
            return endpoint;
        }

        String b = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        String e = endpoint.startsWith("/") ? endpoint : "/" + endpoint;
        return b + e;
    }

    private static HttpRequestBase buildRequest(String method, String url) {
        return switch (method.toUpperCase()) {
            case "GET" -> new HttpGet(url);
            case "POST" -> new HttpPost(url);
            case "PUT" -> new HttpPut(url);
            case "DELETE" -> new HttpDelete(url);
            case "PATCH" -> new HttpPatch(url);
            case "HEAD" -> new HttpHead(url);
            case "OPTIONS" -> new HttpOptions(url);
            default -> throw new IllegalArgumentException("Unsupported method: " + method);
        };
    }

    private static Map<String, String> resolveAuth(String authType, String authValue) {
        Map<String, String> out = new HashMap<>();
        if (authType == null || authType.isEmpty() || "none".equalsIgnoreCase(authType)) return out;

        // Resolve the value — supports ${env.VAR}, ${file.path:key}, or literal
        String value = SslConfig.resolveSecret(authValue == null ? "" : authValue);

        switch (authType.toLowerCase(Locale.ROOT)) {
            case "basic" -> {
                if (value.contains(":")) {
                    String enc = Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
                    out.put(HttpHeaders.AUTHORIZATION, "Basic " + enc);
                }
            }
            case "bearer"         -> out.put(HttpHeaders.AUTHORIZATION, "Bearer " + value);
            case "apikey"         -> out.put("x-api-key", value);
            case "oauth2"         -> out.put(HttpHeaders.AUTHORIZATION, "Bearer " + value);
            case "service_account"-> out.put(HttpHeaders.AUTHORIZATION, "Bearer " + value);
        }
        return out;
    }
}
