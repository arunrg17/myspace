package com.apitest.reporter;

import com.apitest.model.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Generates a self-contained, professional HTML report.
 */
public class Reporter {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void renderReport(List<TestResult> results, Path outPath, String suiteName) throws IOException {
        int total = results.size();
        int passed = (int) results.stream().filter(r -> "PASS".equals(r.status)).count();
        int failed = (int) results.stream().filter(r -> "FAIL".equals(r.status)).count();
        int errored = (int) results.stream().filter(r -> "ERROR".equals(r.status)).count();
        long totalMs = results.stream().mapToLong(r -> r.durationMs).sum();
        long avgMs = total == 0 ? 0 : totalMs / total;
        int passRate = total == 0 ? 0 : (passed * 100 / total);

        Map<String, Integer> modes = new LinkedHashMap<>();
        for (TestResult r : results) {
            modes.merge(r.comparisonMode == null ? "" : r.comparisonMode, 1, Integer::sum);
        }

        Set<String> envs = new TreeSet<>();
        for (TestResult r : results) {
            if (r.sourceA != null && !r.sourceA.isEmpty()) envs.add(r.sourceA);
            if (r.sourceB != null && !r.sourceB.isEmpty()) envs.add(r.sourceB);
        }

        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n");
        html.append("<meta charset=\"utf-8\">\n");
        html.append("<title>").append(esc(suiteName)).append(" — Test Report</title>\n");
        html.append("<style>").append(CSS).append("</style>\n</head>\n<body>\n");

        // Header
        html.append("<header><div><h1>").append(esc(suiteName)).append("</h1>");
        html.append("<div class=\"meta\">Generated ").append(LocalDateTime.now().format(FMT));
        html.append(" · v").append(com.apitest.Version.VERSION);
        html.append(" · ").append(total).append(" test").append(total != 1 ? "s" : "");
        html.append(" · ").append(totalMs).append(" ms total</div></div>");
        html.append("<div class=\"right\">");
        for (String e : envs) html.append("<span class=\"badge-env\">").append(esc(e)).append("</span>");
        html.append("</div></header>\n");

        // Dashboard
        html.append("<div class=\"dashboard\">");
        html.append("<div class=\"dash-card\"><h3>Overall result</h3>").append(donut(passed, failed, errored)).append("</div>");
        html.append("<div class=\"dash-card\"><h3>Run statistics</h3><div class=\"kpi-grid\">");
        html.append(kpi(total, "Tests", ""));
        html.append(kpi(passed, "Passed", "pass"));
        html.append(kpi(failed, "Failed", "fail"));
        html.append(kpi(errored, "Errored", "err"));
        html.append(kpi(passRate + "%", "Pass rate", ""));
        html.append(kpi(avgMs, "Avg ms", ""));
        html.append(kpi(totalMs, "Total ms", ""));
        html.append(kpi(envs.size(), "Envs", ""));
        html.append("</div></div>");
        html.append("<div class=\"dash-card\"><h3>By comparison mode</h3><div class=\"mode-breakdown\">");
        int maxMode = modes.values().stream().max(Integer::compare).orElse(1);
        modes.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .forEach(e -> {
                    int pct = (e.getValue() * 100) / maxMode;
                    html.append("<div class=\"mb-row\"><span class=\"mb-label\">").append(esc(e.getKey()))
                        .append("</span><span class=\"mb-bar-track\"><span class=\"mb-bar\" style=\"width:")
                        .append(pct).append("%\"></span></span><span class=\"mb-count\">")
                        .append(e.getValue()).append("</span></div>");
                });
        html.append("</div></div></div>\n");

        // Toolbar
        html.append("<div class=\"toolbar\">");
        html.append("<div class=\"search-box\"><svg viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"><circle cx=\"7\" cy=\"7\" r=\"5\"/><line x1=\"11\" y1=\"11\" x2=\"14\" y2=\"14\" stroke-linecap=\"round\"/></svg>");
        html.append("<input id=\"search-input\" type=\"text\" placeholder=\"Search tests by id or name… (press / to focus)\" oninput=\"search(this.value)\"></div>");
        html.append("<div class=\"filter-group\"><span class=\"label\">Status</span>");
        html.append("<button class=\"filter-btn active\" data-filter-status onclick=\"setFilterStatus('ALL', this)\">All</button>");
        html.append("<button class=\"filter-btn\" data-filter-status onclick=\"setFilterStatus('PASS', this)\">Pass</button>");
        html.append("<button class=\"filter-btn\" data-filter-status onclick=\"setFilterStatus('FAIL', this)\">Fail</button>");
        html.append("<button class=\"filter-btn\" data-filter-status onclick=\"setFilterStatus('ERROR', this)\">Error</button></div>");
        html.append("<div class=\"filter-group\"><span class=\"label\">Mode</span>");
        html.append("<button class=\"filter-btn active\" data-filter-mode onclick=\"setFilterMode('ALL', this)\">All</button>");
        for (String m : new TreeSet<>(modes.keySet())) {
            html.append("<button class=\"filter-btn\" data-filter-mode onclick=\"setFilterMode('")
                .append(esc(m)).append("', this)\">").append(esc(m)).append("</button>");
        }
        html.append("</div>");
        html.append("<select class=\"sort-select\" onchange=\"sortTests(this.value)\">");
        html.append("<option value=\"order\">Original order</option>");
        html.append("<option value=\"status\">Failures first</option>");
        html.append("<option value=\"duration_desc\">Slowest first</option>");
        html.append("<option value=\"duration_asc\">Fastest first</option>");
        html.append("<option value=\"name\">Name (A→Z)</option>");
        html.append("</select></div>\n");

        // Layout
        html.append("<div class=\"app\"><aside class=\"sidebar\">");
        for (TestResult r : results) html.append(sidebarItem(r));
        html.append("</aside><main class=\"main\">");

        if (results.isEmpty()) {
            html.append("<div class=\"empty\">No test results.</div>");
        } else {
            for (int i = 0; i < results.size(); i++) html.append(testSection(results.get(i), i));
        }

        html.append("</main></div>\n");
        html.append("<script>").append(JS).append("</script>\n</body></html>\n");

        Files.writeString(outPath, html.toString());
    }

    // ------------------------------------------------------------------
    // Components
    // ------------------------------------------------------------------

    private static String kpi(Object n, String label, String cls) {
        return "<div class=\"kpi " + cls + "\"><div class=\"n\">" + n + "</div><div class=\"l\">" + label + "</div></div>";
    }

    private static String donut(int p, int f, int e) {
        int t = p + f + e;
        if (t == 0) return "";
        double R = 56;
        double C = 2 * Math.PI * R;
        double pLen = C * p / t;
        double fLen = C * f / t;
        double eLen = C * e / t;
        return String.format(Locale.US, """
                <div class="donut-wrap">
                  <svg viewBox="0 0 160 160" class="donut">
                    <circle cx="80" cy="80" r="%f" fill="none" stroke="#eef0f3" stroke-width="16"/>
                    <circle cx="80" cy="80" r="%f" fill="none" stroke="#1d9e75" stroke-width="16" stroke-dasharray="%f %f" stroke-dashoffset="0" transform="rotate(-90 80 80)"/>
                    <circle cx="80" cy="80" r="%f" fill="none" stroke="#d14545" stroke-width="16" stroke-dasharray="%f %f" stroke-dashoffset="%f" transform="rotate(-90 80 80)"/>
                    <circle cx="80" cy="80" r="%f" fill="none" stroke="#bf6a0b" stroke-width="16" stroke-dasharray="%f %f" stroke-dashoffset="%f" transform="rotate(-90 80 80)"/>
                    <text x="80" y="76" text-anchor="middle" class="donut-num">%d%%</text>
                    <text x="80" y="94" text-anchor="middle" class="donut-lbl">pass rate</text>
                  </svg>
                  <div class="donut-legend">
                    <div class="lg-row"><span class="lg-sw" style="background:#1d9e75"></span>Passed <strong>%d</strong></div>
                    <div class="lg-row"><span class="lg-sw" style="background:#d14545"></span>Failed <strong>%d</strong></div>
                    <div class="lg-row"><span class="lg-sw" style="background:#bf6a0b"></span>Errored <strong>%d</strong></div>
                  </div>
                </div>
                """, R, R, pLen, C, R, fLen, C, -pLen, R, eLen, C, -(pLen + fLen),
                p * 100 / t, p, f, e);
    }

    private static String sidebarItem(TestResult r) {
        String cls = statusClass(r.status);
        return "<a class=\"nav-item\" href=\"#test-" + esc(r.testId) + "\" data-status=\"" + r.status
                + "\" data-mode=\"" + esc(r.comparisonMode) + "\" data-name=\"" + esc(r.name).toLowerCase(Locale.ROOT)
                + "\"><span class=\"nav-dot " + cls + "\"></span><span class=\"nav-content\">"
                + "<span class=\"nav-id\">" + esc(r.testId) + "</span>"
                + "<span class=\"nav-title\">" + esc(r.name) + "</span>"
                + "<span class=\"nav-meta\">" + esc(r.comparisonMode) + " · " + r.durationMs + "ms</span>"
                + "</span></a>";
    }

    private static String testSection(TestResult r, int idx) {
        String cls = statusClass(r.status);
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"test-section\" id=\"test-").append(esc(r.testId))
          .append("\" data-status=\"").append(r.status)
          .append("\" data-mode=\"").append(esc(r.comparisonMode))
          .append("\" data-name=\"").append(esc(r.name).toLowerCase(Locale.ROOT)).append("\">");

        // Header
        sb.append("<div class=\"test-header\"><div class=\"test-header-left\">");
        sb.append("<span class=\"test-id\">").append(esc(r.testId)).append("</span>");
        sb.append("<h2 class=\"test-name\">").append(esc(r.name)).append("</h2>");
        sb.append("<p class=\"test-desc\">").append(esc(r.description)).append("</p>");
        sb.append("</div><div class=\"test-header-right\">");
        sb.append("<span class=\"status-pill ").append(cls).append("\">").append(r.status).append("</span>");
        sb.append("<span class=\"muted\">").append(r.durationMs).append(" ms</span></div></div>");

        if (r.error != null && !r.error.isEmpty()) {
            sb.append("<div class=\"test-error-banner\">⚠ ").append(esc(r.error)).append("</div>");
        }

        // Tabs
        boolean hasCompare = r.compareResult != null;
        boolean hasAssertions = r.assertionResults != null && !r.assertionResults.isEmpty();
        int diffCount = hasCompare ? r.compareResult.diffs.size() : 0;
        int assertCount = hasAssertions ? r.assertionResults.size() : 0;

        sb.append("<div class=\"tabs\">");
        sb.append("<button class=\"tab-btn active\" onclick=\"setTab(this, 'overview')\">Overview</button>");
        sb.append("<button class=\"tab-btn\" onclick=\"setTab(this, 'steps')\">Steps <span class=\"tab-count\">")
          .append(r.stepsA.size() + r.stepsB.size()).append("</span></button>");
        if (hasCompare) {
            sb.append("<button class=\"tab-btn\" onclick=\"setTab(this, 'compare')\">Comparison");
            if (diffCount > 0) sb.append(" <span class=\"tab-count\">").append(diffCount).append("</span>");
            sb.append("</button>");
        }
        if (hasAssertions) {
            sb.append("<button class=\"tab-btn\" onclick=\"setTab(this, 'asserts')\">Assertions");
            sb.append(" <span class=\"tab-count\">").append(assertCount).append("</span>");
            sb.append("</button>");
        }
        sb.append("</div>");

        // Overview tab
        sb.append("<div class=\"tab-pane active\" data-tab=\"overview\">");
        sb.append(overviewGrid(r));
        if (hasCompare) {
            sb.append("<div class=\"overview-cmp\"><span class=\"ov-label\">Comparison</span><span>")
              .append(esc(r.compareResult.getSummary())).append("<span class=\"muted\"> · ")
              .append(esc(r.compareResult.note)).append("</span></span></div>");
        }
        if (hasAssertions) {
            int aPassed = (int) r.assertionResults.stream().filter(a -> a.passed).count();
            int aFailed = assertCount - aPassed;
            sb.append("<div class=\"overview-cmp\"><span class=\"ov-label\">Assertions</span><span>")
              .append(aPassed).append(" passed · ").append(aFailed).append(" failed</span></div>");
        }
        sb.append("</div>");

        // Steps tab
        sb.append("<div class=\"tab-pane\" data-tab=\"steps\">");
        sb.append("<div class=\"source-section\"><div class=\"source-section-head\">");
        sb.append("<span class=\"source-letter source-a\">A</span><span class=\"source-name\">")
          .append(esc(r.sourceA)).append("</span></div>");
        for (int i = 0; i < r.stepsA.size(); i++) sb.append(stepCard(r.stepsA.get(i), idx + "a" + i, "A"));
        sb.append("</div>");
        if (!r.stepsB.isEmpty()) {
            sb.append("<div class=\"source-section\"><div class=\"source-section-head\">");
            sb.append("<span class=\"source-letter source-b\">B</span><span class=\"source-name\">")
              .append(esc(r.sourceB)).append("</span></div>");
            for (int i = 0; i < r.stepsB.size(); i++) sb.append(stepCard(r.stepsB.get(i), idx + "b" + i, "B"));
            sb.append("</div>");
        }
        sb.append("</div>");

        // Comparison tab
        if (hasCompare) {
            sb.append("<div class=\"tab-pane\" data-tab=\"compare\">");
            String labelA = r.sourceB != null && !r.sourceB.isEmpty() ? "Source A — " + r.sourceA : "Expected";
            String labelB = r.sourceB != null && !r.sourceB.isEmpty() ? "Source B — " + r.sourceB : "Actual";
            String badge = r.compareResult.matched ? "badge-ok" : "badge-bad";
            sb.append("<div class=\"compare-summary\"><span class=\"badge ").append(badge).append("\">")
              .append(esc(r.compareResult.getSummary())).append("</span>");
            sb.append("<span class=\"muted\">").append(esc(r.compareResult.note)).append("</span></div>");

            // Show the prepared payloads (post-CDATA-unwrap, pretty-printed)
            // side-by-side so the user can see exactly what was compared.
            // Often the actual response is deeply wrapped (SOAP + CDATA + escaped
            // XML) and the user can't tell from the raw response.txt what the
            // comparator actually saw — this surfaces that.
            //
            // We do NOT truncate the payload here — the CSS makes the pane
            // scrollable so even very large responses are fully accessible.
            if (r.compareResult.preparedExpected != null || r.compareResult.preparedActual != null) {
                String pe = r.compareResult.preparedExpected == null ? "" : r.compareResult.preparedExpected;
                String pa = r.compareResult.preparedActual == null ? "" : r.compareResult.preparedActual;
                sb.append("<details class=\"compare-prepared\" open><summary>Compared payloads (after CDATA unwrap &amp; pretty-print)")
                  .append(" — <span class=\"muted\">expected ").append(pe.length()).append(" chars · actual ").append(pa.length()).append(" chars</span>")
                  .append("</summary>");
                sb.append("<div class=\"compare-grid\">");
                sb.append("<div class=\"compare-side\"><div class=\"compare-side-head\">").append(esc(labelA)).append("</div>");
                sb.append("<pre class=\"compare-payload\">").append(esc(pe)).append("</pre></div>");
                sb.append("<div class=\"compare-side\"><div class=\"compare-side-head\">").append(esc(labelB)).append("</div>");
                sb.append("<pre class=\"compare-payload\">").append(esc(pa)).append("</pre></div>");
                sb.append("</div></details>");
            }

            sb.append("<div class=\"diff-view-toggle\">");
            sb.append("<button class=\"vt-btn active\" onclick=\"setDiffView('").append(idx).append("', 'side', this)\">Side-by-side</button>");
            sb.append("<button class=\"vt-btn\" onclick=\"setDiffView('").append(idx).append("', 'table', this)\">Table</button>");
            sb.append("</div>");
            sb.append("<div id=\"diff-side-").append(idx).append("\">").append(diffSide(r.compareResult.diffs, labelA, labelB)).append("</div>");
            sb.append("<div id=\"diff-table-").append(idx).append("\" style=\"display:none\">").append(diffTable(r.compareResult.diffs, labelA, labelB)).append("</div>");
            sb.append("</div>");
        }

        // Assertions tab
        if (hasAssertions) {
            sb.append("<div class=\"tab-pane\" data-tab=\"asserts\">");
            sb.append(assertionTable(r.assertionResults));
            sb.append("</div>");
        }

        sb.append("</section>");
        return sb.toString();
    }

    private static String overviewGrid(TestResult r) {
        StringBuilder sb = new StringBuilder("<div class=\"overview-grid\">");
        sb.append(ovCell("Test ID", "<span class=\"mono\">" + esc(r.testId) + "</span>"));
        sb.append(ovCell("Mode", "<span class=\"mode-tag\">" + esc(r.comparisonMode) + "</span>"));
        sb.append(ovCell("Source A", sourceCellValue(r.sourceA, r.stepsA)));
        sb.append(ovCell("Source B", sourceCellValue(r.sourceB, r.stepsB)));
        sb.append(ovCell("Started", "<span class=\"mono\">" + esc(r.started) + "</span>"));
        sb.append(ovCell("Duration", r.durationMs + " ms"));
        sb.append(ovCell("Steps", String.valueOf(r.stepsA.size() + r.stepsB.size())));
        sb.append(ovCell("Result", "<span class=\"status-pill " + statusClass(r.status) + "\">" + r.status + "</span>"));
        return sb.append("</div>").toString();
    }

    /**
     * Render a Source A / Source B cell with an inline pass/fail indicator
     * so the user can immediately see in the Overview that (e.g.) source B
     * had a socket exception even though source A returned cleanly.
     */
    private static String sourceCellValue(String sourceName, List<StepResult> steps) {
        if (sourceName == null || sourceName.isEmpty()) return "—";
        if (steps == null || steps.isEmpty()) return esc(sourceName);
        boolean allPassed = steps.stream().allMatch(s -> s.passed);
        String pillClass = allPassed ? "src-ok" : "src-bad";
        String pillText  = allPassed ? "ok" : "failed";
        return esc(sourceName)
                + " <span class=\"src-pill " + pillClass + "\">" + pillText + "</span>";
    }

    private static String ovCell(String label, String value) {
        return "<div class=\"ov-cell\"><div class=\"ov-label\">" + label + "</div><div class=\"ov-val\">" + value + "</div></div>";
    }

    private static String stepCard(StepResult s, String idx, String sourceLabel) {
        String passClass = s.passed ? "step-pass" : "step-fail";
        String statusClass = s.passed ? "http-ok" : "http-bad";
        String expectedStr = String.join(",", s.expectedStatus.stream().map(String::valueOf).toList());

        StringBuilder sb = new StringBuilder();
        sb.append("<div class=\"step-card ").append(passClass).append("\">");
        sb.append("<div class=\"step-card-head\"><div class=\"step-card-title\">");
        sb.append("<span class=\"step-badge\">").append(sourceLabel).append(" · Step ").append(s.order).append("</span>");
        sb.append("<span class=\"step-name\">").append(esc(s.name)).append("</span></div>");
        sb.append("<div class=\"step-card-meta\"><span class=\"http-status ").append(statusClass).append("\">").append(s.status).append("</span>");
        sb.append("<span class=\"muted\">expects ").append(expectedStr).append("</span>");
        sb.append("<span class=\"muted\">·</span><span class=\"muted\">").append(s.elapsedMs).append(" ms</span></div></div>");

        sb.append("<div class=\"step-card-url\"><span class=\"method method-").append(s.method.toLowerCase(Locale.ROOT))
          .append("\">").append(esc(s.method)).append("</span><code>").append(esc(s.url)).append("</code></div>");

        if (s.error != null && !s.error.isEmpty()) {
            sb.append("<div class=\"step-err\"><div class=\"step-err-head\">⚠ Step error</div>");
            sb.append("<pre class=\"step-err-body\">").append(esc(s.error)).append("</pre></div>");
        }

        sb.append(codeBlock(s.requestBody, "Request body", "req-" + idx));
        sb.append(codeBlock(s.responseBody, "Response body", "resp-" + idx));

        if (!s.extracted.isEmpty()) {
            sb.append("<div class=\"extracted\"><div class=\"extracted-head\">Extracted variables</div>");
            for (Map.Entry<String, String> e : s.extracted.entrySet()) {
                sb.append("<div class=\"kv-row\"><span class=\"kv-k\">").append(esc(e.getKey()))
                  .append("</span><span class=\"kv-v\"><code>").append(esc(e.getValue())).append("</code></span></div>");
            }
            sb.append("</div>");
        }
        sb.append("</div>");
        return sb.toString();
    }

    private static String codeBlock(String payload, String label, String copyId) {
        if (payload == null || payload.isEmpty()) {
            return "<div class=\"code-empty\">" + esc(label) + ": (empty)</div>";
        }
        Pretty p = prettify(payload);
        int lines = (int) p.text.chars().filter(c -> c == '\n').count() + 1;
        String highlighted = highlight(p.text, p.format);

        return "<div class=\"code-block\"><div class=\"code-head\">"
                + "<span class=\"code-label\">" + esc(label) + "</span>"
                + "<span class=\"code-meta\">" + p.format.toUpperCase(Locale.ROOT) + " · " + lines
                + " line" + (lines != 1 ? "s" : "") + " · " + payload.length() + " bytes</span>"
                + "<button class=\"copy-btn\" onclick=\"copyCode('" + copyId + "', this)\">copy</button>"
                + "</div><pre id=\"" + copyId + "\" class=\"code-pre lang-" + p.format + "\">"
                + highlighted + "</pre></div>";
    }

    private static String diffSide(List<DiffEntry> diffs, String labelA, String labelB) {
        if (diffs == null || diffs.isEmpty()) return "<div class=\"diff-ok\">No structural differences detected.</div>";
        StringBuilder sb = new StringBuilder("<div class=\"diff-list\">");
        for (DiffEntry d : diffs) {
            String kind = d.kind == null ? "" : d.kind;
            String kindClass;
            switch (kind) {
                case "value":   kindClass = "k-val"; break;
                case "type":    kindClass = "k-typ"; break;
                case "added":   kindClass = "k-add"; break;
                case "removed": kindClass = "k-rem"; break;
                case "length":  kindClass = "k-len"; break;
                default:        kindClass = "k-val"; break;
            }
            sb.append("<div class=\"diff-row\"><div class=\"diff-meta\">");
            sb.append("<span class=\"diff-kind ").append(kindClass).append("\">").append(esc(kind)).append("</span>");
            sb.append("<code class=\"diff-path\">").append(esc(d.path == null ? "" : d.path)).append("</code></div>");
            sb.append("<div class=\"diff-pair\">");
            sb.append("<div class=\"diff-side diff-exp\"><div class=\"diff-side-head\">").append(esc(labelA)).append("</div>");
            sb.append(diffSideValue(d.expected, "added".equals(kind)));
            sb.append("</div>");
            sb.append("<div class=\"diff-side diff-act\"><div class=\"diff-side-head\">").append(esc(labelB)).append("</div>");
            sb.append(diffSideValue(d.actual, "removed".equals(kind)));
            sb.append("</div>");
            sb.append("</div></div>");
        }
        sb.append("</div>");
        return sb.toString();
    }

    /** Render a value inside a side-by-side diff card. Same semantics as renderDiffCell. */
    private static String diffSideValue(String value, boolean isMissing) {
        if (isMissing || value == null || "<missing>".equals(value)) {
            return "<div class=\"diff-missing\">(missing)</div>";
        }
        if (value.isEmpty()) {
            return "<div class=\"diff-missing\">(empty)</div>";
        }
        final int LIMIT = 500;
        String shown = value;
        boolean truncated = false;
        if (value.length() > LIMIT) {
            int cut = LIMIT;
            int nl = value.lastIndexOf('\n', LIMIT);
            if (nl > LIMIT / 2) cut = nl;
            shown = value.substring(0, cut);
            truncated = true;
        }
        return "<pre>" + esc(shown)
                + (truncated ? "<span class=\"diff-trunc\">…(" + (value.length() - shown.length()) + " more chars)</span>" : "")
                + "</pre>";
    }

    private static String diffTable(List<DiffEntry> diffs, String labelA, String labelB) {
        if (diffs == null || diffs.isEmpty()) {
            return "<div class=\"diff-ok\">No structural differences detected.</div>";
        }
        StringBuilder sb = new StringBuilder("<table class=\"diff-table\"><thead><tr>");
        sb.append("<th>Kind</th><th>Path</th>");
        sb.append("<th>").append(esc(labelA)).append("</th>");
        sb.append("<th>").append(esc(labelB)).append("</th></tr></thead><tbody>");
        for (DiffEntry d : diffs) {
            String kindClass;
            switch (d.kind == null ? "" : d.kind) {
                case "value":   kindClass = "k-val"; break;
                case "type":    kindClass = "k-typ"; break;
                case "added":   kindClass = "k-add"; break;
                case "removed": kindClass = "k-rem"; break;
                case "length":  kindClass = "k-len"; break;
                default:        kindClass = "k-val"; break;
            }
            sb.append("<tr><td><span class=\"diff-kind ").append(kindClass).append("\">")
              .append(esc(d.kind == null ? "?" : d.kind)).append("</span></td>");
            sb.append("<td><code class=\"diff-path\">").append(esc(d.path == null ? "" : d.path)).append("</code></td>");

            // Show added/removed as missing on the OTHER side rather than
            // repeating the same value in both columns
            sb.append(renderDiffCell(d.expected, "added".equals(d.kind)));
            sb.append(renderDiffCell(d.actual, "removed".equals(d.kind)));
            sb.append("</tr>");
        }
        sb.append("</tbody></table>");
        return sb.toString();
    }

    /**
     * Render a single diff table cell. Handles four cases:
     *   1. The cell is the "missing side" of an added/removed diff →  (missing)
     *   2. The internal sentinel string "<missing>" leaked through →  (missing)
     *   3. Empty string value →  (empty)
     *   4. Real value → escaped and softly truncated at a word boundary
     *
     * Values containing XML markup are shown verbatim (still HTML-escaped for
     * safety) but in a pre tag so newlines and indentation read naturally.
     */
    private static String renderDiffCell(String value, boolean isMissing) {
        if (isMissing || value == null || "<missing>".equals(value)) {
            return "<td class=\"diff-cell\"><span class=\"diff-missing\">(missing)</span></td>";
        }
        if (value.isEmpty()) {
            return "<td class=\"diff-cell\"><span class=\"diff-missing\">(empty)</span></td>";
        }

        final int LIMIT = 500;
        String shown;
        boolean truncated = false;
        if (value.length() <= LIMIT) {
            shown = value;
        } else {
            // Try to truncate at a newline boundary so we don't cut tags in half
            int cut = LIMIT;
            int nl = value.lastIndexOf('\n', LIMIT);
            if (nl > LIMIT / 2) cut = nl;
            shown = value.substring(0, cut);
            truncated = true;
        }

        StringBuilder cell = new StringBuilder("<td class=\"diff-cell\"><pre>");
        cell.append(esc(shown));
        if (truncated) {
            cell.append("<span class=\"diff-trunc\">…(")
                .append(value.length() - shown.length())
                .append(" more chars)</span>");
        }
        cell.append("</pre></td>");
        return cell.toString();
    }

    private static String assertionTable(List<AssertionResult> results) {
        // Only render the Description column if at least one assertion has one.
        // Most users leave it blank; an always-on column wastes horizontal
        // space and adds visual noise.
        boolean showDescription = results.stream()
                .anyMatch(a -> a.description != null && !a.description.trim().isEmpty());

        StringBuilder sb = new StringBuilder("<table class=\"assert-table\"><thead><tr>");
        sb.append("<th>Status</th><th>Path</th><th>Operator</th><th>Expected</th><th>Actual</th>");
        if (showDescription) sb.append("<th>Description</th>");
        sb.append("</tr></thead><tbody>");
        for (AssertionResult a : results) {
            String pill = a.passed ? "<span class=\"status-pill s-pass\">PASS</span>"
                                   : "<span class=\"status-pill s-fail\">FAIL</span>";
            sb.append("<tr><td>").append(pill).append("</td>");
            sb.append("<td><code>").append(esc(a.path)).append("</code></td>");
            sb.append("<td>").append(esc(a.operator)).append("</td>");
            sb.append("<td><code>").append(esc(a.expectedValue == null ? "" : a.expectedValue)).append("</code></td>");
            String actual = a.actualValue == null ? "" : a.actualValue;
            sb.append("<td>");
            if (actual.isEmpty()) {
                sb.append("<span class=\"assert-empty\">(empty)</span>");
            } else {
                sb.append("<code>").append(esc(actual)).append("</code>");
            }
            if (!a.passed && a.message != null && !a.message.isEmpty()) {
                sb.append("<div class=\"assert-msg\">").append(esc(a.message)).append("</div>");
            }
            sb.append("</td>");
            if (showDescription) {
                sb.append("<td>").append(esc(a.description == null ? "" : a.description)).append("</td>");
            }
            sb.append("</tr>");
        }
        sb.append("</tbody></table>");
        return sb.toString();
    }

    // ------------------------------------------------------------------
    // Pretty printing & highlighting
    // ------------------------------------------------------------------

    private record Pretty(String text, String format) {}

    private static Pretty prettify(String payload) {
        if (payload == null || payload.isBlank()) return new Pretty("", "text");
        // Strip BOM, leading whitespace, and other junk BEFORE deciding format.
        String s = com.apitest.comparator.Comparator.sanitizeXmlProlog(payload).strip();

        // Server may send XML that contains HTML-escaped XML as text content
        // (common SOAP pattern: <Payload>&lt;Order&gt;...&lt;/Order&gt;</Payload>).
        // If we detect this pattern, decode the escaped portion so it renders
        // and indents like real XML rather than as a wall of "&lt;" tokens.
        s = decodeEmbeddedEscapedXml(s);

        try {
            if (s.startsWith("<")) {
                // Normalize CRLF/CR to LF: the JDK transformer otherwise preserves
                // every \r as a &#xd; entity in the rendered output, which is what
                // produced the trailing &#xd; in SOAP header tags.
                s = s.replace("\r\n", "\n").replace("\r", "");
                // Strip literal &#xd; / &#xD; / &#13; sequences that appear in
                // element content when servers double-encode carriage returns.
                // These would otherwise pass through to the rendered output as
                // visible text (because the parser leaves them alone as legal
                // character refs, and the reporter HTML-escapes the result).
                s = s.replaceAll("&#x[dD];", "").replaceAll("&#13;", "");

                javax.xml.parsers.DocumentBuilderFactory dbf = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                dbf.setNamespaceAware(false);
                // Harden against XXE attacks
                try {
                    dbf.setFeature(javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING, true);
                    dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
                    dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
                    dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
                    dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
                    dbf.setXIncludeAware(false);
                    dbf.setExpandEntityReferences(false);
                } catch (Exception ignore) {
                    // Best-effort hardening — features vary by parser impl
                }
                javax.xml.parsers.DocumentBuilder builder = dbf.newDocumentBuilder();
                // Swallow parser error callbacks AND redirect stderr — Xerces
                // logs "[Fatal Error] :1:N:..." directly to System.err before
                // the handler is invoked, even when the exception is caught
                // by our try/catch around the call.
                builder.setErrorHandler(new org.xml.sax.ErrorHandler() {
                    public void warning(org.xml.sax.SAXParseException e) {}
                    public void error(org.xml.sax.SAXParseException e) {}
                    public void fatalError(org.xml.sax.SAXParseException e) throws org.xml.sax.SAXException { throw e; }
                });
                java.io.PrintStream originalErr = System.err;
                org.w3c.dom.Document doc;
                try {
                    System.setErr(new java.io.PrintStream(java.io.OutputStream.nullOutputStream()));
                    doc = builder.parse(new org.xml.sax.InputSource(new java.io.StringReader(s)));
                } finally {
                    System.setErr(originalErr);
                }
                doc.setXmlStandalone(true);

                // Strip whitespace-only text nodes so the JDK transformer can
                // re-indent the document cleanly. Without this, the input's
                // existing whitespace is preserved AND new indentation is added,
                // producing extra blank lines and erratic indenting.
                stripWhitespaceNodes(doc.getDocumentElement());
                // Strip stray \r characters from text node content (servers
                // sometimes inject them into header values).
                normalizeTextNodes(doc.getDocumentElement());

                javax.xml.transform.Transformer t = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
                t.setOutputProperty(javax.xml.transform.OutputKeys.INDENT, "yes");
                t.setOutputProperty(javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION, "yes");
                t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
                java.io.StringWriter sw = new java.io.StringWriter();
                t.transform(new javax.xml.transform.dom.DOMSource(doc), new javax.xml.transform.stream.StreamResult(sw));
                return new Pretty(sw.toString().trim(), "xml");
            }
            if (s.startsWith("{") || s.startsWith("[")) {
                com.fasterxml.jackson.databind.ObjectMapper m = new com.fasterxml.jackson.databind.ObjectMapper();
                Object tree = m.readValue(s, Object.class);
                return new Pretty(m.writerWithDefaultPrettyPrinter().writeValueAsString(tree), "json");
            }
        } catch (Exception ignore) {}
        return new Pretty(s, "text");
    }

    /** Recursively remove whitespace-only text nodes so the transformer can re-indent cleanly. */
    private static void stripWhitespaceNodes(org.w3c.dom.Node node) {
        org.w3c.dom.NodeList children = node.getChildNodes();
        for (int i = children.getLength() - 1; i >= 0; i--) {
            org.w3c.dom.Node child = children.item(i);
            if (child.getNodeType() == org.w3c.dom.Node.TEXT_NODE
                    && child.getNodeValue() != null
                    && child.getNodeValue().trim().isEmpty()) {
                node.removeChild(child);
            } else if (child.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
                stripWhitespaceNodes(child);
            }
        }
    }

    /** Recursively strip stray \r characters from text node content. */
    private static void normalizeTextNodes(org.w3c.dom.Node node) {
        org.w3c.dom.NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            org.w3c.dom.Node child = children.item(i);
            if (child.getNodeType() == org.w3c.dom.Node.TEXT_NODE) {
                String v = child.getNodeValue();
                if (v != null && v.indexOf('\r') >= 0) {
                    child.setNodeValue(v.replace("\r", ""));
                }
            } else if (child.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
                normalizeTextNodes(child);
            }
        }
    }

    /**
     * If a payload contains long stretches of HTML-escaped XML (&lt;Tag&gt;…&lt;/Tag&gt;)
     * decode them into real XML so the report renders the inner structure.
     * Idempotent and safe: a payload with no escaped content is returned unchanged.
     */
    private static String decodeEmbeddedEscapedXml(String s) {
        if (s == null || !s.contains("&lt;")) return s;
        // Heuristic: only decode if we see escaped tag pairs that look like XML.
        // Requires at least 3 escaped tag openings to avoid touching legitimate text
        // that happens to contain a stray &lt;.
        int hits = 0;
        int idx = 0;
        while ((idx = s.indexOf("&lt;", idx)) != -1) { hits++; idx += 4; if (hits >= 3) break; }
        if (hits < 3) return s;
        return s.replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'")
                .replace("&amp;", "&");
    }

    private static String highlight(String text, String fmt) {
        String e = esc(text);
        if ("xml".equals(fmt)) {
            e = e.replaceAll("(&lt;/?)([\\w:.-]+)", "$1<span class=\"tk-tag\">$2</span>");
            e = e.replaceAll("([\\w:-]+)(=)(&quot;)([^&]*)(&quot;)",
                    "<span class=\"tk-attr\">$1</span>$2<span class=\"tk-str\">$3$4$5</span>");
        } else if ("json".equals(fmt)) {
            e = e.replaceAll("(&quot;[^&]*?&quot;)(\\s*:)", "<span class=\"tk-key\">$1</span>$2");
            e = e.replaceAll(":\\s*(&quot;[^&]*?&quot;)", ": <span class=\"tk-str\">$1</span>");
            e = e.replaceAll(":\\s*(-?\\d+\\.?\\d*)", ": <span class=\"tk-num\">$1</span>");
            e = e.replaceAll(":\\s*(true|false|null)", ": <span class=\"tk-kw\">$1</span>");
        }
        return e;
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private static String statusClass(String status) {
        return switch (status) {
            case "PASS" -> "s-pass";
            case "FAIL" -> "s-fail";
            case "ERROR" -> "s-err";
            default -> "";
        };
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max) : s;
    }

    // ------------------------------------------------------------------
    // Static assets
    // ------------------------------------------------------------------

    private static final String CSS = """
:root {
  --bg: #f5f6f8; --surface: #ffffff; --surface-2: #fafbfc;
  --border: #e1e4e8; --border-strong: #d0d7de;
  --text: #1f2328; --text-muted: #57606a; --text-faint: #8b949e;
  --brand: #1F4E78; --accent: #5b8def;
  --pass: #1d9e75; --pass-bg: #e6f4ec;
  --fail: #d14545; --fail-bg: #fce8e8;
  --err: #bf6a0b; --err-bg: #fdf2e0;
  --code-bg: #f6f8fa;
}
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Inter", system-ui, sans-serif;
       background: var(--bg); color: var(--text); font-size: 14px; line-height: 1.5;
       -webkit-font-smoothing: antialiased; }
.mono, code, pre { font-family: "SF Mono", Consolas, Menlo, monospace; }
.muted { color: var(--text-muted); font-size: 12px; }

header { background: var(--brand); color: white; padding: 18px 28px;
         display: flex; align-items: center; justify-content: space-between; }
header h1 { margin: 0; font-size: 18px; font-weight: 500; }
header .meta { font-size: 12px; opacity: 0.85; margin-top: 3px; }
header .right { display: flex; gap: 6px; flex-wrap: wrap; max-width: 50%; justify-content: flex-end; }
.badge-env { background: rgba(255,255,255,0.15); padding: 4px 10px; border-radius: 4px; font-size: 11px; }

.dashboard { display: grid; grid-template-columns: 280px 1fr 320px; gap: 16px;
             padding: 20px 28px; background: var(--surface); border-bottom: 1px solid var(--border); }
.dash-card { background: var(--surface-2); border: 1px solid var(--border); border-radius: 8px; padding: 16px 18px; }
.dash-card h3 { margin: 0 0 10px; font-size: 11px; font-weight: 600; text-transform: uppercase;
                letter-spacing: 0.6px; color: var(--text-muted); }

.donut-wrap { display: flex; align-items: center; gap: 14px; }
.donut { width: 130px; height: 130px; }
.donut-num { font-size: 22px; font-weight: 600; fill: var(--text); }
.donut-lbl { font-size: 10px; fill: var(--text-muted); }
.donut-legend { display: flex; flex-direction: column; gap: 6px; font-size: 12px; }
.lg-row { display: flex; align-items: center; gap: 8px; }
.lg-sw { width: 10px; height: 10px; border-radius: 2px; }
.lg-row strong { margin-left: auto; }

.kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.kpi { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 14px 16px; }
.kpi .n { font-size: 24px; font-weight: 600; line-height: 1.1; }
.kpi .l { font-size: 10px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.6px; margin-top: 4px; }
.kpi.pass .n { color: var(--pass); }
.kpi.fail .n { color: var(--fail); }
.kpi.err .n { color: var(--err); }

.mode-breakdown { display: flex; flex-direction: column; gap: 8px; }
.mb-row { display: flex; align-items: center; gap: 8px; font-size: 11px; }
.mb-label { flex: 0 0 140px; color: var(--text-muted); }
.mb-bar-track { flex: 1; height: 8px; background: #eef0f3; border-radius: 4px; overflow: hidden; }
.mb-bar { height: 100%; background: var(--accent); }
.mb-count { font-weight: 600; min-width: 20px; text-align: right; }

.toolbar { display: flex; gap: 10px; align-items: center; padding: 12px 28px;
           background: var(--surface); border-bottom: 1px solid var(--border); flex-wrap: wrap; }
.search-box { display: flex; align-items: center; background: var(--surface-2);
              border: 1px solid var(--border); border-radius: 6px; padding: 6px 10px;
              flex: 1; min-width: 240px; max-width: 420px; }
.search-box input { border: none; outline: none; background: transparent; width: 100%;
                    font-size: 13px; font-family: inherit; color: var(--text); }
.search-box svg { width: 14px; height: 14px; opacity: 0.5; margin-right: 6px; }
.filter-group { display: flex; gap: 4px; align-items: center; }
.filter-group .label { font-size: 10px; color: var(--text-muted); margin-right: 4px;
                       text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; }
.filter-btn { background: var(--surface-2); border: 1px solid var(--border); border-radius: 5px;
              padding: 5px 11px; cursor: pointer; font-size: 12px; color: var(--text); font-family: inherit; }
.filter-btn:hover { background: #eef0f3; }
.filter-btn.active { background: var(--brand); color: white; border-color: var(--brand); }
.sort-select { background: var(--surface-2); border: 1px solid var(--border); border-radius: 5px;
               padding: 5px 8px; font-size: 12px; font-family: inherit; cursor: pointer; }

.app { display: grid; grid-template-columns: 320px 1fr; min-height: 600px; }
.sidebar { background: var(--surface); border-right: 1px solid var(--border); padding: 12px 0;
           max-height: calc(100vh - 200px); overflow-y: auto; position: sticky; top: 0; }
.nav-item { display: flex; align-items: flex-start; gap: 10px; padding: 10px 16px;
            text-decoration: none; color: var(--text); border-left: 3px solid transparent; }
.nav-item:hover { background: var(--surface-2); }
.nav-item.active { background: #e8f0fa; border-left-color: var(--brand); }
.nav-dot { width: 8px; height: 8px; border-radius: 50%; margin-top: 6px; flex: 0 0 auto; }
.nav-dot.s-pass { background: var(--pass); } .nav-dot.s-fail { background: var(--fail); }
.nav-dot.s-err { background: var(--err); }
.nav-content { display: flex; flex-direction: column; gap: 2px; min-width: 0; flex: 1; }
.nav-id { font-size: 11px; font-weight: 600; color: var(--brand); font-family: "SF Mono", Consolas, monospace; }
.nav-title { font-size: 13px; line-height: 1.35; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.nav-meta { font-size: 11px; color: var(--text-muted); }
.main { padding: 20px 28px 60px; }

.test-section { background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
                margin-bottom: 16px; overflow: hidden; scroll-margin-top: 20px; }
.test-header { display: flex; justify-content: space-between; align-items: flex-start;
               padding: 18px 22px 14px; border-bottom: 1px solid var(--border); gap: 16px; }
.test-header-left { flex: 1; min-width: 0; }
.test-id { font-size: 11px; font-weight: 600; color: var(--brand); letter-spacing: 0.4px; }
.test-name { margin: 4px 0; font-size: 17px; font-weight: 500; }
.test-desc { margin: 0; font-size: 13px; color: var(--text-muted); }
.test-header-right { display: flex; align-items: center; gap: 10px; flex: 0 0 auto; }

.status-pill { display: inline-block; padding: 4px 10px; border-radius: 12px;
               font-size: 11px; font-weight: 600; letter-spacing: 0.4px; }
.status-pill.s-pass { background: var(--pass-bg); color: var(--pass); }
.status-pill.s-fail { background: var(--fail-bg); color: var(--fail); }
.status-pill.s-err { background: var(--err-bg); color: var(--err); }

.src-pill { display: inline-block; padding: 1px 7px; border-radius: 9px;
            font-size: 10px; font-weight: 600; letter-spacing: 0.3px;
            margin-left: 6px; vertical-align: middle; text-transform: uppercase; }
.src-pill.src-ok  { background: var(--pass-bg); color: var(--pass); }
.src-pill.src-bad { background: var(--fail-bg); color: var(--fail); }

.test-error-banner { padding: 10px 22px; background: var(--fail-bg); color: var(--fail);
                     font-size: 12px; border-bottom: 1px solid var(--border); }

.tabs { display: flex; gap: 2px; padding: 0 22px; border-bottom: 1px solid var(--border);
        background: var(--surface-2); }
.tab-btn { background: none; border: none; padding: 10px 14px; font-size: 12px; font-weight: 500;
           color: var(--text-muted); cursor: pointer; border-bottom: 2px solid transparent;
           font-family: inherit; margin-bottom: -1px; display: flex; align-items: center; gap: 6px; }
.tab-btn:hover { color: var(--text); }
.tab-btn.active { color: var(--brand); border-bottom-color: var(--brand); }
.tab-count { background: var(--border); color: var(--text-muted); font-size: 10px;
             font-weight: 600; padding: 1px 6px; border-radius: 8px; }
.tab-btn.active .tab-count { background: var(--brand); color: white; }
.tab-pane { display: none; padding: 18px 22px; }
.tab-pane.active { display: block; }

.overview-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.ov-cell { background: var(--surface-2); border: 1px solid var(--border); border-radius: 6px; padding: 10px 12px; }
.ov-label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px;
            color: var(--text-muted); margin-bottom: 4px; font-weight: 600; }
.ov-val { font-size: 13px; font-weight: 500; }
.mode-tag { display: inline-block; background: #eef2f7; color: var(--brand);
            padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
.overview-cmp { margin-top: 14px; padding: 10px 14px; background: var(--surface-2);
                border-left: 3px solid var(--brand); border-radius: 0 6px 6px 0;
                font-size: 13px; display: flex; gap: 10px; align-items: baseline; }
.overview-cmp .ov-label { margin-bottom: 0; }

.source-section { margin-bottom: 14px; }
.source-section-head { display: flex; align-items: center; gap: 8px; margin-bottom: 10px;
                       padding-bottom: 6px; border-bottom: 1px solid var(--border); }
.source-letter { display: inline-flex; align-items: center; justify-content: center;
                 width: 22px; height: 22px; background: var(--brand); color: white;
                 border-radius: 4px; font-size: 11px; font-weight: 700; }
.source-letter.source-b { background: var(--accent); }
.source-name { font-size: 12px; font-weight: 500; }

.step-card { background: var(--surface-2); border: 1px solid var(--border);
             border-left: 3px solid var(--border-strong); border-radius: 6px;
             padding: 12px 14px; margin-bottom: 8px; }
.step-card.step-pass { border-left-color: var(--pass); }
.step-card.step-fail { border-left-color: var(--fail); }
.step-card-head { display: flex; justify-content: space-between; align-items: center;
                  margin-bottom: 8px; flex-wrap: wrap; gap: 6px; }
.step-card-title { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.step-badge { background: var(--brand); color: white; font-size: 10px; font-weight: 600;
              padding: 2px 8px; border-radius: 3px; }
.step-name { font-size: 13px; font-weight: 500; }
.step-card-meta { display: flex; align-items: center; gap: 6px; }
.http-status { font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 3px;
               font-family: "SF Mono", Consolas, monospace; }
.http-ok { background: var(--pass-bg); color: var(--pass); }
.http-bad { background: var(--fail-bg); color: var(--fail); }

.step-card-url { display: flex; align-items: center; gap: 8px; margin-bottom: 8px;
                 padding: 6px 10px; background: var(--code-bg); border-radius: 4px;
                 font-size: 12px; overflow-x: auto; }
.step-card-url code { background: none; padding: 0; word-break: break-all; }
.method { font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 3px; flex: 0 0 auto; }
.method-get { background: #e6f1fb; color: #185fa5; }
.method-post { background: #eaf3de; color: #3b6d11; }
.method-put { background: #faeeda; color: #854f0b; }
.method-delete { background: #fcebeb; color: #a32d2d; }
.method-patch { background: #eeedfe; color: #534ab7; }

.step-err { background: var(--fail-bg); border: 1px solid #fbb; color: var(--fail);
            padding: 10px 14px; border-radius: 5px; font-size: 12px; margin: 10px 0; }
.step-err-head { font-weight: 600; margin-bottom: 6px; }
.step-err-body { margin: 0; font-family: ui-monospace, monospace; font-size: 11.5px;
                 white-space: pre-wrap; word-wrap: break-word; color: var(--fail); }

.code-block { margin: 8px 0; border: 1px solid var(--border); border-radius: 5px; overflow: hidden; }
.code-head { display: flex; align-items: center; gap: 10px; padding: 6px 10px;
             background: #eef0f3; border-bottom: 1px solid var(--border); font-size: 11px; }
.code-label { font-weight: 600; }
.code-meta { color: var(--text-muted); flex: 1; }
.copy-btn { background: var(--surface); border: 1px solid var(--border); border-radius: 3px;
            padding: 2px 8px; font-size: 10px; font-family: inherit; cursor: pointer;
            color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.4px; }
.copy-btn:hover { background: var(--brand); color: white; border-color: var(--brand); }
.copy-btn.copied { background: var(--pass); color: white; border-color: var(--pass); }
.code-pre { margin: 0; padding: 10px 12px; font-size: 11.5px; line-height: 1.55;
            overflow-x: auto; background: var(--code-bg); max-height: 300px;
            white-space: pre-wrap; word-break: break-word; }
.code-empty { background: var(--code-bg); border: 1px dashed var(--border); border-radius: 4px;
              padding: 8px 12px; font-size: 11px; color: var(--text-faint); margin: 6px 0;
              font-style: italic; }

.tk-tag { color: #1F4E78; font-weight: 600; }
.tk-attr { color: #a32d2d; }
.tk-str { color: #1d9e75; }
.tk-key { color: #1F4E78; font-weight: 600; }
.tk-num { color: #bf6a0b; }
.tk-kw { color: #6f42c1; font-weight: 600; }

.extracted { margin-top: 8px; padding: 8px 12px; background: var(--surface);
             border: 1px dashed var(--border); border-radius: 4px; }
.extracted-head { font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px;
                  color: var(--text-muted); margin-bottom: 6px; font-weight: 600; }
.kv-row { display: flex; gap: 12px; font-size: 12px; padding: 2px 0; }
.kv-k { color: var(--text-muted); min-width: 100px; }
.kv-v code { background: var(--code-bg); padding: 1px 6px; border-radius: 3px; font-size: 11px; }

.compare-summary { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; flex-wrap: wrap; }
.badge { display: inline-block; padding: 4px 10px; border-radius: 4px; font-size: 11px; font-weight: 600; }
.badge-ok { background: var(--pass-bg); color: var(--pass); }
.badge-bad { background: var(--fail-bg); color: var(--fail); }

.compare-prepared { margin: 0 0 14px 0; border: 1px solid var(--border); border-radius: 5px;
                    background: var(--surface-2); }
.compare-prepared > summary { cursor: pointer; padding: 8px 12px; font-size: 12px;
                              font-weight: 600; color: var(--muted); user-select: none; }
.compare-prepared[open] > summary { border-bottom: 1px solid var(--border); }
.compare-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0; }
.compare-side { border-right: 1px solid var(--border); min-width: 0; }
.compare-side:last-child { border-right: none; }
.compare-side-head { padding: 6px 10px; background: var(--surface); border-bottom: 1px solid var(--border);
                     font-size: 11px; color: var(--muted); font-weight: 600; }
.compare-payload { margin: 0; padding: 10px; font-family: ui-monospace, monospace; font-size: 11.5px;
                   max-height: 600px; overflow: auto; white-space: pre-wrap; word-wrap: break-word;
                   background: var(--surface); }

.diff-view-toggle { display: flex; gap: 4px; margin-bottom: 12px; }
.vt-btn { background: var(--surface-2); border: 1px solid var(--border); border-radius: 4px;
          padding: 5px 12px; font-size: 11px; cursor: pointer; font-family: inherit; }
.vt-btn.active { background: var(--brand); color: white; border-color: var(--brand); }

.diff-ok { background: var(--pass-bg); color: var(--pass); padding: 12px 16px;
           border-radius: 6px; font-size: 13px; font-weight: 500; }
.diff-list { display: flex; flex-direction: column; gap: 12px; }
.diff-row { background: var(--surface-2); border: 1px solid var(--border); border-radius: 6px; overflow: hidden; }
.diff-meta { display: flex; align-items: center; gap: 8px; padding: 6px 12px;
             background: #eef0f3; border-bottom: 1px solid var(--border); flex-wrap: wrap; }
.diff-kind { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;
             padding: 2px 6px; border-radius: 3px; }
.diff-kind.k-val { background: #fce8e8; color: #a32d2d; }
.diff-kind.k-typ { background: #faeeda; color: #854f0b; }
.diff-kind.k-add { background: #eaf3de; color: #3b6d11; }
.diff-kind.k-rem { background: #fce8e8; color: #a32d2d; }
.diff-kind.k-len { background: #eeedfe; color: #534ab7; }
.diff-path { font-size: 11px; color: var(--text-muted); background: var(--surface);
             padding: 1px 6px; border-radius: 3px; }
.diff-pair { display: grid; grid-template-columns: 1fr 1fr; gap: 1px; background: var(--border); }
.diff-side { background: var(--surface); padding: 8px 12px; }
.diff-side-head { font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px;
                  color: var(--text-muted); margin-bottom: 4px; font-weight: 600; }
.diff-side pre { margin: 0; font-size: 11.5px; line-height: 1.5; white-space: pre-wrap;
                 word-break: break-word; max-height: 120px; overflow-y: auto; }
.diff-side.diff-exp { background: #fafefb; }
.diff-side.diff-act { background: #fffafa; }
.diff-table { width: 100%; border-collapse: collapse; font-size: 12px; table-layout: fixed; }
.diff-table th, .diff-table td { border: 1px solid var(--border); padding: 8px 10px;
                                  text-align: left; vertical-align: top; overflow-wrap: anywhere; }
.diff-table th { background: var(--surface-2); font-weight: 600; font-size: 11px;
                 text-transform: uppercase; letter-spacing: 0.4px; color: var(--text-muted); }
.diff-table th:nth-child(1) { width: 80px; }    /* Kind */
.diff-table th:nth-child(2) { width: 28%; }     /* Path */
.diff-table .diff-cell { background: var(--surface); }
.diff-table .diff-cell pre { margin: 0; font-size: 11px; max-height: 200px;
                              white-space: pre-wrap; word-break: break-word; overflow: auto; }
.diff-table code.diff-path { background: var(--code-bg); padding: 1px 5px; border-radius: 3px;
                              font-size: 11px; word-break: break-all; }
.diff-missing { color: var(--text-faint); font-style: italic; font-size: 11px; }
.diff-trunc { color: var(--text-muted); font-size: 10px; font-style: italic; margin-left: 6px; }

.assert-table { width: 100%; border-collapse: collapse; font-size: 12px; }
.assert-table th, .assert-table td { border: 1px solid var(--border); padding: 8px 10px;
                                      text-align: left; vertical-align: top; }
.assert-table th { background: var(--surface-2); font-weight: 600; font-size: 11px;
                   text-transform: uppercase; letter-spacing: 0.4px; color: var(--text-muted); }
.assert-table code { background: var(--code-bg); padding: 1px 5px; border-radius: 3px; font-size: 11px; }
.assert-empty { color: var(--text-faint); font-size: 11px; font-style: italic; }
.assert-msg { color: var(--fail); font-size: 11px; margin-top: 4px; font-style: italic; }

.empty { text-align: center; padding: 60px 20px; color: var(--text-muted); font-size: 14px; }

@media print {
  body { background: white; }
  header, .toolbar, .sidebar { display: none; }
  .app { display: block; }
  .main { padding: 0; }
  .tab-pane { display: block !important; padding: 12px 0; border-top: 1px solid var(--border); }
  .tabs { display: none; }
  .test-section { page-break-inside: avoid; }
  .code-pre { max-height: none; }
}
@media (max-width: 1100px) {
  .dashboard { grid-template-columns: 1fr; }
  .app { grid-template-columns: 1fr; }
  .sidebar { max-height: 300px; position: relative; }
  .overview-grid { grid-template-columns: repeat(2, 1fr); }
  .kpi-grid { grid-template-columns: repeat(2, 1fr); }
  .diff-pair { grid-template-columns: 1fr; }
}
""";

    private static final String JS = """
const state = { status: 'ALL', mode: 'ALL', query: '' };
function applyFilters() {
  const q = state.query.toLowerCase();
  document.querySelectorAll('.test-section').forEach(el => {
    const mS = state.status === 'ALL' || el.dataset.status === state.status;
    const mM = state.mode === 'ALL' || el.dataset.mode === state.mode;
    const mQ = !q || el.dataset.name.includes(q) || el.id.toLowerCase().includes(q);
    el.style.display = (mS && mM && mQ) ? '' : 'none';
  });
  document.querySelectorAll('.nav-item').forEach(el => {
    const mS = state.status === 'ALL' || el.dataset.status === state.status;
    const mM = state.mode === 'ALL' || el.dataset.mode === state.mode;
    const mQ = !q || el.dataset.name.includes(q) || el.getAttribute('href').toLowerCase().includes(q);
    el.style.display = (mS && mM && mQ) ? '' : 'none';
  });
}
function setFilterStatus(v, btn) {
  state.status = v;
  document.querySelectorAll('[data-filter-status]').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  applyFilters();
}
function setFilterMode(v, btn) {
  state.mode = v;
  document.querySelectorAll('[data-filter-mode]').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  applyFilters();
}
function search(v) { state.query = v; applyFilters(); }
function sortTests(v) {
  const main = document.querySelector('.main');
  const sections = Array.from(main.querySelectorAll('.test-section'));
  sections.sort((a, b) => {
    if (v === 'duration_desc' || v === 'duration_asc') {
      const aMs = parseInt(a.querySelector('.test-header-right .muted').textContent) || 0;
      const bMs = parseInt(b.querySelector('.test-header-right .muted').textContent) || 0;
      return v === 'duration_desc' ? bMs - aMs : aMs - bMs;
    }
    if (v === 'name') return a.dataset.name.localeCompare(b.dataset.name);
    if (v === 'status') {
      const rank = { FAIL: 0, ERROR: 1, PASS: 2 };
      return rank[a.dataset.status] - rank[b.dataset.status];
    }
    return 0;
  });
  sections.forEach(s => main.appendChild(s));
}
function setTab(btn, tab) {
  const section = btn.closest('.test-section');
  section.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  section.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  section.querySelector(`.tab-pane[data-tab="${tab}"]`).classList.add('active');
}
function setDiffView(idx, view, btn) {
  btn.parentElement.querySelectorAll('.vt-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById(`diff-side-${idx}`).style.display = view === 'side' ? '' : 'none';
  document.getElementById(`diff-table-${idx}`).style.display = view === 'table' ? '' : 'none';
}
function copyCode(id, btn) {
  const el = document.getElementById(id);
  const text = el.innerText;
  navigator.clipboard.writeText(text).then(() => {
    btn.textContent = 'copied';
    btn.classList.add('copied');
    setTimeout(() => { btn.textContent = 'copy'; btn.classList.remove('copied'); }, 1500);
  });
}
document.addEventListener('keydown', (e) => {
  if (e.key === '/' && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName)) {
    e.preventDefault();
    document.querySelector('#search-input').focus();
  }
  if (e.key === 'Escape') {
    const inp = document.querySelector('#search-input');
    inp.value = ''; state.query = ''; applyFilters();
  }
});
if (location.hash) {
  const el = document.querySelector(location.hash);
  if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
}
""";
}
