package com.apitest.runner;

import com.apitest.comparator.AssertionEngine;
import com.apitest.comparator.Comparator;
import com.apitest.dispatcher.Dispatcher;
import com.apitest.dispatcher.Response;
import com.apitest.excel.ExcelLoader;

import java.io.IOException;
import com.apitest.model.*;
import com.apitest.template.TemplateEngine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Orchestrates: load suite → execute steps → compare/assert → record results.
 *
 * Comparison modes:
 *   vs_expected      Run on source A, compare to expected file
 *   vs_env           Run on source A and source B, compare responses
 *   vs_protocol      Run on two different protocols, compare normalized
 *   assert_only      Run on source A, validate field-level assertions
 *   chain            Run all steps in order, no comparison
 */
public class Runner {

    private static final DateTimeFormatter TS_FOLDER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    private static final DateTimeFormatter TS_DISPLAY = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Run the suite using default conventions (templates/, expected/, output/
     * relative to projectRoot). Kept for backward compatibility and tests.
     */
    public static List<TestResult> runAll(Path suitePath, Path projectRoot) throws Exception {
        RunConfig cfg = new RunConfig(
                suitePath,
                projectRoot.resolve("reports/report.html"),
                projectRoot,
                projectRoot.resolve("templates"),
                projectRoot.resolve("expected"),
                projectRoot.resolve("output"),
                "API Test Suite"
        );
        return runAll(cfg);
    }

    /**
     * Run the suite using the given configuration. Paths in RunConfig take
     * precedence over the conventional defaults.
     */
    public static List<TestResult> runAll(RunConfig cfg) throws Exception {
        TestSuite suite = ExcelLoader.load(cfg.suitePath);
        Path outputRoot = cfg.outputDir.resolve(LocalDateTime.now().format(TS_FOLDER));
        Files.createDirectories(outputRoot);

        List<TestResult> results = new ArrayList<>();
        for (TestCase tc : suite.tests()) {
            System.out.println("  Running " + tc.testId + ": " + tc.name);
            try {
                results.add(runTest(tc, suite, cfg, outputRoot));
            } catch (Throwable ex) {
                // A test threw outside the per-step safety nets — record it
                // as a failed test result and keep going. The suite never
                // aborts because of one bad test.
                TestResult r = new TestResult();
                r.testId = tc.testId;
                r.name = tc.name;
                r.description = tc.description;
                r.status = "ERROR";
                r.error = "Test execution error: " + ex.getClass().getSimpleName()
                        + ": " + ex.getMessage();
                r.started = LocalDateTime.now().format(TS_DISPLAY);
                results.add(r);
                System.err.println("    FAILED: " + r.error);
            }
        }
        return results;
    }

    /** Backward-compatible single-test entry point (kept for tests). */
    public static TestResult runTest(TestCase tc, TestSuite suite, Path projectRoot, Path outputRoot)
            throws Exception {
        RunConfig cfg = new RunConfig(
                null, null, projectRoot,
                projectRoot.resolve("templates"),
                projectRoot.resolve("expected"),
                projectRoot.resolve("output"),
                ""
        );
        return runTest(tc, suite, cfg, outputRoot);
    }

    public static TestResult runTest(TestCase tc, TestSuite suite, RunConfig cfg, Path outputRoot)
            throws Exception {

        long started = System.currentTimeMillis();
        Path testOut = outputRoot.resolve(tc.testId);
        Files.createDirectories(testOut);

        TestResult result = new TestResult();
        result.testId = tc.testId;
        result.name = tc.name;
        result.description = tc.description;
        result.comparisonMode = tc.comparisonMode;
        result.sourceA = tc.sourceA;
        result.sourceB = tc.sourceB;
        result.started = LocalDateTime.now().format(TS_DISPLAY);

        Environment envA = suite.environments().get(tc.sourceA);
        if (envA == null) {
            result.status = "ERROR";
            result.error = "Unknown environment: " + tc.sourceA;
            result.durationMs = System.currentTimeMillis() - started;
            return result;
        }

        result.stepsA = executeSteps(tc.steps, envA, tc.data, cfg, testOut.resolve("sourceA"));
        if (result.stepsA.stream().anyMatch(s -> !s.passed)) {
            result.status = "FAIL";
            result.error = "One or more steps in source A failed";
            result.durationMs = System.currentTimeMillis() - started;
            return result;
        }

        String mode = tc.comparisonMode == null ? "" : tc.comparisonMode;

        // Assertions can run on the final A response regardless of mode (except chain)
        if (!tc.assertions.isEmpty() && !"chain".equals(mode)) {
            String lastA = result.stepsA.get(result.stepsA.size() - 1).responseBody;
            result.assertionResults = AssertionEngine.evaluate(lastA, tc.assertions);
        }

        switch (mode) {
            case "chain" -> { /* nothing further */ }

            case "assert_only" -> {
                if (result.assertionResults.isEmpty()) {
                    result.status = "ERROR";
                    result.error = "assert_only mode requires at least one assertion";
                }
            }

            case "vs_expected" -> {
                String lastA = result.stepsA.get(result.stepsA.size() - 1).responseBody;
                Path expectedPath = resolveFile(tc.expectedFile, cfg.expectedDir, cfg.projectRoot);
                if (expectedPath == null) {
                    result.status = "ERROR";
                    StringBuilder msg = new StringBuilder("Expected file not found: ").append(tc.expectedFile);
                    msg.append("\n  Tried:");
                    if (cfg.expectedDir != null) msg.append("\n    ").append(cfg.expectedDir.resolve(tc.expectedFile));
                    if (cfg.projectRoot != null) msg.append("\n    ").append(cfg.projectRoot.resolve(tc.expectedFile));
                    result.error = msg.toString();
                } else {
                    String expected = Files.readString(expectedPath);
                    result.compareResult = Comparator.compare(expected, lastA, tc.assertions);
                }
            }

            case "vs_env", "vs_protocol" -> {
                Environment envB = suite.environments().get(tc.sourceB);
                if (envB == null) {
                    result.status = "ERROR";
                    result.error = "Unknown environment: " + tc.sourceB;
                } else {
                    result.stepsB = executeSteps(tc.steps, envB, tc.data, cfg, testOut.resolve("sourceB"));
                    if (result.stepsB.stream().anyMatch(s -> !s.passed)) {
                        result.status = "FAIL";
                        result.error = "One or more steps in source B failed";
                    } else {
                        String lastA = result.stepsA.get(result.stepsA.size() - 1).responseBody;
                        String lastB = result.stepsB.get(result.stepsB.size() - 1).responseBody;
                        result.compareResult = Comparator.compare(lastA, lastB, tc.assertions);
                    }
                }
            }

            default -> {
                result.status = "ERROR";
                result.error = "Unknown comparison mode: " + mode;
            }
        }

        // Final pass/fail determination.
        //
        // The switch above may have explicitly set status to FAIL (e.g. when
        // source B's steps failed in vs_env mode) or ERROR (e.g. when the
        // expected file is missing). We must NOT overwrite those — the
        // default PASS/FAIL computation below applies ONLY when no earlier
        // branch has decided the outcome.
        if (!"ERROR".equals(result.status) && !"FAIL".equals(result.status)) {
            boolean assertionsPassed = result.assertionResults.stream().allMatch(a -> a.passed);
            boolean compareMatched = result.compareResult == null || result.compareResult.matched;
            result.status = (assertionsPassed && compareMatched) ? "PASS" : "FAIL";
        }

        result.durationMs = System.currentTimeMillis() - started;
        return result;
    }

    // ------------------------------------------------------------------

    private static List<StepResult> executeSteps(List<Step> steps, Environment env,
                                                 Map<String, String> data, RunConfig cfg,
                                                 Path outputDir) throws Exception {
        List<StepResult> results = new ArrayList<>();
        Map<Integer, Map<String, String>> stepVars = new LinkedHashMap<>();
        Files.createDirectories(outputDir);

        for (Step step : steps) {
            String endpoint = "";
            String body = "";
            Response resp;
            TemplateEngine.RenderLog renderLog = new TemplateEngine.RenderLog();
            try {
                endpoint = TemplateEngine.render(step.endpoint(), data, stepVars, renderLog);
                if (step.bodyTemplate() != null && !step.bodyTemplate().isEmpty()) {
                    // Resolve BodyTemplate against configured templates dir,
                    // with project root as fallback (handles the case where
                    // user wrote "templates/req.xml" in Excel).
                    body = TemplateEngine.renderFile(step.bodyTemplate(), data, stepVars,
                            cfg.templatesDir, cfg.projectRoot, renderLog);
                }
            } catch (Throwable ex) {
                // ANY error during template processing (missing file, required
                // placeholder unresolved, IO error, etc.) becomes a failed step
                // in the report — never an uncaught exception that kills the
                // whole suite.
                StepResult sr = new StepResult();
                sr.order = step.order();
                sr.name = step.name();
                sr.url = step.endpoint();
                sr.method = step.method();
                sr.requestBody = body;
                sr.responseBody = "";
                sr.status = 0;
                sr.expectedStatus = step.expectedStatus();
                sr.passed = false;
                sr.error = "Template error: " + ex.getClass().getSimpleName()
                        + ": " + ex.getMessage()
                        + (renderLog.summary().equals("Render log:\n") ? ""
                            : "\n\n" + renderLog.fullTrace());
                results.add(sr);
                continue;
            }

            // Merge environment-level headers with step-level headers.
            // Step headers override env headers if same key. Both support
            // placeholders like ${step1.token} which get resolved here.
            Map<String, String> finalHeaders = new LinkedHashMap<>();
            for (Map.Entry<String, String> e : env.extraHeaders().entrySet()) {
                finalHeaders.put(e.getKey(),
                        TemplateEngine.render(e.getValue(), data, stepVars));
            }
            for (Map.Entry<String, String> e : step.extraHeaders().entrySet()) {
                finalHeaders.put(e.getKey(),
                        TemplateEngine.render(e.getValue(), data, stepVars));
            }

            try {
                resp = Dispatcher.send(
                        env.protocol(), env.baseUrl(), endpoint, step.method(),
                        body, finalHeaders, env.authType(), env.authValue(),
                        env.sslConfig()
                );
            } catch (Throwable ex) {
                // Network / SSL / dispatch errors. Same pattern: record as a
                // failed step with diagnostic info, don't kill the suite.
                StepResult sr = new StepResult();
                sr.order = step.order();
                sr.name = step.name();
                sr.url = endpoint;
                sr.method = step.method();
                sr.requestBody = body;
                sr.responseBody = "";
                sr.status = 0;
                sr.expectedStatus = step.expectedStatus();
                sr.passed = false;
                sr.error = "Dispatch error: " + ex.getClass().getSimpleName()
                        + ": " + ex.getMessage();
                results.add(sr);
                continue;
            }

            Map<String, String> extracted = new LinkedHashMap<>();
            try {
                for (Map.Entry<String, String> ev : step.extractVars().entrySet()) {
                    extracted.put(ev.getKey(), Comparator.extractVariable(resp.body, ev.getValue()));
                }
            } catch (Throwable ex) {
                // Variable extraction errors shouldn't break the run — record
                // but continue. The step still completes.
                extracted.put("__extract_error__", ex.getMessage());
            }
            stepVars.put(step.order(), extracted);

            boolean passed = step.expectedStatus().contains(resp.status) && resp.error == null;

            Path stepDir = outputDir.resolve("step" + step.order() + "_"
                    + step.name().replaceAll("[^a-zA-Z0-9._-]", "_"));
            try {
                Files.createDirectories(stepDir);
                Files.writeString(stepDir.resolve("request.txt"),
                        step.method() + " " + resp.url + "\n\n" + body);
                Files.writeString(stepDir.resolve("response.txt"),
                        "HTTP " + resp.status + "\nelapsed: " + resp.elapsedMs + "ms\n\n" + resp.body);
                // Persist the render log so the user has it on disk even when
                // the step otherwise passed. Useful when debugging "why did
                // some fields not appear in my request".
                if (!renderLog.summary().equals("Render log:\n")) {
                    Files.writeString(stepDir.resolve("render-log.txt"),
                            renderLog.fullTrace());
                }
            } catch (IOException ioEx) {
                // Disk error during artifact write. Note it but don't fail
                // the step on this alone.
                resp.error = (resp.error == null ? "" : resp.error + "; ")
                        + "Disk write failed: " + ioEx.getMessage();
            }

            StepResult sr = new StepResult();
            sr.name = step.name();
            sr.order = step.order();
            sr.method = step.method();
            sr.url = resp.url;
            sr.status = resp.status;
            sr.expectedStatus = step.expectedStatus();
            sr.elapsedMs = resp.elapsedMs;
            sr.requestBody = body;
            sr.responseBody = resp.body;
            sr.extracted = extracted;
            sr.error = resp.error;
            sr.passed = passed;
            results.add(sr);

            if (!passed) break;
        }
        return results;
    }

    /**
     * Resolve a user-provided file path against a primary directory (e.g.
     * expectedDir / templatesDir) and fall back to projectRoot if not found.
     * Returns null if no candidate exists.
     */
    private static Path resolveFile(String userPath, Path primaryDir, Path projectRoot) {
        if (userPath == null || userPath.isEmpty()) return null;
        Path p = Path.of(userPath);
        if (p.isAbsolute()) return Files.exists(p) ? p : null;
        if (primaryDir != null) {
            Path candidate = primaryDir.resolve(userPath);
            if (Files.exists(candidate)) return candidate;
        }
        if (projectRoot != null) {
            Path candidate = projectRoot.resolve(userPath);
            if (Files.exists(candidate)) return candidate;
        }
        return null;
    }
}
