package com.apitest.model;

/**
 * Field-level assertion or ignore directive.
 *
 * Operators:
 *   equals, not_equals, contains, exists, not_exists,
 *   greater_than, less_than, regex_match, ignore
 *
 * PathType:
 *   jsonpath  — e.g. $.order.id
 *   xpath     — e.g. //*[local-name()='Status']
 */
public record Assertion(
        String path,
        String pathType,
        String operator,
        String expectedValue,
        String description
) {}
