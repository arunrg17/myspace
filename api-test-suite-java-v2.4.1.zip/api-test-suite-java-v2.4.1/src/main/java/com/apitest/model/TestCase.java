package com.apitest.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Mutable test case (built up while parsing the Excel workbook).
 */
public class TestCase {
    public String testId;
    public String name;
    public String description;
    public String comparisonMode;
    public String sourceA;
    public String sourceB;
    public String expectedFile;
    public boolean enabled;
    public List<Step> steps = new ArrayList<>();
    public Map<String, String> data = new HashMap<>();
    public List<Assertion> assertions = new ArrayList<>();

    public TestCase() {}
}
