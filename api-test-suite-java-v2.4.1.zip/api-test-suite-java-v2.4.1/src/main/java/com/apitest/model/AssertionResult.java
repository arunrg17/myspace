package com.apitest.model;

public class AssertionResult {
    public String path;
    public String operator;
    public String expectedValue;
    public String actualValue;
    public String description;
    public boolean passed;
    public String message = "";
}
