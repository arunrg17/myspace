package com.apitest.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Diff entry: one structural mismatch between expected and actual.
 */
public class DiffEntry {
    public String path;
    public String expected;
    public String actual;
    public String kind; // value, type, added, removed, length

    public DiffEntry() {}

    public DiffEntry(String path, String expected, String actual, String kind) {
        this.path = path;
        this.expected = expected;
        this.actual = actual;
        this.kind = kind;
    }
}
