package com.apitest.model;

import java.util.List;
import java.util.Map;

/**
 * A single HTTP request in a test sequence.
 *
 * <p>Each step can override the environment's default headers by providing
 * its own {@code extraHeaders}. Useful for per-step authentication where a
 * previous step extracted a token (e.g. {@code Authorization: Bearer ${step1.token}}).
 */
public record Step(
        String testId,
        int order,
        String name,
        String method,
        String endpoint,
        String bodyTemplate,
        Map<String, String> extractVars,
        List<Integer> expectedStatus,
        Map<String, String> extraHeaders
) {}
