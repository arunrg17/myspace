package com.apitest.model;

import java.util.Map;

public record Environment(
        String name,
        String protocol,
        String baseUrl,
        String authType,
        String authValue,
        Map<String, String> extraHeaders,
        String sslConfig
) {
    /** Backward-compatible constructor — environments without SSL config. */
    public Environment(String name, String protocol, String baseUrl,
                       String authType, String authValue, Map<String, String> extraHeaders) {
        this(name, protocol, baseUrl, authType, authValue, extraHeaders, "");
    }
}
