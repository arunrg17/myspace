package com.apitest.model;

import java.util.List;
import java.util.Map;

public record TestSuite(
        Map<String, Environment> environments,
        List<TestCase> tests
) {}
