package com.apitest.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Per-step execution result.
 */
public class StepResult {
    public String name;
    public int order;
    public String method;
    public String url;
    public int status;
    public List<Integer> expectedStatus;
    public long elapsedMs;
    public String requestBody = "";
    public String responseBody = "";
    public Map<String, String> extracted = new LinkedHashMap<>();
    public String error;
    public boolean passed;
}
