package com.apitest;

import com.apitest.model.TestResult;
import com.apitest.reporter.Reporter;
import com.apitest.runner.RunConfig;
import com.apitest.runner.Runner;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * CLI entry point for the API test suite.
 *
 * <p>Every input or output location is configurable via a flag, so the runner
 * can execute from anywhere — ship just the jar to a colleague and let
 * them point the flags at their own files.
 *
 * <pre>
 *   java -jar api-test-suite.jar \
 *     --suite          /path/to/test_suite.xlsx \
 *     --report         /path/to/output/report.html \
 *     --templates-dir  /path/to/templates \
 *     --expected-dir   /path/to/expected \
 *     --output-dir     /path/to/run-artifacts
 * </pre>
 *
 * <p>Resolution rules:
 * <ul>
 *   <li>Any flag that's omitted falls back to a sensible relative default
 *       (e.g. {@code templates/} under {@code --project-root}).
 *   <li>{@code --project-root} controls those defaults; it defaults to the
 *       current working directory.
 *   <li>BodyTemplate / ExpectedFile entries inside the Excel sheet that are
 *       absolute paths are honoured as-is; relative entries resolve against
 *       {@code --templates-dir} / {@code --expected-dir} respectively.
 * </ul>
 */
public class Main {

    public static void main(String[] args) throws Exception {
        // Defaults — overridden by flags below.
        Path cwd = Paths.get("").toAbsolutePath();
        Path projectRoot   = cwd;
        Path suitePath     = null;
        Path reportPath    = null;
        Path templatesDir  = null;
        Path expectedDir   = null;
        Path outputDir     = null;
        String name = "API Test Suite";

        try {
            for (int i = 0; i < args.length; i++) {
                switch (args[i]) {
                    case "--suite"          -> suitePath    = abs(requireValue(args, ++i, "--suite"), cwd);
                    case "--report"         -> reportPath   = abs(requireValue(args, ++i, "--report"), cwd);
                    case "--project-root"   -> projectRoot  = abs(requireValue(args, ++i, "--project-root"), cwd);
                    case "--templates-dir"  -> templatesDir = abs(requireValue(args, ++i, "--templates-dir"), cwd);
                    case "--expected-dir"   -> expectedDir  = abs(requireValue(args, ++i, "--expected-dir"), cwd);
                    case "--output-dir"     -> outputDir    = abs(requireValue(args, ++i, "--output-dir"), cwd);
                    case "--name"           -> name         = requireValue(args, ++i, "--name");
                    case "--help", "-h"     -> { printHelp(); return; }
                    case "--version", "-v"  -> { System.out.println("api-test-suite " + Version.VERSION); return; }
                    default -> {
                        System.err.println("Unknown argument: " + args[i]);
                        printHelp();
                        System.exit(2);
                    }
                }
            }
        } catch (IllegalArgumentException ex) {
            System.err.println("Error: " + ex.getMessage());
            printHelp();
            System.exit(2);
        }

        // Fill in any flag that wasn't explicitly given.
        if (suitePath    == null) suitePath    = projectRoot.resolve("config/test_suite.xlsx");
        if (reportPath   == null) reportPath   = projectRoot.resolve("reports/report.html");
        if (templatesDir == null) templatesDir = projectRoot.resolve("templates");
        if (expectedDir  == null) expectedDir  = projectRoot.resolve("expected");
        if (outputDir    == null) outputDir    = projectRoot.resolve("output");

        if (!Files.exists(suitePath)) {
            System.err.println("Suite file not found: " + suitePath);
            System.err.println("Provide one with --suite <path>, or place it at config/test_suite.xlsx");
            System.exit(1);
        }

        System.out.println("API Test Suite v" + Version.VERSION);
        System.out.println("  Suite:       " + suitePath);
        System.out.println("  Project:     " + projectRoot);
        System.out.println("  Templates:   " + templatesDir);
        System.out.println("  Expected:    " + expectedDir);
        System.out.println("  Output:      " + outputDir);
        System.out.println("  Report:      " + reportPath);
        System.out.println();

        RunConfig cfg = new RunConfig(suitePath, reportPath, projectRoot,
                templatesDir, expectedDir, outputDir, name);

        List<TestResult> results = Runner.runAll(cfg);

        Files.createDirectories(reportPath.getParent());
        Reporter.renderReport(results, reportPath, name);

        long passed  = results.stream().filter(r -> "PASS".equals(r.status)).count();
        long failed  = results.stream().filter(r -> "FAIL".equals(r.status)).count();
        long errored = results.stream().filter(r -> "ERROR".equals(r.status)).count();

        System.out.println();
        System.out.println("  " + passed + " passed · " + failed + " failed · " + errored + " errored");
        System.out.println("  Report: " + reportPath);

        System.exit((failed == 0 && errored == 0) ? 0 : 1);
    }

    private static Path abs(String input, Path cwd) {
        Path p = Paths.get(input);
        return p.isAbsolute() ? p : cwd.resolve(p);
    }

    private static String requireValue(String[] args, int idx, String flag) {
        if (idx >= args.length || args[idx].startsWith("--")) {
            throw new IllegalArgumentException(flag + " requires a value");
        }
        return args[idx];
    }

    private static void printHelp() {
        System.out.println("API Test Suite v" + Version.VERSION);
        System.out.println();
        System.out.println("Usage: java -jar api-test-suite.jar [options]");
        System.out.println();
        System.out.println("Path options (all support absolute or relative paths):");
        System.out.println("  --suite <path>           Excel suite file");
        System.out.println("                           default: <project-root>/config/test_suite.xlsx");
        System.out.println("  --report <path>          HTML report output file");
        System.out.println("                           default: <project-root>/reports/report.html");
        System.out.println("  --project-root <path>    Base directory used for resolving the four");
        System.out.println("                           defaults below; default: current working dir");
        System.out.println("  --templates-dir <path>   Where BodyTemplate paths in Excel resolve");
        System.out.println("                           default: <project-root>/templates");
        System.out.println("  --expected-dir <path>    Where ExpectedFile paths in Excel resolve");
        System.out.println("                           default: <project-root>/expected");
        System.out.println("  --output-dir <path>      Per-run artifact storage (request/response/log)");
        System.out.println("                           default: <project-root>/output");
        System.out.println();
        System.out.println("Other options:");
        System.out.println("  --name <name>            Suite name shown in the report header");
        System.out.println("  --version, -v            Print version and exit");
        System.out.println("  --help, -h               Show this help message");
        System.out.println();
        System.out.println("Example — using only the jar, with everything explicit:");
        System.out.println("  java -jar api-test-suite.jar \\");
        System.out.println("    --suite          C:/work/tests/my_suite.xlsx \\");
        System.out.println("    --report         C:/work/tests/report.html \\");
        System.out.println("    --templates-dir  C:/work/tests/templates \\");
        System.out.println("    --expected-dir   C:/work/tests/expected \\");
        System.out.println("    --output-dir     C:/work/tests/run-output");
    }
}
