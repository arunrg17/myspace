package com.apitest.comparator;

import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Runs field-level assertions against a response payload.
 *
 * Operators:
 *   equals          actual == expected
 *   not_equals      actual != expected
 *   contains        actual contains expected (substring)
 *   exists          path resolves to a non-empty value
 *   not_exists      path does not resolve / is empty
 *   greater_than    numeric: actual > expected
 *   less_than       numeric: actual < expected
 *   regex_match     actual matches expected as a regex
 *   ignore          (handled by Comparator, not asserted here)
 */
public class AssertionEngine {

    public static List<AssertionResult> evaluate(String responseBody, List<Assertion> assertions) {
        List<AssertionResult> results = new ArrayList<>();
        if (assertions == null) return results;

        for (Assertion a : assertions) {
            if ("ignore".equalsIgnoreCase(a.operator())) continue; // ignores handled in Comparator

            AssertionResult r = new AssertionResult();
            r.path = a.path();
            r.operator = a.operator();
            r.expectedValue = a.expectedValue();
            r.description = a.description();

            // Friendly validation: catch common mistakes before extraction runs.
            String path = a.path() == null ? "" : a.path().trim();
            String pathType = a.pathType() == null ? "" : a.pathType().trim().toLowerCase();
            if ("xpath".equals(pathType) && path.startsWith("$")) {
                r.actualValue = "";
                r.passed = false;
                r.message = "Path starts with '$' but PathType is 'xpath'. "
                          + "Use '//Tag' for XPath, or set PathType to 'jsonpath' for $.field syntax.";
                results.add(r);
                continue;
            }
            if ("jsonpath".equals(pathType) && (path.startsWith("/") || path.startsWith("//"))) {
                r.actualValue = "";
                r.passed = false;
                r.message = "Path starts with '/' but PathType is 'jsonpath'. "
                          + "Use '$.field' for JSONPath, or set PathType to 'xpath' for //Tag syntax.";
                results.add(r);
                continue;
            }

            try {
                r.actualValue = Comparator.extractVariable(responseBody, a.path());
                evaluateOne(r, a);
            } catch (Comparator.ExtractionException ex) {
                r.actualValue = "";
                r.passed = false;
                r.message = ex.getMessage();
            }
            results.add(r);
        }
        return results;
    }

    private static void evaluateOne(AssertionResult r, Assertion a) {
        String op = a.operator() == null ? "" : a.operator().toLowerCase();
        String expected = a.expectedValue() == null ? "" : a.expectedValue();
        String actual = r.actualValue == null ? "" : r.actualValue;

        switch (op) {
            case "equals" -> {
                r.passed = actual.equals(expected);
                r.message = r.passed ? "" : "expected '" + expected + "', got '" + actual + "'";
            }
            case "not_equals" -> {
                r.passed = !actual.equals(expected);
                r.message = r.passed ? "" : "expected NOT '" + expected + "', got '" + actual + "'";
            }
            case "contains" -> {
                r.passed = actual.contains(expected);
                r.message = r.passed ? "" : "expected to contain '" + expected + "', got '" + actual + "'";
            }
            case "exists" -> {
                r.passed = !actual.isEmpty();
                r.message = r.passed ? "" : "path resolved to empty";
            }
            case "not_exists" -> {
                r.passed = actual.isEmpty();
                r.message = r.passed ? "" : "expected no value, got '" + actual + "'";
            }
            case "greater_than" -> {
                try {
                    double a1 = Double.parseDouble(actual);
                    double e1 = Double.parseDouble(expected);
                    r.passed = a1 > e1;
                    r.message = r.passed ? "" : a1 + " is not greater than " + e1;
                } catch (NumberFormatException ex) {
                    r.passed = false;
                    r.message = "non-numeric values";
                }
            }
            case "less_than" -> {
                try {
                    double a1 = Double.parseDouble(actual);
                    double e1 = Double.parseDouble(expected);
                    r.passed = a1 < e1;
                    r.message = r.passed ? "" : a1 + " is not less than " + e1;
                } catch (NumberFormatException ex) {
                    r.passed = false;
                    r.message = "non-numeric values";
                }
            }
            case "regex_match" -> {
                try {
                    r.passed = Pattern.compile(expected).matcher(actual).find();
                    r.message = r.passed ? "" : "'" + actual + "' does not match /" + expected + "/";
                } catch (Exception ex) {
                    r.passed = false;
                    r.message = "invalid regex: " + ex.getMessage();
                }
            }
            default -> {
                r.passed = false;
                r.message = "unknown operator: " + op;
            }
        }
    }
}
