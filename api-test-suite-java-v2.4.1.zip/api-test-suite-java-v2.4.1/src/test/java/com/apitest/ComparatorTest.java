package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ComparatorTest {

    @Test
    void identicalJsonMatches() {
        String a = "{\"name\":\"Alice\",\"age\":30}";
        String b = "{\"name\":\"Alice\",\"age\":30}";
        CompareResult r = Comparator.compare(a, b, List.of());
        assertTrue(r.matched);
        assertEquals(0, r.diffs.size());
    }

    @Test
    void jsonValueDiffDetected() {
        String a = "{\"name\":\"Alice\",\"age\":30}";
        String b = "{\"name\":\"Alice\",\"age\":31}";
        CompareResult r = Comparator.compare(a, b, List.of());
        assertFalse(r.matched);
        assertEquals(1, r.diffs.size());
        assertEquals("$.age", r.diffs.get(0).path);
    }

    @Test
    void identicalXmlMatches() {
        String a = "<root><name>Alice</name><age>30</age></root>";
        String b = "<root><name>Alice</name><age>30</age></root>";
        CompareResult r = Comparator.compare(a, b, List.of());
        assertTrue(r.matched);
    }

    @Test
    void xmlNamespacesIgnored() {
        String a = "<root><name>Alice</name></root>";
        String b = "<ns:root xmlns:ns=\"http://x\"><ns:name>Alice</ns:name></ns:root>";
        CompareResult r = Comparator.compare(a, b, List.of());
        assertTrue(r.matched, "Namespaces should be stripped before comparison");
    }

    @Test
    void crossFormatXmlVsJson() {
        // SOAP-ish XML vs equivalent REST JSON should compare structurally
        String xml = "<account><id>ACC-1</id><balance>100</balance></account>";
        String json = "{\"account\":{\"id\":\"ACC-1\",\"balance\":\"100\"}}";
        CompareResult r = Comparator.compare(xml, json, List.of());
        assertTrue(r.matched, "XML and JSON with same shape should match");
    }

    @Test
    void xpathIgnoreApplied() {
        String a = "<r><id>1</id><ts>2024-01-01</ts></r>";
        String b = "<r><id>1</id><ts>2024-02-02</ts></r>";
        List<Assertion> ignores = List.of(new Assertion("//ts", "xpath", "ignore", "", "ignore ts"));
        CompareResult r = Comparator.compare(a, b, ignores);
        assertTrue(r.matched, "ts field should be ignored");
    }

    @Test
    void jsonpathIgnoreApplied() {
        String a = "{\"id\":1,\"ts\":\"2024-01-01\"}";
        String b = "{\"id\":1,\"ts\":\"2024-02-02\"}";
        List<Assertion> ignores = List.of(new Assertion("$.ts", "jsonpath", "ignore", "", "ignore ts"));
        CompareResult r = Comparator.compare(a, b, ignores);
        assertTrue(r.matched);
    }

    @Test
    void extractJsonpathVariable() {
        String resp = "{\"order\":{\"id\":\"ORD-123\",\"status\":\"created\"}}";
        assertEquals("ORD-123", Comparator.extractVariable(resp, "$.order.id"));
        assertEquals("created", Comparator.extractVariable(resp, "$.order.status"));
    }

    @Test
    void extractXpathVariable() {
        String resp = "<r><id>X-9</id></r>";
        assertEquals("X-9", Comparator.extractVariable(resp, "//id"));
    }

    @Test
    void detectFormats() {
        assertEquals("json", Comparator.detectFormat("{\"a\":1}"));
        assertEquals("xml", Comparator.detectFormat("<r/>"));
        assertEquals("empty", Comparator.detectFormat(""));
        assertEquals("text", Comparator.detectFormat("hello"));
    }

    @org.junit.jupiter.api.Test
    void preparedPayloadsAreExposedForReportDisplay() {
        String expected = "<O><A>1</A></O>";
        String actual = "<S:Envelope xmlns:S=\"x\"><S:Body>"
                + "<r><![CDATA[<O><A>1</A></O>]]></r>"
                + "</S:Body></S:Envelope>";
        com.apitest.model.CompareResult r = com.apitest.comparator.Comparator
                .compare(expected, actual, java.util.List.of());
        org.junit.jupiter.api.Assertions.assertNotNull(r.preparedExpected,
                "preparedExpected should be populated");
        org.junit.jupiter.api.Assertions.assertNotNull(r.preparedActual,
                "preparedActual should be populated");
        // Actual was anchored on root element of expected after CDATA unwrap,
        // so the prepared actual should contain <O> directly
        org.junit.jupiter.api.Assertions.assertTrue(r.preparedActual.contains("<O>"),
                "preparedActual should contain unwrapped <O>: " + r.preparedActual);
    }
}
