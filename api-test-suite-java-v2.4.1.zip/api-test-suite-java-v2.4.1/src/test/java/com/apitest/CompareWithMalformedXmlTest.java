package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.Assertion;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Regression: the user's response had inner <?xml> declarations that worked
 * fine in extractVariable() but threw "XML parse failed: [xX][mM][lL]..."
 * in compare()/xmlToMap() because that path didn't go through the recovery
 * chain.
 */
class CompareWithMalformedXmlTest {

    @Test
    void compareXmlWithConcatenatedDocs() {
        String expected = "<?xml version=\"1.0\"?><Resp><id>X</id></Resp>";
        // Server sent two concatenated XML docs
        String actual = "<?xml version=\"1.0\"?><Resp><id>X</id></Resp>" +
                "<?xml version=\"1.0\"?><Junk/>";

        // The critical thing: compare must complete without throwing.
        // Whether the two are "matched" depends on which recovery layer kicked
        // in (truncate-at-root → match; wrap-in-fake-root → no match because
        // structures differ). Either way, no exception is thrown.
        CompareResult r = Comparator.compare(expected, actual, List.of());
        assertNotNull(r);
        assertFalse(r.note.contains("Parse error"),
                "Compare should not fail with parse error. Note was: " + r.note);
    }

    @Test
    void compareXmlWithInnerXmlPi() {
        String expected = "<Resp><id>X</id></Resp>";
        String actual = "<Resp><Wrapped><?xml version=\"1.0\"?><id>X</id></Wrapped></Resp>";
        // Inner xml PI should be stripped by recovery; structurally compatible
        CompareResult r = Comparator.compare(expected, actual, List.of());
        // We don't insist on matched here (the inner Wrapped element makes them
        // structurally different), but we DO require that parsing didn't fail
        assertFalse(r.note.contains("Parse error"),
                "Compare should not fail with parse error. Note was: " + r.note);
    }

    @Test
    void xpathIgnoreSurvivesMalformedXml() {
        // Inner <?xml in both — ignore directive must not throw, and the
        // ignored fields must be normalized.
        String a = "<Resp><Wrapped><?xml version=\"1.0\"?><id>1</id><ts>2024</ts></Wrapped></Resp>";
        String b = "<Resp><Wrapped><?xml version=\"1.0\"?><id>1</id><ts>2025</ts></Wrapped></Resp>";

        List<Assertion> ignores = List.of(
                new Assertion("//ts", "xpath", "ignore", "", "varies")
        );
        CompareResult r = Comparator.compare(a, b, ignores);
        assertTrue(r.matched, "Should match after ignore. Diffs: " + r.diffs.size());
    }
}
