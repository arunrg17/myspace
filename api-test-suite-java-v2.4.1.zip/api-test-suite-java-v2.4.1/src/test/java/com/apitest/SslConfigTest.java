package com.apitest;

import com.apitest.dispatcher.SslConfig;
import org.junit.jupiter.api.Test;

import javax.net.ssl.SSLContext;

import static org.junit.jupiter.api.Assertions.*;

class SslConfigTest {

    @Test
    void emptyConfigReturnsNull() {
        assertNull(SslConfig.buildContext(""));
        assertNull(SslConfig.buildContext(null));
        assertNull(SslConfig.buildContext("   "));
    }

    @Test
    void verifyFalseEnablesTrustAll() {
        SSLContext ctx = SslConfig.buildContext("verify=false");
        assertNotNull(ctx);
        assertEquals("TLS", ctx.getProtocol());
        assertTrue(SslConfig.isVerifyDisabled("verify=false"));
        assertTrue(SslConfig.isVerifyDisabled("verify=no"));
        assertFalse(SslConfig.isVerifyDisabled("verify=true"));
        assertFalse(SslConfig.isVerifyDisabled(""));
    }

    @Test
    void missingFileThrowsClearError() {
        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> SslConfig.buildContext("trust_store=/no/such/file.jks; trust_password=x"));
        assertTrue(ex.getMessage().contains("SSL config failed"),
                "Error should be clearly attributed to SSL config: " + ex.getMessage());
    }

    @Test
    void caches() {
        SSLContext a = SslConfig.buildContext("verify=false");
        SSLContext b = SslConfig.buildContext("verify=false");
        assertSame(a, b, "Same config string should return cached context");
    }

    private String resolveSecret(String input) throws Exception {
        java.lang.reflect.Method m = SslConfig.class.getDeclaredMethod("resolveSecret", String.class);
        m.setAccessible(true);
        return (String) m.invoke(null, input);
    }

    @Test
    void resolveSecretLiteral() throws Exception {
        assertEquals("plain", resolveSecret("plain"));
        assertEquals("", resolveSecret(null));
        assertEquals("", resolveSecret(""));
    }

    @Test
    void resolveSecretEnvVar() throws Exception {
        String result = resolveSecret("${env.PATH}");
        assertFalse(result.isEmpty(), "Should resolve PATH env var");
    }

    @Test
    void resolveSecretFromFile() throws Exception {
        java.nio.file.Path tmp = java.nio.file.Files.createTempFile("ssl-test", ".properties");
        java.nio.file.Files.writeString(tmp, "my_key_pass=secret123\ntrust_pass=changeit\n");
        try {
            assertEquals("secret123",
                    resolveSecret("${file." + tmp.toAbsolutePath() + ":my_key_pass}"));
            assertEquals("changeit",
                    resolveSecret("${file." + tmp.toAbsolutePath() + ":trust_pass}"));
            assertEquals("",
                    resolveSecret("${file." + tmp.toAbsolutePath() + ":nonexistent}"));
        } finally {
            java.nio.file.Files.deleteIfExists(tmp);
        }
    }

    @Test
    void resolveSecretFromMissingFileReturnsEmpty() throws Exception {
        assertEquals("",
                resolveSecret("${file./no/such/file.properties:key}"));
    }
}
