package com.apitest;

import com.apitest.template.TemplateEngine;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class TemplateEngineTest {

    @Test
    void substitutesSimplePlaceholder() {
        Map<String, String> data = new HashMap<>();
        data.put("name", "Alice");
        String out = TemplateEngine.render("Hello ${name}!", data, new LinkedHashMap<>());
        assertEquals("Hello Alice!", out);
    }

    @Test
    void substitutesMultiplePlaceholders() {
        Map<String, String> data = new HashMap<>();
        data.put("customer_id", "C-1");
        data.put("amount", "100");
        String out = TemplateEngine.render("<o><c>${customer_id}</c><a>${amount}</a></o>",
                data, new LinkedHashMap<>());
        assertEquals("<o><c>C-1</c><a>100</a></o>", out);
    }

    @Test
    void missingPlaceholderRendersEmpty() {
        String out = TemplateEngine.render("Hello ${missing}!", new HashMap<>(), new LinkedHashMap<>());
        assertEquals("Hello !", out);
    }

    @Test
    void renderStepVariables() {
        Map<Integer, Map<String, String>> stepVars = new LinkedHashMap<>();
        Map<String, String> v1 = new HashMap<>();
        v1.put("order_id", "ORD-42");
        stepVars.put(1, v1);

        String out = TemplateEngine.render("/orders/${step1.order_id}/update", new HashMap<>(), stepVars);
        assertEquals("/orders/ORD-42/update", out);
    }

    @Test
    void renderNowProducesIsoTimestamp() {
        String out = TemplateEngine.render("ts=${now}", new HashMap<>(), new LinkedHashMap<>());
        assertTrue(out.startsWith("ts="));
        assertTrue(out.contains("T"), "Should contain ISO-8601 'T' separator");
        assertTrue(out.endsWith("Z"), "Should be UTC");
    }

    @Test
    void renderUuidProducesUuid() {
        String out = TemplateEngine.render("id=${uuid}", new HashMap<>(), new LinkedHashMap<>());
        String uuid = out.substring(3);
        assertEquals(36, uuid.length());
        assertTrue(uuid.matches("[0-9a-f-]+"));
    }

    @Test
    void renderEnvVariable() {
        // PATH is virtually always set
        String out = TemplateEngine.render("p=${env.PATH}", new HashMap<>(), new LinkedHashMap<>());
        assertTrue(out.startsWith("p="));
        assertTrue(out.length() > 3, "PATH should not be empty");
    }

    @Test
    void specialCharsInValueDoNotBreakRegex() {
        // Replacement strings with $ and \ are tricky in Java regex
        Map<String, String> data = new HashMap<>();
        data.put("v", "$1 \\ backslash");
        String out = TemplateEngine.render("[${v}]", data, new LinkedHashMap<>());
        assertEquals("[$1 \\ backslash]", out);
    }

    @Test
    void nullTemplateReturnsEmpty() {
        assertEquals("", TemplateEngine.render(null, new HashMap<>(), new LinkedHashMap<>()));
    }
}
