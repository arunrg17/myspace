package com.apitest;

import com.apitest.comparator.Comparator;
import com.apitest.model.CompareResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Verifies that compare() unwraps CDATA-wrapped business XML so that
 * comparison against a clean expected file produces meaningful results.
 *
 * Without this, a response of the form
 *    &lt;arg0&gt;&lt;![CDATA[&lt;Order&gt;...&lt;/Order&gt;]]&gt;&lt;/arg0&gt;
 * would diff to the entire response treated as a text blob, which is
 * useless for structural comparison.
 */
class CdataAwareComparisonTest {

    @Test
    void cdataWrappedActualComparedToCleanExpected() {
        String expected = "<Order><Id>X100</Id><Status>NEW</Status></Order>";
        String actual = "<Envelope><Body>"
                + "<arg0><![CDATA[<Order><Id>X100</Id><Status>NEW</Status></Order>]]></arg0>"
                + "</Body></Envelope>";

        CompareResult cr = Comparator.compare(expected, actual, List.of());
        assertTrue(cr.matched, "Expected match. Diffs: " + cr.diffs);
    }

    @Test
    void cdataWrappedDifferingPayloadProducesMeaningfulDiff() {
        String expected = "<Order><Id>X100</Id><Status>NEW</Status></Order>";
        String actual = "<Envelope><Body>"
                + "<arg0><![CDATA[<Order><Id>X999</Id><Status>FILLED</Status></Order>]]></arg0>"
                + "</Body></Envelope>";

        CompareResult cr = Comparator.compare(expected, actual, List.of());
        assertFalse(cr.matched);
        // Should have diffs at the actual fields, not at the wrapper
        assertFalse(cr.diffs.isEmpty(), "Should have detected diffs");
    }

    @Test
    void doubleEscapedThenCdataWrappedIsAlsoUnwrapped() {
        // Real-world SOAP-in-SOAP: outer return has escaped XML, inner has CDATA.
        // The point of this test is that the CDATA's inner XML elements become
        // visible to comparison (rather than appearing as a single text blob).
        String response = "<S:Envelope><S:Body><executeResponse>"
                + "<return>&lt;Envelope&gt;&lt;Content&gt;"
                + "&lt;![CDATA[&lt;Order&gt;&lt;Id&gt;X100&lt;/Id&gt;&lt;/Order&gt;]]&gt;"
                + "&lt;/Content&gt;&lt;/Envelope&gt;</return>"
                + "</executeResponse></S:Body></S:Envelope>";
        String unwrapped = Comparator.extractInnerPayload(response);
        // After unwrap, the inner <Order><Id>X100</Id></Order> should be visible
        // as real XML elements in the unwrapped string
        assertTrue(unwrapped.contains("<Order>"), "Order tag visible: " + unwrapped);
        assertTrue(unwrapped.contains("<Id>X100</Id>"), "Id visible: " + unwrapped);
        assertFalse(unwrapped.contains("&lt;Order&gt;"), "Should be unescaped: " + unwrapped);
        assertFalse(unwrapped.contains("<![CDATA["), "CDATA unwrapped: " + unwrapped);
    }

    @Test
    void plainTextCdataLeftAlone() {
        // CDATA containing plain text (not XML) shouldn't be unwrapped
        String unwrapped = Comparator.extractInnerPayload(
                "<Note><![CDATA[Hello, world!]]></Note>");
        // CDATA with non-XML text stays wrapped (or at minimum the text is preserved)
        assertTrue(unwrapped.contains("Hello, world!"));
    }

    @Test
    void noCdataNoChange() {
        String input = "<plain><tag>value</tag></plain>";
        assertEquals(input, Comparator.extractInnerPayload(input));
    }

    @Test
    void emptyInputHandled() {
        assertEquals("", Comparator.extractInnerPayload(""));
        assertNull(Comparator.extractInnerPayload(null));
    }
}
