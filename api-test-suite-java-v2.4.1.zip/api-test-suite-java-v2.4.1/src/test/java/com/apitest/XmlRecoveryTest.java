package com.apitest;

import com.apitest.comparator.Comparator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for severely malformed XML responses that need recovery strategies
 * beyond simple prolog sanitization.
 */
class XmlRecoveryTest {

    @Test
    void multipleInnerXmlPisRecovered() {
        // Server emits inner <?xml multiple times — unparseable as-is
        String response =
            "<?xml version=\"1.0\"?>" +
            "<Resp>" +
            "  <wrap1><?xml version=\"1.0\"?><data>found1</data></wrap1>" +
            "  <wrap2><?xml version=\"1.0\"?><data>found2</data></wrap2>" +
            "</Resp>";
        assertEquals("found1", Comparator.extractVariable(response, "//data"));
    }

    @Test
    void uppercaseInnerXmlPisStripped() {
        // Case-insensitive PI target match
        String response = "<?xml version=\"1.0\"?><r><a>x</a><?XML stuff?><b>y</b></r>";
        assertEquals("x", Comparator.extractVariable(response, "//a"));
        assertEquals("y", Comparator.extractVariable(response, "//b"));
    }

    @Test
    void severelyMalformedXmlFallsBackToRegex() {
        // Something so broken it can't even be repaired by stripping PIs.
        // Multiple roots, no enclosing element — but we can still find tags.
        String response =
            "<a>one</a>" +
            "<b>two</b>" +
            "<?xml version=\"1.0\"?><c>three</c>";
        // After wrapping in __root__, this WILL parse — so DOM extraction works
        assertEquals("one", Comparator.extractVariable(response, "//a"));
        assertEquals("two", Comparator.extractVariable(response, "//b"));
        assertEquals("three", Comparator.extractVariable(response, "//c"));
    }

    @Test
    void siblingByIdLookupWorksInWrappedDocument() {
        // After wrapping fallback fires, the sibling lookup still works
        String response =
            "<securityItem><Security><id>abc111</id><cost>100</cost></Security></securityItem>" +
            "<?xml version=\"1.0\"?>" +
            "<securityItem><Security><id>abc123</id><cost>249.95</cost></Security></securityItem>";
        assertEquals("249.95",
                Comparator.extractVariable(response, "//securityItem/Security[id='abc123']/cost"));
    }

    @Test
    void regexFallbackHandlesSimpleSiblingLookup() {
        // Strongly malformed XML — wrapping fallback handles this fine now,
        // but we want to verify the pattern works end-to-end.
        String response =
            "<wrap>some prefix" +
            "<securityItem><Security>" +
            "<id>abc123</id><cost>249.95</cost>" +
            "</Security></securityItem>" +
            "</wrap>";  // properly closed
        String result = Comparator.extractVariable(response,
                "//Security[id='abc123']/cost");
        assertEquals("249.95", result);
    }

    @Test
    void cleanXmlStillWorks() {
        // Regression: make sure clean responses go through the fast path
        String response = "<?xml version=\"1.0\"?><r><name>Alice</name><age>30</age></r>";
        assertEquals("Alice", Comparator.extractVariable(response, "//name"));
        assertEquals("30", Comparator.extractVariable(response, "//age"));
    }

    @Test
    void totallyBrokenInputReturnsEmptyOrThrows() {
        // Non-XML input — detectFormat won't even classify it as XML, so
        // extraction returns empty without going through the XML path.
        String response = "this is just plain text, not xml";
        String result = Comparator.extractVariable(response, "//notATag");
        assertEquals("", result, "Non-XML returns empty cleanly without error");
    }
}
