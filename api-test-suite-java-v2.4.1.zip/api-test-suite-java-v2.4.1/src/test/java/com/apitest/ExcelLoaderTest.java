package com.apitest;

import com.apitest.excel.ExcelLoader;
import com.apitest.excel.TemplateGenerator;
import com.apitest.model.TestCase;
import com.apitest.model.TestSuite;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class ExcelLoaderTest {

    @Test
    void generateAndLoadRoundTrip(@TempDir Path tmp) throws Exception {
        Path xlsx = tmp.resolve("test_suite.xlsx");
        TemplateGenerator.generate(xlsx);
        assertTrue(java.nio.file.Files.exists(xlsx));

        TestSuite suite = ExcelLoader.load(xlsx);

        // Environments
        assertTrue(suite.environments().containsKey("DEV_REST"));
        assertTrue(suite.environments().containsKey("DEV_SOAP"));
        assertEquals("rest", suite.environments().get("DEV_REST").protocol());

        // Tests — Enabled=Y rows only (T005 is disabled)
        assertTrue(suite.tests().size() >= 5);
        TestCase t002 = suite.tests().stream()
                .filter(t -> "T002".equals(t.testId))
                .findFirst().orElseThrow();
        assertEquals("vs_expected", t002.comparisonMode);
        assertEquals(1, t002.steps.size());

        // Chain test has 3 steps
        TestCase t004 = suite.tests().stream()
                .filter(t -> "T004".equals(t.testId))
                .findFirst().orElseThrow();
        assertEquals(3, t004.steps.size());
        assertEquals(1, t004.steps.get(0).order());
        assertEquals(3, t004.steps.get(2).order());

        // T006 has field-level assertions
        TestCase t006 = suite.tests().stream()
                .filter(t -> "T006".equals(t.testId))
                .findFirst().orElseThrow();
        assertTrue(t006.assertions.size() >= 5,
                "T006 should have its own assertions plus the global '*' ignores");

        // Global * assertions are applied to all tests
        boolean t002HasGlobalIgnore = t002.assertions.stream()
                .anyMatch(a -> "ignore".equals(a.operator()) && a.path().contains("traceId"));
        assertTrue(t002HasGlobalIgnore, "Global * ignores should propagate to T002");

        // T005 (Enabled=N) should be skipped
        boolean t005Present = suite.tests().stream().anyMatch(t -> "T005".equals(t.testId));
        assertFalse(t005Present, "Disabled tests should not be loaded");
    }
}
