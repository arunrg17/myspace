package com.apitest;

import com.apitest.comparator.AssertionEngine;
import com.apitest.model.Assertion;
import com.apitest.model.AssertionResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AssertionEngineTest {

    private static final String JSON_RESP =
            "{\"order\":{\"id\":\"ORD-1\",\"status\":\"created\",\"region\":\"EMEA\"}," +
            "\"total\":249.95,\"items\":3}";

    private static AssertionResult run(String path, String pathType, String op, String val) {
        Assertion a = new Assertion(path, pathType, op, val, "");
        List<AssertionResult> results = AssertionEngine.evaluate(JSON_RESP, List.of(a));
        assertEquals(1, results.size());
        return results.get(0);
    }

    @Test
    void equalsPasses() {
        AssertionResult r = run("$.order.status", "jsonpath", "equals", "created");
        assertTrue(r.passed, r.message);
    }

    @Test
    void equalsFails() {
        AssertionResult r = run("$.order.status", "jsonpath", "equals", "shipped");
        assertFalse(r.passed);
        assertTrue(r.message.contains("shipped"));
    }

    @Test
    void notEqualsPasses() {
        AssertionResult r = run("$.order.status", "jsonpath", "not_equals", "shipped");
        assertTrue(r.passed);
    }

    @Test
    void containsPasses() {
        AssertionResult r = run("$.order.id", "jsonpath", "contains", "ORD");
        assertTrue(r.passed);
    }

    @Test
    void existsPasses() {
        AssertionResult r = run("$.order.id", "jsonpath", "exists", "");
        assertTrue(r.passed);
    }

    @Test
    void existsFailsOnMissing() {
        AssertionResult r = run("$.order.missing", "jsonpath", "exists", "");
        assertFalse(r.passed);
    }

    @Test
    void notExistsPasses() {
        AssertionResult r = run("$.order.missing", "jsonpath", "not_exists", "");
        assertTrue(r.passed);
    }

    @Test
    void greaterThanPasses() {
        AssertionResult r = run("$.total", "jsonpath", "greater_than", "100");
        assertTrue(r.passed);
    }

    @Test
    void greaterThanFails() {
        AssertionResult r = run("$.total", "jsonpath", "greater_than", "1000");
        assertFalse(r.passed);
    }

    @Test
    void lessThanPasses() {
        AssertionResult r = run("$.items", "jsonpath", "less_than", "10");
        assertTrue(r.passed);
    }

    @Test
    void regexMatchPasses() {
        AssertionResult r = run("$.order.region", "jsonpath", "regex_match", "^(EMEA|AMER)$");
        assertTrue(r.passed);
    }

    @Test
    void regexMatchFails() {
        AssertionResult r = run("$.order.region", "jsonpath", "regex_match", "^APAC$");
        assertFalse(r.passed);
    }

    @Test
    void ignoreOperatorIsSkipped() {
        Assertion ignore = new Assertion("$.x", "jsonpath", "ignore", "", "");
        List<AssertionResult> results = AssertionEngine.evaluate(JSON_RESP, List.of(ignore));
        assertEquals(0, results.size(), "ignore operator should be filtered out");
    }

    @Test
    void unknownOperatorFails() {
        AssertionResult r = run("$.total", "jsonpath", "wat", "");
        assertFalse(r.passed);
        assertTrue(r.message.contains("unknown operator"));
    }

    @Test
    void xpathAssertionAgainstXml() {
        String xml = "<r><status>active</status></r>";
        Assertion a = new Assertion("//status", "xpath", "equals", "active", "");
        List<AssertionResult> results = AssertionEngine.evaluate(xml, List.of(a));
        assertTrue(results.get(0).passed);
    }
}
