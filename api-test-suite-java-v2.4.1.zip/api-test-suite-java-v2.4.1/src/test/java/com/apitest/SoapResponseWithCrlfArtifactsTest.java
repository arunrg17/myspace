package com.apitest;

import com.apitest.comparator.Comparator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Reproduces the exact SOAP response shape from the user's screenshot:
 *   - <?xml ... ?> prolog with single quotes
 *   - <S:Envelope> wrapping a business <Envelope> with the same local name
 *   - Literal &#xd; entity refs after every closing tag
 *   - CostItem entries that need predicate-based lookup
 *
 * Also verifies that stderr noise from Xerces doesn't pollute the console.
 */
class SoapResponseWithCrlfArtifactsTest {

    private static final String RESPONSE =
            "<?xml version='1.0' encoding='UTF-8'?>"
            + "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">"
            + "<S:Body>"
            + "<Envelope>&#xd;\n"
            + "  <Version>354</Version>&#xd;\n"
            + "  <Sender>&#xd;\n"
            + "    <ApplicationId>ClientApp</ApplicationId>&#xd;\n"
            + "  </Sender>&#xd;\n"
            + "  <Receiver>&#xd;\n"
            + "    <ApplicationId>BackendService</ApplicationId>&#xd;\n"
            + "  </Receiver>&#xd;\n"
            + "  <Content>&#xd;\n"
            + "    <CostItem>&#xd;\n"
            + "      <Security>&#xd;\n"
            + "        <Id>AAA123</Id>&#xd;\n"
            + "        <Name>Security One</Name>&#xd;\n"
            + "      </Security>&#xd;\n"
            + "      <Cost>249.95</Cost>&#xd;\n"
            + "      <Currency>EUR</Currency>&#xd;\n"
            + "    </CostItem>&#xd;\n"
            + "    <CostItem>&#xd;\n"
            + "      <Security>&#xd;\n"
            + "        <Id>BBB456</Id>&#xd;\n"
            + "        <Name>Security Two</Name>&#xd;\n"
            + "      </Security>&#xd;\n"
            + "      <Cost>500.00</Cost>&#xd;\n"
            + "      <Currency>USD</Currency>&#xd;\n"
            + "    </CostItem>&#xd;\n"
            + "    <CostItem>&#xd;\n"
            + "      <Security>&#xd;\n"
            + "        <Id>CCC789</Id>&#xd;\n"
            + "        <Name>Security Three</Name>&#xd;\n"
            + "      </Security>&#xd;\n"
            + "      <Cost>123.45</Cost>&#xd;\n"
            + "      <Currency>GBP</Currency>&#xd;\n"
            + "    </CostItem>&#xd;\n"
            + "  </Content>&#xd;\n"
            + "</Envelope>&#xd;\n"
            + "</S:Body></S:Envelope>";

    @Test
    void findCostItemByNestedId() {
        // The user's exact XPath
        String cost = Comparator.extractVariable(RESPONSE,
                "//CostItem[Security/Id='AAA123']/Cost");
        assertEquals("249.95", cost);
    }

    @Test
    void findSiblingCurrency() {
        String currency = Comparator.extractVariable(RESPONSE,
                "//CostItem[Security/Id='BBB456']/Currency");
        assertEquals("USD", currency);
    }

    @Test
    void findNestedSecurityName() {
        String name = Comparator.extractVariable(RESPONSE,
                "//CostItem[Security/Id='CCC789']/Security/Name");
        assertEquals("Security Three", name);
    }

    @Test
    void noMatchReturnsEmpty() {
        String missing = Comparator.extractVariable(RESPONSE,
                "//CostItem[Security/Id='ZZZ999']/Cost");
        assertEquals("", missing);
    }

    @Test
    void parseDoesNotWriteToStderr() throws Exception {
        // Capture stderr around an extraction with deliberately tricky XML
        java.io.ByteArrayOutputStream errBuf = new java.io.ByteArrayOutputStream();
        java.io.PrintStream original = System.err;
        try {
            System.setErr(new java.io.PrintStream(errBuf));
            // Force a malformation that would normally produce [Fatal Error] on stderr
            String malformed = "<?xml version=\"1.0\"?><r><a>1</a></r>"
                    + "<?xml version=\"1.0\"?><b>2</b>";
            Comparator.extractVariable(malformed, "//a");
        } finally {
            System.setErr(original);
        }
        String stderr = errBuf.toString();
        assertFalse(stderr.contains("[Fatal Error]"),
                "Xerces should not write to stderr during parse recovery. Got: " + stderr);
    }

    @Test
    void noVisibleCrlfArtifactsInExtractedValues() {
        // The extracted value should not contain literal "&#xd;" text
        String version = Comparator.extractVariable(RESPONSE, "//Version");
        assertEquals("354", version);
        assertFalse(version.contains("&#xd"));
        assertFalse(version.contains("\r"));
    }
}
