package com.apitest;

import com.apitest.model.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Regression test: in vs_env / vs_protocol mode, if source B's step failed
 * (e.g. socket exception), the test must report FAIL — not PASS.
 *
 * The original bug: the final "default to PASS unless ERROR" block was
 * overwriting the FAIL that the vs_env branch had explicitly set, because
 * it only checked for ERROR.
 *
 * This test exercises the status-deciding logic directly by simulating
 * the state the runner reaches just before the final block.
 */
class StatusOverrideRegressionTest {

    /**
     * Apply the same final-status logic the Runner uses. Kept in sync with
     * Runner.runTest's final block — when that block changes, update here.
     */
    private static String applyFinalStatus(TestResult r) {
        if (!"ERROR".equals(r.status) && !"FAIL".equals(r.status)) {
            boolean assertionsPassed = r.assertionResults.stream().allMatch(a -> a.passed);
            boolean compareMatched = r.compareResult == null || r.compareResult.matched;
            r.status = (assertionsPassed && compareMatched) ? "PASS" : "FAIL";
        }
        return r.status;
    }

    @Test
    void vsEnv_sourceBStepFails_finalStatusStaysFail() {
        // Simulate: A succeeded, B failed (socket exception), so the vs_env
        // branch explicitly set status to FAIL. The final block must NOT
        // overwrite that.
        TestResult r = new TestResult();
        r.status = "FAIL";
        r.error = "One or more steps in source B failed";

        // A's assertions all passed (no assertions in this scenario)
        // compareResult is null because we never reached comparison
        // The bug would have these properties cause final block to set PASS.
        assertEquals("FAIL", applyFinalStatus(r),
                "FAIL set by vs_env branch must not be overwritten by final block");
    }

    @Test
    void vsEnv_sourceBOk_assertionFail_finalStatusIsFail() {
        // A and B both ran, but one assertion failed. No explicit status
        // was set by the switch. Final block computes FAIL.
        TestResult r = new TestResult();
        // status defaults to PASS from the model
        AssertionResult ar = new AssertionResult();
        ar.passed = false;
        r.assertionResults.add(ar);
        r.compareResult = new CompareResult();
        r.compareResult.matched = true;
        assertEquals("FAIL", applyFinalStatus(r));
    }

    @Test
    void vsEnv_allOk_finalStatusIsPass() {
        // Happy path: A and B succeeded, comparison matched, no assertions.
        TestResult r = new TestResult();
        r.compareResult = new CompareResult();
        r.compareResult.matched = true;
        assertEquals("PASS", applyFinalStatus(r));
    }

    @Test
    void error_neverOverwritten() {
        // ERROR set earlier (e.g. missing expected file) must stay as ERROR.
        TestResult r = new TestResult();
        r.status = "ERROR";
        r.error = "Expected file not found";
        assertEquals("ERROR", applyFinalStatus(r));
    }

    @Test
    void compareMismatch_finalStatusIsFail() {
        // Comparison ran but did not match. Final block should set FAIL.
        TestResult r = new TestResult();
        r.compareResult = new CompareResult();
        r.compareResult.matched = false;
        DiffEntry d = new DiffEntry("$.X", "1", "2", "value");
        r.compareResult.diffs.add(d);
        assertEquals("FAIL", applyFinalStatus(r));
    }
}
