package com.apitest;

import com.apitest.comparator.Comparator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests addressing specific children inside repeated parent elements,
 * matching the user's Employee XML structure exactly.
 */
class RepeatedParentExtractionTest {

    private static final String EMPLOYEES = """
            <?xml version="1.0" encoding="UTF-8"?>
            <Employees>
                <Employee>
                    <EmployeeId>1001</EmployeeId>
                    <FirstName>Alice</FirstName>
                    <LastName>Kumar</LastName>
                    <Department>QA</Department>
                    <Address>
                        <Street>Main Street 12</Street>
                        <City>Frankfurt</City>
                        <PostalCode>65760</PostalCode>
                        <Country>Germany</Country>
                    </Address>
                    <Projects>
                        <Project>
                            <ProjectId>P101</ProjectId>
                            <ProjectName>Payments API</ProjectName>
                            <Status>Active</Status>
                        </Project>
                        <Project>
                            <ProjectId>P102</ProjectId>
                            <ProjectName>Loan Processing</ProjectName>
                            <Status>Completed</Status>
                        </Project>
                    </Projects>
                </Employee>
                <Employee>
                    <EmployeeId>1002</EmployeeId>
                    <FirstName>Rahul</FirstName>
                    <LastName>Sharma</LastName>
                    <Department>Development</Department>
                    <Address>
                        <Street>River Road 45</Street>
                        <City>Berlin</City>
                        <PostalCode>10115</PostalCode>
                        <Country>Germany</Country>
                    </Address>
                    <Projects>
                        <Project>
                            <ProjectId>P201</ProjectId>
                            <ProjectName>Customer Portal</ProjectName>
                            <Status>Active</Status>
                        </Project>
                        <Project>
                            <ProjectId>P202</ProjectId>
                            <ProjectName>Authentication Service</ProjectName>
                            <Status>InProgress</Status>
                        </Project>
                    </Projects>
                </Employee>
                <Employee>
                    <EmployeeId>1003</EmployeeId>
                    <FirstName>Sneha</FirstName>
                    <LastName>Reddy</LastName>
                    <Department>Operations</Department>
                    <Address>
                        <Street>Lake View 9</Street>
                        <City>Munich</City>
                        <PostalCode>80331</PostalCode>
                        <Country>Germany</Country>
                    </Address>
                    <Projects>
                        <Project>
                            <ProjectId>P301</ProjectId>
                            <ProjectName>Reporting Engine</ProjectName>
                            <Status>Completed</Status>
                        </Project>
                        <Project>
                            <ProjectId>P302</ProjectId>
                            <ProjectName>Data Migration</ProjectName>
                            <Status>Active</Status>
                        </Project>
                    </Projects>
                </Employee>
            </Employees>
            """;

    // ─── Predicate-based: find a SPECIFIC employee, then drill in ──────────────

    @Test
    void selectEmployeeByIdThenChildField() {
        // Find Rahul's city using EmployeeId predicate
        assertEquals("Berlin",
                Comparator.extractVariable(EMPLOYEES, "//Employee[EmployeeId='1002']/Address/City"));
        // Find Sneha's department
        assertEquals("Operations",
                Comparator.extractVariable(EMPLOYEES, "//Employee[EmployeeId='1003']/Department"));
        // Find Alice's first project name
        assertEquals("Payments API",
                Comparator.extractVariable(EMPLOYEES, "//Employee[EmployeeId='1001']/Projects/Project[1]/ProjectName"));
    }

    @Test
    void selectByFirstNamePredicate() {
        // Find Rahul's postal code by first name
        assertEquals("10115",
                Comparator.extractVariable(EMPLOYEES, "//Employee[FirstName='Rahul']/Address/PostalCode"));
    }

    @Test
    void selectSpecificProjectByProjectId() {
        // Find the status of project P202 specifically
        assertEquals("InProgress",
                Comparator.extractVariable(EMPLOYEES, "//Project[ProjectId='P202']/Status"));
        // Find the project name for P301
        assertEquals("Reporting Engine",
                Comparator.extractVariable(EMPLOYEES, "//Project[ProjectId='P301']/ProjectName"));
    }

    @Test
    void positionalIndexInRepeatedElements() {
        // Get the 2nd employee's first name (1-indexed in XPath)
        assertEquals("Rahul",
                Comparator.extractVariable(EMPLOYEES, "//Employee[2]/FirstName"));
        // Get the last employee's department
        assertEquals("Operations",
                Comparator.extractVariable(EMPLOYEES, "//Employee[last()]/Department"));
        // Combined: the 2nd project of the 1st employee
        assertEquals("Loan Processing",
                Comparator.extractVariable(EMPLOYEES, "//Employee[1]/Projects/Project[2]/ProjectName"));
    }

    // ─── Without a predicate: //X returns the FIRST match — useful when there is only one ───

    @Test
    void plainPathReturnsFirstMatch() {
        // //City returns Frankfurt (first match, Alice's city)
        assertEquals("Frankfurt", Comparator.extractVariable(EMPLOYEES, "//City"));
        // //ProjectId returns P101 (first project in document)
        assertEquals("P101", Comparator.extractVariable(EMPLOYEES, "//ProjectId"));
    }

    // ─── Carriage-return normalization in extracted values ─────────────────────

    @Test
    void extractedValueIsNotCorruptedByCarriageReturns() {
        String xmlWithCrlf = "<?xml version=\"1.0\"?>\r\n<r>\r\n  <name>Alice</name>\r\n</r>\r\n";
        assertEquals("Alice", Comparator.extractVariable(xmlWithCrlf, "//name"));
    }
}
