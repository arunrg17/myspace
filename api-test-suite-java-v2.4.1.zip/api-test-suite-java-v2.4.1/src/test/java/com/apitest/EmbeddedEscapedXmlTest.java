package com.apitest;

import com.apitest.comparator.Comparator;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Servers sometimes wrap escaped XML inside a string element (common SOAP pattern).
 * The framework must decode it transparently so XPath extraction works against
 * the inner elements directly.
 */
class EmbeddedEscapedXmlTest {

    @Test
    void extractFromEscapedXmlInsideEnvelope() {
        // Outer XML contains the inner XML as HTML-escaped text — exactly the
        // pattern shown in the user's response screenshot.
        String response = """
                <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                  <soap:Body>
                    <Response>
                      <Payload>&lt;Order&gt;&lt;Id&gt;AAA123&lt;/Id&gt;&lt;Type&gt;AnnualFee&lt;/Type&gt;&lt;Amount&gt;0.00000&lt;/Amount&gt;&lt;Date&gt;20240101&lt;/Date&gt;&lt;/Order&gt;</Payload>
                    </Response>
                  </soap:Body>
                </soap:Envelope>
                """;

        assertEquals("AAA123",       Comparator.extractVariable(response, "//Id"));
        assertEquals("AnnualFee", Comparator.extractVariable(response, "//Type"));
        assertEquals("0.00000",      Comparator.extractVariable(response, "//Amount"));
        assertEquals("20240101",     Comparator.extractVariable(response, "//Date"));
    }

    @Test
    void plainXmlStillWorks() {
        // Make sure the decoder doesn't break ordinary XML payloads.
        String response = "<r><name>Alice</name><id>42</id></r>";
        assertEquals("Alice", Comparator.extractVariable(response, "//name"));
        assertEquals("42",    Comparator.extractVariable(response, "//id"));
    }

    @Test
    void payloadWithSingleEscapedCharIsLeftAlone() {
        // Stray escaped chars (e.g. an ampersand encoded as text) shouldn't
        // trigger decoding. Need ≥3 escaped tag pairs.
        String response = "<r><note>price &lt; 100</note></r>";
        assertEquals("price < 100", Comparator.extractVariable(response, "//note"));
    }

    @Test
    void deeplyNestedEscapedStructure() {
        String response = """
                <root>
                  <data>&lt;parent&gt;&lt;child&gt;&lt;grandchild&gt;found&lt;/grandchild&gt;&lt;/child&gt;&lt;/parent&gt;</data>
                </root>
                """;
        assertEquals("found", Comparator.extractVariable(response, "//grandchild"));
    }
}
