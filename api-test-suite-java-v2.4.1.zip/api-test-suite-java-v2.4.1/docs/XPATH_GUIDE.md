# Writing Assertions for Repeated XML Elements

When your response has many elements with the same name — multiple employees,
multiple line items, multiple projects — a plain XPath like `//City` returns
the **first one in the document**, which is rarely what you actually want.

This guide shows you how to write assertions that target the right element,
using **XPath predicates**.

---

## The problem in one example

Given this response:

```xml
<Employees>
  <Employee>
    <EmployeeId>1001</EmployeeId>
    <FirstName>Alice</FirstName>
    <Address><City>Frankfurt</City></Address>
  </Employee>
  <Employee>
    <EmployeeId>1002</EmployeeId>
    <FirstName>Rahul</FirstName>
    <Address><City>Berlin</City></Address>
  </Employee>
</Employees>
```

This assertion will **always pass** even when checking Rahul:

| Path | Expected | What you actually get |
|---|---|---|
| `//City` | `Berlin` | Frankfurt — **wrong**, it's Alice's city |

You need **predicates** — the `[...]` brackets in XPath — to identify which
parent you want.

---

## The four common patterns

### Pattern 1: Find by a child element's value

> "Find the city of the employee whose ID is 1002"

```
//Employee[EmployeeId='1002']/Address/City
```

Translation: among all `<Employee>` elements, pick the one with a child
`<EmployeeId>` equal to `1002`, then navigate to its `Address/City`.

Use this when you have a unique identifier (ID, name, code, status, etc).

### Pattern 2: Find by position

> "Get the 2nd employee's first name"

```
//Employee[2]/FirstName
```

XPath positions are **1-indexed**, not 0-indexed. `[1]` is the first.

> "Get the last employee's department"

```
//Employee[last()]/Department
```

### Pattern 3: Combine — drill into a specific repeated child of a specific parent

> "What's the project name of P202?" (without caring which employee owns it)

```
//Project[ProjectId='P202']/ProjectName
```

The predicate doesn't have to be on the top-level repeated element — you
can use it anywhere in the path.

> "What's Rahul's 2nd project status?"

```
//Employee[FirstName='Rahul']/Projects/Project[2]/Status
```

### Pattern 4: Find by attribute value

If the field you want to match on is an attribute (like `id="..."`):

```xml
<Employee id="1002"><Address><City>Berlin</City></Address></Employee>
```

Use `@` to address the attribute:

```
//Employee[@id='1002']/Address/City
```

---

## Quick reference for your Employee XML

Using the Employees example from earlier, here are paths and what they return:

| Path | Returns | Notes |
|---|---|---|
| `//City` | `Frankfurt` | First match — usually NOT what you want |
| `//Employee[EmployeeId='1002']/Address/City` | `Berlin` | Predicate on EmployeeId |
| `//Employee[FirstName='Sneha']/Department` | `Operations` | Predicate on FirstName |
| `//Employee[1]/FirstName` | `Alice` | First employee (1-indexed) |
| `//Employee[2]/Address/PostalCode` | `10115` | Second employee |
| `//Employee[last()]/EmployeeId` | `1003` | Last employee |
| `//Project[ProjectId='P201']/Status` | `Active` | Specific project, regardless of owner |
| `//Project[ProjectName='Data Migration']/Status` | `Active` | Predicate on text content |
| `//Employee[EmployeeId='1001']/Projects/Project[1]/ProjectName` | `Payments API` | First project of specific employee |
| `//Employee[Department='QA']/LastName` | `Kumar` | All employees in QA — returns first match |
| `count(//Employee)` | `3` | Use `count()` for cardinality assertions |

---

## Filling in the Assertions sheet

Once you've worked out the right XPath, the row on the **Assertions** sheet
looks like this:

| TestID | Path | PathType | Operator | ExpectedValue | Description |
|---|---|---|---|---|---|
| T100 | `//Employee[EmployeeId='1002']/Address/City` | xpath | equals | Berlin | Rahul's city |
| T100 | `//Project[ProjectId='P202']/Status` | xpath | equals | InProgress | Auth service status |
| T100 | `//Employee[FirstName='Sneha']/Department` | xpath | equals | Operations | Sneha's dept |
| T100 | `count(//Employee)` | xpath | equals | 3 | Three employees returned |

---

## Operators with repeated elements

The 9 operators work the same way against any XPath result. A few
combinations that are especially useful:

- **`exists`** — does at least one element matching this path exist?
  - `//Employee[EmployeeId='1002']` with `exists` → confirms Rahul is in the response
- **`not_exists`** — useful for "no errors in the response"
  - `//Employee[Status='Deleted']` with `not_exists`
- **`regex_match`** — pattern match against the extracted value
  - `//Employee[EmployeeId='1001']/Address/PostalCode` with `regex_match` `^\d{5}$`
- **`greater_than` / `less_than`** — numeric checks
  - `count(//Employee)` with `greater_than` `0` → confirms response is non-empty

---

## Debugging an assertion that comes back empty

If the Assertions tab shows `(empty)` in the Actual column despite the value
clearly being in the response:

1. **Use the built-in XPath tester first.** It uses the same parser as the
   test runner, so what works there works in your assertions:
   ```bash
   java -cp target/api-test-suite.jar com.apitest.XPathTester \
       output/20260513_120000/T001/sourceA/step1_get/response.txt \
       "//YourPath[Here]"
   ```
2. **Look at the assertion's failure message** in the report. The framework
   surfaces XML parse failures and XPath syntax errors directly in the
   message column. If you see "XML parse failed" or "XPath syntax error",
   that's your real problem.
3. **`processing instruction target matching xml is not allowed`** — the
   response contains a second `<?xml` declaration somewhere in the middle.
   Common with proxies that concatenate responses, MTOM strippers, or
   wrapped SOAP-in-SOAP payloads. The framework auto-strips these.
4. **Open the Steps tab.** Look at the response body. Confirm the element
   you expect is actually there with the exact capitalization you used in
   your XPath.

### ⚠ Don't use HTML-mode online XPath testers

Many free online "XPath testers" silently default to **HTML5 parsing mode**,
which lowercases all element names and rejects colons in tag names. Your
SOAP/XML response — with `<S:Envelope>`, `<CostItem>`, etc. — will
appear "invalid" to them with 100+ errors about element names needing to
be lowercase. **This is the tool being wrong, not your XML.**

If you need to test an XPath outside the framework, use these instead:

- **The built-in `XPathTester`** (above) — always matches what the framework sees
- **xmlstarlet** — `xmlstarlet sel -t -v "//path" response.xml`
- **Python lxml** — `python -c "from lxml import etree; print(etree.parse('r.xml').xpath('//path/text()'))"`
- **Online (XML-aware)** — search for "XPath tester XML" (not just "XPath tester")
4. **Check for namespace declarations.** The framework strips namespaces
   automatically, so `//ns:Tag` and `//Tag` both work, but if the source XML
   uses prefixes everywhere you may have copied the prefix accidentally.
5. **Check the predicate syntax.** Wrap text values in **single quotes**:
   - Right: `//Employee[FirstName='Alice']`
   - Wrong: `//Employee[FirstName=Alice]` (XPath thinks `Alice` is an element)
6. **For attributes, use `@`:** `//Employee[@id='1002']`, not `//Employee[id='1002']`.
7. **For "starts with"-style matching**, use the `starts-with()` function:
   `//Employee[starts-with(EmployeeId,'10')]/FirstName`

---

## Cheat sheet — most-asked XPath idioms

| I want… | XPath |
|---|---|
| First match | `//Tag[1]` |
| Last match | `//Tag[last()]` |
| nth match | `//Tag[n]` |
| Match by child element value | `//Parent[Child='X']/OtherChild` |
| Match by attribute value | `//Tag[@attr='X']` |
| Match by partial text | `//Tag[contains(.,'partial')]` |
| Match by text starts-with | `//Tag[starts-with(.,'prefix')]` |
| Count of matches | `count(//Tag)` |
| Element exists with conditions | `//Tag[Condition='X']` + operator `exists` |
| Concatenated text of all matches | `//Tag/text()` (returns first; for all use multiple assertions) |
