# SSL/TLS Configuration

How to handle HTTPS endpoints with private CAs, self-signed certs, or mTLS
(mutual TLS) — all configured per-environment in the Excel `SslConfig` column.

---

## TL;DR

| Scenario | `SslConfig` cell value |
|---|---|
| Public TLS (default) | *(leave blank)* |
| Trust a private CA | `trust_store=certs/ca.jks; trust_password=${env.TRUST_PASS}` |
| Trust a private CA (PKCS12) | `trust_store=certs/ca.p12; trust_password=${env.TRUST_PASS}; trust_type=PKCS12` |
| Mutual TLS (client cert) | `key_store=certs/client.p12; key_password=${env.CLIENT_PASS}; key_type=PKCS12` |
| Both: trust their CA AND present client cert | `trust_store=certs/ca.jks; trust_password=${env.TRUST_PASS}; key_store=certs/client.p12; key_password=${env.CLIENT_PASS}; key_type=PKCS12` |
| Skip verification (DEV ONLY — insecure) | `verify=false` |

Real passwords NEVER go in Excel. Always reference them via `${env.VAR_NAME}` and export the variable in your shell or CI.

---

## How it works

The `SslConfig` column on the `Environments` sheet is a semicolon-separated
list of `key=value` pairs. For each environment, the framework parses these
options once and builds an `SSLContext` that's used for every request to that
environment. SSLContexts are cached, so keystores load only once per run.

### Available options

| Key | Required? | Notes |
|---|---|---|
| `trust_store` | No | Path to the truststore file (relative to project root). Contains the CAs / server certs to trust. |
| `trust_password` | If trust_store is set | Truststore password. Use `${env.VAR}` to read from the environment. |
| `trust_type` | No | `JKS` (default) or `PKCS12`. Inferred from file extension (`.p12` / `.pfx` → PKCS12). |
| `key_store` | No (mTLS only) | Path to the keystore holding **your client cert + private key**. |
| `key_password` | If key_store is set | Keystore password. Use `${env.VAR}`. |
| `key_type` | No | `JKS` (default) or `PKCS12`. Inferred from file extension. |
| `verify` | No | `true` (default) or `false`. **Setting to `false` disables certificate AND hostname verification — never use in production.** |

---

## Preparing the keystore files

### From individual `.pem` or `.crt` files

If your team gave you a CA certificate as a `.pem` or `.crt` file (no keystore),
convert it once using the JDK's `keytool` command:

```bash
# Trust a server's CA — creates a JKS truststore
keytool -import \
        -alias my-ca \
        -file company-root-ca.pem \
        -keystore certs/truststore.jks \
        -storepass changeit \
        -noprompt
```

For multiple certs in the chain, repeat with different aliases:
```bash
keytool -import -alias my-root  -file root-ca.pem  -keystore certs/truststore.jks -storepass changeit -noprompt
keytool -import -alias my-inter -file inter-ca.pem -keystore certs/truststore.jks -storepass changeit -noprompt
```

### From `.pem` + private key (for mTLS)

If the API team gave you `client.crt` and `client.key`, convert to PKCS12:

```bash
# Combine cert + key into a single .p12 file
openssl pkcs12 -export \
        -in client.crt \
        -inkey client.key \
        -name my-client-cert \
        -out certs/client.p12 \
        -password pass:changeit
```

PKCS12 (`.p12` / `.pfx`) is the modern standard — prefer it over JKS for new keystores.

### From `.pfx` (already PKCS12 — just use it)

If you already have a `.pfx` file from the team, no conversion needed:
```
key_store=certs/client.pfx; key_password=${env.CLIENT_PASS}; key_type=PKCS12
```

---

## Folder layout

A common layout for a project with multiple environments:

```
api-test-suite/
├── config/
│   └── test_suite.xlsx
├── certs/                       ← put keystores here
│   ├── dev-truststore.jks
│   ├── uat-truststore.jks
│   └── client.p12
├── templates/
└── ...
```

Then reference them with relative paths in the Excel `SslConfig` column:
```
trust_store=certs/uat-truststore.jks; trust_password=${env.UAT_TRUST_PASS}
```

Add `certs/` to your `.gitignore` so keystores never end up in source control.

---

## Worked examples

### Example 1: SOAP service with a private CA

The bank's internal CA signed the SOAP service's certificate. The Java JVM
doesn't trust this CA by default, so handshake fails with `PKIX path building
failed`.

**Steps:**
1. Get `bank-internal-ca.pem` from your security team.
2. Import it into a JKS truststore:
   ```bash
   keytool -import -alias bank-ca -file bank-internal-ca.pem \
           -keystore certs/bank-truststore.jks -storepass changeit -noprompt
   ```
3. Export the password as an env var:
   ```bash
   export BANK_TRUST_PASS=changeit
   ```
4. Set the `SslConfig` cell on the Environments sheet for `UAT_SOAP`:
   ```
   trust_store=certs/bank-truststore.jks; trust_password=${env.BANK_TRUST_PASS}
   ```

### Example 2: REST service requiring mTLS

The vendor's API requires you to present a client certificate they issued you
(`client.crt` + `client.key`).

**Steps:**
1. Convert to PKCS12:
   ```bash
   openssl pkcs12 -export -in client.crt -inkey client.key \
           -out certs/client.p12 -password pass:supersecret
   ```
2. Export the password:
   ```bash
   export CLIENT_KEY_PASS=supersecret
   ```
3. Set `SslConfig`:
   ```
   key_store=certs/client.p12; key_password=${env.CLIENT_KEY_PASS}; key_type=PKCS12
   ```

### Example 3: Both — private CA AND mTLS

An internal service uses a private CA *and* requires mTLS. Combine both options
on the same row:
```
trust_store=certs/internal-ca.jks; trust_password=${env.TRUST_PASS}; key_store=certs/client.p12; key_password=${env.CLIENT_PASS}; key_type=PKCS12
```

### Example 4: Local dev with self-signed cert (insecure)

Hitting a service running on `https://localhost:8443` with a self-signed cert
that you don't want to bother trusting. **Don't ever use this against any
non-local environment.**
```
verify=false
```

---

## Troubleshooting

### `PKIX path building failed: unable to find valid certification path to requested target`

The JVM doesn't trust the server's certificate chain. The server is using
a CA that isn't in the JVM's default truststore. Fix: get the CA's cert and
add a `trust_store` config (Example 1 above).

### `Received fatal alert: bad_certificate`

The server is asking for mTLS but you're not presenting a client cert.
Add a `key_store` config (Example 2 above).

### `No name matching <host> found`

The server's certificate CN/SAN doesn't match the hostname you're hitting.
Either:
1. Use the correct hostname that matches the cert (preferred), or
2. Use `verify=false` to skip hostname verification (dev/test only).

### `Keystore was tampered with, or password was incorrect`

The truststore/keystore password is wrong. Double-check the env var is exported:
```bash
echo $TRUST_PASS    # should print the password, not empty
```

### `DerInputStream.getLength(): lengthTag=109, too big`

The keystore type is wrong. If the file is `.p12` or `.pfx`, you need
`trust_type=PKCS12` or `key_type=PKCS12`. JKS is the default — only files
created with `keytool -keystore foo.jks` are JKS.

### `Tag number over 30 is not supported`

Same as above — wrong keystore type. Verify with `keytool -list -v -keystore yourfile.jks -storetype PKCS12` — try both `JKS` and `PKCS12` until one lists the contents successfully.

---

## Security notes

- **Never commit keystores or passwords to source control.** Add `certs/` to `.gitignore`.
- Use `${env.VAR}` for every password. The Excel file itself should be safe to share with the team.
- The `verify=false` mode disables BOTH certificate AND hostname checks. It's appropriate for `localhost` development against self-signed certs and nothing else.
- For CI/CD, store keystores as encrypted secrets and write them to disk during the job:
  ```yaml
  - run: echo "$TRUSTSTORE_B64" | base64 -d > certs/truststore.jks
    env:
      TRUSTSTORE_B64: ${{ secrets.TRUSTSTORE_B64 }}
  ```
- The framework caches `SSLContext`s per config string in memory only — they never persist to disk.
