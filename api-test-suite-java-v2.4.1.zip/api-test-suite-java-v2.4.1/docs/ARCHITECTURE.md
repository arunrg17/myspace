# Architecture

How the framework is wired together — for anyone planning to extend or maintain it.

---

## Package layout

```
com.apitest
├── Main                     CLI entry point — parses args, calls Runner, exits
├── model/                   Plain data carriers (records and POJOs)
│   ├── Environment          One environment row
│   ├── Step                 One step row
│   ├── Assertion            One assertion row
│   ├── TestCase             One test, with its steps + data + assertions
│   ├── TestSuite            Top-level container loaded from Excel
│   ├── StepResult           Per-step runtime result
│   ├── DiffEntry            One structural diff
│   ├── CompareResult        Result of one structural comparison
│   ├── AssertionResult      Result of one field-level assertion
│   └── TestResult           Aggregate per-test result
├── excel/
│   ├── ExcelLoader          POI XSSF reader: workbook → TestSuite
│   └── TemplateGenerator    POI XSSF writer: creates the starter workbook
├── template/
│   └── TemplateEngine       Resolves ${placeholders} in templates + endpoints
├── dispatcher/
│   ├── Dispatcher           Apache HttpClient — sends requests, handles auth
│   └── Response             HTTP response container
├── comparator/
│   ├── Comparator           Structural diff (XML/JSON, ignore directives, cross-format)
│   └── AssertionEngine      Field-level assertion runner (9 operators)
├── runner/
│   └── Runner               Orchestrator: load → execute → compare/assert → record
└── reporter/
    └── Reporter             HTML report generator (self-contained, no deps)
```

---

## Data flow

```
config/test_suite.xlsx
       │
       ▼
   ExcelLoader  →  TestSuite (Environments + List<TestCase>)
       │
       ▼
   Runner.runAll()
       │
       ├── for each TestCase:
       │     ├── For each Step:
       │     │     ├── TemplateEngine.render(endpoint, data, stepVars)
       │     │     ├── TemplateEngine.renderFile(body, data, stepVars)
       │     │     ├── Dispatcher.send(...)  ──→  HTTP response
       │     │     └── Comparator.extractVariable(...) → stepVars
       │     │
       │     ├── Comparator.compare(expected, actual, assertions)   [if vs_*]
       │     └── AssertionEngine.evaluate(response, assertions)     [if any]
       │
       ▼
   List<TestResult>
       │
       ▼
   Reporter.renderReport()  ─→  reports/report.html
```

Every test's raw request and response are also dumped to
`output/<timestamp>/<TestID>/sourceA/step<N>_<name>/{request,response}.txt`
for forensic inspection — handy when the HTML report shows a failure and you
need exact bytes.

---

## Why these design choices

### Excel as the source of truth

The team writing tests doesn't write Java. Excel is universal, diffable in
Git (Open XML format), and lets non-engineers add tests. The framework is a
mechanism; the workbook is the test suite.

### POI for Excel I/O

POI is the only mature Apache-licensed Java library for `.xlsx`. The pom.xml
pins 5.2.5 because earlier versions have annoying xmlbeans / log4j shading
issues that bite on Java 21.

### Apache HttpClient 4.5 over HttpClient 5 / Java HttpClient

HttpClient 4.5 is rock-solid, ubiquitous in enterprises, and works identically
across JDK versions. Java's built-in `HttpClient` would also work, but 4.5's
header / entity API is more pleasant for SOAP and the connection pool defaults
match what people expect.

### Jackson + Jayway JsonPath

Jackson handles JSON parsing. JsonPath handles selectors. Both are de facto
standard. The combined dependency surface is small and well-understood.

### XML via DOM, not StAX

Test payloads are typically a few KB. Loading the whole document into a DOM
is simpler than streaming and lets the comparator walk the tree recursively.
For multi-MB SOAP responses this would need revisiting, but that's not the
common case.

### Self-contained HTML report

No CDN dependencies — every byte of CSS and JS is inlined. The report
travels: email it, drop it in an S3 bucket, attach it to a Jira ticket, open
it three years later, it still works. That matters for audit trails.

### Cross-format comparison

XML and JSON get normalized to a `Map<String, Object>` tree before diffing.
This lets `vs_protocol` mode compare a SOAP response against a REST response
when they should be semantically equivalent. Namespace prefixes are stripped
during XML parsing — `<ns:Order>` and `<Order>` compare as the same element.

---

## Extending the framework

### Adding a new comparison mode

1. Add the mode name as a string constant in `Runner` (or just use the literal).
2. Add a `case` to the `switch (mode)` block in `Runner.runTest()`.
3. Implement the new logic — typically you'll call into `Comparator` and / or
   `AssertionEngine` to populate `result.compareResult` and / or `result.assertionResults`.
4. The report already handles arbitrary modes — they'll show up in the
   filters dropdown and the mode breakdown chart automatically.
5. Update `TemplateGenerator` and the docs.

### Adding a new assertion operator

1. Add a case to the `switch (op)` block in `AssertionEngine.evaluateOne()`.
2. Set `r.passed` and `r.message`.
3. Update the docs (README + EXCEL_GUIDE).

### Adding a new protocol or auth type

`Dispatcher` is the only place that knows about protocols. Add a new branch
to `resolveAuth()` for new auth flows, or to the request-building code if
the new protocol needs special header handling.

### Replacing the stubbed OAuth2 / GCP token methods

`Dispatcher.getOauth2Token()` and `Dispatcher.getGcpToken()` are stubs that
fall back to environment variables. Swap them with real implementations:

- **OAuth2 / Fabric** — add `com.microsoft.azure:msal4j` to pom.xml, build a
  `ConfidentialClientApplication`, request `client_credentials` flow,
  cache the result.
- **GCP** — add `com.google.auth:google-auth-library-oauth2-http`, load the
  service account from the `AuthValue` path, call `refreshAccessToken()`.

Keep them silent on success (just return the token) and let exceptions bubble
up — `Dispatcher.send()` will record them as the response error.

---

## Testing

```bash
mvn test
```

Three test classes:

- **`ComparatorTest`** — structural diff, ignore directives, cross-format,
  variable extraction. Covers all the edge cases in the format normalization.
- **`TemplateEngineTest`** — placeholder substitution, step variables, env,
  now, uuid, edge cases like regex special chars in values.
- **`AssertionEngineTest`** — all 9 operators against both JSON and XML.
- **`ExcelLoaderTest`** — round-trip: TemplateGenerator writes a workbook,
  ExcelLoader reads it, every field is verified.

Add a new test class when you add a new package. Use JUnit 5 (`@Test` from
`org.junit.jupiter.api`).

---

## Known limitations

- **No streaming** — entire response is read into memory. Fine for typical
  API testing, would need rework for multi-MB payloads.
- **No retries** — a transient 5xx fails the test. Easy to add to
  `Dispatcher` if needed.
- **No parallel execution** — tests run sequentially. The HTML report design
  doesn't depend on order, so adding a fork-join pool around the loop in
  `Runner.runAll()` is straightforward, but bear in mind ordering of the
  `output/<timestamp>` capture folders if you do.
- **OAuth2 / GCP stubs** — token providers are not implemented out of the
  box (see "Wiring real auth providers" in README).
