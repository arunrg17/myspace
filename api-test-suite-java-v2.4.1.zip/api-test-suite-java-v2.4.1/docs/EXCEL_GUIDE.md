# Excel Workbook Guide

Detailed reference for `config/test_suite.xlsx`. See [README.md](README.md) for
the bigger picture; this document covers every sheet, every column, and the
edge cases.

---

## Sheet 1: Environments

Defines named endpoints. Same protocol can appear multiple times (DEV / UAT / PROD).

### Columns

| Column | Required | Notes |
|---|---|---|
| `EnvName` | yes | Identifier referenced from `SourceA` / `SourceB`. No spaces. |
| `Protocol` | yes | `rest`, `soap`, `fabric`, `gcp`. Drives default headers. |
| `BaseURL` | yes | Full origin including scheme. Trailing slash is stripped. |
| `AuthType` | yes | See auth types below. |
| `AuthValue` | depends | Token literal or `${env.VAR}` reference. |
| `ExtraHeaders` | no | One header per line: `Header-Name: value`. |

### Auth types

| AuthType | AuthValue format | Behaviour |
|---|---|---|
| `none` | (blank) | No Authorization header. |
| `basic` | `user:password` | Encoded as `Authorization: Basic …`. |
| `bearer` | token | Encoded as `Authorization: Bearer <token>`. |
| `oauth2` | client secret or `${env.X}` | Calls `Dispatcher.getOauth2Token()` (currently stubbed — wire in MSAL4J for real use). |
| `service_account` | path to GCP service account JSON | Calls `Dispatcher.getGcpToken()` (stubbed). |

### Examples

```
DEV_REST    | rest   | https://dev-api.example.com         | bearer  | ${env.DEV_TOKEN}        | Content-Type: application/json
UAT_SOAP    | soap   | https://uat-soap.example.com/svc    | basic   | soap_user:soap_pass     | Content-Type: text/xml; charset=utf-8
                                                                                                  | SOAPAction: ""
FABRIC_DEV  | fabric | https://api.fabric.microsoft.com/v1 | oauth2  | ${env.FABRIC_SECRET}    | Content-Type: application/json
```

> Newlines inside `ExtraHeaders` cell: type `Alt+Enter` (Windows) or `Ctrl+Opt+Enter` (macOS) in Excel.

---

## Sheet 2: TestSuite

One row per test case. Drives what gets executed and how it's evaluated.

### Columns

| Column | Required | Notes |
|---|---|---|
| `TestID` | yes | Stable identifier. Used to link Steps / TestData / Assertions. |
| `TestName` | yes | Free text. Shown in the report. |
| `Description` | no | Free text. Shown in report tooltips. |
| `ComparisonMode` | yes | One of: `vs_expected`, `vs_env`, `vs_protocol`, `assert_only`, `chain`. |
| `SourceA` | yes | EnvName from Environments sheet. |
| `SourceB` | conditional | Required for `vs_env` and `vs_protocol`. Blank otherwise. |
| `ExpectedFile` | conditional | Required for `vs_expected`. Path relative to project root. |
| `Enabled` | yes | `Y`/`Yes`/`true` to run, anything else skips the row. |

### Comparison mode quick reference

| Mode | A runs? | B runs? | Compared | Assertions allowed? |
|---|---|---|---|---|
| `vs_expected` | ✓ | — | last A vs `ExpectedFile` | ✓ |
| `vs_env` | ✓ | ✓ | last A vs last B | ✓ |
| `vs_protocol` | ✓ | ✓ | last A vs last B (cross-format OK) | ✓ |
| `assert_only` | ✓ | — | nothing structural | required |
| `chain` | ✓ | — | nothing | ✗ |

---

## Sheet 3: Steps

One row per HTTP request. Multiple rows with the same `TestID` form a chain
(`StepOrder = 1, 2, 3, …`).

### Columns

| Column | Required | Notes |
|---|---|---|
| `TestID` | yes | Must match a row in TestSuite. |
| `StepOrder` | yes | Integer. Steps execute in ascending order. |
| `StepName` | yes | Free text. Shown in the report. |
| `Method` | yes | `GET`, `POST`, `PUT`, `DELETE`, `PATCH`, `HEAD`, `OPTIONS`. |
| `Endpoint` | yes | Path appended to BaseURL. Supports placeholders. |
| `BodyTemplate` | conditional | Path to a template in `/templates`. Leave blank for GET/DELETE. |
| `ExtractVars` | no | Comma-separated `name=path` pairs (see below). |
| `ExpectedStatus` | no | Comma-separated codes (default: `200,201,204`). |

### ExtractVars

After each step, named variables can be pulled from the response for use in
later steps. The path is auto-detected as JSONPath or XPath based on the
response format.

```
order_id=$.order.id, customer_email=$.customer.email
```

Reference these in later steps as `${step1.order_id}`, `${step1.customer_email}`.

### Endpoint placeholders

```
/orders/${step1.order_id}        — chain reference
/customers/${customer_id}         — from TestData
/items?ts=${now}&trace=${uuid}    — generated
```

---

## Sheet 4: TestData

Variable values per test. Each column header (except `TestID`) becomes a
placeholder name available to templates and endpoints.

### Layout

```
TestID | customer_id | product_id | quantity | unit_price | currency | region | priority | notes
T001   | CUST-1001   |            |          |            |          |        |          |
T002   | CUST-1001   | PROD-501   | 5        | 49.99      | USD      | EMEA   | high     | rush
T003   | CUST-1001   |            |          |            |          |        |          |
```

### Rules

- The `TestID` column is special. Every other column is a placeholder name.
- Add as many columns as you need. Unused ones are harmless.
- Numeric values are auto-converted (integers stay integers, decimals stay decimals).
- Empty cells become empty strings — they do **not** fall back to a default.
- Each test has its own row; no inheritance between tests.

### When to use TestData vs `${env.X}`

| Use TestData when… | Use `${env.X}` when… |
|---|---|
| The value differs per test | The value is a secret or token |
| You want it auditable in source control | You don't want it auditable |
| The value is stable test data | The value is environment-specific |

---

## Sheet 5: Assertions

Two things in one sheet: **field-level assertions** and **ignore directives**
that quiet noisy fields during structural comparison.

### Columns

| Column | Required | Notes |
|---|---|---|
| `TestID` | yes | Specific TestID, or `*` to apply the row to every test. |
| `Path` | yes | JSONPath (`$.order.id`) or XPath (`//Status`). |
| `PathType` | yes | `jsonpath` or `xpath`. Must match the response format. |
| `Operator` | yes | One of the 9 operators below. |
| `ExpectedValue` | depends | Required by `equals`, `not_equals`, `contains`, `greater_than`, `less_than`, `regex_match`. Blank for `exists`, `not_exists`, `ignore`. |
| `Description` | no | Shown in the report. Helps future-you remember what this check is for. |

### Operators

| Operator | What it does | ExpectedValue used? |
|---|---|---|
| `equals` | actual == expected (string comparison) | yes |
| `not_equals` | actual != expected | yes |
| `contains` | expected appears as a substring of actual | yes |
| `exists` | path resolves to a non-empty value | no |
| `not_exists` | path doesn't resolve / value is empty | no |
| `greater_than` | numeric: actual > expected | yes |
| `less_than` | numeric: actual < expected | yes |
| `regex_match` | Java regex matches against actual | yes (the regex) |
| `ignore` | **structural-comparison directive**: silently strip this path before diffing | no |

### Examples

Ignore noisy fields globally:
```
*    | //*[local-name()='traceId']     | xpath    | ignore    |                       | varies every call
*    | $.metadata.requestTime          | jsonpath | ignore    |                       | always changes
```

Field assertions on a specific test:
```
T006 | $.order.status                  | jsonpath | equals       | created             | New order state
T006 | $.order.id                      | jsonpath | exists       |                     | ID generated
T006 | $.total                         | jsonpath | greater_than | 0                   | Positive total
T006 | $.order.region                  | jsonpath | regex_match  | ^(EMEA|AMER|APAC)$  | Known region code
T006 | $.error                         | jsonpath | not_exists   |                     | No error field
```

XPath against SOAP:
```
T003 | //*[local-name()='Status']      | xpath    | equals       | active              | Active account
T003 | //*[local-name()='Timestamp']   | xpath    | ignore       |                     | Generated timestamp
```

### Path type cheat sheet

| Response format | PathType | Path examples |
|---|---|---|
| JSON | `jsonpath` | `$.field`, `$.array[0].name`, `$..price` |
| XML / SOAP | `xpath` | `//Status`, `//*[local-name()='ns:Name']`, `/Order/Total` |

**Use `local-name()` in XPath** when the response has namespaces — it strips
the namespace prefix and matches by element name only. Without it, `//Status`
won't find `<ns:Status>`.

---

## Common patterns

### Pattern: "Just check a few fields, don't compare files"

```
TestSuite: T010 | … | assert_only | DEV_REST |  |  | Y
Assertions:
  T010 | $.status         | jsonpath | equals | success | OK status
  T010 | $.transaction_id | jsonpath | exists |         | Must return an ID
```

### Pattern: "Compare two environments but ignore generated IDs"

```
TestSuite: T011 | … | vs_env | DEV_REST | UAT_REST |  | Y
Assertions:
  T011 | $.id                 | jsonpath | ignore |  | Differs by env
  T011 | $.metadata.timestamp | jsonpath | ignore |  | Differs by env
```

### Pattern: "Full chain, no comparison"

```
TestSuite: T012 | … | chain | DEV_REST |  |  | Y
Steps:
  T012 | 1 | Create | POST   | /resources       | templates/create.json | id=$.id | 201
  T012 | 2 | Update | PUT    | /resources/${step1.id} | templates/update.json | | 200
  T012 | 3 | Delete | DELETE | /resources/${step1.id} |                       | | 204
```

### Pattern: "Compare to a baseline, but also assert critical fields"

```
TestSuite: T013 | … | vs_expected | DEV_REST |  | expected/T013_response.json | Y
Assertions:
  T013 | $.order.created_at | jsonpath | ignore |          | timestamp differs every call
  T013 | $.order.id         | jsonpath | ignore |          | generated UUID
  T013 | $.order.status     | jsonpath | equals | created  | Critical field — also asserted
  T013 | $.total            | jsonpath | greater_than | 0  | Critical field
```

---

## Cell formatting tips

- **Long template paths**: enable cell wrap (`Format → Alignment → Wrap text`).
- **Multi-line ExtraHeaders**: `Alt+Enter` to insert a newline within a cell.
- **Numbers that should stay strings** (`"00123"`): format the column as Text before typing.
- **Booleans in `Enabled`**: any of `Y`, `Yes`, `TRUE` work. Case-insensitive.
