@echo off
rem  Place this next to api-test-suite.jar in the project root, then double-click.
java -jar "%~dp0launcher.jar" %*
