/**
 * TestForge — GitHub Copilot Enterprise Backend Proxy
 * ---------------------------------------------------------
 * Keeps your PAT server-side. The browser never sees the token.
 * 
 * Setup:
 *   1. npm install
 *   2. Create .env file with your PAT (see .env.example)
 *   3. node server.js
 * 
 * Runs on: http://localhost:3001
 */

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const rateLimit  = require('express-rate-limit');
const https      = require('https');

const app  = express();
const PORT = process.env.PORT || 3001;

// ── GITHUB COPILOT CONFIG ─────────────────────────────────────────────
const GITHUB_PAT        = process.env.GITHUB_PAT;
const GITHUB_MODEL      = process.env.GITHUB_MODEL || 'gpt-4o';
const COPILOT_ENDPOINT  = 'https://models.inference.ai.azure.com';

if (!GITHUB_PAT) {
  console.error('\n❌  ERROR: GITHUB_PAT is not set in your .env file.');
  console.error('    Copy .env.example → .env and add your token.\n');
  process.exit(1);
}

// ── MIDDLEWARE ────────────────────────────────────────────────────────
app.use(express.json({ limit: '2mb' }));

// CORS — restrict to your internal domain in production
const allowedOrigins = (process.env.ALLOWED_ORIGINS || 'http://localhost,http://127.0.0.1')
  .split(',').map(o => o.trim());

app.use(cors({
  origin: (origin, cb) => {
    // Allow no-origin (same machine file:// open) during dev
    if (!origin || allowedOrigins.some(o => origin.startsWith(o))) return cb(null, true);
    cb(new Error('CORS: origin not allowed — ' + origin));
  }
}));

// Rate limiting — prevent accidental hammering
const limiter = rateLimit({
  windowMs: 60 * 1000,  // 1 minute
  max: 30,
  message: { error: 'Too many requests — please wait a moment.' }
});
app.use('/api/', limiter);

// ── HEALTH CHECK ──────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'TestForge Copilot Proxy',
    model: GITHUB_MODEL,
    timestamp: new Date().toISOString()
  });
});

// ── COPILOT CONNECTION TEST ───────────────────────────────────────────
app.get('/api/test-connection', async (req, res) => {
  try {
    const result = await callCopilot([
      { role: 'user', content: 'Reply with exactly: {"status":"connected"}' }
    ], 50);
    res.json({ connected: true, model: GITHUB_MODEL, response: result });
  } catch (err) {
    res.status(502).json({ connected: false, error: err.message });
  }
});

// ── MAIN GENERATE ENDPOINT ────────────────────────────────────────────
app.post('/api/generate', async (req, res) => {
  const { inputText, template, coverage, count, includeNegative, contextTags } = req.body;

  if (!inputText || inputText.trim().length < 5) {
    return res.status(400).json({ error: 'inputText is required (min 5 chars).' });
  }

  const systemPrompt = buildSystemPrompt(template, coverage, count, includeNegative, contextTags);

  try {
    const raw = await callCopilot([
      { role: 'system', content: systemPrompt },
      { role: 'user',   content: `Generate test cases for the following:\n\n${inputText}` }
    ], 4000);

    // Strip any accidental markdown fences
    const clean = raw.replace(/```json|```/g, '').trim();

    let testCases;
    try {
      testCases = JSON.parse(clean);
      if (!Array.isArray(testCases)) throw new Error('Response is not an array');
    } catch {
      return res.status(502).json({
        error: 'Model returned non-JSON. Try again.',
        raw: clean.substring(0, 300)
      });
    }

    res.json({ testCases, model: GITHUB_MODEL, count: testCases.length });

  } catch (err) {
    console.error('[generate error]', err.message);
    res.status(502).json({ error: 'Copilot API error: ' + err.message });
  }
});

// ── COPILOT API CALL ──────────────────────────────────────────────────
function callCopilot(messages, maxTokens = 4000) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model:      GITHUB_MODEL,
      messages,
      max_tokens: maxTokens,
      temperature: 0.3
    });

    const options = {
      hostname: 'models.inference.ai.azure.com',
      path:     '/chat/completions',
      method:   'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${GITHUB_PAT}`,
        'Content-Length': Buffer.byteLength(body)
      }
    };

    const req = https.request(options, (response) => {
      let data = '';
      response.on('data', chunk => data += chunk);
      response.on('end', () => {
        if (response.statusCode === 401) return reject(new Error('PAT is invalid or SSO not authorized for org.'));
        if (response.statusCode === 403) return reject(new Error('PAT lacks required permissions (models:read).'));
        if (response.statusCode === 429) return reject(new Error('Rate limit hit on GitHub Models API.'));
        if (response.statusCode !== 200) return reject(new Error(`HTTP ${response.statusCode}: ${data.substring(0,200)}`));

        try {
          const json = JSON.parse(data);
          const content = json.choices?.[0]?.message?.content;
          if (!content) return reject(new Error('Empty response from model.'));
          resolve(content);
        } catch {
          reject(new Error('Failed to parse GitHub API response.'));
        }
      });
    });

    req.on('error', err => reject(new Error('Network error: ' + err.message)));
    req.write(body);
    req.end();
  });
}

// ── PROMPT BUILDER ────────────────────────────────────────────────────
function buildSystemPrompt(template, coverage, count, includeNegative, contextTags) {
  const countStr  = (!count || count === 'Auto-detect') ? '6 to 10' : count;
  const tags      = Array.isArray(contextTags) && contextTags.length ? contextTags.join(', ') : 'none specified';

  const templateFormats = {
    standard: `Each object must have: id, title, priority (High/Medium/Low), type (Positive/Negative/Edge), preconditions, steps (array of strings), expectedResult, testData`,
    bdd:      `Each object must have: id, title, priority, type, scenario (string with Given/When/Then/And on new lines), testData`,
    ieee:     `Each object must have: id, title, priority, type, objective, inputs, steps (array), expectedOutputs, passCriteria`,
    exploratory: `Each object must have: id, title, priority, type, charter, areas (array), risks (array), timebox`,
    custom:   `Each object must have: id, title, priority, type, description, steps (array), expectedResult`
  };

  const format = templateFormats[template] || templateFormats.standard;

  return `You are a senior QA engineer specialising in enterprise financial systems.
Your task is to generate structured test cases based on requirements provided.

TEMPLATE: ${template || 'standard'}
FORMAT: ${format}
COVERAGE: ${coverage || 'Happy Path + Edge Cases + Negative'}
COUNT: Generate exactly ${countStr} test cases
INCLUDE NEGATIVE TESTS: ${includeNegative ? 'Yes' : 'No'}
CONTEXT FOCUS AREAS: ${tags}

RULES:
- IDs must follow pattern: TC-001, TC-002, etc.
- Steps must be concrete, numbered action strings
- Cover boundary values, invalid inputs, and auth scenarios where relevant
- For financial features: include data integrity, audit trail, and concurrency scenarios
- Respond ONLY with a valid JSON array. No markdown, no explanation, no preamble.`;
}

// ── START ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✅  TestForge Proxy running on http://localhost:${PORT}`);
  console.log(`    Health:     GET  /api/health`);
  console.log(`    Test conn:  GET  /api/test-connection`);
  console.log(`    Generate:   POST /api/generate\n`);
});
