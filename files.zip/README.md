# TestForge — Setup Guide
## GitHub Copilot Enterprise · Secure Backend Proxy

---

## What's in this package

| File | Purpose |
|---|---|
| `server.js` | Node.js proxy server — holds your PAT securely |
| `testforge-ui.html` | Frontend — open in any browser |
| `package.json` | Node dependencies |
| `.env.example` | Template for your environment config |
| `README.md` | This file |

---

## Step 1 — Prerequisites

- Node.js v18 or higher installed on the server machine
  - Check: `node --version`
  - Download: https://nodejs.org
- Your GitHub PAT (Fine-grained token with `models:read` scope)

---

## Step 2 — Install dependencies

```bash
cd testforge-backend
npm install
```

---

## Step 3 — Configure your PAT

```bash
cp .env.example .env
```

Edit `.env` and add your PAT:

```
GITHUB_PAT=ghp_your_actual_token_here
GITHUB_MODEL=gpt-4o
PORT=3001
ALLOWED_ORIGINS=http://localhost,http://127.0.0.1
```

> ⚠️ Never commit .env to Git. Add it to .gitignore.

---

## Step 4 — Authorize SSO (IMPORTANT for org accounts)

If your org uses SSO (most enterprise/bank orgs do):

1. Go to https://github.com/settings/tokens
2. Find your PAT
3. Click "Configure SSO" next to it
4. Click "Authorize" next to your organisation name
5. Confirm

Without this step, you will get a 401 error even with a valid PAT.

---

## Step 5 — Start the proxy server

```bash
node server.js
```

You should see:
```
✅  TestForge Proxy running on http://localhost:3001
    Health:     GET  /api/health
    Test conn:  GET  /api/test-connection
    Generate:   POST /api/generate
```

---

## Step 6 — Open the frontend

Open `testforge-ui.html` in your browser.

- The tool will auto-test the connection on load
- You should see "Connected · gpt-4o" in the top right
- Start generating test cases!

---

## Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| Cannot reach proxy | Server not running | Run `node server.js` |
| 401 Unauthorized | PAT invalid or SSO not authorized | Authorize SSO (Step 4) |
| 403 Forbidden | Wrong PAT scope | Regenerate PAT with `models:read` |
| 429 Rate Limited | Too many requests | Wait 1 minute and retry |
| CORS error | Wrong ALLOWED_ORIGINS | Add your frontend URL to .env |

---

## Deploying internally (for your IT team)

To make this available to your whole team on the internal network:

1. Run the server on an internal VM/server
2. Change `PORT=3001` to whatever port your org allows
3. Set `ALLOWED_ORIGINS=http://testforge.yourorg.internal` (your internal URL)
4. Host `testforge-ui.html` on IIS, Nginx, or SharePoint
5. Update the Proxy URL in the UI to point to the internal server

---

## Security notes

- The GitHub PAT **never leaves the server** — the browser only calls `/api/generate`
- Rate limiting is enabled (30 requests/minute per IP)
- CORS is restricted to configured origins
- For production: add HTTPS using a reverse proxy (Nginx + cert)
