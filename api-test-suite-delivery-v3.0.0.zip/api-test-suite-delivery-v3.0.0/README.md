# API Test Suite v3.0.0 — Delivery Package

## What's in this package

```
api-test-suite-delivery-v3.0.0/
├── api-test-suite-launcher.jar       ← Double-click to open the desktop UI
├── api-test-suite-backend-v3.0.0.zip ← Backend source (build on your machine)
├── config/
│   └── test_suite.xlsx               ← Starter workbook template
└── README.md                         ← This file
```

---

## Quick Start (5 minutes)

### Step 1 — Build the backend jar (do this once, on your machine)

Requirements: **Java 11+** and **Maven** (with access to your Artifactory).

```bash
unzip api-test-suite-backend-v3.0.0.zip
cd api-test-suite-backend-v3.0.0
mvn package -DskipTests
```

The result is `target/api-test-suite.jar`.
Copy it into the **same folder** as `api-test-suite-launcher.jar`.

### Step 2 — Arrange the two jars side-by-side

```
my-tests/
├── api-test-suite.jar           ← built from Step 1
├── api-test-suite-launcher.jar  ← the desktop GUI (this package)
└── workspace/                   ← your test workbooks go here (auto-created)
```

### Step 3 — Launch

**Double-click** `api-test-suite-launcher.jar`  
*(or run:  `java -jar api-test-suite-launcher.jar`)*

The launcher will:
1. Start `api-test-suite.jar` as a background process
2. Wait for it to be ready (health check)
3. Enable the **Open in Browser** and **Run Test File** buttons

---

## Running the backend directly (no GUI)

If you prefer the command line:

```bash
# Start the web server (port 8080)
java -jar api-test-suite.jar

# CLI mode: run a suite directly and produce an HTML report
java -jar api-test-suite.jar --suite config/test_suite.xlsx --report reports/report.html
```

Environment variables accepted by the web server:
| Variable           | Default       | Purpose                        |
|--------------------|---------------|--------------------------------|
| `SERVER_PORT`      | `8080`        | HTTP port                      |
| `APITEST_WORKSPACE`| `./workspace` | Root for workbooks & reports   |

---

## Launcher UI tour

| Control              | What it does                                                      |
|----------------------|-------------------------------------------------------------------|
| **Port** field       | Port the backend will listen on (default 8080); editable before start |
| **Workspace** field  | Directory that holds your workbooks; browseable                   |
| **Start Backend**    | Launches `api-test-suite.jar`; button becomes **Stop Backend**    |
| **Open in Browser**  | Opens `http://localhost:<port>` in your default browser           |
| **Run Test File…**   | File chooser → uploads an `.xlsx` and starts a run via the API    |
| Log panel            | Live stdout/stderr from the backend, colour-coded by level        |

---

## Troubleshooting

**"Could not find api-test-suite.jar"**  
→ Build it first (Step 1) and place it next to the launcher jar.

**Double-click does nothing on Linux**  
→ Run `java -jar api-test-suite-launcher.jar` from a terminal, or configure
  your file manager to open `.jar` files with the JRE.

**Port already in use**  
→ Change the **Port** field in the launcher before clicking Start, or stop
  whichever process owns the port.

**Maven build fails**  
→ Check that your Artifactory proxy is reachable and that the corporate
  settings.xml is active (`~/.m2/settings.xml` or `-s /path/to/settings.xml`).

---

## Version history (v3.0.0)

- **Merged architecture**: engine + web server in one jar; `--suite` flag
  activates CLI mode, no flag starts the web UI on port 8080.
- **React UI** fully embedded in the jar — no Node.js needed at runtime.
- **AI assistant** (optional): connects to your internal LLM gateway;
  base URL and API key configured from the Settings panel.
- **26+ REST endpoints**: upload workbooks, manage environments, run suites,
  stream progress via Server-Sent Events, download HTML reports.
- All previous engine improvements (v2.x) are included.

---

*Build: api-test-suite v3.0.0 · Launcher compiled for Java 11+ · No external dependencies*
