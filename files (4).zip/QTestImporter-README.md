# qTest Test Case Importer

**Java utility to bulk-import test cases from ALM-exported Excel/CSV into qTest.**

Zero external dependencies — uses only Java 11+ built-in libraries.
Reads `.xlsx` and `.csv` files natively (no Apache POI needed).

---

## Quick Start

### 1. Generate config file
```bash
java QTestImporter generate-config
```
This creates `qtest-config.properties`. Edit it:

```properties
# Your qTest URL
qtest.url=https://your-org.qtestnet.com

# Your token (UserContextToken from browser, or Bearer token from API & SDK page)
qtest.token=your-token-here

# Token type: 'UserContextToken' or 'bearer'
qtest.token.type=UserContextToken

# Project ID (find it with list-projects command)
qtest.project.id=12345

# Optional: target module/folder ID (find it with list-modules)
qtest.module.id=
```

### 2. Test connection
```bash
java QTestImporter test-connection
```

### 3. Explore your qTest project
```bash
java QTestImporter list-projects     # Find your project ID
java QTestImporter list-fields       # See available test case fields + allowed values
java QTestImporter list-modules      # See module/folder tree
```

### 4. Validate with dry run
```bash
java QTestImporter dry-run exported-from-alm.xlsx
```
Shows: field mapping, parsed test cases, step counts, validation errors, and a sample JSON payload.

### 5. Import
```bash
java QTestImporter import exported-from-alm.xlsx
```
Asks for confirmation before importing. Shows progress per test case.

---

## Getting Your Token

### Option A: UserContextToken (from browser session)
1. Log into qTest in your browser
2. Open browser DevTools (F12) > Network tab
3. Click any page in qTest, find an API request
4. Copy the `Authorization` header value (it starts with `UserContextToken`)
5. Paste just the token part (after `UserContextToken `) into the config

### Option B: Bearer Token (recommended for automation)
1. Log into qTest
2. Go to **Resources** > **API & SDK**
3. Copy the **Bearer Token**
4. Set `qtest.token.type=bearer` in config

---

## Field Mapping (ALM to qTest)

The config file controls how ALM Excel columns map to qTest fields.
The tool ships with default mappings for these ALM headers:

| ALM Excel Column    | qTest Field        | Notes                          |
|---------------------|--------------------|--------------------------------|
| Test Case Name      | name               | Required — groups rows by name |
| Description         | description         |                                |
| Prerequisites       | precondition        |                                |
| Status              | Status (property)   | Auto-resolves allowed values   |
| Priority            | Priority (property) | Auto-resolves allowed values   |
| Test Type           | Type (property)     | Auto-resolves allowed values   |
| Automation          | Automation (prop)   |                                |
| Step Description    | step.description    | One row per step               |
| Expected Result     | step.expected       | One row per step               |
| Step Name           | step.name           | Optional step label            |

### Unmapped ALM columns (skipped by default):
Application, Designer, Module, Test Category, Regression Candidate,
Creation Date, Classification, Project, Program, Test Mode,
Test Data Req., Comments, Number of Steps, Requirement Coverage, Test Lab Path

### Custom mapping
Edit `qtest-config.properties`:
```properties
# Map ALM "Application" to a qTest custom field named "Application"
mapping.Application=Application

# Map ALM "Designer" to qTest "Assigned To"
mapping.Designer=Assigned To

# Explicitly skip a column
mapping.Test Lab Path=__skip__
```

### How it works:
- **`name`** — becomes the test case name (required)
- **`description`** — becomes the description field
- **`precondition`** — becomes the precondition field
- **`step.description`** / **`step.expected`** — builds test steps (rows with same test name become multiple steps)
- **Any other value** — looked up as a qTest field label. If the field has allowed values (dropdown), the tool auto-resolves by label match.
- **`__skip__`** — column is ignored

### Step grouping
ALM exports have multiple rows per test case (one row per step).
The tool groups rows by `Test Case Name` and builds steps from each row's `Step Description` + `Expected Result`.

---

## File Format Support

| Format | Support |
|--------|---------|
| `.xlsx` | Native reader (reads XML inside ZIP, no Apache POI) |
| `.csv`  | Full support with quoted field handling |
| `.tsv`  | Tab-separated, same as CSV |
| `.xls`  | Not supported — save as .xlsx or .csv first |

---

## All Commands

```
generate-config           Create qtest-config.properties template
test-connection           Verify qTest connectivity
list-projects             Show available projects with IDs
list-fields               Show test case field definitions + allowed values
list-modules              Show module/folder tree with IDs
dry-run <file>            Validate everything without actually importing
import <file>             Import test cases (with confirmation prompt)

Options:
  --config <file>         Use a different config file
```

---

## Requirements

- **Java 11 or higher** (tested with Java 21)
- No Maven, no Gradle, no external JARs
- Single file: `QTestImporter.java`

### Compile and run:
```bash
javac QTestImporter.java
java QTestImporter <command> [args]
```

### Or run directly (Java 11+):
```bash
java QTestImporter.java <command> [args]
```
