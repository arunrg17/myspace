import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.*;
import java.util.zip.*;

public class QTestImporter {

    private static final String VERSION = "1.0.0";
    private static final int BATCH_DELAY_MS = 500;
    private static final int HTTP_TIMEOUT_MS = 30000;

    private String baseUrl;
    private String token;
    private String tokenType;
    private long projectId;
    private Long parentModuleId;
    private List<Map<String, String>> fieldDefs;

    // ALM Excel headers from user's screenshot
    private static final String[] ALM_HEADERS = {
        "Test Case Name", "Application", "Designer", "Test Type", "Automation",
        "Priority", "Module", "Test Category", "Status", "Regression Candidate",
        "Creation Date", "Classification", "Project", "Program", "Test Mode",
        "Description", "Test Data Req.", "Prerequisites", "Comments",
        "Number of Steps", "Step Name", "Step Description", "Expected Result",
        "Requirement Coverage", "Test Lab Path"
    };

    // Default mapping: ALM header -> qTest field
    private static final Map<String, String> DEFAULT_MAPPING = new LinkedHashMap<>();
    static {
        DEFAULT_MAPPING.put("Test Case Name", "name");
        DEFAULT_MAPPING.put("Description", "description");
        DEFAULT_MAPPING.put("Prerequisites", "precondition");
        DEFAULT_MAPPING.put("Status", "Status");
        DEFAULT_MAPPING.put("Priority", "Priority");
        DEFAULT_MAPPING.put("Test Type", "Type");
        DEFAULT_MAPPING.put("Automation", "Automation");
        DEFAULT_MAPPING.put("Step Description", "step.description");
        DEFAULT_MAPPING.put("Expected Result", "step.expected");
        DEFAULT_MAPPING.put("Step Name", "step.name");
    }

    // ===================== MAIN =====================

    public static void main(String[] args) {
        printBanner();

        if (args.length < 1) {
            printUsage();
            System.exit(1);
        }

        String command = args[0].toLowerCase();
        QTestImporter importer = new QTestImporter();

        try {
            switch (command) {
                case "import":
                    if (args.length < 2) { log("ERROR", "Usage: import <excel-file.xlsx|csv>"); System.exit(1); }
                    importer.runImport(args);
                    break;
                case "test-connection":
                    importer.loadConfig(args);
                    importer.testConnection();
                    break;
                case "list-projects":
                    importer.loadConfig(args);
                    importer.listProjects();
                    break;
                case "list-fields":
                    importer.loadConfig(args);
                    importer.listFields();
                    break;
                case "list-modules":
                    importer.loadConfig(args);
                    importer.listModules();
                    break;
                case "generate-config":
                    importer.generateConfig();
                    break;
                case "dry-run":
                    if (args.length < 2) { log("ERROR", "Usage: dry-run <excel-file.xlsx|csv>"); System.exit(1); }
                    importer.runDryRun(args);
                    break;
                default:
                    log("ERROR", "Unknown command: " + command);
                    printUsage();
                    System.exit(1);
            }
        } catch (Exception e) {
            log("ERROR", e.getMessage());
            System.exit(1);
        }
    }

    // ===================== CONFIG =====================

    private Properties loadConfig(String[] args) throws Exception {
        String configFile = "qtest-config.properties";
        for (int i = 0; i < args.length - 1; i++) {
            if ("--config".equals(args[i])) configFile = args[i + 1];
        }

        Properties props = new Properties();
        File f = new File(configFile);
        if (!f.exists()) {
            throw new Exception("Config file not found: " + configFile + "\nRun 'generate-config' to create one.");
        }
        try (FileInputStream fis = new FileInputStream(f)) {
            props.load(fis);
        }

        baseUrl = requireProp(props, "qtest.url").replaceAll("/+$", "");
        token = requireProp(props, "qtest.token");
        tokenType = props.getProperty("qtest.token.type", "bearer").trim();

        String pid = props.getProperty("qtest.project.id", "").trim();
        if (!pid.isEmpty()) projectId = Long.parseLong(pid);

        String mid = props.getProperty("qtest.module.id", "").trim();
        if (!mid.isEmpty()) parentModuleId = Long.parseLong(mid);

        return props;
    }

    private String requireProp(Properties p, String key) throws Exception {
        String v = p.getProperty(key, "").trim();
        if (v.isEmpty()) throw new Exception("Missing required property: " + key);
        return v;
    }

    private void generateConfig() throws Exception {
        String filename = "qtest-config.properties";
        if (new File(filename).exists()) {
            log("WARN", filename + " already exists. Overwrite? (y/n)");
            String ans = new Scanner(System.in).nextLine().trim().toLowerCase();
            if (!ans.equals("y")) { log("INFO", "Aborted."); return; }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("# qTest Importer Configuration\n");
        sb.append("# Generated on ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())).append("\n\n");
        sb.append("# qTest server URL (no trailing slash)\n");
        sb.append("qtest.url=https://your-org.qtestnet.com\n\n");
        sb.append("# Authentication token\n");
        sb.append("# Get it from: qTest > Resources > API & SDK > Bearer Token\n");
        sb.append("# Or use the UserContextToken from your browser session\n");
        sb.append("qtest.token=your-token-here\n\n");
        sb.append("# Token type: 'bearer' for API tokens, 'UserContextToken' for session tokens\n");
        sb.append("qtest.token.type=UserContextToken\n\n");
        sb.append("# Project ID (run 'list-projects' to find yours)\n");
        sb.append("qtest.project.id=\n\n");
        sb.append("# Target module/folder ID (optional, run 'list-modules' to browse)\n");
        sb.append("# If empty, test cases go to 'Created via API' module\n");
        sb.append("qtest.module.id=\n\n");
        sb.append("# Import settings\n");
        sb.append("import.batch.size=10\n");
        sb.append("import.batch.delay.ms=500\n\n");
        sb.append("# Field mapping (ALM header = qTest field)\n");
        sb.append("# Built-in fields: name, description, precondition\n");
        sb.append("# Step fields: step.description, step.expected, step.name\n");
        sb.append("# Property fields: use the qTest field label (e.g. Status, Priority, Type)\n");
        sb.append("# Use __skip__ to ignore a column\n");
        sb.append("# Unmapped columns are auto-skipped\n\n");
        sb.append("# Default mappings (uncomment/edit as needed):\n");
        for (Map.Entry<String, String> e : DEFAULT_MAPPING.entrySet()) {
            sb.append("mapping.").append(e.getKey()).append("=").append(e.getValue()).append("\n");
        }
        sb.append("\n# Additional ALM columns you can map:\n");
        for (String h : ALM_HEADERS) {
            if (!DEFAULT_MAPPING.containsKey(h)) {
                sb.append("# mapping.").append(h).append("=__skip__\n");
            }
        }

        Files.writeString(Path.of(filename), sb.toString());
        log("OK", "Config file created: " + filename);
        log("INFO", "Edit it with your qTest URL, token, and project ID, then run:");
        log("INFO", "  java QTestImporter test-connection");
        log("INFO", "  java QTestImporter list-projects");
        log("INFO", "  java QTestImporter import your-file.xlsx");
    }

    // ===================== HTTP CLIENT =====================

    private String httpRequest(String method, String path, String body) throws Exception {
        URL url = new URL(baseUrl + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod(method);
        conn.setConnectTimeout(HTTP_TIMEOUT_MS);
        conn.setReadTimeout(HTTP_TIMEOUT_MS);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json");

        if ("UserContextToken".equalsIgnoreCase(tokenType)) {
            conn.setRequestProperty("Authorization", "UserContextToken " + token);
        } else {
            conn.setRequestProperty("Authorization", "bearer " + token);
        }

        if (body != null && !body.isEmpty()) {
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
        }

        int code = conn.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        String response = "";
        if (is != null) {
            response = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            is.close();
        }

        if (code < 200 || code >= 300) {
            throw new Exception("HTTP " + code + ": " + truncate(response, 500));
        }
        return response;
    }

    // ===================== COMMANDS =====================

    private void testConnection() throws Exception {
        log("INFO", "Testing connection to " + baseUrl + " ...");
        log("INFO", "Token type: " + tokenType);
        String resp = httpRequest("GET", "/api/v3/projects", null);
        List<Map<String, Object>> projects = parseJsonArray(resp);
        log("OK", "Connected! Found " + projects.size() + " project(s).");
    }

    private void listProjects() throws Exception {
        String resp = httpRequest("GET", "/api/v3/projects", null);
        List<Map<String, Object>> projects = parseJsonArray(resp);
        log("INFO", "Projects (" + projects.size() + "):");
        System.out.println();
        System.out.printf("  %-12s %-50s %s%n", "ID", "NAME", "STATUS");
        System.out.printf("  %-12s %-50s %s%n", "----", "----", "------");
        for (Map<String, Object> p : projects) {
            System.out.printf("  %-12s %-50s %s%n",
                str(p.get("id")), truncate(str(p.get("name")), 48),
                str(p.get("status_id")));
        }
        System.out.println();
    }

    private void listFields() throws Exception {
        if (projectId == 0) throw new Exception("Set qtest.project.id in config first");
        fieldDefs = fetchFieldDefs();
        log("INFO", "Test Case fields for project " + projectId + ":");
        System.out.println();
        System.out.printf("  %-12s %-30s %-15s %s%n", "FIELD_ID", "LABEL", "TYPE", "REQUIRED");
        System.out.printf("  %-12s %-30s %-15s %s%n", "--------", "-----", "----", "--------");
        for (Map<String, String> f : fieldDefs) {
            System.out.printf("  %-12s %-30s %-15s %s%n",
                f.get("id"), truncate(f.get("label"), 28),
                f.get("type"), f.get("required"));
            String allowed = f.get("allowed");
            if (allowed != null && !allowed.isEmpty()) {
                System.out.println("             Values: " + truncate(allowed, 80));
            }
        }
        System.out.println();
    }

    private void listModules() throws Exception {
        if (projectId == 0) throw new Exception("Set qtest.project.id in config first");
        String resp = httpRequest("GET", "/api/v3/projects/" + projectId + "/modules", null);
        List<Map<String, Object>> modules = parseJsonArray(resp);
        log("INFO", "Modules/folders for project " + projectId + ":");
        System.out.println();
        printModuleTree(modules, 0);
        System.out.println();
    }

    private void printModuleTree(List<Map<String, Object>> modules, int depth) {
        for (Map<String, Object> m : modules) {
            String indent = "  ".repeat(depth + 1);
            System.out.printf("%s%-8s %s%n", indent, str(m.get("id")), str(m.get("name")));
            Object children = m.get("children");
            if (children instanceof List) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> kids = (List<Map<String, Object>>) children;
                printModuleTree(kids, depth + 1);
            }
        }
    }

    // ===================== IMPORT =====================

    private void runImport(String[] args) throws Exception {
        Properties props = loadConfig(args);
        if (projectId == 0) throw new Exception("Set qtest.project.id in config first");

        String filePath = args[1];
        int batchSize = Integer.parseInt(props.getProperty("import.batch.size", "10").trim());

        log("INFO", "Loading field definitions...");
        fieldDefs = fetchFieldDefs();

        Map<String, String> mapping = loadMapping(props);
        log("INFO", "Reading file: " + filePath);
        List<String[]> rows = readFile(filePath);
        if (rows.size() < 2) throw new Exception("File has no data rows");

        String[] headers = rows.get(0);
        List<String[]> dataRows = rows.subList(1, rows.size());
        log("INFO", "Found " + dataRows.size() + " data row(s), " + headers.length + " column(s)");

        mapping = resolveMapping(headers, mapping, props);
        printMappingSummary(headers, mapping);

        List<TestCase> testCases = buildTestCases(headers, dataRows, mapping);
        log("INFO", "Built " + testCases.size() + " test case(s) from " + dataRows.size() + " row(s)");

        System.out.println();
        log("CONFIRM", "Import " + testCases.size() + " test cases to project " + projectId + "?");
        if (parentModuleId != null) log("INFO", "  Target module ID: " + parentModuleId);
        System.out.print("  Type 'yes' to proceed: ");
        String ans = new Scanner(System.in).nextLine().trim().toLowerCase();
        if (!ans.equals("yes")) { log("INFO", "Aborted."); return; }

        doImport(testCases, batchSize, false);
    }

    private void runDryRun(String[] args) throws Exception {
        Properties props = loadConfig(args);
        if (projectId == 0) throw new Exception("Set qtest.project.id in config first");

        log("INFO", "Loading field definitions...");
        fieldDefs = fetchFieldDefs();

        Map<String, String> mapping = loadMapping(props);
        String filePath = args[1];
        List<String[]> rows = readFile(filePath);
        if (rows.size() < 2) throw new Exception("File has no data rows");

        String[] headers = rows.get(0);
        List<String[]> dataRows = rows.subList(1, rows.size());
        mapping = resolveMapping(headers, mapping, props);
        printMappingSummary(headers, mapping);

        List<TestCase> testCases = buildTestCases(headers, dataRows, mapping);

        System.out.println();
        log("DRY-RUN", "Validating " + testCases.size() + " test case(s)...");
        System.out.println();

        int valid = 0, invalid = 0;
        for (int i = 0; i < testCases.size(); i++) {
            TestCase tc = testCases.get(i);
            List<String> errors = validateTestCase(tc);
            if (errors.isEmpty()) {
                valid++;
                System.out.printf("  [%3d] OK   %s (%d steps)%n", i + 1, truncate(tc.name, 60), tc.steps.size());
            } else {
                invalid++;
                System.out.printf("  [%3d] FAIL %s%n", i + 1, truncate(tc.name, 60));
                for (String err : errors) System.out.println("           " + err);
            }
        }
        System.out.println();
        log("DRY-RUN", "Valid: " + valid + ", Invalid: " + invalid + ", Total: " + testCases.size());

        String jsonSample = testCases.isEmpty() ? "{}" : buildJson(testCases.get(0));
        System.out.println();
        log("INFO", "Sample JSON payload (first test case):");
        System.out.println(jsonSample);
    }

    private void doImport(List<TestCase> testCases, int batchSize, boolean dryRun) throws Exception {
        int total = testCases.size(), ok = 0, fail = 0;
        List<String> errors = new ArrayList<>();
        long start = System.currentTimeMillis();

        for (int i = 0; i < total; i++) {
            TestCase tc = testCases.get(i);
            try {
                String json = buildJson(tc);
                String resp = httpRequest("POST",
                    "/api/v3/projects/" + projectId + "/test-cases", json);

                Map<String, Object> created = parseJsonObject(resp);
                String pid = str(created.get("pid"));
                ok++;
                System.out.printf("  [%3d/%d] OK   %s -> %s%n", i + 1, total, truncate(tc.name, 50), pid);

            } catch (Exception e) {
                fail++;
                String msg = truncate(e.getMessage(), 120);
                errors.add(tc.name + ": " + msg);
                System.out.printf("  [%3d/%d] FAIL %s: %s%n", i + 1, total, truncate(tc.name, 50), msg);
            }

            if (i < total - 1 && (i + 1) % batchSize == 0) {
                log("INFO", "Batch pause (" + BATCH_DELAY_MS + "ms)...");
                Thread.sleep(BATCH_DELAY_MS);
            }
        }

        long elapsed = (System.currentTimeMillis() - start) / 1000;
        System.out.println();
        log("DONE", String.format("Imported: %d, Failed: %d, Total: %d, Time: %ds", ok, fail, total, elapsed));

        if (!errors.isEmpty()) {
            String errFile = "import-errors-" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date()) + ".log";
            Files.writeString(Path.of(errFile), String.join("\n", errors));
            log("INFO", "Error details saved to: " + errFile);
        }
    }

    // ===================== FIELD DEFINITIONS =====================

    private List<Map<String, String>> fetchFieldDefs() throws Exception {
        String resp = httpRequest("GET",
            "/api/v3/projects/" + projectId + "/settings/test-cases/fields", null);
        List<Map<String, Object>> raw = parseJsonArray(resp);
        List<Map<String, String>> result = new ArrayList<>();

        for (Map<String, Object> f : raw) {
            Map<String, String> fd = new LinkedHashMap<>();
            fd.put("id", str(f.get("id")));
            fd.put("label", str(f.get("label")));
            fd.put("type", str(f.get("original_name")));
            fd.put("required", str(f.get("required")));

            Object av = f.get("allowed_values");
            if (av instanceof List) {
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> vals = (List<Map<String, Object>>) av;
                String allowed = vals.stream()
                    .map(v -> str(v.get("label")) + "(" + str(v.get("value")) + ")")
                    .collect(Collectors.joining(", "));
                fd.put("allowed", allowed);
                fd.put("_values_json", serializeAllowedValues(vals));
            }
            result.add(fd);
        }
        return result;
    }

    private String serializeAllowedValues(List<Map<String, Object>> vals) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < vals.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append("{\"label\":").append(jsonStr(str(vals.get(i).get("label"))))
              .append(",\"value\":").append(str(vals.get(i).get("value"))).append("}");
        }
        return sb.append("]").toString();
    }

    // ===================== MAPPING =====================

    private Map<String, String> loadMapping(Properties props) {
        Map<String, String> mapping = new LinkedHashMap<>();
        for (String key : props.stringPropertyNames()) {
            if (key.startsWith("mapping.")) {
                String almHeader = key.substring("mapping.".length());
                String qtField = props.getProperty(key).trim();
                if (!qtField.isEmpty()) mapping.put(almHeader, qtField);
            }
        }
        if (mapping.isEmpty()) mapping.putAll(DEFAULT_MAPPING);
        return mapping;
    }

    private Map<String, String> resolveMapping(String[] headers, Map<String, String> mapping, Properties props) {
        Map<String, String> resolved = new LinkedHashMap<>();
        for (String h : headers) {
            String ht = h.trim();
            if (mapping.containsKey(ht)) {
                resolved.put(ht, mapping.get(ht));
            } else {
                // Try case-insensitive match
                for (Map.Entry<String, String> e : mapping.entrySet()) {
                    if (e.getKey().equalsIgnoreCase(ht)) {
                        resolved.put(ht, e.getValue());
                        break;
                    }
                }
                if (!resolved.containsKey(ht)) {
                    resolved.put(ht, "__skip__");
                }
            }
        }
        return resolved;
    }

    private void printMappingSummary(String[] headers, Map<String, String> mapping) {
        System.out.println();
        log("INFO", "Field Mapping:");
        System.out.printf("  %-30s  ->  %s%n", "EXCEL COLUMN", "QTEST FIELD");
        System.out.printf("  %-30s  ->  %s%n", "------------", "-----------");
        for (String h : headers) {
            String target = mapping.getOrDefault(h.trim(), "__skip__");
            String marker = "__skip__".equals(target) ? " (skipped)" : "";
            System.out.printf("  %-30s  ->  %s%s%n", truncate(h, 28), target, marker);
        }
    }

    // ===================== TEST CASE BUILDER =====================

    static class TestCase {
        String name = "";
        String description = "";
        String precondition = "";
        Map<String, String> properties = new LinkedHashMap<>();
        List<TestStep> steps = new ArrayList<>();
    }

    static class TestStep {
        String name = "";
        String description = "";
        String expected = "";
    }

    private List<TestCase> buildTestCases(String[] headers, List<String[]> rows, Map<String, String> mapping) {
        // Group rows by test case name (ALM exports have multiple rows per TC for steps)
        Map<String, List<String[]>> grouped = new LinkedHashMap<>();
        int nameIdx = -1;
        for (int i = 0; i < headers.length; i++) {
            String target = mapping.getOrDefault(headers[i].trim(), "__skip__");
            if ("name".equals(target)) { nameIdx = i; break; }
        }

        if (nameIdx < 0) {
            // If no name column mapped, treat each row as a separate test case
            log("WARN", "No column mapped to 'name'. Each row will be a separate test case.");
            for (int i = 0; i < rows.size(); i++) {
                ArrayList<String[]> single = new ArrayList<>();
                single.add(rows.get(i));
                grouped.put("Row_" + (i + 1), single);
            }
        } else {
            for (String[] row : rows) {
                String name = (nameIdx < row.length) ? row[nameIdx].trim() : "";
                if (name.isEmpty()) name = "Unnamed_" + (grouped.size() + 1);
                grouped.computeIfAbsent(name, k -> new ArrayList<>()).add(row);
            }
        }

        List<TestCase> testCases = new ArrayList<>();
        for (Map.Entry<String, List<String[]>> entry : grouped.entrySet()) {
            TestCase tc = new TestCase();
            tc.name = entry.getKey();
            String[] firstRow = entry.getValue().get(0);

            // Map non-step fields from first row
            for (int i = 0; i < headers.length; i++) {
                String target = mapping.getOrDefault(headers[i].trim(), "__skip__");
                String value = (i < firstRow.length) ? firstRow[i].trim() : "";
                if (value.isEmpty() || "__skip__".equals(target)) continue;

                switch (target) {
                    case "name": break; // already handled
                    case "description": tc.description = value; break;
                    case "precondition": tc.precondition = value; break;
                    case "step.description": case "step.expected": case "step.name": break; // handled below
                    default: tc.properties.put(target, value); break;
                }
            }

            // Build steps from all rows in this group
            int stepDescIdx = -1, stepExpIdx = -1, stepNameIdx = -1;
            for (int i = 0; i < headers.length; i++) {
                String target = mapping.getOrDefault(headers[i].trim(), "__skip__");
                if ("step.description".equals(target)) stepDescIdx = i;
                if ("step.expected".equals(target)) stepExpIdx = i;
                if ("step.name".equals(target)) stepNameIdx = i;
            }

            for (String[] row : entry.getValue()) {
                String stepDesc = (stepDescIdx >= 0 && stepDescIdx < row.length) ? row[stepDescIdx].trim() : "";
                String stepExp = (stepExpIdx >= 0 && stepExpIdx < row.length) ? row[stepExpIdx].trim() : "";
                String stepName = (stepNameIdx >= 0 && stepNameIdx < row.length) ? row[stepNameIdx].trim() : "";

                if (!stepDesc.isEmpty() || !stepExp.isEmpty()) {
                    TestStep step = new TestStep();
                    step.description = stepDesc.isEmpty() ? stepName : stepDesc;
                    step.expected = stepExp;
                    step.name = stepName;
                    tc.steps.add(step);
                }
            }

            testCases.add(tc);
        }
        return testCases;
    }

    private List<String> validateTestCase(TestCase tc) {
        List<String> errors = new ArrayList<>();
        if (tc.name == null || tc.name.isEmpty()) errors.add("Missing name");
        if (tc.name != null && tc.name.length() > 500) errors.add("Name too long (>" + 500 + " chars)");
        return errors;
    }

    // ===================== JSON BUILDER =====================

    private String buildJson(TestCase tc) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"name\":").append(jsonStr(tc.name));

        if (!tc.description.isEmpty()) {
            sb.append(",\"description\":").append(jsonStr(tc.description));
        }
        if (!tc.precondition.isEmpty()) {
            sb.append(",\"precondition\":").append(jsonStr(tc.precondition));
        }
        if (parentModuleId != null) {
            sb.append(",\"parent_id\":").append(parentModuleId);
        }

        // Properties
        if (!tc.properties.isEmpty()) {
            sb.append(",\"properties\":[");
            boolean first = true;
            for (Map.Entry<String, String> e : tc.properties.entrySet()) {
                String fieldLabel = e.getKey();
                String rawValue = e.getValue();
                Map<String, String> fd = findFieldDef(fieldLabel);
                if (fd == null) {
                    log("WARN", "Unknown qTest field: " + fieldLabel + " (skipping)");
                    continue;
                }
                if (!first) sb.append(",");
                first = false;
                sb.append("{\"field_id\":").append(fd.get("id"));

                // Resolve allowed value
                String resolvedValue = resolveFieldValue(fd, rawValue);
                if (resolvedValue != null) {
                    // Check if it's a numeric value ID
                    try {
                        Long.parseLong(resolvedValue);
                        sb.append(",\"field_value\":").append(resolvedValue);
                    } catch (NumberFormatException ex) {
                        sb.append(",\"field_value\":").append(jsonStr(resolvedValue));
                    }
                } else {
                    sb.append(",\"field_value\":").append(jsonStr(rawValue));
                }
                sb.append("}");
            }
            sb.append("]");
        }

        // Test steps
        if (!tc.steps.isEmpty()) {
            sb.append(",\"test_steps\":[");
            for (int i = 0; i < tc.steps.size(); i++) {
                if (i > 0) sb.append(",");
                TestStep s = tc.steps.get(i);
                sb.append("{\"description\":").append(jsonStr(s.description));
                sb.append(",\"expected\":").append(jsonStr(s.expected));
                sb.append(",\"order\":").append(i);
                sb.append("}");
            }
            sb.append("]");
        }

        sb.append("}");
        return sb.toString();
    }

    private Map<String, String> findFieldDef(String label) {
        if (fieldDefs == null) return null;
        for (Map<String, String> fd : fieldDefs) {
            if (label.equalsIgnoreCase(fd.get("label"))) return fd;
        }
        return null;
    }

    private String resolveFieldValue(Map<String, String> fd, String rawValue) {
        String allowed = fd.get("allowed");
        if (allowed == null || allowed.isEmpty()) return null;
        String valuesJson = fd.get("_values_json");
        if (valuesJson == null) return null;

        // Parse allowed values and match by label (case-insensitive)
        // Format: [{"label":"...","value":N},...]
        String target = rawValue.trim().toLowerCase();
        int idx = 0;
        while (idx < valuesJson.length()) {
            int labelStart = valuesJson.indexOf("\"label\":\"", idx);
            if (labelStart < 0) break;
            labelStart += 9;
            int labelEnd = valuesJson.indexOf("\"", labelStart);
            if (labelEnd < 0) break;
            String label = valuesJson.substring(labelStart, labelEnd);

            int valueStart = valuesJson.indexOf("\"value\":", labelEnd);
            if (valueStart < 0) break;
            valueStart += 8;
            int valueEnd = valuesJson.indexOf("}", valueStart);
            if (valueEnd < 0) break;
            String value = valuesJson.substring(valueStart, valueEnd).trim();

            if (label.toLowerCase().equals(target)) return value;
            idx = valueEnd + 1;
        }
        return null;
    }

    // ===================== FILE READING =====================

    private List<String[]> readFile(String filePath) throws Exception {
        File file = new File(filePath);
        if (!file.exists()) throw new Exception("File not found: " + filePath);

        String name = file.getName().toLowerCase();
        if (name.endsWith(".csv") || name.endsWith(".tsv")) {
            return readCsv(file, name.endsWith(".tsv") ? '\t' : ',');
        } else if (name.endsWith(".xlsx")) {
            return readXlsx(file);
        } else if (name.endsWith(".xls")) {
            throw new Exception("Old .xls format not supported. Save as .xlsx or .csv first.");
        } else {
            throw new Exception("Unsupported file format. Use .xlsx or .csv");
        }
    }

    private List<String[]> readCsv(File file, char delimiter) throws Exception {
        List<String[]> rows = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                rows.add(parseCsvLine(line, delimiter));
            }
        }
        log("INFO", "Read " + rows.size() + " row(s) from CSV");
        return rows;
    }

    private String[] parseCsvLine(String line, char delim) {
        List<String> fields = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        current.append('"');
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    current.append(c);
                }
            } else {
                if (c == '"') {
                    inQuotes = true;
                } else if (c == delim) {
                    fields.add(current.toString());
                    current = new StringBuilder();
                } else {
                    current.append(c);
                }
            }
        }
        fields.add(current.toString());
        return fields.toArray(new String[0]);
    }

    // Minimal XLSX reader using only java.util.zip + javax.xml
    private List<String[]> readXlsx(File file) throws Exception {
        log("INFO", "Reading XLSX (built-in reader)...");

        Map<Integer, String> sharedStrings = new LinkedHashMap<>();
        List<String[]> rows = new ArrayList<>();

        try (ZipFile zip = new ZipFile(file)) {
            // 1. Read shared strings
            ZipEntry ssEntry = zip.getEntry("xl/sharedStrings.xml");
            if (ssEntry != null) {
                String ssXml = new String(zip.getInputStream(ssEntry).readAllBytes(), StandardCharsets.UTF_8);
                int idx = 0;
                int siIdx = 0;
                while (true) {
                    int siStart = ssXml.indexOf("<si", idx);
                    if (siStart < 0) break;
                    int siEnd = ssXml.indexOf("</si>", siStart);
                    if (siEnd < 0) break;
                    String si = ssXml.substring(siStart, siEnd);

                    // Extract all <t> text within this <si>
                    StringBuilder text = new StringBuilder();
                    int tIdx = 0;
                    while (true) {
                        int tStart = si.indexOf("<t", tIdx);
                        if (tStart < 0) break;
                        int tClose = si.indexOf(">", tStart);
                        if (tClose < 0) break;
                        int tEnd = si.indexOf("</t>", tClose);
                        if (tEnd < 0) break;
                        text.append(si, tClose + 1, tEnd);
                        tIdx = tEnd + 4;
                    }
                    sharedStrings.put(siIdx++, xmlDecode(text.toString()));
                    idx = siEnd + 5;
                }
            }

            // 2. Read first sheet
            ZipEntry sheetEntry = zip.getEntry("xl/worksheets/sheet1.xml");
            if (sheetEntry == null) throw new Exception("Cannot find sheet1 in XLSX");
            String sheetXml = new String(zip.getInputStream(sheetEntry).readAllBytes(), StandardCharsets.UTF_8);

            // Parse rows
            int rIdx = 0;
            while (true) {
                int rowStart = sheetXml.indexOf("<row", rIdx);
                if (rowStart < 0) break;
                int rowEnd = sheetXml.indexOf("</row>", rowStart);
                if (rowEnd < 0) break;
                String rowXml = sheetXml.substring(rowStart, rowEnd);

                TreeMap<Integer, String> cells = new TreeMap<>();
                int cIdx = 0;
                while (true) {
                    int cStart = rowXml.indexOf("<c ", cIdx);
                    if (cStart < 0) break;
                    int cEnd = rowXml.indexOf("</c>", cStart);
                    if (cEnd < 0) {
                        // Self-closing <c ... />
                        cEnd = rowXml.indexOf("/>", cStart);
                        if (cEnd < 0) break;
                        cEnd += 2;
                    } else {
                        cEnd += 4;
                    }
                    String cellXml = rowXml.substring(cStart, cEnd);

                    // Get cell reference (e.g. "A1", "B1")
                    int rAttr = cellXml.indexOf("r=\"");
                    String ref = "";
                    if (rAttr >= 0) {
                        int rEnd2 = cellXml.indexOf("\"", rAttr + 3);
                        ref = cellXml.substring(rAttr + 3, rEnd2);
                    }
                    int colIdx = cellRefToIndex(ref);

                    // Get type
                    boolean isSharedString = cellXml.contains("t=\"s\"");
                    boolean isInlineStr = cellXml.contains("t=\"inlineStr\"");

                    // Get value
                    String value = "";
                    if (isInlineStr) {
                        int tStart = cellXml.indexOf("<t");
                        if (tStart >= 0) {
                            int tClose = cellXml.indexOf(">", tStart);
                            int tEnd = cellXml.indexOf("</t>", tClose);
                            if (tClose >= 0 && tEnd >= 0) value = xmlDecode(cellXml.substring(tClose + 1, tEnd));
                        }
                    } else {
                        int vStart = cellXml.indexOf("<v>");
                        int vEnd = cellXml.indexOf("</v>");
                        if (vStart >= 0 && vEnd >= 0) {
                            String raw = cellXml.substring(vStart + 3, vEnd).trim();
                            if (isSharedString) {
                                try { value = sharedStrings.getOrDefault(Integer.parseInt(raw), raw); }
                                catch (NumberFormatException e) { value = raw; }
                            } else {
                                value = raw;
                            }
                        }
                    }

                    cells.put(colIdx, value);
                    cIdx = cEnd;
                }

                if (!cells.isEmpty()) {
                    int maxCol = cells.lastEntry().getKey();
                    String[] row = new String[maxCol + 1];
                    Arrays.fill(row, "");
                    for (Map.Entry<Integer, String> e : cells.entrySet()) {
                        row[e.getKey()] = e.getValue();
                    }
                    rows.add(row);
                }
                rIdx = rowEnd + 6;
            }
        }

        log("INFO", "Read " + rows.size() + " row(s) from XLSX");
        return rows;
    }

    private int cellRefToIndex(String ref) {
        int col = 0;
        for (int i = 0; i < ref.length(); i++) {
            char c = ref.charAt(i);
            if (c >= 'A' && c <= 'Z') {
                col = col * 26 + (c - 'A' + 1);
            } else break;
        }
        return col - 1;
    }

    private String xmlDecode(String s) {
        return s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace("&apos;", "'");
    }

    // ===================== MINI JSON PARSER =====================
    // Lightweight JSON handling without external libraries

    private String jsonStr(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append("\"").toString();
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parseJsonArray(String json) {
        return (List<Map<String, Object>>) parseJsonValue(json.trim(), new int[]{0});
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseJsonObject(String json) {
        return (Map<String, Object>) parseJsonValue(json.trim(), new int[]{0});
    }

    private Object parseJsonValue(String json, int[] pos) {
        skipWs(json, pos);
        if (pos[0] >= json.length()) return null;
        char c = json.charAt(pos[0]);

        if (c == '{') return parseObject(json, pos);
        if (c == '[') return parseArray(json, pos);
        if (c == '"') return parseString(json, pos);
        if (c == 't') { pos[0] += 4; return Boolean.TRUE; }
        if (c == 'f') { pos[0] += 5; return Boolean.FALSE; }
        if (c == 'n') { pos[0] += 4; return null; }
        return parseNumber(json, pos);
    }

    private Map<String, Object> parseObject(String json, int[] pos) {
        Map<String, Object> map = new LinkedHashMap<>();
        pos[0]++; // skip {
        skipWs(json, pos);
        if (pos[0] < json.length() && json.charAt(pos[0]) == '}') { pos[0]++; return map; }

        while (pos[0] < json.length()) {
            skipWs(json, pos);
            String key = parseString(json, pos);
            skipWs(json, pos);
            pos[0]++; // skip :
            Object value = parseJsonValue(json, pos);
            map.put(key, value);
            skipWs(json, pos);
            if (pos[0] < json.length() && json.charAt(pos[0]) == ',') pos[0]++;
            else break;
        }
        if (pos[0] < json.length() && json.charAt(pos[0]) == '}') pos[0]++;
        return map;
    }

    private List<Object> parseArray(String json, int[] pos) {
        List<Object> list = new ArrayList<>();
        pos[0]++; // skip [
        skipWs(json, pos);
        if (pos[0] < json.length() && json.charAt(pos[0]) == ']') { pos[0]++; return list; }

        while (pos[0] < json.length()) {
            list.add(parseJsonValue(json, pos));
            skipWs(json, pos);
            if (pos[0] < json.length() && json.charAt(pos[0]) == ',') pos[0]++;
            else break;
        }
        if (pos[0] < json.length() && json.charAt(pos[0]) == ']') pos[0]++;
        return list;
    }

    private String parseString(String json, int[] pos) {
        pos[0]++; // skip opening "
        StringBuilder sb = new StringBuilder();
        while (pos[0] < json.length()) {
            char c = json.charAt(pos[0]++);
            if (c == '"') break;
            if (c == '\\' && pos[0] < json.length()) {
                char esc = json.charAt(pos[0]++);
                switch (esc) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u':
                        if (pos[0] + 4 <= json.length()) {
                            sb.append((char) Integer.parseInt(json.substring(pos[0], pos[0] + 4), 16));
                            pos[0] += 4;
                        }
                        break;
                    default: sb.append(esc);
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private Object parseNumber(String json, int[] pos) {
        int start = pos[0];
        boolean isFloat = false;
        while (pos[0] < json.length()) {
            char c = json.charAt(pos[0]);
            if (c == '.' || c == 'e' || c == 'E') isFloat = true;
            if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') pos[0]++;
            else break;
        }
        String num = json.substring(start, pos[0]);
        if (isFloat) return Double.parseDouble(num);
        try { return Long.parseLong(num); }
        catch (NumberFormatException e) { return Double.parseDouble(num); }
    }

    private void skipWs(String json, int[] pos) {
        while (pos[0] < json.length() && Character.isWhitespace(json.charAt(pos[0]))) pos[0]++;
    }

    // ===================== UTILS =====================

    private static String str(Object o) { return o == null ? "" : String.valueOf(o); }
    private static String truncate(String s, int max) { return s.length() <= max ? s : s.substring(0, max - 3) + "..."; }

    private static void log(String level, String msg) {
        String ts = new SimpleDateFormat("HH:mm:ss").format(new Date());
        String color = switch (level) {
            case "OK" -> "\033[32m";
            case "ERROR" -> "\033[31m";
            case "WARN" -> "\033[33m";
            case "DRY-RUN" -> "\033[36m";
            case "CONFIRM" -> "\033[35m";
            default -> "\033[37m";
        };
        System.out.printf("%s [%s%-7s\033[0m] %s%n", ts, color, level, msg);
    }

    private static void printBanner() {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════╗");
        System.out.println("  ║   qTest Test Case Importer v" + VERSION + "        ║");
        System.out.println("  ║   ALM Excel -> qTest Migration          ║");
        System.out.println("  ╚══════════════════════════════════════════╝");
        System.out.println();
    }

    private static void printUsage() {
        System.out.println("  COMMANDS:");
        System.out.println();
        System.out.println("    generate-config           Create qtest-config.properties template");
        System.out.println("    test-connection            Verify qTest connectivity");
        System.out.println("    list-projects              Show available projects");
        System.out.println("    list-fields                Show test case field definitions");
        System.out.println("    list-modules               Show module/folder tree");
        System.out.println("    dry-run <file.xlsx|csv>    Validate without importing");
        System.out.println("    import <file.xlsx|csv>     Import test cases");
        System.out.println();
        System.out.println("  OPTIONS:");
        System.out.println("    --config <file>            Config file (default: qtest-config.properties)");
        System.out.println();
        System.out.println("  QUICK START:");
        System.out.println("    1. java QTestImporter generate-config");
        System.out.println("    2. Edit qtest-config.properties with your URL/token/project");
        System.out.println("    3. java QTestImporter test-connection");
        System.out.println("    4. java QTestImporter list-fields");
        System.out.println("    5. java QTestImporter dry-run exported-tests.xlsx");
        System.out.println("    6. java QTestImporter import exported-tests.xlsx");
        System.out.println();
    }
}
