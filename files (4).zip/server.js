const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const url = require("url");

const PORT = 3847;
const MAX_BODY = 10 * 1024 * 1024;

function sanitize(s) {
  if (typeof s !== "string") return "";
  return s.replace(/[\x00-\x1f]/g, "").slice(0, 8192);
}

function validateTargetUrl(raw) {
  try {
    const u = new URL(raw);
    if (u.protocol !== "https:" && u.protocol !== "http:") return null;
    if (u.hostname === "localhost" || u.hostname === "127.0.0.1" || u.hostname === "0.0.0.0") return null;
    return u;
  } catch {
    return null;
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY) { req.destroy(); reject(new Error("Body too large")); return; }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, Accept, Cookie",
    "Access-Control-Expose-Headers": "Set-Cookie",
    "Access-Control-Max-Age": "86400",
  };
}

function proxyRequest(targetUrl, method, headers, body) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(targetUrl);
    const mod = parsed.protocol === "https:" ? https : http;
    const proxyHeaders = {};
    const forwardKeys = ["content-type", "authorization", "accept", "cookie"];
    for (const key of forwardKeys) {
      if (headers[key]) proxyHeaders[key] = headers[key];
    }
    proxyHeaders["host"] = parsed.host;

    const opts = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === "https:" ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: method,
      headers: proxyHeaders,
      rejectUnauthorized: false,
    };

    const proxyReq = mod.request(opts, (proxyRes) => {
      const chunks = [];
      proxyRes.on("data", (c) => chunks.push(c));
      proxyRes.on("end", () => {
        const responseHeaders = {};
        const passHeaders = ["content-type", "set-cookie"];
        for (const key of passHeaders) {
          if (proxyRes.headers[key]) responseHeaders[key] = proxyRes.headers[key];
        }
        resolve({
          statusCode: proxyRes.statusCode,
          headers: responseHeaders,
          body: Buffer.concat(chunks),
        });
      });
    });

    proxyReq.on("error", reject);
    proxyReq.setTimeout(30000, () => { proxyReq.destroy(); reject(new Error("Timeout")); });
    if (body && body.length > 0) proxyReq.write(body);
    proxyReq.end();
  });
}

const cookieJar = new Map();

const server = http.createServer(async (req, res) => {
  const cors = corsHeaders();

  if (req.method === "OPTIONS") {
    res.writeHead(204, cors);
    res.end();
    return;
  }

  const parsed = url.parse(req.url, true);

  if (parsed.pathname === "/" || parsed.pathname === "/index.html") {
    const htmlPath = path.join(__dirname, "migration-suite.html");
    try {
      const html = fs.readFileSync(htmlPath, "utf-8");
      res.writeHead(200, { ...cors, "Content-Type": "text/html; charset=utf-8" });
      res.end(html);
    } catch {
      res.writeHead(404, cors);
      res.end("migration-suite.html not found. Place it next to server.js");
    }
    return;
  }

  if (parsed.pathname === "/api/proxy") {
    try {
      const body = await readBody(req);
      let payload;
      try {
        payload = JSON.parse(body.toString("utf-8"));
      } catch {
        res.writeHead(400, { ...cors, "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Invalid JSON body" }));
        return;
      }

      const { targetUrl, method, headers: fwdHeaders, body: fwdBody, sessionId } = payload;

      if (!targetUrl || typeof targetUrl !== "string") {
        res.writeHead(400, { ...cors, "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Missing targetUrl" }));
        return;
      }

      const validUrl = validateTargetUrl(targetUrl);
      if (!validUrl) {
        res.writeHead(400, { ...cors, "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Invalid or blocked target URL" }));
        return;
      }

      const proxyHeadersClean = {};
      if (fwdHeaders && typeof fwdHeaders === "object") {
        const allowed = ["content-type", "authorization", "accept"];
        for (const k of allowed) {
          if (fwdHeaders[k]) proxyHeadersClean[k] = sanitize(String(fwdHeaders[k]));
        }
      }

      if (sessionId && cookieJar.has(sessionId)) {
        proxyHeadersClean["cookie"] = cookieJar.get(sessionId);
      }

      const proxyBody = fwdBody ? Buffer.from(fwdBody, "utf-8") : Buffer.alloc(0);

      const result = await proxyRequest(
        targetUrl,
        (method || "GET").toUpperCase(),
        proxyHeadersClean,
        proxyBody
      );

      if (result.headers["set-cookie"] && sessionId) {
        const existing = cookieJar.get(sessionId) || "";
        const newCookies = Array.isArray(result.headers["set-cookie"])
          ? result.headers["set-cookie"]
          : [result.headers["set-cookie"]];
        const cookieParts = newCookies.map(c => c.split(";")[0]);
        const combined = existing ? existing + "; " + cookieParts.join("; ") : cookieParts.join("; ");
        cookieJar.set(sessionId, combined);
      }

      const respHeaders = {
        ...cors,
        "Content-Type": result.headers["content-type"] || "application/octet-stream",
      };

      res.writeHead(result.statusCode, respHeaders);
      res.end(result.body);

    } catch (e) {
      res.writeHead(502, { ...cors, "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "Proxy error: " + (e.message || "Unknown") }));
    }
    return;
  }

  res.writeHead(404, cors);
  res.end("Not found");
});

server.listen(PORT, "127.0.0.1", () => {
  console.log("");
  console.log("  ==========================================");
  console.log("  Migration Suite - Local Proxy Server");
  console.log("  ==========================================");
  console.log("");
  console.log("  Running at:  http://localhost:" + PORT);
  console.log("");
  console.log("  Open the URL above in your browser.");
  console.log("  Press Ctrl+C to stop.");
  console.log("");
});
