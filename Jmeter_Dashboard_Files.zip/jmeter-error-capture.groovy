// ============================================================================
// JMeter JSR223 PostProcessor - Error Detail Capture (with Trace ID)
// ============================================================================
// HOW TO USE:
//   1. Add a JSR223 PostProcessor under your Thread Group (or a specific sampler)
//   2. Set Language = groovy
//   3. Paste this entire file into the Script box
//   4. Run your test. A file "error-details.csv" is written to your JMeter
//      working directory (the folder you launched JMeter from / your .jmx folder)
//   5. Upload that CSV to the dashboard's Request Log viewer
//
// Logs ONLY failed requests. Bodies truncated to 500 chars so the file stays small.
// Columns: Timestamp,ThreadName,Label,ResponseCode,ResponseMessage,
//          Elapsed,URL,TraceId,RequestBody,ResponseBody
// ============================================================================

import java.text.SimpleDateFormat
import java.util.regex.Pattern
import java.util.regex.Matcher

// ---- Configuration ---------------------------------------------------------
String ERROR_LOG_FILE = "error-details.csv"   // file name
int    MAX_BODY_CHARS = 500                    // truncate request/response bodies

// Trace ID header names to look for (case-insensitive). Add your own if needed.
List<String> TRACE_HEADERS = [
    "X-B3-TraceId",
    "X-Trace-Id",
    "X-Request-Id",
    "X-Correlation-Id",
    "traceparent",
    "X-Amzn-Trace-Id",
    "uber-trace-id",
    "x-datadog-trace-id",
    "X-Cloud-Trace-Context",
    "Request-Id",
    "x-ms-request-id"
]
// ----------------------------------------------------------------------------

// Skip successful samples - nothing to log
if (prev.isSuccessful()) {
    return
}

// ---- Output file: saved to JMeter's current working directory --------------
// new File("name") resolves to the directory JMeter was started from,
// which is normally your project / .jmx folder.
File logFile = new File(ERROR_LOG_FILE)

// Write the header row once
if (!logFile.exists() || logFile.length() == 0L) {
    logFile.setText("Timestamp,ThreadName,Label,ResponseCode,ResponseMessage,Elapsed,URL,TraceId,RequestBody,ResponseBody\n", "UTF-8")
}

// ---- Standard fields -------------------------------------------------------
SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
String timestamp    = sdf.format(new Date(prev.getTimeStamp()))
String threadName   = prev.getThreadName()
String label        = prev.getSampleLabel()
String responseCode = prev.getResponseCode()
String responseMsg  = prev.getResponseMessage()
String elapsed      = String.valueOf(prev.getTime())
String url          = ""
try { url = prev.getUrlAsString() } catch (Exception e) { url = "" }

if (threadName == null)   threadName = ""
if (label == null)        label = ""
if (responseCode == null) responseCode = ""
if (responseMsg == null)  responseMsg = ""
if (url == null)          url = ""

// ---- Helper: find a header value by name in a raw header block -------------
// Header block format is "Name: value" lines separated by newlines.
String findHeaderValue(String headerBlock, String headerName) {
    if (headerBlock == null || headerBlock.length() == 0) return ""
    String pat = "(?im)^" + Pattern.quote(headerName) + "\\s*:\\s*(.+)\$"
    Matcher m = Pattern.compile(pat).matcher(headerBlock)
    if (m.find()) {
        return m.group(1).trim()
    }
    return ""
}

// ---- Extract Trace ID ------------------------------------------------------
String traceId = ""

// 1) Response headers
String respHeaders = ""
try { respHeaders = prev.getResponseHeaders() } catch (Exception e) { respHeaders = "" }
if (respHeaders == null) respHeaders = ""

for (String h : TRACE_HEADERS) {
    String v = findHeaderValue(respHeaders, h)
    if (v != null && v.length() > 0) {
        traceId = v
        break
    }
}

// 2) Request headers (fallback)
if (traceId.length() == 0) {
    String reqHeaders = ""
    try { reqHeaders = prev.getRequestHeaders() } catch (Exception e) { reqHeaders = "" }
    if (reqHeaders == null) reqHeaders = ""
    for (String h : TRACE_HEADERS) {
        String v = findHeaderValue(reqHeaders, h)
        if (v != null && v.length() > 0) {
            traceId = v
            break
        }
    }
}

// 3) Response body (fallback) - search first 2000 chars for common id patterns
if (traceId.length() == 0) {
    String body = ""
    try { body = prev.getResponseDataAsString() } catch (Exception e) { body = "" }
    if (body == null) body = ""
    String area = body.length() > 2000 ? body.substring(0, 2000) : body

    // Patterns built as plain strings (no slashy regex literals)
    List<String> bodyPatterns = [
        "(?i)[\"']?(?:trace[_-]?id|traceid|correlation[_-]?id|request[_-]?id)[\"']?\\s*[:=]\\s*[\"']?([A-Za-z0-9_-]{8,64})",
        "(?i)<(?:trace[_-]?id|traceid|correlationid|requestid)>([^<]+)<",
        "(?i)traceparent[\"']?\\s*[:=]\\s*[\"']?00-([a-f0-9]{32})-"
    ]
    for (String p : bodyPatterns) {
        Matcher m = Pattern.compile(p).matcher(area)
        if (m.find()) {
            traceId = m.group(1).trim()
            break
        }
    }
}

// Normalize composite trace formats
if (traceId.length() > 0) {
    // W3C traceparent: 00-<traceId>-<spanId>-<flags>
    if (traceId.startsWith("00-") && traceId.contains("-")) {
        String[] parts = traceId.split("-")
        if (parts.length >= 2) traceId = parts[1]
    }
    // Jaeger uber-trace-id: <traceId>:<spanId>:<parentId>:<flags>
    else if (traceId.contains(":")) {
        traceId = traceId.split(":")[0]
    }
    // AWS X-Ray: Root=1-xxxx-yyyy;...
    else if (traceId.contains("Root=")) {
        Matcher rm = Pattern.compile("Root=([^;]+)").matcher(traceId)
        if (rm.find()) traceId = rm.group(1).trim()
    }
}

// ---- Request body (strip HTTP header lines, keep only the payload) ---------
String requestBody = ""
try {
    String samplerData = prev.getSamplerData()
    if (samplerData != null && samplerData.length() > 0) {
        int bodyStart = samplerData.indexOf("\n\n")
        if (bodyStart >= 0 && bodyStart < samplerData.length() - 2) {
            requestBody = samplerData.substring(bodyStart + 2).trim()
        } else {
            // No header/body separator. Skip if it looks like a request line.
            boolean looksLikeHeaders =
                samplerData.startsWith("GET ")    || samplerData.startsWith("POST ")  ||
                samplerData.startsWith("PUT ")    || samplerData.startsWith("DELETE ")||
                samplerData.startsWith("PATCH ")  || samplerData.startsWith("HEAD ")  ||
                samplerData.startsWith("OPTIONS ")
            if (!looksLikeHeaders) {
                requestBody = samplerData.trim()
            }
        }
    }
} catch (Exception e) {
    requestBody = ""
}

// ---- Response body ---------------------------------------------------------
String responseBody = ""
try {
    String rb = prev.getResponseDataAsString()
    if (rb != null) responseBody = rb.trim()
} catch (Exception e) {
    responseBody = ""
}

// ---- Truncate to keep file small -------------------------------------------
if (requestBody.length() > MAX_BODY_CHARS) {
    requestBody = requestBody.substring(0, MAX_BODY_CHARS) + "...[truncated]"
}
if (responseBody.length() > MAX_BODY_CHARS) {
    responseBody = responseBody.substring(0, MAX_BODY_CHARS) + "...[truncated]"
}

// ---- CSV escape helper -----------------------------------------------------
String csvEscape(String val) {
    if (val == null || val.length() == 0) return ""
    String v = val.replaceAll("\\r", " ").replaceAll("\\n", " ")
    v = v.replace("\"", "\"\"")
    if (v.contains(",") || v.contains("\"") || v.contains("|")) {
        return "\"" + v + "\""
    }
    return v
}

// ---- Build and append the CSV row ------------------------------------------
StringBuilder sb = new StringBuilder()
sb.append(csvEscape(timestamp)).append(",")
sb.append(csvEscape(threadName)).append(",")
sb.append(csvEscape(label)).append(",")
sb.append(csvEscape(responseCode)).append(",")
sb.append(csvEscape(responseMsg)).append(",")
sb.append(csvEscape(elapsed)).append(",")
sb.append(csvEscape(url)).append(",")
sb.append(csvEscape(traceId)).append(",")
sb.append(csvEscape(requestBody)).append(",")
sb.append(csvEscape(responseBody)).append("\n")

// Append (synchronized to avoid interleaved lines from multiple threads)
synchronized (ERROR_LOG_FILE) {
    logFile.append(sb.toString(), "UTF-8")
}
