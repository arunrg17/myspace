package com.apitest.runner;

import com.apitest.comparator.AssertionEngine;
import com.apitest.comparator.Comparator;
import com.apitest.dispatcher.Dispatcher;
import com.apitest.dispatcher.Response;
import com.apitest.excel.ExcelLoader;
import com.apitest.model.*;
import com.apitest.template.TemplateEngine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Orchestrates: load suite → execute steps → compare/assert → record results.
 *
 * Comparison modes:
 *   vs_expected      Run on source A, compare to expected file
 *   vs_env           Run on source A and source B, compare responses
 *   vs_protocol      Run on two different protocols, compare normalized
 *   assert_only      Run on source A, validate field-level assertions
 *   chain            Run all steps in order, no comparison
 */
public class Runner {

    private static final DateTimeFormatter TS_FOLDER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    private static final DateTimeFormatter TS_DISPLAY = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static List<TestResult> runAll(Path suitePath, Path projectRoot) throws Exception {
        TestSuite suite = ExcelLoader.load(suitePath);
        Path outputRoot = projectRoot.resolve("output").resolve(LocalDateTime.now().format(TS_FOLDER));
        Files.createDirectories(outputRoot);

        List<TestResult> results = new ArrayList<>();
        for (TestCase tc : suite.tests()) {
            System.out.println("  Running " + tc.testId + ": " + tc.name);
            results.add(runTest(tc, suite, projectRoot, outputRoot));
        }
        return results;
    }

    public static TestResult runTest(TestCase tc, TestSuite suite, Path projectRoot, Path outputRoot)
            throws Exception {

        long started = System.currentTimeMillis();
        Path testOut = outputRoot.resolve(tc.testId);
        Files.createDirectories(testOut);

        TestResult result = new TestResult();
        result.testId = tc.testId;
        result.name = tc.name;
        result.description = tc.description;
        result.comparisonMode = tc.comparisonMode;
        result.sourceA = tc.sourceA;
        result.sourceB = tc.sourceB;
        result.started = LocalDateTime.now().format(TS_DISPLAY);

        Environment envA = suite.environments().get(tc.sourceA);
        if (envA == null) {
            result.status = "ERROR";
            result.error = "Unknown environment: " + tc.sourceA;
            result.durationMs = System.currentTimeMillis() - started;
            return result;
        }

        result.stepsA = executeSteps(tc.steps, envA, tc.data, projectRoot, testOut.resolve("sourceA"));
        if (result.stepsA.stream().anyMatch(s -> !s.passed)) {
            result.status = "FAIL";
            result.error = "One or more steps in source A failed";
            result.durationMs = System.currentTimeMillis() - started;
            return result;
        }

        String mode = tc.comparisonMode == null ? "" : tc.comparisonMode;

        // Assertions can run on the final A response regardless of mode (except chain)
        if (!tc.assertions.isEmpty() && !"chain".equals(mode)) {
            String lastA = result.stepsA.get(result.stepsA.size() - 1).responseBody;
            result.assertionResults = AssertionEngine.evaluate(lastA, tc.assertions);
        }

        switch (mode) {
            case "chain" -> { /* nothing further */ }

            case "assert_only" -> {
                if (result.assertionResults.isEmpty()) {
                    result.status = "ERROR";
                    result.error = "assert_only mode requires at least one assertion";
                }
            }

            case "vs_expected" -> {
                String lastA = result.stepsA.get(result.stepsA.size() - 1).responseBody;
                Path expectedPath = projectRoot.resolve(tc.expectedFile);
                if (!Files.exists(expectedPath)) {
                    result.status = "ERROR";
                    result.error = "Expected file not found: " + tc.expectedFile;
                } else {
                    String expected = Files.readString(expectedPath);
                    result.compareResult = Comparator.compare(expected, lastA, tc.assertions);
                }
            }

            case "vs_env", "vs_protocol" -> {
                Environment envB = suite.environments().get(tc.sourceB);
                if (envB == null) {
                    result.status = "ERROR";
                    result.error = "Unknown environment: " + tc.sourceB;
                } else {
                    result.stepsB = executeSteps(tc.steps, envB, tc.data, projectRoot, testOut.resolve("sourceB"));
                    if (result.stepsB.stream().anyMatch(s -> !s.passed)) {
                        result.status = "FAIL";
                        result.error = "One or more steps in source B failed";
                    } else {
                        String lastA = result.stepsA.get(result.stepsA.size() - 1).responseBody;
                        String lastB = result.stepsB.get(result.stepsB.size() - 1).responseBody;
                        result.compareResult = Comparator.compare(lastA, lastB, tc.assertions);
                    }
                }
            }

            default -> {
                result.status = "ERROR";
                result.error = "Unknown comparison mode: " + mode;
            }
        }

        // Final pass/fail determination
        if (!"ERROR".equals(result.status)) {
            boolean assertionsPassed = result.assertionResults.stream().allMatch(a -> a.passed);
            boolean compareMatched = result.compareResult == null || result.compareResult.matched;
            result.status = (assertionsPassed && compareMatched) ? "PASS" : "FAIL";
        }

        result.durationMs = System.currentTimeMillis() - started;
        return result;
    }

    // ------------------------------------------------------------------

    private static List<StepResult> executeSteps(List<Step> steps, Environment env,
                                                 Map<String, String> data, Path projectRoot,
                                                 Path outputDir) throws Exception {
        List<StepResult> results = new ArrayList<>();
        Map<Integer, Map<String, String>> stepVars = new LinkedHashMap<>();
        Files.createDirectories(outputDir);

        for (Step step : steps) {
            String endpoint;
            String body = "";
            Response resp;
            try {
                endpoint = TemplateEngine.render(step.endpoint(), data, stepVars);
                if (step.bodyTemplate() != null && !step.bodyTemplate().isEmpty()) {
                    body = TemplateEngine.renderFile(step.bodyTemplate(), data, stepVars, projectRoot);
                }
            } catch (IllegalStateException ex) {
                // Template rendering failed (e.g. all placeholders unresolved,
                // or required placeholder missing). Record a failed step result
                // with a clear message rather than letting the exception bubble
                // out and kill the whole suite.
                resp = new Response();
                resp.url = step.endpoint();
                resp.status = 0;
                resp.body = "";
                resp.error = "Template error: " + ex.getMessage();

                StepResult sr = new StepResult();
                sr.order = step.order();
                sr.name = step.name();
                sr.url = resp.url;
                sr.method = step.method();
                sr.requestBody = "";
                sr.responseBody = "";
                sr.status = 0;
                sr.expectedStatus = step.expectedStatus();
                sr.passed = false;
                sr.error = resp.error;
                results.add(sr);
                continue;
            }

            resp = Dispatcher.send(
                    env.protocol(), env.baseUrl(), endpoint, step.method(),
                    body, env.extraHeaders(), env.authType(), env.authValue(),
                    env.sslConfig()
            );

            Map<String, String> extracted = new LinkedHashMap<>();
            for (Map.Entry<String, String> ev : step.extractVars().entrySet()) {
                extracted.put(ev.getKey(), Comparator.extractVariable(resp.body, ev.getValue()));
            }
            stepVars.put(step.order(), extracted);

            boolean passed = step.expectedStatus().contains(resp.status) && resp.error == null;

            Path stepDir = outputDir.resolve("step" + step.order() + "_"
                    + step.name().replaceAll("[^a-zA-Z0-9._-]", "_"));
            Files.createDirectories(stepDir);
            Files.writeString(stepDir.resolve("request.txt"),
                    step.method() + " " + resp.url + "\n\n" + body);
            Files.writeString(stepDir.resolve("response.txt"),
                    "HTTP " + resp.status + "\nelapsed: " + resp.elapsedMs + "ms\n\n" + resp.body);

            StepResult sr = new StepResult();
            sr.name = step.name();
            sr.order = step.order();
            sr.method = step.method();
            sr.url = resp.url;
            sr.status = resp.status;
            sr.expectedStatus = step.expectedStatus();
            sr.elapsedMs = resp.elapsedMs;
            sr.requestBody = body;
            sr.responseBody = resp.body;
            sr.extracted = extracted;
            sr.error = resp.error;
            sr.passed = passed;
            results.add(sr);

            if (!passed) break;
        }
        return results;
    }
}
