# xml-json-differ v1.1.0 - Enhancement Plan

**Status:** In Development  
**Based on:** Production feedback from office testing  
**Version:** 1.1.0 (Enhancement Release)

---

## Issues Identified & Solutions

### Issue 1: UTF-8 BOM Encoding Problem ❌

**Problem:**
- JSON files with UTF-8 BOM (Byte Order Mark) cause parsing errors
- Error: Invalid characters at start of JSON

**Solution:**
```java
// Add BOM stripping in DocumentParser
private String stripBOM(String content) {
    if (content.startsWith("\uFEFF")) {
        return content.substring(1);
    }
    return content;
}

// Apply before parsing
public DiffNode parse(String content, String format) throws Exception {
    content = stripBOM(content);  // Remove BOM first
    // ... then parse
}
```

**Status:** ✅ SOLUTION READY

---

### Issue 2: Sticky Filter Header ❌

**Problem:**
- Filter ribbon doesn't stick to top when scrolling
- User must scroll back up to change filters

**Solution:**
```css
/* Make toolbar sticky */
.toolbar {
    position: sticky;
    top: 60px;  /* Below the main header */
    z-index: 99;
    background: white;
    border-bottom: 1px solid #ddd;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.diff-header {
    position: sticky;
    top: 110px;  /* Below toolbar */
    z-index: 98;
}
```

**Status:** ✅ SOLUTION READY

---

### Issue 3: Structure & Indentation Lost ❌

**Problem:**
- HTML output shows flattened diff
- Original XML/JSON structure and indentation not preserved
- Hard to understand nested context

**Solution:**
Enhance DiffLine to include indentation level and original structure:

```java
class DiffLine {
    int depth;              // Nesting level
    String parentPath;      // e.g. "root/user/address"
    boolean isOpening;      // Opening bracket/tag
    boolean isClosing;      // Closing bracket/tag
    String originalKey;     // Original formatting
}
```

HTML rendering with proper indentation:
```html
<div class="diff-row" style="--depth: 2">
    <span class="indent"></span>
    <span class="content">user: {</span>
</div>
```

CSS for indentation:
```css
.indent {
    width: calc(var(--depth) * 20px);
    display: inline-block;
}
```

**Status:** ✅ SOLUTION READY

---

### Issue 4: Handle Jumbled Child Items ❌

**Problem:**
- If array/object children are in different order, marked as modified
- No intelligent matching by content
- Example: 
  ```
  File1: [item1, item2, item3]
  File2: [item3, item1, item2]  // Same items, different order
  ```
  Currently marks all 3 as modified

**Solution:**
Implement content-based matching for arrays:

```java
// In DiffEngine
private Map<String, DiffNode> createContentHash(List<DiffNode> nodes) {
    Map<String, DiffNode> contentMap = new HashMap<>();
    for (DiffNode node : nodes) {
        String hash = computeNodeHash(node);
        contentMap.put(hash, node);
    }
    return contentMap;
}

private String computeNodeHash(DiffNode node) {
    // Hash based on content, not position
    return MD5(node.toString());
}
```

**Benefits:**
- Recognizes same items in different order
- Marks as "reordered" not "modified"
- Reduces false positives

**Status:** ✅ SOLUTION READY

---

### Issue 5: XML vs JSON Comparison ❌

**Problem:**
- Direct XML ↔ JSON comparison fails
- Current workaround: Manual conversion + compare
- Need: Smart internal conversion

**Solution:**
Create normalized tree structure:

```java
// New approach: Normalize to canonical form
private DiffNode normalizeTree(DiffNode input) {
    // Convert both XML and JSON to common tree structure
    // XML attributes become nodes
    // JSON objects become nodes
    // All normalized to same format for comparison
    return normalizedTree;
}

// Then compare normalized trees
DiffNode normalized1 = normalizeTree(xmlTree);
DiffNode normalized2 = normalizeTree(jsonTree);
DiffResult result = engine.diff(normalized1, normalized2);
```

**HTML Output:**
- Shows original format in both columns
- But comparison is on normalized structure
- Visual indicator: "cross-format comparison"

**Status:** ✅ SOLUTION READY

---

### Issue 6: Ignore Fields Configuration ❌

**Problem:**
- No way to ignore timestamp fields
- Dates, trace IDs, request IDs always show as different
- Clutters real differences

**Solution:**
Create config file with ignore patterns:

```yaml
# differ-config.yaml
ignore:
  patterns:
    - ".*timestamp.*"
    - ".*date.*"
    - ".*time.*"
    - ".*traceId.*"
    - ".*requestId.*"
    - ".*correlationId.*"
    - ".*uuid.*"
  
  exact:
    - "root/meta/updated_at"
    - "root/response/generated_on"
    
  paths:
    - "^root/audit/.*"
    - "^root/logs/.*"

normalization:
  lowercase: false
  trim_strings: true
  ignore_null_vs_empty: false
```

**Implementation:**

```java
public class IgnoreConfig {
    List<Pattern> patterns;
    Set<String> exactPaths;
    List<Pattern> pathPatterns;
    
    public boolean shouldIgnore(String path, String key) {
        // Check exact path
        if (exactPaths.contains(path)) return true;
        
        // Check patterns
        for (Pattern p : patterns) {
            if (p.matcher(key).matches()) return true;
        }
        
        // Check path patterns
        for (Pattern p : pathPatterns) {
            if (p.matcher(path).matches()) return true;
        }
        
        return false;
    }
}
```

**Usage:**
```bash
java -jar xml-json-differ.jar \
  file1.json file2.json \
  --config differ-config.yaml \
  output.html
```

**Status:** ✅ SOLUTION READY

---

## Implementation Priority

| Priority | Issue | Effort | Impact |
|----------|-------|--------|--------|
| 🔴 HIGH | BOM Encoding | 2 hours | Critical bug fix |
| 🟠 MEDIUM | Sticky Header | 1 hour | UX improvement |
| 🟠 MEDIUM | Structure/Indent | 4 hours | Major feature |
| 🟡 LOW | Jumbled Items | 6 hours | Nice-to-have |
| 🔴 HIGH | XML↔JSON | 8 hours | Key feature |
| 🟠 MEDIUM | Ignore Config | 4 hours | Practical feature |

**Estimated Total:** 25 hours

---

## Files to Modify/Create

### Modified Files:
1. `DocumentParser.java` - Add BOM handling
2. `HtmlReportGenerator.java` - Add sticky CSS, improve structure
3. `DiffEngine.java` - Add content hashing, normalization
4. `Main.java` - Add config file support

### New Files:
1. `IgnoreConfig.java` - Configuration handling
2. `NormalizedTree.java` - Canonical form conversion
3. `ContentHasher.java` - Content-based matching
4. `ConfigLoader.java` - YAML config parsing

### Test Files:
1. `BOMEncodingTest.java` - BOM handling tests
2. `StructurePreservationTest.java` - Indentation tests
3. `JumbledItemsTest.java` - Order-independent matching
4. `CrossFormatTest.java` - XML↔JSON tests
5. `IgnoreConfigTest.java` - Config file tests

---

## Breaking Changes: NONE

All changes are backward compatible. Existing usage will continue to work:
- Config file is optional
- Default behavior unchanged
- New features are opt-in

---

## Version 1.1.0 New Features

✅ UTF-8 BOM handling  
✅ Sticky filter header  
✅ Structure preservation with indentation  
✅ Smart order-independent array matching  
✅ Cross-format XML↔JSON comparison with conversion  
✅ Field ignore configuration via YAML  

---

## Testing Strategy

### Unit Tests (Estimated)
- BOM encoding: 3 tests
- Structure preservation: 5 tests
- Jumbled items: 4 tests
- XML↔JSON normalization: 8 tests
- Ignore config: 6 tests

**Total: 26 new tests** (in addition to existing 72)

### Integration Tests
- End-to-end with config file
- Real-world file samples
- Performance benchmarks

---

## Documentation Updates Required

1. **README.md** - Add new features section
2. **QUICKSTART.md** - Add config file examples
3. **API_DOCUMENTATION.md** - Document new classes
4. **LIBRARY_INTEGRATION_GUIDE.md** - Update for new APIs
5. **CONFIG_REFERENCE.md** - NEW: Complete YAML config guide
6. **MIGRATION_GUIDE.md** - NEW: Upgrade from v1.0 to v1.1

---

## Release Plan

**Phase 1 (Week 1):** 
- BOM handling (critical)
- Sticky header (quick win)

**Phase 2 (Week 2):**
- Structure preservation
- Ignore config

**Phase 3 (Week 3):**
- Jumbled items handling
- XML↔JSON normalization

**Phase 4 (Week 4):**
- Testing & polish
- Documentation
- Release v1.1.0

---

## Success Criteria

- ✅ All 6 issues resolved
- ✅ Zero regression in existing tests
- ✅ 26 new tests added (all passing)
- ✅ Comprehensive documentation
- ✅ Real-world file samples working
- ✅ Performance within 10% of v1.0

---

## Next Steps

1. Review this plan with team
2. Prioritize implementation
3. Create feature branches
4. Develop & test each enhancement
5. Integration testing
6. Documentation review
7. Release v1.1.0

---

**Prepared by:** Development Team  
**Date:** 2026-04-21  
**Status:** Ready for Implementation
