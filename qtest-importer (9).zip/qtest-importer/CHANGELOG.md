# Changelog

All notable changes to the qTest Test Case Importer are documented here.

Versioning follows [Semantic Versioning](https://semver.org/):
- **MAJOR** version for incompatible or breaking changes
- **MINOR** version for new functionality in a backward-compatible manner
- **PATCH** version for backward-compatible bug fixes

## [2.5.0]

### Fixed
- **Requirement and defect property fields are now imported.** Previously only name
  and description were sent for requirements (other mapped columns were silently
  dropped). Both now fetch their own field definitions and send all mapped property
  fields, with dropdown values resolved against the correct artifact's fields.

### Added
- **`list-fields` accepts an artifact type**: `list-fields requirements` and
  `list-fields defects` (default remains test cases). Shows the built-in targets and
  project fields for that artifact.
- **Rich text now applies to requirements and defects** as well as test cases.
- **Batch import handles requirements and defects.** The manifest gains an optional
  4th column for type (`testcases`, `requirements`, or `defects`); it defaults to
  `testcases`, so existing manifests keep working.
- `import-requirements` and `import-defects` now accept `--attachments-dir`.

## [2.4.0]

### Added
- **Multiple requirement links per test case.** The requirement reference column may
  list several IDs separated by semicolons (e.g. `REQ_001;REQ_002`); each is resolved
  and linked independently.

### Changed
- **Rich-text setting now takes effect.** `import.rich.text` previously had no effect.
  When false (default), HTML tags in description/precondition/step fields are stripped
  and common entities decoded so values are sent as plain text. When true, HTML is
  preserved. Plain values with no markup are passed through untouched.

### Removed
- Dead/unused code removed during a cleanup pass; verified no unused private methods,
  fields, or imports remain.

## [2.3.0]

### Added
- **Automatic requirement linking via ALM ID mapping file.** When requirements are
  imported, the tool writes a `requirement-mapping.csv` file that maps ALM
  `Requirement ID` values to the qTest IDs assigned during import. The subsequent
  test case import reads this mapping file to resolve the same ALM requirement IDs
  automatically, so no manual PID lookup is needed regardless of scale.
- The mapping file path is configurable via `import.requirement.mapping.file`
  (default: `requirement-mapping.csv`).

### Changed
- The `requirement` mapping target now serves both commands: in `import-requirements`
  it captures the ALM ID for the mapping file, and in `import` (test cases) it
  captures the reference for linking. One config line handles both.
- Requirement resolution now checks the mapping CSV first (ALM IDs), then falls
  back to the qTest API (PIDs and names). This means existing qTest PIDs and names
  still work as references, but ALM IDs are resolved without hitting the API.

## [2.2.0]

### Added
- **Attachments** on test cases and individual steps. File names are listed in
  columns mapped to `attachments` (test-case level) and `step.attachments` (step
  level), separated by semicolons, and resolved against an attachments base folder
  (`import.attachments.dir` or `--attachments-dir`). Files upload after each test
  case is created.
- **Requirements import and linking**:
  - `import-requirements <file>` creates requirements (with their own attachments).
  - A column mapped to `requirement` links each test case to a requirement by PID
    or name after the test case is created.
- **Defect import**: `import-defects <file>` creates defects with their fields and
  attachments.
- **Rich text passthrough** via `import.rich.text=true`, so basic HTML formatting
  in description/precondition/step fields is preserved (qTest retains structural
  HTML but strips custom fonts, colours, and CSS).
- New option `--attachments-dir <dir>` to set the attachments base folder per run.

### Notes
- Attachment binaries are referenced by file name in a column and read from the
  attachments folder; the spreadsheet itself does not carry the binaries.
- Defect import assumes native qTest defects; projects integrated with an external
  defect tracker manage defects in that system instead.

## [2.1.0]

### Changed
- The configuration file is now shipped with the package as a ready-to-edit
  `qtest-config.properties`. The `generate-config` command has been removed, along
  with its supporting code, since the file is provided directly.
- Every method now carries a Javadoc comment describing its purpose, parameters,
  and return value, and inline comments explain the non-obvious logic.

### Removed
- `generate-config` command and the unused timestamp helper it relied on.

## [2.0.0]

### Added
- **Folder (module) management**:
  - `create-folder <path>` command creates a folder hierarchy in qTest
    (e.g. `"Regression\Sprint5"`), creating any missing parent folders.
  - `--folder <path>` option on `import` directs test cases into a specific folder.
  - `--create-folder` flag creates the target folder path if it does not exist.
- **Batch import** via `import-batch <manifest>`:
  - Imports multiple Excel/CSV files in one run.
  - Each file can target a different folder: create a new folder, use an existing
    folder, or import at the project root — specified per-file in the manifest.
  - Manifest format: `<file> | <action> | <folder path>` where action is
    `create`, `existing`, or `root`.
  - All files and folder targets are validated before any import begins.
  - A consolidated success/failure summary and error log is produced.
- Sample manifest file (`sample-manifest.txt`) included.

### Changed
- Internal import pipeline refactored to return structured results, enabling
  aggregation across multiple files in batch mode.
- Module lookups now query qTest level-by-level for accurate path resolution.

## [1.1.1]

### Fixed
- **Test step ordering rejected by qTest** ("testSteps[0].order should be greater
  than 1"). The qTest API expects step order to start at 1, not 0. Reverted to
  1-based ordering and made it configurable via `import.step.start.order` (default 1)
  so instances expecting zero-based ordering can override it without code changes.

## [1.1.0]

### Fixed
- **Excel (.xlsx) reading failure** — The shaded JAR was missing the OOXML
  `WorkbookProvider` service registration because competing `META-INF/services`
  files from POI's modules overwrote each other during packaging. Added the
  Maven Shade `ServicesResourceTransformer` to merge them. Both `.xls` and
  `.xlsx` now work from the fat JAR.
- **log4j `NoClassDefFoundError` at startup** — Replaced the previous log4j-api
  exclusion (which broke POI's class loading) with the `log4j-to-slf4j` bridge
  routed to `slf4j-nop`. The vulnerable `log4j-core` remains absent.

### Changed
- **Test step ordering** — Steps are now zero-indexed to match qTest's internal
  ordering. ALM exports starting at step 1 are automatically shifted so the first
  step becomes order 0.

## [1.0.0]

### Added
- Initial release.
- Bulk import of test cases from ALM-exported Excel/CSV into qTest.
- OAuth authentication via `POST /oauth/token` using standard user credentials.
- ALM multi-row-per-test-case grouping (metadata in first row, steps across rows).
- Configurable field mapping via properties file.
- Automatic dropdown value resolution by label.
- Multi-value field support (array wrapping).
- Dry-run validation mode with sample payload output.
- Batch import with configurable size and delay.
- Per-record error logging.
- Discovery commands: `list-projects`, `list-fields`, `list-modules`.
